<?php

return [
    'version' => '1.0.5',
    'brand_default' => 'مهدوب',
    'brand_en' => 'Mahdweb',
];
