<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<title>@yield('title', 'پنل مهدوب')</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;800&family=JetBrains+Mono:wght@500&display=swap">
<link rel="stylesheet" href="{{ asset('css/admin.css') }}">
</head>
<body class="admin-shell">
@php($errN = \App\Support\ErrorLog::openCount())
<aside class="sidebar" id="sidebar">
  <a class="side-brand" href="{{ route('admin.dashboard') }}">
    <span class="mark"></span>
    <span>
      <b>پنل {{ config('mahdwob.brand_en', 'Mahdweb') }}</b>
      <small class="ltr">v{{ config('mahdwob.version') }}</small>
    </span>
  </a>
  <nav class="side-nav">
    <a href="{{ route('admin.dashboard') }}" @class(['on' => request()->routeIs('admin.dashboard')])>داشبورد</a>
    <a href="{{ route('admin.orders.index') }}" @class(['on' => request()->routeIs('admin.orders*')])>سفارش‌ها</a>
    <a href="{{ route('admin.products.index') }}" @class(['on' => request()->routeIs('admin.products*')])>محصولات</a>
    <a href="{{ route('admin.settings') }}" @class(['on' => request()->routeIs('admin.settings')])>تنظیمات</a>
    <div class="side-sep">ابزارها</div>
    <a href="{{ route('admin.tools.update') }}" @class(['on' => request()->routeIs('admin.tools.update*')])>به‌روزرسانی</a>
    <a href="{{ route('admin.tools.backups') }}" @class(['on' => request()->routeIs('admin.tools.backups*')])>پشتیبان‌گیری</a>
    <a href="{{ route('admin.tools.errors') }}" @class(['on' => request()->routeIs('admin.tools.errors*')])>گزارش خطاها @if($errN)<span class="badge">{{ \App\Support\Fa::digits($errN) }}</span>@endif</a>
  </nav>
  <div class="side-foot">
    <a href="{{ route('home') }}" target="_blank" rel="noopener">مشاهده سایت</a>
    <form method="POST" action="{{ route('admin.logout') }}">@csrf<button type="submit">خروج</button></form>
  </div>
</aside>

<div class="admin-main">
  <header class="topbar">
    <button type="button" class="menu-btn" id="menuBtn" aria-label="منو">☰</button>
    <h1 class="top-title">@yield('title', 'پنل مهدوب')</h1>
    <span class="chip">{{ auth()->user()->email ?? 'مدیر' }}</span>
  </header>
  <main class="box">
    @if(session('ok'))<div class="alert ok">{{ session('ok') }}</div>@endif
    @if(session('warn'))<div class="alert warn">{{ session('warn') }}</div>@endif
    @if(session('err'))<div class="alert err" style="white-space:pre-line">{{ session('err') }}</div>@endif
    @if(isset($errors) && ($errors->has('file') || $errors->has('package')))<div class="alert err">{{ $errors->first('file') ?: $errors->first('package') }}</div>@endif
    @yield('content')
  </main>
</div>
<script>
(function(){
  var btn=document.getElementById('menuBtn');
  var side=document.getElementById('sidebar');
  if(btn&&side){btn.addEventListener('click',function(){side.classList.toggle('open');document.body.classList.toggle('side-open');});}
})();
</script>
</body>
</html>
