<?php

return [
    'version' => '1.0.2',
    'brand_default' => 'مهدوب',
];
