# مهدوب ۱.۰.۲ — فروشگاه لایسنس

فروش اسکریپت فروشگاهی/شرکتی و افزونه لاراول با لایسنس دامنه.
پرداخت کارت‌به‌کارت · فعال‌سازی دستی.

## دانلود بسته آماده نصب
فایل: `dist/mahdwob-1.0.2.zip`  
داخل بسته پوشه `vendor` هست — **Composer لازم نیست**.

### نصب روی هاست (عمومی‌ترین حالت)
1. PHP دامنه را **۸٫۳** کنید  
2. zip را در `public_html` آپلود و **Extract** کنید (محتوا مستقیم در ریشه باشد)  
3. مجوز `storage` و `bootstrap/cache` را **۷۷۵** کنید  
4. **آدرس سایت** را در مرورگر باز کنید  
5. دکمه **نصب مهدوب — یک کلیک** (SQLite خودکار)

سایت: `/` · پنل: `/admin`

جزئیات: فایل `راهنمای-نصب.html` داخل بسته.

## امکانات
- صفحه اصلی، محصول، سفارش
- نمایش شماره کارت بعد از سفارش
- پنل: سفارش‌ها، صدور لایسنس، محصولات، تنظیمات کارت

## توسعه محلی
```bash
cd mahdwob
composer install
cp .env.example .env && php artisan key:generate
touch storage/app/database/mahdwob.sqlite
# DB_DATABASE را در .env به مسیر sqlite بدهید
php artisan migrate
php artisan serve
```
