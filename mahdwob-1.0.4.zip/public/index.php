<?php

use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

$faPage = static function (string $title, string $html, int $code = 500): void {
    http_response_code($code);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        .'<title>'.htmlspecialchars($title, ENT_QUOTES, 'UTF-8').'</title>'
        .'<body style="font-family:Tahoma,sans-serif;max-width:600px;margin:60px auto;padding:0 16px;line-height:2;color:#0B1A33;background:#F4F8FC">'
        .$html.'</body></html>';
    exit;
};

// نسخه PHP هاست کمتر از نیاز برنامه است
if (PHP_VERSION_ID < 80200) {
    $faPage('نسخه PHP', '<h2>نسخه PHP هاست را بالا ببرید</h2><p>نسخه فعلی: <b dir="ltr">'.PHP_VERSION.'</b> — این سایت به <b>PHP 8.2 یا بالاتر</b> (پیشنهاد: 8.3) نیاز دارد.</p>'
        .'<ol><li>وارد cPanel شوید.</li><li>بخش <b>Select PHP Version</b> یا <b>MultiPHP Manager</b> را باز کنید.</li><li>نسخه <b>8.3</b> را برای این دامنه انتخاب و ذخیره کنید.</li><li>این صفحه را دوباره باز کنید.</li></ol>');
}

// در حال به‌روزرسانی
$updFlag = __DIR__.'/../storage/framework/updating';
if (is_file($updFlag) && @filemtime($updFlag) > time() - 240) {
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
    if (! preg_match('~^/(health-check|up)(\?|$)~', $uri) && ! str_contains($uri, 'tools/update')) {
        http_response_code(503);
        header('Retry-After: 6');
        header('Cache-Control: no-store');
        header('Content-Type: text/html; charset=utf-8');
        exit('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="6"><title>در حال به‌روزرسانی</title>'
            .'<body style="font-family:Tahoma,sans-serif;background:#0A1430;color:#F2EEE2;display:grid;place-items:center;min-height:90vh;margin:0"><div style="text-align:center;line-height:2">'
            .'<div style="font-size:40px">⏳</div><b>سایت در حال به‌روزرسانی است</b><br><span style="color:#9AA7C6">چند ثانیه دیگر خودکار باز می‌شود…</span></div></body></html>');
    }
}

$base = dirname(__DIR__);

// پوشه‌های ضروری را بساز و تا حد ممکن قابل‌نوشتن کن (علت رایج خطای ۵۰۰ روی هاست)
$needDirs = [
    $base.'/storage/app',
    $base.'/storage/app/database',
    $base.'/storage/framework',
    $base.'/storage/framework/cache',
    $base.'/storage/framework/cache/data',
    $base.'/storage/framework/sessions',
    $base.'/storage/framework/views',
    $base.'/storage/logs',
    $base.'/bootstrap/cache',
];
foreach ($needDirs as $dir) {
    if (! is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    if (is_dir($dir) && ! is_writable($dir)) {
        @chmod($dir, 0775);
        if (! is_writable($dir)) {
            @chmod($dir, 0777);
        }
    }
}

$unwritable = [];
foreach ($needDirs as $dir) {
    if (! is_dir($dir) || ! is_writable($dir)) {
        $unwritable[] = $dir;
        continue;
    }
    $probe = $dir.'/.write_test';
    if (@file_put_contents($probe, '1') === false) {
        $unwritable[] = $dir;
    } else {
        @unlink($probe);
    }
}
if ($unwritable !== []) {
    $list = '<ul>';
    foreach ($unwritable as $d) {
        $list .= '<li dir="ltr" style="word-break:break-all">'.htmlspecialchars($d, ENT_QUOTES, 'UTF-8').'</li>';
    }
    $list .= '</ul>';
    $faPage(
        'دسترسی پوشه',
        '<h2>خطای ۵۰۰ به‌خاطر دسترسی پوشه است</h2>'
        .'<p>پوشه‌های <b>storage</b> و <b>bootstrap/cache</b> باید قابل نوشتن باشند. در File Manager سی‌پنل روی این پوشه‌ها راست‌کلیک → <b>Change Permissions</b> → مقدار <b>775</b> (اگر نشد <b>755</b> با تیک نوشتن برای group، یا موقتاً <b>777</b>).</p>'
        .'<p>پوشه‌های مشکل‌دار:</p>'.$list
        .'<p>بعد از درست کردن دسترسی، همین صفحه را تازه کنید.</p>'
    );
}

// اولین اجرا: ساخت .env از نمونه
if (! file_exists($base.'/.env') && file_exists($base.'/.env.example')) {
    $env = (string) file_get_contents($base.'/.env.example');
    $env = preg_replace('/^APP_KEY=.*$/m', 'APP_KEY=base64:'.base64_encode(random_bytes(32)), $env);
    @file_put_contents($base.'/.env', $env);
}

if (! is_file($base.'/vendor/autoload.php')) {
    $faPage(
        'نصب ناقص است',
        '<h2>پوشه vendor پیدا نشد</h2>'
        .'<p>باید نسخه کامل zip مهدوب را Extract کنید (پوشه <code>vendor</code> داخل بسته هست). اگر فقط بخشی از فایل‌ها آپلود شده، دوباره zip کامل را Extract کنید.</p>',
        503
    );
}

if (file_exists($maintenance = $base.'/storage/framework/maintenance.php')) {
    require $maintenance;
}

require $base.'/vendor/autoload.php';

(require_once $base.'/bootstrap/app.php')->handleRequest(Request::capture());
