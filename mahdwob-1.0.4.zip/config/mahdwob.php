<?php

return [
    'version' => '1.0.4',
    'brand_default' => 'مهدوب',
];
