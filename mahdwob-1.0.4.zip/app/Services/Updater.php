<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;
use ZipArchive;

/**
 * به‌روزرسانی کل سایت با آپلود فایل بسته (zip):
 * بررسی فایل‌ها ← پشتیبان دیتابیس ← جابه‌جایی پوشه‌ها ← اجرای مایگریشن و بررسی سلامت با نسخه جدید
 * ← در صورت خطا، بازگشت خودکار به نسخه قبل و نمایش علت.
 */
class Updater
{
    /** مواردی که هرگز با بسته جایگزین نمی‌شوند */
    protected const KEEP = ['.env', 'storage', 'public/uploads'];

    /** IP همین سرور که بررسی سلامت با آن به سایت رسید (وقتی DNS هاست هنوز دامنه را به جای دیگری می‌برد) */
    protected ?string $forcedIp = null;

    /** IPهای احتمالی همین سرور */
    protected function ownIps(): array
    {
        $list = [$_SERVER['SERVER_ADDR'] ?? null, $_SERVER['LOCAL_ADDR'] ?? null, @gethostbyname((string) gethostname())];
        if (function_exists('shell_exec') && ! in_array('shell_exec', array_map('trim', explode(',', (string) ini_get('disable_functions'))), true)) {
            foreach (preg_split('/\s+/', (string) @shell_exec('hostname -I 2>/dev/null')) as $ip) {
                $list[] = $ip;
            }
        }
        $list[] = '127.0.0.1';

        return array_values(array_unique(array_filter($list, fn ($ip) => $ip && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4))));
    }

    /** فایل‌هایی داخل پوشه‌های جابه‌جاشده که باید از نسخه قبل منتقل شوند (دیتابیس SQLite، فایل‌های دلخواه public) */
    protected const PRESERVE = ['storage/app/database/mahdwob.sqlite', 'database/database.sqlite', 'public/logo-mahdwob.jpg', 'public/.well-known'];

    public function workDir(): string
    {
        $d = storage_path('app/update');
        if (! is_dir($d)) {
            mkdir($d, 0755, true);
        }

        return $d;
    }

    public function log(string $msg): void
    {
        $line = '['.now()->format('Y-m-d H:i:s').'] '.$msg."\n";
        @file_put_contents($this->workDir().'/update.log', $line, FILE_APPEND);
    }

    public function logTail(int $lines = 60): string
    {
        $f = $this->workDir().'/update.log';
        if (! is_file($f)) {
            return '';
        }

        return implode("\n", array_slice(file($f, FILE_IGNORE_NEW_LINES) ?: [], -$lines));
    }

    /**
     * بررسی بسته بدون تغییر سایت.
     *
     * @return array{version: string, root: string, files: int, entries: array}
     */
    public function inspect(string $zipPath): array
    {
        if (! class_exists(ZipArchive::class)) {
            throw new RuntimeException('افزونه ZipArchive روی هاست نصب نیست.');
        }
        $z = new ZipArchive;
        if ($z->open($zipPath) !== true) {
            throw new RuntimeException('فایل zip معتبر نیست.');
        }
        $root = null;
        for ($i = 0; $i < $z->numFiles; $i++) {
            $n = $z->getNameIndex($i);
            if (preg_match('#^(?:([^/]+)/)?artisan$#', $n, $m)) {
                $root = isset($m[1]) && $m[1] !== '' ? $m[1].'/' : '';
                break;
            }
        }
        if ($root === null) {
            $z->close();
            throw new RuntimeException('این فایل بسته سایت نیست (فایل artisan پیدا نشد). فایل نصبی/به‌روزرسانی همین سایت را انتخاب کنید.');
        }
        $cfg = $z->getFromName($root.'config/mahdwob.php');
        if (! $cfg || ! preg_match("/'version'\s*=>\s*'([^']+)'/", $cfg, $vm)) {
            $z->close();
            throw new RuntimeException('این بسته مربوط به این سایت نیست یا نسخه آن مشخص نیست (config/mahdwob.php).');
        }
        if ($z->locateName($root.'vendor/autoload.php') === false) {
            $z->close();
            throw new RuntimeException('پوشه vendor داخل بسته نیست؛ بسته کامل را آپلود کنید.');
        }
        $entries = [];
        for ($i = 0; $i < $z->numFiles; $i++) {
            $n = $z->getNameIndex($i);
            if ($root !== '' && ! str_starts_with($n, $root)) {
                continue;
            }
            $rel = substr($n, strlen($root));
            if ($rel === '' || str_contains($rel, '..')) {
                continue;
            }
            $top = explode('/', $rel)[0];
            if ($top === 'public') {
                $second = explode('/', $rel)[1] ?? '';
                if ($second !== '' && $second !== 'uploads') {
                    $entries['public/'.$second] = true;
                }
            } elseif (! in_array($top, ['.env', 'storage'], true)) {
                $entries[$top] = true;
            }
        }
        $count = $z->numFiles;
        $z->close();

        return ['version' => $vm[1], 'root' => $root, 'files' => $count, 'entries' => array_keys($entries)];
    }

    /** بررسی نحوی فایل‌های PHP (بدون اجرا) */
    protected function lint(string $dir): array
    {
        $errors = [];
        if (! function_exists('token_get_all')) {
            return [];
        }
        foreach (['app', 'config', 'routes', 'database', 'bootstrap'] as $sub) {
            if (! is_dir($dir.'/'.$sub)) {
                continue;
            }
            $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir.'/'.$sub, \FilesystemIterator::SKIP_DOTS));
            foreach ($it as $f) {
                if (! $f->isFile() || ! str_ends_with($f->getFilename(), '.php')) {
                    continue;
                }
                try {
                    token_get_all((string) file_get_contents($f->getPathname()), TOKEN_PARSE);
                } catch (\ParseError $e) {
                    $errors[] = substr($f->getPathname(), strlen($dir) + 1).' خط '.$e->getLine().': '.$e->getMessage();
                    if (count($errors) >= 10) {
                        return $errors;
                    }
                }
            }
        }

        return $errors;
    }

    /**
     * نصب بسته. در صورت شکست، تغییرات برگردانده و استثنا با توضیح فارسی پرتاب می‌شود.
     *
     * @return array{from: string, to: string, backup: string}
     */
    public function install(string $zipPath): array
    {
        @set_time_limit(0);
        @ini_set('memory_limit', '512M');
        $info = $this->inspect($zipPath);
        $from = config('mahdwob.version');
        $ts = now()->format('Ymd-His');
        $work = $this->workDir();
        $new = $work.'/new-'.$ts;
        $old = $work.'/old-'.$ts;
        $this->log("شروع به‌روزرسانی {$from} ← {$info['version']}");

        // ۱) استخراج
        $z = new ZipArchive;
        $z->open($zipPath);
        if (! $z->extractTo($new)) {
            $z->close();
            $this->rrmdir($new);
            throw new RuntimeException('استخراج فایل ممکن نشد (فضای دیسک یا دسترسی پوشه storage را بررسی کنید).');
        }
        $z->close();
        $src = rtrim($new.'/'.$info['root'], '/');

        // ۲) بررسی نحوی
        if ($errors = $this->lint($src)) {
            $this->rrmdir($new);
            $this->log('خطای نحوی: '.implode(' | ', $errors));
            throw new RuntimeException("بسته جدید خطای کد دارد و نصب نشد:\n".implode("\n", $errors));
        }

        // ۳) پشتیبان دیتابیس
        $backup = app(Backup::class)->create('db', 'pre-update');
        $this->log('پشتیبان پیش از به‌روزرسانی: '.$backup);
        $migBefore = $this->migrationCount();

        // بارگذاری کلاس‌های لازم پیش از جابه‌جایی vendor (فرایند فعلی تا آخر با کد قدیم کار کند)
        try {
            $this->selfGet(rtrim(request()->getSchemeAndHttpHost() ?: config('app.url'), '/'), '/up', [], 15, false);
        } catch (Throwable) {
        }
        class_exists(\Illuminate\Http\Client\Response::class);
        class_exists(\Illuminate\Support\Str::class);

        // ۴) جابه‌جایی — در این چند ثانیه بازدیدها صفحه «در حال به‌روزرسانی» می‌بینند (نه خطای کد نیمه‌قدیم/نیمه‌جدید)
        @file_put_contents(storage_path('framework/updating'), (string) time());
        register_shutdown_function(fn () => @unlink(storage_path('framework/updating')));
        foreach (glob(base_path('bootstrap/cache/{config,routes-v7,events}.php'), GLOB_BRACE) ?: [] as $f) {
            @unlink($f);
        }
        $moved = [];
        mkdir($old.'/public', 0755, true);
        try {
            foreach ($info['entries'] as $entry) {
                if (in_array($entry, self::KEEP, true) || ! file_exists($src.'/'.$entry)) {
                    continue;
                }
                $target = base_path($entry);
                if (file_exists($target)) {
                    if (! @rename($target, $old.'/'.$entry)) {
                        throw new RuntimeException('جابه‌جایی «'.$entry.'» ممکن نشد (دسترسی فایل).');
                    }
                }
                $moved[] = $entry;
                if (! @rename($src.'/'.$entry, $target)) {
                    throw new RuntimeException('قرار دادن «'.$entry.'» ممکن نشد.');
                }
            }
        } catch (Throwable $e) {
            $this->rollbackFiles($old, $moved);
            $this->rrmdir($new);
            $this->log('شکست در جابه‌جایی: '.$e->getMessage());
            throw new RuntimeException($e->getMessage().' — نسخه قبلی برگردانده شد.');
        }
        $this->preserve($old);
        $this->clearCaches();

        // ۵) مایگریشن و بررسی سلامت با کد جدید (درخواست جداگانه)
        @unlink(storage_path('framework/updating')); // مایگریشن و بررسی سلامت با درخواست جداگانه؛ سایت باز می‌شود
        $check = $this->healthCheck(true);
        if (! $check['ok']) {
            $this->log('بررسی سلامت ناموفق: '.$check['error']);
            $this->rollbackFiles($old, $moved);
            $this->clearCaches();
            $migAfter = $this->migrationCount();
            $this->log('مایگریشن‌ها: قبل '.$migBefore.'، بعد '.$migAfter.(! empty($check['migrated']) ? ' (اجرا شد)' : ''));
            if (! empty($check['migrated']) || $migAfter !== $migBefore) {
                try {
                    app(Backup::class)->restore($backup, false);
                    $this->log('پایگاه داده از پشتیبان برگردانده شد.');
                } catch (Throwable $e) {
                    $this->log('بازگردانی پایگاه داده ناموفق: '.$e->getMessage());
                }
            }
            $this->rrmdir($new);
            throw new RuntimeException("نسخه جدید روی این هاست درست اجرا نشد و سایت خودکار به نسخه قبل برگشت.\nعلت: ".$check['error']);
        }

        $this->rrmdir($new);
        file_put_contents($old.'/VERSION', $from);
        $this->pruneOld(2);
        $this->log("به‌روزرسانی موفق به نسخه {$info['version']}");

        return ['from' => $from, 'to' => $info['version'], 'backup' => $backup];
    }

    /** برگرداندن فایل‌های داده (مثل SQLite) از نسخه قبل به نسخه جدید */
    protected function preserve(string $old): void
    {
        foreach (self::PRESERVE as $pattern) {
            foreach (glob($old.'/'.$pattern) ?: [] as $src) {
                $rel = substr($src, strlen($old) + 1);
                $dest = base_path($rel);
                // دیتابیس SQLite قدیمی همیشه از نسخه قبل برمی‌گردد (حتی اگر بسته فایل خالی هم‌نام داشته باشد)
                $isDb = str_ends_with($rel, '.sqlite') && is_file($src) && filesize($src) > 0;
                if ($isDb || ! file_exists($dest)) {
                    @mkdir(dirname($dest), 0755, true);
                    @copy($src, $dest) || @rename($src, $dest);
                    if (is_dir($src) && ! file_exists($dest)) {
                        @rename($src, $dest);
                    }
                }
            }
        }
    }

    protected function rollbackFiles(string $old, array $moved): void
    {
        foreach (array_reverse($moved) as $entry) {
            $target = base_path($entry);
            if (file_exists($old.'/'.$entry)) {
                if (file_exists($target)) {
                    $this->rrmdir($target);
                }
                @rename($old.'/'.$entry, $target);
            } elseif (file_exists($target)) {
                $this->rrmdir($target); // مورد جدیدی که قبلاً نبود
            }
        }
        $this->rrmdir($old);
    }

    protected function migrationCount(): int
    {
        try {
            return (int) \Illuminate\Support\Facades\DB::table('migrations')->count();
        } catch (Throwable) {
            return -1;
        }
    }

    /** نسخه‌های قبلی که می‌توان دستی به آن برگشت */
    public function previous(): array
    {
        $out = [];
        foreach (glob($this->workDir().'/old-*', GLOB_ONLYDIR) ?: [] as $d) {
            $out[] = ['dir' => basename($d), 'version' => trim((string) @file_get_contents($d.'/VERSION')) ?: '?', 'time' => filemtime($d)];
        }
        usort($out, fn ($a, $b) => $b['time'] <=> $a['time']);

        return $out;
    }

    /** بازگشت دستی به نسخه قبلی کد (دیتابیس تغییر نمی‌کند) */
    public function rollback(string $dirName): string
    {
        $old = $this->workDir().'/'.basename($dirName);
        if (! preg_match('/^old-\d{8}-\d{6}$/', basename($dirName)) || ! is_dir($old)) {
            throw new RuntimeException('نسخه قبلی پیدا نشد.');
        }
        $version = trim((string) @file_get_contents($old.'/VERSION'));
        $ts = now()->format('Ymd-His');
        $swap = $this->workDir().'/old-'.$ts;
        mkdir($swap.'/public', 0755, true);
        $entries = [];
        foreach (scandir($old) as $e) {
            if ($e === '.' || $e === '..' || $e === 'VERSION') {
                continue;
            }
            if ($e === 'public') {
                foreach (scandir($old.'/public') as $p) {
                    if ($p !== '.' && $p !== '..') {
                        $entries[] = 'public/'.$p;
                    }
                }
            } else {
                $entries[] = $e;
            }
        }
        foreach ($entries as $entry) {
            if (in_array($entry, self::KEEP, true)) {
                continue;
            }
            if (file_exists(base_path($entry))) {
                @rename(base_path($entry), $swap.'/'.$entry);
            }
            @rename($old.'/'.$entry, base_path($entry));
        }
        file_put_contents($swap.'/VERSION', config('mahdwob.version'));
        $this->rrmdir($old);
        $this->clearCaches();
        $this->log('بازگشت دستی به نسخه '.$version);

        return $version;
    }

    /** درخواست به خود سایت (با کد جدید) برای اجرای مایگریشن و بررسی سلامت */
    public function healthCheck(bool $migrate = false): array
    {
        $keyFile = storage_path('app/health.key');
        if (! is_file($keyFile)) {
            file_put_contents($keyFile, Str::random(40));
        }
        $key = trim((string) file_get_contents($keyFile));
        $base = rtrim(request()->getSchemeAndHttpHost() ?: config('app.url'), '/');
        $errors = [];
        $migrated = false;
        foreach ([1, 2, 3] as $attempt) {
            try {
                $r = $this->selfGet($base, '/health-check', ['key' => $key, 'migrate' => $migrate ? 1 : 0], 240);
                $j = $r->json();
                if (($j['marker'] ?? '') !== 'MAHDWOB-OK') {
                    // پاسخ از سایت دیگری آمد (DNS هاست هنوز به هاست قبلی می‌برد): مستقیم به IPهای همین سرور
                    foreach ($this->ownIps() as $ip) {
                        try {
                            $r2 = $this->selfGetVia($base, '/health-check', ['key' => $key, 'migrate' => $migrate ? 1 : 0], 240, true, $ip);
                            $j2 = $r2->json();
                            if (($j2['marker'] ?? '') === 'MAHDWOB-OK') {
                                $r = $r2;
                                $j = $j2;
                                $this->forcedIp = $ip;
                                $this->log('DNS هاست دامنه را به سرور دیگری می‌برد؛ بررسی از راه IP همین سرور ('.$ip.') انجام شد.');
                                break;
                            }
                        } catch (Throwable) {
                        }
                    }
                }
                $migrated = $migrated || ! empty($j['migrated']);
                if ($r->successful() && ($j['marker'] ?? '') === 'MAHDWOB-OK') {
                    // همه مایگریشن‌های نسخه جدید باید اجرا شده باشند
                    try {
                        $files = array_map(fn ($f) => basename($f, '.php'), glob(base_path('database/migrations/*.php')) ?: []);
                        $left = array_diff($files, \Illuminate\Support\Facades\DB::table('migrations')->pluck('migration')->all());
                        if ($left) {
                            $errors[] = 'مایگریشن اجرا نشد: '.implode('، ', $left);

                            return ['ok' => false, 'error' => implode(' | ', array_unique($errors)), 'migrated' => $migrated];
                        }
                    } catch (Throwable) {
                    }
                    // صفحه اصلی و ورود پنل هم باید بدون خطای ۵۰۰ باز شوند
                    foreach (['/', '/admin/login'] as $page) {
                        $p = $this->selfGet($base, $page, [], 30, false);
                        if ($p->status() >= 500) {
                            $errors[] = 'صفحه '.$page.' خطای '.$p->status().' داد: '.($this->lastLoggedError() ?: $this->extractError($p->body()));
                        }
                    }

                    return $errors ? ['ok' => false, 'error' => implode(' | ', array_unique($errors)), 'migrated' => $migrated] : ['ok' => true, 'migrated' => $migrated];
                }
                $errors[] = $j['error'] ?? ('کد '.$r->status().': '.$this->extractError($r->body()));
                $migrate = false;
            } catch (Throwable $e) {
                $errors[] = 'اتصال به سایت برقرار نشد: '.$e->getMessage();
            }
            usleep($attempt * 1500000);
        }

        return ['ok' => false, 'error' => implode(' | ', array_unique($errors)), 'migrated' => $migrated];
    }

    /**
     * درخواست به همین سایت. اگر DNS هاست نام دامنه را پیدا نکند (خطای cURL 6/28 در Resolving)،
     * همان درخواست مستقیم به IP خود سرور فرستاده می‌شود (با همان نام دامنه برای SSL و هاست مجازی).
     */
    public function selfGetVia(string $base, string $path, array $query, int $timeout, bool $json, string $ip): \Illuminate\Http\Client\Response
    {
        $u = parse_url($base);
        $host = $u['host'] ?? '';
        $port = $u['port'] ?? (($u['scheme'] ?? 'https') === 'https' ? 443 : 80);

        return Http::timeout($timeout)->connectTimeout(15)->withoutVerifying()->withoutRedirecting()
            ->withOptions(['curl' => [CURLOPT_RESOLVE => [$host.':'.$port.':'.$ip]]])->when($json, fn ($h) => $h->acceptJson())->get($base.$path, $query);
    }

    public function selfGet(string $base, string $path, array $query = [], int $timeout = 30, bool $json = true): \Illuminate\Http\Client\Response
    {
        $req = fn (array $opts = []) => Http::timeout($timeout)->connectTimeout(15)->withoutVerifying()->withoutRedirecting()
            ->withOptions($opts)->when($json, fn ($h) => $h->acceptJson())->get($base.$path, $query);
        if ($this->forcedIp) {
            return $this->selfGetVia($base, $path, $query, $timeout, $json, $this->forcedIp);
        }
        // اول مستقیم به IP همین سرور: اگر DNS خود هاست هنوز دامنه را به هاست قبلی می‌برد (مثلاً چند ساعت پس از انتقال دامنه)،
        // بررسی سلامت به سایت قدیمی نرسد
        $u0 = parse_url($base);
        $h0 = $u0['host'] ?? '';
        $own = $_SERVER['SERVER_ADDR'] ?? null;
        if ($h0 !== '' && ! filter_var($h0, FILTER_VALIDATE_IP) && $own && filter_var($own, FILTER_VALIDATE_IP) && ! in_array($own, ['127.0.0.1', '::1'], true)) {
            $p0 = $u0['port'] ?? (($u0['scheme'] ?? 'https') === 'https' ? 443 : 80);
            try {
                return $req(['curl' => [CURLOPT_RESOLVE => [$h0.':'.$p0.':'.$own]]]);
            } catch (\Throwable) {
                // ادامه با DNS معمولی
            }
        }
        try {
            return $req();
        } catch (\Illuminate\Http\Client\ConnectionException $e) {
            $u = parse_url($base);
            $host = $u['host'] ?? '';
            $port = $u['port'] ?? (($u['scheme'] ?? 'https') === 'https' ? 443 : 80);
            $ips = array_values(array_unique(array_filter([
                $_SERVER['SERVER_ADDR'] ?? null, $_SERVER['LOCAL_ADDR'] ?? null,
                filter_var(@gethostbyname((string) gethostname()), FILTER_VALIDATE_IP) ?: null, '127.0.0.1',
            ], fn ($ip) => $ip && filter_var($ip, FILTER_VALIDATE_IP))));
            foreach ($ips as $ip) {
                try {
                    $r = $req(['curl' => [CURLOPT_RESOLVE => [$host.':'.$port.':'.$ip]]]);
                    $this->log('DNS هاست پاسخ نداد؛ بررسی از راه IP سرور ('.$ip.') انجام شد.');

                    return $r;
                } catch (\Throwable) {
                }
            }
            throw $e;
        }
    }

    /** آخرین خطای ثبت‌شده در گزارش (پیام و فایل/خط) در دو دقیقه اخیر */
    public function lastLoggedError(): ?string
    {
        $files = glob(storage_path('logs/*.log')) ?: [];
        usort($files, fn ($a, $b) => filemtime($b) <=> filemtime($a));
        if (! $files) {
            return null;
        }
        $fh = @fopen($files[0], 'rb');
        if (! $fh) {
            return null;
        }
        fseek($fh, max(0, filesize($files[0]) - 200000));
        $chunk = (string) fread($fh, 200000);
        fclose($fh);
        if (! preg_match_all('/^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\] \w+\.(?:ERROR|CRITICAL|EMERGENCY): (.*?)(?: \{"|$)/m', $chunk, $m, PREG_SET_ORDER)) {
            return null;
        }
        $last = end($m);
        if (strtotime($last[1]) < time() - 120) {
            return null;
        }
        $msg = $last[2];
        if (preg_match('/ at (\S+?):(\d+)\)/', substr($chunk, strrpos($chunk, $last[0])), $at)) {
            $msg .= ' — '.str_replace(base_path().'/', '', $at[1]).' خط '.$at[2];
        }

        return Str::limit($msg, 400);
    }

    protected function extractError(string $html): string
    {
        $t = trim(preg_replace('/\s+/u', ' ', strip_tags($html)));

        return Str::limit($t, 300);
    }

    public function clearCaches(): void
    {
        foreach (glob(base_path('bootstrap/cache/{config,routes-v7,events}.php'), GLOB_BRACE) ?: [] as $f) {
            @unlink($f);
        }
        foreach (glob(storage_path('framework/views/*.php')) ?: [] as $f) {
            @unlink($f);
        }
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }
    }

    protected function pruneOld(int $keep): void
    {
        foreach (array_slice($this->previous(), $keep) as $p) {
            $this->rrmdir($this->workDir().'/'.$p['dir']);
        }
    }

    public function rrmdir(string $path): void
    {
        if (is_link($path) || is_file($path)) {
            @unlink($path);

            return;
        }
        if (! is_dir($path)) {
            return;
        }
        foreach (scandir($path) as $e) {
            if ($e !== '.' && $e !== '..') {
                $this->rrmdir($path.'/'.$e);
            }
        }
        @rmdir($path);
    }
}
