<?php

namespace App\Services;

use App\Models\Setting;
use App\Support\Fa;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use RuntimeException;
use Throwable;
use ZipArchive;

/**
 * پشتیبان‌گیری و بازگردانی: پایگاه داده (و در حالت کامل، فایل‌های دموها) در یک فایل zip.
 * هر دستور SQL در یک خط ذخیره می‌شود تا بازگردانی خط‌به‌خط و کم‌حافظه انجام شود.
 */
class Backup
{
    public const LABELS = ['manual' => 'دستی', 'auto' => 'خودکار روزانه', 'pre-update' => 'پیش از به‌روزرسانی', 'pre-restore' => 'پیش از بازگردانی', 'upload' => 'آپلودشده'];

    public function dir(): string
    {
        $d = storage_path('app/backups');
        if (! is_dir($d)) {
            mkdir($d, 0755, true);
        }
        if (! is_file($d.'/.htaccess')) {
            file_put_contents($d.'/.htaccess', "Require all denied\nDeny from all\n");
        }

        return $d;
    }

    public function path(string $file): ?string
    {
        if (! preg_match('/^[A-Za-z0-9_.\-]+\.zip$/', $file)) {
            return null;
        }
        $p = $this->dir().'/'.$file;

        return is_file($p) ? $p : null;
    }

    /** @return array<int, array{file: string, size: int, time: Carbon, type: string, label: string}> */
    public function list(): array
    {
        $out = [];
        foreach (glob($this->dir().'/*.zip') ?: [] as $f) {
            $name = basename($f);
            preg_match('/^backup-(\d{8}-\d{6})-(db|full)-([a-z\-]+)/', $name, $m);
            $out[] = [
                'file' => $name,
                'size' => (int) filesize($f),
                'time' => isset($m[1]) ? Carbon::createFromFormat('Ymd-His', $m[1]) : Carbon::createFromTimestamp(filemtime($f)),
                'type' => $m[2] ?? 'db',
                'label' => $m[3] ?? 'upload',
            ];
        }
        usort($out, fn ($a, $b) => $b['time'] <=> $a['time']);

        return $out;
    }

    public function lastTime(): ?Carbon
    {
        foreach ($this->list() as $b) {
            if ($b['label'] !== 'upload') {
                return $b['time'];
            }
        }

        return null;
    }

    public function create(string $type = 'db', string $label = 'manual'): string
    {
        @set_time_limit(0);
        @ini_set('memory_limit', '512M');
        if (! class_exists(ZipArchive::class)) {
            throw new RuntimeException('افزونه ZipArchive روی هاست نصب نیست.');
        }
        $type = $type === 'full' ? 'full' : 'db';
        $name = 'backup-'.now()->format('Ymd-His').'-'.$type.'-'.$label.'.zip';
        $file = $this->dir().'/'.$name;
        $sql = $this->dir().'/dump-'.uniqid().'.sql';
        $tables = $this->dumpDatabase($sql);

        $zip = new ZipArchive;
        if ($zip->open($file, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            @unlink($sql);
            throw new RuntimeException('ساخت فایل پشتیبان ممکن نشد (دسترسی نوشتن پوشه storage را بررسی کنید).');
        }
        $zip->addFile($sql, 'database.sql');
        $count = 0;
        if ($type === 'full') {
            $base = public_path('uploads');
            if (is_dir($base)) {
                $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($base, \FilesystemIterator::SKIP_DOTS));
                foreach ($it as $f) {
                    if (! $f->isFile() || $f->isLink()) {
                        continue;
                    }
                    $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($base) + 1));
                    if (preg_match('/\.(php\d?|phtml|phar)$/i', $rel)) {
                        continue;
                    }
                    $zip->addFile($f->getPathname(), 'uploads/'.$rel);
                    if (preg_match('/\.(jpe?g|png|webp|gif|woff2?|zip|mp4)$/i', $rel)) {
                        $zip->setCompressionName('uploads/'.$rel, ZipArchive::CM_STORE);
                    }
                    $count++;
                }
            }
        }
        $zip->addFromString('manifest.json', json_encode([
            'app' => 'mahdwob',
            'version' => config('mahdwob.version'),
            'type' => $type,
            'label' => $label,
            'created' => now()->toIso8601String(),
            'url' => config('app.url'),
            'driver' => DB::getDriverName(),
            'tables' => $tables,
            'files' => $count,
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        $zip->close();
        @unlink($sql);
        return $name;
    }

    protected function q(mixed $v, bool $sqlite): string
    {
        if ($v === null) {
            return 'NULL';
        }
        if (is_int($v) || is_float($v)) {
            return (string) $v;
        }
        if (is_bool($v)) {
            return $v ? '1' : '0';
        }
        $v = (string) $v;
        if ($sqlite) {
            // در SQLite بک‌اسلش معنای خاصی ندارد؛ خط جدید با char(10) نگه داشته می‌شود
            return "'".str_replace(["'", "\r", "\n"], ["''", "'||char(13)||'", "'||char(10)||'"], $v)."'";
        }

        return "'".strtr($v, ['\\' => '\\\\', "\0" => '\\0', "\n" => '\\n', "\r" => '\\r', "'" => "\\'", "\x1a" => '\\Z'])."'";
    }

    /** @return array<string, int> جدول => تعداد ردیف */
    public function dumpDatabase(string $file): array
    {
        $pdo = DB::connection()->getPdo();
        $sqlite = DB::getDriverName() === 'sqlite';
        $fh = fopen($file, 'wb');
        $w = fn (string $line) => fwrite($fh, str_replace(["\r", "\n"], ' ', $line)."\n");
        $w('-- mahdwob backup '.now()->toIso8601String());
        $tables = [];
        if ($sqlite) {
            $w('PRAGMA foreign_keys=OFF;');
            $rows = $pdo->query("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")->fetchAll(\PDO::FETCH_NUM);
            $list = array_map(fn ($r) => [$r[0], $r[1]], $rows);
        } else {
            $w('SET NAMES utf8mb4;');
            $w('SET FOREIGN_KEY_CHECKS=0;');
            $w("SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';");
            $list = [];
            foreach ($pdo->query('SHOW FULL TABLES')->fetchAll(\PDO::FETCH_NUM) as $r) {
                if (($r[1] ?? 'BASE TABLE') !== 'BASE TABLE') {
                    continue;
                }
                $create = $pdo->query('SHOW CREATE TABLE `'.str_replace('`', '``', $r[0]).'`')->fetch(\PDO::FETCH_NUM)[1];
                $list[] = [$r[0], $create];
            }
        }
        foreach ($list as [$table, $create]) {
            $qt = $sqlite ? '"'.str_replace('"', '""', $table).'"' : '`'.str_replace('`', '``', $table).'`';
            $w('DROP TABLE IF EXISTS '.$qt.';');
            $w($create.';');
            $n = 0;
            $stmt = $pdo->query('SELECT * FROM '.$qt);
            $batch = [];
            $cols = null;
            while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                if ($cols === null) {
                    $cols = implode(',', array_map(fn ($c) => $sqlite ? '"'.$c.'"' : '`'.$c.'`', array_keys($row)));
                }
                $batch[] = '('.implode(',', array_map(fn ($v) => $this->q($v, $sqlite), $row)).')';
                $n++;
                if (count($batch) >= 200) {
                    $w('INSERT INTO '.$qt.' ('.$cols.') VALUES '.implode(',', $batch).';');
                    $batch = [];
                }
            }
            if ($batch) {
                $w('INSERT INTO '.$qt.' ('.$cols.') VALUES '.implode(',', $batch).';');
            }
            $tables[$table] = $n;
        }
        $w($sqlite ? 'PRAGMA foreign_keys=ON;' : 'SET FOREIGN_KEY_CHECKS=1;');
        fclose($fh);

        return $tables;
    }

    public function restore(string $file, bool $withFiles = true): array
    {
        @set_time_limit(0);
        @ini_set('memory_limit', '512M');
        $path = $this->path($file);
        if (! $path) {
            throw new RuntimeException('فایل پشتیبان پیدا نشد.');
        }
        $zip = new ZipArchive;
        if ($zip->open($path) !== true) {
            throw new RuntimeException('فایل پشتیبان خراب است یا zip نیست.');
        }
        $manifest = json_decode((string) $zip->getFromName('manifest.json'), true);
        if (! is_array($manifest) || ($manifest['app'] ?? '') !== 'mahdwob' || $zip->locateName('database.sql') === false) {
            $zip->close();
            throw new RuntimeException('این فایل، پشتیبانِ همین سایت نیست.');
        }
        if (($manifest['driver'] ?? DB::getDriverName()) !== DB::getDriverName()) {
            $zip->close();
            throw new RuntimeException('نوع پایگاه داده پشتیبان با سایت فعلی یکی نیست.');
        }

        $this->create('db', 'pre-restore');

        $tmp = $this->dir().'/restore-'.uniqid().'.sql';
        copy('zip://'.$path.'#database.sql', $tmp);
        $fh = fopen($tmp, 'rb');
        $pdo = DB::connection()->getPdo();
        $n = 0;
        $buf = '';
        try {
            while (($line = fgets($fh)) !== false) {
                $line = rtrim($line, "\r\n");
                if ($line === '' || str_starts_with($line, '-- ')) {
                    continue;
                }
                $pdo->exec($line);
                $n++;
            }
        } catch (Throwable $e) {
            fclose($fh);
            @unlink($tmp);
            $zip->close();
            throw new RuntimeException('خطا در اجرای دستور '.Fa::digits($n + 1).': '.$e->getMessage());
        }
        fclose($fh);
        @unlink($tmp);

        $files = 0;
        if ($withFiles && ($manifest['type'] ?? '') === 'full') {
            $targets = ['uploads/' => public_path('uploads')];
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $name = $zip->getNameIndex($i);
                $prefix = str_starts_with($name, 'uploads/') ? 'uploads/' : null;
                if (! $prefix || str_ends_with($name, '/') || str_contains($name, '..')) {
                    continue;
                }
                if ($prefix === 'uploads/' && preg_match('/\.(php\d?|phtml|phar)$/i', $name)) {
                    continue;
                }
                $dest = $targets[$prefix].'/'.substr($name, strlen($prefix));
                if (! is_dir(dirname($dest))) {
                    @mkdir(dirname($dest), 0755, true);
                }
                copy('zip://'.$path.'#'.$name, $dest);
                $files++;
            }
        }
        $zip->close();
        Setting::flush();
        try {
            Artisan::call('cache:clear');
        } catch (Throwable) {
        }

        return ['statements' => $n, 'files' => $files, 'manifest' => $manifest];
    }

    public function delete(string $file): bool
    {
        $p = $this->path($file);

        return $p ? @unlink($p) : false;
    }

    /** نگه داشتن N پشتیبان خودکار آخر */
    public function prune(int $keep): int
    {
        $keep = max(1, $keep);
        $n = 0;
        $auto = array_values(array_filter($this->list(), fn ($b) => in_array($b['label'], ['auto', 'pre-update', 'pre-restore'], true)));
        foreach (array_slice($auto, $keep) as $b) {
            $n += $this->delete($b['file']) ? 1 : 0;
        }

        return $n;
    }

    public function storeUpload(string $tmpPath, string $original): string
    {
        $zip = new ZipArchive;
        if ($zip->open($tmpPath) !== true || $zip->locateName('database.sql') === false) {
            throw new RuntimeException('فایل انتخاب‌شده پشتیبان معتبر این سایت نیست.');
        }
        $zip->close();
        $name = preg_match('/^backup-\d{8}-\d{6}-(db|full)-[a-z\-]+\.zip$/', $original) ? $original : 'backup-'.now()->format('Ymd-His').'-full-upload.zip';
        copy($tmpPath, $this->dir().'/'.$name);

        return $name;
    }
}
