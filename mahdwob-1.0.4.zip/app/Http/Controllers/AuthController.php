<?php

namespace App\Http\Controllers;

use App\Support\Fa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLogin()
    {
        if (Auth::check()) {
            return redirect()->route('admin.orders.index');
        }

        return view('admin.login');
    }

    public function login(Request $request)
    {
        $data = $request->validate([
            'username' => ['required', 'string'],
            'password' => ['required'],
        ], Fa::messages() + [
            'username.required' => 'نام کاربری را وارد کنید.',
        ]);

        // نام کاربری در ستون email ذخیره می‌شود (می‌تواند admin یا ایمیل باشد)
        if (Auth::attempt(['email' => $data['username'], 'password' => $data['password']], $request->boolean('remember'))) {
            $request->session()->regenerate();

            return redirect()->intended(route('admin.orders.index'));
        }

        return back()->withInput($request->only('username'))->with('err', 'نام کاربری یا رمز عبور درست نیست.');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('admin.login');
    }
}
