<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Support\Fa;

class DashboardController extends Controller
{
    public function index()
    {
        $awaiting = Order::query()->where('status', 'awaiting_payment')->count();
        $paid = Order::query()->where('status', 'paid')->count();
        $activated = Order::query()->where('status', 'activated')->count();
        $products = Product::query()->count();
        $recent = Order::query()->latest('id')->limit(8)->get();

        return view('admin.dashboard', compact('awaiting', 'paid', 'activated', 'products', 'recent'));
    }
}
