<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\Setting;
use App\Models\User;
use App\Services\Backup;
use App\Services\Updater;
use App\Support\ErrorLog;
use App\Support\Fa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Throwable;

/** ابزار سایت: پشتیبان‌گیری، به‌روزرسانی فول‌پکیج، گزارش خطاها */
class ToolsController extends Controller
{
    /* ---------------- پشتیبان‌گیری ---------------- */

    public function backups(Backup $b)
    {
        return view('admin.tools.backups', [
            'list' => $b->list(),
            'auto' => Setting::get('backup_auto', '1') === '1',
            'type' => Setting::get('backup_type', 'db'),
            'keep' => (int) Setting::get('backup_keep', '7'),
            'hour' => (int) Setting::get('backup_hour', '3'),
            'free' => @disk_free_space(storage_path()) ?: null,
            'zip' => class_exists(\ZipArchive::class),
        ]);
    }

    public function backupCreate(Request $request, Backup $b)
    {
        try {
            $f = $b->create($request->input('type') === 'full' ? 'full' : 'db', 'manual');

            return back()->with('ok', 'پشتیبان ساخته شد: '.$f);
        } catch (Throwable $e) {
            report($e);

            return back()->with('err', 'ساخت پشتیبان ناموفق بود: '.$e->getMessage());
        }
    }

    public function backupUpload(Request $request, Backup $b)
    {
        $request->validate(['file' => ['required', 'file']], Fa::messages() + ['file.required' => 'فایل zip پشتیبان را انتخاب کنید.']);
        try {
            $name = $b->storeUpload($request->file('file')->getRealPath(), (string) $request->file('file')->getClientOriginalName());

            return back()->with('ok', 'فایل به فهرست پشتیبان‌ها اضافه شد ('.$name.').');
        } catch (Throwable $e) {
            return back()->with('err', $e->getMessage());
        }
    }

    public function backupSettings(Request $request)
    {
        $d = $request->validate([
            'backup_type' => ['required', 'in:db,full'],
            'backup_keep' => ['required', 'integer', 'min:1', 'max:60'],
            'backup_hour' => ['required', 'integer', 'min:0', 'max:23'],
        ], Fa::messages());
        Setting::put('backup_auto', $request->boolean('backup_auto') ? '1' : '0');
        foreach ($d as $k => $v) {
            Setting::put($k, (string) $v);
        }

        return back()->with('ok', 'تنظیمات پشتیبان خودکار ذخیره شد.');
    }

    public function backupRestore(Request $request, Backup $b, string $file)
    {
        try {
            $r = $b->restore($file, $request->boolean('files', true));

            return redirect()->route('admin.tools.backups')->with('ok', 'بازگردانی انجام شد: '.Fa::digits($r['statements']).' دستور و '.Fa::digits($r['files']).' فایل.');
        } catch (Throwable $e) {
            report($e);

            return back()->with('err', 'بازگردانی ناموفق بود: '.$e->getMessage());
        }
    }

    public function backupDelete(Backup $b, string $file)
    {
        $b->delete($file);

        return back()->with('ok', 'پشتیبان حذف شد.');
    }

    public function backupDownload(Backup $b, string $file)
    {
        $path = $b->path($file);
        abort_unless($path, 404);
        @set_time_limit(0);
        while (ob_get_level() > 0) {
            @ob_end_clean();
        }

        return response()->download($path, basename($path));
    }

    public static function autoBackup(): void
    {
        try {
            if (Setting::get('backup_auto', '1') !== '1' || (int) now()->format('G') < (int) Setting::get('backup_hour', '3')) {
                return;
            }
            $b = app(Backup::class);
            if (($last = $b->lastTime()) && $last->isToday()) {
                return;
            }
            if (! Cache::add('backup.auto.'.now()->format('Ymd'), 1, 3600)) {
                return;
            }
            $b->create(Setting::get('backup_type', 'db'), 'auto');
            $b->prune((int) Setting::get('backup_keep', '7'));
        } catch (Throwable $e) {
            report($e);
        }
    }

    /* ---------------- به‌روزرسانی فول‌پکیج ---------------- */

    protected function packages(Updater $u): array
    {
        $out = [];
        foreach (glob($u->workDir().'/*.zip') ?: [] as $f) {
            $out[] = ['file' => basename($f), 'size' => filesize($f), 'time' => filemtime($f)];
        }
        usort($out, fn ($a, $b) => $b['time'] <=> $a['time']);

        return $out;
    }

    protected function pkgPath(Updater $u, string $file): ?string
    {
        if (! preg_match('/^[A-Za-z0-9_.\-]+\.zip$/', $file)) {
            return null;
        }
        $p = $u->workDir().'/'.$file;

        return is_file($p) ? $p : null;
    }

    public function update(Request $request, Updater $u)
    {
        $inspected = null;
        if ($pkg = $request->query('pkg')) {
            $p = $this->pkgPath($u, (string) $pkg);
            try {
                $inspected = $p ? $u->inspect($p) + ['file' => $pkg] : null;
                if (! $p) {
                    session()->now('err', 'فایل بسته پیدا نشد.');
                }
            } catch (Throwable $e) {
                session()->now('err', $e->getMessage());
            }
        }

        return view('admin.tools.update', [
            'version' => config('mahdwob.version'),
            'packages' => $this->packages($u),
            'inspected' => $inspected,
            'previous' => $u->previous(),
            'log' => $u->logTail(30),
            'maxUpload' => ini_get('upload_max_filesize'),
            'zip' => class_exists(\ZipArchive::class),
        ]);
    }

    public function updateUpload(Request $request, Updater $u)
    {
        $request->validate(['package' => ['required', 'file']], Fa::messages() + ['package.required' => 'فایل zip نسخه جدید را انتخاب کنید.']);
        $name = 'pkg-'.now()->format('Ymd-His').'.zip';
        $request->file('package')->move($u->workDir(), $name);

        return redirect()->route('admin.tools.update', ['pkg' => $name]);
    }

    public function updateInstall(Request $request, Updater $u)
    {
        $p = $this->pkgPath($u, (string) $request->input('pkg'));
        if (! $p) {
            return redirect()->route('admin.tools.update')->with('err', 'فایل بسته پیدا نشد. دوباره آپلود کنید.');
        }
        try {
            $r = $u->install($p);
            @unlink($p);

            return redirect()->route('admin.tools.update')->with('ok', 'سایت از نسخه '.$r['from'].' به '.$r['to'].' به‌روز شد. پشتیبان: '.$r['backup']);
        } catch (Throwable $e) {
            report($e);

            return redirect()->route('admin.tools.update')->with('err', "به‌روزرسانی انجام نشد و سایت روی نسخه قبلی ماند.\n".$e->getMessage());
        }
    }

    public function updateDeletePkg(Updater $u, string $file)
    {
        if ($p = $this->pkgPath($u, $file)) {
            @unlink($p);
        }

        return redirect()->route('admin.tools.update')->with('ok', 'فایل بسته حذف شد.');
    }

    public function updateRollback(Request $request, Updater $u)
    {
        try {
            $v = $u->rollback((string) $request->input('dir'));

            return redirect()->route('admin.tools.update')->with('ok', 'کد سایت به نسخه '.$v.' برگشت.');
        } catch (Throwable $e) {
            return back()->with('err', $e->getMessage());
        }
    }

    public function healthPing(Request $request)
    {
        $key = @file_get_contents(storage_path('app/health.key'));
        abort_unless($key && hash_equals(trim($key), (string) $request->query('key')), 404);
        $checks = [];
        $migrated = false;
        try {
            if ($request->boolean('migrate')) {
                if (function_exists('opcache_reset')) {
                    @opcache_reset();
                }
                @set_time_limit(300);
                @ignore_user_abort(true);
                $out = Cache::lock('schema_migrate', 300)->block(200, function () {
                    Artisan::call('migrate', ['--force' => true]);

                    return Artisan::output();
                });
                $migrated = str_contains($out, 'DONE') || str_contains($out, 'Migrated');
                Setting::flush();
                $checks['migrate'] = true;
            }
            DB::select('select 1');
            $checks['db'] = true;
            Product::query()->count();
            Order::query()->count();
            User::query()->count();
            $checks['models'] = true;
            view('admin.login')->render();
            $checks['views'] = true;
        } catch (Throwable $e) {
            return response()->json(['ok' => false, 'error' => $e->getMessage().' @ '.basename($e->getFile()).':'.$e->getLine(), 'checks' => $checks, 'migrated' => $migrated], 500);
        }

        return response()->json(['ok' => true, 'marker' => 'MAHDWOB-OK', 'version' => config('mahdwob.version'), 'checks' => $checks, 'migrated' => $migrated]);
    }

    /* ---------------- گزارش خطاها ---------------- */

    public function errors(Request $request)
    {
        $tab = (string) $request->query('tab', 'open');
        $all = ErrorLog::groups();
        $counts = array_count_values(array_column($all, 'status'));
        $map = ['open' => ['open', 'again'], 'pending' => ['pending'], 'fixed' => ['fixed'], 'transient' => ['transient'], 'acked' => ['acked'], 'all' => null];
        $want = $map[$tab] ?? null;
        $rows = $want ? array_values(array_filter($all, fn ($g) => in_array($g['status'], $want, true))) : $all;

        return view('admin.tools.errors', ['rows' => array_slice($rows, 0, 150), 'counts' => $counts, 'total' => count($all), 'tab' => $tab, 'ver' => config('mahdwob.version')]);
    }

    public function errorsAck(Request $request)
    {
        ErrorLog::ack((string) $request->input('sig'));

        return back()->with('ok', 'علامت «بررسی شد» ثبت شد.');
    }

    public function errorsDownload()
    {
        $txt = ErrorLog::report(ErrorLog::groups());

        return response()->streamDownload(fn () => print($txt), 'errors-'.date('Ymd-His').'.txt', ['Content-Type' => 'text/plain; charset=utf-8']);
    }

    public function errorsClear()
    {
        foreach (glob(storage_path('logs/*.log')) ?: [] as $f) {
            @unlink($f);
        }
        Cache::forget('errlog.open');

        return back()->with('ok', 'گزارش خطاها پاک شد.');
    }
}
