<?php

namespace App\Providers;

use App\Http\Controllers\ToolsController;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Schema::defaultStringLength(191);
        $this->app->terminating(fn () => ToolsController::autoBackup());
    }
}
