<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<title>نصب مهدوب</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;800&display=swap">
<link rel="stylesheet" href="{{ asset('css/admin.css') }}">
</head>
<body>
<main class="box" style="margin-top:30px;max-width:440px">
  <h1>نصب مهدوب</h1>
  <p class="muted">دیتابیس خودکار ساخته می‌شود. فقط یوزر و رمز پنل را بگذارید.</p>
  @if(session('err'))<div class="alert err">{{ session('err') }}</div>@endif
  @if($errors->any())<div class="alert err">{{ $errors->first() }}</div>@endif

  @if($blocked)
    <div class="card">
      <div class="alert err">قبل از نصب این موارد را درست کنید، بعد صفحه را تازه کنید:</div>
      <table class="req">
        @foreach($checks as $c)
          @if(! $c['ok'] && $c['required'])
            <tr><td>{{ $c['label'] }}</td><td class="no">ناموفق</td></tr>
          @endif
        @endforeach
      </table>
      <p class="muted" style="margin-top:10px">معمولاً: PHP ۸٫۳ + مجوز ۷۷۵ برای <span class="ltr">storage</span> و <span class="ltr">bootstrap/cache</span> + افزونه <span class="ltr">pdo_sqlite</span></p>
    </div>
  @else
    <form method="POST" action="{{ route('install.run') }}" class="card">
      @csrf
      <div class="field"><label>نام کاربری</label><input class="ltr" type="text" name="username" value="{{ old('username', 'admin') }}" required minlength="3" autofocus></div>
      <div class="field"><label>رمز عبور</label><input class="ltr" type="password" name="admin_password" required minlength="6"></div>
      <div class="field"><label>تکرار رمز</label><input class="ltr" type="password" name="admin_password_confirmation" required minlength="6"></div>
      <button class="btn" type="submit">نصب و ساخت دیتابیس</button>
    </form>
  @endif
</main>
</body>
</html>
