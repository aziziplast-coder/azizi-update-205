<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>نصب انجام شد</title>
<link rel="stylesheet" href="{{ asset('css/admin.css') }}">
</head>
<body>
<main class="box" style="margin-top:30px;max-width:440px">
  <h1>تمام شد</h1>
  <div class="card">
    <div class="alert ok">دیتابیس ساخته شد و سایت آماده است.</div>
    @if(session('username'))
      <p>ورود پنل با نام کاربری: <b class="ltr">{{ session('username') }}</b></p>
    @endif
    <p><a class="btn" href="{{ url('/admin/login') }}">ورود به پنل</a>
    <a class="btn" href="{{ url('/') }}" style="margin-inline-start:8px">مشاهده سایت</a></p>
  </div>
</main>
</body>
</html>
