<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<title>ورود به پنل</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;800&display=swap">
<link rel="stylesheet" href="{{ asset('css/admin.css') }}">
</head>
<body>
<main class="login">
  <form class="card" method="POST" action="{{ route('admin.login.post') }}">
    @csrf
    <h1>ورود به پنل</h1>
    @if(session('ok'))<div class="alert ok">{{ session('ok') }}</div>@endif
    @if(session('err'))<div class="alert err">{{ session('err') }}</div>@endif
    <div class="field"><label for="username">نام کاربری</label><input id="username" class="ltr" type="text" name="username" value="{{ old('username') }}" required autofocus>@error('username')<span class="err">{{ $message }}</span>@enderror</div>
    <div class="field"><label for="password">رمز عبور</label><input id="password" class="ltr" type="password" name="password" required>@error('password')<span class="err">{{ $message }}</span>@enderror</div>
    <label class="check"><input type="checkbox" name="remember" value="1"><span>مرا به خاطر بسپار</span></label>
    <button class="btn" type="submit">ورود</button>
  </form>
</main>
</body>
</html>
