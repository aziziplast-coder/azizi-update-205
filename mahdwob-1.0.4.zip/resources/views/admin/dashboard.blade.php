@extends('layouts.admin')
@section('title', 'داشبورد')
@section('content')
@php $fa = fn ($v) => \App\Support\Fa::digits($v); @endphp
<div class="stats">
  <div class="stat"><span class="muted">در انتظار پرداخت</span><b>{{ $fa($awaiting) }}</b></div>
  <div class="stat"><span class="muted">پرداخت‌شده</span><b>{{ $fa($paid) }}</b></div>
  <div class="stat"><span class="muted">فعال‌شده</span><b>{{ $fa($activated) }}</b></div>
  <div class="stat"><span class="muted">محصولات</span><b>{{ $fa($products) }}</b></div>
</div>

<div class="card">
  <div class="head"><h2>آخرین سفارش‌ها</h2><a class="btn line sm" href="{{ route('admin.orders.index') }}">همه سفارش‌ها</a></div>
  @if($recent->isEmpty())
    <p class="muted">هنوز سفارشی ثبت نشده است.</p>
  @else
    <div class="wrap"><table class="tbl">
      <tr><th>کد</th><th>وضعیت</th><th>مبلغ</th><th></th></tr>
      @foreach($recent as $o)
        <tr>
          <td class="ltr">{{ $o->code }}</td>
          <td>{{ $o->status }}</td>
          <td>{{ $fa(number_format((int) $o->amount)) }}</td>
          <td><a class="btn line sm" href="{{ route('admin.orders.show', $o) }}">مشاهده</a></td>
        </tr>
      @endforeach
    </table></div>
  @endif
</div>
@endsection
