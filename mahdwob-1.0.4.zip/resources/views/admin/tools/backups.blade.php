@extends('layouts.admin')
@section('title', 'پشتیبان‌گیری')
@section('content')
@php
  $fa = fn ($v) => \App\Support\Fa::digits($v);
  $size = fn ($b) => $b >= 1048576 ? $fa(number_format($b / 1048576, 1)).' مگابایت' : $fa(max(1, round($b / 1024))).' کیلوبایت';
  $labels = \App\Services\Backup::LABELS;
@endphp
<div class="head"><h1>پشتیبان‌گیری و بازگردانی</h1>
  @if($free)<span class="muted">فضای خالی هاست: {{ $size($free) }}</span>@endif
</div>
@unless($zip)<div class="alert err">افزونه zip روی هاست فعال نیست. در cPanel بخش Select PHP Version، افزونه zip را فعال کنید.</div>@endunless

<div class="card">
  <h2>پشتیبان‌گیری الان</h2>
  <p class="muted">«فقط دیتابیس» سفارش‌ها، محصولات و تنظیمات را دارد. «کامل» فایل‌های آپلودی را هم اضافه می‌کند.</p>
  <form method="POST" action="{{ route('admin.tools.backups.create') }}" class="row" onsubmit="this.querySelector('button').disabled=true;this.querySelector('button').textContent='در حال ساخت…'">
    @csrf
    <label class="check"><input type="radio" name="type" value="db" checked><span>فقط دیتابیس</span></label>
    <label class="check"><input type="radio" name="type" value="full"><span>کامل</span></label>
    <button class="btn" type="submit">ساخت پشتیبان</button>
  </form>
</div>

<div class="card">
  <h2>پشتیبان‌ها</h2>
  @if(! $list)
    <p class="muted">هنوز پشتیبانی ساخته نشده است.</p>
  @else
  <div class="wrap"><table class="tbl">
    <tr><th>زمان</th><th>نوع</th><th>حجم</th><th></th></tr>
    @foreach($list as $b)
      <tr>
        <td>{{ $fa($b['time']->format('Y/m/d H:i')) }}<div class="muted ltr" style="font-size:11.5px">{{ $b['file'] }}</div></td>
        <td><span class="chip {{ $b['type'] === 'full' ? 'good' : '' }}">{{ $b['type'] === 'full' ? 'کامل' : 'دیتابیس' }}</span> <span class="muted">{{ $labels[$b['label']] ?? $b['label'] }}</span></td>
        <td>{{ $size($b['size']) }}</td>
        <td><div class="row" style="justify-content:flex-end">
          <a class="btn line sm" href="{{ route('admin.tools.backups.download', $b['file']) }}">دانلود</a>
          <form method="POST" action="{{ route('admin.tools.backups.restore', $b['file']) }}" class="inline" onsubmit="return confirm('اطلاعات فعلی با این پشتیبان جایگزین شود؟')">@csrf<button class="btn line sm" type="submit">بازگردانی</button></form>
          <form method="POST" action="{{ route('admin.tools.backups.delete', $b['file']) }}" class="inline" onsubmit="return confirm('این پشتیبان حذف شود؟')">@csrf @method('DELETE')<button class="btn danger sm" type="submit">حذف</button></form>
        </div></td>
      </tr>
    @endforeach
  </table></div>
  @endif
</div>

<form class="card" method="POST" action="{{ route('admin.tools.backups.upload') }}" enctype="multipart/form-data">
  @csrf
  <h2>آپلود فایل پشتیبان</h2>
  <div class="field"><input type="file" name="file" accept=".zip" required></div>
  <div class="row"><button class="btn line" type="submit">آپلود</button></div>
</form>

<form class="card" method="POST" action="{{ route('admin.tools.backups.settings') }}">
  @csrf
  <h2>پشتیبان خودکار روزانه</h2>
  <label class="check"><input type="checkbox" name="backup_auto" value="1" @checked($auto)><span>هر روز خودکار پشتیبان گرفته شود</span></label>
  <div class="grid2">
    <div class="field"><label>نوع</label><select name="backup_type"><option value="db" @selected($type === 'db')>فقط دیتابیس</option><option value="full" @selected($type === 'full')>کامل</option></select></div>
    <div class="field"><label>تعداد نگه‌داری</label><input class="ltr" type="number" name="backup_keep" min="1" max="60" value="{{ $keep }}"></div>
    <div class="field"><label>از ساعت</label><input class="ltr" type="number" name="backup_hour" min="0" max="23" value="{{ $hour }}"><small>اولین بازدید بعد از این ساعت</small></div>
  </div>
  <div class="row"><button class="btn" type="submit">ذخیره</button></div>
</form>
@endsection
