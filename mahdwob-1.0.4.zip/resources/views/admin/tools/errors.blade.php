@extends('layouts.admin')
@section('title', 'گزارش خطاها')
@section('content')
@php
  $fa = fn ($v) => \App\Support\Fa::digits($v);
  $tabs = ['open' => 'باز', 'pending' => 'رفع در نسخه بعد', 'fixed' => 'برطرف‌شده', 'transient' => 'موقت (حین به‌روزرسانی)', 'acked' => 'بررسی‌شده', 'all' => 'همه'];
  $badge = ['open' => ['🆕 باز', 'chip'], 'again' => ['⚠️ دوباره رخ داد', 'chip'], 'pending' => ['⏳ رفع در نسخه '.'بعد', 'chip off'], 'fixed' => ['✅ برطرف شد', 'chip good'], 'transient' => ['⏱ موقت', 'chip off'], 'acked' => ['✔ بررسی شد', 'chip off']];
  $cnt = fn ($t) => $t === 'open' ? ($counts['open'] ?? 0) + ($counts['again'] ?? 0) : ($t === 'all' ? $total : ($counts[$t] ?? 0));
@endphp
<div class="head"><h1>شناسایی و رفع خطاها</h1>
  <div class="row">
    <a class="btn line sm" href="{{ route('admin.tools.errors.download') }}">دانلود گزارش برای پشتیبان</a>
    <form method="POST" action="{{ route('admin.tools.errors.clear') }}" class="inline" onsubmit="return confirm('همه گزارش‌های خطا پاک شود؟')">@csrf<button class="btn danger sm" type="submit">پاک کردن گزارش</button></form>
  </div>
</div>
<p class="muted">هر خطایی که در سایت یا پنل رخ دهد این‌جا ثبت و خطاهای یکسان یک‌جا جمع می‌شوند. اگر خطای «باز» دیدید، «دانلود گزارش» را بزنید و فایل را برای پشتیبان بفرستید.</p>

<div class="tabs">
  @foreach($tabs as $k => $t)
    <a href="{{ route('admin.tools.errors', ['tab' => $k]) }}" @class(['on' => $tab === $k])>{{ $t }} ({{ $fa($cnt($k)) }})</a>
  @endforeach
</div>

@forelse($rows as $g)
  <div class="err-item {{ $g['status'] }}">
    <div class="row" style="justify-content:space-between">
      <div class="row"><span class="{{ $badge[$g['status']][1] ?? 'chip' }}">{{ $badge[$g['status']][0] ?? $g['status'] }}</span>
        <span class="muted">{{ $fa($g['count']) }} بار · اول <span dir="ltr">{{ $fa(substr(str_replace('-', '/', $g['first']), 0, 16)) }}</span> · آخر <span dir="ltr">{{ $fa(substr(str_replace('-', '/', $g['last']), 0, 16)) }}</span></span></div>
      @if(in_array($g['status'], ['open', 'again'], true))
        <form method="POST" action="{{ route('admin.tools.errors.ack') }}" class="inline">@csrf<input type="hidden" name="sig" value="{{ $g['sig'] }}"><button class="btn line sm" type="submit">بررسی شد</button></form>
      @endif
    </div>
    @if($g['title'])<b>{{ $g['title'] }}</b>@endif
    @if($g['why'])<span class="muted">{{ $g['why'] }}</span>@endif
    <code>{{ $g['msg'] }}</code>
    @if($g['loc'])<span class="muted ltr" style="font-size:12.5px">{{ $g['loc'] }}</span>@endif
    @if($g['trace'])<details><summary class="muted">جزئیات فنی</summary><pre>{{ $g['trace'] }}</pre></details>@endif
  </div>
@empty
  <div class="card"><p>✅ در این بخش خطایی نیست.</p></div>
@endforelse
@endsection
