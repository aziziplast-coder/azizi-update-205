@extends('layouts.admin')
@section('title', 'به‌روزرسانی')
@section('content')
@php
  $fa = fn ($v) => \App\Support\Fa::digits($v);
  $size = fn ($b) => $fa(number_format($b / 1048576, 1)).' مگابایت';
@endphp
<div class="head"><h1>به‌روزرسانی سایت</h1><span class="chip">نسخه فعلی: {{ $fa($version) }}</span></div>
@unless($zip)<div class="alert err">افزونه zip روی هاست فعال نیست؛ به‌روزرسانی از این صفحه ممکن نیست. در cPanel بخش Select PHP Version، افزونه zip را فعال کنید.</div>@endunless

@if($inspected)
  <div class="card">
    <h2>بسته آماده نصب</h2>
    <div class="kvs">
      <div><span>نسخه فعلی</span><span>{{ $version }}</span></div>
      <div><span>نسخه جدید</span><span>{{ $inspected['version'] }}</span></div>
      <div><span>تعداد فایل</span><span>{{ $inspected['files'] }}</span></div>
    </div>
    @if(version_compare($inspected['version'], $version, '<'))<div class="alert warn">نسخه این بسته از نسخه فعلی قدیمی‌تر است.</div>@endif
    <p class="muted">پیش از نصب، خودکار از دیتابیس پشتیبان گرفته می‌شود. اگر نسخه جدید روی هاست درست اجرا نشود، سایت خودکار به نسخه فعلی برمی‌گردد. تنظیمات (.env)، دیتابیس و فایل‌های آپلودی دست نمی‌خورند.</p>
    <form method="POST" action="{{ route('admin.tools.update.install') }}" class="row" onsubmit="this.querySelector('button').disabled=true;this.querySelector('button').textContent='در حال نصب… (تا دو دقیقه صفحه را نبندید)'">
      @csrf<input type="hidden" name="pkg" value="{{ $inspected['file'] }}">
      <button class="btn" type="submit">نصب نسخه {{ $fa($inspected['version']) }}</button>
      <a class="btn line" href="{{ route('admin.tools.update') }}">انصراف</a>
    </form>
  </div>
@endif

<form class="card" method="POST" action="{{ route('admin.tools.update.upload') }}" enctype="multipart/form-data" onsubmit="this.querySelector('button').disabled=true;this.querySelector('button').textContent='در حال آپلود…'">
  @csrf
  <h2>۱. آپلود فایل نسخه جدید</h2>
  <p class="muted">همان فایل zip نسخه جدید را انتخاب کنید. بعد از آپلود، اطلاعات بسته نمایش داده می‌شود تا «نصب» را بزنید.</p>
  <div class="field"><input type="file" name="package" accept=".zip" required>@error('package')<span class="err">{{ $message }}</span>@enderror
    <small>حداکثر حجم آپلود این هاست: <span class="ltr">{{ $maxUpload }}</span>. اگر فایل بزرگ‌تر است: با File Manager سی‌پنل فایل zip را در پوشه <span class="ltr">storage/app/update</span> آپلود کنید و این صفحه را تازه کنید؛ زیر همین بخش نمایش داده می‌شود.</small></div>
  <div class="row"><button class="btn" type="submit">آپلود و بررسی</button></div>
</form>

@if($packages)
<div class="card">
  <h2>فایل‌های بسته روی هاست</h2>
  <div class="wrap"><table class="tbl">
    @foreach($packages as $p)
      <tr><td class="ltr">{{ $p['file'] }}</td><td>{{ $size($p['size']) }}</td><td>{{ $fa(date('Y/m/d H:i', $p['time'])) }}</td>
        <td><div class="row" style="justify-content:flex-end">
          <a class="btn line sm" href="{{ route('admin.tools.update', ['pkg' => $p['file']]) }}">بررسی و نصب</a>
          <form method="POST" action="{{ route('admin.tools.update.delete', $p['file']) }}" class="inline">@csrf @method('DELETE')<button class="btn danger sm" type="submit">حذف</button></form>
        </div></td></tr>
    @endforeach
  </table></div>
</div>
@endif

@if($previous)
<div class="card">
  <h2>بازگشت به نسخه قبلی</h2>
  <p class="muted">اگر بعد از به‌روزرسانی چیزی درست کار نمی‌کند، کد سایت را به نسخه قبل برگردانید (اطلاعات دیتابیس دست نمی‌خورد).</p>
  @foreach($previous as $p)
    <form method="POST" action="{{ route('admin.tools.update.rollback') }}" class="row" onsubmit="return confirm('کد سایت به نسخه {{ $p['version'] }} برگردد؟')">
      @csrf<input type="hidden" name="dir" value="{{ $p['dir'] }}">
      <span>نسخه <b class="ltr">{{ $p['version'] }}</b> <span class="muted">({{ $fa(date('Y/m/d H:i', $p['time'])) }})</span></span>
      <button class="btn line sm" type="submit">بازگشت به این نسخه</button>
    </form>
  @endforeach
</div>
@endif

@if($log)
<div class="card">
  <h2>گزارش به‌روزرسانی‌ها</h2>
  <pre class="env" style="direction:rtl;text-align:right">{{ $log }}</pre>
</div>
@endif
@endsection
