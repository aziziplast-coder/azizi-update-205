<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\ProductController as AdminProductController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\InstallController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\StoreController;
use App\Http\Controllers\ToolsController;
use Illuminate\Support\Facades\Route;

Route::get('/', [StoreController::class, 'home'])->name('home');
Route::get('/product/{slug}', [StoreController::class, 'product'])->name('product.show');
Route::get('/order', [StoreController::class, 'orderForm'])->name('order.create');
Route::post('/order', [StoreController::class, 'orderStore'])->name('order.store');
Route::get('/order/{code}', [StoreController::class, 'orderShow'])->name('order.show');

Route::get('/health-check', [ToolsController::class, 'healthPing'])->name('health.ping');

Route::get('/install', [InstallController::class, 'show'])->name('install');
Route::post('/install', [InstallController::class, 'run'])->name('install.run');
Route::get('/install/done', [InstallController::class, 'done'])->name('install.done');

Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('login', [AuthController::class, 'login'])->middleware('throttle:10,1')->name('login.post');

    Route::middleware('auth')->group(function () {
        Route::post('logout', [AuthController::class, 'logout'])->name('logout');

        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

        Route::get('orders', [AdminOrderController::class, 'index'])->name('orders.index');
        Route::get('orders/{order}', [AdminOrderController::class, 'show'])->name('orders.show');
        Route::post('orders/{order}', [AdminOrderController::class, 'update'])->name('orders.update');
        Route::post('orders/{order}/activate', [AdminOrderController::class, 'activate'])->name('orders.activate');

        Route::resource('products', AdminProductController::class)->except(['show']);

        Route::get('settings', [SettingsController::class, 'show'])->name('settings');
        Route::post('settings/site', [SettingsController::class, 'updateSite'])->name('settings.site');
        Route::post('settings/password', [SettingsController::class, 'updatePassword'])->name('settings.password');

        Route::prefix('tools')->name('tools.')->controller(ToolsController::class)->group(function () {
            $f = '[A-Za-z0-9_.\-]+\.zip';
            Route::get('backups', 'backups')->name('backups');
            Route::post('backups', 'backupCreate')->name('backups.create');
            Route::post('backups/upload', 'backupUpload')->name('backups.upload');
            Route::post('backups/settings', 'backupSettings')->name('backups.settings');
            Route::get('backups/{file}/download', 'backupDownload')->name('backups.download')->where('file', $f);
            Route::post('backups/{file}/restore', 'backupRestore')->name('backups.restore')->where('file', $f);
            Route::delete('backups/{file}', 'backupDelete')->name('backups.delete')->where('file', $f);

            Route::get('update', 'update')->name('update');
            Route::post('update', 'updateUpload')->name('update.upload');
            Route::post('update/install', 'updateInstall')->name('update.install');
            Route::post('update/rollback', 'updateRollback')->name('update.rollback');
            Route::delete('update/{file}', 'updateDeletePkg')->name('update.delete')->where('file', $f);

            Route::get('errors', 'errors')->name('errors');
            Route::post('errors/ack', 'errorsAck')->name('errors.ack');
            Route::get('errors/download', 'errorsDownload')->name('errors.download');
            Route::post('errors/clear', 'errorsClear')->name('errors.clear');
        });
    });
});
