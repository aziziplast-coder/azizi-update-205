<?php

return [
    'version' => '1.0.3',
    'brand_default' => 'مهدوب',
];
