@extends('walkin.layout', ['bodyClass' => 'wk-app'])

@section('body')
<header class="wk-top">
    <div class="wk-top-row">
        <img src="{{ asset('img/walkin-192.png') }}" alt="" width="34" height="34" class="wk-logo">
        <div class="wk-brand"><b>{{ \App\Services\Walkin::appName() }}</b><small>{{ $user->displayName() }} · {{ $assign ? 'سرپرست تحویل' : ($deliver ? 'بارکدزن و تحویل‌دهنده' : 'بارکدزن') }}</small></div>
        <button type="button" class="wk-inst" data-install hidden title="نصب برنامه روی گوشی">📲 نصب</button>
        <span class="wk-net" data-net title="وضعیت اتصال"></span>
        <form method="post" action="{{ route('walkin.logout') }}">@csrf<button class="wk-ic" title="خروج" aria-label="خروج"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 17l-5-5 5-5M5 12h11"/></svg></button></form>
    </div>
    <nav class="wk-tabs" data-tabs>
        <button type="button" class="on" data-tab="sale"><span>اسکن</span><em data-count="sale">۰</em></button>
        @if ($deliver)<button type="button" data-tab="deliver"><span>تحویل</span><em data-count="deliver">۰</em></button>@endif
        @if ($assign)<button type="button" data-tab="assign"><span>ارجاع</span><em data-count="assign">۰</em></button>@endif
        <button type="button" data-tab="ret"><span>مرجوعی</span><em data-count="ret">۰</em></button>
    </nav>
</header>
<main class="wk-main" data-main></main>
<div class="wk-scan-dock" data-scan-dock hidden>
    <span class="wk-scan-led" aria-hidden="true"></span>
    <input class="wk-scan" data-scan type="text" inputmode="none" enterkeyhint="done" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" aria-label="ورودی بارکدخوان" placeholder="بارکدخوان بلوتوثی را بزنید…">
</div>
<div class="wk-toast" data-toast hidden></div>
<script>window.WK = {!! json_encode(['deliver' => $deliver, 'assign' => $assign, 'me' => $user->id, 'base' => '/'.ltrim(parse_url(url('/walkin/api'), PHP_URL_PATH), '/'), 'csrf' => csrf_token(), 'login' => route('walkin.login', [], false)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!};</script>
<script src="{{ asset('js/walkin.js') }}?v={{ @filemtime(public_path('js/walkin.js')) }}"></script>
@endsection
