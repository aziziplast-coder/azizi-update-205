<?php

use App\Support\Scheduler;
use Illuminate\Support\Facades\Artisan;

Artisan::command('store:cron', function () {
    $done = Scheduler::tick();
    $this->info('OK '.implode(',', $done));
})->purpose('کارهای دوره‌ای فروشگاه (بکاپ روزانه، لغو سفارش‌های پرداخت‌نشده)');
