<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\CollectionController;
use App\Http\Controllers\PushController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\InstallController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\KeeperController;
use App\Http\Controllers\PwaController;
use App\Http\Controllers\SeoController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\ThumbController;
use Illuminate\Support\Facades\Route;

// نصب‌کننده
Route::get('/install', [InstallController::class, 'show'])->name('install');
Route::post('/install', [InstallController::class, 'run'])->name('install.run');

// فایل‌های بدون نیاز به سشن
Route::get('/uploads/_t/{w}/{path}', ThumbController::class)->where(['w' => '[0-9]+', 'path' => '.+'])->name('thumb');
Route::get('/manifest.webmanifest', [PwaController::class, 'manifest'])->name('pwa.manifest');
Route::get('/sw.js', [PwaController::class, 'worker'])->name('pwa.worker');
Route::get('/pwa-icon-{size}.png', [PwaController::class, 'icon'])->where('size', '[0-9]+')->name('pwa.icon');
Route::get('/buyer-icon-{size}.png', [PwaController::class, 'buyerIcon'])->where('size', '[0-9]+')->name('pwa.buyer_icon');
Route::get('/manage-icon-{size}.png', [PwaController::class, 'manageIcon'])->where('size', '[0-9]+')->name('pwa.manage_icon');
Route::get('/factory-icon-{size}.png', [PwaController::class, 'factoryIcon'])->where('size', '[0-9]+')->name('pwa.factory_icon');
Route::get('/download/app', \App\Http\Controllers\AppDownloadController::class)->name('app.download');
// لینک ثابت دانلود مستقیم اپ اندروید (همیشه آخرین نسخه ساخته‌شده؛ با ساخت نسخه تازه، خودکار جایگزین می‌شود)
Route::get('/aziziplast.apk', \App\Http\Controllers\AppDownloadController::class)->name('app.apk');
Route::get('/sitemap.xml', [SeoController::class, 'sitemap'])->name('sitemap');
Route::get('/robots.txt', [SeoController::class, 'robots'])->name('robots');
Route::get('/sitemap-{type}.xml', [SeoController::class, 'part'])->where('type', '[a-z]+(-[0-9]+)?')->name('sitemap.part');
Route::get('/collection/{slug}.json', [CollectionController::class, 'json'])->name('collection.json');
// هم‌شکل سایت قبلی عزیزی‌پلاست (ربات‌های کانال)
// اپ اندروید قدیمی عزیزی‌پلاست: پنجره «نصب اپ جدید» (بعد از انتقال دامنه aziziplast.com)
Route::get('/getHomePage2.php', [\App\Http\Controllers\LegacyAppController::class, 'home'])->middleware('throttle:300,1,legacyapp|');
Route::get('/jsonProducts.php', [\App\Http\Controllers\AziziFeedController::class, 'products'])->name('feed.azizi')->middleware('throttle:120,1,feed.azizi|');
Route::get('/feed/products.json', [\App\Http\Controllers\FeedController::class, 'products'])->name('feed.products')->middleware('throttle:60,1,feed.products|');
Route::get('/feed/categories.json', [\App\Http\Controllers\FeedController::class, 'categories'])->name('feed.categories')->middleware('throttle:60,1,feed.categories|');
Route::get('/feed/category/{slug}.json', [\App\Http\Controllers\FeedController::class, 'category'])->name('feed.category')->middleware('throttle:60,1,feed.category|');
Route::get('/health-check', [AdminController::class, 'healthPing'])->name('health.ping');
Route::get('/app/go/{code}', [\App\Http\Controllers\AppHandoffController::class, 'go'])->name('app.go')->where('code', '[A-Za-z0-9]+');
Route::get('/social-proof.json', [ShopController::class, 'socialProof'])->name('social.proof')->middleware('throttle:60,1,social.proof|');
// کارگر پس‌زمینه همگام‌سازی JSON (فقط با کلید مخفی؛ بدون نشست و کوکی)
Route::get('/_sync/worker/{token}', \App\Http\Controllers\SyncWorkerController::class)->name('sync.worker')->withoutMiddleware([\Illuminate\Session\Middleware\StartSession::class, \Illuminate\View\Middleware\ShareErrorsFromSession::class, \Illuminate\Foundation\Http\Middleware\VerifyCsrfToken::class, \Illuminate\Cookie\Middleware\EncryptCookies::class, \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class]);

Route::middleware('store.open')->group(function () {
    Route::get('/', [HomeController::class, 'index'])->name('home');
    Route::get('/offline', [PwaController::class, 'offline'])->name('offline');
    Route::get('/p/{slug}', [HomeController::class, 'page'])->name('page');
    Route::get('/recent', [HomeController::class, 'recent'])->name('recent')->middleware('throttle:60,1,recent|');
    Route::get('/amazing', [CollectionController::class, 'amazing'])->name('amazing');
    Route::get('/bestsellers', [ShopController::class, 'bestsellers'])->name('bestsellers');
    Route::get('/collection/{slug}', [CollectionController::class, 'show'])->name('collection');

    Route::get('/blog', [BlogController::class, 'index'])->name('blog');
    Route::get('/blog/category/{slug}', [BlogController::class, 'category'])->name('blog.category');
    Route::get('/blog/tag/{tag}', [BlogController::class, 'tag'])->name('blog.tag');
    Route::get('/blog/{slug}', [BlogController::class, 'show'])->name('blog.post');
    Route::get('/blog-{legacy}/{name?}', [BlogController::class, 'legacy'])->where(['legacy' => '[0-9]+', 'name' => '.*'])->name('blog.legacy');


    Route::get('/shop', [ShopController::class, 'index'])->name('shop');
    // لینک‌های هم‌شکل سایت قبلی (حفظ سئو): /product-39073/نام+کالا و /category/1/نام
    Route::get('/product-{legacy}/{name?}', [ShopController::class, 'legacyProduct'])->where(['legacy' => '[0-9]+', 'name' => '.*'])->name('product.legacy');
    Route::get('/category/{legacy}/{name?}', [ShopController::class, 'legacyCategory'])->where(['legacy' => '[0-9]+', 'name' => '.*'])->name('category.legacy');
    Route::get('/category/{slug}', [ShopController::class, 'category'])->name('category');
    Route::get('/product/{slug}', [ShopController::class, 'product'])->name('product');
    Route::get('/search/suggest', [ShopController::class, 'suggest'])->name('search.suggest');
    Route::post('/product/{product}/notify', [ShopController::class, 'notify'])->name('product.notify')->middleware('throttle:10,1,product.notify|');
    Route::post('/product/{product}/review', [ShopController::class, 'review'])->name('product.review')->middleware(['auth', 'throttle:5,1,product.review|']);

    Route::get('/cart', [CartController::class, 'index'])->name('cart');
    Route::post('/cart/set', [CartController::class, 'set'])->name('cart.set')->middleware('throttle:120,1,cart.set|');
    Route::post('/cart/coupon', [CartController::class, 'coupon'])->name('cart.coupon')->middleware('throttle:20,1,cart.coupon|');

    Route::get('/login', [AuthController::class, 'show'])->name('login');
    Route::post('/login/otp', [AuthController::class, 'sendOtp'])->name('login.otp')->middleware('throttle:40,1,login.otp|');
    Route::post('/login/verify', [AuthController::class, 'verifyOtp'])->name('login.verify')->middleware('throttle:120,1,login.verify|');
    Route::post('/login/password', [AuthController::class, 'password'])->name('login.password')->middleware('throttle:120,1,login.password|');
    Route::post('/register', [AuthController::class, 'register'])->name('register')->middleware('throttle:5,1,register|');
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::middleware('auth')->group(function () {
        Route::get('/checkout', [CheckoutController::class, 'show'])->name('checkout');
        Route::post('/checkout', [CheckoutController::class, 'place'])->name('checkout.place')->middleware('throttle:20,1,checkout.place|');
        Route::get('/checkout/summary', [CheckoutController::class, 'summary'])->name('checkout.summary');
        Route::post('/checkout/track', [CheckoutController::class, 'track'])->name('checkout.track')->middleware('throttle:60,1,checkout.track|');
        Route::get('/checkout/cheque', [CheckoutController::class, 'chequePlan'])->name('checkout.cheque')->middleware('throttle:60,1,checkout.cheque|');
        Route::post('/order/{number}/edit', [AccountController::class, 'startEdit'])->name('order.edit');
        Route::post('/order/{number}/reorder', [AccountController::class, 'reorder'])->name('order.reorder')->middleware('throttle:20,1,order.ro|');
        Route::post('/order-edit/cancel', [AccountController::class, 'cancelEdit'])->name('order.edit.cancel');
        Route::post('/order/{number}/amend', [AccountController::class, 'amend'])->name('order.amend')->middleware('throttle:20,1,order.amend|');
        Route::post('/order/{number}/replace', [AccountController::class, 'replaceAdd'])->name('order.replace')->middleware('throttle:30,1,order.replace|');
        Route::get('/order/{number}/replace-search', [AccountController::class, 'replaceSearch'])->name('order.replace.search')->middleware('throttle:60,1,order.rs|');
        Route::post('/order/{number}/replace/{rep}/remove', [AccountController::class, 'replaceRemove'])->name('order.replace.remove')->whereNumber('rep');
        Route::post('/order/{number}/replace-submit', [AccountController::class, 'replaceSubmit'])->name('order.replace.submit')->middleware('throttle:10,1,order.replace.submit|');
        Route::post('/order/{number}/receipt/{payment}', [\App\Http\Controllers\RemitController::class, 'upload'])->name('order.receipt')->whereNumber('payment')->middleware('throttle:20,1,order.receipt|');
        Route::get('/order/{number}/receipt/{payment}', [\App\Http\Controllers\RemitController::class, 'customerReceipt'])->name('order.receipt.show')->whereNumber('payment');
        Route::get('/order/{number}/waybill', [\App\Http\Controllers\RemitController::class, 'customerWaybill'])->name('order.waybill');
        Route::post('/order/{number}/cheques', [\App\Http\Controllers\RemitController::class, 'chequeDocs'])->name('order.cheques')->middleware('throttle:20,1,order.cheques|');
        Route::get('/order/{number}/cheque/{i}', [\App\Http\Controllers\RemitController::class, 'customerChequeImage'])->name('order.cheque.img')->whereNumber('i');
        Route::get('/order/{number}/survey', [AccountController::class, 'survey'])->name('survey');
        Route::post('/order/{number}/survey', [AccountController::class, 'surveySubmit'])->name('survey.submit')->middleware('throttle:10,1,survey.submit|');
        Route::post('/order/{number}/survey/skip', [AccountController::class, 'surveySkip'])->name('survey.skip');
        Route::get('/payment/{number}', [CheckoutController::class, 'pay'])->name('payment.start');

        Route::get('/chats', [\App\Http\Controllers\ChatController::class, 'customerInbox'])->name('chats');
        Route::get('/account', [AccountController::class, 'index'])->name('account');
        Route::post('/account', [AccountController::class, 'update'])->name('account.update');
        Route::get('/order/{number}', [AccountController::class, 'order'])->name('order.show');
        // گفتگو با مسئول سفارش
        Route::get('/order/{number}/chat', [\App\Http\Controllers\ChatController::class, 'show'])->name('order.chat');
        Route::post('/order/{number}/chat', [\App\Http\Controllers\ChatController::class, 'send'])->name('order.chat.send')->middleware('throttle:40,1,chat.send|');
        Route::post('/order/{number}/chat/act', [\App\Http\Controllers\ChatController::class, 'act'])->name('order.chat.act')->middleware('throttle:30,1,chat.act|');
        Route::post('/order/{number}/chat/pay', [\App\Http\Controllers\ChatController::class, 'pay'])->name('order.chat.pay')->middleware('throttle:20,1,chat.pay|');
        Route::post('/order/{number}/chat/cheque', [\App\Http\Controllers\ChatController::class, 'cheque'])->name('order.chat.cheque')->middleware('throttle:20,1,chat.cheque|');
        Route::post('/order/{number}/chat/up', [\App\Http\Controllers\ChatController::class, 'up'])->name('order.chat.up')->middleware('throttle:200,1,chat.up|');
    });
    Route::get('/order/{number}/invoice', [InvoiceController::class, 'show'])->name('invoice')->middleware('auth');
});

Route::post('/push/subscribe', [PushController::class, 'subscribe'])->name('push.subscribe')->middleware('throttle:20,1,push.subscribe|');
Route::post('/push/unsubscribe', [PushController::class, 'unsubscribe'])->name('push.unsubscribe')->middleware('throttle:20,1,push.unsubscribe|');
Route::get('/payment/{number}/callback', [CheckoutController::class, 'callback'])->name('payment.callback');

// کارتابل انباردار (اپ PWA)
// اپ خرید و تأمین (مسئول خرید)
Route::prefix('buyer')->group(function () {
    Route::get('/manifest.webmanifest', [\App\Http\Controllers\BuyerController::class, 'manifest'])->name('buyer.manifest');
    Route::get('/login', [\App\Http\Controllers\BuyerController::class, 'loginForm'])->name('buyer.login');
    Route::post('/login', [\App\Http\Controllers\BuyerController::class, 'login'])->middleware('throttle:60,1,r24|');
    Route::post('/logout', [\App\Http\Controllers\BuyerController::class, 'logout'])->name('buyer.logout');
    Route::middleware(\App\Http\Middleware\BuyerAuth::class)->group(function () {
        Route::get('/', [\App\Http\Controllers\BuyerController::class, 'index'])->name('buyer');
        Route::get('/api/data', [\App\Http\Controllers\BuyerController::class, 'data']);
        Route::get('/api/state', [\App\Http\Controllers\BuyerController::class, 'state']);
        Route::post('/api/mark', [\App\Http\Controllers\BuyerController::class, 'mark'])->middleware('throttle:600,1,r25|');
        Route::post('/api/arrived', [\App\Http\Controllers\BuyerController::class, 'arrived'])->middleware('throttle:300,1,r33|');
        Route::get('/img/{key}', [\App\Http\Controllers\BuyerController::class, 'img'])->where('key', '[ps][0-9]+')->middleware('throttle:900,1,r26|');
        Route::post('/api/opt', [\App\Http\Controllers\BuyerController::class, 'opt']);
        Route::post('/api/rules', [\App\Http\Controllers\BuyerController::class, 'rules']);
        Route::post('/api/supplier/{supplier}', [\App\Http\Controllers\BuyerController::class, 'supplier']);
        Route::get('/api/report/{supplier}', [\App\Http\Controllers\BuyerController::class, 'report']);
        Route::post('/api/place/{supplier}', [\App\Http\Controllers\BuyerController::class, 'place']);
        Route::get('/api/orders', [\App\Http\Controllers\BuyerController::class, 'orders']);
        Route::get('/api/orders/{order}', [\App\Http\Controllers\BuyerController::class, 'order']);
        Route::get('/api/orders/{order}/arrival', [\App\Http\Controllers\BuyerController::class, 'arrival']);
        Route::post('/api/orders/{order}/status', [\App\Http\Controllers\BuyerController::class, 'orderStatus']);
        Route::post('/api/import', [\App\Http\Controllers\BuyerController::class, 'import'])->middleware('throttle:20,1,r27|');
        Route::get('/print', [\App\Http\Controllers\BuyerController::class, 'print'])->name('buyer.print');
    });
});

// آیا درخواست https این دامنه واقعاً به سایت «امن» می‌رسد (پشت CDN/پروکسی هم)؟ — پیش از روشن کردن «اجبار https»
Route::get('/_https-check', fn (\Illuminate\Http\Request $r) => response((string) \Illuminate\Support\Facades\Cache::get('https.probe', '').'|'.($r->isSecure() ? '1' : '0'), 200, ['Content-Type' => 'text/plain', 'Cache-Control' => 'no-store']));
Route::get('/_domain-check', fn () => response((string) \Illuminate\Support\Facades\Cache::get('domain.probe', ''), 200, ['Content-Type' => 'text/plain', 'Cache-Control' => 'no-store']));

Route::get('/l/{code}', function (string $code) {
    $url = \App\Support\ShortLink::resolve($code);
    abort_unless($url, 404);

    return redirect($url);
})->where('code', '[A-Za-z0-9]{4,12}')->name('short')->middleware('throttle:120,1,short|');

// دکمه پست کانال ربات: شمارش کلیک و نشانه ۷ روزه برای سفارش، بعد صفحه کالا
Route::get('/b/{code}', function (string $code) {
    $post = \App\Models\BotPost::query()->with('product')->find((int) base_convert($code, 36, 10));
    abort_unless($post, 404);
    $pf = \App\Models\BotProfile::query()->find($post->profile_id);
    abort_unless($pf, 404);
    \App\Services\BotHub::click($post);

    return redirect(\App\Services\BotHub::target($post->product, $pf))->withCookie(cookie('bsrc', (string) $pf->id, 60 * 24 * 7));
})->where('code', '[a-z0-9]{1,10}')->name('bot.go')->middleware('throttle:120,1,botgo|');

// اپ مدیریت (وب‌اپ موبایلی همکاران) + صفحه بارگذاری فیش مشتری حضوری
Route::get('/w/{token}', [\App\Http\Controllers\ManageController::class, 'walkinShow'])->where('token', '[a-z0-9]{16,40}')->name('walkin.show');
Route::post('/w/{token}', [\App\Http\Controllers\ManageController::class, 'walkinUpload'])->where('token', '[a-z0-9]{16,40}')->middleware('throttle:12,1,walkin.up|')->name('walkin.upload');
Route::prefix('manage')->group(function () {
    $M = \App\Http\Controllers\ManageController::class;
    Route::get('/manifest.webmanifest', [$M, 'manifest'])->name('manage.manifest');
    Route::get('/sw.js', [$M, 'sw'])->name('manage.sw');
    Route::get('/login', [$M, 'loginForm'])->name('manage.login');
    Route::post('/login', [$M, 'login'])->middleware('throttle:12,1,manage.login|');
    Route::post('/logout', [$M, 'logout'])->name('manage.logout');
    Route::middleware(\App\Http\Middleware\ManageAuth::class)->group(function () use ($M) {
        Route::get('/', [$M, 'home'])->name('manage.home');
        Route::get('/chat', [$M, 'chat'])->name('manage.chat');
        Route::get('/orders', [$M, 'orders'])->name('manage.orders');
        Route::get('/orders/{order}', [$M, 'order'])->whereNumber('order')->name('manage.order');
        Route::get('/receipts', [$M, 'receipts'])->name('manage.receipts');
        Route::get('/receipts/new', [$M, 'receiptNew'])->name('manage.receipt.new');
        Route::post('/receipts/new', [$M, 'receiptStore'])->middleware('throttle:40,1,manage.rcpt|');
        Route::get('/receipts/{payment}', [$M, 'receipt'])->whereNumber('payment')->name('manage.receipt');
        Route::get('/receipts/{payment}/print', [$M, 'receiptPrint'])->whereNumber('payment')->name('manage.receipt.print');
        Route::post('/receipts/{payment}/upload', [$M, 'receiptUpload'])->whereNumber('payment')->name('manage.receipt.upload');
        Route::post('/receipts/{payment}/review', [$M, 'receiptReview'])->whereNumber('payment')->name('manage.receipt.review');
        Route::post('/receipts/{payment}/cancel', [$M, 'receiptCancel'])->whereNumber('payment')->name('manage.receipt.cancel');
        Route::get('/receipts/{payment}/img/{i}', [$M, 'receiptImg'])->whereNumber('payment')->whereNumber('i')->name('manage.receipt.img');
        Route::get('/remits', [$M, 'remits'])->name('manage.remits');
        Route::get('/remits/new', [$M, 'remitForm'])->name('manage.remit.new');
        Route::post('/remits/new', [$M, 'remitSave']);
        Route::get('/remits/{remittance}', [$M, 'remit'])->whereNumber('remittance')->name('manage.remit');
        Route::get('/remits/{remittance}/edit', [$M, 'remitForm'])->whereNumber('remittance')->name('manage.remit.edit');
        Route::post('/remits/{remittance}/edit', [$M, 'remitSave'])->whereNumber('remittance');
        Route::post('/remits/{remittance}/close', [$M, 'remitClose'])->whereNumber('remittance')->name('manage.remit.close');
        Route::get('/waybills', [$M, 'waybills'])->name('manage.waybills');
        Route::get('/all', [$M, 'all'])->name('manage.all');
        $MP = \App\Http\Controllers\ManageProductsController::class;
        Route::get('/products', [$MP, 'index'])->name('manage.products');
        Route::get('/products/{product}', [$MP, 'show'])->whereNumber('product')->name('manage.product');
        Route::post('/products/{product}', [$MP, 'save'])->whereNumber('product');
        Route::post('/products/{product}/quick', [$MP, 'quick'])->whereNumber('product')->name('manage.product.quick');
        Route::get('/products/{product}/qe', [$MP, 'qeForm'])->whereNumber('product')->name('manage.product.qe');
        Route::post('/products/{product}/qe', [$MP, 'qeSave'])->whereNumber('product');
        Route::post('/products/quick-fields', [$MP, 'qeFields'])->name('manage.product.qefields');
        Route::post('/products/{product}/publish', [$MP, 'publish'])->whereNumber('product')->name('manage.product.publish');
        Route::post('/products/{product}/image', [$MP, 'image'])->whereNumber('product')->name('manage.product.image');
        Route::post('/waybills/{order}', [$M, 'waybillSave'])->whereNumber('order')->name('manage.waybill.save');
    });
});

Route::prefix('factory')->group(function () {
    $F = \App\Http\Controllers\FactoryController::class;
    Route::get('/manifest.webmanifest', [$F, 'manifest'])->name('factory.manifest');
    Route::get('/sw.js', [$F, 'sw'])->name('factory.sw');
    Route::get('/login', [$F, 'loginForm'])->name('factory.login');
    Route::post('/login', [$F, 'login'])->middleware('throttle:30,1,fac.login|');
    Route::get('/go/{factory}', [$F, 'magic'])->name('factory.magic');
    Route::post('/logout', [$F, 'logout'])->name('factory.logout');
    Route::middleware(\App\Http\Middleware\FactoryAuth::class)->group(function () use ($F) {
        Route::get('/', [$F, 'home'])->name('factory.home');
        Route::post('/terms', [$F, 'terms'])->name('factory.terms')->middleware('throttle:20,1,fac.terms|');
        Route::get('/r/{remittance}', [$F, 'remittance'])->name('factory.remit');
        Route::post('/r/{remittance}/dest', [$F, 'destinations'])->name('factory.dest')->middleware('throttle:20,1,fac.dest|');
        Route::post('/p/{payment}/ok', [$F, 'confirm'])->name('factory.confirm')->middleware('throttle:120,1,fac.ok|');
        Route::post('/p/ok', [$F, 'confirmMany'])->name('factory.confirm.many')->middleware('throttle:30,1,fac.okm|');
        Route::post('/p/{payment}/undo', [$F, 'undo'])->name('factory.undo')->middleware('throttle:30,1,fac.undo|');
        Route::get('/p/{payment}/img', [$F, 'receipt'])->name('factory.receipt');
        Route::get('/accounts', [$F, 'accounts'])->name('factory.accounts');
        Route::post('/accounts/{account}/delete', [$F, 'deleteAccount'])->name('factory.account.delete');
        $FC = \App\Http\Controllers\FactoryChatController::class;
        Route::get('/chat', [$FC, 'page'])->name('factory.chat');
        Route::get('/chat/s', [$FC, 'show'])->name('factory.chat.state');
        Route::post('/chat/s', [$FC, 'send'])->middleware('throttle:40,1,fchat.send|');
        Route::post('/chat/act', [$FC, 'act'])->name('factory.chat.act')->middleware('throttle:30,1,fchat.act|');
        Route::post('/chat/up', [$FC, 'up'])->name('factory.chat.up')->middleware('throttle:200,1,fchat.up|');
    });
});

// اپ بارکدزن فروش حضوری (ورود با همان ورود کارتابل انبار)
Route::prefix('walkin')->group(function () {
    Route::get('/login', [\App\Http\Controllers\WalkinController::class, 'loginForm'])->name('walkin.login');
    Route::post('/login', [\App\Http\Controllers\WalkinController::class, 'login'])->middleware('throttle:12,1,walkin.login|');
    Route::post('/logout', [\App\Http\Controllers\WalkinController::class, 'logout'])->name('walkin.logout');
    Route::get('/manifest.webmanifest', [\App\Http\Controllers\WalkinController::class, 'manifest'])->name('walkin.manifest');
});
Route::prefix('walkin')->middleware([\App\Http\Middleware\KeeperAuth::class])->group(function () {
    Route::get('/', [\App\Http\Controllers\WalkinController::class, 'app'])->name('walkin');
    Route::get('/api/list', [\App\Http\Controllers\WalkinController::class, 'list']);
    Route::get('/api/index', [\App\Http\Controllers\WalkinController::class, 'index']);
    Route::get('/api/lookup', [\App\Http\Controllers\WalkinController::class, 'lookup'])->middleware('throttle:120,1,wk.lk|');
    Route::get('/api/search', [\App\Http\Controllers\WalkinController::class, 'search'])->middleware('throttle:120,1,wk.s|');
    Route::post('/api/start', [\App\Http\Controllers\WalkinController::class, 'start'])->middleware('throttle:60,1,wk.n|');
    Route::get('/api/{sale}', [\App\Http\Controllers\WalkinController::class, 'show'])->whereNumber('sale');
    Route::post('/api/{sale}', [\App\Http\Controllers\WalkinController::class, 'act'])->whereNumber('sale')->middleware('throttle:600,1,wk.a|');
});

Route::prefix('keeper')->group(function () {
    Route::get('/manifest.webmanifest', [KeeperController::class, 'manifest'])->name('keeper.manifest');
    Route::get('/login', [KeeperController::class, 'loginForm'])->name('keeper.login');
    Route::post('/login', [KeeperController::class, 'login'])->middleware('throttle:120,1,r28|');
    Route::post('/logout', [KeeperController::class, 'logout'])->name('keeper.logout');
    Route::middleware([\App\Http\Middleware\KeeperAuth::class, \App\Http\Middleware\CancelledTask::class])->group(function () {
        Route::get('/', [KeeperController::class, 'index'])->name('keeper');
        Route::post('/task/{task}/returned', [KeeperController::class, 'returned']);
        Route::get('/api/tasks', [KeeperController::class, 'tasks'])->name('keeper.tasks');
        Route::get('/task/{task}', [KeeperController::class, 'show'])->name('keeper.task');
        Route::get('/task/{task}/state', [KeeperController::class, 'state']);
        Route::post('/task/{task}/item/{item}', [KeeperController::class, 'mark'])->middleware('throttle:240,1,r29|');
        Route::post('/task/{task}/item/{item}/move', [KeeperController::class, 'move'])->middleware('throttle:60,1,r30|');
        Route::post('/task/{task}/save', [KeeperController::class, 'save']);
        Route::post('/task/{task}/resplit', [KeeperController::class, 'resplit'])->name('keeper.resplit');
        Route::post('/task/{task}/assign', [KeeperController::class, 'assign']);
        Route::post('/auto-assign', [KeeperController::class, 'autoAssign']);
        Route::get('/check/{task}', [KeeperController::class, 'check'])->name('keeper.check');
        Route::post('/ship/{order}/loaded', [KeeperController::class, 'shipLoaded'])->name('keeper.ship.loaded');
        Route::post('/ship/{order}/waybill', [KeeperController::class, 'shipWaybill'])->name('keeper.ship.waybill');
        Route::post('/ship/{order}/fee', [KeeperController::class, 'shipFee'])->name('keeper.ship.fee');
        Route::get('/ship/{order}/waybill', [\App\Http\Controllers\AdminController::class, 'waybill'])->name('keeper.ship.waybill.show');
        Route::get('/check/{task}/state', [KeeperController::class, 'checkStateJson']);
        Route::post('/check/{task}/scan', [KeeperController::class, 'scan'])->middleware('throttle:600,1,r31|');
        Route::post('/check/{task}/item/{item}', [KeeperController::class, 'adjust'])->middleware('throttle:600,1,r32|');
        Route::post('/check/{task}/approve', [KeeperController::class, 'approve']);
        Route::post('/check/{task}/back', [KeeperController::class, 'sendBack']);
        Route::post('/task/{task}/received', [KeeperController::class, 'received']);
        Route::post('/receive', [KeeperController::class, 'receiveByNumber'])->middleware('throttle:120,1,r35|');
        Route::get('/paper/{task}', [KeeperController::class, 'paper'])->name('keeper.paper');
        Route::post('/paper/{task}/item/{item}', [KeeperController::class, 'paperMark'])->middleware('throttle:240,1,r36|');
        Route::post('/task/{task}/done', [KeeperController::class, 'done']);
    });
});

// لینک بازاریابی مشاور
Route::get('/r/{code}/{path?}', [\App\Http\Controllers\RefController::class, 'go'])->where(['code' => '[A-Za-z0-9]{2,32}', 'path' => '.*'])->name('ref');

// اپ مشاور (گفتگوی زنده روی گوشی)
Route::get('/advisor/manifest.webmanifest', [\App\Http\Controllers\AdvisorController::class, 'manifest'])->name('advisor.manifest');
Route::get('/advisor/login', [\App\Http\Controllers\AdvisorController::class, 'loginForm'])->name('advisor.login');
Route::post('/advisor/login', [\App\Http\Controllers\AdvisorController::class, 'login'])->middleware('throttle:20,1,advisor.login|');
Route::post('/advisor/logout', [\App\Http\Controllers\AdvisorController::class, 'logout'])->name('advisor.logout');
Route::get('/advisor', [\App\Http\Controllers\AdvisorController::class, 'app'])->name('advisor');
Route::middleware(['auth'])->prefix('advisor/api')->group(function () {
    Route::get('/home', [\App\Http\Controllers\AdvisorController::class, 'home'])->name('advisor.home');
    Route::get('/customers', [\App\Http\Controllers\AdvisorController::class, 'customers'])->name('advisor.customers');
    Route::get('/wallet', [\App\Http\Controllers\AdvisorController::class, 'wallet'])->name('advisor.wallet');
    Route::post('/bank', [\App\Http\Controllers\AdvisorController::class, 'bank'])->name('advisor.bank')->middleware('throttle:10,1,advisor.bank|');
    Route::get('/calls', [\App\Http\Controllers\AdvisorController::class, 'calls'])->name('advisor.calls');
    Route::get('/crm/{id}', [\App\Http\Controllers\AdvisorController::class, 'crmOne'])->whereNumber('id')->name('advisor.crm');
    Route::post('/call', [\App\Http\Controllers\AdvisorController::class, 'call'])->name('advisor.call')->middleware('throttle:120,1,advisor.call|');
});

// گفتگوی زنده — سمت بازدیدکننده (صفحه‌های کش‌شده توکن CSRF تازه ندارند؛ امنیت با شناسه بازدیدکننده + کلید گفتگو)
Route::post('/live/send', [\App\Http\Controllers\LiveController::class, 'send'])->name('live.send')->middleware('throttle:20,1,live.send|');
Route::get('/live/msgs', [\App\Http\Controllers\LiveController::class, 'messages'])->name('live.msgs')->middleware('throttle:60,1,live.msgs|');
Route::post('/live/act', [\App\Http\Controllers\LiveController::class, 'act'])->name('live.act')->middleware('throttle:30,1,live.act|');
Route::post('/live/contact', [\App\Http\Controllers\LiveController::class, 'contact'])->name('live.contact')->middleware('throttle:10,1,live.contact|');

// مدیریت (خارج از Filament)
Route::middleware(['auth', 'staff'])->prefix('admin-tools')->group(function () {
    Route::get('/live/state', [\App\Http\Controllers\LiveController::class, 'state'])->name('admin.live.state');
    Route::post('/live/send', [\App\Http\Controllers\LiveController::class, 'staffSend'])->name('admin.live.send')->middleware('throttle:120,1,live.staff|');
    Route::post('/live/close', [\App\Http\Controllers\LiveController::class, 'close'])->name('admin.live.close');
    Route::post('/live/assign', [\App\Http\Controllers\LiveController::class, 'assign'])->name('admin.live.assign');
    Route::get('/alerts', [AdminController::class, 'alerts'])->name('admin.alerts');
    Route::get('/desk', [\App\Http\Controllers\DeskController::class, 'list'])->name('admin.desk.list');
    Route::post('/desk/{task}/returned', [\App\Http\Controllers\DeskController::class, 'returned']);
    Route::get('/desk/{task}', [\App\Http\Controllers\DeskController::class, 'show'])->name('admin.desk.show');
    Route::post('/desk/{task}/scan', [\App\Http\Controllers\DeskController::class, 'scan'])->middleware('throttle:600,1,r37|')->middleware(\App\Http\Middleware\CancelledTask::class);
    Route::post('/desk/{task}/item/{item}', [\App\Http\Controllers\DeskController::class, 'set'])->middleware('throttle:600,1,r38|')->middleware(\App\Http\Middleware\CancelledTask::class);
    Route::post('/desk/{task}/item/{item}/picked', [\App\Http\Controllers\DeskController::class, 'correct'])->middleware('throttle:240,1,r42|')->middleware(\App\Http\Middleware\CancelledTask::class);
    Route::post('/desk/{task}/item/{item}/remove', [\App\Http\Controllers\DeskController::class, 'remove'])->middleware('throttle:120,1,r43|')->middleware(\App\Http\Middleware\CancelledTask::class);
    Route::post('/desk/{task}/approve', [\App\Http\Controllers\DeskController::class, 'approve'])->middleware(\App\Http\Middleware\CancelledTask::class);
    Route::post('/desk/{task}/reopen', [\App\Http\Controllers\DeskController::class, 'reopen'])->middleware('throttle:30,1,r44|')->middleware(\App\Http\Middleware\CancelledTask::class);
    Route::get('/desk/{task}/products', [\App\Http\Controllers\DeskController::class, 'products'])->middleware('throttle:120,1,r39|');
    Route::post('/desk/{task}/add', [\App\Http\Controllers\DeskController::class, 'add'])->middleware('throttle:60,1,r40|')->middleware(\App\Http\Middleware\CancelledTask::class);
    Route::post('/desk/{task}/pack', [\App\Http\Controllers\DeskController::class, 'pack'])->middleware('throttle:120,1,r41|')->middleware(\App\Http\Middleware\CancelledTask::class);
    Route::get('/desk/{task}/print', [\App\Http\Controllers\DeskController::class, 'print'])->name('admin.desk.print');
    // گپ داخلی اپراتورها ↔ حسابدار کل
    Route::get('/tchat', [\App\Http\Controllers\TeamChatController::class, 'show'])->name('admin.tchat.me');
    Route::post('/tchat', [\App\Http\Controllers\TeamChatController::class, 'send'])->middleware('throttle:120,1,tchat|');
    Route::post('/tchat-act', [\App\Http\Controllers\TeamChatController::class, 'act'])->name('admin.tchat.me.act');
    Route::post('/tchat-up', [\App\Http\Controllers\TeamChatController::class, 'up'])->name('admin.tchat.up');
    Route::get('/tchat/{user}', [\App\Http\Controllers\TeamChatController::class, 'show'])->whereNumber('user')->name('admin.tchat');
    Route::post('/tchat/{user}', [\App\Http\Controllers\TeamChatController::class, 'send'])->whereNumber('user')->middleware('throttle:120,1,tchat|');
    Route::post('/tchat/{user}/act', [\App\Http\Controllers\TeamChatController::class, 'act'])->whereNumber('user')->name('admin.tchat.act');
    Route::get('/fchat/{factory}', [\App\Http\Controllers\FactoryChatController::class, 'staffShow'])->whereNumber('factory')->name('admin.fchat');
    Route::post('/fchat/{factory}', [\App\Http\Controllers\FactoryChatController::class, 'staffSend'])->whereNumber('factory')->middleware('throttle:120,1,fchat.staff|');
    Route::post('/fchat/{factory}/act', [\App\Http\Controllers\FactoryChatController::class, 'staffAct'])->whereNumber('factory')->name('admin.fchat.act');
    Route::post('/fchat-up', [\App\Http\Controllers\FactoryChatController::class, 'staffUp'])->name('admin.fchat.up');
    Route::get('/invoice/{order}', [InvoiceController::class, 'admin'])->name('admin.invoice');
    Route::get('/holoo/{order}', [\App\Http\Controllers\HolooController::class, 'export'])->name('admin.holoo');
    Route::get('/remit/receipt/{payment}', [\App\Http\Controllers\RemitController::class, 'receipt'])->name('admin.remit.receipt');
    Route::post('/remit/receipt/{payment}/rotate', [\App\Http\Controllers\RemitController::class, 'rotate'])->name('admin.remit.rotate')->middleware('throttle:120,1,rcpt.rot|');
    // بایگانی فیش‌ها: zip فیش‌های یک ماه
    Route::get('/doc-archive/zip', function (\Illuminate\Http\Request $request) {
        abort_unless(\App\Filament\Pages\DocArchivePage::canAccess(), 403);
        $m = (string) $request->query('m');
        $path = \App\Services\DocArchive::zipMonth($m);
        abort_unless($path, 404, 'فیشی در این ماه نیست.');

        return response()->download($path, 'fish-'.$m.'.zip')->deleteFileAfterSend();
    })->middleware('throttle:20,1')->name('admin.docarchive.zip');
    Route::get('/remit/{remittance}/zip', [\App\Http\Controllers\RemitController::class, 'zip'])->name('admin.remit.zip');
    Route::get('/remit/{remittance}/print', [\App\Http\Controllers\RemitController::class, 'print'])->name('admin.remit.print');
    Route::get('/cheque/{order}/{i}', [AdminController::class, 'chequeImage'])->name('admin.cheque')->where('i', '[0-9]+');
    Route::get('/sync-archive/{source}', function (\Illuminate\Http\Request $request, \App\Models\SyncSource $source) {
        abort_unless($request->user()?->hasPerm('products') || $request->user()?->isAdmin(), 403);
        abort_unless($source->archiveInfo(), 404);

        return response()->download($source->archivePath(), 'json-'.$source->id.'-'.date('Ymd', $source->archiveInfo()['at']).'.json');
    })->name('admin.sync.archive');
    Route::get('/waybill/{order}', [AdminController::class, 'waybill'])->name('admin.waybill');
    Route::get('/backup/{file}', [AdminController::class, 'downloadBackup'])->name('admin.backup.download')->where('file', '[A-Za-z0-9_.\-]+');
    Route::get('/export/products', [AdminController::class, 'exportProducts'])->name('admin.export.products');
    Route::post('/stock-scan/start', [\App\Http\Controllers\StockScanController::class, 'start']);
    Route::post('/stock-scan/{id}/file', [\App\Http\Controllers\StockScanController::class, 'file'])->whereNumber('id');
    Route::post('/stock-scan/{id}/analyze', [\App\Http\Controllers\StockScanController::class, 'analyze'])->whereNumber('id');
    Route::post('/stock-scan/{id}/apply', [\App\Http\Controllers\StockScanController::class, 'apply'])->whereNumber('id');
    Route::post('/stock-scan/{id}/undo', [\App\Http\Controllers\StockScanController::class, 'undo'])->whereNumber('id');
    Route::get('/stock-scan/{id}/report/{list}', [\App\Http\Controllers\StockScanController::class, 'report'])->whereNumber('id')->where('list', '[a-z_]+')->name('admin.stockscan.report');
    Route::get('/chat/inbox', [\App\Http\Controllers\ChatController::class, 'inbox'])->name('admin.chat.inbox');
    Route::get('/chat/products', [\App\Http\Controllers\ChatController::class, 'products'])->name('admin.chat.products');
    Route::post('/chat/up', [\App\Http\Controllers\ChatController::class, 'staffUp'])->name('admin.chat.up');
    Route::post('/chat/{order}/fin', [\App\Http\Controllers\ChatController::class, 'staffFin'])->whereNumber('order');
    Route::get('/chat/{order}', [\App\Http\Controllers\ChatController::class, 'staffShow'])->whereNumber('order')->name('admin.chat.show');
    Route::post('/chat/{order}', [\App\Http\Controllers\ChatController::class, 'staffSend'])->whereNumber('order')->middleware('throttle:120,1,chat.staff|');
    Route::post('/chat/{order}/act', [\App\Http\Controllers\ChatController::class, 'staffAct'])->whereNumber('order');
    Route::post('/chat/{order}/pin', [\App\Http\Controllers\ChatController::class, 'staffPin'])->whereNumber('order');
    Route::get('/walkin/{sale}/holoo', [\App\Http\Controllers\WalkinController::class, 'excel'])->whereNumber('sale')->name('walkin.excel');
    Route::post('/price-import/start', [\App\Http\Controllers\PriceImportController::class, 'start']);
    Route::post('/price-import/{token}/run', [\App\Http\Controllers\PriceImportController::class, 'run'])->where('token', '[A-Za-z0-9]{20}');
    Route::post('/bulk/start', [\App\Http\Controllers\BulkUploadController::class, 'start'])->name('admin.bulk.start');
    Route::post('/bulk/{id}/file', [\App\Http\Controllers\BulkUploadController::class, 'file'])->whereNumber('id')->middleware('throttle:1200,1,bulkf|');
    Route::post('/bulk/{id}/images', [\App\Http\Controllers\BulkUploadController::class, 'images'])->whereNumber('id')->middleware('throttle:600,1,bulki|');
    Route::post('/bulk/{id}/finish', [\App\Http\Controllers\BulkUploadController::class, 'finish'])->whereNumber('id');
    Route::post('/bulk/{id}/analyze', [\App\Http\Controllers\BulkUploadController::class, 'analyze'])->whereNumber('id');
    Route::post('/bulk/{id}/create', [\App\Http\Controllers\BulkUploadController::class, 'create'])->whereNumber('id');
    Route::post('/bulk/{id}/update-images', [\App\Http\Controllers\BulkUploadController::class, 'updateImages'])->whereNumber('id');
    Route::post('/bulk/{id}/cancel', [\App\Http\Controllers\BulkUploadController::class, 'cancel'])->whereNumber('id');
    Route::get('/bulk/{id}/thumb/{name}', [\App\Http\Controllers\BulkUploadController::class, 'thumb'])->whereNumber('id')->where('name', '[^/]+');
    Route::get('/bulk/{id}/seo-excel', [\App\Http\Controllers\BulkUploadController::class, 'seoExcel'])->whereNumber('id')->name('admin.bulk.seo');
    Route::post('/bulk/{id}/seo', [\App\Http\Controllers\BulkUploadController::class, 'seo'])->whereNumber('id');
    Route::get('/bulk/{id}/report', [\App\Http\Controllers\BulkUploadController::class, 'report'])->whereNumber('id')->name('admin.bulk.report');
    Route::get('/export/catalog', [AdminController::class, 'catalog'])->name('admin.export.catalog');
    Route::get('/export/photo', [AdminController::class, 'photoReport'])->name('admin.export.photo');
    Route::get('/export/report/{key}', [AdminController::class, 'exportReport'])->name('admin.export.report')->where('key', '[a-z0-9\-]+');
});

// تصویرهای سایت قبلی (آدرس‌هایی که ربات‌ها یا گوگل از قبل دارند) — باید آخرین مسیر باشد
Route::get('/{path}', [\App\Http\Controllers\AziziFeedController::class, 'image'])->where('path', '.+\.(?i:jpe?g|png|webp|gif)')->name('legacy.image');
