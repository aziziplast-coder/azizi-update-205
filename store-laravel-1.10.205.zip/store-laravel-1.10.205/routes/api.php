<?php

use App\Http\Controllers\Api\AuthApiController;
use App\Http\Controllers\Api\CatalogApiController;
use App\Http\Controllers\Api\ShopApiController;
use Illuminate\Support\Facades\Route;

/*
 * API اپ موبایل — نسخه ۱
 * احراز هویت: Authorization: Bearer <token> ؛ سبد مهمان: X-Cart-Token
 */
Route::prefix('v1')->middleware([\App\Http\Middleware\ApiAuth::class, 'throttle:240,1,api1|'])->group(function () {
    Route::get('/config', [CatalogApiController::class, 'config']);
    Route::get('/home', [CatalogApiController::class, 'home']);
    Route::get('/categories', [CatalogApiController::class, 'categories']);
    Route::get('/products', [CatalogApiController::class, 'products']);
    Route::get('/products/{id}', [CatalogApiController::class, 'product'])->whereNumber('id');
    Route::get('/products/slug/{slug}', [CatalogApiController::class, 'productBySlug']);
    Route::post('/products/{id}/notify', [CatalogApiController::class, 'notify'])->whereNumber('id');
    Route::get('/search/suggest', [CatalogApiController::class, 'suggest']);

    Route::post('/auth/otp', [AuthApiController::class, 'sendOtp'])->middleware('throttle:40,1,api2|');
    Route::post('/auth/verify', [AuthApiController::class, 'verifyOtp'])->middleware('throttle:120,1,api3|');
    Route::post('/auth/password', [AuthApiController::class, 'password'])->middleware('throttle:120,1,api4|');

    Route::get('/cart', [ShopApiController::class, 'cart']);
    Route::post('/cart', [ShopApiController::class, 'set']);
    Route::post('/cart/clear', [ShopApiController::class, 'clear']);
    Route::post('/cart/ack-prices', [ShopApiController::class, 'ackPrices']);
    Route::post('/web-link', [ShopApiController::class, 'webLink']);
});

Route::prefix('v1')->middleware([\App\Http\Middleware\ApiAuth::class.':1', 'throttle:240,1,api5|'])->group(function () {
    Route::get('/me', [AuthApiController::class, 'me']);
    Route::post('/me', [AuthApiController::class, 'update']);
    Route::post('/auth/logout', [AuthApiController::class, 'logout']);
    Route::get('/orders', [ShopApiController::class, 'orders']);
    Route::get('/orders/{number}', [ShopApiController::class, 'order']);
    Route::post('/orders/{number}/reorder', [ShopApiController::class, 'reorder']);
    Route::post('/me/delete', [AuthApiController::class, 'destroy']);
    Route::get('/orders/{number}/waybill', [ShopApiController::class, 'waybill']);
    Route::post('/orders/{number}/receipt/{payment}', [ShopApiController::class, 'receipt'])->whereNumber('payment')->middleware('throttle:20,1,api7|');
    Route::post('/orders/{number}/cheques', [ShopApiController::class, 'chequeDocs'])->middleware('throttle:20,1,api8|');
    // گفتگوی سفارش در اپ کامل (همان منطق گفتگوی سایت)
    Route::get('/chats', [\App\Http\Controllers\ChatController::class, 'customerInboxJson']);
    Route::get('/orders/{number}/chat', [\App\Http\Controllers\ChatController::class, 'show']);
    Route::post('/orders/{number}/chat', [\App\Http\Controllers\ChatController::class, 'send'])->middleware('throttle:40,1,chat.send|');
    Route::post('/orders/{number}/chat/act', [\App\Http\Controllers\ChatController::class, 'act'])->middleware('throttle:30,1,chat.act|');
    Route::post('/orders/{number}/chat/pay', [\App\Http\Controllers\ChatController::class, 'pay'])->middleware('throttle:20,1,chat.pay|');
    Route::post('/orders/{number}/chat/cheque', [\App\Http\Controllers\ChatController::class, 'cheque'])->middleware('throttle:20,1,chat.cheque|');
    Route::post('/orders/{number}/chat/up', [\App\Http\Controllers\ChatController::class, 'up'])->middleware('throttle:200,1,chat.up|');
    // تسویه داخل اپ (سرور-محور)
    Route::get('/checkout', [\App\Http\Controllers\Api\CheckoutApiController::class, 'show']);
    Route::post('/checkout/quote', [\App\Http\Controllers\Api\CheckoutApiController::class, 'quote']);
    Route::post('/checkout/place', [\App\Http\Controllers\Api\CheckoutApiController::class, 'place'])->middleware('throttle:20,1,api6|');
});

// ربات کانال روی هاست جدا (BotHub) — با کلید اختصاصی
Route::prefix('bot/v1')->middleware('throttle:30,1,botagent|')->group(function () {
    $B = \App\Http\Controllers\Api\BotAgentController::class;
    Route::post('/hello', [$B, 'hello']);
    Route::post('/import', [$B, 'import']);
    Route::post('/sync', [$B, 'sync']);
});
Route::get('bot/v1/bimg/{b}', [\App\Http\Controllers\Api\BotAgentController::class, 'bimg'])->whereNumber('b')->name('bot.bimg')->middleware('throttle:120,1,botimg2|');
Route::get('bot/v1/img/{product}/{n}', [\App\Http\Controllers\Api\BotAgentController::class, 'img'])->whereNumber(['product', 'n'])->name('bot.img')->middleware('throttle:300,1,botimg|');

