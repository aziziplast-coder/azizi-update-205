<?php

// اگر هاست فایل .htaccess را نخواند، این فایل درخواست را به برنامه می‌رساند.
require __DIR__.'/public/index.php';
