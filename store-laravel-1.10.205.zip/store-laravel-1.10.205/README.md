# فروشگاه عمده و خرده (Laravel)

راهنمای توسعه برای برنامه‌نویس.

## فناوری‌ها
- **Laravel 12**، PHP 8.2 یا بالاتر، MySQL/MariaDB
- **Filament 3** برای پنل مدیریت (`/admin`)
- **فروشگاه:** Blade و CSS/JS ساده، بدون نیاز به build (`public/css/app.css` و `public/js/app.js`)
- **PWA:** فایل manifest و service worker در `PwaController` و `resources/views/pwa-worker.blade.php`

## ساختار
| مسیر | محتوا |
|---|---|
| `app/Models` | Product (منطق کارتنی/تکی)، Order، Category، Warehouse، User (نقش‌ها و دسترسی‌ها) |
| `app/Services` | Cart، Checkout، Sms (چند پنل)، Payment (زرین‌پال/زیبال)، Backup، Updater، HostHealth، Excel |
| `app/Filament` | منابع، صفحه‌های تنظیمات و ابزارهای پنل |
| `app/Support/Settings.php` | تنظیمات کلید/مقدار با مقادیر پیش‌فرض |
| `resources/views/store` | قالب فروشگاه |
| `resources/views/invoice.blade.php` | فاکتور A4 و حواله انبار |

## قواعد مهم
- قیمت‌ها به **تومان** و برای **هر عدد** ذخیره می‌شوند.
- خرید کارتنی، مضربی از `per_carton` است. خرید تکی کمتر از یک کارتن است و قیمت و موجودی جداگانه دارد.
- دسترسی کارکنان با `User::hasPerm()` کنترل می‌شود.
- تغییر ساختار دیتابیس فقط با migration جدید انجام شود. به‌روزرسانی پنل migrationها را خودکار اجرا می‌کند.
- نسخه برنامه در `config/store.php` است. برای هر بسته به‌روزرسانی آن را بالا ببرید.

## توسعه محلی
```
cp .env.example .env   # DB_CONNECTION=sqlite یا mysql
php artisan key:generate
php artisan migrate
php artisan serve
```
وابستگی‌ها داخل پوشه `vendor` آمده‌اند. با `composer update` جدیدترین نسخه‌های سازگار نصب می‌شوند.

## بسته به‌روزرسانی
کل پروژه را بدون `.env`، `storage` و `public/uploads` zip کنید و از «پنل ← ابزار سایت ← به‌روزرسانی» نصب کنید.
