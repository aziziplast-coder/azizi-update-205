<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->trustProxies(at: '*');
        $middleware->append(\App\Http\Middleware\SecurityHeaders::class);
        $middleware->web(prepend: [\App\Http\Middleware\ForceHttps::class, \App\Http\Middleware\DomainRedirect::class, \App\Http\Middleware\EnsureInstalled::class]);
        $middleware->web(append: [\App\Http\Middleware\PseudoCron::class, \App\Http\Middleware\AdvisorRef::class, \App\Http\Middleware\GuestPageCache::class]);
        $middleware->alias([
            'store.open' => \App\Http\Middleware\StoreOpen::class,
            'staff' => \App\Http\Middleware\Staff::class,
        ]);
        $middleware->validateCsrfTokens(except: ['payment/*/callback', 'live/send', 'live/contact', 'live/act']);
        $middleware->encryptCookies(except: ['_str', '_stv', '_sts']); // آمار بازدید (خوانده‌شدن در مرورگر)
        $middleware->redirectGuestsTo(fn () => route('login'));
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        // لینک قدیمی (مقاله/صفحه سایت قبلی) که این‌جا پیدا نشد ← ریدایرکت ۳۰۱ از «ریدایرکت‌ها»
        $exceptions->render(function (\Symfony\Component\HttpKernel\Exception\NotFoundHttpException $e, \Illuminate\Http\Request $request) {
            if (in_array($request->method(), ['GET', 'HEAD'], true) && ! $request->is('api/*', 'admin/*', 'livewire/*', 'uploads/*') && ! $request->expectsJson()) {
                if ($to = \App\Support\Redirects::find($request)) {
                    return redirect()->away($to, 301);
                }
            }

            return null;
        });
    })->create();
