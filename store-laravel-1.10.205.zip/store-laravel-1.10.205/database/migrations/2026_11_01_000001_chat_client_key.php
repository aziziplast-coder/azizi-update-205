<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** شناسه یکتای پیام از سمت گوشی: ارسال دوباره در اینترنت ضعیف پیام تکراری نمی‌سازد */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('chat_messages') && ! Schema::hasColumn('chat_messages', 'client_key')) {
            Schema::table('chat_messages', function (Blueprint $t) {
                $t->string('client_key', 40)->nullable()->after('kind');
                $t->index(['thread_id', 'client_key']);
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('chat_messages', 'client_key')) {
            Schema::table('chat_messages', function (Blueprint $t) {
                $t->dropIndex(['thread_id', 'client_key']);
                $t->dropColumn('client_key');
            });
        }
    }
};
