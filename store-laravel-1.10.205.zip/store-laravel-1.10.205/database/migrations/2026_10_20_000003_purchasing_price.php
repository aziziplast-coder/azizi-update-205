<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** خرید و تأمین: «مبلغ آخرین خرید» از اکسل کالاها و جمع مبلغ سفارش خرید (فقط برای اپراتور) */
return new class extends Migration
{
    /** اجرای امن: اگر جدول/ستون همزمان یا قبلاً ساخته شده باشد، خطا نمی‌دهد */
    private function safe(callable $f): void
    {
        try {
            $f();
        } catch (\Illuminate\Database\QueryException $e) {
            if (! preg_match('/already exists|Duplicate column|Duplicate key name|1050|1060|1061/i', $e->getMessage())) {
                throw $e;
            }
        }
    }

    public function up(): void
    {
        if (Schema::hasTable('supply_items') && ! Schema::hasColumn('supply_items', 'last_price')) {
            $this->safe(fn () => Schema::table('supply_items', fn (Blueprint $t) => $t->unsignedBigInteger('last_price')->nullable()));
        }
        if (Schema::hasTable('purchase_orders') && ! Schema::hasColumn('purchase_orders', 'total_amount')) {
            $this->safe(fn () => Schema::table('purchase_orders', fn (Blueprint $t) => $t->unsignedBigInteger('total_amount')->default(0)));
        }
    }

    public function down(): void
    {
    }
};
