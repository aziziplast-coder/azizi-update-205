<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/* موجودی بی‌نهایت: هر کالای موجود که عدد مثبت موجودی داشت (و خرید را به ۱ کارتن و… محدود می‌کرد) ← بدون محدودیت */
return new class extends Migration
{
    public function up(): void
    {
        $v = DB::table('settings')->where('key', 'stock_unlimited')->value('value');
        if ($v !== null && in_array(trim((string) $v, '"'), ['0', 'false', ''], true)) {
            return; // مدیر عمداً خاموشش کرده
        }
        DB::table('products')->where('stock', '>', 0)->update(['stock' => null]);
        DB::table('products')->where('retail_stock', '>', 0)->update(['retail_stock' => null]);
        try {
            \App\Http\Middleware\GuestPageCache::bump();
            \Illuminate\Support\Facades\Cache::forget('home.blocks');
            \Illuminate\Support\Facades\Cache::forget('api.home');
        } catch (\Throwable) {
        }
    }

    public function down(): void {}
};
