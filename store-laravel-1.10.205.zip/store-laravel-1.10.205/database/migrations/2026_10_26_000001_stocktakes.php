<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** انبارگردانی: مقایسه موجودی هلو با اسکن بارکد انبار (فقط نتیجه نگه داشته می‌شود؛ فایل‌ها پاک می‌شوند) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('stocktakes')) {
            Schema::create('stocktakes', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('created_by')->nullable();
                $t->text('settings')->nullable();
                $t->text('stats')->nullable();
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('stocktake_items')) {
            Schema::create('stocktake_items', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('stocktake_id')->index();
                $t->string('kind', 10)->default('missing')->index(); // missing = در هلو هست، در انبار نیست | extra = در انبار هست، در هلو نیست
                $t->string('code', 64)->index();
                $t->string('barcode', 64)->nullable();
                $t->string('name', 250)->nullable();
                $t->unsignedBigInteger('product_id')->nullable();
                $t->bigInteger('holoo_qty')->default(0);
                $t->bigInteger('branch_qty')->default(0);
                $t->bigInteger('net_qty')->default(0);
                $t->unsignedBigInteger('price')->default(0);
                $t->unsignedBigInteger('value')->default(0);
                $t->unsignedInteger('streak')->default(1);
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('stocktake_items');
        Schema::dropIfExists('stocktakes');
    }
};
