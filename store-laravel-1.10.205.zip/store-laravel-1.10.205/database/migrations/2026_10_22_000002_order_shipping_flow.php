<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** کرایه حمل تا باربری، تخفیف صدور مانده، سهم نقدی، رسیدن چک‌ها، بارگیری و بیجک */
return new class extends Migration
{
    public function up(): void
    {
        $cols = [
            'freight_fee' => fn (Blueprint $t) => $t->unsignedBigInteger('freight_fee')->nullable(),
            'extra_discount' => fn (Blueprint $t) => $t->unsignedBigInteger('extra_discount')->default(0),
            'cash_amount' => fn (Blueprint $t) => $t->unsignedBigInteger('cash_amount')->nullable(),
            'cheques_received_at' => fn (Blueprint $t) => $t->timestamp('cheques_received_at')->nullable(),
            'loaded_at' => fn (Blueprint $t) => $t->timestamp('loaded_at')->nullable(),
            'loaded_by' => fn (Blueprint $t) => $t->unsignedBigInteger('loaded_by')->nullable(),
            'waybill_path' => fn (Blueprint $t) => $t->string('waybill_path', 190)->nullable(),
            'waybill_at' => fn (Blueprint $t) => $t->timestamp('waybill_at')->nullable(),
            'waybill_nag_at' => fn (Blueprint $t) => $t->timestamp('waybill_nag_at')->nullable(),
        ];
        foreach ($cols as $name => $def) {
            if (! Schema::hasColumn('orders', $name)) {
                try {
                    Schema::table('orders', $def);
                } catch (\Illuminate\Database\QueryException $e) {
                    if (! preg_match('/Duplicate column|1060|already exists/i', $e->getMessage())) {
                        throw $e;
                    }
                }
            }
        }
    }

    public function down(): void
    {
        Schema::table('orders', fn (Blueprint $t) => $t->dropColumn(['freight_fee', 'extra_discount', 'cash_amount', 'cheques_received_at', 'loaded_at', 'loaded_by', 'waybill_path', 'waybill_at', 'waybill_nag_at']));
    }
};
