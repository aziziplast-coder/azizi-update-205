<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** بررسی بار سرپرست: تعداد عددیِ تأییدشده به‌صورت دستی (بدون برچسب بارکد) کنار تعداد اسکن‌شده */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('order_items', 'manual_units')) {
            try {
                Schema::table('order_items', fn (Blueprint $t) => $t->unsignedInteger('manual_units')->nullable());
            } catch (\Illuminate\Database\QueryException $e) {
                if (! preg_match('/Duplicate column|1060|already exists/i', $e->getMessage())) {
                    throw $e;
                }
            }
        }
    }

    public function down(): void
    {
        Schema::table('order_items', fn (Blueprint $t) => $t->dropColumn('manual_units'));
    }
};
