<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** چند تصویر فیش برای هر پرداخت (واریزهای خرد) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('remit_payments', 'receipt_files')) {
            try {
                Schema::table('remit_payments', fn (Blueprint $t) => $t->text('receipt_files')->nullable());
            } catch (\Illuminate\Database\QueryException $e) {
                if (! preg_match('/Duplicate column|1060|already exists/i', $e->getMessage())) {
                    throw $e;
                }
            }
        }
    }

    public function down(): void
    {
        Schema::table('remit_payments', fn (Blueprint $t) => $t->dropColumn('receipt_files'));
    }
};
