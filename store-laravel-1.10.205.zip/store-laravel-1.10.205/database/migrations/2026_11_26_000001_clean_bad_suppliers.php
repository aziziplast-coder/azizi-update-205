<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * پاک‌سازی «تأمین‌کننده»های ساختگی: گزارش فروش هلو با سرستون «تعداد» اشتباهاً فهرست تأمین‌کننده خوانده شده بود
 * و ستون تعداد (عدد) به‌جای نام کارخانه ثبت شد. فقط ردیف‌هایی که نامشان عدد (یا «تعداد») است، در فایل فعلی نیستند
 * و هیچ کالا یا سفارش خریدی به آن‌ها وصل نیست حذف می‌شوند.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('suppliers')) {
            return;
        }
        $used = DB::table('supply_items')->distinct()->pluck('supplier_id')->all();
        if (Schema::hasTable('purchase_orders')) {
            $used = array_merge($used, DB::table('purchase_orders')->whereNotNull('supplier_id')->distinct()->pluck('supplier_id')->all());
        }
        $used = array_flip(array_map('intval', $used));
        $ids = [];
        foreach (DB::table('suppliers')->where('in_file', false)->where('items_count', 0)->select('id', 'name')->cursor() as $s) {
            $n = trim(strtr((string) $s->name, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9', ',' => '', '٬' => '']));
            if (! isset($used[(int) $s->id]) && (is_numeric($n) || $n === 'تعداد')) {
                $ids[] = (int) $s->id;
            }
        }
        foreach (array_chunk($ids, 500) as $chunk) {
            DB::table('suppliers')->whereIn('id', $chunk)->delete();
        }
    }

    public function down(): void {}
};
