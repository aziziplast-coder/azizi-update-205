<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** تأیید «نشستن در حساب» به‌جای کارخانه‌دار توسط حسابدار کل (از کارتابل حسابداری) */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('remit_payments') && ! Schema::hasColumn('remit_payments', 'factory_ok_by')) {
            Schema::table('remit_payments', function (Blueprint $t) {
                $t->unsignedBigInteger('factory_ok_by')->nullable();
            });
        }
    }

    public function down(): void {}
};
