<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/* مبلغ اولیه سفارش (همان که مشتری در سایت ثبت کرد) — پیش از تغییرات انبار، جایگزینی و افزوده‌ها */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('orders', 'placed_total')) {
            Schema::table('orders', function (Blueprint $t) {
                $t->unsignedBigInteger('placed_total')->nullable()->after('total');
            });
        }
        // سفارش‌های قبلی: فقط وقتی مطمئن هستیم
        //  ۱) مشتری سفارش را ویرایش کرده ← مبلغ تازه همان ویرایش (پیش از جمع‌آوری انبار)
        //  ۲) اقلام از طرف انبار/همکاران عوض نشده ← مبلغ فعلی بدون کرایه حمل و تخفیف صدور مانده
        //  ۳) بقیه (کسری، حذف، جایگزین در گذشته) ← نامعلوم؛ نمایش داده نمی‌شود
        $hasFreight = Schema::hasColumn('orders', 'freight_fee');
        $hasExtra = Schema::hasColumn('orders', 'extra_discount');
        DB::table('orders')->whereNull('placed_total')->orderBy('id')->select(array_merge(['id', 'user_id', 'total'], $hasFreight ? ['freight_fee'] : [], $hasExtra ? ['extra_discount'] : []))
            ->chunk(300, function ($orders) {
                $ids = $orders->pluck('id')->all();
                $extra = DB::table('order_items')->whereIn('order_id', $ids)
                    ->where(fn ($q) => $q->whereNotNull('replaces_item_id')->orWhere('appendix', true)->orWhere(fn ($w) => $w->whereNotNull('ordered_units')->whereColumn('ordered_units', '!=', 'units')))
                    ->distinct()->pluck('order_id')->flip();
                $ev = DB::table('order_events')->whereIn('order_id', $ids)->orderBy('id')->get(['order_id', 'user_id', 'message'])->groupBy('order_id');
                $num = fn ($t) => (int) str_replace(['٬', ',', ' '], '', strtr($t, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9']));
                foreach ($orders as $o) {
                    $evs = $ev[$o->id] ?? collect();
                    $val = null;
                    // ۱) آخرین ویرایش مشتری: «مبلغ X ← Y تومان»
                    foreach ($evs as $e) {
                        if (str_contains((string) $e->message, 'مشتری اقلام سفارش را تغییر داد') && preg_match('/مبلغ\s*([0-9۰-۹٬,]+)\s*←\s*([0-9۰-۹٬,]+)\s*تومان/u', (string) $e->message, $m)) {
                            $val = $num($m[2]);
                        }
                    }
                    // اقلام جاافتاده در ویرایش مشتری که همکاران برگرداندند ← جزو سفارش خود مشتری است
                    if ($val !== null) {
                        foreach ($evs as $e) {
                            if (str_contains((string) $e->message, 'جاافتاده به سفارش برگشت') && preg_match('/مبلغ سفارش:\s*([0-9۰-۹٬,]+)\s*←\s*([0-9۰-۹٬,]+)/u', (string) $e->message, $m)) {
                                $val += $num($m[2]) - $num($m[1]);
                            }
                        }
                    }
                    if ($val === null) {
                        $itemChange = isset($extra[$o->id]) || $evs->contains(fn ($e) => (int) $e->user_id !== (int) $o->user_id && (
                            preg_match('/حذف شد|جایگزین|افزوده|اضافه شد|کسری|ناموجود|ویرایش/u', (string) $e->message)
                            || (str_contains((string) $e->message, 'مبلغ سفارش') && ! str_contains((string) $e->message, 'کرایه حمل') && ! str_contains((string) $e->message, 'جمع‌آوری انبار تمام شد'))));
                        if (! $itemChange) {
                            $val = max(0, (int) $o->total - (int) ($o->freight_fee ?? 0) + (int) ($o->extra_discount ?? 0));
                        }
                    }
                    if ($val !== null && $val > 0) {
                        DB::table('orders')->where('id', $o->id)->update(['placed_total' => $val]);
                    }
                }
            });
    }

    public function down(): void
    {
        if (Schema::hasColumn('orders', 'placed_total')) {
            Schema::table('orders', fn (Blueprint $t) => $t->dropColumn('placed_total'));
        }
    }
};
