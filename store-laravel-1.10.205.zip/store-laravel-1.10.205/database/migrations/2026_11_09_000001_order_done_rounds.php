<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** مراحل جمع‌آوری که نهایی شده‌اند (برای ادغام بررسی رومیزی کالاهای افزوده در بررسی باز) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('orders', 'done_rounds')) {
            Schema::table('orders', fn (Blueprint $t) => $t->string('done_rounds', 60)->nullable());
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('orders', 'done_rounds')) {
            Schema::table('orders', fn (Blueprint $t) => $t->dropColumn('done_rounds'));
        }
    }
};
