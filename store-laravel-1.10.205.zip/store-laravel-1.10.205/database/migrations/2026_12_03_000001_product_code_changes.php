<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/* تغییر کد کالا در هلو: کدهای قبلی هر کالا + تاریخچه/پیشنهادهای تغییر کد */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('products', 'old_codes')) {
            Schema::table('products', function (Blueprint $t) {
                $t->string('old_codes', 255)->nullable()->after('sku'); // «|43307|12345|»
            });
        }
        if (! Schema::hasTable('product_code_changes')) {
            Schema::create('product_code_changes', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('product_id')->nullable()->index();
                $t->string('old_code', 64)->nullable();
                $t->string('new_code', 64)->index();
                $t->string('file_name', 191)->nullable();   // نام کالا در فایل هلو
                $t->bigInteger('file_price')->nullable();
                $t->string('status', 12)->default('applied')->index(); // applied, pending, rejected, undone
                $t->string('source', 12)->default('auto');  // auto (اکسل)، manual (ویرایش دستی)، assign (انتخاب از فهرست)
                $t->unsignedTinyInteger('score')->default(100);
                $t->string('reason', 191)->nullable();
                $t->unsignedBigInteger('user_id')->nullable();
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('product_code_changes');
        if (Schema::hasColumn('products', 'old_codes')) {
            Schema::table('products', fn (Blueprint $t) => $t->dropColumn('old_codes'));
        }
    }
};
