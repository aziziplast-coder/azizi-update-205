<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * اپ کارخانه‌داران: کارخانه‌دار حواله‌هایش را می‌بیند، حساب مقصد را تعیین می‌کند
 * (حساب خودش یا انتقال به شخص دیگر، یا تقسیم) و نشستن هر فیش در حسابش را تأیید می‌کند.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('factories')) {
            Schema::create('factories', function (Blueprint $t) {
                $t->id();
                $t->string('name', 150);
                $t->string('mobile', 20)->unique();
                $t->string('company', 150)->nullable();
                $t->text('note')->nullable();
                $t->boolean('active')->default(true);
                $t->timestamp('last_seen_at')->nullable();
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('factory_accounts')) {
            Schema::create('factory_accounts', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('factory_id')->index();
                $t->string('kind', 10)->default('own'); // own = حساب خود کارخانه‌دار | other = شخص دیگر
                $t->string('holder_name', 120);
                $t->string('bank_name', 60)->nullable();
                $t->string('card_number', 19)->nullable();
                $t->string('sheba', 34)->nullable();
                $t->string('account_number', 40)->nullable();
                $t->string('mobile', 20)->nullable();
                $t->string('national_id', 12)->nullable();
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('remit_destinations')) {
            Schema::create('remit_destinations', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('remittance_id')->index();
                $t->unsignedBigInteger('factory_id')->nullable()->index();
                $t->string('kind', 10)->default('own');
                $t->unsignedBigInteger('amount');
                $t->string('holder_name', 120);
                $t->string('bank_name', 60)->nullable();
                $t->string('card_number', 19)->nullable();
                $t->string('sheba', 34)->nullable();
                $t->string('account_number', 40)->nullable();
                $t->string('mobile', 20)->nullable();
                $t->string('national_id', 12)->nullable();
                $t->string('note', 300)->nullable();
                $t->string('status', 12)->default('submitted')->index(); // submitted | approved | rejected
                $t->string('reason', 300)->nullable();
                $t->unsignedBigInteger('reviewed_by')->nullable();
                $t->timestamp('reviewed_at')->nullable();
                $t->unsignedBigInteger('child_remittance_id')->nullable();
                $t->timestamps();
            });
        }
        $this->add('remittances', 'factory_id', fn (Blueprint $t) => $t->unsignedBigInteger('factory_id')->nullable()->index());
        // null = حساب را حسابداری تعیین کرده | awaiting = منتظر تصمیم کارخانه‌دار | review = منتظر تأیید حسابداری | approved | rejected
        $this->add('remittances', 'dest_status', fn (Blueprint $t) => $t->string('dest_status', 12)->nullable()->index());
        $this->add('remittances', 'dest_reason', fn (Blueprint $t) => $t->string('dest_reason', 300)->nullable());
        $this->add('remittances', 'dest_at', fn (Blueprint $t) => $t->timestamp('dest_at')->nullable());
        $this->add('remittances', 'account_number', fn (Blueprint $t) => $t->string('account_number', 40)->nullable());
        $this->add('remit_payments', 'factory_confirmed_at', fn (Blueprint $t) => $t->timestamp('factory_confirmed_at')->nullable()->index());
        $this->add('remit_payments', 'factory_seen_at', fn (Blueprint $t) => $t->timestamp('factory_seen_at')->nullable());

        // کارخانه‌دارهای حواله‌های فعلی (از روی موبایل ثبت‌شده) ساخته و وصل می‌شوند
        try {
            $rows = DB::table('remittances')->whereNotNull('factory_phone')->where('factory_phone', '!=', '')->whereNull('factory_id')->get(['id', 'title', 'factory_phone', 'holder_name']);
            foreach ($rows as $r) {
                $m = preg_replace('/\D/', '', strtr((string) $r->factory_phone, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9']));
                if (strlen($m) === 10 && $m[0] === '9') {
                    $m = '0'.$m;
                } elseif (str_starts_with($m, '98') && strlen($m) === 12) {
                    $m = '0'.substr($m, 2);
                }
                if (! preg_match('/^09\d{9}$/', $m)) {
                    continue;
                }
                $fid = DB::table('factories')->where('mobile', $m)->value('id');
                if (! $fid) {
                    $fid = DB::table('factories')->insertGetId(['name' => mb_substr((string) ($r->holder_name ?: $r->title), 0, 150), 'mobile' => $m, 'active' => true, 'created_at' => now(), 'updated_at' => now()]);
                }
                DB::table('remittances')->where('id', $r->id)->update(['factory_id' => $fid]);
            }
        } catch (\Throwable $e) {
            report($e);
        }
    }

    protected function add(string $table, string $col, \Closure $def): void
    {
        if (Schema::hasColumn($table, $col)) {
            return;
        }
        try {
            Schema::table($table, $def);
        } catch (\Illuminate\Database\QueryException $e) {
            if (! preg_match('/Duplicate column|1060|already exists/i', $e->getMessage())) {
                throw $e;
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('remit_destinations');
        Schema::dropIfExists('factory_accounts');
        Schema::dropIfExists('factories');
    }
};
