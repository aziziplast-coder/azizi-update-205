<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * آپلود گروهی محصولات (RAR/ZIP تصاویر + اکسل) با تأیید اپراتور،
 * و «آخرین تغییر قیمت/موجودی» کالا برای تعیین تکلیف ناموجودهای قدیمی.
 */
return new class extends Migration
{
    protected function add(string $table, string $col, callable $def): void
    {
        if (! Schema::hasTable($table) || Schema::hasColumn($table, $col)) {
            return;
        }
        try {
            Schema::table($table, fn (Blueprint $t) => $def($t));
        } catch (\Illuminate\Database\QueryException $e) {
            if (! preg_match('/Duplicate column|1060|already exists/i', $e->getMessage())) {
                throw $e;
            }
        }
    }

    public function up(): void
    {
        if (! Schema::hasTable('product_imports')) {
            Schema::create('product_imports', function (Blueprint $t) {
                $t->id();
                $t->string('title', 190)->nullable();
                $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
                $t->string('status', 20)->default('uploading'); // uploading | analyzed | creating | done
                $t->json('mapping')->nullable();
                $t->json('options')->nullable();
                $t->json('stats')->nullable();
                $t->unsignedInteger('images')->default(0);
                $t->unsignedInteger('created_count')->default(0);
                $t->timestamps();
            });
        }
        $this->add('products', 'import_id', fn (Blueprint $t) => $t->unsignedBigInteger('import_id')->nullable()->index());
        $this->add('products', 'review', fn (Blueprint $t) => $t->string('review', 20)->nullable()->index()); // pending = منتظر تأیید
        $this->add('products', 'changed_at', fn (Blueprint $t) => $t->timestamp('changed_at')->nullable()->index());

        try {
            DB::table('products')->whereNull('changed_at')->update(['changed_at' => DB::raw('COALESCE(updated_at, created_at)')]);
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void {}
};
