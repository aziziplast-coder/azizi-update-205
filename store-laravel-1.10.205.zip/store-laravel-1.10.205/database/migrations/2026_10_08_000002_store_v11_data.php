<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/** پر کردن کلید جستجو و زمان آخرین تغییر وضعیت سفارش‌های موجود */
return new class extends Migration
{
    public function up(): void
    {
        try {
            \App\Support\Search::reindex();
        } catch (\Throwable $e) {
            report($e);
        }
        DB::table('orders')->whereNull('status_changed_at')->update(['status_changed_at' => DB::raw('updated_at')]);
    }

    public function down(): void {}
};
