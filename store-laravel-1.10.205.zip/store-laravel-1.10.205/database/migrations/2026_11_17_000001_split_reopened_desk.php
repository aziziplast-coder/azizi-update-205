<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/**
 * ترمیم: «انتقال کالا» به انباردار دیگر، حواله تمام‌شده و بررسی‌شده او را دوباره باز می‌کرد و اقلام قبلاً بررسی‌شده
 * (و در هلو ثبت‌شده) همراه کالای منتقل‌شده دوباره به بررسی رومیزی می‌آمد (مثلاً سفارش ۱۱۴۶).
 * اقلامی که پیش از تأیید قبلی همان حواله جمع شده بودند به یک حواله «تمام‌شده» جدا برمی‌گردند؛
 * در بررسی باز فقط کالاهای تازه می‌ماند.
 */
return new class extends Migration
{
    public function up(): void
    {
        try {
            $tasks = DB::table('pick_tasks')->whereIn('stage', ['desk', 'review'])->where('status', '!=', 'done')->whereNotNull('checked_at')->get();
            foreach ($tasks as $t) {
                $old = DB::table('order_items')->where('pick_task_id', $t->id)->whereNotNull('picked_at')->where('picked_at', '<=', $t->checked_at)->pluck('id');
                $all = DB::table('order_items')->where('pick_task_id', $t->id)->count();
                if ($old->isEmpty() || $old->count() >= $all) {
                    continue; // همه قدیمی یا همه تازه: چیزی برای جدا کردن نیست
                }
                $row = (array) $t;
                unset($row['id']);
                $row = array_merge($row, ['stage' => null, 'status' => 'done', 'done_at' => $t->checked_at, 'done_by' => $t->checked_by, 'created_at' => $t->created_at, 'updated_at' => now()]);
                $doneId = DB::table('pick_tasks')->insertGetId($row);
                DB::table('order_items')->whereIn('id', $old)->update(['pick_task_id' => $doneId]);
                DB::table('pick_tasks')->where('id', $t->id)->update(['checked_at' => null, 'checked_by' => null]);
                DB::table('order_events')->insert([
                    'order_id' => $t->order_id, 'user_id' => null,
                    'message' => 'ترمیم خودکار: '.fa($old->count()).' قلمِ قبلاً بررسی‌شده (و ثبت‌شده در هلو) از بررسی رومیزی تازه جدا شد؛ در بررسی فقط '.fa($all - $old->count()).' کالای منتقل‌شده/تازه می‌ماند.',
                    'created_at' => now(),
                ]);
            }
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void
    {
    }
};
