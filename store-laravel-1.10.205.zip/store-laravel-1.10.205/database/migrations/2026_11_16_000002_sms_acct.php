<?php

use Illuminate\Database\Migrations\Migration;

/**
 * پیامک‌های پرداخت: حساب مانده ممکن است همان حساب بیعانه باشد؛ پیامک «مانده حساب صادر شد» حالا می‌گوید
 * «به همان حساب بیعانه» یا «به حساب جدید …» ({acct}). فقط متن‌هایی که از نسخه ۱.۱۰.۱۳۱ دست نخورده‌اند عوض می‌شوند.
 */
return new class extends Migration
{
    public function up(): void
    {
        try {
            $saved = (array) setting('sms_events', []);
            if (! $saved) {
                return;
            }
            $old = [
            'customer_processing' => '{name} عزیز، سفارش {order} در حال جمع‌آوری از انبار است. پس از جمع شدن بار، مانده حساب و شماره حساب جدید در تب گفتگوی سفارش برایتان صادر و پیامک می‌شود؛ تا آن زمان واریزی انجام ندهید. {shop}',
            'customer_settling' => '{name} عزیز، بار سفارش {order} در انبار جمع شد. لطفاً هنوز واریز نکنید؛ مانده حساب و شماره حساب جدید (غیر از حساب بیعانه) به‌زودی در تب گفتگوی سفارش برایتان صادر و پیامک می‌شود. {shop}',
            'remit_deposit' => '{name} عزیز، بیعانه سفارش {order}: {amount} تومان. شماره حساب این مرحله در سایت، تب گفتگوی سفارش است؛ فقط به همان حساب واریز کنید و فیش را همان‌جا بفرستید. {shop}',
            'remit_settle' => '{name} عزیز، مانده حساب سفارش {order}: {amount} تومان. شماره حساب جدید این مرحله (غیر از حساب بیعانه) در سایت، تب گفتگوی سفارش است؛ فقط به همان حساب واریز کنید و فیش را همان‌جا بفرستید. {shop}',
            ];
            $def = \App\Services\Sms::events();
            foreach ($old as $k => $text) {
                if (isset($saved[$k], $def[$k]) && trim((string) ($saved[$k]['text'] ?? '')) === $text) {
                    $saved[$k]['text'] = $def[$k]['text'];
                }
                if (isset($saved[$k]) && str_starts_with($k, 'remit_') && ! str_contains((string) ($saved[$k]['vars'] ?? ''), 'acct=')) {
                    $saved[$k]['vars'] = rtrim((string) ($saved[$k]['vars'] ?? ''))."\nacct={acct}";
                }
            }
            \App\Support\Settings::set(['sms_events' => $saved]);
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void
    {
    }
};
