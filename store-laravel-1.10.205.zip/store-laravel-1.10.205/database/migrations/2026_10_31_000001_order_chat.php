<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * گفتگوی مسئول سفارش با مشتری (یک گفتگو برای هر سفارش).
 * سبک: خواندن «پیام تازه هست؟» از یک فایل کوچک ثابت انجام می‌شود، نه از این جدول‌ها.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('chat_threads')) {
            Schema::create('chat_threads', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('order_id')->unique();
                $t->unsignedBigInteger('user_id')->nullable()->index();       // مشتری
                $t->unsignedBigInteger('assignee_id')->nullable()->index();   // مسئول فعلی (همان مسئول سفارش)
                $t->string('token', 40)->unique();                            // نام فایل سیگنال (حدس‌ناپذیر)
                $t->unsignedBigInteger('last_id')->default(0);
                $t->timestamp('last_at')->nullable()->index();
                $t->string('last_side', 1)->nullable();
                $t->string('last_text', 160)->nullable();
                $t->unsignedInteger('unread_staff')->default(0);
                $t->unsignedInteger('unread_customer')->default(0);
                $t->unsignedBigInteger('staff_read_id')->default(0);
                $t->unsignedBigInteger('customer_read_id')->default(0);
                $t->timestamp('awaiting_since')->nullable()->index();         // قدیمی‌ترین پیام بی‌جواب مشتری
                $t->unsignedInteger('first_reply_sec')->nullable();           // زمان اولین پاسخ
                $t->unsignedInteger('replies')->default(0);
                $t->unsignedBigInteger('reply_sec_sum')->default(0);          // برای میانگین زمان پاسخ
                $t->timestamp('alerted_at')->nullable();
                $t->timestamp('sms_at')->nullable();
                $t->timestamp('closed_at')->nullable();
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('chat_messages')) {
            Schema::create('chat_messages', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('thread_id');
                $t->string('side', 1);                  // c مشتری، s همکار، n یادداشت داخلی، x پیام خودکار
                $t->unsignedBigInteger('user_id')->nullable();
                $t->string('kind', 12)->default('text'); // text, image, product, confirm, invoice, event
                $t->text('body')->nullable();
                $t->json('meta')->nullable();
                $t->timestamp('created_at')->nullable();
                $t->index(['thread_id', 'id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('chat_messages');
        Schema::dropIfExists('chat_threads');
    }
};
