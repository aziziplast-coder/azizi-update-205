<?php

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\PickTask;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/**
 * سفارش ۱۱۳۸: ویرایش ۱۳ قلمی از گفتگو به‌خاطر کوتاهی ستون تاریخچه با خطا برگشت ولی اقلام و حواله ثبت شده بود؛
 * با تکرار «ثبت»، همان ۱۳ قلم در مرحله‌های ۳ و ۴ دوباره اضافه شد. اگر هنوز کسی دست به آن حواله‌ها نزده، حذف می‌شوند.
 */
return new class extends Migration
{
    public function up(): void
    {
        try {
            $o = Order::query()->where('number', '1138')->first();
            if (! $o || in_array($o->status, ['cancelled', 'completed', 'shipped'], true)) {
                return;
            }
            $base = OrderItem::query()->where('order_id', $o->id)->where('round', 2)->pluck('product_id')->sort()->values()->all();
            $removed = [];
            foreach ([3, 4] as $round) {
                $items = OrderItem::query()->where('order_id', $o->id)->where('round', $round)->get();
                $tasks = PickTask::query()->where('order_id', $o->id)->where('round', $round)->get();
                if ($items->isEmpty()) {
                    continue;
                }
                $same = $items->pluck('product_id')->sort()->values()->all() === $base;
                $untouched = $tasks->every(fn ($t) => $t->status !== 'done' && ! $t->started_at && ! $t->picker_id && ! $t->picked_done_at && ! in_array($t->stage, ['picking', 'review', 'desk'], true))
                    && $items->every(fn ($i) => $i->pick_status === null && ! $i->picked_units && ! $i->desk_units);
                if (! $same || ! $untouched) {
                    $o->log('⚠ مرحله '.fa($round).' سفارش (تکرار اقلام افزوده) خودکار حذف نشد چون '.(! $same ? 'اقلامش با مرحله ۲ یکی نیست' : 'جمع‌آوری‌اش شروع شده').'؛ دستی بررسی کنید.');

                    continue;
                }
                DB::transaction(function () use ($o, $items, $tasks) {
                    foreach ($items as $it) {
                        \App\Services\OrderEdit::moveStock($o, $it->product_id, $it->cartMode(), -(int) $it->units, $it->name); // موجودی برمی‌گردد
                        $it->delete();
                    }
                    PickTask::query()->whereIn('id', $tasks->pluck('id'))->delete();
                });
                $removed[] = $round;
            }
            if ($removed) {
                $before = (int) $o->total;
                \App\Services\Picking::recalc($o);
                $o->refresh();
                $o->log('🧹 اقلام تکراری مرحله '.implode(' و ', array_map('fa', $removed)).' حذف شد (همان ۱۳ قلم مرحله ۲ که با خطای ثبت تاریخچه، با هر بار «ثبت» دوباره اضافه شده بود) — حواله‌هایش هم بسته شد. مبلغ سفارش: '.money($before).' ← '.money($o->total).' تومان');
            }
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void {}
};
