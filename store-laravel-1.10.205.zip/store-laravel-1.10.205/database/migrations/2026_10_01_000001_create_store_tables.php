<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $t) {
            $t->id();
            $t->string('name')->nullable();
            $t->string('mobile', 15)->nullable()->unique();
            $t->string('email')->nullable()->unique();
            $t->string('password')->nullable();
            $t->string('role', 20)->default('customer')->index(); // admin | staff | keeper | customer
            $t->json('permissions')->nullable();
            $t->boolean('is_active')->default(true);
            $t->string('company')->nullable();
            $t->string('province', 60)->nullable();
            $t->string('city', 80)->nullable();
            $t->text('address')->nullable();
            $t->string('postal_code', 20)->nullable();
            $t->text('note')->nullable();
            $t->timestamp('last_login_at')->nullable();
            $t->rememberToken();
            $t->timestamps();
        });

        Schema::create('sessions', function (Blueprint $t) {
            $t->string('id')->primary();
            $t->foreignId('user_id')->nullable()->index();
            $t->string('ip_address', 45)->nullable();
            $t->text('user_agent')->nullable();
            $t->longText('payload');
            $t->integer('last_activity')->index();
        });

        Schema::create('settings', function (Blueprint $t) {
            $t->id();
            $t->string('key', 100)->unique();
            $t->longText('value')->nullable();
            $t->timestamps();
        });

        Schema::create('categories', function (Blueprint $t) {
            $t->id();
            $t->foreignId('parent_id')->nullable()->constrained('categories')->nullOnDelete();
            $t->string('name');
            $t->string('slug', 191)->unique();
            $t->string('image')->nullable();
            $t->text('description')->nullable();
            $t->integer('sort')->default(0);
            $t->boolean('is_active')->default(true);
            $t->boolean('in_menu')->default(true);
            $t->string('seo_title')->nullable();
            $t->string('seo_description', 500)->nullable();
            $t->timestamps();
        });

        Schema::create('warehouses', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('code', 30)->nullable();
            $t->string('phone', 30)->nullable();
            $t->text('address')->nullable();
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::create('user_warehouse', function (Blueprint $t) {
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('warehouse_id')->constrained()->cascadeOnDelete();
            $t->primary(['user_id', 'warehouse_id']);
        });

        Schema::create('products', function (Blueprint $t) {
            $t->id();
            $t->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $t->string('name');
            $t->string('slug', 191)->unique();
            $t->string('barcode', 64)->nullable()->index();
            $t->string('sku', 64)->nullable();
            $t->text('short_description')->nullable();
            $t->longText('description')->nullable();
            $t->string('image')->nullable();
            $t->json('gallery')->nullable();
            $t->json('specs')->nullable();

            // قیمت هر عدد (تومان)
            $t->unsignedBigInteger('price')->default(0);
            $t->unsignedBigInteger('compare_price')->nullable();

            // فروش کارتنی (عمده)
            $t->unsignedInteger('per_carton')->default(1);
            $t->boolean('carton_enabled')->default(true);
            $t->boolean('in_stock')->default(true);
            $t->integer('stock')->nullable(); // تعداد (عدد) در انبار عمده؛ خالی = بدون شمارش
            $t->foreignId('warehouse_id')->nullable()->constrained()->nullOnDelete();

            // فروش خرد (کمتر از کارتن)
            $t->boolean('retail_enabled')->default(false);
            $t->unsignedBigInteger('retail_price')->nullable();
            $t->boolean('retail_in_stock')->default(true);
            $t->integer('retail_stock')->nullable();
            $t->unsignedInteger('retail_max')->nullable();
            $t->foreignId('retail_warehouse_id')->nullable()->constrained('warehouses')->nullOnDelete();

            $t->boolean('is_active')->default(true)->index();
            $t->boolean('is_featured')->default(false);
            $t->integer('sort')->default(0);
            $t->unsignedInteger('sales_count')->default(0);
            $t->unsignedInteger('views')->default(0);
            $t->string('seo_title')->nullable();
            $t->string('seo_description', 500)->nullable();
            $t->timestamps();
            $t->index(['category_id', 'is_active']);
        });

        Schema::create('reviews', function (Blueprint $t) {
            $t->id();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('name');
            $t->unsignedTinyInteger('rating')->default(5);
            $t->text('body');
            $t->boolean('is_approved')->default(false);
            $t->timestamps();
        });

        Schema::create('stock_alerts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->string('mobile', 15);
            $t->timestamp('notified_at')->nullable();
            $t->timestamps();
            $t->unique(['product_id', 'mobile']);
        });

        Schema::create('orders', function (Blueprint $t) {
            $t->id();
            $t->string('number', 40)->nullable()->unique();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('status', 30)->default('pending_payment')->index();
            $t->string('customer_name');
            $t->string('mobile', 15)->index();
            $t->string('company')->nullable();
            $t->string('province', 60)->nullable();
            $t->string('city', 80)->nullable();
            $t->text('address')->nullable();
            $t->string('postal_code', 20)->nullable();
            $t->text('note')->nullable();
            $t->string('shipping_method', 40)->nullable();
            $t->string('shipping_title')->nullable();
            $t->unsignedBigInteger('shipping_cost')->default(0);
            $t->boolean('shipping_collect')->default(false); // پس‌کرایه
            $t->string('payment_method', 40)->nullable();
            $t->string('payment_title')->nullable();
            $t->string('payment_status', 20)->default('unpaid');
            $t->string('payment_ref')->nullable();
            $t->json('payment_meta')->nullable();
            $t->unsignedBigInteger('items_total')->default(0);
            $t->unsignedBigInteger('discount_total')->default(0);
            $t->json('fees')->nullable();
            $t->unsignedBigInteger('fees_total')->default(0);
            $t->unsignedBigInteger('total')->default(0);
            $t->string('tracking_code')->nullable();
            $t->text('admin_note')->nullable();
            $t->boolean('stock_reduced')->default(false);
            $t->timestamp('paid_at')->nullable();
            $t->timestamp('alerted_at')->nullable()->index();
            $t->string('ip', 45)->nullable();
            $t->timestamps();
            $t->index('created_at');
        });

        Schema::create('order_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('order_id')->constrained()->cascadeOnDelete();
            $t->foreignId('product_id')->nullable()->constrained()->nullOnDelete();
            $t->string('name');
            $t->string('barcode', 64)->nullable();
            $t->string('image')->nullable();
            $t->string('mode', 10)->default('carton');
            $t->unsignedInteger('units');
            $t->unsignedInteger('per_carton')->default(1);
            $t->unsignedBigInteger('unit_price');
            $t->unsignedBigInteger('compare_price')->nullable();
            $t->unsignedBigInteger('total');
            $t->foreignId('warehouse_id')->nullable()->constrained()->nullOnDelete();
        });

        Schema::create('order_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('order_id')->constrained()->cascadeOnDelete();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('message', 500);
            $t->timestamp('created_at')->nullable();
        });

        Schema::create('pages', function (Blueprint $t) {
            $t->id();
            $t->string('title');
            $t->string('slug', 191)->unique();
            $t->longText('body')->nullable();
            $t->boolean('is_active')->default(true);
            $t->boolean('in_footer')->default(true);
            $t->integer('sort')->default(0);
            $t->string('seo_description', 500)->nullable();
            $t->timestamps();
        });

        Schema::create('otp_codes', function (Blueprint $t) {
            $t->id();
            $t->string('mobile', 15)->index();
            $t->string('code');
            $t->unsignedTinyInteger('attempts')->default(0);
            $t->timestamp('expires_at');
            $t->timestamp('created_at')->nullable();
        });

        Schema::create('sms_logs', function (Blueprint $t) {
            $t->id();
            $t->string('event', 40);
            $t->string('mobile', 15)->nullable();
            $t->boolean('ok')->default(false);
            $t->string('message', 1000)->nullable();
            $t->string('provider', 60)->nullable();
            $t->timestamp('created_at')->nullable()->index();
        });
    }

    public function down(): void
    {
        foreach (['sms_logs', 'otp_codes', 'pages', 'order_events', 'order_items', 'orders', 'stock_alerts', 'reviews', 'products', 'user_warehouse', 'warehouses', 'categories', 'settings', 'sessions', 'users'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
