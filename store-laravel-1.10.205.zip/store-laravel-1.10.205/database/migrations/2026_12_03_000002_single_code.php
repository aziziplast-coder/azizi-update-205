<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/* هر کالا فقط یک کد: کد فعلی هلو (sku). کد سایت قبلی و کدهای قدیمی کنار گذاشته می‌شوند. */
return new class extends Migration
{
    public function up(): void
    {
        DB::table('products')->whereNotNull('sync_code')->whereNotNull('sku')->where('sku', '!=', '')->whereColumn('sync_code', '!=', 'sku')
            ->orderBy('id')->select('id', 'sku')->chunk(500, function ($rows) {
                foreach ($rows as $r) {
                    DB::table('products')->where('id', $r->id)->update(['sync_code' => $r->sku]);
                }
            });
        if (Schema::hasColumn('products', 'old_codes')) {
            DB::table('products')->whereNotNull('old_codes')->update(['old_codes' => null]);
        }
    }

    public function down(): void
    {
    }
};
