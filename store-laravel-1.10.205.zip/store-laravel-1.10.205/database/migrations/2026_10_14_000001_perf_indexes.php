<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** ایندکس‌های سرعت فهرست کالاها با ده‌ها هزار کالا (مرتب‌سازی و فیلتر موجود) */
return new class extends Migration
{
    public function up(): void
    {
        foreach ([
            'products_active_stock_idx' => ['is_active', 'in_stock', 'id'],
            'products_active_sales_idx' => ['is_active', 'sales_count'],
            'products_active_price_idx' => ['is_active', 'price'],
            'products_active_views_idx' => ['is_active', 'views'],
        ] as $name => $cols) {
            try {
                Schema::table('products', fn (Blueprint $t) => $t->index($cols, $name));
            } catch (\Throwable) {
                // از قبل وجود دارد
            }
        }
    }

    public function down(): void
    {
    }
};
