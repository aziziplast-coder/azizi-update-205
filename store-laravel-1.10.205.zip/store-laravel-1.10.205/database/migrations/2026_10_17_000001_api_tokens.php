<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** توکن‌های ورود اپلیکیشن موبایل (هر دستگاه یک توکن) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('api_tokens')) {
            Schema::create('api_tokens', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('user_id')->index();
                $t->string('token', 64)->unique(); // sha256
                $t->string('device', 120)->nullable();
                $t->string('platform', 20)->nullable();
                $t->string('app_version', 20)->nullable();
                $t->timestamp('last_used_at')->nullable();
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('api_tokens');
    }
};
