<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * پنجره‌های تغییر سفارش توسط مشتری: پنجره‌های اعلان همکار در گفتگو (staff_pop)
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('orders', 'staff_pop')) {
            Schema::table('orders', fn (Blueprint $t) => $t->text('staff_pop')->nullable());
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('orders', 'staff_pop')) {
            Schema::table('orders', fn (Blueprint $t) => $t->dropColumn('staff_pop'));
        }
    }
};
