<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * کارتابل انباردار: ارجاع سفارش به انبار، جمع‌آوری اقلام، کسری/ناموجود، انتقال بین انباردارها
 * و جایگزینی کالاهای حذف‌شده توسط مشتری.
 * بدون کلید خارجی و با بررسی جداگانه هر ستون تا روی همه نسخه‌های MySQL/MariaDB و اجرای نیمه‌کاره قبلی درست کار کند.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('pick_tasks')) {
            Schema::create('pick_tasks', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('order_id')->index();
                $t->unsignedBigInteger('keeper_id')->nullable();
                $t->unsignedSmallInteger('round')->default(1);
                $t->string('status', 12)->default('open'); // open | saved | done
                $t->timestamp('seen_at')->nullable();
                $t->timestamp('started_at')->nullable();
                $t->timestamp('saved_at')->nullable();
                $t->timestamp('done_at')->nullable();
                $t->unsignedBigInteger('done_by')->nullable();
                $t->timestamps();
                $t->index(['keeper_id', 'status']);
                $t->index(['order_id', 'round']);
            });
        }
        $cols = [
            'order_items' => [
                'pick_task_id' => fn (Blueprint $t) => $t->unsignedBigInteger('pick_task_id')->nullable()->index(),
                'pick_status' => fn (Blueprint $t) => $t->string('pick_status', 10)->nullable(), // ok | short | missing
                'picked_units' => fn (Blueprint $t) => $t->unsignedInteger('picked_units')->nullable(),
                'ordered_units' => fn (Blueprint $t) => $t->unsignedInteger('ordered_units')->nullable(),
                'picked_at' => fn (Blueprint $t) => $t->timestamp('picked_at')->nullable(),
                'picked_by' => fn (Blueprint $t) => $t->unsignedBigInteger('picked_by')->nullable(),
                'pick_note' => fn (Blueprint $t) => $t->string('pick_note', 190)->nullable(),
                'round' => fn (Blueprint $t) => $t->unsignedSmallInteger('round')->default(1),
                'replaces_item_id' => fn (Blueprint $t) => $t->unsignedBigInteger('replaces_item_id')->nullable(),
            ],
            'orders' => [
                'fulfil_status' => fn (Blueprint $t) => $t->string('fulfil_status', 16)->nullable()->index(), // picking | picked | replace_review
                'pick_round' => fn (Blueprint $t) => $t->unsignedSmallInteger('pick_round')->default(0),
                'referred_at' => fn (Blueprint $t) => $t->timestamp('referred_at')->nullable(),
                'referred_by' => fn (Blueprint $t) => $t->unsignedBigInteger('referred_by')->nullable(),
                'picked_at' => fn (Blueprint $t) => $t->timestamp('picked_at')->nullable(),
                'replace_until' => fn (Blueprint $t) => $t->timestamp('replace_until')->nullable(),
                'replace_submitted_at' => fn (Blueprint $t) => $t->timestamp('replace_submitted_at')->nullable(),
                'deposit_amount' => fn (Blueprint $t) => $t->unsignedBigInteger('deposit_amount')->nullable(),
                'deposit_ref' => fn (Blueprint $t) => $t->string('deposit_ref', 120)->nullable(),
            ],
        ];
        foreach ($cols as $table => $list) {
            foreach ($list as $col => $def) {
                if (! Schema::hasColumn($table, $col)) {
                    Schema::table($table, fn (Blueprint $t) => $def($t));
                }
            }
        }
        if (! Schema::hasTable('order_replacements')) {
            Schema::create('order_replacements', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('order_id');
                $t->unsignedBigInteger('replaces_item_id')->nullable();
                $t->unsignedBigInteger('product_id');
                $t->string('name');
                $t->string('mode', 10);
                $t->unsignedInteger('units');
                $t->unsignedInteger('per_carton')->default(1);
                $t->unsignedBigInteger('unit_price');
                $t->string('status', 12)->default('draft'); // draft | submitted | approved | rejected
                $t->timestamps();
                $t->index(['order_id', 'status']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('order_replacements');
        Schema::dropIfExists('pick_tasks');
    }
};
