<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * سایت قبلی هنوز کالای تازه می‌سازد و شماره‌های بعد از ۳۹ هزار را خودش مصرف می‌کند.
 * کالاهایی که این سایت ساخته (دستی/آپلود گروهی) و شماره‌شان در همان محدوده است به محدوده جدا (از ۱۰۰۰۰۱) می‌روند
 * تا همگام‌سازی JSON با خطای «Duplicate entry … products_legacy_id_unique» روبه‌رو نشود.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('products', 'legacy_id')) {
            return;
        }
        $floor = (int) setting('legacy_id_floor', 0);
        $own = \App\Support\LegacyUrls::OWN_FROM;
        $q = DB::table('products')->whereNotNull('legacy_id')->where('legacy_id', '>', $floor)->where('legacy_id', '<', $own)->whereNull('sync_code');
        if (Schema::hasTable('sync_items')) {
            $q->whereNotIn('id', DB::table('sync_items')->whereNotNull('product_id')->select('product_id'));
        }
        $ids = $q->orderBy('legacy_id')->pluck('id');
        $next = max($own - 1, (int) DB::table('products')->where('legacy_id', '>=', $own)->max('legacy_id'));
        foreach ($ids as $id) {
            DB::table('products')->where('id', $id)->update(['legacy_id' => ++$next]);
        }
        \Illuminate\Support\Facades\Cache::forget('legacy-id-last');
    }

    public function down(): void {}
};
