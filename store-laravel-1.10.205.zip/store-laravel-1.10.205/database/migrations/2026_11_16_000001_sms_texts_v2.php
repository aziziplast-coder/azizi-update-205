<?php

use Illuminate\Database\Migrations\Migration;

/**
 * متن پیامک‌های مرحله‌های پرداخت: مشتری فقط وقتی کارت حساب صادر شد پول بخواهد
 * (قبلاً «سفارش جمع شد؛ مانده را تسویه کنید» پیش از صدور مانده حساب می‌رفت و مشتری به حساب بیعانه واریز می‌کرد).
 * یک بار متن ذخیره‌شده این پیام‌ها با متن تازه جایگزین می‌شود (روشن/خاموش و الگوها دست نمی‌خورد).
 */
return new class extends Migration
{
    public function up(): void
    {
        try {
            $saved = (array) setting('sms_events', []);
            if (! $saved) {
                return;
            }
            $def = \App\Services\Sms::events();
            foreach (['customer_on_hold', 'customer_processing', 'customer_settling', 'remit_deposit', 'remit_settle', 'remit_rejected'] as $k) {
                if (isset($saved[$k]) && isset($def[$k])) {
                    $saved[$k]['text'] = $def[$k]['text'];
                }
            }
            \App\Support\Settings::set(['sms_events' => $saved]);
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void
    {
    }
};
