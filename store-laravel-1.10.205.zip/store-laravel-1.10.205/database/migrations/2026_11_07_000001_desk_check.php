<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * - بررسی رومیزی: انبارهایی (مثل خرده‌ریز و لوکس) که بار پس از جمع‌آوری روی میز با کامپیوتر بررسی می‌شود
 * - desk_units: تعداد تأییدشده در بررسی رومیزی (null = هنوز بررسی نشده)
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('warehouses', 'desk_check')) {
            Schema::table('warehouses', fn (Blueprint $t) => $t->boolean('desk_check')->default(false));
        }
        if (! Schema::hasColumn('order_items', 'desk_units')) {
            Schema::table('order_items', fn (Blueprint $t) => $t->integer('desk_units')->nullable());
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('warehouses', 'desk_check')) {
            Schema::table('warehouses', fn (Blueprint $t) => $t->dropColumn('desk_check'));
        }
        if (Schema::hasColumn('order_items', 'desk_units')) {
            Schema::table('order_items', fn (Blueprint $t) => $t->dropColumn('desk_units'));
        }
    }
};
