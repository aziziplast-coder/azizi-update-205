<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* گفتگوی زنده: ویس، جواب خودکار (سؤال‌های متداول / هوش مصنوعی)، مسئول گفتگو */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('live_messages', function (Blueprint $t) {
            if (! Schema::hasColumn('live_messages', 'kind')) {
                $t->string('kind', 10)->default('text'); // text | voice
            }
        });
        Schema::table('live_chats', function (Blueprint $t) {
            if (! Schema::hasColumn('live_chats', 'human')) {
                $t->boolean('human')->default(false);          // مشتری خواسته با همکار صحبت کند
                $t->unsignedSmallInteger('ai_count')->default(0);
                $t->timestamp('assigned_at')->nullable();
                $t->timestamp('staff_at')->nullable();          // آخرین پاسخ همکار
            }
        });
    }

    public function down(): void {}
};
