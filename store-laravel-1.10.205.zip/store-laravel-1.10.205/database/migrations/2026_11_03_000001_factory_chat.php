<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * گفتگوی حسابداری با کارخانه‌دارها: همان جدول گفتگوها، با factory_id به‌جای order_id
 * (یک گفتگو برای هر کارخانه‌دار).
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('chat_threads') || Schema::hasColumn('chat_threads', 'factory_id')) {
            return;
        }
        Schema::table('chat_threads', function (Blueprint $t) {
            $t->unsignedBigInteger('order_id')->nullable()->change();
        });
        Schema::table('chat_threads', function (Blueprint $t) {
            $t->unsignedBigInteger('factory_id')->nullable()->unique()->after('order_id');
        });
    }

    public function down(): void
    {
        if (Schema::hasColumn('chat_threads', 'factory_id')) {
            Schema::table('chat_threads', function (Blueprint $t) {
                $t->dropUnique(['factory_id']);
                $t->dropColumn('factory_id');
            });
        }
    }
};
