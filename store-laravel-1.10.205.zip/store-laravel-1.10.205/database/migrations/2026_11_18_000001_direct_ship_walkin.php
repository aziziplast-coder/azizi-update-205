<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * ۱) ارسال مستقیم (خاور باربری از انبار تا درِ مغازه): بدون بیجک، با بارنامه یا شماره راننده (هر دو اختیاری)
 * ۲) فیش حضوری: پرداخت بدون سفارش (نام مشتری دستی) + لینک بارگذاری فیش برای خود مشتری
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $t) {
            if (! Schema::hasColumn('orders', 'direct_at')) {
                $t->timestamp('direct_at')->nullable();
            }
            if (! Schema::hasColumn('orders', 'driver_phone')) {
                $t->string('driver_phone', 20)->nullable();
            }
        });
        Schema::table('remit_payments', function (Blueprint $t) {
            if (! Schema::hasColumn('remit_payments', 'walkin_name')) {
                $t->string('walkin_name', 120)->nullable();
            }
            if (! Schema::hasColumn('remit_payments', 'walkin_mobile')) {
                $t->string('walkin_mobile', 20)->nullable();
            }
            if (! Schema::hasColumn('remit_payments', 'walkin_token')) {
                $t->string('walkin_token', 40)->nullable()->unique();
            }
        });
        // فیش حضوری سفارش ندارد
        Schema::table('remit_payments', function (Blueprint $t) {
            $t->unsignedBigInteger('order_id')->nullable()->change();
        });
    }

    public function down(): void
    {
    }
};
