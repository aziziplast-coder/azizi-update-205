<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * شناسه یکتا (شکل سایت قبلی /product-شماره/نام) برای همه کالاها:
 * ۱) کالاهای آمده از فید، شناسه واقعی سایت قبلی را می‌گیرند
 * ۲) کالاهای دیگر (دستی/آپلود گروهی) شماره تازه بعد از بزرگ‌ترین شناسه سایت قبلی
 * ۳) ایندکس یکتا تا هیچ‌وقت تکراری نشود
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('products', 'legacy_id')) {
            return;
        }
        try {
            \App\Support\LegacyUrls::backfill();
        } catch (\Throwable $e) {
            report($e);
        }
        $floor = max((int) DB::table('products')->max('legacy_id'), Schema::hasTable('sync_items') ? \App\Support\LegacyUrls::feedMaxId() : 0);
        \App\Support\Settings::set(['legacy_id_floor' => $floor]);

        // شناسه‌های تکراری احتمالی (دو کالا با یک شناسه): کالای دوم شماره تازه می‌گیرد
        $dups = DB::table('products')->whereNotNull('legacy_id')->select('legacy_id')->groupBy('legacy_id')->havingRaw('COUNT(*) > 1')->pluck('legacy_id');
        $next = $floor;
        foreach ($dups as $lid) {
            $ids = DB::table('products')->where('legacy_id', $lid)->orderBy('id')->pluck('id')->slice(1);
            foreach ($ids as $id) {
                DB::table('products')->where('id', $id)->update(['legacy_id' => ++$next, 'legacy_slug' => null]);
            }
        }
        DB::table('products')->whereNull('legacy_id')->orderBy('id')->select('id')->chunkById(500, function ($rows) use (&$next) {
            foreach ($rows as $r) {
                DB::table('products')->where('id', $r->id)->update(['legacy_id' => ++$next]);
            }
        });
        \Illuminate\Support\Facades\Cache::forever('legacy-id-last', $next);

        try {
            $has = collect(Schema::getIndexes('products'))->contains(fn ($ix) => $ix['unique'] && $ix['columns'] === ['legacy_id']);
            if (! $has) {
                Schema::table('products', fn (Blueprint $t) => $t->unique('legacy_id', 'products_legacy_id_unique'));
            }
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void {}
};
