<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/**
 * دسترسی ریز «فروش حضوری»: کارکنانی که تا امروز با دسترسی «سفارش‌ها» کارتابل فروش حضوری را داشتند
 * همان دسترسی‌ها را می‌گیرند (بدون «حذف فاکتور»)؛ مدیر از «کارکنان» کم یا زیادشان می‌کند.
 */
return new class extends Migration
{
    public function up(): void
    {
        $add = ['wk_desk', 'wk_returns', 'wk_excel', 'wk_edit', 'wk_finish'];
        foreach (DB::table('users')->where('role', 'staff')->whereNotNull('permissions')->get(['id', 'permissions']) as $u) {
            $p = json_decode((string) $u->permissions, true);
            if (! is_array($p) || ! in_array('orders', $p, true) || array_intersect($add, $p)) {
                continue;
            }
            DB::table('users')->where('id', $u->id)->update(['permissions' => json_encode(array_values(array_unique(array_merge($p, $add))))]);
        }
    }

    public function down(): void {}
};
