<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** ایندکس برای تطبیق سریع کالاها در همگام‌سازی‌های بزرگ (ده‌ها هزار کالا) */
return new class extends Migration
{
    public function up(): void
    {
        try {
            Schema::table('products', fn (Blueprint $t) => $t->index('sku', 'products_sku_index'));
        } catch (\Throwable) {
            // از قبل وجود دارد
        }
        try {
            Schema::table('sync_items', fn (Blueprint $t) => $t->index(['source_id', 'image_status'], 'sync_items_src_img_index'));
        } catch (\Throwable) {
        }
    }

    public function down(): void
    {
    }
};
