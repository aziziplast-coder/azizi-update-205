<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* آمار بازدید: هر نشست یک ردیف + شمارنده‌های روزانه (کالا، دسته، جستجو، صفحه، ساعت) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('stat_sessions')) {
            Schema::create('stat_sessions', function (Blueprint $t) {
                $t->id();
                $t->string('sid', 32)->unique();
                $t->string('vid', 32)->index();
                $t->date('day')->index();
                $t->unsignedBigInteger('user_id')->nullable()->index();
                $t->unsignedInteger('started_at');
                $t->unsignedInteger('last_at');
                $t->unsignedTinyInteger('hour')->default(0);
                $t->unsignedTinyInteger('wd')->default(0);   // روز هفته: ۰ = شنبه
                $t->unsignedSmallInteger('pv')->default(0);
                $t->unsignedInteger('dur')->default(0);      // ثانیه (فقط وقتی صفحه جلوی چشم بوده)
                $t->string('channel', 16)->default('direct')->index();
                $t->string('source', 80)->nullable();
                $t->string('medium', 40)->nullable();
                $t->string('campaign', 80)->nullable();
                $t->string('landing', 16)->nullable();
                $t->string('landing_t', 120)->nullable();
                $t->string('exit_t', 120)->nullable();
                $t->string('device', 8)->nullable();
                $t->string('os', 10)->nullable();
                $t->string('browser', 12)->nullable();
                $t->unsignedTinyInteger('app')->default(0);  // ۱ اپ اندروید، ۲ نصب‌شده روی صفحه گوشی
                $t->boolean('is_new')->default(false);
                $t->unsignedSmallInteger('products')->default(0);
                $t->unsignedSmallInteger('searches')->default(0);
                $t->unsignedSmallInteger('adds')->default(0);
                $t->boolean('cart')->default(false);
                $t->boolean('checkout')->default(false);
                $t->unsignedSmallInteger('orders')->default(0);
                $t->unsignedBigInteger('revenue')->default(0);
                $t->text('seen')->nullable();                 // کالا/دسته‌های دیده‌شده (برای شمارش یکتا)
                $t->index(['day', 'channel']);
            });
        }
        if (! Schema::hasTable('stat_counts')) {
            Schema::create('stat_counts', function (Blueprint $t) {
                $t->date('day');
                $t->string('kind', 10);     // product, cat, search, kind, hour
                $t->string('key', 120);
                $t->unsignedInteger('n')->default(0);   // بازدید
                $t->unsignedInteger('u')->default(0);   // نشست یکتا
                $t->unsignedInteger('a')->default(0);   // افزودن به سبد / جستجوی بی‌نتیجه
                $t->primary(['day', 'kind', 'key']);
                $t->index(['kind', 'day']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('stat_counts');
        Schema::dropIfExists('stat_sessions');
    }
};
