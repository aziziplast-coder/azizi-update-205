<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * انتقال کالا بین انباردارها: اقلام منتقل‌شده تا «پایان حواله» مبدأ نگه داشته می‌شوند
 * و بعد همه با هم به‌صورت یک حواله برای مقصد (مثلاً سرپرست) می‌روند.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('pick_tasks', 'hold_for')) {
            Schema::table('pick_tasks', function (Blueprint $t) {
                $t->unsignedBigInteger('hold_for')->nullable()->index();
            });
        }
    }

    public function down(): void {}
};
