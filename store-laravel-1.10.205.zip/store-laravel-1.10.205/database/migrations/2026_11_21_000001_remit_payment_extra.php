<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** اضافه‌واریز: واریزی که بعد از پر/بسته شدن حواله به حساب همان کارخانه رسیده (حواله دست نمی‌خورد) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('remit_payments', 'extra')) {
            Schema::table('remit_payments', function (Blueprint $t) {
                $t->boolean('extra')->default(false)->index();
                $t->string('extra_note', 255)->nullable();
            });
        }
    }

    public function down(): void {}
};
