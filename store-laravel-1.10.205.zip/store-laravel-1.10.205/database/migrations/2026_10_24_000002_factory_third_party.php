<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** شخص ثالث: کارخانه‌دار حواله را به او منتقل می‌کند؛ او فقط حساب خودش را ثبت و فیش‌ها را تأیید می‌کند */
return new class extends Migration
{
    public function up(): void
    {
        foreach ([
            'kind' => fn (Blueprint $t) => $t->string('kind', 10)->default('factory')->index(), // factory | third
            'referred_by' => fn (Blueprint $t) => $t->unsignedBigInteger('referred_by')->nullable(),
        ] as $col => $def) {
            if (! Schema::hasColumn('factories', $col)) {
                try {
                    Schema::table('factories', $def);
                } catch (\Illuminate\Database\QueryException $e) {
                    if (! preg_match('/Duplicate column|1060|already exists/i', $e->getMessage())) {
                        throw $e;
                    }
                }
            }
        }
    }

    public function down(): void
    {
        Schema::table('factories', fn (Blueprint $t) => $t->dropColumn(['kind', 'referred_by']));
    }
};
