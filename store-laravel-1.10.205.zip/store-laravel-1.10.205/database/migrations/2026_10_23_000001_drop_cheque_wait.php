<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/** وضعیت «در انتظار رسیدن چک» از مراحل حذف شد: سفارش‌های همان وضعیت ← «در حال ارسال به باربری» */
return new class extends Migration
{
    public function up(): void
    {
        DB::table('orders')->where('status', 'cheque_wait')->update(['status' => 'to_freight']);
    }

    public function down(): void {}
};
