<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * برگشت کالا به انبار پس از لغو سفارش (میز بررسی و کارتابل سرپرست)
 * + هشدار سفارش‌هایی که پس از صدور مانده حساب مبلغشان بیشتر شده است.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('pick_tasks', 'ret_state')) {
            Schema::table('pick_tasks', function (Blueprint $t) {
                $t->string('ret_state', 10)->nullable()->index(); // pending | done
                $t->timestamp('ret_at')->nullable();
                $t->unsignedBigInteger('ret_by')->nullable();
            });
        }
        \App\Support\DbSchema::flush();

        // لغوهای ۳ روز اخیر که کالایشان جمع شده بود ← در صف «برگشت به انبار»
        try {
            \App\Models\Order::query()->where('status', 'cancelled')->where('status_changed_at', '>', now()->subDays(3))->get()
                ->each(fn ($o) => \App\Services\Picking::orderCancelled($o, false));
        } catch (\Throwable $e) {
            report($e);
        }

        // مبلغ سفارش پس از صدور مانده حساب بیشتر شده ولی «پرداخت شده» خورده (مثل جایگزین تأییدشده بعد از صدور مانده)
        try {
            \App\Models\Order::query()->whereNotNull('final_amount')->whereIn('status', ['processing', 'settling', 'to_freight'])
                ->whereColumn('total', '>', 'final_amount')->get()
                ->each(fn ($o) => \App\Services\Remit::totalChanged($o, (int) $o->final_amount));
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void {}
};
