<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('orders') && ! Schema::hasColumn('orders', 'cancel_reason')) {
            Schema::table('orders', function (Blueprint $t) {
                $t->string('cancel_reason', 500)->nullable();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('orders', 'cancel_reason')) {
            Schema::table('orders', fn (Blueprint $t) => $t->dropColumn('cancel_reason'));
        }
    }
};
