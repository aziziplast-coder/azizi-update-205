<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/** ثبت احراز موبایل مشتری (کسانی که کد تأیید گرفتند ولی وارد نکردند) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('users', 'mobile_verified_at')) {
            Schema::table('users', function (Blueprint $t) {
                $t->timestamp('mobile_verified_at')->nullable();
                $t->timestamp('otp_sent_at')->nullable();
                $t->unsignedInteger('otp_sends')->default(0);
            });
            // همه حساب‌های فعلی احراز‌شده حساب می‌شوند
            DB::table('users')->update(['mobile_verified_at' => DB::raw('created_at')]);
            DB::table('users')->whereNull('mobile_verified_at')->update(['mobile_verified_at' => now()]);
        }
        try {
            Schema::table('users', fn (Blueprint $t) => $t->index(['role', 'created_at'], 'users_role_created_index'));
        } catch (\Throwable) {
        }
    }

    public function down(): void
    {
    }
};
