<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* زمان آخرین «تنظیم مستقیم» موجودی (دستی، اکسل، اسکن انبار، ناموجودی در جمع‌آوری).
   سفارشی که قبل از این زمان ثبت شده، هنگام لغو/حذف قلم، موجودی را برنمی‌گرداند (چون آن عدد دیگر از موجودی جدید کم نشده بود) */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $t) {
            if (! Schema::hasColumn('products', 'stock_at')) {
                $t->timestamp('stock_at')->nullable();
            }
            if (! Schema::hasColumn('products', 'retail_stock_at')) {
                $t->timestamp('retail_stock_at')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('products', fn (Blueprint $t) => $t->dropColumn(['stock_at', 'retail_stock_at']));
    }
};
