<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** دور ویرایش مشتری پیش از بیعانه (۱ = زمان اولیه، ۲ = فرصت آخر داده‌شده توسط همکار) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('orders', 'edit_round')) {
            Schema::table('orders', fn (Blueprint $t) => $t->unsignedTinyInteger('edit_round')->default(0));
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('orders', 'edit_round')) {
            Schema::table('orders', fn (Blueprint $t) => $t->dropColumn('edit_round'));
        }
    }
};
