<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** خرید و تأمین: تعداد در کارتن از اکسل تأمین‌کنندگان + اکسل جداگانه فروش (برای مرتب‌سازی پرفروش‌ترین‌ها) */
return new class extends Migration
{
    /** اجرای امن: اگر جدول/ستون همزمان یا قبلاً ساخته شده باشد، خطا نمی‌دهد */
    private function safe(callable $f): void
    {
        try {
            $f();
        } catch (\Illuminate\Database\QueryException $e) {
            if (! preg_match('/already exists|Duplicate column|Duplicate key name|1050|1060|1061/i', $e->getMessage())) {
                throw $e;
            }
        }
    }

    public function up(): void
    {
        if (Schema::hasTable('supply_items') && ! Schema::hasColumn('supply_items', 'per_carton')) {
            $this->safe(fn () => Schema::table('supply_items', fn (Blueprint $t) => $t->unsignedInteger('per_carton')->nullable()));
        }
        if (Schema::hasTable('supply_imports') && ! Schema::hasColumn('supply_imports', 'kind')) {
            $this->safe(fn () => Schema::table('supply_imports', fn (Blueprint $t) => $t->string('kind', 10)->default('supply')));
        }
        if (! Schema::hasTable('supply_sales')) {
            $this->safe(fn () => Schema::create('supply_sales', function (Blueprint $t) {
                $t->string('code_key', 60)->primary();
                $t->unsignedBigInteger('qty')->default(0);
            }));
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('supply_sales');
    }
};
