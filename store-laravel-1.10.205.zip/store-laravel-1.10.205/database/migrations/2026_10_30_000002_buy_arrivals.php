<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * بارهای خریداری‌شده (فایل شبانه «اطلاعات کالا» با «موجود شوند») برای اپ خرید و تأمین:
 * اگر اسکن عمده بعدی کالا را نیاورد، به مسئول خرید گزارش می‌شود تا بررسی کند.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('buy_arrivals')) {
            return;
        }
        Schema::create('buy_arrivals', function (Blueprint $t) {
            $t->id();
            $t->string('code_key', 60)->unique();
            $t->timestamp('arrived_at')->nullable()->index();   // زمان ورود فایل خرید
            $t->timestamp('seen_at')->nullable();               // اولین اسکن عمده بعد از خرید که کالا را داشت
            $t->timestamp('missed_since')->nullable()->index(); // اولین اسکن عمده بعد از خرید که کالا را نداشت
            $t->string('resolution', 10)->nullable();           // here = در انبار هست، gone = واقعاً تمام شده
            $t->unsignedBigInteger('resolved_by')->nullable();
            $t->timestamp('resolved_at')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('buy_arrivals');
    }
};
