<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('remittances') && ! Schema::hasColumn('remittances', 'factory_phone')) {
            Schema::table('remittances', fn (Blueprint $t) => $t->string('factory_phone', 20)->nullable());
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('remittances', 'factory_phone')) {
            Schema::table('remittances', fn (Blueprint $t) => $t->dropColumn('factory_phone'));
        }
    }
};
