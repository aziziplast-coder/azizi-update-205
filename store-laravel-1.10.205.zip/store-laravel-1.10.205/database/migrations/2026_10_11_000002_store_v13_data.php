<?php

use App\Models\Setting;
use App\Models\Survey;
use App\Support\Settings;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        // روش «باربری» قبلی به حالت باربری (پرسیدن نام باربری) برده می‌شود
        $row = Setting::query()->where('key', 'shipping_methods')->first();
        if ($row) {
            $list = json_decode((string) $row->value, true);
            if (is_array($list)) {
                $changed = false;
                foreach ($list as &$m) {
                    if (! array_key_exists('freight', $m) && (($m['id'] ?? '') === 'freight' || str_contains((string) ($m['title'] ?? ''), 'باربری'))) {
                        $m['freight'] = true;
                        $m['inner_type'] = 'fixed';
                        $m['inner_amount'] = 0;
                        $m['inner_title'] = 'ارسال تا باربری (درون‌شهری)';
                        $changed = true;
                    }
                }
                unset($m);
                if ($changed) {
                    Settings::set(['shipping_methods' => $list]);
                }
            }
        }

        if (! Survey::query()->exists()) {
            Survey::create([
                'title' => 'نظر شما درباره خریدتان',
                'intro' => 'با پاسخ به چند سؤال کوتاه کمک کنید خدمات بهتری ارائه دهیم.',
                'trigger_status' => 'completed',
                'delay_hours' => 24,
                'send_sms' => false,
                'is_active' => true,
                'thanks' => 'از اینکه نظرتان را ثبت کردید سپاسگزاریم 🌷',
                'questions' => [
                    ['key' => 'staff', 'label' => 'رضایت شما از کارشناس فروش و پاسخگویی', 'type' => 'rating', 'staff' => true, 'required' => true],
                    ['key' => 'pack', 'label' => 'کیفیت بسته‌بندی و سالم رسیدن کالا', 'type' => 'rating', 'required' => true],
                    ['key' => 'speed', 'label' => 'سرعت آماده‌سازی و ارسال', 'type' => 'rating', 'required' => true],
                    ['key' => 'match', 'label' => 'کالاها مطابق سفارش بود؟', 'type' => 'yesno', 'required' => true],
                    ['key' => 'again', 'label' => 'دوباره از ما خرید می‌کنید؟', 'type' => 'choice', 'options' => ['حتماً', 'شاید', 'خیر'], 'required' => false],
                ],
            ]);
        }
    }

    public function down(): void
    {
    }
};
