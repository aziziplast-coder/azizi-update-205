<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* گپ داخلی اپراتورها با حسابدار کل: یک گفتگو برای هر اپراتور (روی همان جدول گفتگوها) */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('chat_threads') && ! Schema::hasColumn('chat_threads', 'team_user_id')) {
            Schema::table('chat_threads', function (Blueprint $t) {
                $t->unsignedBigInteger('team_user_id')->nullable()->unique();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('chat_threads', 'team_user_id')) {
            Schema::table('chat_threads', function (Blueprint $t) {
                $t->dropUnique(['team_user_id']);
                $t->dropColumn('team_user_id');
            });
        }
    }
};
