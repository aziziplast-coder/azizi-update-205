<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** به‌روزرسانی روزانه موجودی از خروجی اسکنر انبارها (عمده/خرده) با پیش‌نمایش و امکان برگشت */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('stock_scans')) {
            return;
        }
        Schema::create('stock_scans', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('status', 20)->default('uploading'); // uploading | preview | applied | reverted
            $t->json('files')->nullable();
            $t->json('options')->nullable();
            $t->json('stats')->nullable();
            $t->timestamp('applied_at')->nullable();
            $t->timestamp('reverted_at')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void {}
};
