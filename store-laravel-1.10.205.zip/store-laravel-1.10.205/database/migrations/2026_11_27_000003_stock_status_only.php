<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/* فقط «موجود / ناموجود»: عدد موجودی‌های ۰ به کلید ناموجود تبدیل می‌شود (همان وضعیتی که الان در سایت دارند) */
return new class extends Migration
{
    public function up(): void
    {
        $v = DB::table('settings')->where('key', 'stock_unlimited')->value('value');
        if ($v !== null && in_array(trim((string) $v, '"'), ['0', 'false', ''], true)) {
            return;
        }
        DB::table('products')->where('stock', '>', 0)->update(['stock' => null]);
        DB::table('products')->where('retail_stock', '>', 0)->update(['retail_stock' => null]);
        DB::table('products')->whereNotNull('retail_stock')->where('retail_stock', '<=', 0)->update(['retail_stock' => null, 'retail_in_stock' => false]);
        // کارتنی ۰ و خرید تکی باز نیست ← کل کالا ناموجود (۰ فقط برای «کارتنی ناموجود، تکی موجود» می‌ماند)
        DB::table('products')->whereNotNull('stock')->where('stock', '<=', 0)
            ->where(fn ($q) => $q->where('retail_enabled', false)->orWhere('per_carton', '<=', 1)->orWhere('retail_in_stock', false))
            ->update(['stock' => null, 'in_stock' => false]);
        // فقط تکی فروخته می‌شود و تکی‌اش ناموجود است ← کلید «موجود» هم خاموش (در سایت همین الان ناموجود است)
        DB::table('products')->where('in_stock', true)->where('carton_enabled', false)
            ->where(fn ($q) => $q->where('retail_enabled', false)->orWhere('per_carton', '<=', 1)->orWhere('retail_in_stock', false))
            ->update(['in_stock' => false]);
        try {
            \App\Http\Middleware\GuestPageCache::bump();
            \Illuminate\Support\Facades\Cache::forget('home.blocks');
            \Illuminate\Support\Facades\Cache::forget('api.home');
        } catch (\Throwable) {
        }
    }

    public function down(): void {}
};
