<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** سرعت: شمارش پست‌های ربات بر اساس وضعیت (عدد کنار منو) بدون خواندن همه ردیف‌ها */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('bot_posts') && Schema::hasColumn('bot_posts', 'state') && ! Schema::hasIndex('bot_posts', 'bot_posts_state_index')) {
            Schema::table('bot_posts', fn (Blueprint $t) => $t->index('state'));
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('bot_posts') && Schema::hasIndex('bot_posts', 'bot_posts_state_index')) {
            Schema::table('bot_posts', fn (Blueprint $t) => $t->dropIndex(['state']));
        }
    }
};
