<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** اجازه «سفارش مجدد» برای هر سفارش (null = طبق تنظیم کلی) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('orders', 'reorder_ok')) {
            Schema::table('orders', fn (Blueprint $t) => $t->boolean('reorder_ok')->nullable());
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('orders', 'reorder_ok')) {
            Schema::table('orders', fn (Blueprint $t) => $t->dropColumn('reorder_ok'));
        }
    }
};
