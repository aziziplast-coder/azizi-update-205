<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/**
 * دسترسی‌ها جدا شد: «گفتگو با مشتری»، «پیگیری‌های عقب‌افتاده» و «بیجک» دیگر با «سفارش‌ها» خودکار داده نمی‌شوند.
 * کارکنانی که تا امروز «سفارش‌ها» را داشتند همین سه را می‌گیرند تا چیزی برایشان عوض نشود (مدیر می‌تواند بردارد).
 * «گفتگوی زنده» که نسخه قبل خودکار به دارندگان «سفارش‌ها» داده بود برداشته می‌شود؛ مدیر خودش تیک می‌زند.
 */
return new class extends Migration
{
    public function up(): void
    {
        foreach (DB::table('users')->where('role', 'staff')->whereNotNull('permissions')->get(['id', 'permissions']) as $u) {
            $p = json_decode((string) $u->permissions, true);
            if (! is_array($p) || ! in_array('orders', $p, true) || in_array('chats', $p, true)) {
                continue;
            }
            $p = array_values(array_diff($p, ['live']));
            $p = array_values(array_unique(array_merge($p, ['chats', 'followups', 'waybills'])));
            DB::table('users')->where('id', $u->id)->update(['permissions' => json_encode($p)]);
        }
    }

    public function down(): void {}
};
