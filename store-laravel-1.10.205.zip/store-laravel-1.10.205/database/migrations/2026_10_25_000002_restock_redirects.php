<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * - سفارش به کارخانه برای کالای ناموجود (شارژ مجدد)
 * - ریدایرکت لینک‌های قدیمی (مقاله‌ها و صفحه‌های سایت قبلی)
 */
return new class extends Migration
{
    public function up(): void
    {
        $add = function (string $table, string $col, \Closure $def) {
            if (Schema::hasColumn($table, $col)) {
                return;
            }
            try {
                Schema::table($table, $def);
            } catch (\Illuminate\Database\QueryException $e) {
                if (! preg_match('/Duplicate column|1060|already exists/i', $e->getMessage())) {
                    throw $e;
                }
            }
        };
        $add('products', 'restock_at', fn (Blueprint $t) => $t->timestamp('restock_at')->nullable()->index());
        $add('products', 'restock_by', fn (Blueprint $t) => $t->unsignedBigInteger('restock_by')->nullable());
        $add('products', 'restock_note', fn (Blueprint $t) => $t->string('restock_note', 190)->nullable());
        $add('posts', 'legacy_path', fn (Blueprint $t) => $t->string('legacy_path', 500)->nullable());
        if (! Schema::hasTable('redirects')) {
            Schema::create('redirects', function (Blueprint $t) {
                $t->id();
                $t->string('from_path', 500);
                $t->string('from_hash', 40)->unique();
                $t->string('to_url', 1000);
                $t->unsignedInteger('hits')->default(0);
                $t->timestamp('last_hit_at')->nullable();
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('redirects');
    }
};
