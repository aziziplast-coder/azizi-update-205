<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** مقاله‌های سایت قبلی: /blog-134/عنوان */
return new class extends Migration
{
    public function up(): void
    {
        foreach ([
            'legacy_id' => fn (Blueprint $t) => $t->unsignedInteger('legacy_id')->nullable()->index(),
            'legacy_slug' => fn (Blueprint $t) => $t->string('legacy_slug', 300)->nullable(),
        ] as $col => $def) {
            if (! Schema::hasColumn('posts', $col)) {
                try {
                    Schema::table('posts', $def);
                } catch (\Illuminate\Database\QueryException $e) {
                    if (! preg_match('/Duplicate column|1060|already exists/i', $e->getMessage())) {
                        throw $e;
                    }
                }
            }
        }
    }

    public function down(): void
    {
        Schema::table('posts', fn (Blueprint $t) => $t->dropColumn(['legacy_id', 'legacy_slug']));
    }
};
