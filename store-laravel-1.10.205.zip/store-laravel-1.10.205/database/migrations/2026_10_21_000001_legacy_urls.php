<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** لینک‌های سایت قبلی (حفظ سئو): /product-{id}/{نام} و /category/{id}/{نام} */
return new class extends Migration
{
    /** اجرای امن: اگر جدول/ستون همزمان یا قبلاً ساخته شده باشد، خطا نمی‌دهد */
    private function safe(callable $f): void
    {
        try {
            $f();
        } catch (\Illuminate\Database\QueryException $e) {
            if (! preg_match('/already exists|Duplicate column|Duplicate key name|1050|1060|1061/i', $e->getMessage())) {
                throw $e;
            }
        }
    }

    public function up(): void
    {
        if (! Schema::hasColumn('products', 'legacy_id')) {
            $this->safe(fn () => Schema::table('products', function (Blueprint $t) {
                $t->unsignedBigInteger('legacy_id')->nullable()->index();
                $t->string('legacy_slug', 250)->nullable();
            }));
        }
        if (! Schema::hasColumn('categories', 'legacy_id')) {
            $this->safe(fn () => Schema::table('categories', function (Blueprint $t) {
                $t->unsignedBigInteger('legacy_id')->nullable()->index();
            }));
        }
        try {
            \App\Support\LegacyUrls::backfill();
        } catch (\Throwable $e) {
            report($e); // در همگام‌سازی بعدی دوباره پر می‌شود
        }
    }

    public function down(): void
    {
        Schema::table('products', fn (Blueprint $t) => $t->dropColumn(['legacy_id', 'legacy_slug']));
        Schema::table('categories', fn (Blueprint $t) => $t->dropColumn('legacy_id'));
    }
};
