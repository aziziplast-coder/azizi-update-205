<?php

use Illuminate\Database\Migrations\Migration;

/**
 * به‌جای فرصت ۶ ساعته «ویرایش سفارش» پس از ثبت، پیش از ثبت سفارش از مشتری پرسیده می‌شود «مطمئنید؟ تغییراتی ندارید؟».
 * ← پیام «سفارشتان نیاز به ویرایش دارد؟» در گفتگو خاموش؛ بیعانه بلافاصله پس از ثبت صادر می‌شود.
 */
return new class extends Migration
{
    public function up(): void
    {
        try {
            \App\Support\Settings::set(['dep_when' => 'off', 'order_confirm' => true]);
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void {}
};
