<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * کانال‌های ربات — نسخه ۲:
 * - کد کالای هر پست (عوض شدن کد = حذف پست قبلی و ارسال دوباره)
 * - زمان ناموجود شدن (حذف از کانال پس از چند روز ناموجودی)
 * - فیلدهای انتخابی متن پست و متن ثابت پایین پست
 * - «پاک کردن کل کانال» (و ارسال دوباره) با سرعت حذف جدا
 * - پیام جداگانه «دوباره موجود شد» خاموش؛ فقط همان پست ویرایش می‌شود
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('bot_posts')) {
            foreach (['code' => fn (Blueprint $t) => $t->string('code', 64)->nullable(), 'unavail_at' => fn (Blueprint $t) => $t->timestamp('unavail_at')->nullable()] as $c => $fn) {
                if (! Schema::hasColumn('bot_posts', $c)) {
                    Schema::table('bot_posts', $fn);
                }
            }
        }
        if (Schema::hasTable('bot_profiles')) {
            $cols = [
                'fields' => fn (Blueprint $t) => $t->text('fields')->nullable(),
                'footer' => fn (Blueprint $t) => $t->text('footer')->nullable(),
                'gone_days' => fn (Blueprint $t) => $t->unsignedSmallInteger('gone_days')->nullable(),
                'del_per_hour' => fn (Blueprint $t) => $t->unsignedInteger('del_per_hour')->nullable(),
                'purge' => fn (Blueprint $t) => $t->text('purge')->nullable(),
            ];
            foreach ($cols as $c => $fn) {
                if (! Schema::hasColumn('bot_profiles', $c)) {
                    Schema::table('bot_profiles', $fn);
                }
            }
            // پیام جداگانه «دوباره موجود شد» برای همه کانال‌ها خاموش (پست خودش ویرایش و «موجود» می‌شود)
            if (Schema::hasColumn('bot_profiles', 'restock_notice')) {
                DB::table('bot_profiles')->update(['restock_notice' => false]);
            }
            if (Schema::hasTable('bot_posts') && Schema::hasColumn('bot_posts', 'notice')) {
                DB::table('bot_posts')->where('notice', true)->update(['notice' => false]);
            }
            // متن ثابت پایین پست از روی قالب فعلی هر کانال (خط‌های متغیر کنار گذاشته می‌شوند)
            foreach (DB::table('bot_profiles')->whereNull('footer')->get(['id', 'template']) as $r) {
                $lines = preg_split('/\R/u', (string) $r->template);
                $keep = array_filter($lines, fn ($l) => ! preg_match('/\{(name|barcode|carton|price_line|price|status|tags|date|old_price|discount|category|link)\}/u', $l));
                $footer = trim(preg_replace("/\n{3,}/u", "\n\n", implode("\n", $keep)));
                if ($footer !== '') {
                    DB::table('bot_profiles')->where('id', $r->id)->update(['footer' => $footer]);
                }
            }
        }
    }

    public function down(): void
    {
        foreach (['bot_posts' => ['code', 'unavail_at'], 'bot_profiles' => ['fields', 'footer', 'gone_days', 'del_per_hour', 'purge']] as $tb => $cs) {
            foreach ($cs as $c) {
                if (Schema::hasColumn($tb, $c)) {
                    Schema::table($tb, fn (Blueprint $t) => $t->dropColumn($c));
                }
            }
        }
    }
};
