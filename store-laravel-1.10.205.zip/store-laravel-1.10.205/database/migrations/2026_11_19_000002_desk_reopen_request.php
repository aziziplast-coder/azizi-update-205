<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** درخواست ویرایش بررسی رومیزی از طرف بررسی‌کننده (منتظر اجازه مسئول پیگیری) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('pick_tasks', 'rechecks')) {
            Schema::table('pick_tasks', fn (Blueprint $t) => $t->unsignedTinyInteger('rechecks')->default(0));
        }
        if (! Schema::hasColumn('pick_tasks', 'reopen_req')) {
            Schema::table('pick_tasks', fn (Blueprint $t) => $t->string('reopen_req', 400)->nullable());
        }
        \App\Support\DbSchema::flush();
    }

    public function down(): void {}
};
