<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/* گفتگوی زنده با بازدیدکنندگان سایت (پیام هوشمند خودکار + پاسخ همکاران).
   بازدیدها در دیتابیس نوشته نمی‌شوند (فقط فایل کوچک)؛ فقط گفتگوهایی که واقعاً پیامی دارند اینجا ذخیره می‌شوند. */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('live_chats')) {
            Schema::create('live_chats', function (Blueprint $t) {
                $t->id();
                $t->string('vid', 32)->index();
                $t->string('token', 32)->unique();
                $t->foreignId('user_id')->nullable()->index();
                $t->string('name', 80)->nullable();
                $t->string('mobile', 20)->nullable();
                $t->string('status', 10)->default('open')->index(); // open | closed
                $t->unsignedInteger('unread_staff')->default(0);
                $t->unsignedInteger('unread_visitor')->default(0);
                $t->string('last_side', 1)->nullable();
                $t->string('last_text', 200)->nullable();
                $t->timestamp('last_at')->nullable()->index();
                $t->text('page')->nullable();       // صفحه‌ای که گفتگو از آن شروع شد (json)
                $t->string('rule', 20)->nullable(); // پیام خودکاری که گفتگو را شروع کرد
                $t->foreignId('staff_id')->nullable();
                $t->string('ip', 45)->nullable();
                $t->string('device', 60)->nullable();
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('live_messages')) {
            Schema::create('live_messages', function (Blueprint $t) {
                $t->id();
                $t->foreignId('live_chat_id')->index();
                $t->string('side', 1); // v بازدیدکننده | s همکار | a خودکار
                $t->foreignId('user_id')->nullable();
                $t->text('body');
                $t->text('meta')->nullable();
                $t->timestamp('created_at')->nullable();
            });
        }
        // دسترسی «گفتگوی زنده» خودکار به کسی داده نمی‌شود؛ مدیر از فرم کارکنان تیک می‌زند
    }

    public function down(): void
    {
        Schema::dropIfExists('live_messages');
        Schema::dropIfExists('live_chats');
    }
};
