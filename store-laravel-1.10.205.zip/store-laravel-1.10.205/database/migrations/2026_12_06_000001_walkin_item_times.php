<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/** ترتیب اسکن و ترتیب تحویل هر قلم (برای چینش اکسل و فهرست تحویل) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('walkin_items', 's_at')) {
            Schema::table('walkin_items', function (Blueprint $t) {
                // میلی‌ثانیه (epoch) تا ترتیب اسکن‌های پشت‌سرهم در یک ثانیه هم درست بماند
                $t->unsignedBigInteger('s_at')->nullable();
                $t->unsignedBigInteger('d_at')->nullable();
            });
            DB::table('walkin_items')->select(['id', 'units', 'd_units', 'created_at', 'updated_at'])->orderBy('id')->chunkById(500, function ($rows) {
                foreach ($rows as $r) {
                    $up = [];
                    if ((int) $r->units > 0 && $r->created_at) {
                        $up['s_at'] = strtotime($r->created_at) * 1000;
                    }
                    if ((int) $r->d_units > 0 && $r->updated_at) {
                        $up['d_at'] = strtotime($r->updated_at) * 1000;
                    }
                    if ($up) {
                        DB::table('walkin_items')->where('id', $r->id)->update($up);
                    }
                }
            });
        }
    }

    public function down(): void {}
};
