<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** حواله‌های کارخانه و پرداخت‌های مشتریان به آن‌ها (بیعانه و تسویه) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('remittances')) {
            Schema::create('remittances', function (Blueprint $t) {
                $t->id();
                $t->string('code', 30)->nullable()->index();
                $t->string('title', 190);
                $t->unsignedBigInteger('amount');
                $t->string('holder_name', 120)->nullable();
                $t->string('bank_name', 60)->nullable();
                $t->string('card_number', 19)->nullable();
                $t->string('sheba', 34)->nullable();
                $t->unsignedBigInteger('assignee_id')->nullable()->index();
                $t->unsignedBigInteger('created_by')->nullable();
                $t->unsignedBigInteger('parent_id')->nullable()->index();
                $t->string('status', 20)->default('active')->index();
                $t->integer('sort')->default(0);
                $t->text('note')->nullable();
                $t->timestamp('filled_at')->nullable();
                $t->timestamp('closed_at')->nullable();
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('remit_payments')) {
            Schema::create('remit_payments', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('remittance_id')->index();
                $t->unsignedBigInteger('order_id')->index();
                $t->unsignedBigInteger('user_id')->nullable()->index();
                $t->string('kind', 12)->default('deposit');
                $t->unsignedBigInteger('amount');
                $t->string('status', 16)->default('awaiting')->index();
                $t->string('receipt_path')->nullable();
                $t->string('receipt_ref', 80)->nullable();
                $t->string('paid_on', 30)->nullable();
                $t->string('customer_note', 300)->nullable();
                $t->string('reject_reason', 300)->nullable();
                $t->unsignedBigInteger('issued_by')->nullable();
                $t->unsignedBigInteger('reviewed_by')->nullable();
                $t->timestamp('submitted_at')->nullable();
                $t->timestamp('reviewed_at')->nullable();
                $t->timestamps();
            });
        }
        if (Schema::hasTable('users') && ! Schema::hasColumn('users', 'acc_settings')) {
            Schema::table('users', fn (Blueprint $t) => $t->text('acc_settings')->nullable());
        }
        if (Schema::hasTable('orders') && ! Schema::hasColumn('orders', 'final_amount')) {
            Schema::table('orders', fn (Blueprint $t) => $t->unsignedBigInteger('final_amount')->nullable());
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('remit_payments');
        Schema::dropIfExists('remittances');
    }
};
