<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * واحد فروش کالا («جفت»، «دست ۶ عددی»، «پک ۳ عددی») + قیمت لحظه افزودن به سبد (برای نمایش تغییر قیمت)
 * + واحد در اقلام سفارش. واحد کالاهای فعلی از «تعداد در کارتن» نمایشی JSON خودکار پر می‌شود.
 */
return new class extends Migration
{
    protected function add(string $table, string $col, callable $def): void
    {
        if (! Schema::hasTable($table) || Schema::hasColumn($table, $col)) {
            return;
        }
        try {
            Schema::table($table, fn (Blueprint $t) => $def($t));
        } catch (\Illuminate\Database\QueryException $e) {
            if (! preg_match('/Duplicate column|1060|already exists/i', $e->getMessage())) {
                throw $e;
            }
        }
    }

    public function up(): void
    {
        $this->add('products', 'unit_label', fn (Blueprint $t) => $t->string('unit_label', 40)->nullable());
        $this->add('products', 'unit_manual', fn (Blueprint $t) => $t->boolean('unit_manual')->default(false));
        $this->add('order_items', 'unit_label', fn (Blueprint $t) => $t->string('unit_label', 40)->nullable());
        $this->add('carts', 'prices', fn (Blueprint $t) => $t->json('prices')->nullable());

        // پر کردن خودکار واحد از «تعداد در کارتن» نمایشی (مثل «۱۲ جفت» یا «۱۲ دست ۶ عددی»)
        try {
            \App\Models\Product::query()->whereNull('unit_label')->whereNotNull('specs')->select(['id', 'specs'])
                ->chunkById(500, function ($rows) {
                    foreach ($rows as $p) {
                        $u = \App\Models\Product::unitFromText((string) (((array) $p->specs)['تعداد در کارتن'] ?? ''));
                        if ($u) {
                            \App\Models\Product::query()->whereKey($p->id)->update(['unit_label' => $u]);
                        }
                    }
                });
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void
    {
    }
};
