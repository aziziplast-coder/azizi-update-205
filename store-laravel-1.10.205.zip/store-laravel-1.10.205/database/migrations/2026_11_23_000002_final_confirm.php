<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * تأیید نهایی سفارش: «در انتظار تسویه» ← «در حال ارسال به باربری» فقط وقتی همه فیش‌های بیعانه و تسویه
 * به تأیید کارخانه‌دار رسیده (یا حواله کارخانه‌دار ندارد، یا حسابدار کل دستی تأیید کرده).
 * وضعیت «در صف ارسال به باربری» حذف می‌شود؛ سفارش‌های فعلی آن منتقل می‌شوند.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('orders', 'final_ok_at')) {
            Schema::table('orders', function (Blueprint $t) {
                $t->timestamp('final_ok_at')->nullable();
                $t->unsignedBigInteger('final_ok_by')->nullable();
            });
        }
        // سفارش‌هایی که همین حالا «در صف ارسال» هستند با قانون قبلی تأیید شده بودند ← «در حال ارسال به باربری» (آماده بارگیری)
        try {
            foreach (\App\Models\Order::query()->where('status', 'to_freight')->get() as $o) {
                $o->forceFill(['status' => 'shipped'])->saveQuietly();
                $o->log('وضعیت «در صف ارسال به باربری» حذف شد ← «در حال ارسال به باربری»'.($o->loaded_at ? '' : ' (آماده بارگیری در کارتابل سرپرست)'));
            }
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void {}
};
