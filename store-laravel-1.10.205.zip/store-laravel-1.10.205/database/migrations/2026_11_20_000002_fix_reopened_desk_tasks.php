<?php

use Illuminate\Database\Migrations\Migration;

/**
 * حواله‌ای که روی میز بررسی تأیید شده بود و از صفحه سفارش «بازگشایی برای اصلاح» خورده،
 * به کارتابل انباردار برگشته بود (مثل سفارش ۱۱۲۲ — انباردارش هم غیرفعال است) و گیر کرده بود.
 * ← به صف «ویرایش پس از تأیید» میز بررسی همان سالن منتقل می‌شود.
 */
return new class extends Migration
{
    public function up(): void
    {
        try {
            $tasks = \App\Models\PickTask::query()->where('status', '!=', 'done')->whereNull('stage')->whereNotNull('checked_at')->get();
            foreach ($tasks as $t) {
                if (! \App\Services\Picking::deskChecked($t) || ! $t->order || in_array($t->order->status, ['cancelled', 'failed', 'completed'], true)) {
                    continue;
                }
                $t->forceFill(['stage' => 'desk'] + (\App\Support\DbSchema::hasColumn('pick_tasks', 'rechecks') ? ['rechecks' => (int) $t->rechecks + 1] : []))->save();
                $t->order->log('حواله بازگشایی‌شده به صف «ویرایش پس از تأیید» میز بررسی '.\App\Services\Picking::hallName(\App\Services\Picking::taskHall($t)).' منتقل شد (به‌جای کارتابل انباردار)');
            }
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void {}
};
