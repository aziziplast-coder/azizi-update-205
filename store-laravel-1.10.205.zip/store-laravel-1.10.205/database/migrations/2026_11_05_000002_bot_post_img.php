<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** امضای عکس‌های پست کانال: عکس کالا عوض شد = پست قبلی پاک و پست تازه با عکس جدید فرستاده می‌شود */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('bot_posts') && ! Schema::hasColumn('bot_posts', 'img')) {
            Schema::table('bot_posts', fn (Blueprint $t) => $t->string('img', 16)->nullable());
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('bot_posts', 'img')) {
            Schema::table('bot_posts', fn (Blueprint $t) => $t->dropColumn('img'));
        }
    }
};
