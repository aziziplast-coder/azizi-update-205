<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * - پیش از صدور بیعانه: سؤال «فاکتورتان را تغییر می‌دهید؟» در گفتگو (deposit_ask: ask | edit | done)
 * - پیوست فاکتور: اقلامی که پس از ویرایش/کسری انبار (جایگزین یا خرید اضافه) به سفارش افزوده شده‌اند
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('orders', 'deposit_ask')) {
            Schema::table('orders', function (Blueprint $t) {
                $t->string('deposit_ask', 8)->nullable();
                $t->timestamp('deposit_asked_at')->nullable();
            });
        }
        if (! Schema::hasColumn('order_items', 'appendix')) {
            Schema::table('order_items', fn (Blueprint $t) => $t->boolean('appendix')->default(false));
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('orders', 'deposit_ask')) {
            Schema::table('orders', fn (Blueprint $t) => $t->dropColumn(['deposit_ask', 'deposit_asked_at']));
        }
        if (Schema::hasColumn('order_items', 'appendix')) {
            Schema::table('order_items', fn (Blueprint $t) => $t->dropColumn('appendix'));
        }
    }
};
