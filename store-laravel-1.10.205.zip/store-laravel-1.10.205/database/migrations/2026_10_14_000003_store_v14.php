<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** نسخه ۱.۴: فیلدهای دلخواه سفارش، آمار بازدید ساعتی، نشان مجموعه‌ها */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('orders', 'custom_fields')) {
            Schema::table('orders', fn (Blueprint $t) => $t->json('custom_fields')->nullable());
        }
        if (! Schema::hasTable('product_view_stats')) {
            // بازدید هر کالا در هر ساعت (برای «پربازدیدترین‌های ۲۴ ساعت / هفته اخیر»)
            Schema::create('product_view_stats', function (Blueprint $t) {
                $t->unsignedBigInteger('product_id');
                $t->dateTime('hour');
                $t->unsignedInteger('views')->default(0);
                $t->primary(['product_id', 'hour']);
                $t->index('hour');
            });
        }
        if (! Schema::hasColumn('collections', 'badge')) {
            Schema::table('collections', function (Blueprint $t) {
                $t->string('badge', 40)->nullable();
                $t->string('badge_color', 20)->nullable();
            });
        }
    }

    public function down(): void
    {
    }
};
