<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** کالای JSON که دستی «با تصویر کامل» ساخته شده (حتی اگر ناموجود است) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('sync_items', 'full_img')) {
            try {
                Schema::table('sync_items', fn (Blueprint $t) => $t->boolean('full_img')->default(false));
            } catch (\Illuminate\Database\QueryException $e) {
                if (! preg_match('/Duplicate column|1060|already exists/i', $e->getMessage())) {
                    throw $e;
                }
            }
        }
    }

    public function down(): void
    {
        Schema::table('sync_items', fn (Blueprint $t) => $t->dropColumn('full_img'));
    }
};
