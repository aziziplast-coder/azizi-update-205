<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * ستون تاریخچه سفارش ۵۰۰ نویسه بود؛ متن ویرایش چندقلمی (مثلاً ۱۳ قلم) جا نمی‌شد و عملیات با خطا می‌شکست
 * (سفارش ۱۱۳۸: اقلام اضافه و حواله صادر می‌شد ولی پاسخ خطا بود و با تکرار «ثبت» سه بار اضافه شد).
 */
return new class extends Migration
{
    public function up(): void
    {
        try {
            Schema::table('order_events', function (Blueprint $t) {
                $t->text('message')->change();
            });
            \App\Support\Settings::set(['order_events_text' => 1]);
        } catch (\Throwable $e) {
            report($e); // اگر تغییر ستون ممکن نشد، Order::log متن را به ۵۰۰ نویسه کوتاه می‌کند
        }
    }

    public function down(): void {}
};
