<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* مشاوران فروش: لینک بازاریابی، مشتریان هر مشاور، پورسانت پله‌ای، کیف پول و تسویه، شماره حساب */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('advisors')) {
            Schema::create('advisors', function (Blueprint $t) {
                $t->id();
                $t->foreignId('user_id')->unique();
                $t->string('code', 32)->unique();
                $t->boolean('active')->default(true);
                $t->decimal('rate', 5, 2)->nullable();      // درصد اختصاصی (خالی = پله‌های عمومی)
                $t->unsignedBigInteger('target')->nullable(); // هدف فروش ماهانه (تومان)
                $t->unsignedBigInteger('bonus')->nullable();  // پاداش رسیدن به هدف (تومان)
                $t->string('bank_holder', 80)->nullable();
                $t->string('bank_sheba', 26)->nullable();
                $t->string('bank_card', 16)->nullable();
                $t->string('bank_name', 40)->nullable();
                $t->text('bank_new')->nullable();             // تغییر حساب در انتظار تأیید مدیر
                $t->timestamp('bank_ok_at')->nullable();
                $t->timestamps();
            });
        }
        Schema::table('users', function (Blueprint $t) {
            if (! Schema::hasColumn('users', 'advisor_id')) {
                $t->unsignedBigInteger('advisor_id')->nullable()->index(); // مشاورِ صاحب این مشتری (users.id)
                $t->timestamp('advisor_at')->nullable();
                $t->string('advisor_src', 8)->nullable();  // link | chat | manual | crm | order
            }
        });
        Schema::table('orders', function (Blueprint $t) {
            if (! Schema::hasColumn('orders', 'advisor_id')) {
                $t->unsignedBigInteger('advisor_id')->nullable()->index();
                $t->string('advisor_src', 8)->nullable();
            }
        });
        if (! Schema::hasTable('commissions')) {
            Schema::create('commissions', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('advisor_id')->index(); // users.id
                $t->unsignedBigInteger('order_id')->unique();
                $t->unsignedBigInteger('base')->default(0);
                $t->decimal('rate', 5, 2)->default(0);
                $t->unsignedBigInteger('amount')->default(0);
                $t->string('status', 10)->default('pending')->index(); // pending | earned | void
                $t->string('src', 8)->nullable();
                $t->boolean('first')->default(false);
                $t->timestamp('earned_at')->nullable();
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('wallet_tx')) {
            Schema::create('wallet_tx', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('user_id')->index();
                $t->string('type', 12); // commission | payout | bonus | adjust
                $t->bigInteger('amount');
                $t->unsignedBigInteger('commission_id')->nullable()->index();
                $t->string('ref', 60)->nullable();
                $t->string('receipt')->nullable();
                $t->string('note', 300)->nullable();
                $t->unsignedBigInteger('by_id')->nullable();
                $t->string('period', 7)->nullable(); // پاداش ماهانه: 1405-08
                $t->timestamp('created_at')->nullable();
            });
        }
        if (! Schema::hasTable('advisor_stats')) {
            Schema::create('advisor_stats', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('advisor_id');
                $t->date('day');
                $t->unsignedInteger('clicks')->default(0);
                $t->unsignedInteger('signups')->default(0);
                $t->unique(['advisor_id', 'day']);
            });
        }
    }

    public function down(): void {}
};
