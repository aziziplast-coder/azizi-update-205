<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** سالن بررسی رومیزی هر حواله (بر اساس انبارداری که جمع کرده) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('pick_tasks', 'hall')) {
            Schema::table('pick_tasks', fn (Blueprint $t) => $t->string('hall', 20)->nullable());
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('pick_tasks', 'hall')) {
            Schema::table('pick_tasks', fn (Blueprint $t) => $t->dropColumn('hall'));
        }
    }
};
