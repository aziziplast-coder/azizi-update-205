<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * - desk_at: زمان تأیید هر قلم در بررسی رومیزی (ترتیب خروجی هلو = ترتیب بررسی)
 * - bags / boxes: تعداد کیسه و کارتن بار پس از بررسی رومیزی (سالن خرده‌ریز)
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('order_items', 'desk_at')) {
            Schema::table('order_items', fn (Blueprint $t) => $t->timestamp('desk_at')->nullable());
        }
        if (! Schema::hasColumn('pick_tasks', 'bags')) {
            Schema::table('pick_tasks', function (Blueprint $t) {
                $t->unsignedSmallInteger('bags')->nullable();
                $t->unsignedSmallInteger('boxes')->nullable();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('order_items', 'desk_at')) {
            Schema::table('order_items', fn (Blueprint $t) => $t->dropColumn('desk_at'));
        }
        if (Schema::hasColumn('pick_tasks', 'bags')) {
            Schema::table('pick_tasks', fn (Blueprint $t) => $t->dropColumn(['bags', 'boxes']));
        }
    }
};
