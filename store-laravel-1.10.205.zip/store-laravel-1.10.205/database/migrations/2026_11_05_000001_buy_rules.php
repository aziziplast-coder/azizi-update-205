<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * قانون خرید عمده: حداقل خرید و گام افزایش
 *  - هر انبار: قانون بر اساس بازه قیمت (مثلاً ۱٬۰۰۰ تا ۱۰۰٬۰۰۰ تومان → حداقل ۱۲ عدد)
 *  - هر کالا: «طبق انبار» یا «کارتن کامل» / «بسته‌ای (هر N عدد)» / «فله (حداقل N، بعد یکی‌یکی)»
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('products', 'buy_mode')) {
            Schema::table('products', function (Blueprint $t) {
                $t->string('buy_mode', 8)->nullable();              // null = طبق قانون انبار | carton | pack | bulk
                $t->unsignedInteger('buy_qty')->nullable();         // N (خالی = تعداد در کارتن)
            });
        }
        if (! Schema::hasColumn('warehouses', 'buy_rules')) {
            Schema::table('warehouses', fn (Blueprint $t) => $t->json('buy_rules')->nullable());
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('products', 'buy_mode')) {
            Schema::table('products', fn (Blueprint $t) => $t->dropColumn(['buy_mode', 'buy_qty']));
        }
        if (Schema::hasColumn('warehouses', 'buy_rules')) {
            Schema::table('warehouses', fn (Blueprint $t) => $t->dropColumn('buy_rules'));
        }
    }
};
