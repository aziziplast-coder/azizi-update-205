<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** ایندکس‌های پرکاربرد پنل (فهرست سفارش‌ها، داشبورد، اقلام سفارش) برای سرعت با حجم زیاد داده */
return new class extends Migration
{
    protected function index(string $table, array $cols): void
    {
        if (! Schema::hasTable($table)) {
            return;
        }
        foreach ($cols as $c) {
            if (! Schema::hasColumn($table, $c)) {
                return;
            }
        }
        try {
            foreach (Schema::getIndexes($table) as $ix) {
                if (array_values($ix['columns']) === array_values($cols) || (count($cols) === 1 && ($ix['columns'][0] ?? null) === $cols[0])) {
                    return; // قبلاً هست (یا ایندکسی که با همین ستون شروع می‌شود)
                }
            }
            Schema::table($table, fn (Blueprint $t) => $t->index($cols, $table.'_'.implode('_', $cols).'_speed'));
        } catch (\Throwable $e) {
            if (! preg_match('/Duplicate key name|already exists|1061/i', $e->getMessage())) {
                report($e);
            }
        }
    }

    public function up(): void
    {
        $this->index('orders', ['status', 'created_at']);
        $this->index('orders', ['created_at']);
        $this->index('orders', ['user_id']);
        $this->index('order_items', ['order_id']);
        $this->index('order_items', ['product_id']);
        $this->index('products', ['category_id']);
        $this->index('products', ['barcode']);
        $this->index('reviews', ['is_approved']);
    }

    public function down(): void {}
};
