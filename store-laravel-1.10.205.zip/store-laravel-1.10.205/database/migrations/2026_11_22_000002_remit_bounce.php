<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * پول برگشتی (مثلاً حساب اتباع که هر واریز را برمی‌گرداند):
 * - remit_payments.bounce: کارت «واریز مجدد حواله برگشتی» (قابل ابطال توسط اپراتور نیست)
 * - remit_payments.alt_account: حساب جدید کارخانه برای همین واریز (در همان حواله حساب می‌شود)
 * - factories.terms_ack_*: تأیید «متوجه شدم» شرایط حسابداری توسط کارخانه‌دار
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('remit_payments', 'bounce')) {
            Schema::table('remit_payments', function (Blueprint $t) {
                $t->boolean('bounce')->default(false);
                $t->unsignedBigInteger('bounce_of')->nullable();
                $t->text('alt_account')->nullable();
            });
        }
        if (Schema::hasTable('factories') && ! Schema::hasColumn('factories', 'terms_ack_at')) {
            Schema::table('factories', function (Blueprint $t) {
                $t->timestamp('terms_ack_at')->nullable();
                $t->string('terms_ack_v', 40)->nullable();
            });
        }
    }

    public function down(): void {}
};
