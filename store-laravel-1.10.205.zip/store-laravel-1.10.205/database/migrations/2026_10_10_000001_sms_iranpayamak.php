<?php

use App\Models\Setting;
use App\Support\Settings;
use Illuminate\Database\Migrations\Migration;

/** پنل فراز به وب‌سرویس جدید ایران پیامک منتقل شده؛ پنل‌های «فراز» قبلی به درایور جدید برده می‌شوند. */
return new class extends Migration
{
    public function up(): void
    {
        $row = Setting::query()->where('key', 'sms_gateways')->first();
        if (! $row) {
            return;
        }
        $list = json_decode((string) $row->value, true);
        if (! is_array($list)) {
            return;
        }
        $changed = false;
        foreach ($list as &$g) {
            if (($g['type'] ?? '') === 'faraz') {
                $g['type'] = 'iranpayamak';
                $changed = true;
            }
        }
        unset($g);
        if ($changed) {
            Settings::set(['sms_gateways' => $list]);
        }
    }

    public function down(): void
    {
    }
};
