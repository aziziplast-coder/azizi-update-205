<?php

use App\Support\Settings;
use Illuminate\Database\Migrations\Migration;

/** تنظیمات پیش‌فرض نسخه ۱.۴ */
return new class extends Migration
{
    public function up(): void
    {
        try {
            // نمایش پیش‌فرض کالاها در گوشی: ردیفی (افقی)
            Settings::set(['mobile_view' => 'list']);
        } catch (\Throwable) {
        }
    }

    public function down(): void
    {
    }
};
