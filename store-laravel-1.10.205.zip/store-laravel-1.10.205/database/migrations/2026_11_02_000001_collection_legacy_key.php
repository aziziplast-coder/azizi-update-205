<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** شناسه مجموعه در سایت قدیمی (لینک JSON ربات: index.php?p=specificAdds&what=…&id=…&json=true) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('collections', 'legacy_key')) {
            Schema::table('collections', function (Blueprint $t) {
                $t->string('legacy_key', 60)->nullable()->index();
            });
        }
    }

    public function down(): void
    {
        Schema::table('collections', fn (Blueprint $t) => $t->dropColumn('legacy_key'));
    }
};
