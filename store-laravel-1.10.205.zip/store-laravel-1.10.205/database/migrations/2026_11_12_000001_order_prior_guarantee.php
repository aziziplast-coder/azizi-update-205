<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * - مانده قبلی مشتری در هلو (طلب/بدهی) که در بیعانه/مانده حساب لحاظ می‌شود
 * - مشتری جدید و «چک ضمانت» (عکس چک + شماره صیاد)
 * - مقصد بار (نزدیک‌ترین شهری که باربری دارد) در تسویه نهایی
 */
return new class extends Migration
{
    public function up(): void
    {
        $cols = [
            'holoo_bal' => fn (Blueprint $t) => $t->bigInteger('holoo_bal')->nullable(),   // + بدهکار به ما، − طلبکار
            'holoo_dep' => fn (Blueprint $t) => $t->boolean('holoo_dep')->default(false),  // در بیعانه لحاظ شد
            'new_customer' => fn (Blueprint $t) => $t->boolean('new_customer')->default(false),
            'guarantee' => fn (Blueprint $t) => $t->text('guarantee')->nullable(),
            'freight_dest' => fn (Blueprint $t) => $t->string('freight_dest', 120)->nullable(),
        ];
        foreach ($cols as $c => $fn) {
            if (! Schema::hasColumn('orders', $c)) {
                Schema::table('orders', $fn);
            }
        }
    }

    public function down(): void
    {
        foreach (['holoo_bal', 'holoo_dep', 'new_customer', 'guarantee', 'freight_dest'] as $c) {
            if (Schema::hasColumn('orders', $c)) {
                Schema::table('orders', fn (Blueprint $t) => $t->dropColumn($c));
            }
        }
    }
};
