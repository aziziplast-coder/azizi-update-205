<?php

use Illuminate\Database\Migrations\Migration;

/** فرصت افزودن/جایگزینی پس از جمع‌آوری: ۶ ساعت (اپراتور در گفتگو تغییرش می‌دهد) */
return new class extends Migration
{
    public function up(): void
    {
        try {
            // سفارش‌های قدیمی که مهلتشان پیش از این نسخه تمام شده، خودکار مانده حساب نمی‌گیرند
            \App\Support\Settings::set(['replace_hours' => 6, 'replace_enabled' => true, 'addwin_since' => now()->timestamp]);
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void {}
};
