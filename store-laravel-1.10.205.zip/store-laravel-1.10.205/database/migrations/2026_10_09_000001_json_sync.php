<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** ماژول همگام‌سازی با JSON تأمین‌کننده */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sync_sources', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->text('url');
            $t->boolean('enabled')->default(false);
            $t->unsignedInteger('interval')->default(60); // دقیقه
            $t->json('options')->nullable();   // نگاشت فیلدها، قیمت‌گذاری، تصاویر، سیاست‌ها
            $t->json('state')->nullable();     // وضعیت اجرای جاری
            $t->json('stats')->nullable();     // آمار آخرین اجرا
            $t->json('log')->nullable();
            $t->timestamp('last_run_at')->nullable();
            $t->timestamp('last_ok_at')->nullable();
            $t->timestamps();
        });

        Schema::create('sync_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('source_id')->constrained('sync_sources')->cascadeOnDelete();
            $t->string('code', 120);
            $t->unsignedBigInteger('product_id')->nullable()->index();
            $t->string('title')->nullable();
            $t->string('category')->nullable();
            $t->decimal('raw_price', 16, 2)->default(0);
            $t->unsignedBigInteger('price')->default(0);        // قیمت نهایی (تومان)
            $t->unsignedBigInteger('retail_price')->nullable();
            $t->float('markup')->nullable();
            $t->integer('stock_retail')->default(0);
            $t->integer('stock_wholesale')->default(0);
            $t->unsignedInteger('per_carton')->default(1);
            $t->json('images')->nullable();
            $t->json('extra')->nullable();
            $t->string('hash', 40)->nullable();
            $t->string('status', 20)->default('new');           // new | created | updated | unchanged | skipped | error | removed
            $t->string('reason', 40)->nullable();
            $t->string('message', 500)->nullable();
            $t->string('force', 5)->nullable();                 // in | out (اصلاح دستی)
            $t->float('markup_override')->nullable();           // درصد اختصاصی (مثلاً از اکسل)
            $t->string('image_status', 20)->nullable();         // ok | failed | pending | none
            $t->string('image_error', 300)->nullable();
            $t->unsignedTinyInteger('image_tries')->default(0);
            $t->unsignedBigInteger('price_first')->nullable();
            $t->unsignedBigInteger('price_prev')->nullable();
            $t->boolean('in_feed')->default(true);
            $t->string('run', 20)->nullable();
            $t->timestamp('price_changed_at')->nullable();
            $t->timestamps();
            $t->unique(['source_id', 'code']);
            $t->index(['source_id', 'status']);
        });

        Schema::create('sync_price_changes', function (Blueprint $t) {
            $t->id();
            $t->foreignId('source_id')->constrained('sync_sources')->cascadeOnDelete();
            $t->string('code', 120);
            $t->unsignedBigInteger('product_id')->nullable();
            $t->string('title')->nullable();
            $t->decimal('raw_old', 16, 2)->nullable();
            $t->decimal('raw_new', 16, 2)->nullable();
            $t->unsignedBigInteger('old_price')->nullable();
            $t->unsignedBigInteger('new_price')->nullable();
            $t->timestamp('created_at')->nullable()->index();
        });

        Schema::table('products', function (Blueprint $t) {
            $t->unsignedBigInteger('sync_source_id')->nullable()->index();
            $t->string('sync_code', 120)->nullable()->index();
            $t->boolean('sync_locked')->default(false); // قیمت/نام دستی؛ همگام‌سازی تغییرش ندهد
        });
    }

    public function down(): void
    {
        Schema::table('products', fn (Blueprint $t) => $t->dropColumn(['sync_source_id', 'sync_code', 'sync_locked']));
        Schema::dropIfExists('sync_price_changes');
        Schema::dropIfExists('sync_items');
        Schema::dropIfExists('sync_sources');
    }
};
