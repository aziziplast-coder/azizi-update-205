<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * ربات کانال روی هاست جدا: «مغز» (چه کالایی ارسال/ویرایش/حذف شود، متن، زمان‌بندی) روی سایت است
 * و برنامه کوچک روی هاست ربات فقط کارها را از سایت می‌گیرد و در بله انجام می‌دهد.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('bot_profiles')) {
            Schema::create('bot_profiles', function (Blueprint $t) {
                $t->id();
                $t->string('name', 120);
                $t->string('key', 40)->unique();                 // نام کانال در تنظیمات هاست ربات (مثلاً haraji)
                $t->string('platform', 12)->default('bale');
                $t->string('chat_id', 64)->nullable();            // فقط برای نمایش؛ کانال واقعی روی هاست ربات تعیین می‌شود
                $t->boolean('enabled')->default(false);
                $t->string('source', 12)->default('collection');  // collection | all
                $t->unsignedBigInteger('collection_id')->nullable();
                $t->boolean('only_wholesale')->default(true);     // «موجود» یعنی موجود برای فروش عمده (کارتنی)
                $t->string('on_unavailable', 8)->default('mark'); // mark = ویرایش وضعیت، delete = حذف پست
                $t->unsignedTinyInteger('max_images')->default(1); // ۱ = تک‌عکس با دکمه؛ بیشتر = آلبوم
                $t->boolean('text_fallback')->default(false);     // اگر عکس آماده نشد، بدون عکس ارسال شود؟
                $t->text('template')->nullable();
                $t->string('button_text', 60)->nullable();
                $t->string('button_url', 300)->nullable();
                $t->string('quiet_from', 5)->nullable();          // ساعت خاموشی (تهران)
                $t->string('quiet_to', 5)->nullable();
                $t->unsignedSmallInteger('per_hour')->default(120); // سقف ارسال/ویرایش در ساعت
                $t->boolean('approve_new')->default(false);       // کالای تازه اول در پنل تأیید شود
                $t->boolean('restock_notice')->default(true);     // «🔔 دوباره موجود شد» در کانال
                $t->string('daily_at', 5)->nullable();            // ساعت خلاصه روزانه «جدیدهای امروز» (خالی = خاموش)
                $t->date('daily_done')->nullable();
                $t->json('stats')->nullable();
                $t->timestamp('imported_at')->nullable();
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('bot_broadcasts')) {
            // پیام دستی/زمان‌بندی‌شده، خلاصه روزانه و پیام آزمایشی
            Schema::create('bot_broadcasts', function (Blueprint $t) {
                $t->id();
                $t->string('kind', 10)->default('manual');        // manual | daily | test
                $t->string('title', 150)->nullable();
                $t->text('text')->nullable();
                $t->string('image', 300)->nullable();
                $t->json('product_ids')->nullable();               // آلبوم کالاها (خلاصه روزانه)
                $t->json('profile_ids');
                $t->string('button_text', 60)->nullable();
                $t->string('button_url', 300)->nullable();
                $t->timestamp('send_at')->nullable();
                $t->string('status', 10)->default('queued');       // queued | done | cancelled
                $t->json('results')->nullable();                   // {profile_id: {ok, mid, error, at}}
                $t->unsignedBigInteger('created_by')->nullable();
                $t->timestamps();
                $t->index(['status', 'send_at']);
            });
        }
        if (! Schema::hasColumn('orders', 'bot_src')) {
            Schema::table('orders', fn (Blueprint $t) => $t->unsignedInteger('bot_src')->nullable()->index()); // سفارش از کلیک کانال ربات
        }
        if (! Schema::hasTable('bot_posts')) {
            Schema::create('bot_posts', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('profile_id');
                $t->unsignedBigInteger('product_id')->nullable();
                $t->unsignedBigInteger('legacy_id')->nullable();   // شناسه کالا در سایت قبلی (پست‌های ربات قدیمی)
                $t->string('message_id', 40)->nullable();
                $t->json('extra_ids')->nullable();                 // بقیه پیام‌های آلبوم
                $t->string('kind', 8)->nullable();                 // photo | text | album | ?
                $t->string('hash', 32)->nullable();                // آخرین چیزی که در کانال است
                $t->boolean('avail')->default(false);
                $t->unsignedBigInteger('last_price')->nullable();  // قیمتی که الان در کانال است (برای «قیمت کاهش یافت»)
                $t->boolean('notice')->default(false);              // پس از ویرایش، پیام «دوباره موجود شد»
                // ok | new | edit | delete | repost | gone (حذف شد چون ناموجود) | skip | failed
                $t->string('state', 8)->default('new');
                $t->unsignedTinyInteger('attempts')->default(0);
                $t->string('last_error', 300)->nullable();
                $t->timestamp('next_try_at')->nullable();
                $t->timestamp('lease_until')->nullable();
                $t->timestamp('sent_at')->nullable();
                $t->timestamps();
                $t->unique(['profile_id', 'product_id']);
                $t->index(['profile_id', 'state']);
                $t->index(['profile_id', 'legacy_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('bot_posts');
        Schema::dropIfExists('bot_broadcasts');
        Schema::dropIfExists('bot_profiles');
    }
};
