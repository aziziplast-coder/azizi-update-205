<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * نوع انبار: عمده (کارتنی) یا خرده (تکی). شماره انبار در هر نوع جداست (انبار ۷ عمده ≠ انبار ۷ خرده).
 * انبارهایی که نسخه ۱.۴.۱ با نام «انبار شماره …» ساخته بود، بر اساس استفاده جدا می‌شوند.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('warehouses', 'kind')) {
            Schema::table('warehouses', fn (Blueprint $t) => $t->string('kind', 10)->nullable()); // carton | retail | null (هر دو)
        }
        foreach (DB::table('warehouses')->where('name', 'like', 'انبار شماره %')->whereNull('kind')->get() as $w) {
            $asCarton = DB::table('products')->where('warehouse_id', $w->id)->exists();
            $asRetail = DB::table('products')->where('retail_warehouse_id', $w->id)->exists();
            $num = preg_replace('/^انبار شماره\s*/u', '', $w->name);
            if ($asRetail && ! $asCarton) {
                DB::table('warehouses')->where('id', $w->id)->update(['kind' => 'retail', 'name' => 'انبار خرده '.$num]);

                continue;
            }
            DB::table('warehouses')->where('id', $w->id)->update(['kind' => 'carton', 'name' => 'انبار عمده '.$num]);
            if ($asRetail) {
                $rid = DB::table('warehouses')->insertGetId(['name' => 'انبار خرده '.$num, 'code' => $w->code, 'kind' => 'retail', 'is_active' => true, 'created_at' => now(), 'updated_at' => now()]);
                DB::table('products')->where('retail_warehouse_id', $w->id)->update(['retail_warehouse_id' => $rid]);
                DB::table('order_items')->where('warehouse_id', $w->id)->where('mode', 'retail')->update(['warehouse_id' => $rid]);
            }
        }
    }

    public function down(): void
    {
    }
};
