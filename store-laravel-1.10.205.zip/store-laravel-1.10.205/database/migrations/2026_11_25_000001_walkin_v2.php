<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * اسکن و تحویل (نسخه ۲): ارجاع بار به تحویل‌دهنده توسط سرپرست (خالی = همه تحویل‌دهنده‌ها)
 * و «پایان» فاکتور از کارتابل دفتر در هر مرحله.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('walkin_sales')) {
            return;
        }
        Schema::table('walkin_sales', function (Blueprint $t) {
            if (! Schema::hasColumn('walkin_sales', 'assigned_to')) {
                $t->unsignedBigInteger('assigned_to')->nullable();
            }
            if (! Schema::hasColumn('walkin_sales', 'assigned_by')) {
                $t->unsignedBigInteger('assigned_by')->nullable();
            }
            if (! Schema::hasColumn('walkin_sales', 'done_at')) {
                $t->timestamp('done_at')->nullable();
            }
            if (! Schema::hasColumn('walkin_sales', 'done_by')) {
                $t->unsignedBigInteger('done_by')->nullable();
            }
            if (! Schema::hasColumn('walkin_sales', 'done_from')) {
                $t->string('done_from', 12)->nullable(); // وضعیت پیش از پایان
            }
        });
    }

    public function down(): void {}
};
