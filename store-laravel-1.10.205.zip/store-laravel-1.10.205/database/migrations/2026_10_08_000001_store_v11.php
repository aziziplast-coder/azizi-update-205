<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * نسخه ۱.۱: مقالات، کوپن، مجموعه‌ها، ویژگی‌ها، اعلان، مسئول سفارش و پیگیری اجباری،
 * کالاهای مشابه، شگفت‌انگیز، جستجوی هوشمند و تنظیمات دسته‌ها.
 * ستون‌های جدید جداول قدیمی بدون کلید خارجی اضافه می‌شوند تا روی SQLite هم بی‌دردسر اجرا شود.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('categories', function (Blueprint $t) {
            $t->string('icon')->nullable();                 // تصویر PNG نوار دسته‌های صفحه اول
            $t->boolean('on_home')->default(true);          // نمایش در نوار دسته‌های صفحه اول
            $t->string('default_sort', 20)->nullable();     // مرتب‌سازی پیش‌فرض کالاها
            $t->string('h1')->nullable();
            $t->longText('seo_text')->nullable();           // متن سئو پایین صفحه دسته
            $t->boolean('noindex')->default(false);
            $t->string('banner')->nullable();
        });

        Schema::table('products', function (Blueprint $t) {
            $t->json('related_ids')->nullable();
            $t->boolean('related_auto')->default(true);
            $t->text('search_key')->nullable();
            $t->boolean('is_amazing')->default(false);
            $t->integer('amazing_sort')->default(0);
            $t->timestamp('offer_ends_at')->nullable();
            $t->string('h1')->nullable();
            $t->boolean('noindex')->default(false);
            $t->string('focus_keyword')->nullable();
        });

        Schema::table('orders', function (Blueprint $t) {
            $t->unsignedBigInteger('assignee_id')->nullable()->index();
            $t->timestamp('status_changed_at')->nullable();
            $t->timestamp('assigned_at')->nullable();
            $t->string('coupon_code', 60)->nullable();
            $t->unsignedBigInteger('coupon_discount')->default(0);
            $t->timestamp('terms_accepted_at')->nullable();
        });

        Schema::table('users', function (Blueprint $t) {
            $t->boolean('force_followup')->default(false);  // پنل تا به‌روز کردن سفارش‌های عقب‌افتاده قفل شود
            $t->boolean('receives_orders')->default(false); // سفارش جدید به‌صورت نوبتی به او سپرده شود
        });

        Schema::create('attributes', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('slug', 120)->unique();
            $t->string('type', 10)->default('text'); // text | color
            $t->boolean('filterable')->default(true);
            $t->boolean('on_card')->default(false);
            $t->integer('sort')->default(0);
            $t->timestamps();
        });

        Schema::create('attribute_values', function (Blueprint $t) {
            $t->id();
            $t->foreignId('attribute_id')->constrained()->cascadeOnDelete();
            $t->string('value');
            $t->string('color', 20)->nullable();
            $t->integer('sort')->default(0);
        });

        Schema::create('product_attribute_value', function (Blueprint $t) {
            $t->foreignId('product_id')->constrained()->cascadeOnDelete();
            $t->foreignId('attribute_value_id')->constrained()->cascadeOnDelete();
            $t->primary(['product_id', 'attribute_value_id']);
        });

        Schema::create('post_categories', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('slug', 160)->unique();
            $t->text('description')->nullable();
            $t->string('seo_title')->nullable();
            $t->string('seo_description', 500)->nullable();
            $t->integer('sort')->default(0);
            $t->timestamps();
        });

        Schema::create('posts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('post_category_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('author_id')->nullable()->constrained('users')->nullOnDelete();
            $t->string('title');
            $t->string('slug', 191)->unique();
            $t->text('excerpt')->nullable();
            $t->longText('body')->nullable();
            $t->string('image')->nullable();
            $t->string('image_alt')->nullable();
            $t->json('tags')->nullable();
            $t->json('faq')->nullable();
            $t->json('product_ids')->nullable();
            $t->boolean('is_published')->default(true)->index();
            $t->timestamp('published_at')->nullable()->index();
            $t->string('seo_title')->nullable();
            $t->string('seo_description', 500)->nullable();
            $t->string('focus_keyword')->nullable();
            $t->string('canonical')->nullable();
            $t->boolean('noindex')->default(false);
            $t->unsignedInteger('views')->default(0);
            $t->timestamps();
        });

        Schema::create('coupons', function (Blueprint $t) {
            $t->id();
            $t->string('code', 60)->unique();
            $t->string('title')->nullable();
            $t->string('type', 20)->default('percent'); // percent | fixed | shipping
            $t->unsignedBigInteger('amount')->default(0);
            $t->unsignedBigInteger('max_discount')->nullable();
            $t->unsignedBigInteger('min_cart')->nullable();
            $t->unsignedInteger('max_uses')->nullable();
            $t->unsignedInteger('max_per_user')->nullable();
            $t->unsignedInteger('used_count')->default(0);
            $t->timestamp('starts_at')->nullable();
            $t->timestamp('ends_at')->nullable();
            $t->boolean('first_order')->default(false);
            $t->boolean('exclude_sale')->default(false);
            $t->string('applies_to', 20)->default('all'); // all | carton | retail
            $t->json('category_ids')->nullable();
            $t->json('product_ids')->nullable();
            $t->text('mobiles')->nullable();
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::create('coupon_usages', function (Blueprint $t) {
            $t->id();
            $t->foreignId('coupon_id')->constrained()->cascadeOnDelete();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('order_id')->nullable()->constrained()->cascadeOnDelete();
            $t->unsignedBigInteger('amount')->default(0);
            $t->timestamp('created_at')->nullable();
        });

        Schema::create('collections', function (Blueprint $t) {
            $t->id();
            $t->string('title');
            $t->string('slug', 160)->unique();
            $t->text('description')->nullable();
            $t->string('image')->nullable();
            $t->string('mode', 10)->default('rules'); // rules | manual
            $t->json('rules')->nullable();
            $t->json('product_ids')->nullable();
            $t->string('sort_by', 20)->default('newest');
            $t->unsignedInteger('home_limit')->default(12);
            $t->string('display', 10)->default('strip'); // strip | grid
            $t->string('color', 20)->nullable();
            $t->boolean('on_home')->default(true);
            $t->boolean('is_active')->default(true);
            $t->integer('sort')->default(0);
            $t->string('seo_title')->nullable();
            $t->string('seo_description', 500)->nullable();
            $t->timestamps();
        });

        Schema::create('push_subscriptions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('hash', 64)->unique();
            $t->text('endpoint');
            $t->string('p256dh', 200);
            $t->string('auth', 100);
            $t->boolean('is_staff')->default(false);
            $t->timestamp('last_ok_at')->nullable();
            $t->timestamps();
        });

        Schema::create('push_campaigns', function (Blueprint $t) {
            $t->id();
            $t->string('title');
            $t->string('body', 500)->nullable();
            $t->string('url')->nullable();
            $t->string('image')->nullable();
            $t->string('audience', 20)->default('all'); // all | customers | guests | staff
            $t->unsignedInteger('sent')->default(0);
            $t->unsignedInteger('failed')->default(0);
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['push_campaigns', 'push_subscriptions', 'collections', 'coupon_usages', 'coupons', 'posts', 'post_categories', 'product_attribute_value', 'attribute_values', 'attributes'] as $table) {
            Schema::dropIfExists($table);
        }
        Schema::table('categories', fn (Blueprint $t) => $t->dropColumn(['icon', 'on_home', 'default_sort', 'h1', 'seo_text', 'noindex', 'banner']));
        Schema::table('products', fn (Blueprint $t) => $t->dropColumn(['related_ids', 'related_auto', 'search_key', 'is_amazing', 'amazing_sort', 'offer_ends_at', 'h1', 'noindex', 'focus_keyword']));
        Schema::table('orders', fn (Blueprint $t) => $t->dropColumn(['assignee_id', 'status_changed_at', 'assigned_at', 'coupon_code', 'coupon_discount', 'terms_accepted_at']));
        Schema::table('users', fn (Blueprint $t) => $t->dropColumn(['force_followup', 'receives_orders']));
    }
};
