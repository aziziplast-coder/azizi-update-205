<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* باشگاه مشتریان (CRM): مشتریان هلو و سایت، فاکتورها، کالاهای هر مشتری، تماس‌ها، کمپین‌های برگشت */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('crm_customers')) {
            Schema::create('crm_customers', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('user_id')->nullable()->index();
                $t->string('code', 40)->nullable()->index();   // کد شخص در هلو
                $t->string('name', 150);
                $t->string('nkey', 150)->nullable()->index();   // نام یکسان‌شده برای تطبیق
                $t->string('mobile', 20)->nullable()->index();
                $t->string('phone', 40)->nullable();
                $t->string('city', 80)->nullable();
                $t->string('company', 150)->nullable();
                $t->string('address', 300)->nullable();
                $t->date('first_at')->nullable();
                $t->date('last_at')->nullable()->index();
                $t->unsignedInteger('orders')->default(0);
                $t->unsignedBigInteger('total')->default(0);       // کل خرید (تومان)
                $t->unsignedBigInteger('total_year')->default(0);  // خرید ۱۲ ماه اخیر
                $t->unsignedBigInteger('total_prev')->default(0);  // خرید ۱۲ ماه قبل از آن
                $t->unsignedInteger('gap')->nullable();            // میانگین فاصله خریدها (روز)
                $t->string('segment', 10)->nullable()->index();    // gold | silver | bronze | risk | lost | new
                $t->unsignedBigInteger('advisor_id')->nullable()->index();
                $t->unsignedBigInteger('assigned_to')->nullable()->index(); // فهرست تماس امروزِ این مشاور
                $t->timestamp('assigned_at')->nullable();
                $t->timestamp('next_call_at')->nullable()->index();
                $t->timestamp('last_call_at')->nullable();
                $t->string('last_result', 20)->nullable();
                $t->boolean('dnc')->default(false);                 // دیگر تماس نگیرید
                $t->text('notes')->nullable();
                $t->date('birthday')->nullable();
                $t->string('prev_segment', 10)->nullable();
                $t->timestamp('returned_at')->nullable()->index();   // پس از «در خطر/از دست رفته» دوباره خرید کرد
                $t->unsignedBigInteger('returned_by')->nullable();   // مشاوری که در ۳۰ روز قبلش تماس گرفته بود
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('crm_sales')) {
            Schema::create('crm_sales', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('crm_customer_id')->index();
                $t->string('source', 6)->default('holoo'); // holoo | site
                $t->string('ref', 40);                       // شماره فاکتور
                $t->date('day')->index();
                $t->unsignedBigInteger('amount')->default(0);
                $t->unique(['source', 'ref']);
            });
        }
        if (! Schema::hasTable('crm_items')) {
            Schema::create('crm_items', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('crm_customer_id')->index();
                $t->string('code', 60)->nullable();
                $t->string('name', 200);
                $t->unsignedInteger('qty')->default(0);
                $t->unsignedBigInteger('amount')->default(0);
                $t->date('last_day')->nullable();
                $t->unique(['crm_customer_id', 'name']);
            });
        }
        if (! Schema::hasTable('crm_calls')) {
            Schema::create('crm_calls', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('crm_customer_id')->index();
                $t->unsignedBigInteger('user_id')->index();
                $t->string('result', 20);
                $t->string('note', 500)->nullable();
                $t->timestamp('next_at')->nullable();
                $t->timestamp('created_at')->nullable()->index();
            });
        }
        if (! Schema::hasTable('crm_campaigns')) {
            Schema::create('crm_campaigns', function (Blueprint $t) {
                $t->id();
                $t->string('name', 120);
                $t->text('filter')->nullable();
                $t->text('text');
                $t->string('coupon', 40)->nullable();
                $t->string('status', 10)->default('draft'); // draft | sending | sent
                $t->unsignedInteger('targets')->default(0);
                $t->unsignedInteger('sent')->default(0);
                $t->unsignedInteger('returned')->default(0);
                $t->unsignedBigInteger('revenue')->default(0);
                $t->unsignedBigInteger('by_id')->nullable();
                $t->timestamp('sent_at')->nullable();
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('crm_campaign_targets')) {
            Schema::create('crm_campaign_targets', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('campaign_id')->index();
                $t->unsignedBigInteger('crm_customer_id')->index();
                $t->string('status', 10)->default('wait'); // wait | sent | fail | skip
                $t->timestamp('sent_at')->nullable();
                $t->timestamp('returned_at')->nullable();
                $t->unsignedBigInteger('revenue')->default(0);
                $t->unique(['campaign_id', 'crm_customer_id']);
            });
        }
        if (! Schema::hasTable('crm_snapshots')) {
            Schema::create('crm_snapshots', function (Blueprint $t) {
                $t->id();
                $t->date('day')->unique();
                $t->text('counts');
            });
        }
        if (! Schema::hasTable('crm_imports')) {
            Schema::create('crm_imports', function (Blueprint $t) {
                $t->id();
                $t->string('kind', 12);
                $t->string('file', 190);
                $t->text('stats')->nullable();
                $t->unsignedBigInteger('by_id')->nullable();
                $t->timestamp('created_at')->nullable();
            });
        }
    }

    public function down(): void {}
};
