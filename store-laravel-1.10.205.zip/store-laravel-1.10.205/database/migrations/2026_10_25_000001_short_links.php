<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** لینک کوتاه برای پیامک (پنل‌های پیامک و اپراتورها پیامک دارای لینک بلند/https را رد یا فیلتر می‌کنند) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('short_links')) {
            Schema::create('short_links', function (Blueprint $t) {
                $t->id();
                $t->string('code', 12)->unique();
                $t->string('hash', 40)->index();
                $t->text('url');
                $t->unsignedInteger('hits')->default(0);
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('short_links');
    }
};
