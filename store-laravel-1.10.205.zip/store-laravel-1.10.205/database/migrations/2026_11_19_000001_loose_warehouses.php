<?php

use App\Models\Warehouse;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * انبارهای «فروش عددی»: سوله خرده‌ریز (۷ عمده) و سوله نوید (۶ عمده) کارتن ندارند؛
 * تعداد در کارتن قدیمی (۱۲تایی برای پرش ۱۲ تا ۱۲ تا) برداشته می‌شود و گام خرید از «قانون انبار» می‌آید.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('warehouses', 'loose')) {
            Schema::table('warehouses', fn (Blueprint $t) => $t->boolean('loose')->default(false));
        }
        if (! Schema::hasColumn('products', 'loose_backup')) {
            Schema::table('products', fn (Blueprint $t) => $t->string('loose_backup', 120)->nullable());
        }
        if (! Schema::hasColumn('pick_tasks', 'rechecks')) {
            Schema::table('pick_tasks', fn (Blueprint $t) => $t->unsignedTinyInteger('rechecks')->default(0));
        }
        \App\Support\DbSchema::flush();
        if (\Illuminate\Support\Facades\DB::table('settings')->where('key', 'loose_v1_done')->exists()) {
            return;
        }
        $whs = Warehouse::query()->where('kind', 'carton')->whereIn('code', ['6', '7'])->orderBy('id')->get();
        $seven = $whs->firstWhere('code', '7');
        foreach ($whs as $w) {
            // سوله نوید قانون ندارد: همان قانون سوله خرده‌ریز (۱۲ / ۶ / ۳ بر اساس قیمت)
            if (! $w->buy_rules && $seven && $seven->buy_rules && $w->id !== $seven->id) {
                $w->buy_rules = $seven->buy_rules;
            }
            $w->loose = true;
            $w->save(); // تبدیل کالاها در رویداد saved
        }
        \Illuminate\Support\Facades\DB::table('settings')->insert(['key' => 'loose_v1_done', 'value' => 'true', 'created_at' => now(), 'updated_at' => now()]);
    }

    public function down(): void {}
};
