<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * خرید و تأمین: فهرست کالاهای تأمین‌کنندگان (از اکسل جداگانه)، علامت‌های مسئول خرید (کارتن/حذف) و سفارش‌های خرید.
 * این داده‌ها با محصولات سایت ترکیب نمی‌شوند؛ فقط برای دیدن موجودی به کالای سایت/فید وصل می‌شوند.
 */
return new class extends Migration
{
    /** اجرای امن: اگر جدول/ستون همزمان یا قبلاً ساخته شده باشد، خطا نمی‌دهد */
    private function safe(callable $f): void
    {
        try {
            $f();
        } catch (\Illuminate\Database\QueryException $e) {
            if (! preg_match('/already exists|Duplicate column|Duplicate key name|1050|1060|1061/i', $e->getMessage())) {
                throw $e;
            }
        }
    }

    public function up(): void
    {
        if (! Schema::hasTable('suppliers')) {
            $this->safe(fn () => Schema::create('suppliers', function (Blueprint $t) {
                $t->id();
                $t->string('name', 190);
                $t->string('name_key', 190)->unique();
                $t->string('phone', 20)->nullable();
                $t->string('contact', 120)->nullable();
                $t->string('note', 500)->nullable();
                $t->unsignedInteger('items_count')->default(0);
                $t->boolean('in_file')->default(true);
                $t->timestamps();
            }));
        }
        if (! Schema::hasTable('supply_items')) {
            $this->safe(fn () => Schema::create('supply_items', function (Blueprint $t) {
                $t->id();
                $t->string('code', 60);
                $t->string('code_key', 60)->unique();
                $t->string('name', 250);
                $t->unsignedBigInteger('supplier_id')->index();
                $t->unsignedBigInteger('product_id')->nullable()->index();
                $t->unsignedBigInteger('sync_item_id')->nullable();
                $t->unsignedInteger('row')->default(0);
            }));
        }
        if (! Schema::hasTable('supply_imports')) {
            $this->safe(fn () => Schema::create('supply_imports', function (Blueprint $t) {
                $t->id();
                $t->string('file_name', 190)->nullable();
                $t->unsignedInteger('rows')->default(0);
                $t->unsignedInteger('suppliers')->default(0);
                $t->unsignedInteger('matched')->default(0);
                $t->unsignedInteger('feed_only')->default(0);
                $t->unsignedInteger('unmatched')->default(0);
                $t->unsignedInteger('skipped')->default(0);
                $t->unsignedBigInteger('user_id')->nullable();
                $t->timestamps();
            }));
        }
        if (! Schema::hasTable('purchase_marks')) {
            $this->safe(fn () => Schema::create('purchase_marks', function (Blueprint $t) {
                $t->id();
                $t->string('code_key', 60)->unique();
                $t->unsignedInteger('cartons')->default(0);
                $t->boolean('excluded')->default(false);
                $t->string('note', 190)->nullable();
                $t->unsignedBigInteger('user_id')->nullable();
                $t->timestamps();
            }));
        }
        if (! Schema::hasTable('purchase_orders')) {
            $this->safe(fn () => Schema::create('purchase_orders', function (Blueprint $t) {
                $t->id();
                $t->string('number', 30)->nullable()->index();
                $t->unsignedBigInteger('supplier_id')->nullable()->index();
                $t->string('supplier_name', 190);
                $t->string('status', 20)->default('sent')->index();   // sent | received | cancelled
                $t->longText('lines');                                 // [{c,k,n,q,pc,note}]
                $t->unsignedInteger('total_cartons')->default(0);
                $t->unsignedInteger('items_count')->default(0);
                $t->string('note', 500)->nullable();
                $t->unsignedBigInteger('created_by')->nullable();
                $t->timestamp('closed_at')->nullable();
                $t->timestamps();
            }));
        }
    }

    public function down(): void
    {
        foreach (['purchase_orders', 'purchase_marks', 'supply_imports', 'supply_items', 'suppliers'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
