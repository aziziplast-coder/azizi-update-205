<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** یادداشت‌های داخلی پین‌شده هر سفارش (متن یا صدا) — با عوض شدن مسئول سفارش هم می‌ماند */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('order_pins')) {
            Schema::create('order_pins', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('order_id')->index();
                $t->unsignedBigInteger('user_id')->nullable();
                $t->string('kind', 10)->default('text');
                $t->text('body')->nullable();
                $t->string('path', 255)->nullable();
                $t->unsignedInteger('sec')->nullable();
                $t->unsignedBigInteger('msg_id')->nullable();
                $t->unsignedBigInteger('edited_by')->nullable();
                $t->timestamps();
            });
            // یادداشت‌های داخلی قبلی سفارش‌های باز ← پین (تا همکار تازه هم ببیند)
            try {
                $open = \App\Models\Order::query()->whereIn('status', ['on_hold', 'processing', 'settling', 'to_freight', 'shipped'])->pluck('id');
                foreach ($open->chunk(200) as $ids) {
                    $rows = \Illuminate\Support\Facades\DB::table('chat_messages')->join('chat_threads', 'chat_threads.id', '=', 'chat_messages.thread_id')
                        ->whereIn('chat_threads.order_id', $ids)->where('chat_messages.side', 'n')->whereIn('chat_messages.kind', ['text', 'voice'])
                        ->orderBy('chat_messages.id')->get(['chat_threads.order_id', 'chat_messages.id', 'chat_messages.user_id', 'chat_messages.kind', 'chat_messages.body', 'chat_messages.meta', 'chat_messages.created_at']);
                    foreach ($rows as $m) {
                        $meta = (array) json_decode((string) $m->meta, true);
                        if (! empty($meta['del']) || ($m->kind === 'text' && trim((string) $m->body) === '') || ($m->kind === 'voice' && empty($meta['path']))) {
                            continue;
                        }
                        \Illuminate\Support\Facades\DB::table('order_pins')->insert(['order_id' => $m->order_id, 'user_id' => $m->user_id, 'kind' => $m->kind,
                            'body' => $m->kind === 'text' ? mb_substr((string) $m->body, 0, 3000) : null, 'path' => $meta['path'] ?? null, 'sec' => $meta['sec'] ?? null,
                            'msg_id' => $m->id, 'created_at' => $m->created_at, 'updated_at' => $m->created_at]);
                    }
                }
            } catch (\Throwable $e) {
                report($e);
            }
        }
    }

    public function down(): void {}
};
