<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * فروش حضوری: بارکدزن اقلامی را که مشتری حضوری از انبار می‌برد اسکن و به دفتر می‌فرستد؛
 * تحویل‌دهنده هنگام تحویل دوباره اسکن می‌کند؛ مرجوعی با وضعیت سالم / ایراد کارخانه / ضایعات.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('walkin_sales')) {
            Schema::create('walkin_sales', function (Blueprint $t) {
                $t->id();
                $t->string('kind', 10)->default('sale'); // sale | return
                $t->string('status', 12)->default('draft'); // draft | scanned | loaded | returned
                $t->string('customer_name', 120);
                $t->string('city', 80)->nullable();
                $t->string('phone', 20)->nullable();
                $t->string('bay', 60)->nullable();
                $t->text('note')->nullable();
                $t->unsignedBigInteger('scanned_by')->nullable();
                $t->timestamp('sent_at')->nullable();
                $t->unsignedBigInteger('delivered_by')->nullable();
                $t->timestamp('delivered_at')->nullable();
                $t->unsignedInteger('diffs')->default(0);
                $t->unsignedBigInteger('total')->default(0);
                $t->timestamp('excel_at')->nullable();
                $t->timestamps();
                $t->index(['kind', 'status']);
            });
        }
        if (! Schema::hasTable('walkin_items')) {
            Schema::create('walkin_items', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('sale_id')->index();
                $t->unsignedBigInteger('product_id')->nullable();
                $t->string('name', 255);
                $t->string('code', 60)->nullable();
                $t->unsignedInteger('per')->default(1);
                $t->unsignedInteger('units')->default(0);
                $t->unsignedInteger('d_units')->nullable(); // شمارش تحویل‌دهنده
                $t->string('cond', 10)->nullable(); // مرجوعی: ok | factory | waste
                $t->unsignedBigInteger('unit_price')->default(0);
                $t->timestamps();
            });
        }
    }

    public function down(): void {}
};
