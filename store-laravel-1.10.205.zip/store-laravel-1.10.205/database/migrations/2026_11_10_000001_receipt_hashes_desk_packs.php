<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * - receipt_hashes: اثر انگشت فایل اصلی فیش‌ها (جلوگیری از فیش تکراری)
 * - desk_pack: شماره کیسه/کارتن هر قلم در بررسی رومیزی (سالن خرده‌ریز)
 * - packs: کیسه‌ها و کارتن‌های بسته‌شده هر بررسی [{n, type}]
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('remit_payments', 'receipt_hashes')) {
            Schema::table('remit_payments', fn (Blueprint $t) => $t->text('receipt_hashes')->nullable());
        }
        if (! Schema::hasColumn('order_items', 'desk_pack')) {
            Schema::table('order_items', fn (Blueprint $t) => $t->unsignedSmallInteger('desk_pack')->nullable());
        }
        if (! Schema::hasColumn('pick_tasks', 'packs')) {
            Schema::table('pick_tasks', fn (Blueprint $t) => $t->text('packs')->nullable());
        }
    }

    public function down(): void
    {
        foreach ([['remit_payments', 'receipt_hashes'], ['order_items', 'desk_pack'], ['pick_tasks', 'packs']] as [$tb, $col]) {
            if (Schema::hasColumn($tb, $col)) {
                Schema::table($tb, fn (Blueprint $t) => $t->dropColumn($col));
            }
        }
    }
};
