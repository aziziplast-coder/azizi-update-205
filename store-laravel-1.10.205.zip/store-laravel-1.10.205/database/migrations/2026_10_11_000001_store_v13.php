<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * نسخه ۱.۳: خرید چکی و صف بررسی، باربری، سبد ماندگار و سبدهای رها شده، ویرایش سفارش توسط مشتری،
 * شماره پیام‌رسان، نظرسنجی، ارسال خودکار به کانال‌ها.
 * همه مراحل «اگر وجود ندارد» نوشته شده‌اند تا اجرای دوباره (بعد از خطای نیمه‌کاره روی MySQL) مشکلی نسازد.
 */
return new class extends Migration
{
    public function up(): void
    {
        $add = function (string $table, string $col, callable $def) {
            if (! Schema::hasColumn($table, $col)) {
                Schema::table($table, fn (Blueprint $t) => $def($t));
            }
        };

        $add('orders', 'review_status', fn ($t) => $t->string('review_status', 20)->nullable()->index());
        $add('orders', 'reviewed_by', fn ($t) => $t->unsignedBigInteger('reviewed_by')->nullable());
        $add('orders', 'reviewed_at', fn ($t) => $t->timestamp('reviewed_at')->nullable());
        $add('orders', 'cheque', fn ($t) => $t->json('cheque')->nullable());
        $add('orders', 'freight_name', fn ($t) => $t->string('freight_name', 150)->nullable());
        $add('orders', 'messenger', fn ($t) => $t->string('messenger', 20)->nullable());
        $add('orders', 'edit_locked', fn ($t) => $t->boolean('edit_locked')->default(false));
        $add('orders', 'customer_edited_at', fn ($t) => $t->timestamp('customer_edited_at')->nullable());
        $add('orders', 'survey_notified_at', fn ($t) => $t->timestamp('survey_notified_at')->nullable());

        $add('users', 'cheque_allowed', fn ($t) => $t->boolean('cheque_allowed')->default(false));
        $add('users', 'messenger', fn ($t) => $t->string('messenger', 20)->nullable());

        $add('products', 'channel_posted_at', fn ($t) => $t->timestamp('channel_posted_at')->nullable());

        if (! Schema::hasTable('carts')) {
            Schema::create('carts', function (Blueprint $t) {
                $t->id();
                $t->string('token', 64)->unique();
                $t->unsignedBigInteger('user_id')->nullable()->index();
                $t->json('items')->nullable();
                $t->string('stage', 20)->default('cart')->index();
                $t->json('info')->nullable();
                $t->unsignedInteger('items_count')->default(0);
                $t->unsignedBigInteger('total')->default(0);
                $t->unsignedBigInteger('order_id')->nullable();
                $t->unsignedBigInteger('edit_order_id')->nullable();
                $t->timestamp('reminded_at')->nullable();
                $t->timestamp('last_activity_at')->nullable()->index();
                $t->timestamps();
            });
        }

        if (! Schema::hasTable('surveys')) {
            Schema::create('surveys', function (Blueprint $t) {
                $t->id();
                $t->string('title');
                $t->text('intro')->nullable();
                $t->json('questions')->nullable();
                $t->string('trigger_status', 30)->default('completed');
                $t->decimal('delay_hours', 8, 2)->default(24);
                $t->boolean('send_sms')->default(false);
                $t->string('thanks')->nullable();
                $t->boolean('is_active')->default(true);
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('survey_responses')) {
            Schema::create('survey_responses', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('survey_id')->index();
                $t->unsignedBigInteger('order_id')->index();
                $t->unsignedBigInteger('user_id')->nullable()->index();
                $t->unsignedBigInteger('assignee_id')->nullable()->index();
                $t->string('status', 20)->default('done');
                $t->json('answers')->nullable();
                $t->decimal('rating', 4, 2)->nullable();
                $t->decimal('staff_rating', 4, 2)->nullable();
                $t->text('comment')->nullable();
                $t->timestamps();
                $t->unique(['survey_id', 'order_id']);
            });
        }

        if (! Schema::hasTable('channel_posts')) {
            Schema::create('channel_posts', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('product_id')->index();
                $t->string('channel', 40);
                $t->string('kind', 20)->default('new');
                $t->string('status', 20)->default('queued')->index();
                $t->unsignedTinyInteger('attempts')->default(0);
                $t->string('message_id', 100)->nullable();
                $t->text('error')->nullable();
                $t->timestamp('sent_at')->nullable();
                $t->timestamps();
                $t->index(['channel', 'status']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('channel_posts');
        Schema::dropIfExists('survey_responses');
        Schema::dropIfExists('surveys');
        Schema::dropIfExists('carts');
    }
};
