<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * تیم انبار: سرپرست (تقسیم فاکتورها و بررسی بار با بارکدخوان) و جمع‌کننده‌های زیر نظر او.
 * بدون کلید خارجی و ستون‌به‌ستون (سازگار با همه نسخه‌های MySQL/MariaDB).
 */
return new class extends Migration
{
    public function up(): void
    {
        $cols = [
            'users' => [
                'pick_role' => fn (Blueprint $t) => $t->string('pick_role', 12)->nullable(), // supervisor | picker
                'supervisor_id' => fn (Blueprint $t) => $t->unsignedBigInteger('supervisor_id')->nullable()->index(),
            ],
            'pick_tasks' => [
                'picker_id' => fn (Blueprint $t) => $t->unsignedBigInteger('picker_id')->nullable()->index(),
                'stage' => fn (Blueprint $t) => $t->string('stage', 12)->nullable(), // new | picking | review
                'assigned_at' => fn (Blueprint $t) => $t->timestamp('assigned_at')->nullable(),
                'picked_done_at' => fn (Blueprint $t) => $t->timestamp('picked_done_at')->nullable(),
                'bay' => fn (Blueprint $t) => $t->string('bay', 80)->nullable(),
                'checked_by' => fn (Blueprint $t) => $t->unsignedBigInteger('checked_by')->nullable(),
                'checked_at' => fn (Blueprint $t) => $t->timestamp('checked_at')->nullable(),
                'check_note' => fn (Blueprint $t) => $t->string('check_note', 190)->nullable(),
            ],
            'order_items' => [
                'scanned_units' => fn (Blueprint $t) => $t->unsignedInteger('scanned_units')->nullable(),
            ],
        ];
        foreach ($cols as $table => $list) {
            foreach ($list as $col => $def) {
                if (! Schema::hasColumn($table, $col)) {
                    Schema::table($table, fn (Blueprint $t) => $def($t));
                }
            }
        }
    }

    public function down(): void
    {
    }
};
