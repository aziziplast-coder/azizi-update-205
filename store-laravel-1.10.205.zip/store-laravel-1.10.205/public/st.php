<?php
/*
 * آمار بازدید — ثبت یک خط برای هر رویداد (بازدید صفحه / خروج / افزودن به سبد).
 * عمداً بدون بارگذاری سایت و بدون دیتابیس: فقط افزودن یک خط به فایل روز (کمتر از یک میلی‌ثانیه).
 * جمع‌بندی و ذخیره در دیتابیس هر چند دقیقه یک بار در پس‌زمینه انجام می‌شود (App\Services\Stats::ingest).
 */
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
header('X-LiteSpeed-Cache-Control: no-cache');
header('X-Robots-Tag: noindex');

$base = dirname(__DIR__).'/storage/app/_stats';
if (is_file($base.'/off')) {
    http_response_code(204);
    exit;
}
$raw = (string) file_get_contents('php://input', false, null, 0, 6000);
$in = json_decode($raw, true);
if (! is_array($in)) {
    http_response_code(204);
    exit;
}
$ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
if ($ua === '' || strlen($ua) < 20 || preg_match('/bot|crawl|spider|slurp|headless|lighthouse|pingdom|uptime|monitor|preview|facebookexternalhit|curl|wget|python|java\/|go-http|okhttp\/[0-9]|axios|scrapy|phantom|selenium/i', $ua)) {
    http_response_code(204);
    exit;
}
$id = fn ($s) => preg_match('/^[a-z0-9]{12,32}$/', (string) $s) ? (string) $s : '';
$v = $id($in['v'] ?? '');
$s = $id($in['s'] ?? '');
$e = (string) ($in['e'] ?? '');
if ($v === '' || $s === '' || ! in_array($e, ['p', 'x', 'a'], true)) {
    http_response_code(204);
    exit;
}
function st_str($x, int $max): string
{
    $x = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', (string) $x));

    return function_exists('mb_substr') ? mb_substr($x, 0, $max) : substr($x, 0, $max * 2);
}

$o = ['t' => time(), 'e' => $e, 'v' => $v, 's' => $s];
foreach (['i' => 0, 'ci' => 0, 'n' => -1, 'dur' => 0, 'w' => 0, 'seq' => 0, 'app' => 0] as $k => $_) {
    if (isset($in[$k]) && is_numeric($in[$k])) {
        $o[$k] = (int) $in[$k];
    }
}
if ($e === 'p') {
    $o['k'] = preg_replace('/[^a-z]/', '', (string) ($in['k'] ?? 'other')) ?: 'other';
    foreach (['tt' => 120, 'q' => 80, 'r' => 120, 'us' => 60, 'um' => 40, 'uc' => 80] as $k => $max) {
        if (! empty($in[$k])) {
            $o[$k] = st_str($in[$k], $max);
        }
    }
    if (! empty($in['r'])) {
        $o['r'] = strtolower((string) (parse_url((string) $in['r'], PHP_URL_HOST) ?: ''));
        $self = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
        if ($o['r'] === '' || preg_replace('/^www\./', '', $o['r']) === preg_replace('/^www\./', '', $self)) {
            unset($o['r']);
        }
    }
    foreach (['nv', 'l'] as $k) {
        if (! empty($in[$k])) {
            $o[$k] = 1;
        }
    }
    // کاربر واردشده (امضای سایت؛ همان کلید گفتگوی زنده)
    $uid = (int) ($in['u'] ?? 0);
    if ($uid > 0) {
        $kf = dirname(__DIR__).'/storage/app/_live/key';
        $key = is_file($kf) ? trim((string) @file_get_contents($kf)) : '';
        if ($key !== '' && hash_equals(substr(hash_hmac('sha256', 'u'.$uid, $key), 0, 24), (string) ($in['us2'] ?? ''))) {
            $o['u'] = $uid;
        }
    }
    if (! empty($o['l'])) {
        // دستگاه، سیستم‌عامل و مرورگر فقط برای اولین صفحه هر نشست
        $o['d'] = preg_match('/iPad|Tablet|PlayBook|Silk|(Android(?!.*Mobile))/i', $ua) ? 't' : (preg_match('/Mobi|iPhone|iPod|Android|Opera Mini|IEMobile/i', $ua) ? 'm' : 'd');
        $o['os'] = preg_match('/Android/i', $ua) ? 'android' : (preg_match('/iPhone|iPad|iPod|iOS/i', $ua) ? 'ios' : (preg_match('/Windows/i', $ua) ? 'windows' : (preg_match('/Mac OS|Macintosh/i', $ua) ? 'mac' : (preg_match('/Linux|X11|CrOS/i', $ua) ? 'linux' : 'other'))));
        $o['br'] = preg_match('/Instagram/i', $ua) ? 'instagram' : (preg_match('/SamsungBrowser/i', $ua) ? 'samsung' : (preg_match('/Edg\//i', $ua) ? 'edge' : (preg_match('/OPR\/|Opera/i', $ua) ? 'opera' : (preg_match('/Firefox|FxiOS/i', $ua) ? 'firefox' : (preg_match('/; wv\)|WebView/i', $ua) ? 'webview' : (preg_match('/Chrome|CriOS/i', $ua) ? 'chrome' : (preg_match('/Safari/i', $ua) ? 'safari' : 'other')))))));
    }
}

if (! is_dir($base)) {
    @mkdir($base, 0775, true);
}
@file_put_contents($base.'/q-'.date('Ymd').'.log', json_encode($o, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)."\n", FILE_APPEND | LOCK_EX);
http_response_code(204);
