<?php
/*
 * وضعیت گفتگو (پیام تازه؟ خوانده شد؟ در حال نوشتن؟) — عمداً بدون بارگذاری سایت و بدون دیتابیس.
 * فقط فایل کوچک همان گفتگو را می‌خواند؛ با سرآیندهای ضدکش تا هیچ کش هاست/CDN/مرورگری نسخه کهنه ندهد.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
header('Pragma: no-cache');
header('Expires: 0');
header('X-Accel-Expires: 0');
header('X-LiteSpeed-Cache-Control: no-cache');
header('CDN-Cache-Control: no-store');
$k = (string) ($_GET['k'] ?? '');
$u = (string) ($_GET['u'] ?? '');
if (preg_match('/^[A-Za-z0-9]{32}$/', $k)) {
    $f = __DIR__.'/uploads/_chat/t-'.$k.'.json';
} elseif (preg_match('/^[a-f0-9]{32}$/', $u)) {
    $f = __DIR__.'/uploads/_chat/u-'.$u.'.json';
} else {
    http_response_code(400);
    exit('{}');
}
clearstatcache(true, $f);
$d = is_file($f) ? json_decode((string) @file_get_contents($f), true) : null;
if (! is_array($d)) {
    $d = [];
}
$d['srv'] = time();
echo json_encode($d);
