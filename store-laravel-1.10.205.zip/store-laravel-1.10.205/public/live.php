<?php
/*
 * گفتگوی زنده — ثبت صفحه‌ای که بازدیدکننده می‌بیند و خبر پیام تازه.
 * عمداً بدون بارگذاری سایت و بدون دیتابیس: فقط یک فایل کوچک برای همان بازدیدکننده (چند میکروثانیه).
 * ورودی: JSON با کلیدهای v (شناسه بازدیدکننده)، e (p=صفحه تازه، h=هنوز اینجاست، a=پیام خودکار نمایش داده شد)
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
header('X-LiteSpeed-Cache-Control: no-cache');
header('CDN-Cache-Control: no-store');
header('X-Robots-Tag: noindex');

$raw = (string) file_get_contents('php://input', false, null, 0, 8000);
$in = json_decode($raw, true);
if (! is_array($in)) {
    $in = $_GET;
}
$v = (string) ($in['v'] ?? '');
if (! preg_match('/^[a-z0-9]{16,32}$/', $v)) {
    http_response_code(400);
    exit('{}');
}
$ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
if ($ua === '' || preg_match('/bot|crawl|spider|slurp|headless|lighthouse|preview|facebookexternalhit|curl|wget|python/i', $ua)) {
    exit('{}');
}
$base = dirname(__DIR__).'/storage/app/_live';
foreach (['', '/v', '/s'] as $sub) {
    if (! is_dir($base.$sub)) {
        @mkdir($base.$sub, 0775, true);
    }
}
$f = $base.'/v/'.$v.'.json';
$e = (string) ($in['e'] ?? 'h');
$now = time();

function lv_str($s, int $max): string
{
    $s = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', (string) $s));

    return function_exists('mb_substr') ? mb_substr($s, 0, $max) : substr($s, 0, $max * 2);
}
function lv_page($p): array
{
    $p = is_array($p) ? $p : [];
    $o = ['k' => preg_replace('/[^a-z]/', '', (string) ($p['k'] ?? 'other')) ?: 'other', 't' => lv_str($p['t'] ?? '', 120)];
    foreach (['i' => 0, 'ci' => 0, 'n' => 0] as $k => $_) {
        if (isset($p[$k]) && $p[$k] !== null && $p[$k] !== '') {
            $o[$k] = (int) $p[$k];
        }
    }
    foreach (['c' => 80, 'code' => 40, 'q' => 80] as $k => $max) {
        if (! empty($p[$k])) {
            $o[$k] = lv_str($p[$k], $max);
        }
    }
    foreach (['im', 'u'] as $k) {
        if (! empty($p[$k]) && preg_match('~^(https?:)?/[^\s"<>]{0,400}$~', (string) $p[$k])) {
            $o[$k] = (string) $p[$k];
        }
    }

    return $o;
}

$d = null;
if ($e === 'h' && is_file($f)) {
    // فقط «هنوز اینجاست»: تغییر زمان فایل کافی است (حداکثر هر ۱۰ ثانیه)
    if (filemtime($f) < $now - 10) {
        @touch($f);
    }
} elseif ($e === 'p' || $e === 'a' || ! is_file($f)) {
    $fh = @fopen($f, 'c+');
    if ($fh) {
        flock($fh, LOCK_EX);
        $d = json_decode((string) stream_get_contents($fh), true);
        if (! is_array($d) || ($d['v'] ?? '') !== $v) {
            $d = ['v' => $v, 'first' => $now, 'n' => 0, 'h' => [], 'a' => []];
        }
        // کاربر واردشده (امضای سایت)
        $uid = (int) ($in['u'] ?? 0);
        if ($uid > 0 && empty($d['u'])) {
            $kf = $base.'/key';
            $key = is_file($kf) ? trim((string) @file_get_contents($kf)) : '';
            if ($key !== '' && hash_equals(substr(hash_hmac('sha256', 'u'.$uid, $key), 0, 24), (string) ($in['s'] ?? ''))) {
                $d['u'] = $uid;
                $d['un'] = lv_str($in['un'] ?? '', 40);
            }
        }
        if (empty($d['d'])) {
            $d['d'] = preg_match('/iPhone|iPad/i', $ua) ? 'آیفون' : (preg_match('/Android/i', $ua) ? 'اندروید' : (preg_match('/Windows/i', $ua) ? 'ویندوز' : (preg_match('/Mac OS/i', $ua) ? 'مک' : 'دیگر')));
            $d['app'] = ! empty($in['app']) ? 1 : 0;
            $d['ref'] = lv_str(parse_url((string) ($in['r'] ?? ''), PHP_URL_HOST) ?: '', 60);
            $d['ip'] = (string) ($_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '');
        }
        if ($e === 'p' || ! isset($d['p'])) {
            $p = lv_page($in['p'] ?? []);
            $same = isset($d['p']) && ($d['p']['k'] ?? '') === $p['k'] && ($d['p']['i'] ?? null) === ($p['i'] ?? null) && ($d['p']['t'] ?? '') === $p['t'];
            if (! $same) {
                $d['p'] = $p;
                $d['at'] = $now;
                $d['n'] = (int) ($d['n'] ?? 0) + 1;
                $d['h'][] = ['k' => $p['k'], 't' => $p['t'], 'i' => $p['i'] ?? null, 'at' => $now];
                $d['h'] = array_slice($d['h'], -15);
            }
            if (isset($in['cart'])) {
                $d['cart'] = max(0, (int) $in['cart']);
            }
        }
        if ($e === 'a' && is_array($in['a'] ?? null)) {
            $d['a'][] = ['r' => preg_replace('/[^a-z]/', '', (string) ($in['a']['r'] ?? '')), 't' => lv_str($in['a']['t'] ?? '', 300), 'at' => $now];
            $d['a'] = array_slice($d['a'], -6);
        }
        $d['lv'] = $now;
        ftruncate($fh, 0);
        rewind($fh);
        fwrite($fh, json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        fflush($fh);
        flock($fh, LOCK_UN);
        fclose($fh);
    }
}

// پاسخ: پیام تازه از همکاران؟ همکاری آنلاین است؟
$out = ['ok' => 1];
$sf = $base.'/s/'.$v.'.json';
if (is_file($sf)) {
    $s = json_decode((string) @file_get_contents($sf), true);
    if (is_array($s)) {
        $out['s'] = (int) ($s['t'] ?? 0);
        $out['k'] = (string) ($s['k'] ?? '');
        $out['n'] = (int) ($s['n'] ?? 0);
        if ((int) ($s['ty'] ?? 0) > $now) {
            $out['ty'] = 1;
        }
    }
}
// فاصله «هنوز اینجام» بر اساس تعداد آنلاین‌ها (شمارش هر ۳۰ ثانیه یک بار، فقط توسط یک درخواست)
$nf = $base.'/n.json';
$cnt = is_file($nf) ? json_decode((string) @file_get_contents($nf), true) : null;
if (! is_array($cnt) || (int) ($cnt['t'] ?? 0) < $now - 30) {
    $lk = @fopen($base.'/n.lock', 'c');
    if ($lk && flock($lk, LOCK_EX | LOCK_NB)) {
        $n = 0;
        foreach (glob($base.'/v/*.json') ?: [] as $vf) {
            if (@filemtime($vf) > $now - 80) {
                $n++;
            }
        }
        $cnt = ['n' => $n, 't' => $now];
        @file_put_contents($nf, json_encode($cnt));
        flock($lk, LOCK_UN);
    }
    if ($lk) {
        fclose($lk);
    }
}
$n = (int) ($cnt['n'] ?? 0);
$out['hb'] = $n > 600 ? 60 : ($n > 250 ? 40 : 20);
$on = $base.'/on';
$out['on'] = is_file($on) && filemtime($on) > $now - 90 ? 1 : 0;
echo json_encode($out);
