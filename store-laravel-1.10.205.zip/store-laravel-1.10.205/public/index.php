<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// نسخه PHP هاست کمتر از نیاز برنامه است: پیام فارسی به‌جای خطای انگلیسی
if (PHP_VERSION_ID < 80200) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>نسخه PHP</title>'
        .'<body style="font-family:Tahoma,sans-serif;background:#f6f5f9;padding:24px"><div style="max-width:560px;margin:40px auto;background:#fff;border:1px solid #e3e1ea;border-radius:16px;padding:24px;line-height:2">'
        .'<h2 style="margin:0 0 8px">نسخه PHP هاست را بالا ببرید</h2>'
        .'<p>نسخه فعلی: <b dir="ltr">'.PHP_VERSION.'</b> — این فروشگاه به <b>PHP 8.2 یا بالاتر</b> (پیشنهاد: 8.3) نیاز دارد.</p>'
        .'<ol><li>وارد سی‌پنل شوید.</li><li>بخش <b>Select PHP Version</b> یا <b>MultiPHP Manager</b> را باز کنید.</li><li>نسخه <b>8.3</b> را برای این دامنه انتخاب و ذخیره کنید.</li><li>این صفحه را دوباره باز کنید.</li></ol>'
        .'</div></body></html>';
    exit;
}

// در حال به‌روزرسانی (جابه‌جایی فایل‌ها، چند ثانیه): به‌جای خطای «کد نیمه‌قدیم/نیمه‌جدید»، صفحه کوتاه «چند ثانیه صبر کنید»
$updFlag = __DIR__.'/../storage/framework/updating';
if (is_file($updFlag) && @filemtime($updFlag) > time() - 240) {
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
    if (! preg_match('~^/(health-check|up)(\?|$)~', $uri) && ! str_contains($uri, 'admin/update') && ! str_contains($uri, 'livewire/')) {
        http_response_code(503);
        header('Retry-After: 6');
        header('Cache-Control: no-store');
        $json = str_contains((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'json') || str_ends_with(strtok($uri, '?'), '.php');
        if ($json) {
            header('Content-Type: application/json');
            exit('{"ok":false,"updating":1}');
        }
        header('Content-Type: text/html; charset=utf-8');
        exit('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="6"><title>در حال به‌روزرسانی</title>'
            .'<body style="font-family:Tahoma,sans-serif;background:#f6f5f9;display:grid;place-items:center;min-height:90vh;margin:0"><div style="background:#fff;border-radius:18px;padding:28px 24px;text-align:center;line-height:2;box-shadow:0 10px 30px rgba(0,0,0,.08)">'
            .'<div style="font-size:40px">⏳</div><b>سایت در حال به‌روزرسانی است</b><br><span style="color:#64748b">چند ثانیه دیگر خودکار باز می‌شود…</span></div></body></html>');
    }
}

// اولین اجرا روی هاست: ساخت فایل .env با کلید امن تا نصب‌کننده باز شود
if (! file_exists(__DIR__.'/../.env') && file_exists(__DIR__.'/../.env.example')) {
    $env = (string) file_get_contents(__DIR__.'/../.env.example');
    $env = preg_replace('/^APP_KEY=.*$/m', 'APP_KEY=base64:'.base64_encode(random_bytes(32)), $env);
    @file_put_contents(__DIR__.'/../.env', $env);
}

// اگر فایل‌های برنامه عوض شده‌اند (مثلاً آپلود دستی نسخه جدید)، کش مسیرها و پنل پاک شود
$cacheDir = __DIR__.'/../bootstrap/cache';
$routesCache = $cacheDir.'/routes-v7.php';
if (file_exists($routesCache)) {
    $stamp = (string) @filemtime(__DIR__.'/../config/store.php').'-'.@filemtime(__DIR__.'/../routes/web.php');
    if (@file_get_contents($cacheDir.'/.stamp') !== $stamp) {
        @unlink($routesCache);
        @unlink($cacheDir.'/blade-icons.php');
        foreach (glob($cacheDir.'/filament/*/*') ?: [] as $f) {
            @unlink($f);
        }
        @file_put_contents($cacheDir.'/.stamp', $stamp);
    }
}

// اپ قدیمی عزیزی‌پلاست آدرس‌ها را با دو اسلش می‌سازد (http://aziziplast.com//getHomePage2.php)
if (isset($_SERVER['REQUEST_URI']) && str_starts_with((string) $_SERVER['REQUEST_URI'], '//')) {
    $_SERVER['REQUEST_URI'] = '/'.ltrim((string) $_SERVER['REQUEST_URI'], '/');
}

// Determine if the application is in maintenance mode...
if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) {
    require $maintenance;
}

// Register the Composer autoloader...
require __DIR__.'/../vendor/autoload.php';

// Bootstrap Laravel and handle the request...
/** @var Application $app */
$app = require_once __DIR__.'/../bootstrap/app.php';

$app->handleRequest(Request::capture());
