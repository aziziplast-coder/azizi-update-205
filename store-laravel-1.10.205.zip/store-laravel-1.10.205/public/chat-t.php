<?php
/*
 * «در حال نوشتن…» در گفتگوی سفارش — عمداً بدون بارگذاری سایت (چند میکروثانیه، بدون دیتابیس).
 * فقط زمان «تا کی می‌نویسد» را در فایل کوچک سیگنال همان گفتگو می‌گذارد.
 */
header('Cache-Control: no-store');
header('Content-Type: text/plain; charset=utf-8');
$k = (string) ($_GET['k'] ?? '');
$s = (string) ($_GET['s'] ?? '');
if (! preg_match('/^[A-Za-z0-9]{32}$/', $k) || ($s !== 'c' && $s !== 's')) {
    http_response_code(400);
    exit;
}
$f = __DIR__.'/uploads/_chat/t-'.$k.'.json';
if (! is_file($f) || ! ($fh = @fopen($f, 'c+'))) {
    http_response_code(404);
    exit;
}
flock($fh, LOCK_EX);
$d = json_decode((string) stream_get_contents($fh), true);
$key = $s === 'c' ? 'tc' : 'ts';
$now = time();
if (is_array($d) && (int) ($d[$key] ?? 0) < $now + 3) { // حداکثر هر چند ثانیه یک نوشتن
    $d[$key] = $now + 6;
    $d['now'] = $now;
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($d));
    fflush($fh);
}
flock($fh, LOCK_UN);
fclose($fh);
echo 'ok';
