<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Support\Feed;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

/** خروجی JSON کالاها و دسته‌ها */
class FeedController extends Controller
{
    protected function guard(Request $request): ?\Illuminate\Http\JsonResponse
    {
        $c = Feed::config();
        if (! $c['enabled']) {
            return response()->json(['success' => false, 'message' => 'خروجی JSON غیرفعال است.'], 404);
        }
        if ($c['key'] !== '' && ! hash_equals($c['key'], (string) $request->query('key'))) {
            return response()->json(['success' => false, 'message' => 'کلید دسترسی (key) نادرست است.'], 403);
        }

        return null;
    }

    protected function respond(array $data, int $minutes)
    {
        return response()->json($data, 200, [
            'Access-Control-Allow-Origin' => '*',
            'Cache-Control' => 'public, max-age='.($minutes * 60),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function products(Request $request)
    {
        if ($e = $this->guard($request)) {
            return $e;
        }
        $p = $request->except('key');
        ksort($p);
        $min = Feed::config()['cache'];
        $build = fn () => Feed::build($p);
        $data = $min > 0 ? Cache::remember('feed.'.md5(json_encode($p).request()->getHost()), $min * 60, $build) : $build();

        return $this->respond($data, $min);
    }

    public function category(Request $request, string $slug)
    {
        $request->query->set('category', $slug);

        return $this->products($request);
    }

    public function categories(Request $request)
    {
        if ($e = $this->guard($request)) {
            return $e;
        }
        $key = Feed::config()['key'];
        $counts = \App\Models\Product::query()->where('is_active', true)->selectRaw('category_id, count(*) c')->groupBy('category_id')->pluck('c', 'category_id');
        $cats = Category::query()->orderBy('sort')->orderBy('name')->get();
        $out = $cats->map(fn (Category $c) => [
            'id' => $c->id,
            'name' => $c->name,
            'slug' => $c->slug,
            'parent_id' => $c->parent_id,
            'path' => Feed::categoryPath($c),
            'products' => (int) ($counts[$c->id] ?? 0),
            'url' => $c->url(),
            'feed' => route('feed.category', $c->slug).($key !== '' ? '?key='.$key : ''),
        ])->values();

        return $this->respond(['success' => true, 'store' => store_name(), 'count' => $out->count(), 'categories' => $out], Feed::config()['cache']);
    }
}
