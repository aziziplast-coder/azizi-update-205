<?php

namespace App\Http\Controllers;

use App\Services\StockScan;
use App\Support\XlsWriter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Throwable;

/** به‌روزرسانی روزانه موجودی از فایل‌های اسکنر انبار (صفحه «ورود از اکسل») */
class StockScanController extends Controller
{
    protected function guard(Request $request, ?int $id = null): void
    {
        abort_unless((bool) $request->user()?->hasPerm(StockScan::PERM), 403);
        if ($id !== null) {
            abort_unless(DB::table('stock_scans')->where('id', $id)->exists(), 404);
        }
    }

    public function start(Request $request)
    {
        $this->guard($request);
        $id = DB::table('stock_scans')->insertGetId(['user_id' => $request->user()->id, 'status' => 'uploading', 'created_at' => now(), 'updated_at' => now()]);
        @mkdir(StockScan::dir($id).'/files', 0775, true);
        try {
            StockScan::prune();
        } catch (Throwable) {
        }

        return response()->json(['id' => $id]);
    }

    public function file(Request $request, int $id)
    {
        $this->guard($request, $id);
        $saved = [];
        foreach ((array) $request->file('files', []) as $i => $f) {
            if (! $f || ! $f->isValid()) {
                continue;
            }
            $name = (string) (((array) $request->input('names', []))[$i] ?? $f->getClientOriginalName());
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (! in_array($ext, ['xlsx', 'xls', 'csv', 'xlsb', 'txt'], true) || str_starts_with($name, '~$')) {
                continue;
            }
            $safe = preg_replace('/[^\p{L}\p{N}\-_. ()]+/u', '', $name) ?: 'file.'.$ext;
            $dest = StockScan::dir($id).'/files/'.$safe;
            for ($n = 2; is_file($dest); $n++) {
                $dest = StockScan::dir($id).'/files/'.pathinfo($safe, PATHINFO_FILENAME).' ('.$n.').'.$ext;
            }
            $f->move(dirname($dest), basename($dest));
            $saved[] = basename($dest);
        }

        return response()->json(['ok' => true, 'saved' => $saved]);
    }

    public function analyze(Request $request, int $id)
    {
        $this->guard($request, $id);
        try {
            $kinds = array_filter((array) $request->input('kinds', []), fn ($k) => in_array($k, ['carton', 'retail', 'skip'], true));
            $r = StockScan::analyze($id, $kinds, $request->input('scope') === 'all' ? 'all' : 'covered');
        } catch (Throwable $e) {
            report($e);

            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }

        return response()->json(['ok' => true] + $r, 200, [], JSON_UNESCAPED_UNICODE);
    }

    public function apply(Request $request, int $id)
    {
        $this->guard($request, $id);
        try {
            return response()->json(StockScan::apply($id));
        } catch (Throwable $e) {
            report($e);

            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
    }

    public function undo(Request $request, int $id)
    {
        $this->guard($request, $id);
        try {
            return response()->json(['ok' => true, 'n' => StockScan::undo($id)]);
        } catch (Throwable $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
    }

    /** دانلود فهرست‌ها: c_on، c_off، r_on، r_off، unknown */
    public function report(Request $request, int $id, string $list)
    {
        $this->guard($request, $id);
        $d = StockScan::lists($id);
        $titles = ['c_on' => 'کارتنی موجود شد', 'c_off' => 'کارتنی ناموجود شد', 'r_on' => 'خرده موجود شد', 'r_off' => 'خرده ناموجود شد', 'unknown' => 'کد ناشناخته', 'summary' => 'خلاصه موجودی'];
        abort_unless(isset($titles[$list]), 404);
        $x = new XlsWriter($titles[$list]);
        // خلاصه شمارش‌ها بالای هر گزارش
        $st = json_decode((string) \Illuminate\Support\Facades\DB::table('stock_scans')->where('id', $id)->value('stats'), true) ?: [];
        $c = (array) ($st['counts'] ?? []);
        $sum = [
            ['کل کالاهای موجود پس از این فایل‌ها (کارتنی یا خرده)', $c['all_total'] ?? null],
            ['کل کالاهای کارتنی موجود (تازه موجودشده + از قبل موجود)', $c['c_total'] ?? null],
            ['کل کالاهای خرده موجود (تازه موجودشده + از قبل موجود)', $c['r_total'] ?? null],
            ['کارتنی که موجود شد', $c['c_on'] ?? 0],
            ['خرده که موجود شد', $c['r_on'] ?? 0],
            ['کارتنی که ناموجود شد', $c['c_off'] ?? 0],
            ['خرده که ناموجود شد', $c['r_off'] ?? 0],
            ['کد ناشناخته (در سایت نیست)', $st['unknown'] ?? 0],
        ];
        if ($list === 'summary') {
            $x->row(['شرح', 'تعداد']);
            foreach ($sum as $r) {
                if ($r[1] !== null) {
                    $x->row([$r[0], (int) $r[1]]);
                }
            }

            return response($x->output(), 200, ['Content-Type' => 'application/vnd.ms-excel', 'Content-Disposition' => 'attachment; filename="stock-'.$id.'-summary.xls"']);
        }
        foreach ($sum as $r) {
            if ($r[1] !== null) {
                $x->row([$r[0], fa((int) $r[1])]);
            }
        }
        $x->row(['', '']);
        if ($list === 'unknown') {
            $x->row(['کد', 'فایل']);
            foreach ((array) ($d['unknown'] ?? []) as $u) {
                $x->row([(string) $u[0], (string) $u[1]]);
            }
        } else {
            $x->row(['کد کالا', 'نام کالا', 'انبار عمده', 'انبار خرده']);
            foreach ((array) ($d['lists'][$list] ?? []) as $r) {
                $x->row([(string) $r['c'], (string) $r['n'], (string) $r['w'], (string) ($r['rw'] ?? '')]);
            }
        }

        return response($x->output(), 200, ['Content-Type' => 'application/vnd.ms-excel', 'Content-Disposition' => 'attachment; filename="stock-'.$id.'-'.$list.'.xls"']);
    }
}
