<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Page;
use App\Models\Post;
use App\Models\PostCategory;
use App\Models\Product;
use App\Models\ProductCollection;
use Illuminate\Support\Facades\Cache;

/** نقشه سایت خودکار (فهرست + بخش‌ها با تصویر) و robots.txt */
class SeoController extends Controller
{
    protected const PER = 5000;

    public function sitemap()
    {
        $xml = Cache::remember('sitemap.index.'.request()->getHost(), 3600, function () {
            $parts = ['pages' => now()];
            $parts['categories'] = Category::query()->active()->max('updated_at');
            $n = Product::query()->active()->where('noindex', false)->count();
            for ($i = 1; $i <= max(1, (int) ceil($n / self::PER)); $i++) {
                $parts['products-'.$i] = Product::query()->active()->max('updated_at');
            }
            if (Post::query()->published()->exists()) {
                $parts['posts'] = Post::query()->published()->max('updated_at');
            }
            if (ProductCollection::query()->where('is_active', true)->exists()) {
                $parts['collections'] = ProductCollection::query()->max('updated_at');
            }
            $out = '<?xml version="1.0" encoding="UTF-8"?>'."\n".'<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
            foreach ($parts as $type => $d) {
                $out .= '<sitemap><loc>'.e(route('sitemap.part', $type)).'</loc>'.($d ? '<lastmod>'.\Illuminate\Support\Carbon::parse($d)->toAtomString().'</lastmod>' : '').'</sitemap>';
            }

            return $out.'</sitemapindex>';
        });

        return response($xml, 200, ['Content-Type' => 'application/xml; charset=utf-8']);
    }

    public function part(string $type)
    {
        $xml = Cache::remember('sitemap.'.$type.'.'.request()->getHost(), 3600, function () use ($type) {
            $urls = [];
            if ($type === 'pages') {
                $urls[] = [route('home'), now(), [], '1.0'];
                $urls[] = [route('shop'), now(), [], '0.9'];
                if (data_get(setting('amazing'), 'enabled')) {
                    $urls[] = [route('amazing'), now(), [], '0.8'];
                }
                foreach (Page::query()->where('is_active', true)->get(['slug', 'updated_at']) as $pg) {
                    $urls[] = [$pg->url(), $pg->updated_at, [], '0.5'];
                }
            } elseif ($type === 'categories') {
                foreach (Category::query()->active()->where('noindex', false)->get(['slug', 'legacy_id', 'updated_at', 'image', 'banner', 'name']) as $c) {
                    $urls[] = [$c->url(), $c->updated_at, array_filter([$c->banner ?: $c->image]), '0.8'];
                }
            } elseif (preg_match('/^products-(\d+)$/', $type, $m)) {
                $page = max(1, (int) $m[1]);
                foreach (Product::query()->active()->where('noindex', false)->orderBy('id')->skip(($page - 1) * self::PER)->take(self::PER)->get(['slug', 'legacy_id', 'legacy_slug', 'updated_at', 'image', 'gallery', 'name']) as $p) {
                    $urls[] = [$p->url(), $p->updated_at, array_slice($p->images(), 0, 5), '0.7'];
                }
            } elseif ($type === 'posts') {
                $urls[] = [route('blog'), now(), [], '0.6'];
                foreach (PostCategory::query()->get(['slug', 'updated_at']) as $pc) {
                    $urls[] = [$pc->url(), $pc->updated_at, [], '0.5'];
                }
                foreach (Post::query()->published()->where('noindex', false)->get(['slug', 'updated_at', 'image', 'title', 'legacy_id', 'legacy_slug']) as $p) {
                    $urls[] = [$p->url(), $p->updated_at, array_filter([$p->image]), '0.6'];
                }
            } elseif ($type === 'collections') {
                foreach (ProductCollection::query()->where('is_active', true)->get(['slug', 'updated_at', 'image']) as $c) {
                    $urls[] = [$c->url(), $c->updated_at, array_filter([$c->image]), '0.6'];
                }
            } else {
                abort(404);
            }
            $out = '<?xml version="1.0" encoding="UTF-8"?>'."\n".'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">';
            foreach ($urls as [$u, $d, $imgs, $prio]) {
                $out .= '<url><loc>'.htmlspecialchars($u, ENT_XML1).'</loc>'.($d ? '<lastmod>'.$d->toAtomString().'</lastmod>' : '').'<priority>'.$prio.'</priority>';
                foreach ($imgs as $img) {
                    $out .= '<image:image><image:loc>'.htmlspecialchars(url(upload_url($img)), ENT_XML1).'</image:loc></image:image>';
                }
                $out .= '</url>';
            }

            return $out.'</urlset>';
        });

        return response($xml, 200, ['Content-Type' => 'application/xml; charset=utf-8']);
    }

    public function robots()
    {
        $txt = "User-agent: *\nDisallow: /admin\nDisallow: /admin-tools\nDisallow: /cart\nDisallow: /checkout\nDisallow: /account\nDisallow: /login\nDisallow: /search/\nDisallow: /recent\nDisallow: /push/\nDisallow: /*?*sort=\nDisallow: /*?*f%5B\n";
        if ($extra = trim((string) setting('seo_robots_extra'))) {
            $txt .= $extra."\n";
        }
        $txt .= "\nSitemap: ".route('sitemap')."\n";

        return response($txt, 200, ['Content-Type' => 'text/plain; charset=utf-8']);
    }
}
