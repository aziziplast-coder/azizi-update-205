<?php

namespace App\Http\Controllers;

use App\Models\ChatMessage;
use App\Models\ChatThread;
use App\Models\Factory;
use App\Services\Chat;
use App\Services\FactoryChat;
use Illuminate\Http\Request;
use RuntimeException;

/**
 * گفتگوی حسابداری با کارخانه‌دار — اپ کارخانه‌داران (/factory/chat) و پنل (گفتگو با کارخانه‌دارها).
 * پاسخ‌ها همان شکل گفتگوی سفارش است تا همان پنجره گفتگو (chat.js) استفاده شود.
 */
class FactoryChatController extends Controller
{
    protected const NOCACHE = ['Cache-Control' => 'no-store'];

    /** شناسه مجازی برای پوشه موقت تکه‌های ویدیوی کارخانه‌دار (جدا از کاربران سایت) */
    protected function upId(Factory $f): int
    {
        return 900_000_000 + (int) $f->id;
    }

    protected function json(array $data)
    {
        return response()->json($data, 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /**
     * ثبت پیام از هر دو طرف
     *
     * @param  string  $side  c|s
     */
    protected function store(Request $r, ChatThread $t, string $side, ?\App\Models\User $u, int $upId): ChatMessage
    {
        Chat::$reply = $r->integer('reply') ?: null;
        $type = (string) $r->input('type');
        if ($type === 'voice') {
            return Chat::post($t, $side, $u, 'voice', null, Chat::storeVoice($r->file('voice') ?? throw new RuntimeException('صدا ضبط نشد.'), (int) $r->input('sec')));
        }
        if ($type === 'video') {
            return Chat::post($t, $side, $u, 'video', $r->input('text'), Chat::storeVideo($upId, (string) $r->input('uid'), $r->file('poster'), $r->only(['sec', 'w', 'h'])));
        }
        if ($r->hasFile('image')) {
            return Chat::post($t, $side, $u, 'image', $r->input('text'), Chat::storeImage($r->file('image')));
        }
        $text = trim((string) $r->input('text'));
        if ($text === '') {
            throw new RuntimeException('پیام خالی است.');
        }

        return Chat::post($t, $side, $u, 'text', $text);
    }

    protected static function preview(ChatMessage $m): string
    {
        return match ($m->kind) { 'image' => '📷 عکس فرستاد', 'voice' => '🎤 پیام صوتی فرستاد', 'video' => '🎬 ویدیو فرستاد', default => (string) $m->body };
    }

    /* ======================= کارخانه‌دار ======================= */

    protected function fac(Request $r): Factory
    {
        abort_unless(FactoryChat::enabled(), 404);

        return $r->attributes->get('factory');
    }

    public function page(Request $r)
    {
        $f = $this->fac($r);
        $t = FactoryChat::thread($f);

        return view('factory.chat', ['t' => $t, 'f' => $f]);
    }

    public function show(Request $r)
    {
        $f = $this->fac($r);
        $t = FactoryChat::thread($f);
        if ($before = (int) $r->query('before', 0)) {
            $list = Chat::messages($t, 0, false, 60, $before);

            return $this->json(['ok' => true, 'messages' => $list, 'more' => count($list) >= 60]);
        }
        Chat::markRead($t, 'c');

        return $this->json(FactoryChat::state($t->refresh(), $f, 'c', null, max(0, (int) $r->query('after', 0))));
    }

    public function send(Request $r)
    {
        $f = $this->fac($r);
        $t = FactoryChat::thread($f);
        Chat::clientKey($r->input('ck'));
        if (Chat::alreadyGot($t)) {
            Chat::$clientKey = Chat::$reply = null;

            return $this->json(FactoryChat::state($t->refresh(), $f, 'c', null, max(0, (int) $r->input('after', 0))));
        }
        try {
            $m = $this->store($r, $t, 'c', null, $this->upId($f));
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
        Chat::markRead($t->refresh(), 'c');
        FactoryChat::notifyStaff($f, static::preview($m));

        return $this->json(FactoryChat::state($t->refresh(), $f, 'c', null, max(0, (int) $r->input('after', 0))));
    }

    public function act(Request $r)
    {
        $f = $this->fac($r);
        $t = FactoryChat::thread($f);
        if ($r->input('act') === 'del') {
            $m = ChatMessage::query()->where('thread_id', $t->id)->findOrFail((int) $r->input('mid'));
            if (! Chat::canDelete($m, 'c', null)) {
                return response()->json(['ok' => false, 'msg' => 'این پیام دیگر قابل حذف نیست.'], 422);
            }
            Chat::remove($m);
        }

        return $this->json(FactoryChat::state($t->refresh(), $f, 'c', null, 0));
    }

    public function up(Request $r)
    {
        $f = $this->fac($r);
        try {
            $n = Chat::chunk($this->upId($f), (string) $r->input('uid'), (int) $r->input('i'), $r->file('part') ?? throw new RuntimeException('تکه نرسید.'));
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }

        return response()->json(['ok' => true, 'have' => $n]);
    }

    /* ======================= حسابداری (پنل) ======================= */

    protected function staffFactory(Request $r, int $id): Factory
    {
        abort_unless(FactoryChat::canStaff($r->user()), 403);

        return Factory::query()->findOrFail($id);
    }

    public function staffShow(Request $r, int $factory)
    {
        $f = $this->staffFactory($r, $factory);
        $t = FactoryChat::thread($f);
        if ($before = (int) $r->query('before', 0)) {
            $list = Chat::messages($t, 0, true, 60, $before);

            return $this->json(['ok' => true, 'messages' => $list, 'more' => count($list) >= 60]);
        }
        Chat::markRead($t, 's');

        return $this->json(FactoryChat::state($t->refresh(), $f, 's', $r->user(), max(0, (int) $r->query('after', 0))));
    }

    public function staffSend(Request $r, int $factory)
    {
        $f = $this->staffFactory($r, $factory);
        $t = FactoryChat::thread($f);
        Chat::clientKey($r->input('ck'));
        if (Chat::alreadyGot($t)) {
            Chat::$clientKey = Chat::$reply = null;

            return $this->json(FactoryChat::state($t->refresh(), $f, 's', $r->user(), max(0, (int) $r->input('after', 0))));
        }
        try {
            $this->store($r, $t, 's', $r->user(), (int) $r->user()->id);
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
        FactoryChat::notifyFactory($t->refresh(), $f);

        return $this->json(FactoryChat::state($t->refresh(), $f, 's', $r->user(), max(0, (int) $r->input('after', 0))));
    }

    public function staffAct(Request $r, int $factory)
    {
        $f = $this->staffFactory($r, $factory);
        $t = FactoryChat::thread($f);
        if ($r->input('act') === 'del') {
            $m = ChatMessage::query()->where('thread_id', $t->id)->findOrFail((int) $r->input('mid'));
            if (! Chat::canDelete($m, 's', $r->user())) {
                return response()->json(['ok' => false, 'msg' => 'این پیام دیگر قابل حذف نیست (فقط پیام خودتان و در مهلت تعیین‌شده).'], 422);
            }
            Chat::remove($m);
        } elseif ($r->input('act') === 'read') {
            Chat::markRead($t, 's');
        }

        return $this->json(FactoryChat::state($t->refresh(), $f, 's', $r->user(), 0));
    }

    public function staffUp(Request $r)
    {
        abort_unless(FactoryChat::canStaff($r->user()), 403);
        try {
            $n = Chat::chunk((int) $r->user()->id, (string) $r->input('uid'), (int) $r->input('i'), $r->file('part') ?? throw new RuntimeException('تکه نرسید.'));
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }

        return response()->json(['ok' => true, 'have' => $n]);
    }
}
