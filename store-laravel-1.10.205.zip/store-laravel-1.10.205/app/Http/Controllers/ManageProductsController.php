<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use App\Support\ImageCompressor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * اپ مدیریت ← محصولات: فهرست و ویرایش سریع کالاها مخصوص گوشی
 * (قیمت، موجودی، نمایش، عکس از دوربین، تأیید و انتشار). ویرایش کامل همچنان در پنل.
 */
class ManageProductsController extends Controller
{
    public const TABS = ['all' => 'همه', 'pending' => 'منتظر تأیید', 'out' => 'ناموجود', 'hidden' => 'مخفی', 'nophoto' => 'بی‌عکس', 'nowh' => 'بدون انبار'];

    public const SORTS = ['new' => 'جدیدترین', 'changed' => 'آخرین تغییر', 'sales' => 'پرفروش‌ترین', 'cheap' => 'ارزان‌ترین', 'dear' => 'گران‌ترین'];

    protected function need(Request $r): User
    {
        $u = $r->user();
        abort_unless(ManageController::can($u, 'products'), 403, 'به محصولات دسترسی ندارید.');

        return $u;
    }

    protected function tabQuery(string $tab)
    {
        $q = Product::query();

        return match ($tab) {
            'pending' => $q->where('review', 'pending'),
            'out' => $q->where('in_stock', false),
            'hidden' => $q->where('is_active', false)->where(fn ($w) => $w->whereNull('review')->orWhere('review', '!=', 'pending')),
            'nophoto' => $q->where(fn ($w) => $w->whereNull('image')->orWhere('image', '')),
            'nowh' => \App\Filament\Resources\ProductResource::noWarehouse($q),
            default => $q,
        };
    }

    public static function counts(): array
    {
        return Cache::remember('manage.prod.counts', 60, function () {
            $c = new static;
            $out = [];
            foreach (array_keys(static::TABS) as $t) {
                $out[$t] = $c->tabQuery($t)->count();
            }

            return $out;
        });
    }

    public function index(Request $r)
    {
        $u = $this->need($r);
        $tab = array_key_exists($r->query('tab'), static::TABS) ? $r->query('tab') : 'all';
        $sort = array_key_exists($r->query('sort'), static::SORTS) ? $r->query('sort') : 'new';
        $cat = (int) $r->query('cat');
        $q = trim((string) $r->query('q', ''));
        $list = $this->tabQuery($tab)->with('category:id,name')
            ->when($cat, fn ($w) => $w->whereIn('category_id', array_merge([$cat], Category::query()->where('parent_id', $cat)->pluck('id')->all())))
            ->when($q !== '', function ($w) use ($q) {
                $d = en_digits($q);
                $w->where(fn ($x) => $x->where('sku', $d)->orWhere('barcode', $d)->orWhere('sync_code', $d)->orWhereIn('id', Product::query()->search($q)->select('products.id')));
            })
            ->when($sort === 'new', fn ($w) => $w->latest('id'))
            ->when($sort === 'changed', fn ($w) => $w->orderByDesc('updated_at'))
            ->when($sort === 'sales', fn ($w) => $w->orderByDesc('sales_count'))
            ->when($sort === 'cheap', fn ($w) => $w->orderBy('price'))
            ->when($sort === 'dear', fn ($w) => $w->orderByDesc('price'))
            ->paginate(30)->withQueryString();
        $cats = Category::query()->orderBy('sort')->orderBy('name')->get(['id', 'name', 'parent_id']);

        return view('manage.products', ['u' => $u, 'list' => $list, 'tab' => $tab, 'sort' => $sort, 'cat' => $cat, 'q' => $q,
            'counts' => static::counts(), 'cats' => $cats, 'nav' => 'products']);
    }

    public function show(Request $r, Product $product)
    {
        $u = $this->need($r);
        $cats = Category::query()->orderBy('sort')->orderBy('name')->get(['id', 'name', 'parent_id']);
        $missing = \App\Services\BulkImport::missing($product);

        return view('manage.product', ['u' => $u, 'p' => $product->load('category:id,name'), 'cats' => $cats, 'missing' => $missing, 'nav' => 'products',
            'warehouses' => \App\Models\Warehouse::query()->pluck('name', 'id')]);
    }

    /** ذخیره فرم ویرایش سریع (فقط فیلدهای فرستاده‌شده) */
    public function save(Request $r, Product $product)
    {
        $this->need($r);
        $int = fn ($v) => ($v = preg_replace('/\D/', '', en_digits((string) $v))) === '' ? null : (int) $v;
        $d = $r->validate([
            'name' => 'sometimes|required|string|max:190', 'sku' => 'nullable|string|max:64', 'barcode' => 'nullable|string|max:64',
            'category_id' => 'nullable|integer', 'unit_label' => 'nullable|string|max:40', 'short_description' => 'nullable|string|max:1000',
            'price' => 'nullable', 'compare_price' => 'nullable', 'per_carton' => 'nullable', 'stock' => 'nullable',
            'retail_price' => 'nullable', 'retail_stock' => 'nullable',
        ]);
        $row = [];
        foreach (['name', 'unit_label', 'short_description'] as $k) {
            if ($r->has($k)) {
                $row[$k] = trim((string) $d[$k]) ?: null;
            }
        }
        foreach (['sku', 'barcode'] as $k) {
            if ($r->has($k)) {
                $row[$k] = trim(en_digits((string) $d[$k])) ?: null;
            }
        }
        if ($r->has('sku') && $row['sku'] && Product::query()->where('sku', $row['sku'])->whereKeyNot($product->id)->exists()) {
            return back()->withInput()->with('m_err', 'کد کالای '.fa($row['sku']).' برای کالای دیگری ثبت شده است.');
        }
        if ($r->has('buy_mode')) {
            $m = (string) $r->input('buy_mode');
            $row['buy_mode'] = in_array($m, ['carton', 'pack', 'bulk'], true) ? $m : null;
            $row['buy_qty'] = in_array($m, ['pack', 'bulk'], true) ? ($int($r->input('buy_qty')) ?: null) : null;
            if ($m === 'carton' && (int) ($int($r->input('per_carton')) ?? $product->per_carton) < 2) {
                return back()->withInput()->with('m_err', 'برای «کارتن کامل» تعداد در کارتن را (۲ یا بیشتر) بنویسید.');
            }
        }
        if ($r->has('category_id')) {
            $row['category_id'] = $d['category_id'] ? (int) $d['category_id'] : null;
        }
        foreach (['price', 'compare_price', 'per_carton', 'stock', 'retail_price', 'retail_stock'] as $k) {
            if ($r->has($k)) {
                $row[$k] = $int($r->input($k));
            }
        }
        if (array_key_exists('price', $row)) {
            $row['price'] = (int) $row['price'];
        }
        if (array_key_exists('per_carton', $row)) {
            $row['per_carton'] = max(1, (int) $row['per_carton']);
        }
        foreach (['in_stock', 'is_active', 'retail_enabled', 'retail_in_stock', 'carton_enabled'] as $k) {
            if ($r->has('_b_'.$k)) {
                $row[$k] = $r->boolean($k);
            }
        }
        $product->update($row);
        Cache::forget('manage.prod.counts');

        return redirect()->route('manage.product', $product)->with('m_ok', 'ذخیره شد ✅');
    }

    /** تغییر سریع از فهرست (کلید موجود/نمایش، قیمت و موجودی) — پاسخ JSON */
    public function quick(Request $r, Product $product)
    {
        $this->need($r);
        $f = (string) $r->input('f');
        $int = fn ($v) => ($v = preg_replace('/\D/', '', en_digits((string) $v))) === '' ? null : (int) $v;
        if (in_array($f, ['in_stock', 'is_active'], true)) {
            $product->update([$f => $r->boolean('v')]);
        } elseif ($f === 'price_stock') {
            $row = ['price' => (int) $int($r->input('price'))];
            if ($r->filled('stock') || $r->has('stock')) {
                $row['stock'] = $int($r->input('stock'));
            }
            if ($r->has('in_stock')) {
                $row['in_stock'] = $r->boolean('in_stock');
            }
            $product->update($row);
        } else {
            abort(422);
        }
        Cache::forget('manage.prod.counts');
        $product->refresh();

        return response()->json(['ok' => true, 'in_stock' => $product->in_stock, 'is_active' => $product->is_active, 'review' => $product->review,
            'price' => money($product->price), 'stock' => $product->stock === null ? null : fa($product->stock), 'msg' => 'ذخیره شد']);
    }

    /** ⚡ ویرایش سریع: همان فیلدهای «ویرایش سریع» پنل (قابل انتخاب از «فیلدهای ویرایش سریع») */
    public function qeForm(Request $r, Product $product)
    {
        $this->need($r);

        return view('manage.partials.qe', ['p' => $product, 'fields' => \App\Filament\Resources\ProductResource::quickFields(),
            'cats' => Category::query()->orderBy('sort')->orderBy('name')->get(['id', 'name', 'parent_id']),
            'whs' => \App\Models\Warehouse::query()->where(fn ($w) => $w->whereNull('kind')->orWhere('kind', 'carton'))->pluck('name', 'id')]);
    }

    public function qeSave(Request $r, Product $product)
    {
        $this->need($r);
        $PR = \App\Filament\Resources\ProductResource::class;
        $fields = $PR::quickFields();
        if (in_array('buy_mode', $fields, true)) {
            $fields[] = 'buy_qty';
        }
        if (in_array('name', $fields, true) && $r->has('name') && trim((string) $r->input('name')) === '') {
            return response()->json(['ok' => false, 'msg' => 'نام کالا خالی نمی‌شود.'], 422);
        }
        if (in_array('barcode', $fields, true) && ($bc = trim(en_digits((string) $r->input('barcode')))) && Product::query()->where('barcode', $bc)->whereKeyNot($product->id)->exists()) {
            return response()->json(['ok' => false, 'msg' => 'این بارکد برای کالای دیگری ثبت شده است.'], 422);
        }
        foreach ($fields as $f) {
            if (in_array($f, ['in_stock', 'is_active', 'retail_enabled'], true)) {
                if ($r->has('_b_'.$f)) {
                    $PR::quickSave($product, $f, $r->boolean($f));
                }
            } elseif ($r->has($f)) {
                $v = $r->input($f);
                $PR::quickSave($product, $f, in_array($f, ['sku', 'barcode'], true) ? en_digits((string) $v) : $v);
            }
            $product->refresh();
        }
        session()->forget('filament.notifications'); // پیام‌های پنل در اپ لازم نیست
        Cache::forget('manage.prod.counts');

        return response()->json(['ok' => true, 'msg' => 'ذخیره شد ✅', 'html' => view('manage.partials.pcard', ['p' => $product->load('category:id,name')])->render()]);
    }

    /** انتخاب فیلدهای پنجره ویرایش سریع (همان تنظیم پنل) */
    public function qeFields(Request $r)
    {
        $this->need($r);
        $all = array_keys(\App\Filament\Resources\ProductResource::QUICK_FIELDS);
        $f = array_values(array_intersect($all, (array) $r->input('fields', [])));
        if (! $f) {
            return back()->with('m_err', 'دست‌کم یک فیلد انتخاب کنید.');
        }
        \App\Support\Settings::set(['quick_edit_fields' => $f]);

        return back()->with('m_ok', 'فیلدهای ویرایش سریع ذخیره شد.');
    }

    public function publish(Request $r, Product $product)
    {
        $this->need($r);
        $miss = \App\Services\BulkImport::missing($product);
        if ($miss && ! $r->boolean('force')) {
            return back()->with('m_err', 'کالا ناقص است: '.implode('، ', $miss).'.');
        }
        $product->update(['review' => null, 'is_active' => true]);
        Cache::forget('manage.prod.counts');

        return back()->with('m_ok', 'کالا تأیید و در سایت منتشر شد ✅');
    }

    /** عکس: افزودن (اصلی/گالری) از دوربین یا گالری گوشی، اصلی کردن، حذف */
    public function image(Request $r, Product $product)
    {
        $this->need($r);
        $do = (string) $r->input('do', 'add');
        $gallery = array_values(array_filter((array) $product->gallery));
        if ($do === 'add') {
            $r->validate(['files' => 'required|array|min:1|max:12', 'files.*' => 'file|max:'.(15 * 1024).'|mimes:jpg,jpeg,png,webp']);
            $paths = [];
            foreach ($r->file('files') as $f) {
                $c = ImageCompressor::compress((string) file_get_contents($f->getRealPath()), 1600, 88);
                $path = 'products/'.Str::lower(Str::random(26)).'.'.$c['ext'];
                Storage::disk('public')->put($path, $c['body']);
                $paths[] = $path;
            }
            if ($r->input('as') === 'main' || ! $product->image) {
                if ($product->image) {
                    array_unshift($gallery, $product->image);
                }
                $product->image = array_shift($paths);
            }
            $gallery = array_slice(array_values(array_merge($gallery, $paths)), 0, 12);
        } else {
            $path = (string) $r->input('path');
            $all = $product->images();
            abort_unless(in_array($path, $all, true), 422);
            if ($do === 'main') {
                $gallery = array_values(array_filter($all, fn ($x) => $x !== $path));
                $product->image = $path;
            } elseif ($do === 'delete') {
                if ($product->image === $path) {
                    $product->image = $gallery ? array_shift($gallery) : null;
                } else {
                    $gallery = array_values(array_filter($gallery, fn ($x) => $x !== $path));
                }
            }
        }
        $product->gallery = $gallery ?: null;
        $product->save();
        Cache::forget('manage.prod.counts');

        return redirect()->route('manage.product', $product)->with('m_ok', $do === 'delete' ? 'عکس حذف شد.' : ($do === 'main' ? 'عکس اصلی عوض شد.' : 'عکس اضافه شد ✅'));
    }
}
