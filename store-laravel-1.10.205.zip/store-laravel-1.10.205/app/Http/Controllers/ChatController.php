<?php

namespace App\Http\Controllers;

use App\Models\ChatMessage;
use App\Models\ChatThread;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Models\RemitPayment;
use App\Services\Chat;
use App\Services\ChatFinance;
use App\Services\Remit;
use Illuminate\Http\UploadedFile;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;
use RuntimeException;

/**
 * گفتگوی سفارش — مشتری (صفحه سفارش) و همکار (پنل ← گفتگوها).
 * این مسیرها فقط وقتی صدا زده می‌شوند که فایل سیگنال پیام تازه نشان بدهد یا کسی پیام بفرستد.
 */
class ChatController extends Controller
{
    protected const NOCACHE = ['Cache-Control' => 'no-store'];

    /* ======================= مشتری ======================= */

    protected function ownOrder(Request $r, string $number): Order
    {
        abort_unless(Chat::enabled(), 404);

        return Order::query()->where('number', $number)->where('user_id', $r->user()->id)->firstOrFail();
    }

    protected function customerState(Order $o, ChatThread $t, int $after): array
    {
        $staff = $o->assignee_id ? User::query()->find($o->assignee_id) : null;

        return [
            'ok' => true, 'sig' => Chat::signalUrl($t), 'token' => $t->token, 'last' => (int) $t->last_id,
            'staff' => $staff ? ['name' => Chat::firstName($staff), 'initial' => mb_substr(Chat::firstName($staff), 0, 1)] : null,
            'shop' => store_name(), 'order' => fa($o->number), 'closed' => Chat::closed($t, $o), 'off' => Chat::offHours(),
            'read' => (int) $t->staff_read_id, 'messages' => $msgs = Chat::messages($t, $after), 'more' => ! $after && count($msgs) >= 60,
            'fin' => ['block' => ChatFinance::blocksImages($o)], 'media' => Chat::mediaCfg(), 'del_min' => Chat::cfg()['del_min'], 'react' => 1,
            'addwin' => \App\Services\OrderWindows::addWin($o), // تایمر و کادر افزودن کالا به بار
        ];
    }

    /** کادر افزودن کالا (مشتری): جستجو با نام یا کد */
    protected function addSearch(string $s): array
    {
        if (mb_strlen($s) < 2) {
            return [];
        }
        $rows = Product::query()->active()->search($s)->limit(40)->get()->sortByDesc(fn ($p) => $p->isAvailable() ? 1 : 0)->take(20);

        return $rows->map(function (Product $p) {
            [$min, $step, $custom] = $p->buyRule();
            $c = $p->cartonAvailable();
            $rt = $p->retailAllowed() && $p->retailAvailable();

            return [
                'id' => $p->id, 'name' => $p->name, 'img' => $p->image ? thumb($p->image, 160) : null, 'code' => (string) ($p->sku ?: $p->sync_code),
                'avail' => $c || $rt,
                'carton' => $c ? ['price' => money($p->unitPrice(Product::CARTON)), 'per' => max(1, (int) $p->per_carton), 'boxed' => $p->per_carton > 1 && ! $custom,
                    'unit' => $p->per_carton > 1 && ! $custom ? 'کارتن' : $p->unitName(), 'min' => $custom ? max(1, (int) $min) : 1, 'note' => $custom ? (string) $p->buyRuleText() : ($p->per_carton > 1 ? $p->cartonText() : '')] : null,
                'retail' => $rt ? ['price' => money($p->unitPrice(Product::RETAIL)), 'unit' => $p->unitName()] : null,
                'uname' => $p->unitName(),
            ];
        })->values()->all();
    }

    /** صفحه «گفتگوها» برای مشتری: گفتگوی هر سفارش در یک فهرست (مثل پیام‌رسان) */
    public function customerInbox(Request $r)
    {
        return response()->view('store.chats', ['rows' => $this->inboxRows($r)], 200, self::NOCACHE);
    }

    /** همان فهرست برای اپ کامل */
    public function customerInboxJson(Request $r)
    {
        $rows = $this->inboxRows($r)->map(fn ($x) => [
            'number' => (string) $x->o->number, 'n' => fa($x->o->number), 'status' => $x->o->status, 'status_label' => $x->o->statusLabel(),
            'has' => (bool) $x->has, 'unread' => $x->unread, 'last' => $x->last, 'staff' => $x->staff,
            'at' => $x->at ? ($x->at->isToday() ? fa($x->at->timezone('Asia/Tehran')->format('H:i')) : jdate($x->at)) : '',
        ])->values();

        return response()->json(['ok' => true, 'chats' => $rows, 'unread' => (int) $rows->sum('unread')], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    protected function inboxRows(Request $r)
    {
        abort_unless(Chat::enabled(), 404);
        $u = $r->user();
        $orders = Order::query()->where('user_id', $u->id)->whereNotIn('status', ['failed', 'pending_payment'])
            ->with('assignee:id,name')->orderByDesc('id')->limit(40)->get(['id', 'number', 'status', 'total', 'created_at', 'assignee_id']);
        $threads = ChatThread::query()->whereIn('order_id', $orders->pluck('id'))->get()->keyBy('order_id');
        $rows = $orders->map(function (Order $o) use ($threads) {
            $t = $threads->get($o->id);

            return (object) [
                'o' => $o, 'has' => $t && $t->last_at, 'unread' => $t ? (int) $t->unread_customer : 0,
                'last' => $t && $t->last_at ? ($t->last_side === 'c' ? 'شما: ' : '').$t->last_text : '',
                'at' => $t?->last_at, 'staff' => $o->assignee ? Chat::firstName($o->assignee) : null,
                'open' => in_array($o->status, Order::OPEN, true),
            ];
        })->filter(fn ($x) => $x->has || $x->open)
            ->sortByDesc(fn ($x) => [$x->unread > 0 ? 1 : 0, $x->at ? $x->at->timestamp : $x->o->created_at->timestamp])->values();

        return $rows;
    }

    public function show(Request $r, string $number)
    {
        $o = $this->ownOrder($r, $number);
        $t = Chat::thread($o);
        if ($before = (int) $r->query('before', 0)) { // پیام‌های قدیمی‌تر (اسکرول به بالا)
            $list = Chat::messages($t, 0, false, 60, $before);

            return response()->json(['ok' => true, 'messages' => $list, 'more' => count($list) >= 60], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
        }
        $after = max(0, (int) $r->query('after', 0));
        Chat::markRead($t, 'c');

        return response()->json($this->customerState($o, $t->refresh(), $after), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    public function send(Request $r, string $number)
    {
        $o = $this->ownOrder($r, $number);
        $t = Chat::thread($o);
        if (Chat::closed($t, $o)) {
            return response()->json(['ok' => false, 'msg' => 'این گفتگو بسته شده است.'], 422);
        }
        Chat::$reply = $r->integer('reply') ?: null;
        Chat::clientKey($r->input('ck'));
        if (Chat::alreadyGot($t)) { // همین پیام قبلاً رسیده؛ فقط وضعیت تازه
            Chat::$clientKey = Chat::$reply = null;

            return response()->json($this->customerState($o, $t->refresh(), max(0, (int) $r->input('after', 0))), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
        }
        try {
            $type = (string) $r->input('type');
            if ($type === 'voice') {
                $m = Chat::post($t, 'c', $r->user(), 'voice', null, Chat::storeVoice($r->file('voice') ?? throw new RuntimeException('صدا ضبط نشد.'), (int) $r->input('sec')));
            } elseif ($type === 'video') {
                $m = Chat::post($t, 'c', $r->user(), 'video', $r->input('text'), Chat::storeVideo($r->user()->id, (string) $r->input('uid'), $r->file('poster'), $r->only(['sec', 'w', 'h'])));
            } elseif ($r->hasFile('image')) {
                if (ChatFinance::blocksImages($o)) {
                    return response()->json(['ok' => false, 'msg' => 'فیش واریزی را روی «کارت حواله» همین گفتگو بفرستید (دکمه ارسال فیش)؛ تا مبلغی منتظر واریز است، عکس معمولی فرستاده نمی‌شود.', 'code' => 'pay'], 422);
                }
                $meta = Chat::storeImage($r->file('image'));
                $m = Chat::post($t, 'c', $r->user(), 'image', $r->input('text'), $meta);
            } else {
                $text = trim((string) $r->input('text'));
                if ($text === '') {
                    return response()->json(['ok' => false, 'msg' => 'پیام خالی است.'], 422);
                }
                $m = Chat::post($t, 'c', $r->user(), 'text', $text);
            }
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
        Chat::markRead($t->refresh(), 'c');
        Chat::notifyStaff($t, $o, match ($m->kind) { 'image' => '📷 عکس فرستاد', 'voice' => '🎤 پیام صوتی فرستاد', 'video' => '🎬 ویدیو فرستاد', default => (string) $m->body });
        $after = max(0, (int) $r->input('after', 0));

        return response()->json($this->customerState($o, $t->refresh(), $after), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** پاسخ مشتری به سؤال «بله/خیر» یا پیشنهاد کالا */
    public function act(Request $r, string $number)
    {
        $o = $this->ownOrder($r, $number);
        $t = Chat::thread($o);
        if ($r->input('act') === 'del') { // حذف پیام اشتباه خود مشتری
            $m = ChatMessage::query()->where('thread_id', $t->id)->findOrFail((int) $r->input('mid'));
            if (! Chat::canDelete($m, 'c', $r->user())) {
                return response()->json(['ok' => false, 'msg' => 'این پیام دیگر قابل حذف نیست.'], 422);
            }
            Chat::remove($m);

            return response()->json($this->customerState($o, $t->refresh(), 0) + ['full' => true], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
        }
        if ($r->input('act') === 'guar') { // چک ضمانت مشتری جدید: فقط عکس چک
            $r->validate(['guar_img' => 'nullable|file|max:'.(12 * 1024).'|mimes:jpg,jpeg,png,webp,heic,heif,pdf']);
            try {
                \App\Services\OrderPrior::submitGuar($o, $r->file('guar_img'));
            } catch (\Illuminate\Validation\ValidationException $e) {
                return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
            }

            return response()->json($this->customerState($o->refresh(), $t->refresh(), 0) + ['full' => true], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
        }
        // کادر «افزودن کالا به بار» داخل گفتگو (فرصت پس از جمع‌آوری یا فرستاده‌شده از طرف همکار)
        if (in_array($r->input('act'), ['add_q', 'add', 'add_del', 'add_send'], true)) {
            $act = (string) $r->input('act');
            if ($act === 'add_q') {
                abort_unless($o->canReplace() && ! $o->replace_submitted_at, 403);

                return response()->json(['items' => $this->addSearch(trim((string) $r->input('q')))], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
            }
            $picking = app(\App\Services\Picking::class);
            try {
                if ($act === 'add') {
                    $p = Product::query()->findOrFail((int) $r->input('pid'));
                    $mode = $r->input('mode') === 'retail' ? 'retail' : 'carton';
                    $qty = max(1, min(100000, (int) $r->input('qty')));
                    $units = $mode === 'carton' && $p->per_carton > 1 && ! $p->buyRule()[2] ? $qty * (int) $p->per_carton : $qty;
                    $rep = $picking->addReplacement($o, $p->id, $mode, $units, $r->integer('replaces') ?: null);
                    $msg = '«'.$rep->name.'» ('.$rep->qtyLabel().') اضافه شد. دیگه چی می‌خواید؟';
                } elseif ($act === 'add_del') {
                    $o->replacements()->where('status', 'draft')->whereKey((int) $r->input('rid'))->delete();
                    $msg = 'حذف شد';
                } else {
                    $n = $picking->submitReplacements($o);
                    $msg = \App\Services\OrderWindows::autoAdd() ? fa($n).' کالا به سفارش اضافه شد و برای جمع‌آوری به انبار رفت ✅' : fa($n).' کالا برای تأیید فروشگاه فرستاده شد ✅';
                }
            } catch (\Illuminate\Validation\ValidationException $e) {
                return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
            }

            return response()->json(['toast' => $msg] + $this->customerState($o->refresh(), $t->refresh(), max(0, (int) $r->input('after', 0))), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
        }
        if (in_array($r->input('act'), ['edit', 'like'], true)) { // ویرایش پیام خود / لایک
            $m = ChatMessage::query()->where('thread_id', $t->id)->findOrFail((int) $r->input('mid'));
            if ($r->input('act') === 'edit') {
                $txt = trim((string) $r->input('text'));
                if ($txt === '' || ! Chat::canEdit($m, 'c', $r->user())) {
                    return response()->json(['ok' => false, 'msg' => 'این پیام دیگر قابل ویرایش نیست.'], 422);
                }
                Chat::editMsg($m, $txt);
            } else {
                abort_unless(Chat::canLike($m, 'c'), 422);
                Chat::like($m, 'c');
            }

            return response()->json($this->customerState($o, $t->refresh(), 0) + ['full' => true], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
        }
        $m = ChatMessage::query()->where('thread_id', $t->id)->where('side', 's')->findOrFail((int) $r->input('mid'));
        $meta = (array) $m->meta;
        if ($m->kind === 'confirm' && empty($meta['ans'])) {
            $ans = (string) $r->input('ans');
            abort_unless(in_array($ans, (array) ($meta['opts'] ?? ['بله', 'خیر']), true), 422);
            $meta['ans'] = $ans;
            $m->update(['meta' => $meta]);
            $txt = 'پاسخ مشتری به «'.mb_substr((string) $m->body, 0, 80).'»: '.$ans;
            Chat::post($t, 'c', $r->user(), 'text', $ans, ['reply' => $m->id]);
            Chat::notifyStaff($t, $o, $txt);
            if (($meta['k'] ?? '') === 'dep' && in_array($o->deposit_ask, ['ask', 'edit'], true)) {
                $go = Remit::depositAnswer($o, $ans === (((array) ($meta['opts'] ?? []))[0] ?? Remit::DEP_YES), app(\App\Services\Cart::class));
                if ($go) {
                    Chat::post($t, 'x', null, 'event', '🛒 اقلام سفارش در سبد خرید قرار گرفت؛ تغییرات را انجام دهید و «ثبت تغییرات سفارش» را بزنید. بعد از ثبت، بیعانه با مبلغ تازه صادر می‌شود.', ['r' => 1]);
                } else {
                    \App\Services\OrderWindows::editDone($o, false);
                }
            } elseif (($meta['k'] ?? '') === 'dep2') {
                // فرصت آخر ویرایش (داده‌شده توسط همکار) ← اقلام به سبد
                $go = \App\Services\OrderWindows::goEdit($o, app(\App\Services\Cart::class));
                if (! $go) {
                    Chat::post($t, 'x', null, 'event', 'زمان ویرایش این سفارش تمام شده است.', ['r' => 1]);
                }
            } elseif (($meta['k'] ?? '') === 'pick' || ($meta['k'] ?? '') === 'addbox') {
                // «بار شما جمع شد؛ جایگزین یا کالای جدید؟» / «➕ افزودن کالا به سفارش» ← کادر افزودن همین‌جا در گفتگو
                $yes = $ans === \App\Services\OrderWindows::PICKED_YES || $ans === \App\Services\OrderWindows::ADD_GO;
                $can = $yes && \App\Services\OrderWindows::pickedAnswer($o, $yes);
                if ($yes && ! $can) {
                    Chat::post($t, 'x', null, 'event', 'مهلت افزودن کالا به این سفارش تمام شده است؛ اگر کالایی لازم دارید همین‌جا پیام بدهید.', ['r' => 1]);
                } elseif ($yes) {
                    $openAdd = true;
                }
            }
        } elseif ($m->kind === 'product' && ($meta['st'] ?? '') === 'offer') {
            $ok = $r->boolean('ok');
            $meta['st'] = $ok ? 'accepted' : 'declined';
            $m->update(['meta' => $meta]);
            Chat::post($t, 'c', $r->user(), 'text', ($ok ? '✅ با افزودن «' : '❌ «').$meta['name'].'» ('.$meta['label'].')'.($ok ? ' به سفارش موافقم.' : ' را نمی‌خواهم.'), ['reply' => $m->id]);
            Chat::notifyStaff($t, $o, $ok ? 'مشتری افزودن «'.$meta['name'].'» را تأیید کرد — در گفتگو «اعمال در سفارش» را بزنید.' : 'مشتری «'.$meta['name'].'» را نخواست.');
        }
        Chat::markRead($t->refresh(), 'c');

        return response()->json($this->customerState($o->refresh(), $t->refresh(), max(0, (int) $r->input('after', 0))) + (! empty($go) ? ['go' => $go, 'go_msg' => $goMsg ?? 'در حال رفتن به سبد خرید برای ویرایش…'] : []) + (! empty($openAdd) ? ['open_add' => true] : []), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** تکه ویدیو (مشتری) */
    public function up(Request $r, string $number)
    {
        $this->ownOrder($r, $number);
        try {
            $n = Chat::chunk($r->user()->id, (string) $r->input('uid'), (int) $r->input('i'), $r->file('part') ?? throw new RuntimeException('تکه نرسید.'));
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }

        return response()->json(['ok' => true, 'have' => $n]);
    }

    /** فیش روی کارت حواله (مشتری) */
    public function pay(Request $r, string $number)
    {
        $o = $this->ownOrder($r, $number);
        abort_unless(ChatFinance::remitOn(), 404);
        $p = RemitPayment::query()->where('order_id', $o->id)->findOrFail((int) $r->input('pid'));
        $files = $this->receiptFiles($r);
        if (is_string($files)) {
            return response()->json(['ok' => false, 'msg' => $files], 422);
        }
        try {
            Remit::submit($p, $files, $r->input('ref'));
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }
        // تسویه نهایی بار باربری: نام باربری و مقصد (نزدیک‌ترین شهری که باربری دارد)
        if ($p->kind === 'settle' && \App\Services\Shipping::isFreight($o) && ($r->filled('freight_name') || $r->filled('freight_dest'))) {
            $fn = mb_substr(trim((string) $r->input('freight_name')), 0, 150);
            $fd = mb_substr(trim((string) $r->input('freight_dest')), 0, 120);
            $upd = [];
            if ($fn !== '' && $fn !== (string) $o->freight_name) {
                $upd['freight_name'] = $fn;
            }
            if ($fd !== '' && \App\Services\OrderPrior::on() && $fd !== (string) $o->freight_dest) {
                $upd['freight_dest'] = $fd;
            }
            if ($upd) {
                $o->forceFill($upd)->saveQuietly();
                $o->log('مشتری در تسویه نهایی: باربری «'.($o->freight_name ?: '—').'» — مقصد «'.($o->freight_dest ?: $o->city ?: '—').'»');
                Chat::event($o, '🚚 باربری: '.($o->freight_name ?: '—').' — مقصد بار: '.($o->freight_dest ?: $o->city ?: '—'));
            }
        }
        $t = Chat::thread($o);
        Chat::markRead($t->refresh(), 'c');

        return response()->json($this->customerState($o, $t->refresh(), 0), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** مدارک چک روی کارت چک‌ها (مشتری) */
    public function cheque(Request $r, string $number)
    {
        $o = $this->ownOrder($r, $number);
        abort_unless(ChatFinance::on(), 404);
        try {
            \App\Services\Cheques::submitSettleDocs($o, $r);
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }
        $t = Chat::thread($o);

        return response()->json($this->customerState($o->refresh(), $t->refresh(), 0), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** @return array<UploadedFile>|string */
    protected function receiptFiles(Request $r): array|string
    {
        $files = array_values(array_filter((array) $r->file('receipt'), fn ($f) => $f instanceof UploadedFile));
        if (! $files) {
            return 'تصویر فیش را انتخاب کنید.';
        }
        if (count($files) > 20) {
            return 'حداکثر ۲۰ فیش با هم.';
        }
        foreach ($files as $f) {
            if (! $f->isValid() || $f->getSize() > 12 * 1024 * 1024 || ! in_array(strtolower($f->getClientOriginalExtension() ?: $f->guessExtension()), ['jpg', 'jpeg', 'png', 'webp', 'heic', 'pdf'], true)) {
                return 'فیش باید عکس (jpg، png) یا PDF و حداکثر ۱۲ مگابایت باشد.';
            }
        }

        return $files;
    }

    /* ======================= همکار ======================= */

    protected function staffOrder(Request $r, int $orderId): Order
    {
        abort_unless(Chat::enabled(), 404);
        $o = Order::query()->with('assignee')->findOrFail($orderId);
        abort_unless(Chat::canView($r->user(), $o), 403, 'فقط مسئول همین سفارش به گفتگوی آن دسترسی دارد.');

        return $o;
    }

    /** فهرست گفتگوها: همکار فقط سفارش‌های خودش، مدیر کل همه */
    public function inbox(Request $r)
    {
        abort_unless(Chat::enabled() && $r->user()->hasPerm('chats'), 403);
        $u = $r->user();
        $q = Chat::orders()->with(['order:id,number,customer_name,mobile,status,assignee_id,total,cancel_reason', 'assignee:id,name,mobile'])->whereNotNull('last_at');
        if (! $u->isAdmin()) {
            $q->where('assignee_id', $u->id);
        }
        $f = (string) $r->query('f', 'open');
        if ($f === 'unread') {
            $q->where('unread_staff', '>', 0);
        } elseif ($f === 'waiting') {
            $q->whereNotNull('awaiting_since')->whereNull('closed_at');
        } elseif ($f === 'closed') {
            $q->whereNotNull('closed_at');
        } elseif ($f === 'mine') {
            $q->where('assignee_id', $u->id);
        } elseif ($f === 'nobody') {
            $q->whereNull('assignee_id');
        } elseif ($f === 'cancelled') {
            // سفارش‌های لغوشده (باز یا بسته) — با برچسب علت: عدم واریزی / توسط مشتری
            $q->whereIn('order_id', Order::query()->where('status', 'cancelled')->select('id'));
        } elseif ($f === 'rcpt') {
            // فیش بیعانه/مانده رسیده و منتظر بررسی
            $q->whereNull('closed_at')->whereIn('order_id', \App\Models\RemitPayment::query()->where('status', 'submitted')->whereNotNull('order_id')->select('order_id'));
        } else {
            $q->whereNull('closed_at');
        }
        $s = trim(en_digits((string) $r->query('q', '')));
        if ($s !== '') {
            $q->where(function ($w) use ($s) {
                $w->whereHas('order', fn ($o) => $o->where('number', 'like', '%'.$s.'%')->orWhere('customer_name', 'like', '%'.$s.'%')->orWhere('mobile', 'like', '%'.$s.'%'))
                    ->orWhereIn('id', ChatMessage::query()->where('body', 'like', '%'.$s.'%')->whereIn('side', ['c', 's', 'n'])->select('thread_id'));
            });
        }
        $rows = $q->orderByRaw('CASE WHEN unread_staff > 0 THEN 0 ELSE 1 END')->orderByDesc('last_at')->limit(150)->get();
        // برچسب فیش: بیعانه/مانده‌ای که مشتری فیشش را فرستاده و منتظر بررسی است (و مبلغ صادرشده منتظر واریز)
        $rc = [];
        if (\App\Services\Remit::enabled() && $rows->isNotEmpty()) {
            foreach (\App\Models\RemitPayment::query()->whereIn('order_id', $rows->pluck('order_id'))->whereIn('status', ['submitted', 'awaiting', 'rejected'])
                ->selectRaw('order_id, kind, status, COUNT(*) c')->groupBy('order_id', 'kind', 'status')->get() as $x) {
                $k = $x->kind === 'deposit' ? 'd' : 's';
                $rc[$x->order_id][$x->status === 'submitted' ? $k : $k.'w'] = (int) $x->c;
            }
        }

        return response()->json(['ok' => true, 'threads' => $rows->map(fn (ChatThread $t) => [
            'o' => (int) $t->order_id, 'n' => fa((string) $t->order?->number), 'name' => (string) $t->order?->customer_name,
            'last' => (string) $t->last_text, 'side' => (string) $t->last_side, 'unread' => (int) $t->unread_staff,
            'at' => $t->last_at ? ($t->last_at->isToday() ? fa($t->last_at->timezone('Asia/Tehran')->format('H:i')) : \App\Support\Jalali::format($t->last_at, false)) : '',
            'wait' => $t->awaiting_since ? (int) $t->awaiting_since->diffInMinutes(now(), true) : null, 'closed' => (bool) $t->closed_at,
            'who' => $t->assignee?->displayName(), 'mine' => (int) $t->assignee_id === (int) $r->user()->id,
            'sk' => (string) $t->order?->status, 'sl' => (string) ($t->order ? $t->order->statusLabel() : ''),
            'rc' => $rc[$t->order_id] ?? null,
            'cx' => $t->order?->status === 'cancelled' ? self::cancelTag((string) $t->order->cancel_reason) : null,
        ])->values(), 'unread' => Chat::unreadFor($u)], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** برچسب علت لغو در فهرست گفتگو */
    public static function cancelTag(string $reason): array
    {
        $auto = str_contains($reason, 'لغو خودکار') || str_contains($reason, 'واریز نشد') || str_contains($reason, 'پرداخت انجام نشد') || str_contains($reason, 'عدم واریز');

        return ['t' => $auto ? 'عدم واریزی' : 'توسط مشتری', 'k' => $auto ? 'pay' : 'cust', 'why' => mb_substr($reason, 0, 160)];
    }

    protected function staffState(Request $r, Order $o, ChatThread $t, int $after, bool $full = false): array
    {
        $u = $r->user();
        $out = [
            'ok' => true, 'o' => $o->id, 'sig' => Chat::signalUrl($t), 'token' => $t->token, 'last' => (int) $t->last_id, 'read' => (int) $t->customer_read_id,
            'closed' => Chat::closed($t, $o), 'can_send' => Chat::canSend($u, $o), 'can_manage' => Chat::canManage($u, $o),
            'messages' => $msgs = Chat::messages($t, $after, true), 'more' => ! $after && count($msgs) >= 60,
            'media' => Chat::mediaCfg(), 'del_min' => Chat::cfg()['del_min'], 'react' => 1, 'me' => (int) $u->id,
            'pins' => \App\Services\OrderPins::list($o, $u, Chat::canManage($u, $o)),
            'addwin' => (\App\Services\OrderWindows::addWin($o) ?? ['open' => false, 'review' => false]) + ['can' => in_array($o->fulfil_status, ['picked'], true) && ! $o->isPaid() && in_array($o->status, ['on_hold', 'processing', 'settling'], true)
                && $u->hasPerm('orders_edit') && ($u->isAdmin() || (int) $o->assignee_id === (int) $u->id), 'hours' => (float) setting('replace_hours', 6)],
        ];
        if ($full) {
            $out['fin'] = ChatFinance::on() ? ChatFinance::summary($o, $u) : null;
            $out['pops'] = \App\Services\OrderWindows::pops($o, $u);
        }
        if ($full) {
            $out['head'] = [
                'number' => fa($o->number), 'name' => $o->customer_name, 'mobile' => fa((string) $o->mobile), 'status' => $o->statusLabel(), 'status_key' => $o->status,
                'assignee' => $o->assignee?->displayName(), 'assignee_id' => (int) $o->assignee_id, 'url' => url('/admin/orders/'.$o->id),
                'total' => money($o->total), 'tracking' => (string) $o->tracking_code, 'invoice' => route('invoice', $o->number),
                'print' => \App\Services\Chat::printLocked($o) ? null : route('admin.invoice', ['order' => $o->id, 'plain' => 1]),
                'printed' => ($pe = \App\Models\OrderEvent::query()->where('order_id', $o->id)->where('message', 'like', '🖨 فاکتور کامل از گفتگو چاپ شد%')->latest('id')->first())
                    ? ['n' => \App\Models\OrderEvent::query()->where('order_id', $o->id)->where('message', 'like', '🖨 فاکتور کامل از گفتگو چاپ شد%')->count(),
                        'at' => jdate($pe->created_at, true), 'by' => trim((string) \Illuminate\Support\Str::after($pe->message, '— '))] : null,
            ];
            $out['card'] = $this->customerCard($o);
            $out['quick'] = array_map(fn ($q) => ['title' => (string) ($q['title'] ?? mb_substr((string) $q['text'], 0, 24)), 'text' => Chat::fill((string) $q['text'], $o, $u)], Chat::cfg()['quick']);
            $out['staff'] = $u->isAdmin() || Chat::canManage($u, $o)
                ? User::query()->where('is_active', true)->whereIn('role', ['admin', 'staff'])->orderBy('name')->get()->filter(fn ($x) => $x->hasPerm('chats'))->map(fn ($x) => ['id' => $x->id, 'name' => $x->displayName()])->values()->all()
                : [];
            // ترتیب اقلام = ترتیب حواله کامل انبار (شماره انبار، عمده پیش از خرده)
            $its = $o->items()->with('warehouse')->get(['id', 'product_id', 'name', 'image', 'mode', 'units', 'per_carton', 'unit_price', 'total', 'pick_status', 'pick_task_id', 'warehouse_id']);
            $whMeta = \App\Models\Warehouse::query()->whereIn('id', $its->pluck('warehouse_id')->filter()->unique())->get()->keyBy('id');
            $openTasks = \App\Models\PickTask::query()->whereIn('id', $its->pluck('pick_task_id')->filter()->unique())->where('status', '!=', 'done')->pluck('id')->map(fn ($v) => (int) $v)->all();
            $out['items'] = \App\Support\Slips::sortItems($its, $whMeta)->map(fn ($i) => [
                'id' => $i->id, 'name' => $i->name, 'short' => in_array($i->pick_status, ['short', 'missing'], true),
                'pc' => \App\Services\OrderEdit::packSize($i), 'qty' => intdiv((int) $i->units, \App\Services\OrderEdit::packSize($i)), 'carton' => $i->mode === Product::CARTON && \App\Services\OrderEdit::packSize($i) > 1,
                'units' => (int) $i->units, 'per' => max(1, (int) $i->per_carton), 'boxed' => $i->mode === Product::CARTON && (int) $i->per_carton > 1,
                'whn' => $i->warehouse?->label() ?? 'بدون انبار',
                'label' => \App\Services\OrderEdit::label((string) $i->mode, (int) $i->units, (int) $i->per_carton), 'price' => money($i->unit_price), 'up' => (int) $i->unit_price, 'total' => money($i->total),
                // قفل فقط وقتی انباردار همین الان مشغول این قلم است؛ قلم جمع‌شده هم قابل اصلاح است
                'lock' => $i->pick_status !== null && in_array((int) $i->pick_task_id, $openTasks, true), 'picked' => $i->pick_status !== null,
                'wh' => (bool) $i->pick_task_id, 'img' => $i->image ? thumb($i->image, 120) : null,
            ])->values()->all();
            $out['order'] = $this->orderFlow($o, $u);
            $out['wait'] = $t->awaiting_since && ! $t->closed_at ? (int) $t->awaiting_since->diffInMinutes(now(), true) : null;
            $out['off'] = Chat::offHours();
        }

        return $out;
    }

    /** کارت مشتری کنار گفتگو (سبک: بدون آمار و سفارش‌های قبلی) */
    protected function customerCard(Order $o): array
    {
        $u = $o->user_id ? User::query()->find($o->user_id, ['id', 'note']) : null;

        return ['city' => trim(($o->province ? $o->province.'، ' : '').$o->city), 'company' => (string) $o->company, 'note' => (string) ($u->note ?? ''), 'order_note' => (string) $o->note];
    }

    /** مراحل سفارش، مرحله بعد و اجازه تغییر وضعیت/ویرایش برای کارت کنار گفتگو */
    protected function orderFlow(Order $o, User $u): array
    {
        $flow = ['on_hold', 'processing', 'settling', 'shipped', 'completed'];
        $short = ['on_hold' => 'بیعانه', 'processing' => 'جمع‌آوری', 'settling' => 'تسویه', 'to_freight' => 'باربری', 'shipped' => 'باربری', 'completed' => 'تکمیل'];
        $i = array_search($o->status === 'to_freight' ? 'shipped' : $o->status, $flow, true); // (to_freight قدیمی)
        $canStatus = $u->hasPerm('orders_edit') && $o->review_status !== 'pending' && ($u->isAdmin() || (int) $o->assignee_id === (int) $u->id);
        $next = null;
        $block = null;
        if ($i !== false && $i < count($flow) - 1) {
            $k = $flow[$i + 1];
            $next = ['k' => $k, 'label' => Order::STATUSES[$k]];
            $block = $o->statusBlockReason($k, $u);
        }
        $since = $o->status_changed_at ?? $o->created_at;
        $m = $since ? (int) $since->diffInMinutes(now(), true) : 0;
        $items = $o->items()->get(['pick_status', 'pick_task_id']);
        $inWh = $items->whereNotNull('pick_task_id');

        return [
            'cur' => $o->status, 'label' => $o->statusLabel(), 'idx' => $i === false ? -1 : $i,
            'steps' => array_map(fn ($k) => ['k' => $k, 'label' => $short[$k]], $flow),
            'since' => fa($m < 60 ? max(1, $m).' دقیقه' : ($m < 2880 ? intdiv($m, 60).' ساعت' : intdiv($m, 1440).' روز')),
            'next' => $next, 'block' => $block, 'can_status' => $canStatus,
            'allowed' => $canStatus ? collect($o->allowedStatuses($u))->except($o->status)->map(fn ($l, $k) => ['k' => $k, 'label' => $l])->values()->all() : [],
            'note_req' => (bool) ($u->force_followup && setting('followup_note', true)),
            'edit' => \App\Services\OrderEdit::why($o, $u), 'reduce_only' => \App\Services\OrderEdit::onlyReduce($o),
            'pay' => (string) $o->payment_title, 'pay_key' => \App\Services\PayMethod::isCheque($o) ? 'cheque' : (string) $o->payment_method,
            'pays' => \App\Services\PayMethod::can($u, $o) ? collect(\App\Services\PayMethod::options())->map(fn ($l, $k) => ['k' => $k, 'label' => $l])->values()->all() : [],
            'reorder' => $o->reorderAllowed(), 'can_reorder' => $u->hasPerm('orders_edit') && setting('one_open_order', true) && $o->isOpen() && \App\Support\DbSchema::hasColumn('orders', 'reorder_ok'),
            'pick' => $o->fulfil_status === 'picking' && $inWh->count() ? ['done' => $inWh->whereNotNull('pick_status')->count(), 'all' => $inWh->count()] : null,
            'fulfil' => $o->fulfil_status ? (Order::FULFIL[$o->fulfil_status] ?? null) : null, 'repl' => $o->fulfil_status === 'replace_review',
            'n' => $items->count(), 'ship' => (string) $o->shipping_title, 'tracking' => (string) $o->tracking_code,
            'cancelled' => in_array($o->status, ['cancelled', 'failed'], true),
        ];
    }

    public function staffShow(Request $r, int $order)
    {
        $o = $this->staffOrder($r, $order);
        $t = Chat::thread($o);
        if ($before = (int) $r->query('before', 0)) {
            $list = Chat::messages($t, 0, true, 60, $before);

            return response()->json(['ok' => true, 'messages' => $list, 'more' => count($list) >= 60], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
        }
        $after = max(0, (int) $r->query('after', 0));
        // فقط مسئول خواندن را ثبت می‌کند (مدیری که فقط نظارت می‌کند، «خوانده شد» نمی‌زند)
        if ((int) $o->assignee_id === (int) $r->user()->id) {
            Chat::markRead($t, 's');
        }

        return response()->json($this->staffState($r, $o, $t->refresh(), $after, ! $after && ! $r->boolean('lite')), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** یادداشت پین‌شده: ویرایش / حذف */
    public function staffPin(Request $r, int $order)
    {
        $o = $this->staffOrder($r, $order);
        $u = $r->user();
        $id = (int) $r->input('id');
        try {
            $can = Chat::canManage($u, $o);
            $own = \App\Support\DbSchema::hasTable('order_pins') && \Illuminate\Support\Facades\DB::table('order_pins')->where('id', $id)->where('user_id', $u->id)->exists();
            abort_unless($can || $own, 403);
            match ((string) $r->input('act')) {
                'edit' => \App\Services\OrderPins::edit($o, $u, $id, (string) $r->input('text')),
                'del' => \App\Services\OrderPins::delete($o, $u, $id),
                default => abort(422),
            };
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true, 'pins' => \App\Services\OrderPins::list($o, $u, Chat::canManage($u, $o))], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    public function staffSend(Request $r, int $order)
    {
        $o = $this->staffOrder($r, $order);
        $t = Chat::thread($o);
        $u = $r->user();
        $type = (string) $r->input('type', 'text');
        Chat::$reply = $r->integer('reply') ?: null;
        Chat::clientKey($r->input('ck'));
        if (Chat::alreadyGot($t)) {
            Chat::$clientKey = Chat::$reply = null;

            return response()->json($this->staffState($r, $o, $t->refresh(), max(0, (int) $r->input('after', 0))), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
        }
        if ($type === 'note') {
            abort_unless(Chat::canManage($u, $o), 403);
            $text = trim((string) $r->input('text'));
            abort_if($text === '', 422, 'یادداشت خالی است.');
            $m = Chat::post($t, 'n', $u, 'text', $text);
            \App\Services\OrderPins::add($o, $u, 'text', $text, [], $m?->id); // پین بالای گفتگو
        } elseif ($type === 'note_voice') {
            // یادداشت داخلی صوتی (پین‌شده)
            abort_unless(Chat::canManage($u, $o), 403);
            try {
                $meta = Chat::storeVoice($r->file('voice') ?? throw new RuntimeException('صدا ضبط نشد.'), (int) $r->input('sec'));
            } catch (RuntimeException $e) {
                return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
            }
            $m = Chat::post($t, 'n', $u, 'voice', null, $meta);
            \App\Services\OrderPins::add($o, $u, 'voice', null, $meta, $m?->id);
        } else {
            if (! Chat::canSend($u, $o)) {
                return response()->json(['ok' => false, 'msg' => 'فقط مسئول همین سفارش می‌تواند به مشتری پیام بدهد. اول سفارش را بردارید یا به خودتان بسپارید.'], 403);
            }
            if (Chat::closed($t, $o)) {
                return response()->json(['ok' => false, 'msg' => 'این گفتگو بسته شده است.'], 422);
            }
            try {
                $m = match ($type) {
                    'image' => Chat::post($t, 's', $u, 'image', $r->input('text'), Chat::storeImage($r->file('image') ?? throw new RuntimeException('عکسی انتخاب نشده است.'))),
                    'voice' => Chat::post($t, 's', $u, 'voice', null, Chat::storeVoice($r->file('voice') ?? throw new RuntimeException('صدا ضبط نشد.'), (int) $r->input('sec'))),
                    'video' => Chat::post($t, 's', $u, 'video', $r->input('text'), Chat::storeVideo($u->id, (string) $r->input('uid'), $r->file('poster'), $r->only(['sec', 'w', 'h']))),
                    'product' => Chat::post($t, 's', $u, 'product', trim((string) $r->input('text')) ?: null,
                        Chat::productMeta(Product::query()->findOrFail((int) $r->input('pid')), (string) $r->input('mode', 'carton'), max(1, (int) $r->input('qty', 1)), $r->integer('replaces') ?: null)),
                    'confirm' => Chat::post($t, 's', $u, 'confirm', trim((string) $r->input('text')) ?: throw new RuntimeException('متن سؤال را بنویسید.'), ['opts' => ['بله', 'خیر'], 'ans' => null]),
                    'invoice' => Chat::post($t, 's', $u, 'invoice', 'فاکتور سفارش '.fa($o->number).' — مبلغ '.money($o->total).' تومان', ['url' => route('invoice', $o->number)]),
                    default => Chat::post($t, 's', $u, 'text', trim((string) $r->input('text')) ?: throw new RuntimeException('پیام خالی است.')),
                };
            } catch (RuntimeException $e) {
                return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
            }
            Chat::notifyCustomer($t->refresh(), $o, match ($m->kind) {
                'image' => '📷 عکس فرستاد', 'voice' => '🎤 پیام صوتی', 'video' => '🎬 ویدیو', 'product' => '🛒 پیشنهاد کالا: '.(((array) $m->meta)['name'] ?? ''), 'invoice' => '🧾 فاکتور سفارش',
                default => (string) $m->body,
            }, $u);
        }

        return response()->json($this->staffState($r, $o, $t->refresh(), max(0, (int) $r->input('after', 0))), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** اعمال پیشنهاد تأییدشده، سپردن گفتگو، برداشتن سفارش */
    public function staffAct(Request $r, int $order)
    {
        $o = $this->staffOrder($r, $order);
        $t = Chat::thread($o);
        $u = $r->user();
        $act = (string) $r->input('act');
        try {
            if ($act === 'pop') {
                \App\Services\OrderWindows::dropPop($o, (string) $r->input('k'));
            } elseif ($act === 'ext') {
                abort_unless($u->hasPerm('orders_edit') && ($u->isAdmin() || (int) $o->assignee_id === (int) $u->id), 403);
                $toast = \App\Services\OrderWindows::extend($o, $u);
            } elseif ($act === 'addwin' || $act === 'addbox') {
                // زمان فرصت افزودن مشتری (۰ = بستن) / فرستادن «کادر افزودن به سفارش»
                abort_unless($u->hasPerm('orders_edit') && ($u->isAdmin() || (int) $o->assignee_id === (int) $u->id), 403);
                $h = (float) $r->input('hours', setting('replace_hours', 6));
                $toast = $act === 'addwin' ? \App\Services\OrderWindows::setWindow($o, $h, $u) : \App\Services\OrderWindows::sendBox($o, $u, $h > 0 ? $h : (float) setting('replace_hours', 6));
            } elseif ($act === 'repl') {
                abort_unless($u->hasPerm('orders_edit') && ($u->isAdmin() || (int) $o->assignee_id === (int) $u->id), 403);
                $toast = \App\Services\OrderWindows::replDecide($o, $r->boolean('ok'), $u, $r->input('reason'));
                // تأیید شد و به انبار رفت ← چاپ مستقیم حواله فقط کالاهای افزوده (با جایگاه بقیه بار)
                if ($r->boolean('ok') && ($rnd = (int) $o->items()->where('units', '>', 0)->max('round')) > 1 && ! Chat::printLocked($o->refresh())) {
                    $printAsk = ['url' => route('admin.invoice', ['order' => $o->id, 'wh' => 'add-'.$rnd]), 'title' => 'کالاهای افزوده به انبار رفت — چاپ حواله افزوده‌ها',
                        'note' => 'فقط کالاهایی که مشتری اضافه کرده، مثل حواله انبار، با جایگاه بقیه بار این سفارش.'];
                }
            } elseif ($act === 'apply') {
                abort_unless(Chat::canSend($u, $o), 403);
                Chat::applyOffer(\App\Models\ChatMessage::query()->where('thread_id', $t->id)->findOrFail((int) $r->input('mid')), $u);
            } elseif ($act === 'assign') {
                abort_unless(Chat::canManage($u, $o), 403);
                $to = (int) $r->input('to');
                $target = User::query()->where('is_active', true)->findOrFail($to);
                abort_unless($target->hasPerm('chats'), 422);
                $note = trim((string) $r->input('note'));
                if ($note !== '') {
                    Chat::post($t, 'n', $u, 'text', 'سپردن گفتگو به '.$target->displayName().': '.$note);
                }
                $o->assignTo($target->id, $u->id, 'از گفتگو');
            } elseif ($act === 'del') {
                $m = \App\Models\ChatMessage::query()->where('thread_id', $t->id)->findOrFail((int) $r->input('mid'));
                if (! Chat::canDelete($m, 's', $u)) {
                    throw new RuntimeException('این پیام دیگر قابل حذف نیست (فقط پیام خودتان و در مهلت تعیین‌شده).');
                }
                Chat::remove($m);
                $toast = 'پیام حذف شد.';
            } elseif ($act === 'edit' && $r->filled('mid')) { // ویرایش متن پیام (ویرایش اقلام سفارش هم act=edit است ولی mid ندارد)
                $m = \App\Models\ChatMessage::query()->where('thread_id', $t->id)->findOrFail((int) $r->input('mid'));
                $txt = trim((string) $r->input('text'));
                if ($txt === '' || ! Chat::canEdit($m, 's', $u)) {
                    throw new RuntimeException('این پیام دیگر قابل ویرایش نیست (فقط پیام متنی خودتان و در مهلت تعیین‌شده).');
                }
                Chat::editMsg($m, $txt);
                $toast = 'پیام ویرایش شد.';
            } elseif ($act === 'like') {
                $m = \App\Models\ChatMessage::query()->where('thread_id', $t->id)->findOrFail((int) $r->input('mid'));
                abort_unless(Chat::canLike($m, 's'), 422);
                Chat::like($m, 's');
            } elseif ($act === 'read') {
                Chat::markRead($t, 's');
            } elseif ($act === 'status') {
                abort_unless($u->hasPerm('orders_edit') && ($u->isAdmin() || (int) $o->assignee_id === (int) $u->id), 403, 'فقط مسئول سفارش (با دسترسی ویرایش) وضعیت را عوض می‌کند.');
                abort_if($o->review_status === 'pending', 422, 'سفارش در صف بررسی چک است.');
                $to = (string) $r->input('status');
                abort_unless(array_key_exists($to, Order::STATUSES), 422);
                if ($why = $o->statusBlockReason($to, $u)) {
                    throw new RuntimeException($why);
                }
                $note = trim((string) $r->input('note'));
                if ($to === 'cancelled' && $note === '') {
                    throw new RuntimeException('علت لغو سفارش را بنویسید.');
                }
                if ($note === '' && $u->force_followup && setting('followup_note', true)) {
                    throw new RuntimeException('توضیح پیگیری را بنویسید.');
                }
                if ($to === 'shipped' && $r->filled('tracking')) {
                    $o->tracking_code = mb_substr(trim(en_digits((string) $r->input('tracking'))), 0, 60);
                    $o->save();
                }
                $o->setStatus($to, $note ?: 'از گفتگو', true, $r->boolean('sms', true) ? 'default' : 'none');
                $toast = 'وضعیت سفارش: '.$o->statusLabel();
            } elseif ($act === 'printed') {
                // چاپ فاکتور کامل برای سرپرست انبار ← تیک «چاپ شد» کنار دکمه (برای همه همکاران)
                Chat::markPrinted($o, $u);
                $toast = 'چاپ فاکتور ثبت شد ✓';
            } elseif ($act === 'paymethod') {
                $toast = \App\Services\PayMethod::change($o, (string) $r->input('method'), $u);
                Chat::post($t, 'x', null, 'event', '💳 '.$toast, ['r' => 1]);
            } elseif ($act === 'reorder') {
                if (! $u->hasPerm('orders_edit')) {
                    throw new RuntimeException('برای این کار دسترسی «ویرایش سفارش» لازم است.');
                }
                $o->reorder_ok = $r->boolean('on');
                $o->saveQuietly();
                $o->log(($o->reorder_ok ? 'اجازه ثبت سفارش جدید به مشتری داده شد' : 'اجازه سفارش جدید مشتری بسته شد').' (از گفتگو — '.$u->displayName().')', $u->id);
                if ($o->reorder_ok) {
                    Chat::post($t, 's', $u, 'text', '✅ اجازه ثبت سفارش جدید برای شما باز شد؛ می‌توانید از سایت یا اپ سفارش تازه ثبت کنید.');
                    Chat::notifyCustomer($t->refresh(), $o, '🛒 اجازه ثبت سفارش جدید برای شما باز شد', $u);
                } else {
                    Chat::post($t, 'x', null, 'event', '🛒 اجازه سفارش جدید مشتری بسته شد', ['r' => 1]);
                }
                $toast = $o->reorder_ok ? 'مشتری حالا می‌تواند سفارش جدید ثبت کند (یک‌بار)' : 'اجازه سفارش جدید بسته شد';
            } elseif ($act === 'edit') {
                $lines = [];
                foreach ((array) $r->input('lines', []) as $id => $qty) {
                    $lines[(int) $id] = (int) en_digits((string) $qty);
                }
                foreach ((array) $r->input('ul', []) as $id => $qty) { // اصلاح به عدد
                    $lines[(int) $id] = ['u' => (int) en_digits((string) $qty)];
                }
                $adds = array_values(array_filter(array_map(fn ($a) => ['pid' => (int) ($a['pid'] ?? 0), 'mode' => (string) ($a['mode'] ?? 'carton'), 'qty' => (int) en_digits((string) ($a['qty'] ?? 1))], (array) $r->input('adds', [])), fn ($a) => $a['pid'] > 0 && $a['qty'] > 0));
                $text = \App\Services\OrderEdit::apply($o, $lines, $adds, $u, $r->boolean('short'));
                Chat::post($t, 'x', null, 'event', $text, ['r' => 1]);
                if ($r->boolean('short') && $o->refresh()->canReplace()) {
                    Chat::post($t, 's', $u, 'text', '🔄 برای کالاهای کسری می‌توانید از صفحه سفارش جایگزین انتخاب کنید یا هر کالای دیگری اضافه کنید؛ اقلام تازه به‌صورت پیوست فاکتور به سفارش اضافه می‌شوند:'."\n".route('order.show', $o->number).'#replace');
                }
                Chat::notifyCustomer($t->refresh(), $o->refresh(), '🛒 سفارش شما ویرایش شد — مبلغ تازه: '.money($o->total).' تومان', $u);
                $toast = 'سفارش ویرایش شد'.($o->final_amount && Remit::payments($o, 'settle')->isNotEmpty() && ! $o->isPaid() ? ' — مانده حساب قبلاً صادر شده؛ «اصلاح مانده حساب» را بزنید.' : '.');
            }
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
        $o->refresh();
        if (! Chat::canView($u, $o)) {
            return response()->json(['ok' => true, 'gone' => true]);
        }

        return response()->json((isset($toast) ? ['toast' => $toast] : []) + (isset($printAsk) ? ['print_ask' => $printAsk] : []) + $this->staffState($r, $o, $t->refresh(), 0, true), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** تکه ویدیو (همکار) */
    public function staffUp(Request $r)
    {
        abort_unless(Chat::enabled() && $r->user()->hasPerm('chats'), 403);
        try {
            $n = Chat::chunk($r->user()->id, (string) $r->input('uid'), (int) $r->input('i'), $r->file('part') ?? throw new RuntimeException('تکه نرسید.'));
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }

        return response()->json(['ok' => true, 'have' => $n]);
    }

    /**
     * امور مالی از داخل گفتگو: صدور بیعانه/مانده، ثبت فیش به‌جای مشتری، تبدیل عکس گفتگو به فیش،
     * تأیید (کامل یا با مبلغ کمتر)، رد، اصلاح مبلغ، ابطال، بررسی مدارک چک — همه با همان سیستم حواله‌ها.
     */
    public function staffFin(Request $r, int $order)
    {
        $o = $this->staffOrder($r, $order);
        abort_unless(ChatFinance::on(), 404);
        $u = $r->user();
        $act = (string) $r->input('act');
        $pay = function () use ($r, $o): RemitPayment {
            return RemitPayment::query()->with(['remittance', 'order'])->where('order_id', $o->id)->findOrFail((int) $r->input('pid'));
        };
        $review = function (RemitPayment $p) use ($u) {
            abort_unless(ChatFinance::canReview($u, $p), 403, 'بررسی این فیش با کمک‌حسابدار همین حواله یا سفارش است.');
        };
        $by = 'بارگذاری توسط '.$u->displayName().' (از گفتگو)';
        try {
            switch ($act) {
                case 'issue':
                    abort_unless(Remit::enabled() && Remit::canWork($u), 403);
                    $kind = (string) $r->input('kind');
                    $prior = $r->only(['holoo_type', 'holoo_amount', 'holoo_in_dep', 'guar_amount']);
                    if ($r->has('new_customer')) {
                        $prior['new_customer'] = $r->boolean('new_customer');
                    }
                    if ($kind === 'deposit') {
                        $amount = (int) \App\Services\OrderPrior::apply($o, $prior, $u, (int) to_int($r->input('amount')));
                        $o->refresh();
                        $made = Remit::issue($o, 'deposit', $amount, null, $u);
                        Remit::notifyCustomer($o, 'deposit');
                        $msg = 'بیعانه '.money($made->sum('amount')).' تومان صادر شد.';
                    } else {
                        $isCheque = $o->payment_method === 'cheque' || ! empty(((array) $o->cheque)['settle']) || ! empty(((array) $o->cheque)['cheques']);
                        if ($isCheque) {
                            throw new RuntimeException('برای سفارش چکی، «صدور مانده حساب» را از صفحه سفارش بزنید (مشخصات چک‌ها لازم است).');
                        }
                        if (\App\Services\Shipping::isFreight($o) && $r->filled('freight_fee')) {
                            \App\Services\Shipping::setFreightFee($o, (int) to_int($r->input('freight_fee')), $u);
                            $o->refresh();
                        }
                        \App\Services\OrderPrior::apply($o, $prior, $u);
                        $o->refresh();
                        $made = Remit::settleFull($o, (int) to_int($r->input('discount', 0)), null, null, null, $u);
                        if ($made) {
                            Remit::notifyCustomer($o, 'settle');
                        }
                        $msg = $made ? 'مانده '.money($made->sum('amount')).' تومان صادر شد.' : 'مانده‌ای برای پرداخت نیست.';
                    }
                    break;
                case 'guar': // بررسی چک ضمانت مشتری جدید
                    abort_unless(Remit::canWork($u) || (int) $o->assignee_id === (int) $u->id, 403);
                    \App\Services\OrderPrior::reviewGuar($o, $r->boolean('ok'), (string) $r->input('reason'), $u);
                    $msg = $r->boolean('ok') ? 'چک ضمانت تأیید شد.' : 'چک ضمانت رد شد.';
                    break;
                case 'upload':
                    $p = $pay();
                    abort_unless(ChatFinance::canReview($u, $p) || (int) $o->assignee_id === (int) $u->id, 403);
                    $files = $this->receiptFiles($r);
                    if (is_string($files)) {
                        throw new RuntimeException($files);
                    }
                    Remit::submit($p, $files, $r->input('ref'), null, $by);
                    $msg = 'فیش ثبت شد.';
                    break;
                case 'replace':
                    // فیش تأییدشده/منتظر: تصویر اشتباه بود یا واریز برگشت خورد ← فیش تازه
                    $p = $pay();
                    $review($p);
                    $files = $this->receiptFiles($r);
                    if (is_string($files)) {
                        throw new RuntimeException($files);
                    }
                    Remit::replaceReceipt($p, $files, $u, (string) $r->input('reason'), $r->input('mode') !== 'add', $r->input('ref'));
                    $msg = 'فیش تازه ثبت شد'.($p->status === 'confirmed' ? '؛ برای تأیید دوباره به کارخانه‌دار رفت.' : '.');
                    break;
                case 'attach':
                    // عکسی که مشتری معمولی فرستاده ← فیش همین کارت
                    $p = $pay();
                    abort_unless(ChatFinance::canReview($u, $p) || (int) $o->assignee_id === (int) $u->id, 403);
                    $t = Chat::thread($o);
                    $m = ChatMessage::query()->where('thread_id', $t->id)->where('kind', 'image')->findOrFail((int) $r->input('mid'));
                    $meta = (array) $m->meta;
                    $src = ! empty($meta['path']) && empty($meta['gone']) ? public_path('uploads/'.$meta['path']) : null;
                    if (! $src || ! is_file($src)) {
                        throw new RuntimeException('عکس دیگر موجود نیست.');
                    }
                    $file = new UploadedFile($src, basename($src), mime_content_type($src) ?: 'image/jpeg', null, true);
                    Remit::submit($p, [$file], null, null, $by);
                    $meta['receipt'] = (int) $p->id;
                    $m->update(['meta' => $meta]);
                    $msg = 'عکس به‌عنوان فیش '.$p->kindLabel().' ثبت شد.';
                    break;
                case 'confirm':
                    $p = $pay();
                    $review($p);
                    $amt = $r->filled('amount') ? (int) to_int($r->input('amount')) : (int) $p->amount;
                    if ($amt <= 0) {
                        throw new RuntimeException('مبلغ واریزی را بنویسید.');
                    }
                    if ($amt !== (int) $p->amount) {
                        $rest = (int) $p->amount - $amt;
                        Remit::editPayment($p, $amt, null, false, $u);
                        if ($rest > 0 && $r->input('rest') === 'wait') {
                            try {
                                Remit::issue($o, $p->kind, $rest, [$p->remittance_id], $u);
                            } catch (ValidationException) {
                                Remit::issue($o, $p->kind, $rest, null, $u);
                            }
                            Remit::notifyCustomer($o, $p->kind);
                        }
                    }
                    Remit::confirm($p->fresh(), $u);
                    $msg = 'فیش '.money($amt).' تومانی تأیید شد.';
                    // بیعانه تأیید شد ← پنجره چاپ فاکتور کامل برای همین همکار (انباردارها مثل قبل حواله را در اپ می‌گیرند)
                    if ($p->kind === 'deposit' && ! \App\Services\Chat::printLocked($o->refresh())) {
                        $printAsk = ['url' => route('admin.invoice', ['order' => $o->id, 'plain' => 1]), 'title' => 'بیعانه تأیید شد — چاپ فاکتور کامل سفارش '.fa($o->number)];
                    }
                    break;
                case 'dropfile':
                    // تصویر تکراری فیش (همکار از گفتگو ثبت کرده + مشتری هم روی کارت فرستاده) ← حذف، بعد تأیید
                    $p = $pay();
                    $review($p);
                    $left = Remit::removeReceipt($p, [(int) $r->input('i')], $u);
                    $msg = 'تصویر تکراری حذف شد؛ '.fa($left).' تصویر ماند.';
                    break;
                case 'reject':
                    $p = $pay();
                    $review($p);
                    $why = trim((string) $r->input('reason'));
                    if ($why === '') {
                        throw new RuntimeException('علت رد را بنویسید.');
                    }
                    Remit::reject($p, $why, $u);
                    $msg = 'فیش رد شد و به مشتری خبر داده شد.';
                    break;
                case 'edit':
                    $p = $pay();
                    $review($p);
                    Remit::editPayment($p, (int) to_int($r->input('amount')), null, $r->boolean('rebalance', true), $u);
                    Remit::notifyCustomer($o, $p->kind);
                    $msg = 'مبلغ اصلاح شد.';
                    break;
                case 'cancel':
                    $p = $pay();
                    $review($p);
                    Remit::cancel($p, $u, trim((string) $r->input('reason')) ?: 'از گفتگو');
                    $msg = 'مبلغ باطل شد.';
                    break;
                case 'cheq':
                    abort_unless($u->hasPerm('orders_edit'), 403);
                    $type = (string) $r->input('type');
                    abort_unless(in_array($type, ['cheque', 'sayad', 'post'], true), 422);
                    $ok = $r->boolean('ok');
                    if (! $ok && trim((string) $r->input('reason')) === '') {
                        throw new RuntimeException('علت رد را بنویسید.');
                    }
                    \App\Services\Cheques::reviewDoc($o, $type, $type === 'post' ? null : (int) $r->input('i'), $ok, $r->input('reason'), $u);
                    $msg = $ok ? 'تأیید شد.' : 'رد شد و به مشتری خبر داده شد.';
                    break;
                default:
                    abort(422);
            }
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
        $t = Chat::thread($o->refresh());

        return response()->json(['toast' => $msg] + (isset($printAsk) ? ['print_ask' => $printAsk] : []) + $this->staffState($r, $o, $t->refresh(), 0, true), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** جستجوی کالا برای کارت کالا */
    public function products(Request $r)
    {
        abort_unless(Chat::enabled() && $r->user()->hasPerm('chats'), 403);
        $s = trim((string) $r->query('q', ''));
        if (mb_strlen($s) < 2) {
            return response()->json(['items' => []]);
        }
        // اول کالاهای موجود، بعد ناموجودها (ترتیب شباهت جستجو داخل هر گروه حفظ می‌شود)
        $rows = Product::query()->active()->search($s)->limit(40)->get(['id', 'name', 'image', 'price', 'retail_price', 'per_carton', 'retail_enabled', 'in_stock', 'stock', 'retail_in_stock', 'retail_stock', 'carton_enabled', 'sku', 'sync_code', 'barcode', 'warehouse_id', 'buy_mode', 'buy_qty', 'unit_label'])
            ->values()->sortBy(fn (Product $p, $i) => [$p->isAvailable() ? 0 : 1, $i])->take(15)->values();

        return response()->json(['items' => $rows->map(fn (Product $p) => [
            'id' => $p->id, 'name' => $p->name, 'img' => $p->image ? thumb($p->image, 160) : null, 'price' => money($p->unitPrice(Product::CARTON)), 'up' => $p->unitPrice(Product::CARTON), 'rup' => $p->retailAllowed() ? $p->unitPrice(Product::RETAIL) : 0,
            'pc' => max(1, (int) $p->per_carton), 'retail' => $p->retailAllowed(), 'avail' => $p->isAvailable(), 'code' => fa((string) ($p->sku ?: $p->sync_code ?: $p->barcode)),
        ])->values()], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }
}
