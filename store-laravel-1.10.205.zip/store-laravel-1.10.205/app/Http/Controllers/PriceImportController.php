<?php

namespace App\Http\Controllers;

use App\Services\BulkImport;
use App\Services\Excel;
use App\Support\SheetReader;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * «اطلاعات کالا» در صفحه ورود از اکسل: فایل قیمت هلو (یا هر نرم‌افزار حسابداری).
 * ستون‌ها و ردیف عنوان خودکار تشخیص داده می‌شوند، ریال/تومان هم از مقایسه با قیمت‌های فعلی سایت.
 */
class PriceImportController extends Controller
{
    /** فیلدهای قابل انتخاب برای هر ستون */
    public static function fields(): array
    {
        return ['' => '— نادیده گرفته شود —', 'code' => 'کد کالا / بارکد', 'name' => 'نام کالا', 'price' => 'قیمت فروش'] + Excel::targets();
    }

    public static function letter(int $i): string
    {
        return ($i >= 26 ? chr(64 + intdiv($i, 26)) : '').chr(65 + ($i % 26));
    }

    protected function dir(Request $request, string $token): string
    {
        abort_unless((bool) $request->user()?->hasPerm('stock'), 403);
        abort_unless(preg_match('/^[A-Za-z0-9]{20}$/', $token), 404);
        $d = storage_path('app/priceimport/'.$token);
        abort_unless(is_dir($d) && (int) @file_get_contents($d.'/.user') === (int) $request->user()->id, 404);

        return $d;
    }

    public function start(Request $request)
    {
        abort_unless((bool) $request->user()?->hasPerm('stock'), 403);
        @set_time_limit(300);
        @ini_set('memory_limit', '512M');
        // پوشه‌های قدیمی‌تر از یک روز
        foreach (glob(storage_path('app/priceimport/*'), GLOB_ONLYDIR) ?: [] as $old) {
            if (@filemtime($old) < time() - 86400) {
                // (قبلاً «.» و «..» هم پاک می‌شد و خطای ۵۰۰ می‌داد؛ از روز بعدِ هر ورود ناتمام، همه ورودها خطا می‌خوردند)
                foreach (array_merge(glob($old.'/*') ?: [], [$old.'/.user']) as $f) {
                    if (is_file($f)) {
                        @unlink($f);
                    }
                }
                @rmdir($old);
            }
        }
        $token = Str::random(20);
        $d = storage_path('app/priceimport/'.$token);
        @mkdir($d, 0775, true);
        file_put_contents($d.'/.user', (string) $request->user()->id);
        $saved = [];
        foreach ((array) $request->file('files', []) as $i => $f) {
            if (! $f || ! $f->isValid()) {
                continue;
            }
            $name = (string) (((array) $request->input('names', []))[$i] ?? $f->getClientOriginalName());
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (! in_array($ext, ['xlsx', 'xls', 'csv', 'xlsb'], true) || str_starts_with($name, '~$')) {
                continue;
            }
            $safe = (count($saved) + 1).'-'.(preg_replace('/[^\p{L}\p{N}\-_. ()]+/u', '', $name) ?: 'file.'.$ext);
            $f->move($d, $safe);
            $saved[] = $safe;
        }
        if (! $saved) {
            $big = false;
            foreach ((array) $request->file('files', []) as $f) {
                $big = $big || ($f && in_array($f->getError(), [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true));
            }
            if ($big || (! $request->file('files') && (int) $request->server('CONTENT_LENGTH') > 0)) {
                return response()->json(['ok' => false, 'msg' => 'حجم فایل از سقف آپلود هاست ('.ini_get('upload_max_filesize').') بیشتر است. فایل را zip کنید یا فقط برگه قیمت را جدا ذخیره کنید.'], 422);
            }

            return response()->json(['ok' => false, 'msg' => 'فایل اکسل معتبری نرسید.'], 422);
        }

        try {
            return response()->json(['ok' => true, 'token' => $token] + $this->detect($d), 200, [], JSON_UNESCAPED_UNICODE);
        } catch (Throwable $e) {
            report($e);

            return response()->json(['ok' => false, 'msg' => 'خواندن فایل ناموفق بود: '.$e->getMessage()], 422);
        }
    }

    /** ردیف عنوان، نقش هر ستون و واحد قیمت */
    protected function detect(string $d): array
    {
        $files = array_values(array_filter(glob($d.'/*') ?: [], 'is_file'));
        // گذر اول: فقط ۵۰۰ ردیف اول در حافظه (برای پیدا کردن عنوان ستون‌ها)؛ فایل‌های بزرگ هاست را از حافظه نمی‌اندازند
        $rows = [];
        $total = 0;
        SheetReader::read($files[0], basename($files[0]), function ($r) use (&$rows, &$total) {
            $total++;
            if (count($rows) < 500) {
                $rows[] = (array) $r; // کلیدها = شماره ستون (ممکن است جاخالی داشته باشد)
            }
        });
        if (! $rows) {
            throw new RuntimeException('فایل خالی است.');
        }
        $width = 0;
        foreach (array_slice($rows, 0, 500) as $r) {
            $width = max($width, $r ? max(array_keys($r)) + 1 : 0);
        }
        $width = min($width, 40);
        $rows = array_map(function ($r) use ($width) {
            $o = [];
            for ($j = 0; $j < $width; $j++) {
                $o[$j] = trim((string) ($r[$j] ?? ''));
            }

            return $o;
        }, $rows);
        $map = ['code' => 'code', 'name' => 'name', 'price' => 'price', 'compare_price' => 'compare_price', 'per_carton' => 'per_carton', 'retail_price' => 'retail_price',
            'category' => 'category', 'warehouse' => 'warehouse', 'retail_warehouse' => 'retail_warehouse', 'short_description' => 'short_description', 'description' => 'description'];
        // ردیف عنوان: ردیفی (از ۱۰ ردیف اول) که بیشترین ستون شناخته‌شده را دارد
        $best = -1;
        $bestN = 0;
        $guess = [];
        foreach (array_slice($rows, 0, 10, true) as $i => $r) {
            $g = [];
            $raw = [];
            foreach ($r as $j => $v) {
                $f = BulkImport::guessField((string) $v);
                // «تعداد» خالی در فایل قیمت معمولاً موجودی است، نه تعداد در کارتن
                if ($f === 'per_carton' && ! str_contains(Excel::text((string) $v), 'کارتن')) {
                    $f = '';
                }
                $raw[$j] = $f;
            }
            // کد کالای هلو بر بارکد اولویت دارد؛ هر فیلد فقط یک ستون
            $hasCode = in_array('code', $raw, true);
            $used = [];
            foreach ($raw as $j => $f) {
                if ($f === 'barcode') {
                    $f = $hasCode ? '' : 'code';
                }
                $f = ($f !== 'skip' && isset($map[$f]) && ! isset($used[$f])) ? $map[$f] : '';
                if ($f !== '') {
                    $used[$f] = true;
                }
                $g[$j] = $f;
            }
            $n = count(array_filter($g));
            if ($n > $bestN) {
                [$best, $bestN, $guess] = [$i, $n, $g];
            }
        }
        if ($best < 0) {
            // بدون عنوان: از روی داده (کد عددی ۳ تا ۱۳ رقمی، نام فارسی، عدد بزرگ = قیمت)
            $guess = array_fill(0, $width, '');
            $stat = [];
            foreach (array_slice($rows, 0, 50) as $r) {
                foreach ($r as $j => $v) {
                    $v = trim(en_digits((string) $v));
                    if ($v === '') {
                        continue;
                    }
                    if (preg_match('/^\d{3,13}(\.0)?$/', $v) && (float) $v < 10_000_000_000_000) {
                        $stat[$j]['code'] = ($stat[$j]['code'] ?? 0) + ((float) $v < 1_000_000 ? 1 : 0.5);
                    }
                    if (preg_match('/\p{Arabic}/u', $v)) {
                        $stat[$j]['name'] = ($stat[$j]['name'] ?? 0) + 1;
                    }
                    if (is_numeric(str_replace(',', '', $v)) && (float) str_replace(',', '', $v) >= 1000) {
                        $stat[$j]['price'] = ($stat[$j]['price'] ?? 0) + 1;
                    }
                }
            }
            foreach (['name', 'code', 'price'] as $k) {
                $col = null;
                $top = 0;
                foreach ($stat as $j => $s) {
                    if (($s[$k] ?? 0) > $top && $guess[$j] === '') {
                        [$col, $top] = [$j, $s[$k]];
                    }
                }
                if ($col !== null) {
                    $guess[$col] = $k;
                }
            }
        }
        $headers = [];
        for ($j = 0; $j < $width; $j++) {
            $h = $best >= 0 ? trim((string) ($rows[$best][$j] ?? '')) : '';
            $headers[] = $h !== '' ? $h : 'ستون '.static::letter($j);
            $guess[$j] ??= '';
        }
        $data = array_slice($rows, $best + 1);
        // ریال یا تومان: نسبت قیمت فایل به قیمت فعلی همان کالا در سایت
        $unit = 'toman';
        $ci = array_search('code', $guess, true);
        $pi = array_search('price', $guess, true);
        $ni = array_search('name', $guess, true);
        $matched = 0;
        $renames = 0;
        $renameSample = [];
        if ($ci !== false) {
            $site = Excel::siteIndex(['id', 'price', 'name'], true); // سبک (بدون مدل)
            $ratios = [];
            // گذر دوم: همه ردیف‌ها بدون نگه داشتن در حافظه
            $i = -1;
            SheetReader::read($files[0], basename($files[0]), function ($r) use (&$i, $best, $ci, $pi, $ni, $site, &$matched, &$ratios, &$renames, &$renameSample) {
                $i++;
                if ($i <= $best) {
                    return;
                }
                $r = (array) $r;
                $k = Excel::key(Excel::barcode(trim((string) ($r[$ci] ?? ''))));
                if ($k !== '' && isset($site[$k])) {
                    $matched++;
                    if ($pi !== false && count($ratios) < 5000 && ($fp = Excel::number(trim((string) ($r[$pi] ?? '')))) && $site[$k]->price > 0) {
                        $ratios[] = $fp / $site[$k]->price;
                    }
                    // نام کالای سایت با نام فایل فرق دارد؟ (پیش از اجرا هشدار داده می‌شود)
                    if ($ni !== false) {
                        $fn = Excel::productName((string) ($r[$ni] ?? '')); // همان نامی که واقعاً ذخیره می‌شود (بدون «// ۴ عددی»)
                        if ($fn !== '' && ! Excel::sameName($fn, (string) $site[$k]->name)) {
                            $renames++;
                            if (count($renameSample) < 8) {
                                $renameSample[] = ['from' => (string) $site[$k]->name, 'to' => mb_substr($fn, 0, 120)];
                            }
                        }
                    }
                }
            });
            if ($ratios) {
                sort($ratios);
                $med = $ratios[intdiv(count($ratios), 2)];
                $unit = $med > 5 ? 'rial' : 'toman';
            }
        }

        return [
            'files' => array_map('basename', $files), 'headers' => $headers, 'mapping' => array_values($guess), 'fields' => static::fields(),
            'skip' => $best + 1, 'rows' => max(0, $total - $best - 1), 'matched' => $matched, 'unit' => $unit,
            'renames' => $renames, 'rename_sample' => $renameSample,
            'sample' => array_map(fn ($r) => array_map(fn ($v) => mb_substr((string) $v, 0, 60), array_pad(array_slice($r, 0, $width), $width, '')), array_slice($data, 0, 5)),
        ];
    }

    public function run(Request $request, string $token)
    {
        $d = $this->dir($request, $token);
        @set_time_limit(300);
        @ini_set('memory_limit', '512M');
        $files = [];
        foreach (array_filter(glob($d.'/*') ?: [], 'is_file') as $f) {
            $files[] = ['path' => $f, 'name' => preg_replace('/^\d+-/', '', basename($f))];
        }
        $mapping = array_values((array) $request->input('mapping', []));
        $letter = fn (int $i) => static::letter($i);
        $o =['skip' => max(0, (int) $request->input('skip', 1)), 'extra' => []];
        foreach ($mapping as $i => $f) {
            if ($f === 'code') {
                $o['col_barcode'] = $letter($i);
            } elseif ($f === 'name') {
                $o['col_name'] = $letter($i);
            } elseif ($f === 'price') {
                $o['col_price'] = $letter($i);
            } elseif ($f !== '' && isset(Excel::targets()[$f])) {
                // ستون‌های قیمتی دیگر هم فقط وقتی «قیمت‌ها به‌روز شود» روشن است
                if (in_array($f, ['compare_price', 'retail_price'], true) && ! $request->boolean('update_price')) {
                    continue;
                }
                $o['extra'][] = ['col' => $letter($i), 'target' => $f];
            }
        }
        if (empty($o['col_barcode'])) {
            return response()->json(['ok' => false, 'msg' => 'ستون «کد کالا / بارکد» را مشخص کنید.'], 422);
        }
        $o['col_name'] ??= '';
        $o['col_price'] ??= '';
        $o['rial'] = $request->input('unit') === 'rial';
        $o['update_price'] = $request->boolean('update_price');
        $o['update_name'] = $request->boolean('update_name');
        $o['stock_mode'] = $request->boolean('instock') ? 'instock' : 'none';
        $o['notify'] = $request->boolean('instock') && $request->boolean('notify');
        try {
            $r = app(Excel::class)->import($files, $o, $request->user()->id);
        } catch (Throwable $e) {
            report($e);

            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        } finally {
            foreach ($files as $f) {
                @unlink($f['path']);
            }
            @unlink($d.'/.user');
            @rmdir($d);
        }

        return response()->json(['ok' => true, 'stats' => $r['stats'], 'lists' => array_map(fn ($l) => count($l['rows'] ?? []), $r['lists'])], 200, [], JSON_UNESCAPED_UNICODE);
    }
}
