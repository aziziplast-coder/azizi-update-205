<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\Live;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

/** اپ مشاور (گوشی و کامپیوتر): گفتگوی زنده با مشتری‌ها — بدون ورود به پنل اصلی */
class AdvisorController extends Controller
{
    public static function can(?User $u): bool
    {
        return $u && $u->is_active && in_array($u->role, ['admin', 'staff'], true) && ($u->hasPerm('live') || \App\Services\Advisors::isAdvisor($u));
    }

    protected function adv(Request $r): User
    {
        $u = $r->user();
        abort_unless($u && \App\Services\Advisors::enabled() && \App\Services\Advisors::isAdvisor($u), 403);

        return $u;
    }

    protected function json(array $d, int $code = 200)
    {
        return response()->json($d, $code, ['Cache-Control' => 'no-store, private'], JSON_UNESCAPED_UNICODE);
    }

    /** خانه: فروش ماه، هدف، پورسانت، موجودی، لینک، آمار لینک، رتبه */
    public function home(Request $r)
    {
        $u = $this->adv($r);
        $A = \App\Services\Advisors::class;
        $row = $A::row($u);
        $A::monthBonus($u);
        [$from, $to, $period] = $A::monthRange();
        $month = \Illuminate\Support\Facades\DB::table('commissions')->where('advisor_id', $u->id)->where('status', '!=', 'void')->whereBetween('created_at', [$from, $to]);
        $sales = (int) (clone $month)->sum('base');
        $comm = (int) (clone $month)->sum('amount');
        $orders = (int) (clone $month)->count();
        $stats = \Illuminate\Support\Facades\DB::table('advisor_stats')->where('advisor_id', $u->id)->where('day', '>=', now()->subDays(29)->toDateString());
        $board = \Illuminate\Support\Facades\DB::table('commissions')->where('status', '!=', 'void')->whereBetween('created_at', [$from, $to])
            ->selectRaw('advisor_id, SUM(base) s')->groupBy('advisor_id')->orderByDesc('s')->limit(50)->get();
        $names = User::query()->whereIn('id', $board->pluck('advisor_id'))->pluck('name', 'id');
        $rank = $board->search(fn ($x) => (int) $x->advisor_id === $u->id);

        return $this->json([
            'ok' => true, 'name' => $u->name, 'period' => fa(str_replace('-', '/', $period)),
            'sales' => $sales, 'target' => (int) $row->target, 'bonus' => (int) $row->bonus, 'comm' => $comm, 'orders' => $orders,
            'balance' => $A::balance($u->id), 'pending' => $A::pending($u->id),
            'customers' => User::query()->where('advisor_id', $u->id)->count(),
            'new_customers' => User::query()->where('advisor_id', $u->id)->where('advisor_at', '>=', $from)->count(),
            'clicks' => (int) (clone $stats)->sum('clicks'), 'signups' => (int) (clone $stats)->sum('signups'),
            'link' => $A::link($row), 'code' => $row->code,
            'rank' => $rank === false ? null : $rank + 1, 'board' => $board->take(5)->map(fn ($x) => ['n' => \Illuminate\Support\Str::before(trim((string) ($names[$x->advisor_id] ?? '')), ' ') ?: '—', 's' => (int) $x->s, 'me' => (int) $x->advisor_id === $u->id])->values(),
            'tiers' => $row->rate !== null ? [['from' => 0, 'rate' => (float) $row->rate, 'chat' => (float) $row->rate]] : $A::cfg()['tiers'],
            'first_bonus' => (float) $A::cfg()['first_bonus'],
        ]);
    }

    public function customers(Request $r)
    {
        $u = $this->adv($r);
        $q = trim((string) $r->query('q'));
        $rows = User::query()->where('advisor_id', $u->id)
            ->when($q !== '', fn ($w) => $w->where(fn ($x) => $x->where('name', 'like', '%'.$q.'%')->orWhere('mobile', 'like', '%'.en_digits($q).'%')->orWhere('company', 'like', '%'.$q.'%')->orWhere('city', 'like', '%'.$q.'%')))
            ->withCount(['orders' => fn ($o) => $o->whereNotIn('status', ['cancelled', 'failed', 'pending_payment'])])
            ->withSum(['orders' => fn ($o) => $o->whereNotIn('status', ['cancelled', 'failed', 'pending_payment'])], 'total')
            ->withMax('orders', 'created_at')
            ->orderByDesc('orders_max_created_at')->orderByDesc('advisor_at')->limit(300)->get();

        return $this->json(['ok' => true, 'rows' => $rows->map(fn (User $c) => [
            'name' => $c->name ?: 'بدون نام', 'mobile' => $c->mobile, 'city' => $c->city, 'company' => $c->company,
            'orders' => (int) $c->orders_count, 'total' => (int) $c->orders_sum_total,
            'last' => $c->orders_max_created_at ? jdate($c->orders_max_created_at) : null,
            'days' => $c->orders_max_created_at ? (int) \Illuminate\Support\Carbon::parse($c->orders_max_created_at)->diffInDays(now()) : null,
            'since' => $c->advisor_at ? jdate($c->advisor_at) : null, 'src' => \App\Services\Advisors::SRC[$c->advisor_src] ?? null,
        ])->values()]);
    }

    public function wallet(Request $r)
    {
        $u = $this->adv($r);
        $A = \App\Services\Advisors::class;
        $row = $A::row($u);
        $tx = \Illuminate\Support\Facades\DB::table('wallet_tx')->where('user_id', $u->id)->orderByDesc('id')->limit(150)->get();
        $comms = \Illuminate\Support\Facades\DB::table('commissions')->join('orders', 'orders.id', '=', 'commissions.order_id')
            ->where('commissions.advisor_id', $u->id)->orderByDesc('commissions.id')->limit(100)
            ->get(['commissions.*', 'orders.number', 'orders.customer_name', 'orders.status as ostatus']);
        $new = $row->bank_new ? (array) json_decode($row->bank_new, true) : null;

        return $this->json([
            'ok' => true, 'balance' => $A::balance($u->id), 'pending' => $A::pending($u->id),
            'bank' => ['holder' => $row->bank_holder, 'sheba' => $row->bank_sheba, 'card' => $row->bank_card, 'name' => $row->bank_name, 'new' => $new],
            'tx' => $tx->map(fn ($x) => ['t' => $x->type, 'a' => (int) $x->amount, 'n' => $x->note, 'ref' => $x->ref, 'rc' => $x->receipt ? asset('uploads/'.$x->receipt) : null, 'at' => jdate($x->created_at, true)])->values(),
            'comms' => $comms->map(fn ($c) => ['no' => fa($c->number), 'c' => $c->customer_name, 'b' => (int) $c->base, 'r' => (float) $c->rate, 'a' => (int) $c->amount, 's' => $c->status,
                'src' => $A::SRC[$c->src] ?? $c->src, 'first' => (bool) $c->first, 'os' => \App\Models\Order::STATUSES[$c->ostatus] ?? $c->ostatus, 'at' => jdate($c->created_at)])->values(),
        ]);
    }

    /** فهرست تماس امروز (باشگاه مشتریان) */
    public function calls(Request $r)
    {
        $u = $this->adv($r);
        abort_unless(\App\Services\Crm::ready(), 404);
        $DB = \Illuminate\Support\Facades\DB::class;
        $rows = \App\Services\Crm::queue($u->id)->orderByRaw('CASE WHEN next_call_at IS NULL THEN 1 ELSE 0 END')->orderBy('next_call_at')->orderByDesc('total_year')->limit(200)->get();
        $later = $DB::table('crm_customers')->where('assigned_to', $u->id)->where('next_call_at', '>', now()->endOfDay())->orderBy('next_call_at')->limit(50)->get(['id', 'name', 'next_call_at', 'last_result']);
        $S = \App\Services\Crm::SEGMENTS;
        $map = fn ($c) => ['id' => $c->id, 'name' => $c->name, 'mobile' => $c->mobile, 'city' => $c->city, 'company' => $c->company, 'seg' => $S[$c->segment][0] ?? '', 'segk' => $c->segment,
            'total' => (int) $c->total, 'year' => (int) $c->total_year, 'orders' => (int) $c->orders, 'last' => $c->last_at ? jdate($c->last_at) : null,
            'days' => $c->last_at ? (int) \Illuminate\Support\Carbon::parse($c->last_at)->diffInDays(now()) : null, 'gap' => $c->gap,
            'res' => \App\Services\Crm::RESULTS[$c->last_result] ?? null, 'due' => $c->next_call_at ? jdate($c->next_call_at, true) : null, 'notes' => $c->notes];

        return $this->json(['ok' => true, 'rows' => $rows->map($map)->values(),
            'later' => $later->map(fn ($c) => ['id' => $c->id, 'name' => $c->name, 'due' => jdate($c->next_call_at, true), 'res' => \App\Services\Crm::RESULTS[$c->last_result] ?? ''])->values(),
            'today' => $DB::table('crm_calls')->where('user_id', $u->id)->where('created_at', '>=', now()->startOfDay())->count(),
            'returned' => $DB::table('crm_customers')->where('returned_by', $u->id)->where('returned_at', '>=', \App\Services\Advisors::monthRange()[0])->count(),
            'results' => \App\Services\Crm::RESULTS]);
    }

    public function crmOne(Request $r, int $id)
    {
        $u = $this->adv($r);
        $c = \Illuminate\Support\Facades\DB::table('crm_customers')->where('id', $id)->where(fn ($w) => $w->where('assigned_to', $u->id)->orWhere('advisor_id', $u->id))->first();
        abort_unless($c, 404);
        $DB = \Illuminate\Support\Facades\DB::class;

        return $this->json(['ok' => true,
            'items' => $DB::table('crm_items')->where('crm_customer_id', $id)->orderByDesc('amount')->limit(10)->get(['name', 'qty'])->map(fn ($i) => ['n' => $i->name, 'q' => (int) $i->qty]),
            'sales' => $DB::table('crm_sales')->where('crm_customer_id', $id)->orderByDesc('day')->limit(12)->get(['day', 'amount', 'source'])->map(fn ($s) => ['d' => jdate($s->day), 'a' => (int) $s->amount, 'src' => $s->source]),
            'calls' => $DB::table('crm_calls')->where('crm_customer_id', $id)->orderByDesc('id')->limit(10)->get()->map(fn ($x) => ['at' => jdate($x->created_at, true), 'r' => \App\Services\Crm::RESULTS[$x->result] ?? $x->result, 'n' => $x->note]),
        ]);
    }

    public function call(Request $r)
    {
        $u = $this->adv($r);
        $id = (int) $r->input('id');
        $ok = \Illuminate\Support\Facades\DB::table('crm_customers')->where('id', $id)->where(fn ($w) => $w->where('assigned_to', $u->id)->orWhere('advisor_id', $u->id))->exists();
        abort_unless($ok, 404);
        try {
            \App\Services\Crm::record($id, $u, (string) $r->input('result'), $r->input('note'), $r->input('next'));
        } catch (\RuntimeException $e) {
            return $this->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }

        return $this->json(['ok' => true]);
    }

    public function bank(Request $r)
    {
        $u = $this->adv($r);
        try {
            $res = \App\Services\Advisors::saveBank($u, (string) $r->input('holder'), (string) $r->input('sheba'), (string) $r->input('card'));
        } catch (\RuntimeException $e) {
            return $this->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }

        return $this->json(['ok' => true, 'msg' => $res === 'pending' ? 'تغییر حساب ثبت شد؛ پس از تأیید مدیر، پرداخت‌ها به حساب جدید می‌رود.' : 'شماره حساب ثبت شد ✓']);
    }

    public function app(Request $r)
    {
        if (! static::can($r->user())) {
            return redirect()->route('advisor.login');
        }

        return response()->view('advisor.app', ['u' => $r->user()], 200, ['Cache-Control' => 'no-store, private']);
    }

    public function loginForm(Request $r)
    {
        if (static::can($r->user())) {
            return redirect()->route('advisor');
        }

        return view('advisor.login');
    }

    public function login(Request $r)
    {
        $m = mobile((string) $r->input('mobile'));
        if ($lg = \App\Support\LoginGuard::blocked('keeper', $m)) {
            return back()->withErrors(['mobile' => $lg])->withInput();
        }
        $u = $m ? User::query()->where('mobile', $m)->first() : null;
        if (! $u || ! $u->password || ! Hash::check((string) $r->input('password'), $u->password) || ! static::can($u)) {
            \App\Support\LoginGuard::fail('keeper', $m);

            return back()->withErrors(['mobile' => 'موبایل یا رمز عبور درست نیست، یا این حساب دسترسی «گفتگوی زنده» ندارد.'])->withInput();
        }
        \App\Support\LoginGuard::clear('keeper', $m);
        Auth::login($u, true);
        $r->session()->regenerate();
        $u->forceFill(['last_login_at' => now()])->saveQuietly();

        return redirect()->route('advisor');
    }

    public function logout(Request $r)
    {
        Auth::logout();
        $r->session()->invalidate();
        $r->session()->regenerateToken();

        return redirect()->route('advisor.login');
    }

    public function manifest()
    {
        return response()->json([
            'id' => '/advisor', 'name' => 'اپ مشاور — '.store_name(), 'short_name' => 'اپ مشاور', 'lang' => 'fa', 'dir' => 'rtl',
            'description' => 'گفتگوی زنده با مشتری‌های سایت',
            'start_url' => '/advisor?source=pwa', 'scope' => '/advisor', 'display' => 'standalone', 'orientation' => 'portrait',
            'background_color' => '#6d5dfc', 'theme_color' => '#6d5dfc',
            'icons' => [
                ['src' => route('pwa.icon', 192), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.icon', 512), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
            ],
        ], 200, ['Content-Type' => 'application/manifest+json', 'Cache-Control' => 'public, max-age=3600'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
