<?php

namespace App\Http\Controllers;

use App\Models\PushSubscription;
use App\Services\WebPush;
use Illuminate\Http\Request;

class PushController extends Controller
{
    public function subscribe(Request $request)
    {
        abort_unless(WebPush::enabled(), 404);
        $data = $request->validate([
            'endpoint' => 'required|url|max:1000',
            'keys.p256dh' => 'required|string|max:200',
            'keys.auth' => 'required|string|max:100',
        ]);
        $host = parse_url($data['endpoint'], PHP_URL_HOST) ?: '';
        abort_if($host === '' || filter_var($host, FILTER_VALIDATE_IP) || str_ends_with($host, 'localhost'), 422);
        $user = $request->user();
        PushSubscription::query()->updateOrCreate(['hash' => hash('sha256', $data['endpoint'])], [
            'endpoint' => $data['endpoint'],
            'p256dh' => $data['keys']['p256dh'],
            'auth' => $data['keys']['auth'],
            'user_id' => $user?->id,
            'is_staff' => (bool) ($user?->isStaffLike() && $request->boolean('staff')),
        ]);

        return response()->json(['ok' => true]);
    }

    public function unsubscribe(Request $request)
    {
        PushSubscription::query()->where('hash', hash('sha256', (string) $request->input('endpoint')))->delete();

        return response()->json(['ok' => true]);
    }
}
