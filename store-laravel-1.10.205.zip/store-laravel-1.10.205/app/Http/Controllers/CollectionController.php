<?php

namespace App\Http\Controllers;

use App\Models\ProductCollection;
use App\Support\HomeBlocks;
use Illuminate\Http\Request;

class CollectionController extends Controller
{
    public function show(Request $request, string $slug)
    {
        $c = ProductCollection::query()->where('slug', $slug)->where('is_active', true)->firstOrFail();
        $products = $c->products()->paginate((int) setting('shop_per_page', 24))->withQueryString();

        return view('store.listing', [
            'title' => $c->title,
            'seoTitle' => $c->seo_title ?: $c->title,
            'description' => $c->seo_description ?: $c->description,
            'intro' => $c->description,
            'image' => $c->image,
            'products' => $products,
            'canonical' => $c->url(),
            'tint' => $c->color,
        ]);
    }

    /** همان لینک قدیمی ← مجموعه‌ای که در پنل «شناسه در سایت قدیمی»اش همین است */
    public function legacy(\Illuminate\Http\Request $r)
    {
        $key = trim((string) $r->query('what')).':'.trim((string) $r->query('id'));
        $c = ProductCollection::query()->where('legacy_key', $key)->where('is_active', true)->first();
        if (! $r->boolean('json')) {
            return redirect($c ? $c->url() : route('home'), 301);
        }
        if (! $c) {
            return response()->json([], 404, ['Access-Control-Allow-Origin' => '*']);
        }
        $data = \Illuminate\Support\Facades\Cache::remember('legacy-feed:'.$c->id.':'.optional($c->updated_at)->timestamp, 300, fn () => $c->toLegacyFeed());

        return response()->json($data, 200, ['Access-Control-Allow-Origin' => '*', 'Cache-Control' => 'public, max-age=300'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function json(string $slug)
    {
        $c = ProductCollection::query()->where('slug', $slug)->where('is_active', true)->firstOrFail();
        // ?bot=1 ← همان شکل قدیمی که ربات می‌شناسد
        if (request()->boolean('bot')) {
            $data = \Illuminate\Support\Facades\Cache::remember('legacy-feed:'.$c->id.':'.optional($c->updated_at)->timestamp, 300, fn () => $c->toLegacyFeed());

            return response()->json($data, 200, ['Access-Control-Allow-Origin' => '*', 'Cache-Control' => 'public, max-age=300'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        return response()->json($c->toFeed(), 200, ['Access-Control-Allow-Origin' => '*', 'Cache-Control' => 'public, max-age=300'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function amazing()
    {
        $a = HomeBlocks::amazing(120);
        abort_if(empty($a['settings']['enabled']), 404);

        return view('store.listing', [
            'title' => $a['settings']['title'] ?? 'شگفت‌انگیز',
            'seoTitle' => $a['settings']['title'] ?? 'شگفت‌انگیز',
            'description' => $a['settings']['subtitle'] ?? null,
            'intro' => $a['settings']['subtitle'] ?? null,
            'products' => $a['products'],
            'canonical' => route('amazing'),
            'tint' => $a['settings']['color'] ?? null,
            'endsAt' => $a['ends_at'] ?? null,
        ]);
    }
}
