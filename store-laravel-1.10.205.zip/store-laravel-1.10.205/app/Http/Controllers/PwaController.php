<?php

namespace App\Http\Controllers;

use Throwable;

class PwaController extends Controller
{
    public function manifest()
    {
        abort_unless(setting('pwa_enabled', true), 404);
        $brand = setting('brand_color', '#4f4a63');
        $iv = substr(md5((string) (setting('pwa_icon') ?: setting('logo')).$brand), 0, 8);
        $data = [
            'name' => setting('pwa_name') ?: store_name(),
            'short_name' => setting('pwa_short_name') ?: mb_substr(store_name(), 0, 12),
            'description' => setting('store_tagline') ?: setting('about'),
            'lang' => 'fa',
            'dir' => 'rtl',
            'id' => '/?source=pwa',
            'start_url' => '/?source=pwa',
            'display_override' => ['standalone', 'minimal-ui'],
            'prefer_related_applications' => false,
            'scope' => '/',
            'display' => 'standalone',
            'orientation' => 'portrait',
            'background_color' => '#fbfbfd',
            'theme_color' => $brand,
            'categories' => ['shopping'],
            'icons' => [
                ['src' => route('pwa.icon', 192).'?v='.$iv, 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.icon', 512).'?v='.$iv, 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.icon', 513).'?v='.$iv, 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
            ],
            'shortcuts' => [
                ['name' => 'محصولات', 'url' => '/shop', 'icons' => [['src' => route('pwa.icon', 192), 'sizes' => '192x192']]],
                ['name' => 'سبد خرید', 'url' => '/cart', 'icons' => [['src' => route('pwa.icon', 192), 'sizes' => '192x192']]],
                ['name' => 'سفارش‌های من', 'url' => '/account', 'icons' => [['src' => route('pwa.icon', 192), 'sizes' => '192x192']]],
            ],
        ];

        return response()->json($data, 200, ['Content-Type' => 'application/manifest+json', 'Cache-Control' => 'public, max-age=3600'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /** آیکون PNG از «آیکون اپ» یا لوگو؛ در نبود آن، نشان ساده با رنگ برند. 513 = نسخه maskable */
    public function icon(int $size)
    {
        abort_unless(in_array($size, [64, 180, 192, 512, 513], true), 404);
        $maskable = $size === 513;
        $px = $maskable ? 512 : $size;
        $src = setting('pwa_icon') ?: setting('logo');
        $brand = setting('brand_color', '#4f4a63');
        $key = md5($src.'|'.$brand.'|'.$size.'|v4');
        $file = public_path('uploads/_pwa/icon-'.$size.'-'.$key.'.png');
        if (! is_file($file)) {
            try {
                $this->draw($file, $px, $src ? public_path('uploads/'.$src) : null, $brand, $maskable);
            } catch (Throwable $e) {
                report($e);
                abort(404);
            }
        }

        return response()->file($file, ['Content-Type' => 'image/png', 'Cache-Control' => 'public, max-age=86400']);
    }

    /** آیکون اپ مدیریت: لوگوی پخش عزیزی + نشان گرد «کیف مدیریت» (طراحی آماده در resources/images) */
    public function manageIcon(int $size)
    {
        abort_unless(in_array($size, [64, 180, 192, 512, 513], true), 404);
        $maskable = $size === 513;
        $px = $maskable ? 512 : $size;
        $ready = resource_path('images/manage-icon'.($maskable ? '-maskable' : '').'.png');
        if (! is_file($ready)) {
            return $this->icon($size);
        }
        $file = public_path('uploads/_pwa/manage-r'.$size.'-'.substr(md5((string) filemtime($ready).filesize($ready)), 0, 10).'.png');
        if (! is_file($file) && ($im = @imagecreatefrompng($ready))) {
            $out = imagecreatetruecolor($px, $px);
            imagecopyresampled($out, $im, 0, 0, 0, 0, $px, $px, imagesx($im), imagesy($im));
            is_dir(dirname($file)) || mkdir(dirname($file), 0755, true);
            imagepng($out, $file, 9);
            imagedestroy($im);
            imagedestroy($out);
        }

        return is_file($file)
            ? response()->file($file, ['Content-Type' => 'image/png', 'Cache-Control' => 'public, max-age=86400'])
            : $this->icon($size);
    }

    /** آیکون اپ کارخانه‌دارها: لوگوی پخش عزیزی + نشان گرد «کارخانه» (طراحی آماده در resources/images) */
    public function factoryIcon(int $size)
    {
        abort_unless(in_array($size, [64, 180, 192, 512, 513], true), 404);
        $maskable = $size === 513;
        $px = $maskable ? 512 : $size;
        $ready = resource_path('images/factory-icon'.($maskable ? '-maskable' : '').'.png');
        if (! is_file($ready)) {
            return $this->icon($size);
        }
        $file = public_path('uploads/_pwa/factory-r'.$size.'-'.substr(md5((string) filemtime($ready).filesize($ready)), 0, 10).'.png');
        if (! is_file($file) && ($im = @imagecreatefrompng($ready))) {
            $out = imagecreatetruecolor($px, $px);
            imagecopyresampled($out, $im, 0, 0, 0, 0, $px, $px, imagesx($im), imagesy($im));
            is_dir(dirname($file)) || mkdir(dirname($file), 0755, true);
            imagepng($out, $file, 9);
            imagedestroy($im);
            imagedestroy($out);
        }

        return is_file($file)
            ? response()->file($file, ['Content-Type' => 'image/png', 'Cache-Control' => 'public, max-age=86400'])
            : $this->icon($size);
    }

    /**
     * آیکون اپ خرید و تأمین: همان آیکون/لوگوی فروشگاه + نشان گرد «سبد خرید» در گوشه
     * تا روی گوشی کنار آیکون فروشگاه شناخته شود ولی با آن یکی نباشد.
     */
    public function buyerIcon(int $size)
    {
        abort_unless(in_array($size, [64, 180, 192, 512, 513], true), 404);
        $maskable = $size === 513;
        $px = $maskable ? 512 : $size;
        // طراحی آماده (لوگوی فروشگاه + نشان سبد خرید با رنگ‌های خود لوگو)
        $ready = resource_path('images/buyer-icon'.($maskable ? '-maskable' : '').'.png');
        if (is_file($ready)) {
            $file = public_path('uploads/_pwa/buyer-r'.$size.'-'.substr(md5((string) filemtime($ready).filesize($ready)), 0, 10).'.png');
            if (! is_file($file) && ($im = @imagecreatefrompng($ready))) {
                $out = imagecreatetruecolor($px, $px);
                imagecopyresampled($out, $im, 0, 0, 0, 0, $px, $px, imagesx($im), imagesy($im));
                is_dir(dirname($file)) || mkdir(dirname($file), 0755, true);
                imagepng($out, $file, 9);
                imagedestroy($im);
                imagedestroy($out);
            }
            if (is_file($file)) {
                return response()->file($file, ['Content-Type' => 'image/png', 'Cache-Control' => 'public, max-age=86400']);
            }
        }
        $src = setting('pwa_icon') ?: setting('logo');
        $brand = setting('brand_color', '#4f4a63');
        $key = md5($src.'|'.$brand.'|'.$size.'|b2');
        $file = public_path('uploads/_pwa/buyer-'.$size.'-'.$key.'.png');
        if (! is_file($file)) {
            try {
                // پایه را بزرگ می‌سازیم و نشان را با کیفیت بالا (نمونه‌برداری چهاربرابر) می‌کشیم
                $big = 1024;
                $base = public_path('uploads/_pwa/tmp-'.getmypid().'-'.$size.'.png');
                $this->draw($base, $big, $src ? public_path('uploads/'.$src) : null, $brand, $maskable);
                $im = imagecreatefrompng($base);
                @unlink($base);
                $this->badge($im, $big, $brand, $maskable);
                $out = imagecreatetruecolor($px, $px);
                imagealphablending($out, false);
                imagesavealpha($out, true);
                imagecopyresampled($out, $im, 0, 0, 0, 0, $px, $px, $big, $big);
                is_dir(dirname($file)) || mkdir(dirname($file), 0755, true);
                imagepng($out, $file);
                imagedestroy($im);
                imagedestroy($out);
            } catch (Throwable $e) {
                report($e);

                return $this->icon($size);
            }
        }

        return response()->file($file, ['Content-Type' => 'image/png', 'Cache-Control' => 'public, max-age=86400']);
    }

    /** نشان گرد با سبد خرید سفید، رنگ مکمل برند، حلقه سفید و سایه نرم */
    protected function badge(\GdImage $im, int $px, string $brand, bool $maskable): void
    {
        imagealphablending($im, true);
        [$r, $g, $b] = sscanf(ltrim($brand, '#').'000000', '%02x%02x%02x');
        // رنگ نشان: نارنجی گرم (روی هر رنگ برندی دیده می‌شود)؛ اگر برند خودش گرم/نارنجی است، سبز
        $warm = ($r ?? 0) > 180 && ($g ?? 0) < 170 && ($b ?? 0) < 120;
        $fill = $warm ? [22, 163, 74] : [245, 124, 0];
        $d = (int) round($px * ($maskable ? 0.34 : 0.42));
        $cx = (int) round($maskable ? $px * 0.68 : $px - $d / 2 - $px * 0.03);
        $cy = $cx;
        // سایه
        for ($i = 14; $i >= 1; $i--) {
            $a = (int) min(127, 112 + $i);
            imagefilledellipse($im, $cx + (int) ($px * 0.008), $cy + (int) ($px * 0.014), $d + $i * 3, $d + $i * 3, imagecolorallocatealpha($im, 0, 0, 0, $a));
        }
        imagefilledellipse($im, $cx, $cy, $d + (int) ($px * 0.045), $d + (int) ($px * 0.045), imagecolorallocate($im, 255, 255, 255));
        imagefilledellipse($im, $cx, $cy, $d, $d, imagecolorallocate($im, ...$fill));
        // سبد خرید
        $w = imagecolorallocate($im, 255, 255, 255);
        $u = $d / 24; // شبکه ۲۴ واحدی مثل آیکون‌های خطی
        $x0 = $cx - 12 * $u;
        $y0 = $cy - 12 * $u + $u * 0.6;
        $P = fn ($x, $y) => [(int) round($x0 + $x * $u), (int) round($y0 + $y * $u)];
        imagesetthickness($im, max(2, (int) round($u * 1.9)));
        $line = function ($a, $b2) use ($im, $w, $P) {
            [$x1, $y1] = $P(...$a);
            [$x2, $y2] = $P(...$b2);
            imageline($im, $x1, $y1, $x2, $y2, $w);
        };
        $line([4, 6], [6.6, 6]);      // دسته
        $line([6.6, 6], [8.8, 15]);   // بدنه
        $line([8.8, 15], [17.6, 15]);
        $line([17.6, 15], [19.6, 8.2]);
        $line([19.6, 8.2], [7.4, 8.2]);
        $line([10, 11.6], [18.2, 11.6]); // خط میانی سبد
        imagesetthickness($im, 1);
        foreach ([[10, 18.4], [16.4, 18.4]] as $c) {
            [$x, $y] = $P(...$c);
            imagefilledellipse($im, $x, $y, (int) round($u * 3.2), (int) round($u * 3.2), $w);
        }
    }

    protected function draw(string $file, int $px, ?string $src, string $brand, bool $maskable): void
    {
        [$r, $g, $b] = sscanf(ltrim($brand, '#').'000000', '%02x%02x%02x');
        $im = imagecreatetruecolor($px, $px);
        imagesavealpha($im, true);
        $bg = imagecolorallocate($im, $r ?? 79, $g ?? 74, $b ?? 99);
        $white = imagecolorallocate($im, 255, 255, 255);
        imagefill($im, 0, 0, $bg);
        $logo = null;
        if ($src && is_file($src) && ($info = @getimagesize($src))) {
            $logo = match ($info[2]) {
                IMAGETYPE_PNG => @imagecreatefrompng($src),
                IMAGETYPE_JPEG => @imagecreatefromjpeg($src),
                IMAGETYPE_WEBP => @imagecreatefromwebp($src),
                default => null,
            };
        }
        $lwo = $logo ? imagesx($logo) : 0;
        $lho = $logo ? imagesy($logo) : 0;
        if ($logo && $lwo >= 128 && abs($lwo - $lho) <= max($lwo, $lho) * 0.04) {
            // آیکون مربعی آماده (مثل آیکون اپ): تمام‌قد، بدون قاب سفید؛ برای «maskable» کمی کوچک‌تر روی رنگ لبه خودش
            if ($maskable) {
                // زمینه هر ردیف = رنگ لبه همان ردیف تصویر (بدون قاب و درز)
                $pad = (int) round($px * 0.07);
                for ($y = 0; $y < $px; $y++) {
                    $sy = (int) max(0, min($lho - 1, ($y - $pad) * $lho / max(1, $px - 2 * $pad)));
                    $c = imagecolorsforindex($logo, imagecolorat($logo, 1, $sy));
                    imageline($im, 0, $y, $px - 1, $y, imagecolorallocate($im, $c['red'], $c['green'], $c['blue']));
                }
            } else {
                $pad = 0;
            }
            imagecopyresampled($im, $logo, $pad, $pad, 0, 0, $px - 2 * $pad, $px - 2 * $pad, $lwo, $lho);
        } elseif ($logo) {
            // لوگو روی زمینه سفید با حاشیه امن
            imagefill($im, 0, 0, $white);
            $pad = (int) round($px * ($maskable ? 0.2 : 0.08));
            $box = $px - 2 * $pad;
            $lw = imagesx($logo);
            $lh = imagesy($logo);
            $scale = min($box / $lw, $box / $lh);
            $nw = (int) round($lw * $scale);
            $nh = (int) round($lh * $scale);
            imagecopyresampled($im, $logo, (int) (($px - $nw) / 2), (int) (($px - $nh) / 2), 0, 0, $nw, $nh, $lw, $lh);
        } else {
            // نشان کیسه خرید
            $s = $px / 24;
            $o = $maskable ? $px * 0.15 : 0;
            $k = $maskable ? 0.7 : 1;
            $t = fn ($v) => (int) round($o + $v * $s * $k);
            imagesetthickness($im, max(2, (int) round($px / 22 * $k)));
            imagefilledpolygon($im, [$t(5), $t(9), $t(19), $t(9), $t(17.8), $t(20), $t(6.2), $t(20)], $white);
            imagearc($im, $t(12), $t(9), (int) ($s * 7 * $k), (int) ($s * 8 * $k), 180, 360, $white);
        }
        if (! is_dir(dirname($file))) {
            mkdir(dirname($file), 0755, true);
        }
        imagepng($im, $file);
        imagedestroy($im);
    }

    public function worker()
    {
        $v = config('store.version').'-'.substr(md5((string) setting('brand_color').(string) setting('font')), 0, 6);
        $assets = [
            '/offline',
            '/css/app.css?v='.config('store.version'),
            '/js/app.js?v='.config('store.version'),
            '/fonts/fonts.css?v='.config('store.version'),
            '/fonts/vazirmatn-Regular.woff2',
            '/fonts/vazirmatn-Bold.woff2',
            '/fonts/vazirmatn-ExtraBold.woff2',
        ];
        $js = view('pwa-worker', ['version' => $v, 'assets' => $assets])->render();

        return response($js, 200, [
            'Content-Type' => 'application/javascript; charset=utf-8',
            'Cache-Control' => 'no-cache',
            'Service-Worker-Allowed' => '/',
        ]);
    }

    public function offline()
    {
        return view('store.offline');
    }
}
