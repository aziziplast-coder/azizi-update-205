<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\RemitPayment;
use App\Models\Remittance;
use App\Models\User;
use App\Services\Chat;
use App\Services\Remit;
use App\Services\Shipping;
use App\Services\Walkin;
use App\Support\Banks;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

/**
 * «اپ مدیریت»: وب‌اپ موبایلی همکاران (نصب‌شدنی). هر کس فقط بخش‌هایی را می‌بیند که دسترسی‌اش را دارد:
 * گفتگو و سفارش‌ها (orders)، فیش‌ها و حواله‌ها (remit_assist / remit_manage)، بیجک (orders).
 * فیش حضوری: صدور برای مشتری بدون سفارش، چاپ با فیش‌پرینتر (۵۸/۸۰ میلی‌متر)، بارگذاری عکس فیش با گوشی.
 */
class ManageController extends Controller
{
    /* ---------------- دسترسی‌ها ---------------- */

    public static function can(?User $u, string $s): bool
    {
        if (! $u || ! $u->is_active || ! in_array($u->role, ['admin', 'staff'], true)) {
            return false;
        }

        return match ($s) {
            'chat' => Chat::enabled() && $u->hasPerm('chats'),
            'orders' => $u->hasPerm('orders'),
            'waybills' => $u->hasPerm('waybills'),
            'receipts', 'remits' => Remit::enabled() && Remit::canWork($u),
            'chief' => Remit::enabled() && Remit::isChief($u),
            'walkin' => Remit::enabled() && Remit::canWork($u) && $u->hasPerm('walkin') && \App\Services\WalkinReceipt::on(),
            'products' => $u->hasPerm('products'),
            default => false,
        };
    }

    protected function need(Request $r, string $s): User
    {
        $u = $r->user();
        abort_unless(static::can($u, $s), 403, 'به این بخش دسترسی ندارید.');

        return $u;
    }

    /** پرداخت‌هایی که این همکار می‌بیند (همان قاعده پنل) */
    protected function payQuery(User $u)
    {
        $q = RemitPayment::query()->with(['order:id,number,customer_name,mobile,assignee_id', 'remittance']);
        if (Remit::isChief($u)) {
            return $q;
        }

        return $q->where(fn ($w) => $w->whereHas('remittance', fn ($r) => $r->where('assignee_id', $u->id))
            ->orWhereHas('order', fn ($o) => $o->where('assignee_id', $u->id))
            ->orWhere(fn ($x) => $x->whereNull('order_id')->where('issued_by', $u->id)));
    }

    protected function canSee(User $u, RemitPayment $p): bool
    {
        return $this->payQuery($u)->whereKey($p->id)->exists();
    }

    protected function back(Request $r, string $msg, bool $ok = true)
    {
        return back()->with($ok ? 'm_ok' : 'm_err', $msg);
    }

    /* ---------------- PWA ---------------- */

    public function manifest()
    {
        return response()->json([
            'id' => '/manage', 'name' => 'اپ مدیریت — '.store_name(), 'short_name' => 'مدیریت عزیزی', 'lang' => 'fa', 'dir' => 'rtl',
            'start_url' => '/manage?source=pwa', 'scope' => '/manage', 'display' => 'standalone', 'orientation' => 'portrait',
            'background_color' => '#f4f5f9', 'theme_color' => setting('brand_color', '#4f4a63'),
            'icons' => [
                ['src' => route('pwa.manage_icon', 192), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.manage_icon', 512), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.manage_icon', 513), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
            ],
        ], 200, ['Content-Type' => 'application/manifest+json'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function sw()
    {
        $js = <<<'JS'
self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', function (e) {
  if (e.request.mode !== 'navigate') return;
  e.respondWith(fetch(e.request).catch(function () {
    return new Response('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>اینترنت وصل نیست</title><body style="font-family:Tahoma,sans-serif;text-align:center;padding:70px 20px;color:#333;background:#f4f5f9"><div style="font-size:46px">📡</div><h2>اینترنت وصل نیست</h2><p>بعد از وصل شدن اینترنت (یا روشن کردن اینترنت گوشی) دوباره امتحان کنید.</p><button onclick="location.reload()" style="margin-top:12px;padding:12px 26px;border:0;border-radius:14px;background:#4f4a63;color:#fff;font:inherit">تلاش دوباره</button></body></html>', { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
  }));
});
JS;

        return response($js, 200, ['Content-Type' => 'application/javascript; charset=utf-8', 'Service-Worker-Allowed' => '/manage', 'Cache-Control' => 'no-cache']);
    }

    /* ---------------- ورود ---------------- */

    public function loginForm(Request $r)
    {
        if (static::can($r->user(), 'orders') || static::can($r->user(), 'receipts')) {
            return redirect()->route('manage.home');
        }

        return view('manage.login');
    }

    public function login(Request $r)
    {
        $data = $r->validate(['mobile' => 'required|string|max:20', 'password' => 'required|string|max:120']);
        $m = mobile($data['mobile']);
        usleep(250000);
        $u = $m ? User::query()->where('mobile', $m)->first() : null;
        if (! $u || ! $u->is_active || ! in_array($u->role, ['admin', 'staff'], true) || ! $u->password || ! \Illuminate\Support\Facades\Hash::check($data['password'], $u->password)) {
            if ($u && $u->role === 'keeper') {
                return back()->withInput()->with('m_err', 'انباردارها از «اپ انبار» وارد شوند.');
            }

            return back()->withInput()->with('m_err', 'شماره موبایل یا رمز عبور درست نیست.');
        }
        Auth::login($u, true);
        $r->session()->regenerate();
        $u->forceFill(['last_login_at' => now()])->saveQuietly();

        return redirect()->intended(route('manage.home'));
    }

    public function logout(Request $r)
    {
        Auth::logout();
        $r->session()->invalidate();
        $r->session()->regenerateToken();

        return redirect()->route('manage.login');
    }

    /* ---------------- خانه ---------------- */

    public function home(Request $r)
    {
        $u = $r->user();
        $k = [];
        if (static::can($u, 'chat')) {
            $k['chat'] = Chat::unreadFor($u);
        }
        if (static::can($u, 'orders')) {
            $k['orders'] = Order::query()->released()->whereIn('status', ['on_hold', 'processing', 'settling', 'to_freight'])
                ->when(! $u->isAdmin(), fn ($q) => $q->where('assignee_id', $u->id))->count();
            $k['waybills'] = Shipping::pendingQuery()->count();
            $k['late'] = Shipping::overdueCount();
        }
        if (static::can($u, 'receipts')) {
            $k['review'] = $this->payQuery($u)->where('status', 'submitted')->count();
            $k['awaiting'] = $this->payQuery($u)->where('status', 'awaiting')->count();
            $mine = Remittance::query()->where('status', 'active')->when(! Remit::isChief($u), fn ($q) => $q->where('assignee_id', $u->id))->get();
            $k['free'] = (int) $mine->sum(fn ($x) => $x->stats()['free']);
            $k['remits'] = $mine->count();
            $k['today'] = (int) $this->payQuery($u)->where('kind', 'walkin')->where('created_at', '>=', now()->startOfDay())->where('status', '!=', 'cancelled')->sum('amount');
        }

        // کسی که بخش‌های گوشیِ اپ را ندارد (مثلاً مسئول محصولات): بخش‌های پنلش مستقیم روی صفحه خانه
        $groups = (! static::can($u, 'receipts') && ! static::can($u, 'orders')) ? static::modules($u) : null;
        if (static::can($u, 'products')) {
            $k['prod'] = ManageProductsController::counts();
        }

        return view('manage.home', ['u' => $u, 'k' => $k, 'nav' => 'home', 'groups' => $groups]);
    }

    /* ---------------- گفتگو ---------------- */

    public function chat(Request $r)
    {
        $u = $this->need($r, 'chat');

        return view('manage.chat', ['u' => $u, 'nav' => 'chat']);
    }

    /* ---------------- سفارش‌ها ---------------- */

    public function orders(Request $r)
    {
        $u = $this->need($r, 'orders');
        $f = (string) $r->query('f', $u->isAdmin() ? 'open' : 'mine');
        $q = trim(en_digits((string) $r->query('q', '')));
        $list = Order::query()->released()->with('assignee:id,name,mobile')
            ->when($f === 'mine', fn ($w) => $w->where('assignee_id', $u->id)->whereNotIn('status', ['completed', 'cancelled', 'failed']))
            ->when($f === 'open', fn ($w) => $w->whereIn('status', ['on_hold', 'processing', 'settling', 'to_freight', 'shipped']))
            ->when($f === 'free', fn ($w) => $w->whereNull('assignee_id')->whereIn('status', ['on_hold', 'processing', 'settling', 'to_freight', 'shipped']))
            ->when(isset(Order::STATUSES[$f]), fn ($w) => $w->where('status', $f))
            ->when($q !== '', fn ($w) => $w->where(fn ($x) => $x->where('number', 'like', "%$q%")->orWhere('customer_name', 'like', "%$q%")->orWhere('mobile', 'like', '%'.(mobile($q) ?: $q).'%')->orWhere('company', 'like', "%$q%")))
            ->latest('id')->paginate(25)->withQueryString();

        return view('manage.orders', ['u' => $u, 'list' => $list, 'f' => $f, 'q' => $q, 'nav' => 'orders']);
    }

    public function order(Request $r, Order $order)
    {
        $u = $this->need($r, 'orders');
        $order->load(['items' => fn ($q) => $q->orderBy('id'), 'assignee']);
        $pays = RemitPayment::query()->with('remittance')->where('order_id', $order->id)->where('status', '!=', 'cancelled')->orderBy('id')->get();
        $events = $order->events()->latest('id')->limit(12)->get();

        return view('manage.order', ['u' => $u, 'o' => $order, 'pays' => $pays, 'events' => $events, 'nav' => 'orders', 'canChat' => Chat::canView($u, $order), 'acts' => static::orderActions($order)]);
    }

    /* ---------------- فیش‌ها ---------------- */

    public function receipts(Request $r)
    {
        $u = $this->need($r, 'receipts');
        $tab = (string) $r->query('tab', 'submitted');
        $kind = (string) $r->query('kind', 'all');
        $q = trim(en_digits((string) $r->query('q', '')));
        $base = $this->payQuery($u);
        $counts = [
            'submitted' => (clone $base)->where('status', 'submitted')->count(),
            'awaiting' => (clone $base)->whereIn('status', ['awaiting', 'rejected'])->count(),
        ];
        $list = $base
            ->when($tab === 'submitted', fn ($w) => $w->where('status', 'submitted'))
            ->when($tab === 'awaiting', fn ($w) => $w->whereIn('status', ['awaiting', 'rejected']))
            ->when($tab === 'confirmed', fn ($w) => $w->where('status', 'confirmed'))
            ->when($tab === 'all', fn ($w) => $w->where('status', '!=', 'cancelled'))
            ->when($kind === 'walkin', fn ($w) => $w->where('kind', 'walkin'))
            ->when($kind === 'online', fn ($w) => $w->where('kind', '!=', 'walkin'))
            ->when($q !== '', fn ($w) => $w->where(fn ($x) => $x->where('walkin_name', 'like', "%$q%")->orWhere('walkin_mobile', 'like', "%$q%")
                ->orWhereHas('order', fn ($o) => $o->where('number', 'like', "%$q%")->orWhere('customer_name', 'like', "%$q%")->orWhere('mobile', 'like', "%$q%"))
                ->orWhereHas('remittance', fn ($o) => $o->where('code', 'like', "%$q%")->orWhere('holder_name', 'like', "%$q%"))))
            ->orderByDesc($tab === 'submitted' ? 'submitted_at' : 'id')->paginate(25)->withQueryString();

        return view('manage.receipts', ['u' => $u, 'list' => $list, 'tab' => $tab, 'kind' => $kind, 'q' => $q, 'counts' => $counts, 'nav' => 'receipts']);
    }

    public function receiptNew(Request $r)
    {
        $u = $this->need($r, 'walkin');

        return view('manage.receipt-new', ['u' => $u, 'remits' => \App\Services\WalkinReceipt::remits($u), 'nav' => 'receipts']);
    }

    public function receiptStore(Request $r)
    {
        $u = $this->need($r, 'walkin');
        $d = $r->validate(['name' => 'required|string|max:120', 'mobile' => 'nullable|string|max:20', 'amount' => 'required', 'remit' => 'required|integer', 'note' => 'nullable|string|max:300']);
        try {
            $p = \App\Services\WalkinReceipt::issue($u, $d['name'], $d['mobile'] ?? null, (int) to_int($d['amount']), (int) $d['remit'], $d['note'] ?? null);
        } catch (ValidationException $e) {
            return back()->withInput()->with('m_err', collect($e->errors())->flatten()->first());
        }

        return redirect()->route('manage.receipt', [$p, 'new' => 1])->with('m_ok', 'فیش '.money($p->amount).' تومان برای «'.$p->walkin_name.'» صادر شد.');
    }

    public function receipt(Request $r, RemitPayment $payment)
    {
        $u = $this->need($r, 'receipts');
        abort_unless($this->canSee($u, $payment), 404);
        $payment->load('remittance', 'order', 'issuer', 'reviewer');

        return view('manage.receipt', ['u' => $u, 'p' => $payment, 'acc' => \App\Services\WalkinReceipt::account($payment), 'nav' => 'receipts',
            'canReview' => $payment->status === 'submitted' && \App\Filament\Resources\RemitPaymentResource::canReview($payment),
            'canFix' => in_array($payment->status, ['submitted', 'confirmed'], true) && \App\Filament\Resources\RemitPaymentResource::canReview($payment),
            'reasons' => Remit::rejectReasons()]);
    }

    public function receiptPrint(Request $r, RemitPayment $payment)
    {
        $u = $this->need($r, 'receipts');
        abort_unless($this->canSee($u, $payment), 404);
        $payment->load('remittance', 'order', 'issuer');

        return view('manage.print', ['p' => $payment, 'acc' => \App\Services\WalkinReceipt::account($payment), 'link' => $payment->walkin_token ? \App\Services\WalkinReceipt::link($payment) : null, 'u' => $u]);
    }

    public function receiptUpload(Request $r, RemitPayment $payment)
    {
        $u = $this->need($r, 'receipts');
        abort_unless($this->canSee($u, $payment), 404);
        $r->validate(['files' => 'required|array|min:1|max:8', 'files.*' => 'file|max:'.(15 * 1024).'|mimes:jpg,jpeg,png,webp,heic,heif,pdf', 'ref' => 'nullable|string|max:80']);
        try {
            Remit::submit($payment, $r->file('files'), $r->input('ref'), null, 'بارگذاری توسط '.$u->displayName());
        } catch (ValidationException $e) {
            return $this->back($r, collect($e->errors())->flatten()->first(), false);
        }

        return $this->back($r, 'عکس فیش بارگذاری شد؛ پس از دیدن مبلغ در حساب، تأیید کنید.');
    }

    public function receiptReview(Request $r, RemitPayment $payment)
    {
        $u = $this->need($r, 'receipts');
        abort_unless($this->canSee($u, $payment) && \App\Filament\Resources\RemitPaymentResource::canReview($payment), 403);
        if ($r->input('do') === 'replace') {
            $r->validate(['files' => 'required|array|min:1|max:8', 'files.*' => 'file|max:'.(15 * 1024).'|mimes:jpg,jpeg,png,webp,heic,heif,pdf', 'reason' => 'required|string|max:200']);
            try {
                Remit::replaceReceipt($payment, $r->file('files'), $u, (string) $r->input('reason'), ! $r->boolean('add'), $r->input('ref'));
            } catch (ValidationException $e) {
                return $this->back($r, collect($e->errors())->flatten()->first(), false);
            }

            return $this->back($r, '🔁 فیش تازه ثبت شد'.($payment->status === 'confirmed' ? '؛ برای تأیید دوباره به کارخانه‌دار رفت.' : '.'));
        }
        if ($r->input('do') === 'drop') {
            try {
                $left = Remit::removeReceipt($payment, [(int) $r->input('i')], $u);
            } catch (ValidationException $e) {
                return $this->back($r, collect($e->errors())->flatten()->first(), false);
            }

            return $this->back($r, '🗑 تصویر تکراری حذف شد؛ '.fa($left).' تصویر ماند. حالا تأیید کنید.');
        }
        if ($r->input('do') === 'ok') {
            abort_unless($payment->status === 'submitted', 422);
            Remit::confirm($payment, $u);

            return $this->back($r, '✅ فیش '.money($payment->amount).' تومان تأیید شد.');
        }
        $why = trim((string) ($r->input('reason') === '_other' ? $r->input('other') : $r->input('reason')));
        if ($why === '') {
            return $this->back($r, 'علت رد را انتخاب یا بنویسید.', false);
        }
        Remit::reject($payment, $why, $u);

        return $this->back($r, 'فیش رد شد'.($payment->order_id ? ' و برای مشتری پیامک شد.' : '.'));
    }

    public function receiptCancel(Request $r, RemitPayment $payment)
    {
        $u = $this->need($r, 'receipts');
        abort_unless($this->canSee($u, $payment) && ! $payment->order_id && in_array($payment->status, ['awaiting', 'rejected'], true), 403);
        Remit::cancel($payment, $u, 'ابطال فیش حضوری توسط '.$u->displayName());
        Remit::checkFilled($payment->remittance->fresh());

        return redirect()->route('manage.receipts', ['tab' => 'awaiting', 'kind' => 'walkin'])->with('m_ok', 'فیش باطل شد و ظرفیت حواله آزاد شد.');
    }

    public function receiptImg(Request $r, RemitPayment $payment, int $i = 0)
    {
        $u = $this->need($r, 'receipts');
        abort_unless($this->canSee($u, $payment), 404);
        $path = $payment->files()[$i] ?? null;
        abort_unless($path && Storage::disk('local')->exists($path), 404);

        return response()->file(Storage::disk('local')->path($path), ['Cache-Control' => 'private, max-age=600']);
    }

    /**
     * همه کارهای صفحه سفارش پنل (همان دکمه‌ها با همان دسترسی‌ها) برای اپ:
     * هر دکمه همان فرم پنل را مستقیم باز می‌کند (?action=…) تا چیزی از پنل کم نباشد و منطق دوتا نشود.
     */
    public static function orderActions(Order $o): array
    {
        try {
            $page = new \App\Filament\Resources\OrderResource\Pages\ViewOrder;
            (new \ReflectionProperty($page, 'record'))->setValue($page, $o);
            $list = (fn () => $this->getHeaderActions())->call($page);
        } catch (\Throwable $e) {
            report($e);

            return [];
        }
        $base = url('/admin/orders/'.$o->id);
        $out = [];
        $add = function ($a, string $group) use (&$out, $base, $o) {
            if (! $a instanceof \Filament\Actions\Action || ! $a->isVisible()) {
                return;
            }
            $name = $a->getName();
            if (in_array($name, ['chat', 'keeperApp'], true)) {
                return; // در خود اپ هست
            }
            $url = $name === 'edit' ? $base.'/edit' : ($a->getUrl() ?: $base.'?'.http_build_query(['action' => $name, 'from' => 'app']));
            $out[$group][] = ['name' => $name, 'label' => trim(strip_tags((string) $a->getLabel())), 'color' => (string) ($a->getColor() ?: 'gray'),
                'url' => $url, 'off' => $a->isDisabled(), 'tab' => (bool) $a->getUrl() && $name !== 'edit'];
        };
        foreach ($list as $a) {
            if ($a instanceof \Filament\Actions\ActionGroup) {
                if ($a->isVisible()) {
                    foreach ($a->getActions() as $x) {
                        $add($x, trim(strip_tags((string) $a->getLabel())));
                    }
                }
            } else {
                $add($a, '');
            }
        }

        return $out;
    }

    /* ---------------- همه بخش‌ها (منوی کامل پنل، متناسب با دسترسی) ---------------- */

    /** همه بخش‌های پنل که این کارمند به آن دسترسی دارد؛ بخش‌هایی که نسخه گوشی در اپ دارند به اپ می‌روند */
    public static function modules(User $u): array
    {
        try {
            $panel = \Filament\Facades\Filament::getPanel('admin');
            \Filament\Facades\Filament::setCurrentPanel($panel);
            $panel->boot();
            $nav = \Filament\Facades\Filament::getNavigation();
        } catch (\Throwable $e) {
            report($e);

            return [];
        }
        $native = array_filter([
            '/admin/chats' => static::can($u, 'chat') ? route('manage.chat') : null,
            '/admin/orders' => static::can($u, 'orders') ? route('manage.orders') : null,
            '/admin/waybills' => static::can($u, 'waybills') ? route('manage.waybills') : null,
            '/admin/remit-payments' => static::can($u, 'receipts') ? route('manage.receipts') : null,
            '/admin/remittances' => static::can($u, 'remits') ? route('manage.remits') : null,
            '/admin/products' => static::can($u, 'products') ? route('manage.products') : null,
        ]);
        $out = [];
        foreach ($nav as $g) {
            $items = [];
            foreach ($g->getItems() as $i) {
                if (! $i->isVisible()) {
                    continue;
                }
                $url = (string) $i->getUrl();
                $path = '/'.ltrim((string) parse_url($url, PHP_URL_PATH), '/');
                $app = $native[$path] ?? null;
                $sep = str_contains($url, '?') ? '&' : '?';
                $items[] = [
                    'label' => (string) $i->getLabel(), 'icon' => (string) ($i->getIcon() ?: 'heroicon-o-squares-2x2'),
                    'badge' => $i->getBadge() !== null ? (string) $i->getBadge() : null, 'app' => (bool) $app,
                    'url' => $app ?: ($path === '/keeper' ? url('/keeper') : ($path === '/admin' ? url('/admin') : $url.$sep.'from=app')),
                    'ext' => $path === '/keeper',
                ];
            }
            if ($items) {
                $out[] = ['label' => (string) ($g->getLabel() ?: 'پیشخوان'), 'items' => $items];
            }
        }

        return $out;
    }

    public function all(Request $r)
    {
        $u = $r->user();

        return view('manage.all', ['u' => $u, 'groups' => static::modules($u), 'nav' => 'all']);
    }

    /* ---------------- حواله‌ها ---------------- */

    public function remits(Request $r)
    {
        $u = $this->need($r, 'remits');
        $tab = (string) $r->query('tab', 'active');
        $list = Remittance::query()->with('assignee:id,name,mobile')
            ->when(! Remit::isChief($u), fn ($q) => $q->where('assignee_id', $u->id))
            ->when($tab === 'active', fn ($q) => $q->whereIn('status', ['active', 'pending']))
            ->when($tab === 'filled', fn ($q) => $q->where('status', 'filled'))
            ->when($tab === 'closed', fn ($q) => $q->whereIn('status', ['closed', 'transferred']))
            ->orderByRaw("case status when 'active' then 0 when 'pending' then 1 when 'filled' then 2 else 3 end")->orderBy('sort')->orderByDesc('id')->paginate(30)->withQueryString();

        return view('manage.remits', ['u' => $u, 'list' => $list, 'tab' => $tab, 'nav' => 'remits', 'chief' => Remit::isChief($u)]);
    }

    public function remit(Request $r, Remittance $remittance)
    {
        $u = $this->need($r, 'remits');
        abort_unless(Remit::isChief($u) || (int) $remittance->assignee_id === (int) $u->id, 404);
        $pays = $remittance->payments()->with('order:id,number,customer_name,mobile')->where('status', '!=', 'cancelled')->latest('id')->limit(80)->get();

        return view('manage.remit', ['u' => $u, 'x' => $remittance->load('assignee', 'factory'), 'st' => $remittance->stats(), 'pays' => $pays, 'nav' => 'remits', 'chief' => Remit::isChief($u)]);
    }

    public function remitForm(Request $r, ?Remittance $remittance = null)
    {
        $u = $this->need($r, 'chief');

        return view('manage.remit-form', ['u' => $u, 'x' => $remittance, 'nav' => 'remits', 'assistants' => Remit::assistants(),
            'factories' => \App\Models\Factory::query()->where('active', true)->orderBy('name')->get(['id', 'name', 'mobile'])]);
    }

    public function remitSave(Request $r, ?Remittance $remittance = null)
    {
        $u = $this->need($r, 'chief');
        $d = $r->validate([
            'code' => 'required|string|max:30', 'title' => 'required|string|max:190', 'amount' => 'required', 'assignee_id' => 'required|integer',
            'holder_name' => 'nullable|string|max:120', 'card_number' => 'nullable|string|max:30', 'sheba' => 'nullable|string|max:40', 'account_number' => 'nullable|string|max:40',
            'bank_name' => 'nullable|string|max:60', 'factory_phone' => 'nullable|string|max:20', 'factory_id' => 'nullable|integer', 'sort' => 'nullable|integer', 'note' => 'nullable|string|max:500',
            'factory_decides' => 'nullable|boolean',
        ]);
        $code = trim(en_digits($d['code']));
        if (Remittance::query()->where('code', $code)->when($remittance, fn ($q) => $q->whereKeyNot($remittance->id))->exists()) {
            return back()->withInput()->with('m_err', 'حواله‌ای با این شماره قبلاً ثبت شده است.');
        }
        $amount = (int) to_int($d['amount']);
        if ($amount < 1000 || ($remittance && $amount < $remittance->stats()['reserved'])) {
            return back()->withInput()->with('m_err', $remittance ? 'مبلغ کمتر از مبالغ صادرشده برای مشتریان ('.money($remittance->stats()['reserved']).' تومان) نمی‌شود.' : 'مبلغ حواله را درست بنویسید.');
        }
        $decides = ! $remittance && ! empty($d['factory_decides']) && ! empty($d['factory_id']);
        $card = Banks::digits($d['card_number'] ?? '') ?: null;
        $sheba = Banks::digits($d['sheba'] ?? '') ? Banks::normalizeSheba($d['sheba']) : null;
        if (! $decides && ($remittance === null || $remittance->status !== 'pending')) {
            if (! $card && ! $sheba && empty($d['account_number'])) {
                return back()->withInput()->with('m_err', 'شماره کارت، شبا یا شماره حساب را وارد کنید.');
            }
            if ($card && (strlen($card) !== 16 || ! Banks::validCard($card))) {
                return back()->withInput()->with('m_err', 'شماره کارت معتبر نیست.');
            }
            if ($sheba && ! Banks::validSheba(Banks::digits($sheba))) {
                return back()->withInput()->with('m_err', 'شماره شبا معتبر نیست.');
            }
            if (trim((string) ($d['holder_name'] ?? '')) === '') {
                return back()->withInput()->with('m_err', 'نام صاحب حساب را بنویسید.');
            }
        }
        $row = [
            'code' => $code, 'title' => trim($d['title']), 'amount' => $amount, 'assignee_id' => (int) $d['assignee_id'],
            'factory_id' => $d['factory_id'] ?? null, 'sort' => (int) ($d['sort'] ?? 0), 'note' => $d['note'] ?? null,
            'factory_phone' => Banks::digits($d['factory_phone'] ?? '') ?: null,
        ];
        if (! empty($row['factory_id'])) {
            $row['factory_phone'] = \App\Models\Factory::find($row['factory_id'])?->mobile ?: $row['factory_phone'];
        }
        if (! $decides) {
            $row += ['holder_name' => trim((string) ($d['holder_name'] ?? '')) ?: null, 'card_number' => $card, 'sheba' => $sheba, 'account_number' => trim((string) ($d['account_number'] ?? '')) ?: null,
                'bank_name' => trim((string) ($d['bank_name'] ?? '')) ?: (Banks::fromCard($card) ?: Banks::fromSheba($sheba))];
        }
        if ($remittance) {
            $remittance->update($row);
            Remit::checkFilled($remittance->fresh());

            return redirect()->route('manage.remit', $remittance)->with('m_ok', 'حواله '.fa($code).' ذخیره شد.');
        }
        $x = Remittance::query()->create($row + ['created_by' => $u->id, 'status' => $decides ? 'pending' : 'active', 'dest_status' => $decides ? 'awaiting' : null]);
        if ($x->factory_id && \App\Services\FactoryPortal::cfg()['enabled']) {
            try {
                \App\Services\FactoryPortal::announce($x);
            } catch (\Throwable $e) {
                report($e);
            }
        }

        return redirect()->route('manage.remit', $x)->with('m_ok', 'حواله '.fa($x->code).' ایجاد شد'.($decides ? '؛ منتظر تعیین حساب توسط کارخانه‌دار.' : '.'));
    }

    public function remitClose(Request $r, Remittance $remittance)
    {
        $u = $this->need($r, 'chief');
        if (in_array($remittance->status, ['active', 'filled', 'pending'], true)) {
            $remittance->payments()->whereIn('status', ['awaiting', 'rejected'])->get()->each(fn ($p) => Remit::cancel($p, $u, 'بستن حواله'));
            $remittance->update(['status' => 'closed', 'closed_at' => now()]);
        }

        return redirect()->route('manage.remit', $remittance)->with('m_ok', 'حواله بسته شد.');
    }

    /* ---------------- بیجک ---------------- */

    public function waybills(Request $r)
    {
        $u = $this->need($r, 'waybills');
        $tab = $r->query('tab') === 'archive' ? 'archive' : 'pending';
        $q = trim(en_digits((string) $r->query('q', '')));
        $list = ($tab === 'archive' ? Shipping::archiveQuery()->orderByDesc('updated_at') : Shipping::pendingQuery()->orderBy('status_changed_at'))
            ->with('assignee:id,name,mobile')
            ->when($q !== '', fn ($w) => $w->where(fn ($x) => $x->where('number', 'like', "%$q%")->orWhere('customer_name', 'like', "%$q%")->orWhere('mobile', 'like', "%$q%")))
            ->paginate(25)->withQueryString();

        return view('manage.waybills', ['u' => $u, 'list' => $list, 'tab' => $tab, 'q' => $q, 'nav' => 'waybills',
            'counts' => ['pending' => Shipping::pendingQuery()->count(), 'late' => Shipping::overdueCount()]]);
    }

    public function waybillSave(Request $r, Order $order)
    {
        $u = $this->need($r, 'waybills');
        $r->validate(['file' => 'nullable|file|max:'.(15 * 1024).'|mimes:jpg,jpeg,png,webp,heic,heif,pdf', 'driver' => 'nullable|string|max:20', 'mode' => 'required|in:waybill,direct']);
        try {
            if ($r->input('mode') === 'direct') {
                Shipping::markDirect($order, $r->file('file'), $r->input('driver'), $u);

                return $this->back($r, 'ارسال مستقیم سفارش '.fa($order->number).' ثبت شد'.($r->filled('driver') ? ' و برای مشتری پیامک شد.' : '.'));
            }
            abort_unless($r->hasFile('file'), 422, 'تصویر بیجک را انتخاب کنید.');
            Shipping::uploadWaybill($order, $r->file('file'), $u);
        } catch (ValidationException $e) {
            return $this->back($r, collect($e->errors())->flatten()->first(), false);
        }

        return $this->back($r, 'بیجک سفارش '.fa($order->number).' بارگذاری شد.');
    }

    /* ---------------- صفحه عمومی مشتری حضوری ---------------- */

    public function walkinShow(string $token)
    {
        $p = \App\Services\WalkinReceipt::byToken($token);
        abort_unless($p, 404);

        return view('manage.walkin', ['p' => $p, 'acc' => \App\Services\WalkinReceipt::account($p)]);
    }

    public function walkinUpload(Request $r, string $token)
    {
        $p = \App\Services\WalkinReceipt::byToken($token);
        abort_unless($p, 404);
        $r->validate(['files' => 'required|array|min:1|max:6', 'files.*' => 'file|max:'.(15 * 1024).'|mimes:jpg,jpeg,png,webp,heic,heif,pdf', 'ref' => 'nullable|string|max:80']);
        try {
            Remit::submit($p, $r->file('files'), $r->input('ref'));
        } catch (ValidationException $e) {
            return back()->with('m_err', collect($e->errors())->flatten()->first());
        }

        return back()->with('m_ok', 'فیش شما رسید ✅ پس از دیدن مبلغ در حساب تأیید می‌شود.');
    }
}
