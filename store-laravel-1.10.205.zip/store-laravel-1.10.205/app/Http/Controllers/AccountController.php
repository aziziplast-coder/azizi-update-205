<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Survey;
use App\Models\SurveyResponse;
use App\Services\Cart;
use App\Services\Checkout;
use App\Support\Provinces;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $orders = $user->orders()->with(['remitPayments', 'items.product:id,sku,barcode'])->latest('id')->paginate(15);

        return view('store.account', ['user' => $user, 'orders' => $orders, 'provinces' => Provinces::all(), 'tab' => $request->query('tab', 'orders')]);
    }

    public function update(Request $request)
    {
        $request->merge(['postal_code' => en_digits($request->input('postal_code'))]);
        $data = $request->validate([
            'name' => 'required|string|max:120',
            'company' => 'nullable|string|max:150',
            'province' => 'nullable|string|max:60',
            'city' => 'nullable|string|max:80',
            'address' => 'nullable|string|max:500',
            'postal_code' => 'nullable|string|max:20',
            'password' => 'nullable|string|min:6|confirmed',
        ], [], ['name' => 'نام', 'password' => 'رمز عبور']);
        if (empty($data['password'])) {
            unset($data['password']);
        }
        $request->user()->update($data);

        return redirect()->route('account', ['tab' => 'profile'])->with('ok', 'اطلاعات حساب ذخیره شد.');
    }

    public function order(Request $request, string $number)
    {
        $order = Order::query()->with('items')->where('number', $number)->where('user_id', $request->user()->id)->firstOrFail();
        $card = $order->payment_method === 'card' ? (array) setting('pay_card') : null;
        $remit = \App\Services\Remit::enabled() || $order->remitPayments()->exists();
        $remitPays = $remit ? $order->remitPayments()->with('remittance')->where('status', '!=', 'cancelled')->orderBy('id')->get() : collect();
        if ($remit) {
            $card = null; // پرداخت از طریق حساب حواله‌ها
        }
        $survey = null;
        foreach (Survey::query()->where('is_active', true)->get() as $s) {
            if (in_array($order->status, $s->statuses(), true) && ! SurveyResponse::query()->where('survey_id', $s->id)->where('order_id', $order->id)->where('status', 'done')->exists()) {
                $survey = $s;
                break;
            }
        }

        // کالاهای حذف‌شده در انبار و پیشنهاد جایگزین
        $removed = \App\Services\Picking::removedItems($order);
        $suggest = [];
        $canReplace = $order->canReplace() && ! $order->replace_submitted_at;
        if ($canReplace) {
            $pids = $order->items->pluck('product_id')->filter()->all();
            foreach ($removed as $it) {
                $p = $it->product_id ? \App\Models\Product::query()->find($it->product_id) : null;
                $gone = ['id' => (int) $it->product_id, 'name' => $it->name, 'price' => (int) $it->unit_price, 'category_id' => $p?->category_id,
                    'mode' => $it->mode, 'units' => max(1, $it->orderedUnits() - (int) $it->units), 'per_carton' => (int) $it->per_carton];
                $suggest[$it->id] = array_values(array_filter(\App\Services\Replacements::for($gone, 4), fn ($r) => ! in_array($r['product']->id, $pids, true)));
            }
        }

        return view('store.order', [
            'removed' => $removed,
            'suggest' => $suggest,
            'canReplace' => $canReplace,
            'reps' => $order->replacements()->whereIn('status', ['draft', 'submitted', 'approved', 'rejected'])->get(),
            'order' => $order,
            'card' => $card,
            'remit' => $remit,
            'remitPays' => $remitPays,
            'canPay' => $order->status === 'pending_payment' && isset(Checkout::paymentMethods()['gateway']),
            'canEdit' => $order->customerCanEdit(),
            'survey' => $survey,
        ]);
    }

    protected function own(Request $request, string $number): Order
    {
        return Order::query()->with('items')->where('number', $number)->where('user_id', $request->user()->id)->firstOrFail();
    }

    /** شروع ویرایش سفارش: اقلام سفارش به سبد منتقل می‌شوند */
    public function startEdit(Request $request, string $number, Cart $cart)
    {
        $order = $this->own($request, $number);
        if (! $order->customerCanEdit()) {
            return redirect()->route('order.show', $number)->withErrors(['pay' => 'این سفارش دیگر قابل تغییر نیست؛ برای تغییر با فروشگاه تماس بگیرید.']);
        }
        $cart->loadOrder($order);

        return redirect()->route('cart')->with('ok', 'اقلام سفارش '.fa($order->number).' در سبد قرار گرفت. تغییرات را انجام دهید و «ثبت تغییرات سفارش» را بزنید.');
    }

    /** «سفارش مجدد»: اقلام همین سفارش با قیمت و موجودی امروز به سبد خرید */
    public function reorder(Request $request, string $number, Cart $cart)
    {
        $order = $this->own($request, $number);
        if (! $order->canReorder()) {
            return redirect()->route('order.show', $number)->withErrors(['pay' => 'سفارش مجدد برای این سفارش فعال نیست؛ با فروشگاه تماس بگیرید.']);
        }
        if ($cart->record()?->edit_order_id) {
            return redirect()->route('cart')->withErrors(['cart' => 'اول ویرایش سفارش قبلی را ثبت یا لغو کنید، بعد سفارش مجدد بزنید.']);
        }
        $want = [];
        foreach ($order->items()->whereNotNull('product_id')->get() as $it) {
            $u = max((int) $it->units, (int) ($it->ordered_units ?? 0));
            if ($u > 0) {
                $k = $it->product_id.':'.$it->cartMode();
                $want[$k] = ['pid' => (int) $it->product_id, 'mode' => $it->cartMode(), 'u' => ($want[$k]['u'] ?? 0) + $u, 'name' => $it->name];
            }
        }
        $raw = $cart->raw();
        $ok = 0;
        $bad = [];
        foreach ($want as $k => $w) {
            $r = $cart->set($w['pid'], $w['mode'], (int) ($raw[$k] ?? 0) + $w['u']);
            if (! empty($r['units'])) {
                $ok++;
            } else {
                $bad[] = $w['name'];
            }
        }
        $order->log('مشتری «سفارش مجدد» زد: '.fa($ok).' کالا به سبد رفت'.($bad ? '، '.fa(count($bad)).' کالا موجود نبود' : ''), $order->user_id);
        $msg = $ok ? fa($ok).' کالای سفارش '.fa($order->number).' با قیمت و موجودی امروز به سبد اضافه شد. تعدادها را بررسی و سفارش را ثبت کنید.' : 'متأسفانه هیچ‌کدام از کالاهای این سفارش الان موجود نیست.';
        if ($bad) {
            $msg .= ' ناموجود: '.implode('، ', array_slice($bad, 0, 8)).(count($bad) > 8 ? ' و …' : '');
        }

        return redirect()->route('cart')->with($ok ? 'ok' : 'err', $msg);
    }

    public function cancelEdit(Request $request, Cart $cart)
    {
        $rec = $cart->record();
        if ($rec && $rec->edit_order_id) {
            $eo = \App\Models\Order::query()->where('user_id', $request->user()?->id)->find($rec->edit_order_id);
            $rec->update(['items' => [], 'items_count' => 0, 'edit_order_id' => null, 'total' => 0]);
            // «در ویرایش مشتری» پیش از بیعانه: انصراف = تغییری ندارد ← بیعانه
            if ($eo && $eo->status === 'on_hold' && in_array($eo->deposit_ask, ['edit', 'late'], true)) {
                \App\Services\Remit::depositGo($eo, 'مشتری از ویرایش سفارش انصراف داد');
                \App\Services\OrderWindows::editDone($eo, false);
            }
        }

        return redirect()->route('account')->with('ok', 'ویرایش سفارش لغو شد؛ سفارش بدون تغییر باقی ماند.');
    }

    public function amend(Request $request, string $number, Cart $cart, Checkout $checkout)
    {
        $order = $this->own($request, $number);
        if ((int) $cart->record()?->edit_order_id !== (int) $order->id) {
            return redirect()->route('cart');
        }
        $checkout->amend($order, $cart);

        return redirect()->route('order.show', $number)->with('ok', 'تغییرات سفارش ثبت شد.');
    }

    /* ---------------- جایگزینی کالاهای حذف‌شده در انبار ---------------- */

    public function replaceAdd(Request $request, string $number, \App\Services\Picking $picking)
    {
        $order = $this->own($request, $number);
        $data = $request->validate(['product' => 'required|integer', 'mode' => 'required|in:carton,retail', 'qty' => 'required|integer|min:1|max:100000', 'replaces' => 'nullable|integer']);
        $p = \App\Models\Product::query()->findOrFail((int) $data['product']);
        // کارتنی: تعداد کارتن؛ کالای با قانون خرید خاص (بسته‌ای/فله) یا خرده: تعداد عدد
        $units = $data['mode'] === 'carton' && $p->per_carton > 1 && ! $p->buyRule()[2] ? (int) $data['qty'] * (int) $p->per_carton : (int) $data['qty'];
        try {
            $r = $picking->addReplacement($order, $p->id, $data['mode'], $units, $data['replaces'] ?? null);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return back()->withErrors(['replace' => collect($e->errors())->flatten()->first()]);
        }

        return redirect(route('order.show', $number).'#replace')->with('ok', '«'.$r->name.'» به فهرست جایگزین‌ها اضافه شد. در پایان «ارسال برای تأیید» را بزنید.');
    }

    /** جستجوی کالا برای «خرید کالای دیگر» در مهلت جایگزینی (پیوست فاکتور) */
    public function replaceSearch(Request $request, string $number)
    {
        $order = $this->own($request, $number);
        abort_unless($order->canReplace() && ! $order->replace_submitted_at, 403);
        $s = trim((string) $request->query('q', ''));
        if (mb_strlen($s) < 2) {
            return response()->json(['items' => []]);
        }
        $rows = \App\Models\Product::query()->active()->search($s)->limit(40)->get()
            ->sortByDesc(fn ($p) => $p->isAvailable() ? 1 : 0)->take(15); // موجودها اول

        return response()->json(['items' => $rows->map(function ($p) {
            [$min, $step, $custom] = $p->buyRule();
            $carton = $p->cartonAvailable();

            return [
                'id' => $p->id, 'name' => $p->name, 'img' => $p->image ? thumb($p->image, 160) : null, 'avail' => $p->isAvailable(),
                'mode' => $carton ? 'carton' : 'retail', 'price' => money($p->unitPrice($carton ? 'carton' : 'retail')).' تومان هر '.$p->unitName(),
                'unit' => $carton && $p->per_carton > 1 && ! $custom ? 'کارتن' : $p->unitName(), 'qty' => $carton && $custom ? $min : 1,
                'note' => $carton ? ($custom ? $p->buyRuleText() : ($p->per_carton > 1 ? $p->cartonText() : '')) : 'خرده',
            ];
        })->values()], 200, [], JSON_UNESCAPED_UNICODE);
    }

    public function replaceRemove(Request $request, string $number, int $rep)
    {
        $order = $this->own($request, $number);
        $order->replacements()->where('status', 'draft')->whereKey($rep)->delete();

        return redirect(route('order.show', $number).'#replace');
    }

    public function replaceSubmit(Request $request, string $number, \App\Services\Picking $picking)
    {
        $order = $this->own($request, $number);
        try {
            $n = $picking->submitReplacements($order);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return back()->withErrors(['replace' => collect($e->errors())->flatten()->first()]);
        }

        return redirect(route('order.show', $number).'#replace')->with('ok', fa($n).' کالای جایگزین برای تأیید فروشگاه ارسال شد؛ پس از تأیید به سفارش اضافه و از انبار جمع‌آوری می‌شود.');
    }

    /* ---------------- نظرسنجی ---------------- */

    public function survey(Request $request, string $number)
    {
        $order = $this->own($request, $number);
        $survey = Survey::query()->where('is_active', true)->findOrFail((int) $request->query('s', 0) ?: Survey::query()->where('is_active', true)->value('id'));
        $done = SurveyResponse::query()->where('survey_id', $survey->id)->where('order_id', $order->id)->where('status', 'done')->exists();

        return view('store.survey', ['order' => $order, 'survey' => $survey, 'done' => $done]);
    }

    public function surveySubmit(Request $request, string $number)
    {
        $order = $this->own($request, $number);
        $survey = Survey::query()->findOrFail((int) $request->input('survey'));
        $answers = [];
        $ratings = [];
        $staff = [];
        foreach ($survey->items() as $q) {
            $v = $request->input('a.'.$q['key']);
            $v = is_string($v) ? mb_substr(trim($v), 0, 1000) : null;
            if ($q['type'] === 'rating') {
                $v = $v !== null && $v !== '' ? max(1, min(5, (int) $v)) : null;
                if ($v) {
                    $ratings[] = $v;
                    if ($q['staff']) {
                        $staff[] = $v;
                    }
                }
            } elseif ($q['type'] === 'choice' && $v !== null && ! in_array($v, $q['options'], true)) {
                $v = null;
            }
            if ($q['required'] && ($v === null || $v === '')) {
                if ($request->expectsJson()) {
                    return response()->json(['ok' => false, 'msg' => 'لطفاً به «'.$q['label'].'» پاسخ دهید.'], 422);
                }

                return back()->withErrors(['survey' => 'لطفاً به «'.$q['label'].'» پاسخ دهید.'])->withInput();
            }
            $answers[$q['key']] = $v;
        }
        SurveyResponse::query()->updateOrCreate(['survey_id' => $survey->id, 'order_id' => $order->id], [
            'user_id' => $order->user_id,
            'assignee_id' => $order->assignee_id,
            'status' => 'done',
            'answers' => $answers,
            'rating' => $ratings ? round(array_sum($ratings) / count($ratings), 2) : null,
            'staff_rating' => $staff ? round(array_sum($staff) / count($staff), 2) : null,
            'comment' => mb_substr(trim((string) $request->input('comment')), 0, 2000) ?: null,
        ]);
        \Illuminate\Support\Facades\Cache::forget('survey.p.'.$order->user_id);
        $thanks = $survey->thanks ?: 'از اینکه نظرتان را ثبت کردید سپاسگزاریم 🌷';
        if ($request->expectsJson()) {
            return response()->json(['ok' => true, 'msg' => $thanks]);
        }

        return redirect()->route('order.show', $number)->with('ok', $thanks);
    }

    public function surveySkip(Request $request, string $number)
    {
        $order = $this->own($request, $number);
        $survey = Survey::query()->findOrFail((int) $request->input('survey'));
        SurveyResponse::query()->firstOrCreate(['survey_id' => $survey->id, 'order_id' => $order->id], ['user_id' => $order->user_id, 'assignee_id' => $order->assignee_id, 'status' => 'skipped']);
        \Illuminate\Support\Facades\Cache::forget('survey.p.'.$order->user_id);

        return response()->json(['ok' => true]);
    }
}
