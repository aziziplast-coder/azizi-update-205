<?php

namespace App\Http\Controllers;

use App\Models\ChatMessage;
use App\Models\ChatThread;
use App\Models\User;
use App\Services\Chat;
use App\Services\TeamChat;
use Illuminate\Http\Request;
use RuntimeException;

/**
 * گپ داخلی اپراتورها با حسابدار کل.
 * اپراتور: /admin-tools/tchat (یک گفتگو) — حسابدار کل: /admin-tools/tchat/{user} (گفتگوی هر اپراتور).
 * پاسخ‌ها همان شکل گفتگوی سفارش است تا همان پنجره گفتگو (chat.js) استفاده شود.
 */
class TeamChatController extends Controller
{
    protected function json(array $data)
    {
        return response()->json($data, 200, ['Cache-Control' => 'no-store'], JSON_UNESCAPED_UNICODE);
    }

    protected function store(Request $r, ChatThread $t, string $side, User $u): ChatMessage
    {
        Chat::$reply = $r->integer('reply') ?: null;
        $type = (string) $r->input('type');
        if ($type === 'voice') {
            return Chat::post($t, $side, $u, 'voice', null, Chat::storeVoice($r->file('voice') ?? throw new RuntimeException('صدا ضبط نشد.'), (int) $r->input('sec')));
        }
        if ($type === 'video') {
            return Chat::post($t, $side, $u, 'video', $r->input('text'), Chat::storeVideo((int) $u->id, (string) $r->input('uid'), $r->file('poster'), $r->only(['sec', 'w', 'h'])));
        }
        if ($r->hasFile('image')) {
            return Chat::post($t, $side, $u, 'image', $r->input('text'), Chat::storeImage($r->file('image')));
        }
        $text = trim((string) $r->input('text'));
        if ($text === '') {
            throw new RuntimeException('پیام خالی است.');
        }

        return Chat::post($t, $side, $u, 'text', $text);
    }

    protected static function preview(ChatMessage $m): string
    {
        return match ($m->kind) { 'image' => '📷 عکس فرستاد', 'voice' => '🎤 پیام صوتی فرستاد', 'video' => '🎬 ویدیو فرستاد', default => (string) $m->body };
    }

    /** طرف گفتگو: اپراتور خودش (c) یا حسابدار کل برای یک اپراتور (s) */
    protected function ctx(Request $r, ?int $user): array
    {
        $me = $r->user();
        if ($user === null) {
            abort_unless(TeamChat::isOperator($me), 403);

            return [TeamChat::thread($me), 'c', $me];
        }
        abort_unless(TeamChat::canChief($me), 403);
        $op = User::query()->whereIn('role', ['admin', 'staff'])->findOrFail($user);

        return [TeamChat::thread($op), 's', $op];
    }

    public function show(Request $r, ?int $user = null)
    {
        [$t, $side] = $this->ctx($r, $user);
        if ($before = (int) $r->query('before', 0)) {
            $list = Chat::messages($t, 0, true, 60, $before);

            return $this->json(['ok' => true, 'messages' => $list, 'more' => count($list) >= 60]);
        }
        Chat::markRead($t, $side);

        return $this->json(TeamChat::state($t->refresh(), $side, $r->user(), max(0, (int) $r->query('after', 0))));
    }

    public function send(Request $r, ?int $user = null)
    {
        [$t, $side, $op] = $this->ctx($r, $user);
        Chat::clientKey($r->input('ck'));
        if (Chat::alreadyGot($t)) {
            Chat::$clientKey = Chat::$reply = null;

            return $this->json(TeamChat::state($t->refresh(), $side, $r->user(), max(0, (int) $r->input('after', 0))));
        }
        try {
            $m = $this->store($r, $t, $side, $r->user());
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
        Chat::markRead($t->refresh(), $side);
        $side === 'c' ? TeamChat::notifyChiefs($op, static::preview($m)) : TeamChat::notifyOperator($op, $r->user(), static::preview($m));

        return $this->json(TeamChat::state($t->refresh(), $side, $r->user(), max(0, (int) $r->input('after', 0))));
    }

    public function act(Request $r, ?int $user = null)
    {
        [$t, $side] = $this->ctx($r, $user);
        if ($r->input('act') === 'del') {
            $m = ChatMessage::query()->where('thread_id', $t->id)->findOrFail((int) $r->input('mid'));
            // اپراتور طرف c است؛ فقط پیام خودش
            $ok = $side === 'c' ? ((int) $m->user_id === (int) $r->user()->id && Chat::canDelete($m, 'c', null)) : Chat::canDelete($m, 's', $r->user());
            if (! $ok) {
                return response()->json(['ok' => false, 'msg' => 'این پیام دیگر قابل حذف نیست (فقط پیام خودتان و در مهلت تعیین‌شده).'], 422);
            }
            Chat::remove($m);
        } elseif ($r->input('act') === 'read') {
            Chat::markRead($t, $side);
        }

        return $this->json(TeamChat::state($t->refresh(), $side, $r->user(), 0));
    }

    public function up(Request $r)
    {
        abort_unless(TeamChat::isOperator($r->user()) || TeamChat::canChief($r->user()), 403);
        try {
            $n = Chat::chunk((int) $r->user()->id, (string) $r->input('uid'), (int) $r->input('i'), $r->file('part') ?? throw new RuntimeException('تکه نرسید.'));
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }

        return response()->json(['ok' => true, 'have' => $n]);
    }
}
