<?php

namespace App\Http\Controllers;

use App\Models\Page;
use App\Models\Product;
use App\Support\HomeBlocks;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(\Illuminate\Http\Request $request)
    {
        // لینک‌های سایت قدیمی (ربات): index.php?p=specificAdds&what=homepage_off&id=2&json=true
        if ($request->query('p') === 'specificAdds') {
            return app(CollectionController::class)->legacy($request);
        }

        return view('store.home', ['blocks' => HomeBlocks::for('site')]);
    }

    public function page(string $slug)
    {
        $page = Page::query()->where('slug', $slug)->where('is_active', true)->firstOrFail();

        return view('store.page', compact('page'));
    }

    /** کارت کالاهای «بازدیدهای اخیر» (شناسه‌ها از مرورگر مشتری) */
    public function recent(Request $request)
    {
        $ids = array_slice(array_values(array_unique(array_filter(array_map('intval', explode(',', (string) $request->query('ids', '')))))), 0, 30);
        $limit = max(4, min(30, (int) setting('recent_limit', 12)));
        if (! $ids || ! setting('recent_enabled', true)) {
            return response()->json(['html' => '', 'count' => 0]);
        }
        $products = Product::query()->active()->with('category')->whereIn('id', $ids)->get()
            ->sortBy(fn ($p) => array_search($p->id, $ids))->take($limit);
        $html = '';
        foreach ($products as $p) {
            $html .= view('store.partials.product-card', ['p' => $p])->render();
        }

        return response()->json(['html' => $html, 'count' => $products->count(), 'ids' => $products->pluck('id')->values()]);
    }
}
