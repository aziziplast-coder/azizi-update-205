<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\PostCategory;
use App\Models\Product;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function index(Request $request)
    {
        return $this->list($request, null);
    }

    public function category(Request $request, string $slug)
    {
        return $this->list($request, PostCategory::query()->where('slug', $slug)->firstOrFail());
    }

    public function tag(Request $request, string $tag)
    {
        return $this->list($request, null, $tag);
    }

    protected function list(Request $request, ?PostCategory $cat, ?string $tag = null)
    {
        $q = Post::query()->published()->with('category')->latest('published_at');
        if ($cat) {
            $q->where('post_category_id', $cat->id);
        }
        if ($tag) {
            $ids = Post::query()->published()->whereNotNull('tags')->get(['id', 'tags'])
                ->filter(fn ($p) => in_array($tag, array_map('trim', (array) $p->tags), true))->pluck('id')->all();
            $q->whereIn('id', $ids ?: [0]);
        }
        if ($term = trim((string) $request->query('q'))) {
            $q->where(fn ($w) => $w->where('title', 'like', '%'.$term.'%')->orWhere('excerpt', 'like', '%'.$term.'%'));
        }
        $posts = $q->paginate(max(6, min(48, (int) setting('blog_per_page', 12))))->withQueryString();
        $cats = PostCategory::query()->withCount(['posts' => fn ($p) => $p->published()])->orderBy('sort')->get()->filter(fn ($c) => $c->posts_count > 0);

        return view('store.blog', compact('posts', 'cats', 'cat', 'tag', 'term'));
    }

    /** لینک مقاله سایت قبلی: /blog-134/عنوان */
    public function legacy(\Illuminate\Http\Request $request, string $legacy, ?string $name = null)
    {
        $post = Post::query()->published()->with(['category', 'author'])->where('legacy_id', (int) $legacy)->first();
        if (! $post) {
            // مقاله‌ای که منتقل نشده: «ریدایرکت‌ها»، وگرنه جستجوی همان عنوان در وبلاگ
            if ($to = \App\Support\Redirects::find($request)) {
                return redirect()->away($to, 301);
            }
            $q = trim(urldecode((string) $name));

            return $q !== '' ? redirect()->route('blog', ['q' => $q], 302) : redirect()->route('blog', [], 302);
        }
        $want = rawurldecode((string) parse_url($post->url(), PHP_URL_PATH));
        if (\App\Support\LegacyUrls::enabled() && $want !== rawurldecode($request->getPathInfo())) {
            return redirect()->to($post->url(), 301);
        }

        return $this->render($post);
    }

    public function show(string $slug)
    {
        $post = Post::query()->published()->with(['category', 'author'])->where('slug', $slug)->firstOrFail();
        // در حالت لینک سایت قبلی، نشانی اصلی همان /blog-شناسه/عنوان است
        if ($post->legacy_id && \App\Support\LegacyUrls::enabled()) {
            return redirect()->to($post->url(), 301);
        }

        return $this->render($post);
    }

    protected function render(Post $post)
    {
        Post::query()->whereKey($post->id)->increment('views');
        [$body, $toc] = $post->bodyWithToc();
        $ids = array_filter(array_map('intval', (array) $post->product_ids));
        $products = $ids ? Product::query()->active()->with('category')->whereIn('id', $ids)->get() : collect();
        $related = Post::query()->published()->whereKeyNot($post->id)
            ->when($post->post_category_id, fn ($q) => $q->orderByRaw('CASE WHEN post_category_id = ? THEN 0 ELSE 1 END', [$post->post_category_id]))
            ->latest('published_at')->limit(3)->get();

        return view('store.post', compact('post', 'body', 'toc', 'products', 'related'));
    }
}
