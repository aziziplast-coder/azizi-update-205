<?php

namespace App\Http\Controllers;

use App\Services\Sync\SyncWorker;

/** کارگر پس‌زمینه همگام‌سازی JSON (فقط با کلید مخفی) */
class SyncWorkerController extends Controller
{
    public function __invoke(string $token)
    {
        abort_unless(hash_equals(SyncWorker::token(), $token), 404);

        return response(SyncWorker::run(), 200, ['Content-Type' => 'text/plain', 'X-Robots-Tag' => 'noindex', 'Cache-Control' => 'no-store']);
    }
}
