<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Warehouse;
use App\Support\Slips;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    /** فاکتور برای مشتری (فقط سفارش خودش) */
    public function show(Request $request, string $number)
    {
        $order = Order::query()->with('items.warehouse')->where('number', $number)->firstOrFail();
        $user = $request->user();
        if ($order->user_id !== $user->id && ! $user->hasPerm('orders')) {
            abort(404);
        }

        return $this->render($order, 'customer', null, route('order.show', $order->number));
    }

    /** فاکتور یا حواله انبار برای مدیر/کارمند/انباردار */
    public function admin(Request $request, Order $order)
    {
        $user = $request->user();
        abort_unless($user->hasPerm('orders') || ($order->review_status === 'pending' && $user->hasPerm('cheque_review')), 403);
        abort_if($order->review_status === 'pending' && ! $user->hasPerm('cheque_review'), 403, 'این سفارش چکی هنوز بررسی و تأیید نشده است.');
        abort_if(\App\Services\Chat::printLocked($order), 403, 'این سفارش هنوز مسئول ندارد؛ اول یکی از همکاران سفارش را بردارد، بعد چاپ کنید.');
        \App\Services\Picking::syncWarehouses($order);
        // چاپ فاکتور کامل از گفتگو (plain) ← تیک «چاپ شد» کنار دکمه؛ همین‌جا در سرور ثبت می‌شود تا به مرورگر وابسته نباشد
        if ($request->boolean('plain') && ! $request->query('wh')) {
            \App\Services\Chat::markPrinted($order, $user);
        }
        $order->load(['items.warehouse', 'items.product:id,barcode,sku']);
        $back = url('/admin/orders/'.$order->id);
        $param = (string) $request->query('wh', '');
        $role = 'staff';
        $mine = null;
        if ($user->isKeeper()) {
            $role = 'keeper';
            $mine = $user->warehouses()->pluck('warehouses.id')->map(fn ($v) => (int) $v)->all();
            abort_unless($order->items->whereIn('warehouse_id', $mine)->isNotEmpty(), 403);
        }

        // حواله کالاهای افزوده/جایگزین یک مرحله (پس از تأیید اپراتور، چاپ مستقیم از گفتگو) — بدون «به‌جای کدام کالا»
        if ($param === 'add' || preg_match('/^add-(\d+)$/', $param)) {
            return $this->addSlips($order, $role, $mine, $back, $param);
        }

        // حواله کالاهای جایگزین‌شده (برای انبار سرپرست‌دار که از روی کاغذ جمع می‌کند)
        if ($param === 'repl' || str_starts_with($param, 'repl-')) {
            return $this->replacementSlips($order, $user, $role, $mine, $back, $param);
        }

        // یک انبار مشخص
        if (ctype_digit($param) && (int) $param > 0 && ($mine === null || in_array((int) $param, $mine, true))) {
            return $this->render($order, $role, [(int) $param], $back);
        }

        // انباردار: یک حواله با اقلام همه انبارهای خودش (به ترتیب شماره انبار)
        if ($role === 'keeper') {
            $wids = array_values(array_intersect($order->items->pluck('warehouse_id')->map(fn ($v) => (int) $v)->unique()->all(), $mine));
            $one = ['key' => 'k'.$user->id, 'label' => $user->displayName(), 'keepers' => $user->displayName(), 'wids' => $wids];
            // ترتیب درست انبارها در حواله ترکیبی
            $metas = Warehouse::query()->whereIn('id', $one['wids'])->get(['id', 'code', 'kind', 'name'])->keyBy('id');
            usort($one['wids'], fn ($a, $b) => Slips::whKey($metas[$a] ?? null, $a) <=> Slips::whKey($metas[$b] ?? null, $b));
            $one['whLabel'] = collect($one['wids'])->map(fn ($id) => ($metas[$id] ?? null)?->label() ?? 'بدون انبار')->implode('، ');

            return $this->render($order, $role, null, $back, [$one], 'mine');
        }

        $groups = Slips::groups($order);
        // همه حواله‌ها پشت سر هم (هر انباردار یک برگه)
        if ($param === 'all') {
            return $this->render($order, $role, null, $back, array_values($groups), 'all');
        }
        // حواله یک انباردار / انبار بدون انباردار
        if (isset($groups[$param])) {
            return $this->render($order, $role, null, $back, [$groups[$param]], $param);
        }

        return $this->render($order, $role, null, $back);
    }

    /**
     * چاپ کالاهای جایگزین‌شده: هر انباردار/سرپرست یک برگه با همان قالب حواله (دو خانه تیک برای روال کاغذی).
     * wh=repl همه برگه‌ها؛ wh=repl-{کلید حواله} فقط یک انباردار.
     */
    protected function replacementSlips(Order $order, $user, string $role, ?array $mine, string $back, string $param)
    {
        $repl = \App\Services\Picking::replacedItems($order);
        if ($role === 'keeper') {
            $repl = $repl->filter(fn ($i) => in_array((int) $i->warehouse_id, (array) $mine, true))->values();
        }
        abort_if($repl->isEmpty(), 404, 'در این سفارش کالای جایگزین‌شده‌ای برای چاپ نیست.');
        $wids = $repl->pluck('warehouse_id')->map(fn ($v) => (int) $v)->unique()->values()->all();
        $groups = array_values(array_filter(Slips::groups($order, $wids), fn ($g) => $repl->contains(fn ($i) => in_array((int) $i->warehouse_id, $g['wids'], true))));
        if (str_starts_with($param, 'repl-')) {
            $key = substr($param, 5);
            $groups = array_values(array_filter($groups, fn ($g) => $g['key'] === $key));
        }
        abort_if(! $groups, 404, 'برای این انباردار کالای جایگزین‌شده‌ای نیست.');

        return $this->render($order, $role, null, $back, $groups, 'repl', $repl->pluck('id')->all(), true);
    }

    /** فقط کالاهایی که مشتری در یک مرحله اضافه/جایگزین کرده؛ مثل حواله انبار، با جایگاه بقیه بار */
    protected function addSlips(Order $order, string $role, ?array $mine, string $back, string $param)
    {
        $round = str_starts_with($param, 'add-') ? (int) substr($param, 4) : (int) $order->items->where('units', '>', 0)->max('round');
        abort_if($round <= 1, 404, 'این سفارش کالای افزوده ندارد.');
        $items = $order->items->filter(fn ($i) => (int) $i->round === $round && (int) $i->units > 0);
        if ($role === 'keeper') {
            $items = $items->filter(fn ($i) => in_array((int) $i->warehouse_id, (array) $mine, true));
        }
        abort_if($items->isEmpty(), 404, 'در این مرحله کالای افزوده‌ای برای چاپ نیست.');
        $wids = $items->pluck('warehouse_id')->map(fn ($v) => (int) $v)->unique()->values()->all();
        $groups = array_values(array_filter(Slips::groups($order, $wids), fn ($g) => $items->contains(fn ($i) => in_array((int) $i->warehouse_id, $g['wids'], true))));
        $bays = \App\Models\PickTask::query()->where('order_id', $order->id)->where('round', '<', $round)->whereNotNull('bay')->where('bay', '!=', '')->pluck('bay')
            ->flatMap(fn ($b) => preg_split('/\s*[،,]\s*/u', (string) $b))->map(fn ($b) => trim($b))->filter(fn ($b) => $b !== '' && ! str_contains($b, 'بدون جایگاه'))->unique()->values()->all();
        view()->share('addsInfo', ['round' => $round, 'bays' => $bays]);

        return $this->render($order, $role, null, $back, $groups, 'add-'.$round, $items->pluck('id')->all());
    }

    protected function render(Order $order, string $role, ?array $scope, string $back, ?array $slips = null, string $slipMode = '', ?array $onlyItemIds = null, bool $repl = false)
    {
        // نام اصلی همه اقلام (حتی ناموجودها) برای نوشتن «جایگزین کدام کالا» در حواله جایگزین‌ها
        $replOf = $order->items->pluck('name', 'id')->all();
        // تعداد اقلام جایگزین‌شده (برای دکمه چاپ جایگزین‌شده‌ها)؛ انباردار فقط انبارهای خودش را می‌بیند
        $replItems = $role === 'customer' ? collect() : \App\Services\Picking::replacedItems($order);
        if ($role === 'keeper') {
            $mineIds = auth()->user()->warehouses()->pluck('warehouses.id')->map(fn ($v) => (int) $v)->all();
            $replItems = $replItems->filter(fn ($i) => in_array((int) $i->warehouse_id, $mineIds, true));
        }
        $replCount = $replItems->count();
        // اقلامی که در انبار ناموجود بودند (تعداد صفر) در فاکتور و حواله چاپ نمی‌شوند
        $order->setRelation('items', $order->items->filter(fn ($i) => (int) $i->units > 0)->values());
        if ($onlyItemIds !== null) {
            $order->setRelation('items', $order->items->whereIn('id', $onlyItemIds)->values());
        }
        $whIds = $order->items->pluck('warehouse_id')->filter()->unique()->values();
        $warehouses = Warehouse::query()->with(['keepers' => fn ($q) => $q->where('is_active', true)])->whereIn('id', $whIds)->get()->keyBy('id');
        $sort = fn ($items) => setting('invoice_group_wh', true) ? Slips::sortItems($items, $warehouses) : $items->values();
        $pages = [];
        if ($slips) {
            foreach ($slips as $g) {
                $pages[] = ['items' => $sort($order->items->filter(fn ($i) => in_array((int) $i->warehouse_id, $g['wids'], true))), 'scope' => $g['wids'], 'isSlip' => true, 'group' => $g];
            }
        } else {
            $items = $scope ? $order->items->whereIn('warehouse_id', $scope) : $order->items;
            $pages[] = ['items' => $sort($items), 'scope' => $scope, 'isSlip' => (bool) $scope && $role !== 'customer', 'group' => null];
        }
        $options = [];
        if ($role === 'staff') {
            $options = collect(Slips::groups($order))->mapWithKeys(fn ($g) => [$g['key'] => $g['key'][0] === 'k' ? 'انباردار '.$g['label'] : $g['label']])->all();
        }

        return view('invoice', [
            'order' => $order,
            'pages' => $pages,
            'role' => $role,
            'showPrice' => $role !== 'keeper' || setting('keeper_prices', true),
            'options' => $options,
            'warehouses' => $warehouses,
            'back' => $back,
            'mode' => $slipMode ?: ($scope && count($scope) === 1 ? (string) $scope[0] : ''),
            'repl' => $repl,
            'replOf' => $replOf,
            'replCount' => $replCount,
        ]);
    }
}
