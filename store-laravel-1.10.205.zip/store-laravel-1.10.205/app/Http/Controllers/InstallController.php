<?php

namespace App\Http\Controllers;

use App\Models\Page;
use App\Models\User;
use App\Models\Warehouse;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use PDO;
use Throwable;

class InstallController extends Controller
{
    public static function requirements(): array
    {
        $r = [];
        $r[] = ['PHP نسخه 8.2 یا بالاتر', version_compare(PHP_VERSION, '8.2.0', '>='), PHP_VERSION, true];
        foreach (['pdo_sqlite' => false, 'pdo_mysql' => false, 'mbstring' => true, 'openssl' => true, 'tokenizer' => true, 'xml' => true, 'ctype' => true, 'fileinfo' => true, 'curl' => true, 'zip' => false, 'gd' => false, 'intl' => true] as $ext => $req) {
            $ok = $ext === 'zip' ? class_exists('ZipArchive') : extension_loaded($ext);
            if (in_array($ext, ['pdo_sqlite', 'pdo_mysql'], true)) {
                continue;
            }
            $r[] = ['افزونه '.$ext, $ok, $ok ? 'نصب است' : ($req ? 'نصب نیست — در Select PHP Version فعال کنید' : 'پیشنهادی — برای '.['zip' => 'پشتیبان و به‌روزرسانی', 'gd' => 'تصاویر کوچک', 'intl' => 'فرمت اعداد'][$ext]), $req];
        }
        $db = extension_loaded('pdo_sqlite') || extension_loaded('pdo_mysql');
        $r[] = ['پایگاه داده (pdo_sqlite یا pdo_mysql)', $db, $db ? (extension_loaded('pdo_sqlite') ? 'آماده — نیازی به ساخت دیتابیس نیست' : 'فقط MySQL') : 'هیچ‌کدام فعال نیست', true];
        foreach (['storage' => storage_path(), 'bootstrap/cache' => base_path('bootstrap/cache'), 'public/uploads' => public_path('uploads'), 'فایل .env' => base_path('.env')] as $label => $path) {
            $ok = file_exists($path) ? is_writable($path) : is_writable(dirname($path));
            $r[] = ['دسترسی نوشتن: '.$label, $ok, $ok ? 'درست' : 'دسترسی را 755 (پوشه) / 644 (فایل) کنید', true];
        }

        return $r;
    }

    public function show(Request $request)
    {
        $req = static::requirements();
        $ok = collect($req)->every(fn ($r) => $r[1] || ! $r[3]);

        return view('install', ['req' => $req, 'ok' => $ok, 'url' => $request->getSchemeAndHttpHost(), 'cpUser' => \App\Services\CpanelDatabase::guessUser()]);
    }

    public function run(Request $request)
    {
        $request->merge(['admin_mobile' => mobile($request->input('admin_mobile'))]);
        $data = $request->validate([
            'app_url' => 'nullable|url',
            'driver' => 'required|in:cpanel,mysql,sqlite',
            'cp_user' => [\Illuminate\Validation\Rule::requiredIf(fn () => $request->input('driver') === 'cpanel' && ! static::pendingDb()), 'nullable', 'string', 'max:64'],
            'cp_pass' => [\Illuminate\Validation\Rule::requiredIf(fn () => $request->input('driver') === 'cpanel' && ! static::pendingDb()), 'nullable', 'string', 'max:200'],
            'db_host' => 'required_if:driver,mysql|nullable|string',
            'db_port' => 'nullable|numeric',
            'db_name' => 'required_if:driver,mysql|nullable|string',
            'db_user' => 'required_if:driver,mysql|nullable|string',
            'db_pass' => 'nullable|string',
            'store_name' => 'required|string|max:100',
            'admin_name' => 'required|string|max:100',
            'admin_mobile' => 'required',
            'admin_email' => 'nullable|email',
            'admin_password' => 'required|string|min:8|confirmed',
        ], ['admin_mobile.required' => 'موبایل مدیر را درست وارد کنید (09xxxxxxxxx).', 'admin_password.min' => 'رمز مدیر دست‌کم ۸ کاراکتر باشد.', 'admin_password.confirmed' => 'تکرار رمز با رمز یکی نیست.']);

        // ۱) اتصال پایگاه داده
        $data['app_url'] = rtrim($data['app_url'] ?? '', '/') ?: $request->getSchemeAndHttpHost();
        if ($data['driver'] === 'sqlite' && ! extension_loaded('pdo_sqlite')) {
            return back()->withInput()->withErrors(['db_name' => 'افزونه pdo_sqlite روی هاست فعال نیست. آن را در Select PHP Version فعال کنید، یا در «تنظیمات پیشرفته» اطلاعات MySQL را وارد کنید.']);
        }
        if ($data['driver'] === 'cpanel') {
            // ساخت خودکار دیتابیس MySQL روی هاست؛ رمز سی‌پنل ذخیره نمی‌شود
            // اشتباه رایج: نوشتن نام کاربری دیتابیس (مثل user_admin) به‌جای نام کاربری سی‌پنل
            $guess = \App\Services\CpanelDatabase::guessUser();
            $cpUser = strtolower(preg_replace('/\s+/', '', (string) ($data['cp_user'] ?? $guess)));
            if ($guess && $cpUser !== $guess && str_starts_with($cpUser, $guess.'_')) {
                $cpUser = $guess;
            }
            try {
                // اگر در تلاش قبلی دیتابیس ساخته شده، دوباره ساخته نشود
                $db = static::pendingDb();
                if (! $db) {
                    $db = app(\App\Services\CpanelDatabase::class)->create($cpUser, preg_replace('/\s+/', '', (string) ($data['cp_pass'] ?? '')), $request->getHost());
                    static::pendingDb($db);
                }
            } catch (Throwable $e) {
                return back()->withInput($request->except(['cp_pass', 'admin_password', 'admin_password_confirmation']))->withErrors(['cp_pass' => $e->getMessage()]);
            }
            $data = array_merge($data, ['driver' => 'mysql', 'db_host' => $db['host'], 'db_port' => 3306, 'db_name' => $db['name'], 'db_user' => $db['user'], 'db_pass' => $db['pass']]);
            unset($data['cp_pass']);
            $autoDb = true;
        }
        if ($data['driver'] === 'sqlite') {
            $dbFile = storage_path('app/database/store.sqlite');
            @mkdir(dirname($dbFile), 0755, true);
            if (! is_file($dbFile)) {
                touch($dbFile);
            }
            $conn = ['DB_CONNECTION' => 'sqlite', 'DB_DATABASE' => ''];
            Config::set('database.connections.sqlite.database', $dbFile);
        } else {
            try {
                $dsn = 'mysql:host='.$data['db_host'].';port='.($data['db_port'] ?: 3306).';dbname='.$data['db_name'].';charset=utf8mb4';
                for ($try = 1; ; $try++) {
                    try {
                        new PDO($dsn, $data['db_user'], (string) $data['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 8]);
                        break;
                    } catch (Throwable $e) {
                        if ($try === 2 && $data['db_host'] === 'localhost') {
                            // بعضی هاست‌ها فقط با 127.0.0.1 وصل می‌شوند
                            $data['db_host'] = '127.0.0.1';
                            $dsn = 'mysql:host=127.0.0.1;port='.($data['db_port'] ?: 3306).';dbname='.$data['db_name'].';charset=utf8mb4';
                        }
                        if ($try >= 3) {
                            if (! empty($autoDb)) {
                                throw new \UnexpectedValueException('دیتابیس '.$data['db_name'].' در سی‌پنل ساخته شد ولی اتصال به آن برقرار نشد. از بخش MySQL Databases سی‌پنل مطمئن شوید کاربر '.$data['db_user'].' به آن اضافه شده است. پیام سرور: '.$e->getMessage());
                            }
                            throw $e;
                        }
                        sleep(2); // دسترسی کاربر تازه‌ساخته گاهی چند ثانیه بعد فعال می‌شود
                    }
                }
            } catch (\UnexpectedValueException $e) {
                return back()->withInput($request->except(['cp_pass', 'admin_password', 'admin_password_confirmation']))->withErrors(['db_name' => $e->getMessage()]);
            } catch (Throwable $e) {
                return back()->withInput()->withErrors(['db_name' => 'اتصال به پایگاه داده برقرار نشد. نام دیتابیس، نام کاربری و رمز را بررسی کنید و مطمئن شوید کاربر به دیتابیس اضافه شده (All Privileges). پیام سرور: '.$e->getMessage()]);
            }
            $conn = ['DB_CONNECTION' => 'mysql', 'DB_HOST' => $data['db_host'], 'DB_PORT' => (string) ($data['db_port'] ?: 3306), 'DB_DATABASE' => $data['db_name'], 'DB_USERNAME' => $data['db_user'], 'DB_PASSWORD' => (string) $data['db_pass']];
            Config::set('database.connections.mysql', array_merge(config('database.connections.mysql'), [
                'host' => $data['db_host'], 'port' => $data['db_port'] ?: 3306, 'database' => $data['db_name'], 'username' => $data['db_user'], 'password' => (string) $data['db_pass'],
            ]));
        }
        Config::set('database.default', $data['driver']);
        DB::purge();

        // ۲) فایل .env
        $this->writeEnv($conn + [
            'APP_NAME' => $data['store_name'],
            'APP_URL' => rtrim($data['app_url'], '/'),
            'APP_ENV' => 'production',
            'APP_DEBUG' => 'false',
        ]);

        // ۳) جدول‌ها و داده‌های اولیه
        try {
            @set_time_limit(300);
            Artisan::call('migrate', ['--force' => true]);
            Settings::flush();
            Settings::set(['store_name' => $data['store_name'], 'email' => $data['admin_email'] ?? '', 'admin_mobiles' => $data['admin_mobile']]);
            User::query()->updateOrCreate(['mobile' => $data['admin_mobile']], [
                'name' => $data['admin_name'],
                'email' => ($data['admin_email'] ?? null) ?: null,
                'password' => $data['admin_password'],
                'role' => 'admin',
                'is_active' => true,
            ]);
            if (! Warehouse::query()->exists()) {
                Warehouse::create(['name' => 'انبار اصلی', 'code' => 'W1']);
            }
            if (! Page::query()->exists()) {
                Page::create(['title' => 'درباره ما', 'slug' => 'about', 'body' => '<p>معرفی فروشگاه را از پنل مدیریت ← صفحات ویرایش کنید.</p>', 'sort' => 1]);
                Page::create(['title' => 'قوانین و شرایط خرید', 'slug' => 'terms', 'body' => '<p>شرایط ارسال، مرجوعی و پرداخت را این‌جا بنویسید.</p>', 'sort' => 2]);
                Page::create(['title' => 'تماس با ما', 'slug' => 'contact', 'body' => '<p>شماره تماس و آدرس فروشگاه.</p>', 'sort' => 3]);
            }
        } catch (Throwable $e) {
            report($e);

            return back()->withInput()->withErrors(['db_name' => 'ساخت جدول‌ها ناموفق بود: '.$e->getMessage()]);
        }

        @unlink(storage_path('app/install-db.json'));
        @mkdir(public_path('uploads'), 0755, true);
        file_put_contents(storage_path('app/health.key'), Str::random(40));
        file_put_contents(storage_path('app/installed.json'), json_encode(['at' => now()->toIso8601String(), 'version' => config('store.version')]));

        try {
            \App\Support\Optimizer::warm();
        } catch (\Throwable $e) {
            report($e);
        }

        return redirect('/admin/login')->with('installed', true);
    }

    /** دیتابیسی که در تلاش قبلی نصب ساخته شده (رمزنگاری‌شده در storage) */
    public static function pendingDb(?array $set = null): ?array
    {
        $f = storage_path('app/install-db.json');
        if ($set !== null) {
            file_put_contents($f, \Illuminate\Support\Facades\Crypt::encryptString(json_encode($set)));

            return $set;
        }
        try {
            return is_file($f) ? json_decode(\Illuminate\Support\Facades\Crypt::decryptString((string) file_get_contents($f)), true) : null;
        } catch (Throwable) {
            return null;
        }
    }

    protected function writeEnv(array $values): void
    {
        $file = base_path('.env');
        $env = is_file($file) ? file_get_contents($file) : file_get_contents(base_path('.env.example'));
        if (! preg_match('/^APP_KEY=base64:.+$/m', $env)) {
            $key = 'base64:'.base64_encode(random_bytes(32));
            $env = preg_match('/^APP_KEY=.*$/m', $env) ? preg_replace('/^APP_KEY=.*$/m', 'APP_KEY='.$key, $env) : "APP_KEY=$key\n".$env;
        }
        foreach ($values as $k => $v) {
            $v = (string) $v;
            $line = $k.'='.(preg_match('/[\s#"\'\\\\$]/u', $v) || $v === '' ? '"'.addcslashes($v, '"\\$').'"' : $v);
            if (preg_match('/^'.preg_quote($k, '/').'=.*$/m', $env)) {
                $env = preg_replace('/^'.preg_quote($k, '/').'=.*$/m', str_replace(['\\', '$'], ['\\\\', '\\$'], $line), $env);
            } else {
                $env .= "\n".$line;
            }
        }
        file_put_contents($file, $env);
    }
}
