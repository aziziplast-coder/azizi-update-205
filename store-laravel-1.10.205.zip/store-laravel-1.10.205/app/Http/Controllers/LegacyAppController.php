<?php

namespace App\Http\Controllers;

/**
 * اپ اندروید قدیمی عزیزی‌پلاست (com.persiandesigners.aziziplast، نسخه ۱.۴.۹ / versionCode 39).
 * آن اپ هنگام باز شدن http://aziziplast.com//getHomePage2.php را می‌خواند (XML با چند <data><content>).
 * بخش ششم آن JSON «به‌روزرسانی» است: {"version","payam","updateLink","ejbar"}؛ اگر version از نسخه اپ بزرگ‌تر باشد
 * پنجره «نسخه جدید» با دکمه دانلود باز می‌شود و ejbar=1 یعنی بدون نصب، اپ بسته می‌شود.
 * پس با انتقال دامنه، کاربران اپ قدیمی به نصب اپ جدید هدایت می‌شوند.
 */
class LegacyAppController extends Controller
{
    public static function cfg(): array
    {
        $app = (array) setting('mobile_app', []);
        $l = (array) ($app['legacy'] ?? []);
        $link = trim((string) ($l['link'] ?? '')) ?: (trim((string) ($app['download_url'] ?? '')) ?: url('/download/app'));

        return [
            'enabled' => ! array_key_exists('enabled', $l) || ! empty($l['enabled']),
            'force' => ! array_key_exists('force', $l) || ! empty($l['force']),
            'message' => trim((string) ($l['message'] ?? '')) ?: 'اپلیکیشن جدید '.store_name().' منتشر شد. این نسخه دیگر پشتیبانی نمی‌شود؛ برای ادامه خرید، اپ جدید را نصب کنید.',
            'link' => $link,
        ];
    }

    public function home()
    {
        $c = static::cfg();
        $parts = array_fill(0, 22, '');
        foreach ([0, 1, 2, 3, 4, 16, 21] as $i) {
            $parts[$i] = 'not##'; // فهرست‌های کالا خالی
        }
        $parts[12] = 'false';
        $parts[14] = '{}';
        if ($c['enabled']) {
            $parts[5] = json_encode(['version' => '9999', 'payam' => $c['message'], 'updateLink' => $c['link'], 'ejbar' => $c['force'] ? 1 : 0], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            // نوار پیام صفحه اصلی (اگر کاربر پنجره را ببندد و اجباری نباشد)
            $parts[8] = json_encode(['msg_active' => 1, 'msg' => $c['message'], 'msg_color' => '#c62828', 'msg_marque' => 1, 'popImg' => ''], JSON_UNESCAPED_UNICODE);
        }
        $xml = '<?xml version="1.0" encoding="UTF-8"?>'."\n<root>";
        foreach ($parts as $p) {
            $xml .= '<data><content><![CDATA['.str_replace(']]>', ']]]]><![CDATA[>', $p).']]></content></data>';
        }
        $xml .= '</root>';

        return response($xml, 200, ['Content-Type' => 'text/xml; charset=utf-8', 'Cache-Control' => 'no-store']);
    }
}
