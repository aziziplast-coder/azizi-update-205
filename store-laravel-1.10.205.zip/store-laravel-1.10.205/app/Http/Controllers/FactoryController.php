<?php

namespace App\Http\Controllers;

use App\Models\Factory;
use App\Models\FactoryAccount;
use App\Models\RemitPayment;
use App\Models\Remittance;
use App\Services\FactoryPortal;
use App\Services\Remit;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/** اپ تحت وب کارخانه‌داران (/factory) */
class FactoryController extends Controller
{
    protected function f(Request $r): Factory
    {
        return $r->attributes->get('factory');
    }

    /* ---------- ورود ---------- */

    public function loginForm(Request $request)
    {
        abort_unless(FactoryPortal::cfg()['enabled'], 404);
        if ($request->session()->get('factory_id')) {
            return redirect()->route('factory.home');
        }

        return view('factory.login', ['mobile' => (string) $request->session()->get('fac_mobile', ''), 'step' => $request->session()->get('fac_step', 'mobile')]);
    }

    public function login(Request $request)
    {
        abort_unless(FactoryPortal::cfg()['enabled'], 404);
        $mobile = mobile($request->input('mobile', $request->session()->get('fac_mobile')));
        if ($request->filled('code')) {
            $f = FactoryPortal::verifyCode($mobile, (string) $request->input('code'));
            if (! $f) {
                return back()->withErrors(['code' => 'کد درست نیست یا منقضی شده است.'])->with(['fac_step' => 'code']);
            }

            return $this->enter($request, $f);
        }
        $res = FactoryPortal::sendCode($mobile, (string) $request->ip());
        $request->session()->put('fac_mobile', $mobile);

        return back()->with(['fac_step' => ! empty($res['code_step']) ? 'code' : 'mobile', $res['ok'] ? 'fac_ok' : 'fac_err' => $res['msg']]);
    }

    public function magic(Request $request, Factory $factory)
    {
        if (! $request->hasValidRelativeSignature() || ! $factory->active || ! hash_equals(substr(sha1($factory->mobile.$factory->created_at), 0, 10), (string) $request->query('h'))) {
            return redirect()->route('factory.login')->with('fac_err', 'لینک ورود معتبر نیست یا منقضی شده است؛ با شماره موبایل وارد شوید.');
        }

        return $this->enter($request, $factory);
    }

    protected function enter(Request $request, Factory $f)
    {
        $request->session()->regenerate();
        $request->session()->put('factory_id', $f->id);
        $request->session()->forget(['fac_mobile', 'fac_step']);
        $f->forceFill(['last_seen_at' => now()])->saveQuietly();

        return redirect()->intended(route('factory.home'));
    }

    public function logout(Request $request)
    {
        $request->session()->forget('factory_id');

        return redirect()->route('factory.login');
    }

    public function manifest()
    {
        $name = FactoryPortal::cfg()['name'];

        return response()->json([
            'id' => '/factory', 'name' => $name.' — '.store_name(), 'short_name' => mb_substr($name, 0, 14), 'lang' => 'fa', 'dir' => 'rtl',
            'start_url' => '/factory?source=pwa', 'scope' => '/factory', 'display' => 'standalone', 'orientation' => 'portrait',
            'background_color' => '#f5f6f8', 'theme_color' => setting('brand_color', '#4f4a63'),
            'icons' => [
                ['src' => route('pwa.factory_icon', 192), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.factory_icon', 512), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.factory_icon', 513), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
            ],
        ], 200, ['Content-Type' => 'application/manifest+json'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /** سرویس‌ورکر اپ کارخانه‌داران (لازم برای نصب؛ بدون ذخیره صفحه‌ها — فقط پیام «اینترنت وصل نیست») */
    public function sw()
    {
        $js = <<<'JS'
self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', function (e) {
  if (e.request.mode !== 'navigate') return;
  e.respondWith(fetch(e.request).catch(function () {
    return new Response('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>اینترنت وصل نیست</title><body style="font-family:Tahoma,sans-serif;text-align:center;padding:60px 20px;color:#333;background:#f5f6f8"><h2>اینترنت وصل نیست</h2><p>بعد از وصل شدن اینترنت، اپ را دوباره باز کنید.</p><button onclick="location.reload()" style="margin-top:12px;padding:12px 26px;border:0;border-radius:12px;background:#4f4a63;color:#fff;font:inherit">تلاش دوباره</button></body></html>', { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
  }));
});
JS;

        return response($js, 200, ['Content-Type' => 'application/javascript; charset=utf-8', 'Service-Worker-Allowed' => '/factory', 'Cache-Control' => 'no-cache']);
    }

    /* ---------- صفحه‌ها ---------- */

    /** «متوجه شدم» شرایط حسابداری (پول برگشتی و حساب جدید) */
    public function terms(Request $r)
    {
        $f = $this->f($r);
        if (\App\Support\DbSchema::hasColumn('factories', 'terms_ack_v')) {
            $f->forceFill(['terms_ack_at' => now(), 'terms_ack_v' => FactoryPortal::termsVersion()])->save();
        }

        return redirect()->back()->with('fac_ok', 'ممنون؛ شرایط حسابداری ثبت شد.');
    }

    public function home(Request $request)
    {
        $f = $this->f($request);
        $rs = FactoryPortal::remittances($f);
        $ids = $rs->pluck('id');
        $stats = $rs->mapWithKeys(fn ($r) => [$r->id => $r->stats()]);
        $wait = FactoryPortal::payments($f)->whereNull('factory_confirmed_at')->with('remittance', 'order:id,number')->oldest('submitted_at')->get();

        return view('factory.home', ['rs' => $rs, 'st' => $stats, 'sum' => FactoryPortal::stats($f), 'wait' => $wait, 'tab' => $request->query('tab', 'todo'),
            'done' => FactoryPortal::payments($f)->whereNotNull('factory_confirmed_at')->with('remittance', 'order:id,number')->latest('factory_confirmed_at')->limit(50)->get()]);
    }

    public function remittance(Request $request, Remittance $remittance)
    {
        $f = $this->f($request);
        abort_unless((int) $remittance->factory_id === (int) $f->id, 404);
        $f->loadMissing('referrer');
        $kids = Remittance::query()->where('parent_id', $remittance->id)->where('factory_id', $f->id)->get();
        $all = collect([$remittance])->merge($kids);
        $pays = RemitPayment::query()->whereIn('remittance_id', $all->pluck('id'))->whereIn('status', ['submitted', 'confirmed'])->whereNotNull('submitted_at')
            ->with('order:id,number', 'remittance:id,code,holder_name')->latest('submitted_at')->get();
        RemitPayment::query()->whereIn('id', $pays->whereNull('factory_seen_at')->pluck('id'))->update(['factory_seen_at' => now()]);

        return view('factory.remittance', ['r' => $remittance, 'kids' => $kids, 'pays' => $pays, 'st' => $remittance->stats(),
            'dests' => $remittance->destinations()->with('child')->orderBy('id')->get(), 'saved' => FactoryAccount::query()->where('factory_id', $f->id)->latest('id')->get(),
            'decide' => FactoryPortal::needsDecision($remittance), 'cfg' => FactoryPortal::cfg()]);
    }

    public function destinations(Request $request, Remittance $remittance)
    {
        try {
            FactoryPortal::submitDestinations($this->f($request), $remittance, (array) $request->input('d', []));
        } catch (ValidationException $e) {
            return back()->withErrors($e->errors())->withInput();
        }

        $remittance->refresh();
        $tr = $remittance->destinations()->where('status', 'transferred')->with('child.factory')->get();
        $msg = $tr->isNotEmpty() ? 'حواله به '.$tr->map(fn ($d) => $d->holder_name)->implode('، ').' منتقل شد و برایش پیامک رفت؛ حساب و تأیید واریزها با خود اوست.' : '';
        if ($remittance->dest_status === 'review') {
            $msg .= ($msg ? ' ' : '').'حساب شما برای تأیید به حسابداری رفت؛ نتیجه پیامک می‌شود.';
        }

        return redirect()->route('factory.remit', $remittance)->with('fac_ok', $msg ?: 'ثبت شد.');
    }

    public function confirm(Request $request, RemitPayment $payment)
    {
        try {
            FactoryPortal::confirmPayment($this->f($request), $payment);
        } catch (ValidationException $e) {
            return back()->withErrors($e->errors());
        }

        return back()->with('fac_ok', money($payment->amount).' تومان — تأیید شد ✓');
    }

    /** کارخانه‌دار: «اشتباه زدم — هنوز ننشسته» (تا ۳ روز پس از تأیید) */
    public function undo(Request $request, RemitPayment $payment)
    {
        $f = $this->f($request);
        abort_unless((int) $payment->remittance?->factory_id === (int) $f->id, 404);
        if (! $payment->factory_confirmed_at || $payment->factory_confirmed_at->lt(now()->subDays(3))) {
            return back()->withErrors(['pay' => 'این تأیید دیگر از اینجا برگشت‌پذیر نیست؛ با حسابداری تماس بگیرید.']);
        }
        try {
            \App\Services\Remit::undoFactory($payment, (string) $request->input('reason', 'کارخانه‌دار: اشتباه تأیید کردم'), null, $f->name);
        } catch (ValidationException $e) {
            return back()->withErrors($e->errors());
        }

        return back()->with('fac_ok', 'تأیید '.money($payment->amount).' تومان برگردانده شد ↩');
    }

    public function confirmMany(Request $request)
    {
        $f = $this->f($request);
        $ids = array_map('intval', (array) $request->input('ids', []));
        $n = 0;
        foreach (FactoryPortal::payments($f)->whereIn('id', $ids)->whereNull('factory_confirmed_at')->get() as $p) {
            FactoryPortal::confirmPayment($f, $p);
            $n++;
        }

        return back()->with('fac_ok', fa($n).' فیش تأیید شد ✓');
    }

    public function receipt(Request $request, RemitPayment $payment)
    {
        abort_unless((int) $payment->remittance?->factory_id === (int) $this->f($request)->id, 404);
        $f = Remit::receiptFile($payment, max(0, (int) $request->query('i', 0)));
        abort_unless($f, 404);

        return response()->file($f, ['Cache-Control' => 'private, max-age=600']);
    }

    public function accounts(Request $request)
    {
        return view('factory.accounts', ['accounts' => FactoryAccount::query()->where('factory_id', $this->f($request)->id)->latest('id')->get()]);
    }

    public function deleteAccount(Request $request, FactoryAccount $account)
    {
        abort_unless((int) $account->factory_id === (int) $this->f($request)->id, 404);
        $account->delete();

        return back()->with('fac_ok', 'حساب حذف شد.');
    }
}
