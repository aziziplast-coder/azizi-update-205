<?php

namespace App\Http\Controllers;

use App\Models\OrderItem;
use App\Models\PickTask;
use App\Models\User;
use App\Models\Warehouse;
use App\Services\Picking;
use App\Support\Slips;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;

/** کارتابل انباردار (اپ PWA موبایل/تبلت در /keeper) */
class KeeperController extends Controller
{
    /* ---------------- ورود ---------------- */

    public function loginForm(Request $request)
    {
        $u = $request->user();
        if ($u && Picking::canUse($u)) {
            return redirect('/keeper');
        }

        return view('keeper.login');
    }

    public function login(Request $request)
    {
        $m = mobile((string) $request->input('mobile'));
        $u = $m ? User::query()->where('mobile', $m)->first() : null;
        if ($lgMsg = \App\Support\LoginGuard::blocked('keeper', $m)) {
            return back()->withErrors(['mobile' => $lgMsg])->withInput();
        }
        if ($u && $u->isPicker() && Picking::paper() && $u->password && Hash::check((string) $request->input('password'), $u->password)) {
            return back()->withErrors(['mobile' => 'جمع‌آوری انبار شما با فاکتور کاغذی است و نیازی به ورود به اپ ندارید؛ فاکتور را از سرپرست بگیرید و بعد از جمع‌آوری به او تحویل دهید.'])->withInput();
        }
        if (! $u || ! $u->password || ! Hash::check((string) $request->input('password'), $u->password) || ! Picking::canUse($u)) {
            \App\Support\LoginGuard::fail('keeper', $m);

            return back()->withErrors(['mobile' => 'موبایل یا رمز عبور درست نیست، یا این حساب به کارتابل انبار دسترسی ندارد.'])->withInput();
        }
        \App\Support\LoginGuard::clear('keeper', $m);
        Auth::login($u, true);
        $request->session()->regenerate();
        $u->forceFill(['last_login_at' => now()])->saveQuietly();

        return redirect('/keeper');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/keeper/login');
    }

    /* ---------------- کارتابل ---------------- */

    public function index(Request $request)
    {
        $u = $request->user();
        if (\App\Services\Walkin::isWalkin($u)) {
            return redirect()->route('walkin'); // بارکدزن فروش حضوری
        }

        if ($u->isSupervisor()) {
            return view('keeper.supervisor', ['user' => $u, 'data' => $this->listData($request) + ['sig' => $this->signature($request)]]);
        }

        return view('keeper.index', [
            'user' => $u,
            'data' => $this->listData($request) + ['sig' => $this->signature($request)],
            'seesAll' => Picking::seesAll($u),
            'keepers' => Picking::seesAll($u) ? Picking::keepers()->map(fn ($k) => ['id' => $k->id, 'name' => $k->displayName()])->values() : collect(),
        ]);
    }

    /**
     * فهرست زنده حواله‌ها. اپ هر چند ثانیه با امضای قبلی (sig) می‌پرسد؛ اگر چیزی عوض نشده باشد
     * فقط {same:true} برمی‌گردد (دو پرس‌وجوی سبک) تا بررسی پیاپی بار هاست را بالا نبرد.
     */
    public function tasks(Request $request)
    {
        $sig = $this->signature($request);
        $headers = ['Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0', 'Pragma' => 'no-cache', 'X-LiteSpeed-Cache-Control' => 'no-cache'];
        if ($sig !== '' && hash_equals($sig, (string) $request->query('sig'))) {
            return response()->json(['same' => true, 'sig' => $sig], 200, $headers);
        }

        return response()->json($this->listData($request) + ['sig' => $sig], 200, $headers);
    }

    protected function signature(Request $request): string
    {
        try {
            $base = Picking::tasksQuery($request->user())->where(fn ($w) => $w->where('status', '!=', 'done')->orWhere('done_at', '>', now()->subDays(3)));
            $t = (clone $base)->toBase()->selectRaw('count(*) as c, max(pick_tasks.id) as i, max(pick_tasks.updated_at) as m, sum(pick_tasks.keeper_id) as k, sum(coalesce(pick_tasks.picker_id, 0)) as pk')->first();
            $ids = (clone $base)->toBase()->select('pick_tasks.id');
            $i = OrderItem::query()->toBase()->whereIn('pick_task_id', $ids)
                ->selectRaw('count(*) as c, count(pick_status) as s, sum(coalesce(picked_units, 0)) as u, sum(pick_task_id) as t, max(picked_at) as p, sum(coalesce(scanned_units, 0) + coalesce(manual_units, 0)) as sc')->first();

            $sh = $request->user()->isSupervisor() || Picking::seesAll($request->user())
                ? $this->shipQuery($request->user())->toBase()->selectRaw('count(*) as c, max(orders.updated_at) as m, max(orders.id) as i')->first() : null;

            $rt = Picking::hasRet() ? PickTask::query()->where('ret_state', 'pending')->selectRaw('count(*) as c, max(updated_at) as m')->first()?->toArray() : null;

            return md5(json_encode([$t, $i, $sh, $rt]));
        } catch (\Throwable) {
            return '';
        }
    }

    protected function listData(Request $request): array
    {
        $u = $request->user();
        try {
            Picking::sweepHolds();
        } catch (\Throwable $e) {
            report($e);
        }
        $q = Picking::tasksQuery($u)->withCount(['items', 'items as checked_count' => fn ($i) => $i->whereNotNull('pick_status'),
            'items as scanned_count' => fn ($i) => $i->whereRaw('coalesce(scanned_units, 0) + coalesce(manual_units, 0) >= coalesce(picked_units, ordered_units, units)')])
            ->where(fn ($w) => $w->where('status', '!=', 'done')->orWhere('done_at', '>', now()->subDays(3)))
            ->orderByRaw("CASE WHEN status = 'done' THEN 1 ELSE 0 END")->orderBy('created_at')->limit(300);
        $rows = $q->get()->filter(fn (PickTask $t) => $t->order && ! in_array($t->order->status, ['cancelled', 'failed'], true));
        // نام انبارهای هر حواله
        $pairs = OrderItem::query()->whereIn('pick_task_id', $rows->pluck('id'))->select('pick_task_id', 'warehouse_id')->distinct()->get();
        $whs = Warehouse::query()->whereIn('id', $pairs->pluck('warehouse_id')->filter()->unique())->get()->keyBy('id');
        $whOf = $pairs->groupBy('pick_task_id')->map(fn ($g) => $g->pluck('warehouse_id')->map(fn ($id) => (int) $id)->unique()
            ->sort(fn ($a, $b) => Slips::whKey($whs[$a] ?? null, $a) <=> Slips::whKey($whs[$b] ?? null, $b))
            ->map(fn ($id) => ($whs[$id] ?? null)?->label() ?? 'بدون انبار')->implode('، '));

        return [
            'now' => now()->toIso8601String(),
            // سفارش لغوشده‌ای که کالایش جمع شده ← کارت قرمز «برگشت به انبار» بالای فهرست
            'ret' => Picking::pendingReturns($u)->map(fn (PickTask $t) => Picking::retCard($t))->values()->all(),
            'tasks' => $rows->map(fn (PickTask $t) => [
                'id' => $t->id,
                'status' => $t->status,
                'isNew' => ! $t->seen_at && $t->status === 'open' && ! $t->started_at,
                'round' => (int) $t->round,
                'order' => fa($t->order->number),
                'name' => $t->order->customer_name,
                'company' => (string) $t->order->company,
                'city' => trim(($t->order->province ? $t->order->province.'، ' : '').$t->order->city),
                'mobile' => $t->order->mobile,
                'mobileFa' => fa($t->order->mobile),
                'items' => (int) $t->items_count,
                'checked' => (int) $t->checked_count,
                'keeper' => $t->keeper?->displayName(),
                'op' => $t->order->assignee?->displayName(), // کارشناس مسئول سفارش (قفری/مهرداد…) — با تغییر مسئول، همین‌جا عوض می‌شود
                'whs' => (string) ($whOf[$t->id] ?? ''),
                'keeperId' => $t->keeper_id,
                'at' => $t->created_at->toIso8601String(),
                'ago' => $t->created_at->diffForHumans(),
                'doneAgo' => $t->done_at?->diffForHumans(),
                'url' => url(($t->stage === 'review' && $u->isSupervisor() ? (Picking::paper() ? '/keeper/paper/' : '/keeper/check/') : '/keeper/task/').$t->id),
                'stage' => $t->stage,
                'picker' => $t->picker?->displayName(),
                'pickerId' => $t->picker_id,
                'bay' => (string) $t->bay,
                'scanned' => (int) $t->scanned_count,
                'checkNote' => (string) $t->check_note,
                'orderDate' => jdate($t->order->created_at).' '.fa($t->order->created_at->setTimezone(config('app.timezone'))->format('H:i')),
                'orderTs' => $t->order->created_at->timestamp,
                'search' => mb_strtolower($t->order->customer_name.' '.$t->order->company.' '.$t->order->number.' '.fa($t->order->number).' '.$t->order->mobile.' '.$t->order->city),
                'pickedAgo' => $t->picked_done_at?->diffForHumans(),
                'assignedAgo' => $t->assigned_at?->diffForHumans(),
                'print' => $u->isSupervisor() ? route('admin.invoice', $t->order_id) : null,
                'verified' => (bool) $t->checked_at, // جدا از «checked» (تعداد قلم تیک‌خورده) که قبلاً با همین نام رونویسی می‌شد
            ])->values()->all(),
            'team' => $u->isSupervisor() ? $this->teamStats($u) : null,
            'paper' => Picking::paper(),
            'ship' => $u->isSupervisor() || Picking::seesAll($u) ? $this->shipList($u) : [],
        ];
    }

    /** سفارش‌های «در صف ارسال به باربری» و ارسال‌شده‌های بدون بیجک (برای سرپرست/مدیر) */
    protected function shipQuery(User $u)
    {
        return \App\Models\Order::query()
            ->where(fn ($w) => $w->where('status', 'to_freight')
                ->orWhere(fn ($x) => $x->where('status', 'shipped')->whereNull('waybill_path')->where(fn ($y) => $y->whereNull('loaded_at')->orWhere('status_changed_at', '>=', now()->subDays(15))))
                // دستی «تکمیل شده» خورده ولی بیجک ندارد ← سرپرست هنوز بتواند بیجکش را بفرستد
                ->orWhere(fn ($x) => \App\Services\Shipping::completedNoWaybill($x->whereNull('waybill_path')->when(\App\Services\Shipping::hasDirect(), fn ($d) => $d->whereNull('direct_at')))))
            ->when(! Picking::seesAll($u), fn ($q) => $q->whereHas('pickTasks', fn ($t) => $t->where('keeper_id', $u->id)));
    }

    protected function shipList(User $u): array
    {
        $rows = $this->shipQuery($u)->with(['pickTasks' => fn ($q) => $q->select('id', 'order_id', 'bay', 'round')->orderByDesc('round')])
            ->withCount('items')->orderBy('status_changed_at')->limit(200)->get();

        return $rows->map(function (\App\Models\Order $o) {
            $dl = \App\Services\Shipping::deadline($o);

            return [
                'id' => $o->id,
                'order' => fa($o->number),
                'name' => $o->customer_name,
                'city' => trim(($o->province ? $o->province.'، ' : '').$o->city),
                'mobile' => $o->mobile,
                'freight' => (string) $o->freight_name,
                'isFreight' => \App\Services\Shipping::isFreight($o),
                'fee' => (int) $o->freight_fee,
                'feeFa' => $o->freight_fee ? money($o->freight_fee) : '',
                'bay' => (string) ($o->pickTasks->pluck('bay')->filter()->unique()->implode('، ')),
                'items' => (int) $o->items_count,
                // «در حال ارسال به باربری» و هنوز بارگیری نشده = آماده بارگیری (سربرگ «آماده ارسال»)
                'status' => $o->status === 'to_freight' || ($o->status === 'shipped' && ! $o->loaded_at) ? 'to_freight' : 'shipped', // تکمیل‌شده بی‌بیجک = منتظر بیجک
                'since' => $o->status_changed_at?->diffForHumans(),
                'loaded' => $o->loaded_at ? jdate($o->loaded_at, true) : null,
                'waybill' => (bool) $o->waybill_path,
                'late' => $o->loaded_at && $o->status !== 'to_freight' && $dl && $dl->isPast(),
                'left' => $o->loaded_at && $o->status !== 'to_freight' && $dl && ! $dl->isPast() ? fa((int) now()->diffInHours($dl)).' ساعت' : null,
                'search' => mb_strtolower($o->customer_name.' '.$o->number.' '.fa($o->number).' '.$o->mobile.' '.$o->city.' '.$o->freight_name),
            ];
        })->values()->all();
    }

    protected function shipOrder(Request $request, \App\Models\Order $order): void
    {
        $u = $request->user();
        abort_unless(Picking::seesAll($u) || ($u->isSupervisor() && $order->pickTasks()->where('keeper_id', $u->id)->exists()), 403);
    }

    /** بارگیری و تحویل به باربری (اختیاری با کرایه حمل) */
    public function shipLoaded(Request $request, \App\Models\Order $order)
    {
        $this->shipOrder($request, $order);
        try {
            $fee = $request->filled('fee') ? (int) to_int($request->input('fee')) : null;
            \App\Services\Shipping::markLoaded($order, $request->user(), $fee);
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true]);
    }

    /** عکس بیجک از اپ انبار */
    public function shipWaybill(Request $request, \App\Models\Order $order)
    {
        $this->shipOrder($request, $order);
        $request->validate(['file' => 'required|file|mimes:jpg,jpeg,png,webp,heic,pdf|max:12288'], ['file.*' => 'عکس یا PDF بیجک (حداکثر ۱۲ مگابایت) لازم است.']);
        \App\Services\Shipping::uploadWaybill($order, $request->file('file'), $request->user());

        return response()->json(['ok' => true]);
    }

    /** کرایه حمل (بعداً) */
    public function shipFee(Request $request, \App\Models\Order $order)
    {
        $this->shipOrder($request, $order);
        \App\Services\Shipping::setFreightFee($order, (int) to_int($request->input('fee')), $request->user());

        return response()->json(['ok' => true, 'fee' => (int) $order->fresh()->freight_fee]);
    }

    /** آمار جمع‌کننده‌های سرپرست (به‌علاوه خودش) */
    protected function teamStats(User $sup): array
    {
        $team = $sup->pickers()->get()->prepend($sup);
        $ids = $team->pluck('id')->all();
        $today = now()->startOfDay();
        $week = now()->subDays(6)->startOfDay();
        $open = PickTask::query()->whereIn('picker_id', $ids)->where('keeper_id', $sup->id)->where('status', '!=', 'done')
            ->selectRaw('picker_id, stage, count(*) as n')->groupBy('picker_id', 'stage')->get();
        $doneQ = fn ($from) => PickTask::query()->whereIn('picker_id', $ids)->where('keeper_id', $sup->id)->whereNotNull('picked_done_at')->where('picked_done_at', '>=', $from)
            ->selectRaw('picker_id, count(*) as n')->groupBy('picker_id')->pluck('n', 'picker_id')->all();
        $d1 = $doneQ($today);
        $d7 = $doneQ($week);

        return $team->map(fn (User $p) => [
            'id' => $p->id,
            'name' => $p->displayName(),
            'self' => (int) $p->id === (int) $sup->id,
            'picking' => (int) $open->where('picker_id', $p->id)->where('stage', 'picking')->sum('n'),
            'review' => (int) $open->where('picker_id', $p->id)->where('stage', 'review')->sum('n'),
            'today' => (int) ($d1[$p->id] ?? 0),
            'week' => (int) ($d7[$p->id] ?? 0),
        ])->values()->all();
    }

    protected function supTask(Request $request, PickTask $task): void
    {
        $u = $request->user();
        abort_unless(Picking::seesAll($u) || ($u->isSupervisor() && (int) $task->keeper_id === (int) $u->id), 403);
    }

    public function assign(Request $request, PickTask $task, Picking $picking)
    {
        $this->supTask($request, $task);
        $to = $request->input('picker') === 'me' ? (int) ($task->keeper_id ?: $request->user()->id) : (int) $request->input('picker');
        try {
            $picking->assign($task, $to, $request->user());
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true, 'picker' => $task->fresh('picker')->picker?->displayName()]);
    }

    public function autoAssign(Request $request, Picking $picking)
    {
        $u = $request->user();
        abort_unless($u->isSupervisor(), 403);
        try {
            $n = $picking->autoAssign($u);
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true, 'n' => $n]);
    }

    /** صفحه بررسی بار با بارکدخوان */
    public function check(Request $request, PickTask $task)
    {
        $this->supTask($request, $task);
        if ($task->stage !== 'review') {
            return redirect('/keeper/task/'.$task->id);
        }
        if (Picking::paper() && $task->picker_id) {
            return redirect('/keeper/paper/'.$task->id);
        }

        return view('keeper.check', ['task' => $task, 'order' => $task->order()->firstOrFail(), 'state' => $this->checkState($task)]);
    }

    protected function checkState(PickTask $task): array
    {
        $task->refresh();
        $items = $task->items()->with(['warehouse', 'product:id,sku,barcode,image,sync_code'])->get();
        $metas = Warehouse::query()->whereIn('id', $items->pluck('warehouse_id')->filter()->unique())->get()->keyBy('id');
        $picking = app(Picking::class);

        $order = $task->order;

        return [
            'id' => $task->id,
            'freight' => $order && \App\Services\Shipping::isFreight($order),
            'freightName' => (string) $order?->freight_name,
            'fee' => (int) $order?->freight_fee,
            'stage' => $task->stage,
            'done' => $task->isDone(),
            'items' => Slips::sortItems($items, $metas)->map(fn (OrderItem $i) => [
                'id' => $i->id,
                'name' => $i->name,
                'img' => $i->image ? thumb($i->image, 160) : null,
                'codes' => Picking::itemCodes($i),
                'code' => (string) ($i->barcode ?: $i->product?->sku),
                'step' => Picking::scanStep($i),
                'unit' => Picking::scanStep($i) > 1 ? 'کارتن' : 'عدد',
                'per' => (int) $i->per_carton,
                'want' => $i->orderedUnits(),
                'cap' => $i->pickCap(),
                'target' => $picking->target($i),
                'scanned' => (int) $i->scanned_units,
                'manual' => (int) $i->manual_units,
                'status' => $i->pick_status,
                'note' => (string) $i->pick_note,
            ])->values()->all(),
        ];
    }

    public function checkStateJson(Request $request, PickTask $task)
    {
        $this->supTask($request, $task);

        return response()->json($this->checkState($task));
    }

    public function scan(Request $request, PickTask $task, Picking $picking)
    {
        $this->supTask($request, $task);
        $code = (string) $request->input('code', '');
        try {
            $r = $picking->scan($task, $code);
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true, 'type' => $r['type'], 'name' => $r['name'], 'itemId' => $r['item']?->id, 'scanned' => $r['item'] ? (int) $r['item']->scanned_units : null,
            'manual' => $r['item'] ? (int) $r['item']->manual_units : null]);
    }

    public function adjust(Request $request, PickTask $task, OrderItem $item, Picking $picking)
    {
        $this->supTask($request, $task);
        try {
            $item = $request->has('manual')
                ? $picking->manualCheck($task, $item, (int) en_digits((string) $request->input('manual')))
                : $picking->adjustScan($task, $item, $request->integer('delta') >= 0 ? 1 : -1);
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true, 'scanned' => (int) $item->scanned_units, 'manual' => (int) $item->manual_units]);
    }

    public function approve(Request $request, PickTask $task, Picking $picking)
    {
        $this->supTask($request, $task);
        try {
            $mode = in_array($request->input('mode'), ['picker', 'paper'], true) ? (string) $request->input('mode') : 'scanned';
            $all = $picking->approve($task, $request->user(), $mode, $request->has('bay') ? (string) $request->input('bay') : null);
            if ($request->filled('fee')) {
                \App\Services\Shipping::setFreightFee($task->order()->firstOrFail(), (int) to_int($request->input('fee')), $request->user());
            }
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true, 'all' => $all]);
    }

    /* ---------------- روال کاغذی (انبارهای سرپرست‌دار) ---------------- */

    /** «تحویل گرفتم»: فاکتور کاغذی از جمع‌کننده برگشت ← شروع بررسی */
    public function received(Request $request, PickTask $task, Picking $picking)
    {
        $this->supTask($request, $task);
        try {
            $picking->received($task, $request->user());
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true, 'url' => url('/keeper/paper/'.$task->id)]);
    }

    /** «تحویل گرفتم» با تایپ/اسکن شماره فاکتور */
    public function receiveByNumber(Request $request, Picking $picking)
    {
        $u = $request->user();
        abort_unless($u->isSupervisor() || Picking::seesAll($u), 403);
        $task = Picking::findForSupervisor($u, (string) $request->input('number'));
        if (! $task) {
            return response()->json(['ok' => false, 'msg' => 'فاکتوری با این شماره در کارتابل شما باز نیست.'], 404);
        }
        if ($task->stage === 'new') {
            return response()->json(['ok' => false, 'new' => $task->id, 'msg' => 'فاکتور '.fa($task->order->number).' هنوز به جمع‌کننده‌ای داده نشده؛ اول بگویید دست چه کسی بوده.'], 422);
        }
        try {
            $picking->received($task, $u);
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true, 'url' => url('/keeper/paper/'.$task->id)]);
    }

    /** صفحه بررسی فاکتور کاغذی: فقط اقلامی که تغییر دارند ثبت می‌شوند */
    public function paper(Request $request, PickTask $task)
    {
        $this->supTask($request, $task);
        if ($task->stage !== 'review') {
            return redirect('/keeper/task/'.$task->id);
        }

        return view('keeper.paper', ['task' => $task, 'order' => $task->order()->firstOrFail(), 'state' => $this->paperState($task)]);
    }

    protected function paperState(PickTask $task): array
    {
        $st = $this->taskState($task);
        $order = $task->order;

        return $st + [
            'freight' => $order && \App\Services\Shipping::isFreight($order),
            'freightName' => (string) $order?->freight_name,
            'fee' => (int) $order?->freight_fee,
            'order' => fa((string) $order?->number),
        ];
    }

    public function paperMark(Request $request, PickTask $task, OrderItem $item, Picking $picking)
    {
        $this->supTask($request, $task);
        if ($task->stage !== 'review' || $task->isDone()) {
            return response()->json(['ok' => false, 'msg' => 'این فاکتور در مرحله بررسی نیست.'], 422);
        }
        $data = $request->validate(['action' => 'required|in:ok,missing,qty,reset', 'units' => 'nullable|integer|min:0', 'note' => 'nullable|string|max:190']);
        $item = $picking->mark($task, $item, $data['action'], $data['units'] ?? null, $request->has('note') ? (string) $request->input('note') : null);

        return response()->json(['ok' => true, 'item' => $this->itemData($item->fresh(['warehouse', 'product']))]);
    }

    public function sendBack(Request $request, PickTask $task, Picking $picking)
    {
        $this->supTask($request, $task);
        try {
            $picking->sendBack($task, (string) $request->input('note'));
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true]);
    }

    /** سفارش لغو شد: «کالاها به انبار برگشت» (سرپرست/انباردار صاحب حواله یا جمع‌کننده) */
    public function returned(Request $request, PickTask $task, Picking $picking)
    {
        abort_unless(Picking::canAccess($request->user(), $task), 403);
        try {
            $picking->returned($task, $request->user());
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true]);
    }

    public function show(Request $request, PickTask $task)
    {
        $u = $request->user();
        abort_unless(Picking::canAccess($u, $task), 403);
        $order = $task->order()->firstOrFail();
        if ($task->stage === 'review' && $u->isSupervisor() && (int) $task->keeper_id === (int) $u->id) {
            return redirect((Picking::paper() ? '/keeper/paper/' : '/keeper/check/').$task->id);
        }
        $mine = $task->stage !== null ? (int) $task->picker_id === (int) $u->id : (int) $task->keeper_id === (int) $u->id;
        if (! $task->seen_at && $mine) {
            $task->forceFill(['seen_at' => now()])->save();
        }

        return view('keeper.task', [
            'task' => $task,
            'order' => $order,
            'state' => $this->taskState($task),
            'keepers' => Picking::keepers()->reject(fn ($k) => (int) $k->id === (int) $task->keeper_id)
                ->map(fn ($k) => ['id' => $k->id, 'name' => $k->displayName(), 'wh' => $k->warehouses()->get()->sortBy(fn ($w) => Slips::whKey($w, $w->id))->map->label()->implode('، ')])->values(),
        ]);
    }

    /** وضعیت کامل حواله برای صفحه جمع‌آوری */
    protected function taskState(PickTask $task): array
    {
        $task->refresh();
        $items = $task->items()->with(['warehouse', 'product:id,sku,barcode,image'])->get();
        $metas = Warehouse::query()->whereIn('id', $items->pluck('warehouse_id')->filter()->unique())->get()->keyBy('id');
        $items = Slips::sortItems($items, $metas);

        return [
            'id' => $task->id,
            'status' => $task->status,
            'round' => (int) $task->round,
            'stage' => $task->stage,
            'readOnly' => ! Picking::canPick(request()->user(), $task),
            'needBay' => $task->stage !== null,
            'bay' => (string) $task->bay,
            'checkNote' => (string) $task->check_note,
            'picker' => $task->picker?->displayName(),
            'items' => $items->map(fn (OrderItem $i) => $this->itemData($i))->values()->all(),
            // منتقل‌شده‌ها: با «پایان حواله» یکجا برای مقصد می‌روند
            'held' => Picking::heldFrom($task)->map(fn (PickTask $h) => ['to' => $h->keeper?->displayName(), 'n' => (int) $h->items_count,
                'names' => OrderItem::query()->where('pick_task_id', $h->id)->pluck('name')->all()])->values()->all(),
        ];
    }

    protected function itemData(OrderItem $i): array
    {
        $want = $i->orderedUnits();
        $carton = ! $i->isRetail() && $i->per_carton > 1;

        return [
            'id' => $i->id,
            'name' => $i->name,
            'img' => $i->image ? thumb($i->image, 160) : null,
            'codes' => array_values(array_filter(array_unique([(string) $i->barcode, (string) $i->product?->barcode, (string) $i->product?->sku]))),
            'code' => (string) ($i->barcode ?: $i->product?->sku),
            'wh' => $i->warehouse?->label() ?? 'بدون انبار',
            'whId' => (int) $i->warehouse_id,
            'mode' => $i->isRetail() ? 'retail' : ($carton ? 'carton' : 'unit'),
            'per' => max(1, (int) $i->per_carton),
            'want' => $want,
            'max' => $i->overCap(), // جمع بیشتر از سفارش (مثلاً کارتن کامل)
            'wantLabel' => $carton ? fa(intdiv($want, $i->per_carton)).' کارتن '.fa($i->per_carton).'تایی'.($want % $i->per_carton ? ' و '.fa($want % $i->per_carton).' عدد' : '') : fa($want).' عدد',
            'wantUnits' => fa($want).' عدد',
            'picked' => $i->picked_units,
            'pickedLabel' => $i->picked_units !== null ? $i->unitsLabel((int) $i->picked_units) : null,
            'status' => $i->pick_status,
            'note' => (string) $i->pick_note,
            'replaces' => (bool) $i->replaces_item_id,
        ];
    }

    public function mark(Request $request, PickTask $task, OrderItem $item, Picking $picking)
    {
        abort_unless(Picking::canAccess($request->user(), $task), 403);
        if (! Picking::canPick($request->user(), $task)) {
            return response()->json(['ok' => false, 'msg' => 'این فاکتور فقط قابل مشاهده است (دست جمع‌کننده یا در بررسی).'], 422);
        }
        $data = $request->validate(['action' => 'required|in:ok,missing,qty,reset', 'units' => 'nullable|integer|min:0', 'note' => 'nullable|string|max:190']);
        try {
            $item = $picking->mark($task, $item, $data['action'], $data['units'] ?? null, $request->has('note') ? (string) $request->input('note') : null);
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true, 'item' => $this->itemData($item->fresh(['warehouse', 'product']))]);
    }

    public function move(Request $request, PickTask $task, OrderItem $item, Picking $picking)
    {
        abort_unless(Picking::canAccess($request->user(), $task), 403);
        if (! Picking::canPick($request->user(), $task)) {
            return response()->json(['ok' => false, 'msg' => 'این فاکتور فقط قابل مشاهده است.'], 422);
        }
        $data = $request->validate(['keeper' => 'required|integer']);
        try {
            $dest = $picking->move($task, $item, (int) $data['keeper']);
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'msg' => collect($e->errors())->flatten()->first()], 422);
        }

        return response()->json(['ok' => true, 'to' => $dest->keeper?->displayName(), 'held' => $dest->stage === 'hold', 'gone' => ! PickTask::query()->whereKey($task->id)->exists()]);
    }

    /** مدیر: تقسیم دوباره حواله‌های باز این سفارش بین انباردارها */
    public function resplit(Request $request, PickTask $task, Picking $picking)
    {
        abort_unless(Picking::seesAll($request->user()), 403);
        try {
            $n = $picking->resplit($task->order);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return back()->with('kp_msg', collect($e->errors())->flatten()->first());
        }
        $request->session()->flash('kp_msg', 'حواله‌ها بین انباردارها تقسیم شد — '.fa($n).' حواله.');

        return PickTask::query()->whereKey($task->id)->exists() ? redirect()->route('keeper.task', $task) : redirect()->route('keeper');
    }

    public function save(Request $request, PickTask $task, Picking $picking)
    {
        abort_unless(Picking::canAccess($request->user(), $task), 403);
        $picking->save($task);

        return response()->json(['ok' => true]);
    }

    public function done(Request $request, PickTask $task, Picking $picking)
    {
        abort_unless(Picking::canAccess($request->user(), $task), 403);
        try {
            if (! Picking::canPick($request->user(), $task)) {
                throw ValidationException::withMessages(['task' => 'این فاکتور فقط قابل مشاهده است.']);
            }
            $all = $picking->complete($task, $request->boolean('missing'), $request->has('bay') ? (string) $request->input('bay') : null);
        } catch (ValidationException $e) {
            $errs = $e->errors();

            return response()->json(['ok' => false, 'left' => isset($errs['left']), 'bay' => isset($errs['bay']), 'msg' => collect($errs)->flatten()->first()], 422);
        }

        $stage = $task->fresh()?->stage ?? 'desk'; // حواله ادغام‌شده در بررسی سالن (حذف شده)

        return response()->json(['ok' => true, 'all' => $all, 'review' => $stage === 'review', 'desk' => $stage === 'desk']);
    }

    public function state(Request $request, PickTask $task)
    {
        abort_unless(Picking::canAccess($request->user(), $task), 403);

        return response()->json($this->taskState($task));
    }

    /* ---------------- PWA ---------------- */

    public function manifest()
    {
        $name = setting('keeper_app_name') ?: 'کارتابل انبار '.store_name();

        return response()->json([
            'id' => '/keeper',
            'name' => $name,
            'short_name' => mb_substr(setting('keeper_app_name') ?: 'کارتابل انبار', 0, 14),
            'lang' => 'fa',
            'dir' => 'rtl',
            'start_url' => '/keeper?source=pwa',
            'scope' => '/keeper',
            'display' => 'standalone',
            'orientation' => 'portrait',
            'background_color' => '#f4f5f7',
            'theme_color' => setting('brand_color', '#4f4a63'),
            'icons' => [
                ['src' => route('pwa.icon', 192), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.icon', 512), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.icon', 513), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
            ],
        ], 200, ['Content-Type' => 'application/manifest+json', 'Cache-Control' => 'public, max-age=3600'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
