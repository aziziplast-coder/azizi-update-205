<?php

namespace App\Http\Controllers;

use App\Http\Middleware\StoreOpen;
use App\Models\Order;
use App\Services\Cart;
use App\Services\Checkout;
use App\Services\Cheques;
use App\Services\Payment;
use App\Support\Provinces;
use Illuminate\Http\Request;
use RuntimeException;

class CheckoutController extends Controller
{
    public function show(Request $request, Cart $cart)
    {
        if ($cart->isEmpty() || ! StoreOpen::canOrder()) {
            return redirect()->route('cart');
        }
        if ($cart->record()?->edit_order_id) {
            return redirect()->route('cart');
        }
        if ($blk = Checkout::openBlock($request->user())) {
            return redirect()->route('cart')->with('err', Checkout::openBlockMsg($blk));
        }
        $ships = Checkout::shippingMethods();
        $pays = Checkout::paymentMethods();
        $ship = old('shipping', array_key_first($ships));
        $user = $request->user();
        $itemsTotal = $cart->itemsTotal();
        $chequeAv = isset($pays['cheque']) ? Cheques::availability($user, $itemsTotal) : null;
        $first = array_key_first(array_filter($pays, fn ($p) => $p['id'] !== 'cheque' || ($chequeAv['ok'] ?? false)));
        $cart->track('checkout', ['name' => $user->name, 'mobile' => $user->mobile]);
        $totals = $cart->totals($ship);

        return view('store.checkout', [
            'user' => $user,
            'lines' => $cart->lines(),
            'totals' => $totals,
            'ships' => $ships,
            'pays' => $pays,
            'ship' => $ship,
            'pay' => old('payment', $first),
            'provinces' => Provinces::all(),
            'itemsTotal' => $itemsTotal,
            'cheque' => $chequeAv ? [
                'av' => $chequeAv,
                'cfg' => Cheques::config(),
                'plans' => Cheques::plans(),
                'docs' => Cheques::needsDocs($user) ? Cheques::config()['docs'] : 'none',
                'review' => Cheques::needsReview($user),
            ] : null,
            'messenger' => (array) setting('messenger', []),
        ]);
    }

    /** ثبت مرحله‌ای که مشتری در صفحه تسویه به آن رسیده (برای سبدهای رها شده) */
    public function track(Request $request, Cart $cart)
    {
        $stage = (string) $request->input('stage', 'info');
        if (! in_array($stage, ['info', 'shipping', 'payment'], true)) {
            $stage = 'info';
        }
        $info = array_map(fn ($v) => is_string($v) ? mb_substr(trim($v), 0, 200) : null, $request->only(['name', 'city', 'province', 'shipping', 'payment', 'company']));
        $ships = Checkout::shippingMethods();
        $pays = Checkout::paymentMethods();
        if (! empty($info['shipping'])) {
            $info['shipping'] = $ships[$info['shipping']]['title'] ?? null;
        }
        if (! empty($info['payment'])) {
            $info['payment'] = $pays[$info['payment']]['title'] ?? null;
        }
        $cart->track($stage, $info);

        return response()->json(['ok' => true]);
    }

    /** محاسبه طرح چکی برای نمایش زنده */
    public function chequePlan(Request $request, Cart $cart)
    {
        $plans = Cheques::plans();
        $plan = $plans[(int) $request->query('plan', -1)] ?? null;
        if (! $plan) {
            return response()->json(['ok' => false]);
        }
        $t = $cart->totals($request->query('shipping'));
        $s = Cheques::schedule($plan, (int) $t['total']);
        if (! Cheques::config()['show_calc'] || $s['cash'] === null) {
            return response()->json(['ok' => false]);
        }

        return response()->json([
            'ok' => true,
            'cash' => money($s['cash']),
            'cheques' => array_map(fn ($c) => ['amount' => money($c['amount']), 'due' => $c['due_fa']], $s['cheques']),
            'guarantee' => $s['guarantee'] ? money($s['guarantee']) : null,
            'desc' => $plan['desc'],
        ]);
    }

    public function summary(Request $request, Cart $cart)
    {
        $t = $cart->totals($request->query('shipping'));

        return response()->json([
            'freight' => ! empty($t['shipping']['freight']),
            'shipping' => $t['shipping_label'],
            'shippingTitle' => $t['shipping']['title'] ?? '',
            'total' => money($t['total']),
        ]);
    }

    public function place(Request $request, Cart $cart, Checkout $checkout)
    {
        if (! StoreOpen::canOrder()) {
            return redirect()->route('cart');
        }
        $order = $checkout->placeFromRequest($request, $cart);
        if ($order->payment_method === 'gateway') {
            return redirect()->route('payment.start', $order->number);
        }

        return redirect()->route('order.show', $order->number)->with('placed', true);
    }

    public function pay(Request $request, string $number, Payment $payment)
    {
        $order = Order::query()->where('number', $number)->where('user_id', $request->user()->id)->firstOrFail();
        if ($order->isPaid() || $order->status !== 'pending_payment') {
            return redirect()->route('order.show', $order->number);
        }
        try {
            return redirect()->away($payment->start($order));
        } catch (RuntimeException $e) {
            return redirect()->route('order.show', $order->number)->withErrors(['pay' => $e->getMessage()]);
        }
    }

    public function callback(Request $request, string $number, Payment $payment, Checkout $checkout)
    {
        $order = Order::query()->where('number', $number)->firstOrFail();
        if (! $order->isPaid() && $order->status === 'pending_payment') {
            $res = $payment->verify($order, $request->query());
            if ($res['ok']) {
                $checkout->markPaid($order, $res['ref'], (array) $order->payment_meta + ['ref' => $res['ref']]);

                return redirect()->route('order.show', $order->number)->with('placed', true);
            }
            $order->log('پرداخت ناموفق: '.$res['msg'], $order->user_id);

            return redirect()->route('order.show', $order->number)->withErrors(['pay' => $res['msg']]);
        }

        return redirect()->route('order.show', $order->number);
    }
}
