<?php

namespace App\Http\Controllers;

use App\Support\AziziFeed;
use Throwable;

/** خروجی هم‌شکل سایت قبلی عزیزی‌پلاست برای ربات‌های کانال */
class AziziFeedController extends Controller
{
    public function products(\Illuminate\Http\Request $request)
    {
        if (! AziziFeed::config()['enabled']) {
            return response()->json(['success' => false, 'products' => [], 'total' => 0], 404);
        }
        try {
            $f = AziziFeed::ready();
        } catch (Throwable $e) {
            report($e);
            $f = AziziFeed::file();
            if (! is_file($f)) {
                return response()->json(['success' => false, 'products' => [], 'total' => 0], 503);
            }
        }

        // صفحه‌بندی: ?p=1 (یا ?page=1) = ۱۰۰ کالا در هر صفحه؛ بدون p مثل سایت قبلی همه کالاها
        $p = $request->query('p', $request->query('page'));
        if ($p !== null && $p !== '') {
            $n = max(1, (int) en_digits((string) $p));
            $f = AziziFeed::page($n);
            if (! $f) {
                $total = 0;
                if (preg_match('/"total":(\d+)\}$/', (string) @file_get_contents(AziziFeed::file(), false, null, max(0, (int) @filesize(AziziFeed::file()) - 40)), $m)) {
                    $total = (int) $m[1];
                }

                return response()->json(['success' => true, 'products' => [], 'total' => $total, 'page' => $n, 'pages' => (int) ceil($total / AziziFeed::PER_PAGE), 'per_page' => AziziFeed::PER_PAGE], 200, ['Access-Control-Allow-Origin' => '*', 'X-Store-Self-Feed' => '1']);
            }
        }
        $headers = [
            'Content-Type' => 'application/json; charset=utf-8',
            'Access-Control-Allow-Origin' => '*',
            'Cache-Control' => 'no-cache',
            'X-Store-Self-Feed' => '1',
            'Vary' => 'Accept-Encoding',
        ];
        // نسخه gzip آماده (بدون فشرده‌سازی در هر درخواست)
        if (str_contains((string) $request->header('Accept-Encoding'), 'gzip') && is_file($f.'.gz') && filemtime($f.'.gz') >= filemtime($f) - 5) {
            return response()->file($f.'.gz', $headers + ['Content-Encoding' => 'gzip']);
        }

        return response()->file($f, $headers);
    }

    /** تصویرهای سایت قبلی (/Opitures/sm123.jpg و …) */
    public function image(string $path)
    {
        $f = AziziFeed::image($path);
        abort_unless($f, 404);

        return response()->file($f, ['Cache-Control' => 'public, max-age=604800']);
    }
}
