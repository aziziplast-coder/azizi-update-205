<?php

namespace App\Http\Controllers;

use App\Models\PurchaseOrder;
use App\Models\Supplier;
use App\Models\User;
use App\Services\Purchasing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use RuntimeException;

/** اپ PWA مسئول خرید (/buyer): کالاهای ناموجود هر کارخانه، تعیین کارتن، گزارش و سفارش خرید */
class BuyerController extends Controller
{
    protected const NOCACHE = ['Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0', 'Pragma' => 'no-cache', 'X-LiteSpeed-Cache-Control' => 'no-cache'];

    /* ---------------- ورود ---------------- */

    public function loginForm(Request $request)
    {
        if (Purchasing::canUse($request->user())) {
            return redirect('/buyer');
        }

        return view('buyer.login', ['cfg' => Purchasing::cfg()]);
    }

    public function login(Request $request)
    {
        $m = mobile((string) $request->input('mobile'));
        $u = $m ? User::query()->where('mobile', $m)->first() : null;
        if ($lgMsg = \App\Support\LoginGuard::blocked('buyer', $m)) {
            return back()->withErrors(['mobile' => $lgMsg])->withInput();
        }
        if (! $u || ! $u->password || ! Hash::check((string) $request->input('password'), $u->password) || ! Purchasing::canUse($u)) {
            \App\Support\LoginGuard::fail('buyer', $m);

            return back()->withErrors(['mobile' => 'موبایل یا رمز عبور درست نیست، یا این حساب دسترسی «خرید و تأمین» ندارد.'])->withInput();
        }
        \App\Support\LoginGuard::clear('buyer', $m);
        Auth::login($u, true);
        $request->session()->regenerate();
        $u->forceFill(['last_login_at' => now()])->saveQuietly();

        return redirect('/buyer');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/buyer/login');
    }

    public function manifest()
    {
        $name = Purchasing::cfg()['app_name'];

        return response()->json([
            'id' => '/buyer', 'name' => $name.' '.store_name(), 'short_name' => mb_substr($name, 0, 14),
            'lang' => 'fa', 'dir' => 'rtl', 'start_url' => '/buyer?source=pwa', 'scope' => '/buyer',
            'display' => 'standalone', 'orientation' => 'any', 'background_color' => '#f2f3f6', 'theme_color' => setting('brand_color', '#4f4a63'),
            'icons' => [
                ['src' => route('pwa.buyer_icon', 192), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.buyer_icon', 512), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => route('pwa.buyer_icon', 513), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
            ],
        ], 200, ['Content-Type' => 'application/manifest+json', 'Cache-Control' => 'public, max-age=3600'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /* ---------------- اپ ---------------- */

    public function index(Request $request)
    {
        $u = $request->user();
        $cfg = Purchasing::cfg();

        return view('buyer.app', ['cfg' => $cfg, 'bodyClass' => 'by-app'.($request->boolean('embed') ? ' by-embed' : ''), 'kp' => [
            'user' => $u->displayName(), 'me' => $u->id, 'admin' => $u->isStaffLike(), 'store' => $cfg['report_name'], 'brand' => setting('brand_color', '#4f4a63'),
            'logo' => $cfg['report_logo'] ? route('pwa.icon', 192) : '', 'images' => $cfg['report_images'], 'total' => $cfg['report_total'], 'icon' => route('pwa.buyer_icon', 192), 'phone' => $cfg['report_phone'], 'note' => $cfg['report_note'],
            'low' => $cfg['low'], 'app' => $cfg['app_name'], 'rules' => $cfg['unload_rules'], 'unit' => $cfg['price_unit'],
            'panel' => $u->hasPerm('purchasing') ? url('/admin') : null, 'embed' => $request->boolean('embed'),
        ]]);
    }

    public function data(Request $request)
    {
        // بعد از ارسال پاسخ: چند تصویر دیگر در پس‌زمینه آماده شود (قفل دارد؛ هم‌زمان اجرا نمی‌شود)
        app()->terminating(fn () => \App\Services\BuyerImages::warm(15, 40));
        $ds = Purchasing::dataset($request->boolean('na'));
        if ($request->query('v') && hash_equals($ds['v'], (string) $request->query('v'))) {
            return response()->json(['same' => true], 200, self::NOCACHE);
        }

        return response()->json($ds, 200, self::NOCACHE, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function state(Request $request)
    {
        $sig = Purchasing::stateSig();
        if (hash_equals($sig, (string) $request->query('sig'))) {
            return response()->json(['same' => true, 'sig' => $sig], 200, self::NOCACHE);
        }

        return response()->json(Purchasing::state(), 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** بررسی کالای خریده‌شده‌ای که در اسکن انبار نیامد */
    public function arrived(Request $request)
    {
        try {
            Purchasing::resolveArrival((string) $request->input('k'), (string) $request->input('r'), $request->user());
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }

        return response()->json(['ok' => true]);
    }

    public function mark(Request $request)
    {
        $out = [];
        $list = $request->input('marks');
        if (! is_array($list)) {
            $list = [$request->only(['k', 'cartons', 'excluded', 'note'])];
        }
        foreach (array_slice($list, 0, 500) as $m) {
            $k = (string) ($m['k'] ?? '');
            if ($k === '') {
                continue;
            }
            try {
                $out[$k] = Purchasing::mark($k, array_intersect_key($m, array_flip(['cartons', 'excluded', 'note'])), $request->user());
            } catch (RuntimeException) {
                // کالایی که با ورود اکسل تازه حذف شده است
            }
        }

        return response()->json(['ok' => true, 'marks' => (object) $out, 'sig' => Purchasing::stateSig()]);
    }

    /** تصویر کوچک کالا (اولین بار ساخته می‌شود؛ بعد از آن فایل ثابت مستقیم داده می‌شود) */
    public function img(string $key)
    {
        abort_unless(preg_match('/^[ps]\d+$/', $key), 404);
        @set_time_limit(60);
        abort_unless(\App\Services\BuyerImages::make($key), 404);

        return response()->file(\App\Services\BuyerImages::path($key), ['Content-Type' => 'image/jpeg', 'Cache-Control' => 'no-store']);
    }

    /** کلیدهای سریع گزارش: تصویر کالا و جمع کل در گزارش کارخانه */
    public function opt(Request $request)
    {
        $set = [];
        foreach (['images' => 'buy_report_images', 'total' => 'buy_report_total'] as $in => $key) {
            if ($request->has($in)) {
                $set[$key] = $request->boolean($in);
            }
        }
        if ($set) {
            \App\Support\Settings::set($set);
        }

        return response()->json(['ok' => true]);
    }

    /** قوانین تخلیه بار (زیر همه گزارش‌های کارخانه چاپ می‌شود) */
    public function rules(Request $request)
    {
        $t = mb_substr(trim(str_replace("\r", '', (string) $request->input('rules'))), 0, 1500);
        $name = mb_substr(trim((string) $request->input('name')), 0, 80);
        $logo = $request->boolean('logo');
        \App\Support\Settings::set(['buy_unload_rules' => $t, 'buy_report_name' => $name, 'buy_report_logo' => $logo, 'buy_report_images' => $request->boolean('images')]);
        Purchasing::flush();

        return response()->json(['ok' => true, 'rules' => $t, 'name' => $name, 'logo' => $logo ? route('pwa.icon', 192) : '']);
    }

    public function supplier(Request $request, Supplier $supplier)
    {
        $phone = preg_replace('/[^\d+]/', '', en_digits((string) $request->input('phone')));
        $supplier->update([
            'phone' => $phone ? mb_substr($phone, 0, 20) : null,
            'contact' => mb_substr(trim((string) $request->input('contact')), 0, 120) ?: null,
            'note' => mb_substr(trim((string) $request->input('note')), 0, 500) ?: null,
        ]);
        Purchasing::flush();

        return response()->json(['ok' => true, 'supplier' => [$supplier->id, $supplier->name, (string) $supplier->phone, (string) $supplier->contact, (int) $supplier->items_count]]);
    }

    /** مدل گزارش پیش‌نویس یک کارخانه */
    public function report(Supplier $supplier)
    {
        $r = Purchasing::report(null, $supplier);

        return response()->json($r + ['text' => Purchasing::reportText($r), 'sid' => $supplier->id], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    public function place(Request $request, Supplier $supplier)
    {
        try {
            $po = Purchasing::placeOrder($supplier->id, $request->input('note'), $request->user());
        } catch (RuntimeException $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
        $r = Purchasing::report($po);

        return response()->json(['ok' => true, 'id' => $po->id] + $r + ['text' => Purchasing::reportText($r), 'sid' => $supplier->id, 'sig' => Purchasing::stateSig()], 200, [], JSON_UNESCAPED_UNICODE);
    }

    public function orders(Request $request)
    {
        return response()->json(['orders' => Purchasing::orders(150, $request->integer('sid') ?: null)], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    public function order(PurchaseOrder $order)
    {
        $r = Purchasing::report($order);

        return response()->json(['id' => $order->id, 'status' => $order->status] + $r + ['text' => Purchasing::reportText($r), 'sid' => $order->supplier_id], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /** اقلام سفارش با وضعیت رسیده/نرسیده */
    public function arrival(PurchaseOrder $order)
    {
        $rows = Purchasing::arrival($order);

        return response()->json(['id' => $order->id, 'number' => $order->number, 'supplier' => $order->supplier_name, 'status' => $order->status,
            'date' => \App\Support\Jalali::format($order->created_at, true), 'lines' => $rows], 200, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    public function orderStatus(Request $request, PurchaseOrder $order)
    {
        Purchasing::setOrderStatus($order, (string) $request->input('status'));

        return response()->json(['ok' => true, 'sig' => Purchasing::stateSig()]);
    }

    /** ورود یک یا چند اکسل (کالاها/فروش)؛ نوع هر فایل از سرستون‌ها تشخیص داده می‌شود. فایل کالاها اول خوانده می‌شود. */
    public function import(Request $request)
    {
        @set_time_limit(300);
        @ini_set('memory_limit', '512M');
        $files = array_values(array_filter(array_merge((array) $request->file('files', []), [$request->file('file')]), fn ($f) => $f && $f->isValid()));
        if (! $files) {
            return response()->json(['ok' => false, 'msg' => 'فایل اکسل انتخاب نشده یا ناقص بارگذاری شد.'], 422);
        }
        $done = [];
        foreach ($files as $f) {
            try {
                $done[] = Purchasing::import($f->getRealPath(), $f->getClientOriginalName(), $request->user());
            } catch (\Throwable $e) {
                report($e);
                $done[] = ['error' => $e->getMessage(), 'file' => $f->getClientOriginalName()];
            }
        }
        $ok = array_filter($done, fn ($d) => ! isset($d['error']));
        if ($ok) {
            app()->terminating(fn () => \App\Services\BuyerImages::warm(50, 250));
        }

        return response()->json(['ok' => (bool) $ok, 'msg' => $ok ? null : ($done[0]['error'] ?? 'خطا'), 'results' => $done], $ok ? 200 : 422);
    }

    /** صفحه چاپ: ?s=1,2 (پیش‌نویس کارخانه‌ها) یا ?po=3,4 (سفارش‌های ثبت‌شده) یا ?all=1 (همه پیش‌نویس‌ها) */
    public function print(Request $request)
    {
        $reports = [];
        $ids = fn ($k) => array_filter(array_map('intval', explode(',', (string) $request->query($k))));
        if ($po = $ids('po')) {
            foreach (PurchaseOrder::query()->with('supplier')->whereIn('id', $po)->orderBy('id')->get() as $o) {
                $reports[] = Purchasing::report($o);
            }
        } else {
            $sids = $request->boolean('all')
                ? \Illuminate\Support\Facades\DB::table('supply_items as i')->join('purchase_marks as m', 'm.code_key', '=', 'i.code_key')
                    ->where('m.cartons', '>', 0)->where('m.excluded', false)->distinct()->pluck('i.supplier_id')->all()
                : $ids('s');
            foreach (Supplier::query()->whereIn('id', $sids)->orderBy('name')->get() as $s) {
                $r = Purchasing::report(null, $s);
                if ($r['lines']) {
                    $reports[] = $r;
                }
            }
        }

        return view('buyer.print', ['reports' => $reports, 'cfg' => Purchasing::cfg()]);
    }
}
