<?php

namespace App\Http\Controllers;

use App\Services\AppBuilder;
use Illuminate\Support\Facades\Storage;

/**
 * دریافت آخرین نسخه اپ اندروید.
 * منبع فایل (جدیدترین برنده می‌شود):
 *  ۱) اپ ساخته‌شده خودکار از پنل
 *  ۲) فایل APK آپلودشده در «تنظیمات اپ موبایل»
 *  ۳) فایلی که دستی با فایل‌منیجر هاست کنار سایت گذاشته شده (aziziplast.apk یا هر ‎.apk‌ در پوشه اصلی)
 */
class AppDownloadController extends Controller
{
    public function __invoke(\Illuminate\Http\Request $r)
    {
        $file = static::file();
        if (! $file) {
            $url = (string) (setting('mobile_app')['download_url'] ?? '');
            if ($url && ! str_contains($url, '/download/app') && ! str_contains($url, '/aziziplast.apk')) {
                return redirect()->away($url);
            }
            abort(404, 'هنوز فایل اپ روی سایت قرار نگرفته است.');
        }
        // لینک ثابت aziziplast.apk ← همان نام؛ لینک قدیمی ← نام بسته و نسخه
        $name = $r->is('aziziplast.apk') || ! (AppBuilder::state()['package'] ?? null) ? 'aziziplast.apk'
            : \Illuminate\Support\Str::slug((string) (AppBuilder::state()['package'] ?? 'app'), '-').'-'.(AppBuilder::state()['version_name'] ?? '').'.apk';

        while (ob_get_level() > 0) {
            @ob_end_clean(); // بافر خروجی هاست فایل بزرگ را خراب نکند
        }

        return response()->download($file, $name, [
            'Content-Type' => 'application/vnd.android.package-archive',
            'Cache-Control' => 'no-cache, no-store, must-revalidate', // نسخه تازه بلافاصله (نه نسخه کش‌شده)
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    /** مسیر کامل جدیدترین فایل APK معتبر، یا null */
    public static function file(): ?string
    {
        $c = [];
        $disk = Storage::disk('public');
        if ($f = AppBuilder::latestFile()) {
            $c[] = $disk->path($f);
        }
        $up = (string) (setting('mobile_app')['apk_file'] ?? '');
        if ($up !== '' && $disk->exists($up)) {
            $c[] = $disk->path($up);
        }
        foreach (array_unique([base_path(), public_path(), dirname(base_path())]) as $dir) {
            $c[] = $dir.'/aziziplast.apk';
            foreach ((array) @glob($dir.'/*.apk') as $g) {
                $c[] = $g;
            }
        }
        $best = null;
        $bt = -1;
        foreach (array_unique(array_filter($c)) as $p) {
            if (! is_file($p) || filesize($p) < 1024) {
                continue;
            }
            $h = @fopen($p, 'rb');
            $sig = $h ? fread($h, 2) : '';
            $h && fclose($h);
            if ($sig !== 'PK') {
                continue; // فایل خراب یا صفحه HTML با پسوند apk
            }
            $t = (int) filemtime($p);
            if ($t > $bt) {
                $best = $p;
                $bt = $t;
            }
        }

        return $best;
    }
}
