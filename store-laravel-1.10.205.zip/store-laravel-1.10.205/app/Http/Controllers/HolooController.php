<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\PickTask;
use App\Services\Picking;
use App\Support\Slips;
use App\Support\XlsWriter;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;

/** خروجی اکسل ۹۷-۲۰۰۳ برای ورود فاکتور به نرم‌افزار حسابداری هلو */
class HolooController extends Controller
{
    /** همه حواله‌های مرحله فعلی برای این گروه انبار بسته شده‌اند؟ */
    protected function groupDone(Order $order, string $scope): bool
    {
        if ($scope[0] === 'k') {
            $q = PickTask::query()->where('order_id', $order->id)->where('keeper_id', (int) substr($scope, 1));
        } else {
            $wid = (int) substr($scope, 1);
            $q = PickTask::query()->where('order_id', $order->id)->whereNull('keeper_id')->whereHas('items', fn ($i) => $i->where('warehouse_id', $wid));
        }
        $tasks = $q->get(['id', 'status', 'round']);

        return $tasks->isNotEmpty() && $tasks->every(fn ($t) => $t->status === 'done');
    }

    /** کد کالا در هلو */
    public static function code(OrderItem $i): string|int
    {
        $code = (string) ($i->product?->sku ?: ($i->product?->sync_code ?: ($i->barcode ?: $i->product?->barcode)));

        return ctype_digit(en_digits($code)) ? (int) en_digits($code) : $code;
    }

    /**
     * ردیف‌های هلو: [کد، تعداد کارتن، تعداد کل عدد، فی، نام، مبلغ]
     * - اقلام تکراری یک کالا با قیمت و حالت یکسان جمع می‌شوند (ترتیب = ترتیب ورودی)
     * - کالای کارتنی که مضرب کارتن نیست (مثلاً ۵۰ عدد از کارتن ۱۲تایی): تعداد کارتن صفر و فقط تعداد کل
     *
     * @param  callable(OrderItem): int  $qty
     */
    public static function rows(Collection $items, callable $qty, array $opt = []): array
    {
        $byPack = ! empty($opt['packs']);
        $rows = [];
        foreach ($items as $i) {
            $u = $qty($i);
            if ($u <= 0) {
                continue;
            }
            $code = static::code($i);
            $per = max(1, (int) $i->per_carton);
            $carton = ! $i->isRetail() && $per > 1;
            $pack = $byPack ? (int) ($i->desk_pack ?? 0) : 0;
            $k = $code.'|'.(int) $i->unit_price.'|'.($carton ? 'c'.$per : 'u').'|'.$pack;
            $rows[$k] ??= ['code' => $code, 'cartons' => 0, 'units' => 0, 'price' => (int) $i->unit_price, 'name' => $i->name, 'per' => $carton ? $per : 1, 'pack' => $pack, 'packName' => ''];
            $rows[$k]['units'] += $u;
        }
        foreach ($rows as &$r) {
            // بررسی رومیزی: «تعداد دوم» همیشه صفر، فقط تعداد کل طبق بررسی
            $r['cartons'] = empty($opt['zero_cartons']) && $r['per'] > 1 && $r['units'] % $r['per'] === 0 ? intdiv($r['units'], $r['per']) : 0;
            $r['total'] = $r['units'] * $r['price'];
        }
        unset($r);
        $rows = array_values($rows);
        if ($byPack) {
            // نام کیسه/کارتن روی آخرین ردیف هر بسته
            foreach ($rows as $idx => $r) {
                $next = $rows[$idx + 1]['pack'] ?? null;
                if ($r['pack'] && $next !== $r['pack']) {
                    $rows[$idx]['packName'] = (string) ($opt['packs'][$r['pack']] ?? $r['pack']);
                }
            }
        }

        return $rows;
    }

    /** اقلام بررسی‌شده یک حواله رومیزی به ترتیب بررسی (اول تأییدشده‌ها به ترتیب زمان، بعد بقیه به ترتیب حواله) */
    public static function deskItems(PickTask $task): Collection
    {
        $items = $task->items()->with(['product:id,sync_code,sku,barcode', 'warehouse'])->get();
        $metas = \App\Models\Warehouse::query()->whereIn('id', $items->pluck('warehouse_id')->filter()->unique())->get()->keyBy('id');
        $sorted = Slips::sortItems($items, $metas)->values();
        $pos = $sorted->pluck('id')->flip();

        // اول بر اساس کیسه/کارتن (بسته ۱، ۲، …؛ بی‌بسته آخر)، بعد ترتیب بررسی
        return $sorted->sortBy(fn (OrderItem $i) => [(int) ($i->desk_pack ?? 0) ?: PHP_INT_MAX, $i->desk_at ? 0 : 1, $i->desk_at?->getTimestamp() ?? 0, $pos[$i->id]])->values();
    }

    /** گزینه‌های ردیف‌های هلو برای یک بررسی رومیزی (تعداد دوم صفر، ستون نام کیسه در سالن شمارشی) */
    public static function deskOpts(PickTask $task): array
    {
        $hall = Picking::taskHall($task);
        $cfg = Picking::halls()[$hall] ?? [];
        $packs = [];
        if (($cfg['mode'] ?? 'scan') === 'count' && ! empty($cfg['pack_col'])) {
            foreach (Picking::packsOf($task) as $p) {
                $packs[(int) $p['n']] = Picking::packName($p);
            }
        }

        return ['zero_cartons' => true, 'packs' => $packs];
    }

    public function export(Request $request, Order $order)
    {
        $scope = (string) $request->query('scope', 'all');
        $taskScope = preg_match('/^t(\d+)$/', $scope, $tm) ? PickTask::query()->where('order_id', $order->id)->find((int) $tm[1]) : null;
        $grouped = (bool) preg_match('/^[kw]\d+$/', $scope) || $taskScope;
        $desk = $grouped && Picking::canDesk($request->user());
        abort_unless($request->user()->hasPerm('orders') || $desk, 403);
        if (! $desk) {
            abort_if(\App\Services\Chat::printLocked($order), 403, 'این سفارش هنوز مسئول ندارد؛ اول یکی از همکاران سفارش را بردارد.');
        }
        if (str_starts_with($scope, 't')) {
            // خروجی یک انبار پس از بررسی رومیزی: فقط اقلام همان بررسی، به ترتیب بررسی
            abort_unless($taskScope && $taskScope->isDone(), 409, 'اکسل این انبار پس از «تأیید نهایی» بررسی رومیزی آماده می‌شود.');
            abort_unless($request->user()->hasPerm('orders') || Picking::canHall($request->user(), Picking::taskHall($taskScope)), 403);
            $items = static::deskItems($taskScope);
            $rows = static::rows($items, fn (OrderItem $i) => (int) ($i->picked_units ?? $i->units), static::deskOpts($taskScope));
            $packCol = (bool) static::deskOpts($taskScope)['packs'];
            $label = '-'.$scope;
        } else {
            // خروجی یک انبار: همین که حواله‌های آن انبار بررسی و بسته شد آماده است (لازم نیست بقیه انبارها تمام کنند)
            abort_unless($order->holooReady() || ($grouped && $this->groupDone($order, $scope)), 409, 'اکسل هلو پس از پایان جمع‌آوری بار (و بررسی) این انبار آماده می‌شود.');
            $order->load('items.product:id,sync_code,sku,barcode');
            // پیش از پایان جمع‌آوری همه انبارها (خروجی یک انبار): تعداد = تعداد جمع‌شده/تأییدشده همان انبار
            $early = ! $order->holooReady();
            $qty = fn (OrderItem $i) => $early && $i->pick_status !== null && $i->picked_units !== null ? min((int) $i->picked_units, $i->orderedUnits()) : (int) $i->units;
            $items = $order->items->filter(fn (OrderItem $i) => $qty($i) > 0);
            $label = '';
            if ($scope === 'carton') {
                $items = $items->filter(fn (OrderItem $i) => ! $i->isRetail());
                $label = '-carton';
            } elseif ($scope === 'retail') {
                $items = $items->filter(fn (OrderItem $i) => $i->isRetail());
                $label = '-retail';
            } elseif (preg_match('/^[kw]\d+$/', $scope)) {
                $g = Slips::groups($order)[$scope] ?? null;
                abort_unless($g, 404);
                $items = $items->filter(fn (OrderItem $i) => in_array((int) $i->warehouse_id, $g['wids'], true));
                $label = '-'.$scope;
            }
            // فقط اقلام افزوده/جایگزین یک مرحله (اقلام مرحله‌های قبل پیش‌تر بررسی و در هلو ثبت شده‌اند)
            if (($rnd = (int) $request->query('round', 0)) > 0) {
                $items = $items->filter(fn (OrderItem $i) => (int) $i->round === $rnd);
                $label .= '-r'.$rnd;
            }
            $rows = static::rows($items, $qty);
        }
        $x = (new XlsWriter('Sheet1'))->money([3]);
        // همان سرستون‌های نمونه هلو
        // ستون‌ها: A کد کالا | B تعداد کارتن (غیرکارتنی یا کمتر از کارتن = ۰) | C مجموع تعداد عدد (۲ کارتن ۱۲تایی = ۲۴) | D فی هر عدد
        $packCol ??= false;
        $x->row(array_merge(['کد کالا ', 'تعداد دوم', 'تعداد', 'فی', 'شرح کالا'], $packCol ? ['نام کیسه'] : []));
        // شرح کالا: نام جایگاه بار روبه‌روی ردیف اول
        $bays = $taskScope ? [$taskScope->bay] : PickTask::query()->where('order_id', $order->id)
            ->when(preg_match('/^k(\d+)$/', $scope, $km), fn ($q) => $q->where('keeper_id', (int) $km[1]))
            ->whereNotNull('bay')->orderBy('id')->pluck('bay')->all();
        $bays = array_values(array_unique(array_filter(array_map(fn ($b) => trim((string) $b), $bays), fn ($b) => $b !== '' && $b !== 'بدون جایگاه')));
        $bayText = $bays ? (count($bays) === 1 && str_contains($bays[0], 'جایگاه') ? $bays[0] : 'جایگاه '.implode('، ', $bays)) : '';
        foreach ($rows as $n => $r) {
            // ستون نام کیسه: فقط شماره بسته روی آخرین ردیفش (کیسه ۱ ← 1)
            $x->row(array_merge([$r['code'], $r['cartons'], $r['units'], $r['price'], $n === array_key_first($rows) ? en_digits($bayText) : ''], $packCol ? [$r['packName'] !== '' ? (int) $r['pack'] : ''] : []));
        }
        $order->log('دریافت اکسل هلو'.($scope !== 'all' ? ' ('.$scope.')' : '').(($rq = (int) $request->query('round', 0)) > 0 ? ' — فقط افزوده/جایگزین مرحله '.fa($rq) : '').' — '.fa(count($rows)).' ردیف');

        return response($x->output(), 200, [
            'Content-Type' => 'application/vnd.ms-excel',
            // نام فایل: نام مشتری به حروف انگلیسی + شماره سفارش (مثلاً Ali-Rezaei-1073-k5.xls)
            'Content-Disposition' => 'attachment; filename="'.\App\Support\Finglish::fileName($order->customer_name ?: $order->company, $order->number.$label).'"',
            'Cache-Control' => 'no-store',
        ]);
    }
}
