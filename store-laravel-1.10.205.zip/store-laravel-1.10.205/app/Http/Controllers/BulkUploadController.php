<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Services\BulkImport;
use App\Support\XlsWriter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Throwable;

/** آپلود گروهی محصولات (فایل‌ها یکی‌یکی از مرورگر می‌رسند تا محدودیت حجم هاست مشکلی نسازد) */
class BulkUploadController extends Controller
{
    protected function guard(Request $request, ?int $id = null): void
    {
        abort_unless(BulkImport::canUse($request->user()), 403);
        if ($id !== null) {
            abort_unless(DB::table('product_imports')->where('id', $id)->exists(), 404);
        }
    }

    public function start(Request $request)
    {
        $this->guard($request);
        $id = DB::table('product_imports')->insertGetId([
            'title' => mb_substr(trim((string) $request->input('title')) ?: 'آپلود '.jdate(now(), true), 0, 190),
            'user_id' => $request->user()->id, 'status' => 'uploading', 'created_at' => now(), 'updated_at' => now(),
        ]);
        @mkdir(BulkImport::dir($id).'/img', 0775, true);
        @mkdir(BulkImport::dir($id).'/excel', 0775, true);

        return response()->json(['id' => $id]);
    }

    public function file(Request $request, int $id)
    {
        $this->guard($request, $id);
        $f = $request->file('file');
        if (! $f || ! $f->isValid()) {
            return response()->json(['ok' => false, 'msg' => 'فایل ناقص رسید.'], 422);
        }
        $name = (string) ($request->input('name') ?: $f->getClientOriginalName());
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($request->input('kind') === 'excel') {
            abort_unless(in_array($ext, ['xlsx', 'xls', 'csv', 'xlsb'], true), 422, 'فرمت اکسل پشتیبانی نمی‌شود.');
            foreach (glob(BulkImport::dir($id).'/excel/*') ?: [] as $old) {
                @unlink($old);
            }
            $f->move(BulkImport::dir($id).'/excel', 'sheet.'.$ext);

            return response()->json(['ok' => true]);
        }
        [$ok, $msg] = $this->storeOne($id, $f, $name);

        return $ok ? response()->json(['ok' => true, 'name' => $ok]) : response()->json(['ok' => false, 'msg' => $msg], 422);
    }

    /** چند تصویر در یک درخواست (سریع‌تر: رفت‌وبرگشت کمتر) */
    public function images(Request $request, int $id)
    {
        $this->guard($request, $id);
        $files = (array) $request->file('files', []);
        $names = (array) $request->input('names', []);
        $saved = 0;
        $bad = [];
        foreach ($files as $i => $f) {
            $name = (string) ($names[$i] ?? '') ?: ($f ? $f->getClientOriginalName() : '');
            if (! $f || ! $f->isValid()) {
                $bad[] = $name.': ناقص رسید';

                continue;
            }
            [$ok, $msg] = $this->storeOne($id, $f, $name, false);
            $ok ? $saved++ : $bad[] = $msg;
        }
        if ($saved) {
            DB::table('product_imports')->where('id', $id)->increment('images', $saved);
        }

        return response()->json(['ok' => true, 'saved' => $saved, 'bad' => $bad]);
    }

    protected function storeOne(int $id, $f, string $name, bool $count = true): array
    {
        // فقط تصویر واقعی (نه فایل اجرایی با پسوند عکس)
        $info = @getimagesize($f->getRealPath());
        if (! $info || ! in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP, IMAGETYPE_GIF], true)) {
            return [null, 'تصویر معتبر نیست: '.$name];
        }
        $stored = BulkImport::storeImage($id, $name, $f->getRealPath());
        if ($count) {
            DB::table('product_imports')->where('id', $id)->increment('images');
        }

        return [$stored, null];
    }

    /** پایان ساخت (بعد از همه بسته‌های موازی): پاک کردن فایل‌های موقت */
    public function finish(Request $request, int $id)
    {
        $this->guard($request, $id);
        DB::table('product_imports')->where('id', $id)->update(['status' => 'done', 'created_count' => Product::query()->where('import_id', $id)->count(), 'updated_at' => now()]);
        BulkImport::cleanup($id, false);

        return response()->json(['ok' => true, 'made' => Product::query()->where('import_id', $id)->count()]);
    }

    public function analyze(Request $request, int $id)
    {
        $this->guard($request, $id);
        try {
            [$headers] = BulkImport::readExcel($id);
            $mapping = (array) $request->input('mapping', []);
            $guessed = BulkImport::guessMapping($headers);
            if (! $mapping) {
                $mapping = $guessed;
            }
            $opt = ['unit' => $request->input('unit') === 'rial' ? 'rial' : 'toman', 'in_stock' => (bool) $request->input('in_stock', true)];
            $a = BulkImport::analyze($id, $mapping, $opt);
        } catch (Throwable $e) {
            report($e);

            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
        $cats = \App\Models\Category::query()->pluck('name', 'id');

        return response()->json([
            'ok' => true, 'headers' => $headers, 'mapping' => array_values(array_map('strval', $mapping)), 'fields' => BulkImport::FIELDS,
            'stats' => $a['stats'], 'issues' => $a['issues'], 'issue_labels' => BulkImport::ISSUES,
            'rows' => array_map(fn ($r) => [
                'row' => $r['row'], 'code' => $r['code'], 'name' => $r['name'], 'price' => $r['price'], 'pc' => $r['per_carton'], 'unit' => $r['unit'],
                'wh' => $r['wh'], 'cat' => $r['cat'] ? ($cats[$r['cat']] ?? null) : null, 'cat_guess' => $r['cat_guess'], 'imgs' => $r['imgs'], 'flags' => $r['flags'],
            ], array_slice($a['rows'], 0, 2000)),
            'updates' => array_map(fn ($u) => ['pid' => $u['pid'], 'code' => $u['code'], 'name' => $u['name'], 'imgs' => $u['imgs'], 'old' => $u['old'] ? url(thumb($u['old'], 160)) : null], array_slice($a['updates'], 0, 2000)),
        ], 200, [], JSON_UNESCAPED_UNICODE);
    }

    public function create(Request $request, int $id)
    {
        $this->guard($request, $id);
        try {
            return response()->json(BulkImport::createChunk($id, max(0, (int) $request->input('offset')), max(1, min(40, (int) $request->input('limit', 20))), ! $request->boolean('parallel')));
        } catch (Throwable $e) {
            report($e);

            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
    }

    /** تعویض عکس اصلی کالاهای موجود (چند تا چند تا) */
    public function updateImages(Request $request, int $id)
    {
        $this->guard($request, $id);
        try {
            return response()->json(BulkImport::updateChunk($id, max(0, (int) $request->input('offset')), max(1, min(20, (int) $request->input('limit', 10)))));
        } catch (Throwable $e) {
            report($e);

            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
    }

    /** پیش‌نمایش کوچک تصویر آپلودشده */
    public function thumb(Request $request, int $id, string $name)
    {
        $this->guard($request, $id);
        $f = BulkImport::dir($id).'/img/'.basename($name);
        abort_unless(is_file($f), 404);

        return response()->file($f, ['Cache-Control' => 'private, max-age=3600']);
    }

    /** اکسل سئو (ستون‌های سئو خالی) برای پر کردن با Claude */
    public function seoExcel(Request $request, int $id)
    {
        $this->guard($request, $id);
        try {
            $f = BulkImport::seoExcel($id);
        } catch (Throwable $e) {
            abort(422, $e->getMessage());
        }

        return response()->download($f, 'seo-bulk-'.$id.'.xlsx')->deleteFileAfterSend();
    }

    /** ورود اکسل سئوی پرشده */
    public function seo(Request $request, int $id)
    {
        $this->guard($request, $id);
        $f = $request->file('file');
        if (! $f || ! $f->isValid() || ! in_array(strtolower($f->getClientOriginalExtension()), ['xlsx', 'xls', 'csv'], true)) {
            return response()->json(['ok' => false, 'msg' => 'یک فایل اکسل (xlsx) انتخاب کنید.'], 422);
        }
        try {
            return response()->json(['ok' => true] + BulkImport::seoImport($id, $f->getRealPath(), $f->getClientOriginalName()));
        } catch (Throwable $e) {
            return response()->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
    }

    /** گزارش مغایرت‌ها به اکسل */
    public function report(Request $request, int $id)
    {
        $this->guard($request, $id);
        $plan = json_decode((string) @file_get_contents(BulkImport::dir($id).'/plan.json'), true) ?: ['issues' => []];
        $x = new XlsWriter('مغایرت‌ها');
        $x->row(['نوع', 'کد کالا', 'نام کالا', 'ردیف اکسل', 'تصویر', 'توضیح']);
        foreach ($plan['issues'] as $is) {
            $x->row([BulkImport::ISSUES[$is['t']] ?? $is['t'], (string) ($is['code'] ?? ''), (string) ($is['name'] ?? ''), (string) ($is['row'] ?? ''), (string) ($is['img'] ?? ''), (string) ($is['msg'] ?? '')]);
        }

        return response($x->output(), 200, [
            'Content-Type' => 'application/vnd.ms-excel',
            'Content-Disposition' => 'attachment; filename="bulk-'.$id.'-issues.xls"',
        ]);
    }

    public function cancel(Request $request, int $id)
    {
        $this->guard($request, $id);
        BulkImport::cleanup($id);
        if (! Product::query()->where('import_id', $id)->exists()) {
            DB::table('product_imports')->where('id', $id)->delete();
        }

        return response()->json(['ok' => true]);
    }
}
