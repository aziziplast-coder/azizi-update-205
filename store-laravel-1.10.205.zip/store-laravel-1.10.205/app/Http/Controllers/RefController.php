<?php

namespace App\Http\Controllers;

use App\Services\Advisors;
use Illuminate\Http\Request;

/** لینک بازاریابی مشاور: /r/کد یا /r/کد/مسیر-هر-صفحه */
class RefController extends Controller
{
    public function go(Request $r, string $code, ?string $path = null)
    {
        $to = '/'.ltrim((string) $path, '/');
        if (! preg_match('~^/[^\s\\\\]*$~', $to) || str_starts_with($to, '//')) {
            $to = '/';
        }
        if ($q = $r->getQueryString()) {
            $to .= '?'.$q;
        }
        $res = redirect($to);
        if (! Advisors::enabled() || ! ($aid = Advisors::byCode($code))) {
            return $res;
        }
        $cur = (string) $r->cookie(Advisors::COOKIE);
        $fresh = ! str_starts_with($cur, $aid.'.') || (int) substr($cur, strpos($cur, '.') + 1) < time() - 86400;
        // مشتری‌ای که لینک مشاور دیگری دارد و هنوز معتبر است: کوکی عوض نمی‌شود مگر «جایگزینی» روشن باشد
        $other = Advisors::cookieAdvisor();
        if ($other && $other !== $aid && ! Advisors::cfg()['override']) {
            return $res;
        }
        Advisors::click($aid, $fresh);
        $res->withCookie(cookie('_str', 'adv'.preg_replace('/[^a-z0-9]/i', '', $code), 2, '/', null, null, false, false, 'Lax')); // آمار بازدید: ورود از لینک مشاور
        $days = max(1, (int) Advisors::cfg()['link_days']);
        $r->session()->forget('adv.done');
        if ($u = $r->user()) {
            Advisors::own($u, $aid, 'link');
        }

        return $res->withCookie(cookie(Advisors::COOKIE, $aid.'.'.time(), $days * 1440, '/', null, null, true, false, 'Lax'));
    }
}
