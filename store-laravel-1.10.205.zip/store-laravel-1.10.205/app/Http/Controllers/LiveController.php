<?php

namespace App\Http\Controllers;

use App\Models\LiveChat;
use App\Models\LiveMessage;
use App\Models\User;
use App\Services\Live;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use Throwable;

/** گفتگوی زنده: سمت بازدیدکننده (سایت) و سمت پاسخگوها (پنل و اپ مشاور) */
class LiveController extends Controller
{
    protected const NOCACHE = ['Cache-Control' => 'no-store, private', 'X-LiteSpeed-Cache-Control' => 'no-cache'];

    protected function json(array $d, int $code = 200)
    {
        return response()->json($d, $code, self::NOCACHE, JSON_UNESCAPED_UNICODE);
    }

    /* ================= بازدیدکننده ================= */

    protected function visitorChat(Request $r): ?LiveChat
    {
        $v = (string) $r->input('v');
        $k = (string) $r->input('k');
        if (! Live::validVid($v) || ! preg_match('/^[A-Za-z0-9]{32}$/', $k)) {
            return null;
        }

        return LiveChat::query()->where('token', $k)->where('vid', $v)->first();
    }

    /** پیام بازدیدکننده (متن یا ویس) ← جواب خودکار یا سپردن به همکاران */
    public function send(Request $r)
    {
        abort_unless(Live::enabled(), 404);
        $v = (string) $r->input('v');
        $text = trim((string) $r->input('text'));
        $voice = $r->file('voice');
        if (! Live::validVid($v) || (! $voice && ($text === '' || mb_strlen($text) > 1000))) {
            return $this->json(['ok' => false, 'msg' => 'پیام نامعتبر است.'], 422);
        }
        $vm = null;
        if ($voice) {
            try {
                $vm = Live::storeVoice($voice, (int) $r->input('sec'));
            } catch (Throwable $e) {
                return $this->json(['ok' => false, 'msg' => $e->getMessage()], 422);
            }
        }
        $c = $this->visitorChat($r) ?? Live::chatFor($v);
        $new = false;
        if (! $c) {
            $vis = Live::visitor($v) ?? [];
            $page = $r->input('p');
            if (is_string($page)) {
                $page = json_decode($page, true);
            }
            $auto = $r->input('auto');
            if (is_string($auto)) {
                $auto = json_decode($auto, true);
            }
            $c = Live::chatFor($v, true, [
                'user_id' => $r->user()?->id,
                'page' => is_array($page) ? array_slice(array_map(fn ($x) => is_scalar($x) ? mb_substr((string) $x, 0, 300) : null, $page), 0, 12) : ($vis['p'] ?? null),
                'rule' => is_array($auto) && isset(Live::RULES[$auto['r'] ?? '']) ? $auto['r'] : null,
                'ip' => $r->ip(), 'device' => mb_substr((string) ($vis['d'] ?? ''), 0, 60),
            ]);
            $new = true;
            // همان پیام خودکاری که بازدیدکننده جوابش را داد، اول گفتگو ثبت می‌شود
            if (is_array($auto) && trim((string) ($auto['t'] ?? '')) !== '') {
                Live::post($c, 'a', mb_substr((string) $auto['t'], 0, 600), null, ['rule' => $auto['r'] ?? null]);
            }
        }
        if (! $c->user_id && $r->user()) {
            $c->user_id = $r->user()->id;
        }
        $after = (int) $r->input('after');
        $staffActive = $c->staff_at && $c->staff_at->gt(now()->subMinutes(30));
        $bot = ! $vm && ! $c->human && ! $staffActive;
        // ۱) سؤال‌های متداول (رایگان، فوری)
        $faq = $bot ? Live::matchFaq($text) : null;
        if ($faq) {
            Live::post($c, 'v', $text, null, ['faq_hit' => $faq['i']], 'text', false);
            Live::post($c, 'a', $faq['a'], null, ['faq' => $faq['i'], 'ask' => 1]);
        } else {
            // ۲) هوش مصنوعی (اگر روشن است)
            $ai = null;
            if ($bot && Live::aiReady()) {
                Live::post($c, 'v', $text, null, ['nf' => 1], 'text', false);
                $ai = Live::aiReply($c, $text);
                if ($ai !== null) {
                    Live::post($c, 'a', $ai, null, ['ai' => 1, 'ask' => 1]);
                } else {
                    $c->increment('unread_staff');
                }
            } else {
                $vm ? Live::post($c, 'v', '', null, $vm, 'voice') : Live::post($c, 'v', $text, null, $bot && Live::cfg()['faq_on'] ? ['nf' => 1] : []);
            }
            // ۳) همکاران
            if ($ai === null) {
                $this->toHuman($c, $vm ? '🎤 پیام صوتی' : $text);
            }
        }
        $c->refresh();
        $c->forceFill(['unread_visitor' => 0])->save();

        return $this->json(['ok' => true, 'k' => $c->token, 'new' => $new, 'msgs' => $this->msgs($c, $new ? 0 : $after), 'ask' => ! $c->user_id && ! $c->mobile]);
    }

    /** پیام باید به دست همکار برسد: سپردن، اعلان، و پیام «رسید» وقتی کسی آنلاین نیست */
    protected function toHuman(LiveChat $c, string $text): void
    {
        Live::autoAssign($c);
        Live::notify($c, $text);
        $cfg = Live::cfg();
        if (! Live::staffOnline() && trim((string) $cfg['offline_text']) !== '' && ! $c->messages()->where('side', 'a')->where('meta', 'like', '%"off":1%')->exists()) {
            Live::post($c, 'a', (string) $cfg['offline_text'], null, ['off' => 1]);
        }
        Cache::forget('live.unread');
    }

    /** دکمه‌های زیر جواب خودکار: «جوابم را گرفتم» / «صحبت با همکار» */
    public function act(Request $r)
    {
        $c = $this->visitorChat($r);
        if (! $c) {
            return $this->json(['ok' => false], 404);
        }
        $m = $c->messages()->whereKey((int) $r->input('m'))->first();
        if ($m) {
            $meta = (array) $m->meta;
            $meta['done'] = $r->input('a') === 'human' ? 'human' : 'ok';
            $m->forceFill(['meta' => $meta])->save();
        }
        if ($r->input('a') === 'human') {
            $c->forceFill(['human' => true, 'unread_staff' => $c->unread_staff + 1])->save();
            Live::post($c, 'a', 'به همکارانمان خبر دادیم 🙏 همین‌جا جوابتان را می‌دهند.', null, ['sys' => 1]);
            $this->toHuman($c, 'مشتری خواست با همکار صحبت کند');
        }
        $c->forceFill(['unread_visitor' => 0])->save();

        return $this->json(['ok' => true, 'msgs' => $this->msgs($c, 0)]);
    }

    public function messages(Request $r)
    {
        $c = $this->visitorChat($r);
        if (! $c) {
            return $this->json(['ok' => false, 'msgs' => []], 404);
        }
        $out = $this->msgs($c, (int) $r->query('after'));
        if ($c->unread_visitor) {
            $c->forceFill(['unread_visitor' => 0])->save();
            Live::signal($c, false);
        }
        $ty = Live::typingOf($c);

        return $this->json(['ok' => true, 'msgs' => $out, 'closed' => $c->status === 'closed', 'ask' => ! $c->user_id && ! $c->mobile, 'ty' => $ty ? 1 : 0]);
    }

    public function contact(Request $r)
    {
        $c = $this->visitorChat($r);
        if (! $c) {
            return $this->json(['ok' => false], 404);
        }
        $m = preg_replace('/\D/', '', en_digits((string) $r->input('mobile')));
        if (strlen($m) >= 10) {
            $m = '0'.substr($m, -10);
        }
        if (! preg_match('/^09\d{9}$/', $m)) {
            return $this->json(['ok' => false, 'msg' => 'شماره موبایل درست نیست.'], 422);
        }
        $name = mb_substr(trim((string) $r->input('name')), 0, 60);
        $c->forceFill(['mobile' => $m, 'name' => $name ?: $c->name])->save();
        $u = User::query()->where('mobile', $m)->first();
        if ($u && ! $c->user_id) {
            $c->forceFill(['user_id' => $u->id])->save();
        }
        Live::post($c, 'a', 'شماره شما ثبت شد ✅ اگر از سایت رفتید، با همین شماره با شما در تماس هستیم.', null, ['sys' => 1]);
        $c->forceFill(['unread_visitor' => 0])->save();

        return $this->json(['ok' => true, 'msgs' => $this->msgs($c, (int) $r->input('after'))]);
    }

    protected function msgs(LiveChat $c, int $after): array
    {
        $agent = Live::cfg()['agent'];
        $names = [];

        return $c->messages()->where('id', '>', $after)->orderBy('id')->limit(300)->get()
            ->map(function (LiveMessage $m) use ($agent, &$names) {
                $n = $agent;
                if ($m->side === 's' && $m->user_id) {
                    $n = $names[$m->user_id] ??= (Str::before(trim((string) User::query()->whereKey($m->user_id)->value('name')), ' ') ?: $agent);
                }

                return Live::msgJson($m, $n);
            })->all();
    }

    /* ================= پاسخگوها (پنل و اپ مشاور) ================= */

    protected function staff(Request $r): User
    {
        $u = $r->user();
        abort_unless($u && $u->hasPerm('live'), 403);

        return $u;
    }

    /** گفتگوهایی که این پاسخگو می‌بیند */
    protected function scope(User $u)
    {
        $q = LiveChat::query();
        if (! $u->isAdmin() && Live::cfg()['own_only']) {
            $q->where(fn ($w) => $w->whereNull('staff_id')->orWhere('staff_id', $u->id));
        }

        return $q;
    }

    public function state(Request $r)
    {
        $u = $this->staff($r);
        Live::touchOnline();
        Live::markOnline($u);
        $now = time();
        $vis = Live::visitors(80);
        // شمارش‌ها از همه آنلاین‌ها؛ جزئیات فقط برای مهم‌ترها (سبک ماندن صفحه با صدها آنلاین)
        $kp = ['on' => count($vis), 'prod' => 0, 'cart' => 0, 'known' => 0];
        foreach ($vis as $d) {
            $kp['prod'] += ($d['p']['k'] ?? '') === 'product' ? 1 : 0;
            $kp['cart'] += ! empty($d['cart']) ? 1 : 0;
            $kp['known'] += ! empty($d['u']) ? 1 : 0;
        }
        $vids = array_column($vis, 'v');
        $byVid = $vids ? LiveChat::query()->whereIn('vid', $vids)->where('status', 'open')->get(['id', 'vid', 'unread_staff', 'staff_id'])->keyBy('vid') : collect();
        $q = trim((string) $r->query('q'));
        if ($q !== '') {
            $qn = Live::norm($q);
            $uidHit = User::query()->where(fn ($w) => $w->where('name', 'like', '%'.$q.'%')->orWhere('mobile', 'like', '%'.en_digits($q).'%'))->limit(200)->pluck('id')->all();
            $vis = array_values(array_filter($vis, fn ($d) => str_contains(Live::norm(($d['p']['t'] ?? '').' '.($d['un'] ?? '')), $qn) || (isset($d['u']) && in_array($d['u'], $uidHit, true))));
        }
        $score = function ($d) use ($byVid) {
            $ch = $byVid->get($d['v']);

            return ($ch?->unread_staff ? 1000 : 0) + ($ch ? 300 : 0) + (! empty($d['cart']) ? 120 : 0) + (($d['p']['k'] ?? '') === 'product' ? 80 : 0) + (! empty($d['u']) ? 60 : 0) + min(50, (int) ($d['n'] ?? 0) * 5);
        };
        usort($vis, fn ($a, $b) => $score($b) <=> $score($a) ?: (($b['at'] ?? 0) <=> ($a['at'] ?? 0)));
        $max = 150;
        $more = max(0, count($vis) - $max);
        $vis = array_slice($vis, 0, $max);
        $uids = array_values(array_filter(array_column($vis, 'u')));
        $users = $uids ? User::query()->whereIn('id', $uids)->get(['id', 'name', 'mobile', 'city', 'company'])->keyBy('id') : collect();
        $vOut = [];
        foreach ($vis as $d) {
            $usr = isset($d['u']) ? $users->get($d['u']) : null;
            $ch = $byVid->get($d['v']);
            $vOut[] = [
                'v' => $d['v'], 'name' => $usr?->name ?: ($d['un'] ?? null), 'mobile' => $usr?->mobile ? fa($usr->mobile) : null,
                'city' => $usr?->city, 'company' => $usr?->company, 'p' => $d['p'] ?? null,
                'on' => max(0, $now - (int) ($d['at'] ?? $now)), 'site' => max(0, $now - (int) ($d['first'] ?? $now)), 'n' => (int) ($d['n'] ?? 0),
                'd' => $d['d'] ?? '', 'app' => ! empty($d['app']), 'ref' => $d['ref'] ?? '', 'cart' => (int) ($d['cart'] ?? 0),
                'h' => array_reverse(array_slice($d['h'] ?? [], -8)), 'a' => array_reverse($d['a'] ?? []),
                'chat' => $ch?->id, 'unread' => (int) ($ch?->unread_staff ?? 0), 'idle' => max(0, $now - (int) ($d['seen'] ?? $now)),
            ];
        }
        // گفتگوها
        $f = (string) $r->query('f', 'open');
        $cq = $this->scope($u)->with('user:id,name,mobile', 'staff:id,name');
        match ($f) {
            'mine' => $cq->where('staff_id', $u->id)->where('status', 'open'),
            'none' => $cq->whereNull('staff_id')->where('status', 'open'),
            'closed' => $cq->where('status', 'closed'),
            'bot' => $cq->where('status', 'open')->where('unread_staff', 0)->where('last_side', 'a'),
            default => $cq->where('status', 'open'),
        };
        if ($q !== '') {
            $cq->where(fn ($w) => $w->where('name', 'like', '%'.$q.'%')->orWhere('mobile', 'like', '%'.en_digits($q).'%')->orWhere('last_text', 'like', '%'.$q.'%')
                ->orWhereHas('user', fn ($x) => $x->where('name', 'like', '%'.$q.'%')->orWhere('mobile', 'like', '%'.en_digits($q).'%')));
        }
        $chats = $cq->orderByDesc('unread_staff')->orderByDesc('last_at')->limit(80)->get();
        $online = array_flip($vids);
        $cOut = $chats->map(fn (LiveChat $c) => [
            'id' => $c->id, 'v' => $c->vid, 'name' => $c->label(), 'mobile' => $c->mobile ? fa($c->mobile) : ($c->user?->mobile ? fa($c->user->mobile) : null),
            'unread' => (int) $c->unread_staff, 'last' => ($c->last_side === 's' ? '↩ ' : ($c->last_side === 'a' ? '🤖 ' : '')).$c->last_text,
            'at' => $c->last_at ? ($c->last_at->isToday() ? fa($c->last_at->timezone('Asia/Tehran')->format('H:i')) : jdate($c->last_at)) : '',
            'closed' => $c->status === 'closed', 'online' => isset($online[$c->vid]), 'staff' => $c->staff?->name, 'mine' => (int) $c->staff_id === $u->id,
            'ty' => ($t = Live::typingOf($c)) && $t['i'] !== $u->id ? $t['n'] : null,
        ])->values();
        $base = $this->scope($u)->where('status', 'open');
        $counts = [
            'open' => (clone $base)->count(), 'mine' => (clone $base)->where('staff_id', $u->id)->count(), 'none' => (clone $base)->whereNull('staff_id')->count(),
            'unread' => (int) (clone $base)->sum('unread_staff'),
        ];
        $out = ['ok' => true, 'visitors' => $vOut, 'more' => $more, 'kp' => $kp, 'chats' => $cOut, 'counts' => $counts, 'unread' => $counts['unread'], 'now' => $now,
            'agents' => Live::agents(true), 'online' => Live::onlineStaff()];
        // گفتگوی باز
        if ($id = (int) $r->query('c')) {
            $c = $this->scope($u)->with('user:id,name,mobile,city,company', 'staff:id,name')->find($id);
            if ($c) {
                if ($r->boolean('tp')) {
                    Live::typing($c, $u);
                }
                if ($c->unread_staff) {
                    $c->forceFill(['unread_staff' => 0])->save();
                    Cache::forget('live.unread');
                }
                $ty = Live::typingOf($c);
                $out['chat'] = [
                    'id' => $c->id, 'v' => $c->vid, 'name' => $c->label(), 'closed' => $c->status === 'closed',
                    'mobile' => $c->mobile ?: $c->user?->mobile, 'user' => $c->user_id ? url('/admin/customers/'.$c->user_id.'/edit') : null,
                    'city' => $c->user?->city, 'company' => $c->user?->company, 'device' => $c->device, 'start' => $c->page, 'rule' => Live::RULES[$c->rule] ?? null,
                    'staff' => $c->staff?->name, 'staff_id' => $c->staff_id, 'human' => (bool) $c->human,
                    'ty' => $ty && $ty['i'] !== $u->id ? $ty['n'] : null,
                    'seen' => ! $c->unread_visitor && $c->last_side !== 'v',
                    'msgs' => $this->msgs($c, (int) $r->query('after')),
                ];
            }
        }

        return $this->json($out);
    }

    public function staffSend(Request $r)
    {
        $u = $this->staff($r);
        $text = trim((string) $r->input('text'));
        $voice = $r->file('voice');
        if (! $voice && ($text === '' || mb_strlen($text) > 2000)) {
            return $this->json(['ok' => false, 'msg' => 'متن پیام خالی است.'], 422);
        }
        $c = null;
        if ($id = (int) $r->input('c')) {
            $c = $this->scope($u)->find($id);
        } elseif (Live::validVid($v = (string) $r->input('v'))) {
            $vis = Live::visitor($v);
            $c = Live::chatFor($v, true, ['user_id' => $vis['u'] ?? null, 'page' => $vis['p'] ?? null, 'rule' => 'manual', 'device' => mb_substr((string) ($vis['d'] ?? ''), 0, 60), 'ip' => $vis['ip'] ?? null]);
        }
        if (! $c) {
            return $this->json(['ok' => false, 'msg' => 'گفتگو پیدا نشد.'], 404);
        }
        if ($c->status === 'closed') {
            $c->status = 'open';
        }
        try {
            if ($voice) {
                Live::post($c, 's', '', $u, Live::storeVoice($voice, (int) $r->input('sec')), 'voice');
            } else {
                Live::post($c, 's', $text, $u);
            }
        } catch (Throwable $e) {
            return $this->json(['ok' => false, 'msg' => $e->getMessage()], 422);
        }
        Cache::forget('live.ty.'.$c->id);

        return $this->json(['ok' => true, 'c' => $c->id]);
    }

    public function close(Request $r)
    {
        $u = $this->staff($r);
        $c = $this->scope($u)->findOrFail((int) $r->input('c'));
        $c->forceFill(['status' => $r->boolean('open') ? 'open' : 'closed', 'unread_staff' => 0])->save();
        Cache::forget('live.unread');
        Live::signal($c, false);

        return $this->json(['ok' => true]);
    }

    /** سپردن / انتقال گفتگو به پاسخگوی دیگر (مسئول فعلی یا مدیر کل) */
    public function assign(Request $r)
    {
        $u = $this->staff($r);
        $c = $this->scope($u)->findOrFail((int) $r->input('c'));
        abort_unless($u->isAdmin() || ! $c->staff_id || (int) $c->staff_id === $u->id, 403);
        $to = (int) $r->input('to');
        if ($to && ! in_array($to, array_column(Live::agents(true), 'id'), true)) {
            return $this->json(['ok' => false, 'msg' => 'این همکار دسترسی گفتگوی زنده ندارد.'], 422);
        }
        $c->forceFill(['staff_id' => $to ?: null, 'assigned_at' => $to ? now() : null])->save();
        if ($to && $to !== $u->id) {
            Cache::forget('live.push.'.$c->id);
            Live::notify($c, 'گفتگو به شما سپرده شد ('.$u->name.')');
        }

        return $this->json(['ok' => true]);
    }
}
