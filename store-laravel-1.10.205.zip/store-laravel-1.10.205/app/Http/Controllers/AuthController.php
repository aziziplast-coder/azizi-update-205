<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\Otp;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;

class AuthController extends Controller
{
    public function show(Request $request)
    {
        if ($request->user()) {
            return redirect()->route('account');
        }
        if ($request->query('next')) {
            session(['url.intended' => url($request->query('next'))]);
        }

        return view('store.login', [
            'otp' => Otp::enabled(),
            'password' => Otp::passwordEnabled(),
        ]);
    }

    public function sendOtp(Request $request, Otp $otp)
    {
        abort_unless(Otp::enabled(), 404);
        $m = mobile($request->input('mobile'));
        if (! $m) {
            return response()->json(['ok' => false, 'msg' => 'شماره موبایل را درست وارد کنید (مثلاً ۰۹۱۲۳۴۵۶۷۸۹).'], 422);
        }
        $res = $otp->send($m, $request->ip());
        $user = User::query()->where('mobile', $m)->first();

        return response()->json($res + ['mobile' => $m, 'isNew' => ! $user || ! $user->name], $res['ok'] || ! empty($res['codeStep']) ? 200 : 429);
    }

    public function verifyOtp(Request $request, Otp $otp)
    {
        abort_unless(Otp::enabled(), 404);
        $m = mobile($request->input('mobile'));
        if (! $m || ! $otp->verify($m, (string) $request->input('code'))) {
            return response()->json(['ok' => false, 'msg' => 'کد وارد شده درست نیست یا منقضی شده است.'], 422);
        }
        $user = User::query()->firstOrCreate(['mobile' => $m], ['role' => 'customer', 'is_active' => true]);
        if ($user->wasRecentlyCreated) {
            $user->refresh(); // مقادیر پیش‌فرض ستون‌ها از دیتابیس
        }
        if ($user->is_active === false) {
            return response()->json(['ok' => false, 'msg' => 'حساب شما غیرفعال است. با فروشگاه تماس بگیرید.'], 403);
        }
        $name = trim(strip_tags((string) $request->input('name')));
        if ($name !== '' && ! $user->name) {
            $user->name = mb_substr($name, 0, 120);
        }
        $user->last_login_at = now();
        if (User::verifyColumns() && ! $user->mobile_verified_at) {
            $user->mobile_verified_at = now();
        }
        $user->save();
        Auth::login($user, true);
        $request->session()->regenerate();

        return response()->json(['ok' => true, 'redirect' => redirect()->intended(route('account'))->getTargetUrl()]);
    }

    public function password(Request $request)
    {
        abort_unless(Otp::passwordEnabled(), 404);
        $m = mobile($request->input('mobile'));
        $user = $m ? User::query()->where('mobile', $m)->first() : null;
        if ($lgMsg = \App\Support\LoginGuard::blocked('site', $m)) {
            return back()->withErrors(['mobile' => $lgMsg])->withInput();
        }
        if (! $user || ! $user->password || ! Hash::check((string) $request->input('password'), $user->password)) {
            \App\Support\LoginGuard::fail('site', $m); // کند کردن حدس رمز، بدون مسدود کردن حساب

            return back()->withErrors(['mobile' => 'موبایل یا رمز عبور درست نیست.'])->withInput();
        }
        if (! $user->is_active) {
            return back()->withErrors(['mobile' => 'حساب شما غیرفعال است.']);
        }
        $user->update(['last_login_at' => now()]);
        \App\Support\LoginGuard::clear('site', $m);
        Auth::login($user, true);
        $request->session()->regenerate();

        return redirect()->intended(route('account'));
    }

    public function register(Request $request)
    {
        abort_unless(Otp::passwordEnabled(), 404);
        $request->merge(['mobile' => mobile($request->input('mobile'))]);
        $data = $request->validate([
            'name' => 'required|string|max:120',
            // حسابی که فقط کد گرفته و هرگز احراز نشده، مانع ثبت‌نام نیست
            'mobile' => ['required', \Illuminate\Validation\Rule::unique('users', 'mobile')->where(fn ($q) => User::verifyColumns() ? $q->where(fn ($w) => $w->whereNotNull('mobile_verified_at')->orWhereNotNull('password')) : $q)],
            'password' => 'required|string|min:6|confirmed',
        ], ['mobile.unique' => 'این موبایل قبلاً ثبت‌نام کرده است؛ وارد شوید.', 'mobile.required' => 'شماره موبایل را درست وارد کنید.'], ['name' => 'نام', 'password' => 'رمز عبور']);
        $lead = User::query()->where('mobile', $data['mobile'])->first();
        if ($lead) {
            $lead->fill($data + ['is_active' => true, 'last_login_at' => now(), 'mobile_verified_at' => now()])->save();
            $user = $lead;
        } else {
            $user = User::create($data + ['role' => 'customer', 'is_active' => true, 'last_login_at' => now()]);
        }
        Auth::login($user, true);
        $request->session()->regenerate();

        return redirect()->intended(route('account'));
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home');
    }
}
