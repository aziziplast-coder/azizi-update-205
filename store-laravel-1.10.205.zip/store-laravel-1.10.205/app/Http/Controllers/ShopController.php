<?php

namespace App\Http\Controllers;

use App\Models\Attribute;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductCollection;
use App\Models\Review;
use App\Models\StockAlert;
use App\Support\Search;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    public const SORTS = [
        'newest' => 'جدیدترین',
        'popular' => 'پرفروش‌ترین',
        'views' => 'پربازدیدترین',
        'cheap' => 'ارزان به گران',
        'expensive' => 'گران به ارزان',
        'discount' => 'بیشترین تخفیف',
        'sort' => 'پیشنهاد فروشگاه',
    ];

    public function index(Request $request)
    {
        return $this->listing($request, null);
    }

    public function category(Request $request, string $slug)
    {
        $category = Category::query()->active()->with('parent')->where('slug', $slug)->firstOrFail();
        if (($u = $this->canonicalRedirect($category->url(), $request))) {
            return $u;
        }

        return $this->listing($request, $category);
    }

    /** /category/1/پلاستیک — شناسه دسته در سایت قبلی (یا دسته‌ای که نامک عددی دارد) */
    public function legacyCategory(Request $request, string $legacy, ?string $name = null)
    {
        $category = Category::query()->active()->with('parent')->where('legacy_id', (int) $legacy)->first();
        if (! $category) {
            $category = Category::query()->active()->with('parent')->where('slug', $legacy)->first();
            if ($category && $name === null) {
                return $this->listing($request, $category);
            }
            abort_unless($category, 404);
        }
        if (($u = $this->canonicalRedirect($category->url(), $request))) {
            return $u;
        }

        return $this->listing($request, $category);
    }

    /** اگر لینک اصلی کالا/دسته شکل دیگری دارد (مثلاً لینک قدیم همین سایت) ← ۳۰۱ */
    protected function canonicalRedirect(string $canonical, Request $request)
    {
        $want = rtrim((string) parse_url($canonical, PHP_URL_PATH), '/');
        $have = rtrim('/'.ltrim($request->getPathInfo(), '/'), '/');
        if (urldecode($want) === urldecode($have) || $request->method() !== 'GET') {
            return null;
        }
        $qs = $request->getQueryString();

        return redirect()->to($canonical.($qs ? '?'.$qs : ''), 301);
    }

    protected function listing(Request $request, ?Category $category)
    {
        $term = trim((string) $request->query('q', ''));
        $searchNote = null;
        $fuzzyIds = null;

        $base = function () use ($request, $category) {
            $q = Product::query()->active()->with('category');
            if ($category) {
                $q->whereIn('category_id', $category->descendantIds());
            }

            return $this->filters($q, $request);
        };

        if ($term !== '') {
            $r = Search::resolve($term, fn (callable $apply) => $apply($base())->count());
            if ($r['kind'] === 'synonym') {
                $searchNote = 'نتیجه‌ای برای «'.$term.'» نبود؛ نتایج «'.$r['term'].'» نمایش داده شد.';
                $term = $r['term'];
            } elseif ($r['kind'] === 'fuzzy') {
                $searchNote = 'نتیجه دقیقی برای «'.$term.'» نبود؛ نزدیک‌ترین کالاها'.($r['term'] !== $term ? ' (منظورتان «'.$r['term'].'» بود؟)' : '').' نمایش داده شد.';
                $fuzzyIds = $r['ids'];
            }
        }

        $q = $base();
        if ($fuzzyIds !== null) {
            $q->whereIn('id', $fuzzyIds ?: [0]);
        } elseif ($term !== '') {
            Search::apply($q, $term);
        }

        $default = $category?->default_sort ?: setting('shop_default_sort', 'newest');
        $sort = array_key_exists((string) $request->query('sort'), self::SORTS) ? $request->query('sort') : ($term !== '' && ! $request->has('sort') ? 'relevance' : $default);
        if ($sort === 'relevance') {
            if ($fuzzyIds) {
                $q->orderByRaw('CASE id '.implode(' ', array_map(fn ($id, $i) => 'WHEN '.(int) $id.' THEN '.$i, $fuzzyIds, array_keys($fuzzyIds))).' ELSE 99999 END');
            }
        } else {
            ProductCollection::applySort($q, $sort);
        }
        if (setting('shop_out_mode', 'last') === 'last' && ! $request->boolean('only')) {
            Product::availableFirst($q);
        }
        $products = $q->paginate(max(8, min(96, (int) setting('shop_per_page', 24))))->withQueryString();

        // زیردسته‌ها با تعداد کالا (شامل زیردسته‌های خودشان)، از کش
        $counts = Category::productCounts();
        $subcats = ($category ? $category->children()->active()->orderBy('sort')->orderBy('name')->get() : Category::query()->active()->whereNull('parent_id')->orderBy('sort')->orderBy('name')->get())
            ->each(fn ($c) => $c->products_count = (int) ($counts[$c->id] ?? 0));

        // ویژگی‌های قابل فیلتر که در این بخش کالا دارند
        $attrs = Attribute::query()->where('filterable', true)->orderBy('sort')->with(['values' => fn ($v) => $v->whereHas('products', fn ($p) => $p->where('is_active', true)->when($category, fn ($c) => $c->whereIn('category_id', $category->descendantIds())))])->get()
            ->filter(fn ($a) => $a->values->isNotEmpty());

        return view('store.shop', [
            'category' => $category,
            'products' => $products,
            'subcats' => $subcats,
            'term' => $term,
            'sort' => $sort,
            'sorts' => ($term !== '' ? ['relevance' => 'مرتبط‌ترین'] : []) + self::SORTS,
            'attrs' => $attrs,
            'searchNote' => $searchNote,
        ]);
    }

    protected function filters(Builder $q, Request $request): Builder
    {
        if ($request->boolean('retail')) {
            $q->where('retail_enabled', true)->where('per_carton', '>', 1);
        }
        if ($request->boolean('carton')) {
            $q->where('carton_enabled', true)->where('per_carton', '>', 1);
        }
        // «انتهای فهرست»: ناموجودها هم نمایش داده می‌شوند ولی بعد از همه موجودها (تیک «فقط موجودها» آن‌ها را برمی‌دارد)
        if (setting('shop_out_mode', 'last') === 'last' ? $request->boolean('only') : ! $request->has('all')) {
            $q->available();
        }
        if ($request->boolean('sale')) {
            $q->onSale();
        }
        if ($min = to_int($request->query('min'))) {
            $q->where('price', '>=', $min);
        }
        if ($max = to_int($request->query('max'))) {
            $q->where('price', '<=', $max);
        }
        foreach ((array) $request->query('f', []) as $attrId => $valueIds) {
            $ids = array_filter(array_map('intval', (array) $valueIds));
            if ($ids) {
                $q->whereHas('attributeValues', fn ($v) => $v->whereIn('attribute_values.id', $ids));
            }
        }

        return $q;
    }

    /** فهرست کامل پرفروش‌ترین‌ها (تا ۵۰۰ کالا، طبق تنظیم بخش پرفروش‌ترین‌های صفحه اول) */
    public function bestsellers(Request $request)
    {
        $cfg = collect(\App\Support\HomeBlocks::blocks())->first(fn ($b) => ($b['type'] ?? '') === 'bestsellers');
        $d = (array) ($cfg['data'] ?? []);
        $max = max(10, min(500, (int) ($d['more_limit'] ?? 100)));
        $all = \App\Support\Rankings::bestsellers($max, (int) ($d['days'] ?? 0));
        $per = 48;
        $page = max(1, (int) $request->query('page', 1));
        $products = new \Illuminate\Pagination\LengthAwarePaginator($all->forPage($page, $per)->values(), $all->count(), $per, $page, ['path' => route('bestsellers')]);

        return view('store.bestsellers', ['products' => $products, 'title' => $d['title'] ?? 'پرفروش‌ترین‌ها', 'showSold' => ! empty($d['show_sold']), 'offset' => ($page - 1) * $per]);
    }

    public function socialProof()
    {
        return response()->json(\App\Support\SocialProof::feed())->header('Cache-Control', 'public, max-age=120');
    }

    public function product(Request $request, string $slug)
    {
        $product = Product::query()->active()->with(['category.parent', 'attributeValues'])->where('slug', $slug)->first();
        if (! $product) {
            return $this->hiddenProduct(Product::query()->where('slug', $slug)->first());
        }
        if (($u = $this->canonicalRedirect($product->url(), $request))) {
            return $u;
        }

        return $this->showProduct($product);
    }

    /** کالای پنهان‌شده (مثلاً ناموجود قدیمی): به‌جای ۴۰۴، انتقال دائمی به دسته‌اش تا اعتبار لینک در گوگل حفظ شود */
    protected function hiddenProduct(?Product $p)
    {
        abort_if(! $p || $p->review === 'pending', 404); // کالای منتظر تأیید هنوز منتشر نشده
        $cat = $p->category_id ? \App\Models\Category::query()->find($p->category_id) : null;

        return redirect()->to($cat ? $cat->url() : route('shop'), 301);
    }

    /** /product-39073/سطل+رولی3+تکنو — لینک کالا در سایت قبلی */
    public function legacyProduct(Request $request, string $legacy, ?string $name = null)
    {
        $product = Product::query()->active()->with(['category.parent', 'attributeValues'])->where('legacy_id', (int) $legacy)->first();
        if (! $product && ($hidden = Product::query()->where('legacy_id', (int) $legacy)->where(fn ($w) => $w->whereNull('review')->orWhere('review', '!=', 'pending'))->first())) {
            return $this->hiddenProduct($hidden);
        }
        if (! $product) {
            // کالایی که این‌جا ساخته نشده: به‌جای خطای ۴۰۴، جستجوی همان نام
            $name = trim(urldecode((string) $name));
            abort_if($name === '', 404);

            return redirect()->route('shop', ['q' => $name], 302);
        }
        if (($u = $this->canonicalRedirect($product->url(), $request))) {
            return $u;
        }

        return $this->showProduct($product);
    }

    protected function showProduct(Product $product)
    {
        Product::query()->whereKey($product->id)->increment('views');
        \App\Support\Rankings::hit($product->id);
        $reviews = $product->reviews()->where('is_approved', true)->latest()->limit(30)->get();
        $related = $product->relatedProducts(12);

        return view('store.product', compact('product', 'reviews', 'related'));
    }

    public function suggest(Request $request)
    {
        $term = trim((string) $request->query('q', ''));
        if (mb_strlen($term) < 2) {
            return response()->json([]);
        }
        $items = Product::query()->active()->search($term)->limit(8)->get(['id', 'name', 'slug', 'legacy_id', 'legacy_slug', 'image', 'price']);
        $note = null;
        if ($items->isEmpty()) {
            $r = Search::resolve($term, fn (callable $apply) => $apply(Product::query()->active())->count());
            if ($r['kind'] === 'synonym') {
                $items = Product::query()->active()->search($r['term'])->limit(8)->get(['id', 'name', 'slug', 'legacy_id', 'legacy_slug', 'image', 'price']);
                $note = $r['term'];
            } elseif ($r['kind'] === 'fuzzy' && $r['ids']) {
                $ids = array_slice($r['ids'], 0, 8);
                $items = Product::query()->active()->whereIn('id', $ids)->get(['id', 'name', 'slug', 'legacy_id', 'legacy_slug', 'image', 'price'])->sortBy(fn ($p) => array_search($p->id, $ids))->values();
                $note = $r['term'];
            }
        }
        $cats = Search::numericCodes($term) ? collect() : Category::query()->active()->get(['id', 'name', 'slug'])
            ->filter(fn ($c) => str_contains(Search::key($c->name), Search::key($term)) || Search::similarity(Search::key($c->name), Search::key($term)) >= 0.75)
            ->take(3);

        return response()->json([
            'note' => $note,
            'cats' => $cats->map(fn ($c) => ['name' => $c->name, 'url' => $c->url()])->values(),
            'items' => $items->map(fn ($p) => [
                'name' => $p->name,
                'url' => $p->url(),
                'img' => thumb($p->image, 160),
                'price' => money($p->price),
            ])->values(),
        ]);
    }

    public function notify(Request $request, Product $product)
    {
        $m = mobile($request->input('mobile', optional($request->user())->mobile));
        if (! $m) {
            return back()->withErrors(['mobile' => 'شماره موبایل معتبر وارد کنید.'])->withInput();
        }
        StockAlert::query()->updateOrCreate(['product_id' => $product->id, 'mobile' => $m], ['notified_at' => null]);

        return back()->with('ok', 'وقتی «'.$product->name.'» موجود شد به '.fa($m).' پیامک می‌دهیم.');
    }

    public function review(Request $request, Product $product)
    {
        $data = $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'body' => 'required|string|min:3|max:2000',
        ]);
        Review::create([
            'product_id' => $product->id,
            'user_id' => $request->user()->id,
            'name' => $request->user()->displayName(),
            'rating' => $data['rating'],
            'body' => strip_tags($data['body']),
            'is_approved' => false,
        ]);

        return back()->with('ok', 'نظر شما ثبت شد و پس از بررسی نمایش داده می‌شود.');
    }
}
