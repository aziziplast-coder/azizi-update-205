<?php

use App\Support\Jalali;
use App\Support\Settings;

if (! function_exists('installed')) {
    /** آیا نصب‌کننده اجرا و کامل شده است؟ */
    function installed(): bool
    {
        static $done = null;

        return $done ??= is_file(storage_path('app/installed.json'));
    }
}

if (! function_exists('setting')) {
    function setting(string $key, mixed $default = null): mixed
    {
        return Settings::get($key, $default);
    }
}

if (! function_exists('fa')) {
    /** ارقام انگلیسی → فارسی */
    function fa(mixed $value): string
    {
        return strtr((string) $value, ['0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹']);
    }
}

if (! function_exists('en_digits')) {
    /** ارقام فارسی/عربی → انگلیسی */
    function en_digits(mixed $value): string
    {
        return strtr((string) $value, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ]);
    }
}

if (! function_exists('to_int')) {
    /** «۶۱۵٬۰۰۰ تومان» → 615000 ؛ خالی → null */
    function to_int(mixed $value): ?int
    {
        if ($value === null) {
            return null;
        }
        if (is_int($value)) {
            return $value;
        }
        $s = preg_replace('/[^0-9\-]/', '', en_digits((string) $value));

        return ($s === '' || $s === '-') ? null : (int) $s;
    }
}

if (! function_exists('money')) {
    /** ۶۱۵٬۰۰۰ */
    function money(int|float|string|null $amount, bool $withUnit = false): string
    {
        $out = fa(number_format((float) $amount, 0, '.', '٬'));

        return $withUnit ? $out.' تومان' : $out;
    }
}

if (! function_exists('jdate')) {
    /** تاریخ شمسی: 1405/07/16 (با ساعت اختیاری) */
    function jdate(mixed $date, bool $withTime = false): string
    {
        if (! $date) {
            return '';
        }

        return Jalali::format($date, $withTime);
    }
}

if (! function_exists('mobile')) {
    /** موبایل ایران به شکل 09xxxxxxxxx یا رشته خالی */
    function mobile(mixed $raw): string
    {
        $s = preg_replace('/\D/', '', en_digits((string) $raw));
        if (str_starts_with($s, '0098')) {
            $s = substr($s, 4);
        } elseif (str_starts_with($s, '98') && strlen($s) === 12) {
            $s = substr($s, 2);
        }
        if (strlen($s) === 10 && $s[0] === '9') {
            $s = '0'.$s;
        }

        return preg_match('/^09\d{9}$/', $s) ? $s : '';
    }
}

if (! function_exists('upload_url')) {
    function upload_url(?string $path): ?string
    {
        if (! $path) {
            return null;
        }
        if (preg_match('#^(https?:)?//#', $path) || str_starts_with($path, '/')) {
            return $path;
        }

        return '/uploads/'.ltrim($path, '/');
    }
}

if (! function_exists('thumb')) {
    /**
     * نسخه کوچک‌شده تصویر (webp). بار اول ساخته و در public/uploads/_t ذخیره می‌شود و
     * دفعه‌های بعد مستقیم توسط وب‌سرور ارسال می‌شود.
     */
    function thumb(?string $path, int $width = 480): ?string
    {
        if (! $path) {
            return null;
        }
        if (preg_match('#^(https?:)?//#', $path) || str_starts_with($path, '/')) {
            return $path;
        }
        // GIF متحرک (بنر و اسلایدر) همان فایل اصلی می‌ماند تا انیمیشن از بین نرود
        if (preg_match('/\.gif$/i', $path)) {
            return upload_url($path);
        }
        $width = in_array($width, App\Http\Controllers\ThumbController::SIZES, true) ? $width : 480;

        return '/uploads/_t/'.$width.'/'.ltrim($path, '/').'.webp';
    }
}

if (! function_exists('srcset')) {
    /** srcset برای تصاویر واکنش‌گرا (اسلایدر، بنر) */
    function srcset(?string $path, array $widths = [480, 960, 1600, 2400]): string
    {
        if (! $path || preg_match('#^(https?:)?//#', $path) || str_starts_with($path, '/') || preg_match('/\.gif$/i', $path)) {
            return '';
        }

        return implode(', ', array_map(fn ($w) => thumb($path, $w).' '.$w.'w', $widths));
    }
}

if (! function_exists('num_words')) {
    function num_words(int|float $number): string
    {
        return App\Support\NumberWords::convert($number);
    }
}

if (! function_exists('store_name')) {
    function store_name(): string
    {
        return (string) setting('store_name', config('app.name'));
    }
}

if (! function_exists('clean_html')) {
    /** HTML امن برای نمایش (حذف اسکریپت و ویژگی‌های خطرناک) */
    function clean_html(?string $html): string
    {
        if (! $html) {
            return '';
        }
        static $s = null;
        $s ??= new Symfony\Component\HtmlSanitizer\HtmlSanitizer(
            (new Symfony\Component\HtmlSanitizer\HtmlSanitizerConfig())
                ->allowSafeElements()
                ->allowRelativeLinks()
                ->allowRelativeMedias()
                ->allowAttribute('class', '*')
                ->allowAttribute('style', ['span', 'p', 'td', 'th', 'div'])
                ->withMaxInputLength(500000)
        );

        return $s->sanitize($html);
    }
}

if (! function_exists('messenger_link')) {
    /**
     * لینک گفتگو با مشتری در پیام‌رسان انتخاب‌شده.
     * واتس‌اپ و تلگرام با شماره مستقیم باز می‌شوند؛ روبیکا، ایتا و بله لینک مستقیم با شماره ندارند،
     * پس شماره کپی و نسخه وب پیام‌رسان باز می‌شود تا شماره را جستجو کنید.
     *
     * @return array{url: string, app: string, label: string, direct: bool}
     */
    function messenger_link(?string $phone): ?array
    {
        $m = mobile((string) $phone);
        if (! $m) {
            return null;
        }
        $cfg = (array) setting('messenger', []);
        $app = $cfg['app'] ?? 'rubika';
        $intl = '98'.substr($m, 1);
        $custom = trim((string) ($cfg['link'] ?? ''));
        if ($custom !== '') {
            return ['url' => strtr($custom, ['{phone}' => $m, '{phone98}' => $intl]), 'app' => $app, 'label' => 'گفتگو', 'direct' => true];
        }

        return match ($app) {
            'whatsapp' => ['url' => 'https://wa.me/'.$intl, 'app' => $app, 'label' => 'واتس‌اپ', 'direct' => true],
            'telegram' => ['url' => 'https://t.me/+'.$intl, 'app' => $app, 'label' => 'تلگرام', 'direct' => true],
            'eitaa' => ['url' => 'https://web.eitaa.com/', 'app' => $app, 'label' => 'ایتا', 'direct' => false],
            'bale' => ['url' => 'https://web.bale.ai/', 'app' => $app, 'label' => 'بله', 'direct' => false],
            default => ['url' => 'https://web.rubika.ir/', 'app' => 'rubika', 'label' => 'روبیکا', 'direct' => false],
        };
    }
}
