<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** سفارش خریدِ ثبت‌شده برای یک کارخانه (اقلام به‌صورت ثابت ذخیره می‌شوند) */
class PurchaseOrder extends Model
{
    public const STATUSES = ['sent' => 'ارسال‌شده، در انتظار بار', 'received' => 'دریافت شد', 'cancelled' => 'لغو شد'];

    public const COLORS = ['sent' => 'warning', 'received' => 'success', 'cancelled' => 'gray'];

    protected $fillable = ['number', 'supplier_id', 'supplier_name', 'status', 'lines', 'total_cartons', 'items_count', 'total_amount', 'note', 'created_by', 'closed_at'];

    protected function casts(): array
    {
        return ['lines' => 'array', 'closed_at' => 'datetime'];
    }

    protected static function booted(): void
    {
        static::created(function (PurchaseOrder $o) {
            if (! $o->number) {
                $o->number = 'P-'.(1000 + $o->id);
                $o->saveQuietly();
            }
        });
    }

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
