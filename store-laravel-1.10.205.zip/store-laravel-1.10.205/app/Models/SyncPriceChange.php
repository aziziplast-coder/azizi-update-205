<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SyncPriceChange extends Model
{
    public const UPDATED_AT = null;

    protected $fillable = ['source_id', 'code', 'product_id', 'title', 'raw_old', 'raw_new', 'old_price', 'new_price'];
}
