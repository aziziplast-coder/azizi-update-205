<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * حواله کارخانه: مبلغی که باید با واریز مستقیم مشتریان (بیعانه و تسویه سفارش‌ها) پر شود.
 * active = جاری | filled = پر شده | closed = بسته/بایگانی
 */
class Remittance extends Model
{
    public const STATUSES = ['pending' => 'منتظر تعیین حساب', 'active' => 'جاری', 'filled' => 'پر شده', 'closed' => 'بسته شده', 'transferred' => 'منتقل شد به شخص دیگر'];

    /** تعیین حساب مقصد توسط کارخانه‌دار */
    public const DEST = ['awaiting' => 'منتظر تعیین حساب', 'review' => 'منتظر تأیید حسابداری', 'approved' => 'حساب تأیید شد', 'rejected' => 'رد شد — منتظر اصلاح کارخانه‌دار'];

    protected $fillable = ['code', 'title', 'amount', 'factory_phone', 'holder_name', 'bank_name', 'card_number', 'sheba', 'assignee_id', 'created_by', 'parent_id', 'status', 'sort', 'note', 'filled_at', 'closed_at',
        'factory_id', 'dest_status', 'dest_reason', 'dest_at', 'account_number'];

    protected function casts(): array
    {
        return ['filled_at' => 'datetime', 'closed_at' => 'datetime', 'dest_at' => 'datetime', 'amount' => 'integer'];
    }

    /** رکوردهای خوانده‌شده در همین درخواست (برای خواندن آمار همه با یک پرس‌وجو) */
    protected static array $pool = [];

    protected static function booted(): void
    {
        static::retrieved(function (Remittance $r) {
            if (count(static::$pool) < 500) {
                static::$pool[$r->id] = $r;
            }
        });
        static::created(function (Remittance $r) {
            if (! $r->code) {
                $r->code = 'H-'.(1000 + $r->id);
                $r->saveQuietly();
            }
        });
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assignee_id');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function factory(): BelongsTo
    {
        return $this->belongsTo(Factory::class);
    }

    public function destinations(): HasMany
    {
        return $this->hasMany(RemitDestination::class);
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(RemitPayment::class);
    }

    /** همان آمار، یک بار برای هر رکورد در هر درخواست (برای نمایش در جدول؛ در محاسبات از stats() استفاده شود) */
    public function statsCached(): array
    {
        if ($this->statsMemo === null) {
            // جدول حواله‌ها: آمار همه ردیف‌های صفحه با یک پرس‌وجو (به‌جای یکی برای هر ردیف)
            $ids = array_keys(array_filter(static::$pool, fn (Remittance $r) => $r->statsMemo === null));
            if (count($ids) > 1) {
                $all = RemitPayment::query()->whereIn('remittance_id', $ids)->whereIn('status', RemitPayment::LIVE)
                    ->selectRaw('remittance_id, status, SUM(amount) as s, COUNT(*) as c')->groupBy('remittance_id', 'status')->get()->groupBy('remittance_id');
                foreach ($ids as $id) {
                    static::$pool[$id]->statsMemo = static::$pool[$id]->buildStats(($all[$id] ?? collect())->keyBy('status'));
                }
            }
        }

        return $this->statsMemo ??= $this->stats();
    }

    protected ?array $statsMemo = null;

    /** آمار لحظه‌ای: تأییدشده، فیش رسیده (منتظر تأیید)، صادرشده منتظر واریز، آزاد */
    public function stats(): array
    {
        return $this->buildStats(RemitPayment::query()->where('remittance_id', $this->id)->whereIn('status', RemitPayment::LIVE)
            ->selectRaw('status, SUM(amount) as s, COUNT(*) as c')->groupBy('status')->get()->keyBy('status'));
    }

    protected function buildStats(\Illuminate\Support\Collection $rows): array
    {
        $confirmed = (int) ($rows['confirmed']->s ?? 0);
        $submitted = (int) ($rows['submitted']->s ?? 0);
        $awaiting = (int) ($rows['awaiting']->s ?? 0) + (int) ($rows['rejected']->s ?? 0);
        $amount = (int) $this->amount;

        return [
            'amount' => $amount,
            'confirmed' => $confirmed,
            'submitted' => $submitted,
            'awaiting' => $awaiting,
            'reserved' => $confirmed + $submitted + $awaiting,
            'free' => max(0, $amount - $confirmed - $submitted - $awaiting),
            'left' => max(0, $amount - $confirmed),
            'over' => max(0, $confirmed - $amount), // اضافه‌واریز: کارخانه بیشتر از مبلغ حواله گرفته
            'pct' => $amount > 0 ? min(100, round($confirmed * 100 / $amount, 1)) : 0,
            'pct_reserved' => $amount > 0 ? min(100, round(($submitted + $awaiting) * 100 / $amount, 1)) : 0,
            'count' => (int) $rows->sum('c'),
            'pending_receipts' => (int) ($rows['submitted']->c ?? 0),
        ];
    }

    public function statusLabel(): string
    {
        return self::STATUSES[$this->status] ?? $this->status;
    }

    public function label(): string
    {
        return $this->code.' — '.$this->title;
    }

    public function cardFormatted(): string
    {
        $d = preg_replace('/\D/', '', (string) $this->card_number);

        return $d ? trim(chunk_split($d, 4, '-'), '-') : '';
    }
}
