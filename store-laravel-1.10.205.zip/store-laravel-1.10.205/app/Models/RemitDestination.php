<?php

namespace App\Models;

use App\Support\Banks;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * حساب مقصدی که کارخانه‌دار برای (بخشی از) مبلغ حواله تعیین کرده است.
 * kind: own = به حساب خودم | other = انتقال به شخص دیگر
 */
class RemitDestination extends Model
{
    public const KINDS = ['own' => 'به حساب خودم', 'other' => 'انتقال به شخص دیگر'];

    public const STATUSES = ['submitted' => 'منتظر تأیید حسابداری', 'approved' => 'تأیید شد', 'rejected' => 'رد شد', 'transferred' => 'منتقل شد'];

    protected $fillable = ['remittance_id', 'factory_id', 'kind', 'amount', 'holder_name', 'bank_name', 'card_number', 'sheba', 'account_number', 'mobile', 'national_id', 'note', 'status', 'reason', 'reviewed_by', 'reviewed_at', 'child_remittance_id'];

    protected function casts(): array
    {
        return ['amount' => 'integer', 'reviewed_at' => 'datetime'];
    }

    public function remittance(): BelongsTo
    {
        return $this->belongsTo(Remittance::class);
    }

    public function child(): BelongsTo
    {
        return $this->belongsTo(Remittance::class, 'child_remittance_id');
    }

    public function kindLabel(): string
    {
        return self::KINDS[$this->kind] ?? $this->kind;
    }

    public function accountLine(): string
    {
        return implode(' — ', array_filter([
            $this->bank_name,
            $this->card_number ? 'کارت '.Banks::formatCard($this->card_number) : null,
            $this->sheba ? Banks::formatSheba($this->sheba) : null,
            $this->account_number ? 'حساب '.$this->account_number : null,
        ]));
    }
}
