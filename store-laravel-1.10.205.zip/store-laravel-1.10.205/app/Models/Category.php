<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Category extends Model
{
    protected $fillable = ['parent_id', 'name', 'slug', 'legacy_id', 'image', 'description', 'sort', 'is_active', 'in_menu', 'seo_title', 'seo_description',
        'icon', 'on_home', 'default_sort', 'h1', 'seo_text', 'noindex', 'banner'];

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'in_menu' => 'boolean', 'on_home' => 'boolean', 'noindex' => 'boolean'];
    }

    protected static function booted(): void
    {
        static::saving(function (Category $c) {
            $c->slug = Product::makeSlug($c->slug ?: $c->name, static::class, $c->id);
        });
        static::saved(function () {
            foreach (['menu.cats', 'menu.mega', 'home.blocks', 'home.cats'] as $k) {
                \Illuminate\Support\Facades\Cache::forget($k);
            }
        });
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(Category::class, 'parent_id')->orderBy('sort')->orderBy('name');
    }

    public function products(): HasMany
    {
        return $this->hasMany(Product::class);
    }

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('is_active', true);
    }

    /** شناسه این دسته و همه زیردسته‌ها */
    public function descendantIds(): array
    {
        $all = static::query()->get(['id', 'parent_id'])->groupBy('parent_id');
        $out = [$this->id];
        $stack = [$this->id];
        while ($stack) {
            $id = array_pop($stack);
            foreach ($all->get($id, collect()) as $child) {
                if (! in_array($child->id, $out, true)) {
                    $out[] = $child->id;
                    $stack[] = $child->id;
                }
            }
        }

        return $out;
    }

    /**
     * تعداد کالاهای فعال و موجود هر دسته با احتساب زیردسته‌ها (کش ۱۰ دقیقه‌ای؛ یک کوئری گروهی به‌جای ده‌ها کوئری)
     *
     * @return array<int, int>
     */
    public static function productCounts(): array
    {
        return \Illuminate\Support\Facades\Cache::remember('cat.counts', 600, function () {
            $direct = Product::query()->active()->available()->whereNotNull('category_id')
                ->selectRaw('category_id, COUNT(*) n')->groupBy('category_id')->pluck('n', 'category_id')->all();
            $parents = static::query()->pluck('parent_id', 'id')->all();
            $total = [];
            foreach ($direct as $cid => $n) {
                $seen = [];
                for ($c = (int) $cid; $c && ! isset($seen[$c]); $c = (int) ($parents[$c] ?? 0)) {
                    $seen[$c] = true;
                    $total[$c] = ($total[$c] ?? 0) + (int) $n;
                }
            }

            return $total;
        });
    }

    /**
     * درخت دسته‌های فعال برای منوی موبایل (کش)
     *
     * @return array<int, array{id:int,name:string,url:string,icon:?string,n:int,children:array}>
     */
    public static function tree(): array
    {
        return \Illuminate\Support\Facades\Cache::remember('cat.tree.'.setting('url_style', 'default'), 600, function () {
            $counts = static::productCounts();
            $all = static::query()->active()->orderBy('sort')->orderBy('name')->get(['id', 'name', 'slug', 'legacy_id', 'parent_id', 'icon', 'image'])->groupBy(fn ($c) => (int) $c->parent_id);
            $build = function (int $pid, int $depth) use (&$build, $all, $counts) {
                $out = [];
                foreach ($all->get($pid, collect()) as $c) {
                    $n = (int) ($counts[$c->id] ?? 0);
                    if (! $n) {
                        continue;
                    }
                    $out[] = ['id' => $c->id, 'name' => $c->name, 'url' => $c->url(), 'icon' => $c->iconPath() ? thumb($c->iconPath(), 64) : null, 'n' => $n,
                        'children' => $depth < 2 ? $build($c->id, $depth + 1) : []];
                }

                return $out;
            };

            return $build(0, 0);
        });
    }

    /** تصویر نوار دسته‌ها: آیکون PNG یا تصویر دسته */
    public function iconPath(): ?string
    {
        return $this->icon ?: $this->image;
    }

    public function url(): string
    {
        if (\App\Support\LegacyUrls::enabled() && ($u = \App\Support\LegacyUrls::category($this))) {
            return $u;
        }

        return route('category', $this->slug);
    }
}
