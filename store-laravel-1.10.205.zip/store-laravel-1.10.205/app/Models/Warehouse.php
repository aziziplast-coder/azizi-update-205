<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Warehouse extends Model
{
    protected $fillable = ['name', 'code', 'phone', 'address', 'is_active', 'kind', 'buy_rules', 'desk_check', 'loose'];

    public const KINDS = ['carton' => 'عمده (کارتنی)', 'retail' => 'خرده (تکی)'];

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'buy_rules' => 'array', 'desk_check' => 'boolean', 'loose' => 'boolean'];
    }

    protected static function booted(): void
    {
        // قانون‌ها تمیز ذخیره شوند (عدد انگلیسی بدون جداکننده؛ از کم به زیاد)
        static::saving(function (Warehouse $w) {
            if ($w->buy_rules === null) {
                return;
            }
            $n = fn ($v) => (int) en_digits(str_replace([',', '٬', ' '], '', (string) $v));
            $rules = [];
            foreach ((array) $w->buy_rules as $r) {
                if (! is_array($r) || ! in_array($r['mode'] ?? '', ['carton', 'pack', 'bulk'], true)) {
                    continue;
                }
                $rules[] = ['from' => max(0, $n($r['from'] ?? 0)), 'to' => max(0, $n($r['to'] ?? 0)) ?: null, 'mode' => $r['mode'], 'qty' => $r['mode'] === 'carton' ? null : ($n($r['qty'] ?? 0) ?: null)];
            }
            $w->buy_rules = $rules ?: null;
        });
        static::saved(function (Warehouse $w) {
            static::flushRules();
            // «فروش عددی بدون کارتن» روشن/خاموش شد: کالاهای انبار تبدیل یا به حالت قبل برگردانده می‌شوند
            if ($w->wasChanged('loose') && \App\Support\DbSchema::hasColumn('products', 'loose_backup')) {
                static::applyLoose($w, (bool) $w->loose);
            }
        });
        static::deleted(fn () => static::flushRules());
    }

    /** @var array<int, array>|null */
    protected static ?array $rulesMemo = null;

    public static function flushRules(): void
    {
        static::$rulesMemo = null;
        static::$looseMemo = null;
        \Illuminate\Support\Facades\Cache::forget('wh.buy_rules');
        \Illuminate\Support\Facades\Cache::forget('wh.loose');
        \App\Http\Middleware\GuestPageCache::bump();
    }

    /** قانون‌های همه انبارها (کش؛ یک کوئری در روز یا تا تغییر انبار) */
    public static function allRules(): array
    {
        if (static::$rulesMemo !== null) {
            return static::$rulesMemo;
        }
        try {
            return static::$rulesMemo = \Illuminate\Support\Facades\Cache::remember('wh.buy_rules', 86400, function () {
                if (! \App\Support\DbSchema::hasColumn('warehouses', 'buy_rules')) {
                    return [];
                }
                $out = [];
                foreach (static::query()->whereNotNull('buy_rules')->get(['id', 'buy_rules']) as $w) {
                    $rules = array_values(array_filter((array) $w->buy_rules, fn ($r) => is_array($r) && in_array($r['mode'] ?? '', ['carton', 'pack', 'bulk'], true)));
                    if ($rules) {
                        $out[(int) $w->id] = $rules;
                    }
                }

                return $out;
            });
        } catch (\Throwable) {
            return static::$rulesMemo = [];
        }
    }

    /* ---------------- انبار «فروش عددی» (بدون کارتن؛ طبق قانون انبار) ---------------- */

    /** @var array<int, true>|null */
    protected static ?array $looseMemo = null;

    /** شناسه انبارهای عمده‌ای که کارتن ندارند و طبق قانون انبار عددی فروخته می‌شوند */
    public static function looseIds(): array
    {
        if (static::$looseMemo !== null) {
            return static::$looseMemo;
        }
        try {
            return static::$looseMemo = \Illuminate\Support\Facades\Cache::remember('wh.loose', 86400, fn () => \App\Support\DbSchema::hasColumn('warehouses', 'loose')
                ? array_fill_keys(static::query()->where('loose', true)->pluck('id')->map(fn ($v) => (int) $v)->all(), true) : []);
        } catch (\Throwable) {
            return static::$looseMemo = [];
        }
    }

    public static function isLoose(?int $id): bool
    {
        return $id && isset(static::looseIds()[$id]);
    }

    /**
     * تبدیل کالاهای انبار به «عددی»: تعداد در کارتن ← ۱ (فاکتور و حواله: کارتن ۰، فقط عدد؛ گام خرید از قانون انبار)،
     * فروش تکی جدا خاموش (چون همان عمده عددی است)، کالای «فقط تکی» عمده‌اش روشن می‌شود. مقادیر قبلی برای برگشت نگه داشته می‌شوند.
     * خاموش کردن: همه به حالت قبل برمی‌گردند.
     *
     * @return int تعداد کالاهای تغییرکرده
     */
    public static function applyLoose(Warehouse $w, bool $on): int
    {
        $n = 0;
        $now = now();
        if ($on) {
            \App\Models\Product::query()->where('warehouse_id', $w->id)->whereNull('loose_backup')
                ->where(fn ($q) => $q->whereNull('buy_mode')->orWhere('buy_mode', '!=', 'carton')) // «فقط کارتنی»ها دست نمی‌خورند
                ->where(fn ($q) => $q->where('per_carton', '>', 1)->orWhere('carton_enabled', false)->orWhere('retail_enabled', true))
                ->select(['id', 'per_carton', 'carton_enabled', 'retail_enabled', 'in_stock', 'retail_in_stock'])
                ->chunkById(500, function ($rows) use (&$n, $now) {
                    foreach ($rows as $p) {
                        $bak = ['pc' => (int) $p->per_carton, 'ce' => (int) $p->carton_enabled, 're' => (int) $p->retail_enabled, 'in' => (int) $p->in_stock];
                        $upd = ['per_carton' => 1, 'retail_enabled' => false, 'carton_enabled' => true, 'loose_backup' => json_encode($bak), 'updated_at' => $now];
                        if (! $p->carton_enabled) {
                            // کالایی که فقط تکی فروخته می‌شد: موجودی‌اش همان موجودی تکی است
                            $upd['in_stock'] = (bool) $p->in_stock && (bool) $p->retail_in_stock;
                        }
                        \Illuminate\Support\Facades\DB::table('products')->where('id', $p->id)->update($upd);
                        $n++;
                    }
                });
        } else {
            \App\Models\Product::query()->where('warehouse_id', $w->id)->whereNotNull('loose_backup')->select(['id', 'loose_backup'])
                ->chunkById(500, function ($rows) use (&$n, $now) {
                    foreach ($rows as $p) {
                        $b = (array) json_decode((string) $p->loose_backup, true);
                        \Illuminate\Support\Facades\DB::table('products')->where('id', $p->id)->update([
                            'per_carton' => max(1, (int) ($b['pc'] ?? 1)), 'carton_enabled' => (bool) ($b['ce'] ?? 1), 'retail_enabled' => (bool) ($b['re'] ?? 0),
                            'in_stock' => (bool) ($b['in'] ?? 1), 'loose_backup' => null, 'updated_at' => $now,
                        ]);
                        $n++;
                    }
                });
        }
        static::$looseMemo = null;
        \Illuminate\Support\Facades\Cache::forget('wh.loose');
        \Illuminate\Support\Facades\Cache::forget('home.blocks');
        \App\Http\Middleware\GuestPageCache::bump();

        return $n;
    }

    /** قانون بازه قیمتی که برای این قیمت در این انبار برقرار است ({mode, qty} یا null) */
    public static function buyRuleFor(int $warehouseId, int $price): ?array
    {
        foreach (static::allRules()[$warehouseId] ?? [] as $r) {
            $from = (int) ($r['from'] ?? 0);
            $to = (int) ($r['to'] ?? 0);
            if ($price >= $from && ($to <= 0 || $price <= $to)) {
                return $r;
            }
        }

        return null;
    }

    public function keepers(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'user_warehouse');
    }

    public function label(): string
    {
        return $this->code && ! str_contains($this->name, (string) $this->code) && ! str_contains($this->name, fa((string) $this->code)) ? $this->name.' ('.$this->code.')' : $this->name;
    }
}
