<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class LiveChat extends Model
{
    protected $guarded = [];

    protected function casts(): array
    {
        return ['last_at' => 'datetime', 'page' => 'array', 'staff_at' => 'datetime', 'assigned_at' => 'datetime', 'human' => 'boolean'];
    }

    public function messages(): HasMany
    {
        return $this->hasMany(LiveMessage::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function staff(): BelongsTo
    {
        return $this->belongsTo(User::class, 'staff_id');
    }

    public function label(): string
    {
        return $this->user?->name ?: ($this->name ?: ($this->mobile ? fa($this->mobile) : 'مهمان '.strtoupper(substr($this->vid, 0, 4))));
    }
}
