<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PushCampaign extends Model
{
    public const AUDIENCES = [
        'all' => 'همه مشترکان',
        'customers' => 'فقط مشتریان واردشده',
        'guests' => 'فقط بازدیدکنندگان بدون ورود',
        'staff' => 'فقط کارکنان',
    ];

    protected $fillable = ['title', 'body', 'url', 'image', 'audience', 'sent', 'failed', 'user_id'];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
