<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** یک بار انبارگردانی (مقایسه هلو با اسکن انبار) */
class Stocktake extends Model
{
    protected $fillable = ['created_by', 'settings', 'stats'];

    protected function casts(): array
    {
        return ['settings' => 'array', 'stats' => 'array'];
    }

    public function items(): HasMany
    {
        return $this->hasMany(StocktakeItem::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function label(): string
    {
        return jdate($this->created_at, true).' — '.fa((int) ($this->stats['missing'] ?? 0)).' کالای گم‌شده';
    }
}
