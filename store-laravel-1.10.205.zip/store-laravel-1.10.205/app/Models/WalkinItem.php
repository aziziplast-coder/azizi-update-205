<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WalkinItem extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['s_at' => 'integer', 'd_at' => 'integer'];

    protected static function booted(): void
    {
        // زمان اولین اسکن و اولین تحویل هر قلم: ملاک ترتیب اکسل و فهرست تحویل
        static::saving(function (WalkinItem $i) {
            $ms = (int) floor(microtime(true) * 1000);
            if ((int) $i->units > 0 && ! $i->s_at) {
                $i->s_at = $ms;
            }
            if ($i->isDirty('d_units')) {
                $i->d_at = (int) $i->d_units > 0 ? ($i->d_at ?: $ms) : null;
            }
        });
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /** تعداد نهایی: پس از تحویل، شمارش تحویل‌دهنده */
    public function finalUnits(): int
    {
        return $this->d_units !== null ? (int) $this->d_units : (int) $this->units;
    }

    public function qtyLabel(?int $u = null): string
    {
        $u ??= (int) $this->units;
        $per = max(1, (int) $this->per);
        if ($per > 1 && $u >= $per) {
            $c = intdiv($u, $per);
            $r = $u % $per;

            return fa($c).' کارتن'.($r ? ' و '.fa($r).' عدد' : '').' ('.fa($u).' عدد)';
        }

        return fa($u).' عدد';
    }
}
