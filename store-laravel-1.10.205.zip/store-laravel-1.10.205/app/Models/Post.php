<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** مقاله وبلاگ */
class Post extends Model
{
    protected $fillable = [
        'post_category_id', 'author_id', 'title', 'slug', 'excerpt', 'body', 'image', 'image_alt', 'tags', 'faq', 'product_ids',
        'is_published', 'published_at', 'seo_title', 'seo_description', 'focus_keyword', 'canonical', 'noindex', 'views', 'legacy_path', 'legacy_id', 'legacy_slug',
    ];

    protected function casts(): array
    {
        return [
            'tags' => 'array',
            'faq' => 'array',
            'product_ids' => 'array',
            'is_published' => 'boolean',
            'noindex' => 'boolean',
            'published_at' => 'datetime',
        ];
    }

    protected static function booted(): void
    {
        static::saving(function (Post $p) {
            $p->slug = Product::makeSlug($p->slug ?: $p->title, static::class, $p->id);
            if ($p->is_published && ! $p->published_at) {
                $p->published_at = now();
            }
        });
        static::saved(function () {
            \Illuminate\Support\Facades\Cache::forget('home.blocks');
            \Illuminate\Support\Facades\Cache::forget('blog.has');
        });
        static::deleted(fn () => \Illuminate\Support\Facades\Cache::forget('blog.has'));
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(PostCategory::class, 'post_category_id');
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(User::class, 'author_id');
    }

    public function scopePublished(Builder $q): Builder
    {
        return $q->where('is_published', true)->where(fn ($w) => $w->whereNull('published_at')->orWhere('published_at', '<=', now()));
    }

    public function url(): string
    {
        // شکل لینک سایت قبلی: /blog-134/عنوان (فاصله = %20، مثل عزیزی‌پلاست)
        $a = $this->getAttributes();
        if (! empty($a['legacy_id']) && \App\Support\LegacyUrls::enabled()) {
            return url('/blog-'.$a['legacy_id'].'/'.rawurlencode(trim((string) (($a['legacy_slug'] ?? null) ?: ($a['title'] ?? '')))));
        }

        return route('blog.post', $this->slug);
    }

    public function readingMinutes(): int
    {
        $words = count(preg_split('/\s+/u', trim(strip_tags((string) $this->body))) ?: []);

        return max(1, (int) ceil($words / 200));
    }

    public function summary(int $len = 160): string
    {
        $t = $this->excerpt ?: strip_tags((string) $this->body);

        return \Illuminate\Support\Str::limit(trim(preg_replace('/\s+/u', ' ', html_entity_decode($t))), $len);
    }

    /**
     * بدنه با شناسه برای تیترها + فهرست مطالب
     *
     * @return array{0: string, 1: array<int, array{id: string, text: string, level: int}>}
     */
    public function bodyWithToc(): array
    {
        $toc = [];
        $i = 0;
        $html = preg_replace_callback('#<h([23])([^>]*)>(.*?)</h\1>#isu', function ($m) use (&$toc, &$i) {
            $text = trim(strip_tags($m[3]));
            if ($text === '') {
                return $m[0];
            }
            $id = 's'.(++$i);
            $toc[] = ['id' => $id, 'text' => $text, 'level' => (int) $m[1]];
            $attrs = preg_replace('/\sid="[^"]*"/i', '', $m[2]);

            return '<h'.$m[1].$attrs.' id="'.$id.'">'.$m[3].'</h'.$m[1].'>';
        }, clean_html($this->body));

        return [$html, $toc];
    }
}
