<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** وضعیت پست یک کالا در یک کانال ربات */
class BotPost extends Model
{
    public const STATES = ['ok' => 'در کانال', 'hold' => 'منتظر تأیید شما', 'new' => 'منتظر ارسال', 'edit' => 'منتظر ویرایش', 'delete' => 'منتظر حذف', 'repost' => 'منتظر ارسال دوباره', 'gone' => 'حذف شد (ناموجود)', 'skip' => 'نادیده', 'failed' => 'ناموفق'];

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['avail' => 'boolean', 'extra_ids' => 'array', 'next_try_at' => 'datetime', 'lease_until' => 'datetime', 'sent_at' => 'datetime', 'unavail_at' => 'datetime'];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function profile(): BelongsTo
    {
        return $this->belongsTo(BotProfile::class, 'profile_id');
    }
}
