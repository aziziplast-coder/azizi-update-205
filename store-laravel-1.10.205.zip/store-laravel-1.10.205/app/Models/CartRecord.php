<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** سبد خرید ماندگار (مهمان با کوکی، مشتری با حساب) — برای سبدهای رها شده هم استفاده می‌شود */
class CartRecord extends Model
{
    protected $table = 'carts';

    protected $fillable = ['token', 'user_id', 'items', 'stage', 'info', 'items_count', 'total', 'order_id', 'edit_order_id', 'reminded_at', 'last_activity_at', 'prices'];

    public const STAGES = [
        'cart' => 'سبد خرید',
        'checkout' => 'ورود به صفحه تسویه',
        'info' => 'اطلاعات گیرنده',
        'shipping' => 'انتخاب شیوه ارسال',
        'payment' => 'انتخاب شیوه تسویه',
        'placed' => 'سفارش ثبت شد',
        'converted' => 'تبدیل به سفارش (مدیر)',
    ];

    public const STAGE_STEP = ['cart' => 1, 'checkout' => 2, 'info' => 3, 'shipping' => 4, 'payment' => 5, 'placed' => 6, 'converted' => 6];

    protected function casts(): array
    {
        return [
            'items' => 'array',
            'info' => 'array',
            'prices' => 'array',
            'reminded_at' => 'datetime',
            'last_activity_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function stageLabel(): string
    {
        return self::STAGES[$this->stage] ?? $this->stage;
    }

    /** ثبت پیشرفت مشتری (فقط رو به جلو) */
    public function advance(string $stage, array $info = []): void
    {
        if ((self::STAGE_STEP[$stage] ?? 0) > (self::STAGE_STEP[$this->stage] ?? 0)) {
            $this->stage = $stage;
        }
        if ($info) {
            $this->info = array_merge((array) $this->info, array_filter($info, fn ($v) => $v !== null && $v !== ''));
        }
        $this->last_activity_at = now();
        $this->save();
    }

    public function mobile(): ?string
    {
        return $this->user?->mobile ?: (($this->info['mobile'] ?? null) ?: null);
    }

    public function customerName(): string
    {
        return ($this->info['name'] ?? '') ?: ($this->user?->name ?: ($this->user ? $this->user->mobile : 'مهمان'));
    }

    /** سبدهای رها شده: کالا دارند، سفارش نشده‌اند و مدتی فعالیتی نداشته‌اند */
    public static function abandonedQuery(): \Illuminate\Database\Eloquent\Builder
    {
        $min = max(5, (int) setting('abandoned_after', 60));

        return static::query()->whereNull('order_id')->whereNull('edit_order_id')->where('items_count', '>', 0)
            ->where('last_activity_at', '<', now()->subMinutes($min));
    }
}
