<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StocktakeItem extends Model
{
    protected $fillable = ['stocktake_id', 'kind', 'code', 'barcode', 'name', 'product_id', 'holoo_qty', 'branch_qty', 'net_qty', 'price', 'value', 'streak'];
}
