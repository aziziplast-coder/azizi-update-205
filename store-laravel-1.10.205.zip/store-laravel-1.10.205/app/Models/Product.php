<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Support\Search;
use Illuminate\Support\Facades\Cache;

/**
 * قیمت‌ها «هر عدد» هستند. خرید کارتنی مضربی از «تعداد در کارتن» است؛ خرید خرد (تکی)
 * کمتر از یک کارتن، با قیمت و انبار جداگانه.
 */
class Product extends Model
{
    public const CARTON = 'carton';

    public const RETAIL = 'retail';

    /** تغییر دستی کد در همین ذخیره (برای تاریخچه) — ستون جدول نیست */
    public ?array $codeLog = null;

    protected $fillable = [
        'category_id', 'name', 'slug', 'legacy_id', 'legacy_slug', 'restock_at', 'restock_by', 'restock_note', 'barcode', 'sku', 'short_description', 'description', 'image', 'gallery', 'specs',
        'price', 'compare_price', 'per_carton', 'carton_enabled', 'in_stock', 'stock', 'warehouse_id',
        'retail_enabled', 'retail_price', 'retail_in_stock', 'retail_stock', 'retail_max', 'retail_warehouse_id',
        'is_active', 'is_featured', 'sort', 'sales_count', 'views', 'seo_title', 'seo_description',
        'related_ids', 'related_auto', 'is_amazing', 'amazing_sort', 'offer_ends_at', 'h1', 'noindex', 'focus_keyword',
        'sync_source_id', 'sync_code', 'old_codes', 'sync_locked', 'unit_label', 'unit_manual', 'import_id', 'review', 'changed_at',
        'buy_mode', 'buy_qty',
    ];

    protected function casts(): array
    {
        return [ 'restock_at' => 'datetime',
            'gallery' => 'array',
            'specs' => 'array',
            'price' => 'integer',
            'compare_price' => 'integer',
            'per_carton' => 'integer',
            'carton_enabled' => 'boolean',
            'in_stock' => 'boolean',
            'stock' => 'integer',
            'retail_enabled' => 'boolean',
            'retail_price' => 'integer',
            'retail_in_stock' => 'boolean',
            'retail_stock' => 'integer',
            'retail_max' => 'integer',
            'is_active' => 'boolean',
            'is_featured' => 'boolean',
            'related_ids' => 'array',
            'related_auto' => 'boolean',
            'is_amazing' => 'boolean',
            'changed_at' => 'datetime',
            'stock_at' => 'datetime',
            'retail_stock_at' => 'datetime',
            'noindex' => 'boolean',
            'offer_ends_at' => 'datetime',
            'sync_locked' => 'boolean',
            'unit_manual' => 'boolean',
            'buy_qty' => 'integer',
        ];
    }

    protected static function booted(): void
    {
        static::saving(function (Product $p) {
            $p->slug = static::makeSlug($p->slug ?: $p->name, static::class, $p->id);
            if (\App\Support\SeoAuto::enabled() && (blank($p->seo_title) || blank($p->seo_description))) {
                \App\Support\SeoAuto::product($p);
            }
            $p->per_carton = max(1, (int) $p->per_carton);
            // کالای ناموجود قدیمی که خودکار پنهان شده بود و دوباره موجود شد: به سایت برمی‌گردد
            if ($p->exists && $p->review === 'stale' && ! $p->is_active && $p->isDirty(['in_stock', 'stock', 'retail_in_stock', 'retail_stock']) && $p->isAvailable()) {
                $p->is_active = true;
                $p->review = null;
            } elseif ($p->review === 'stale' && $p->isDirty('is_active') && $p->is_active) {
                $p->review = null;
            }
            // روشن کردن «نمایش در سایت» = تأیید کالای منتظر تأیید
            if ($p->exists && $p->review && $p->isDirty('is_active') && $p->is_active) {
                $p->review = null;
            }
            // آخرین تغییر قیمت یا موجودی (برای «ناموجودهای قدیمی»)
            if (! $p->exists || $p->isDirty(['price', 'compare_price', 'in_stock', 'stock', 'retail_in_stock', 'retail_stock', 'retail_price', 'per_carton'])) {
                $p->changed_at = now();
            }
            // موجودی بی‌نهایت: فقط «موجود / ناموجود» مهم است؛ عدد موجودی معنا ندارد
            if (static::unlimited()) {
                static::onlyStatus($p);
            }
            // تنظیم مستقیم موجودی (فرم کالا) ← سفارش‌های قبلی هنگام لغو موجودی را برنمی‌گردانند
            if ($p->exists && static::hasStockAt()) {
                foreach (['stock', 'retail_stock'] as $c) {
                    if ($p->isDirty($c) && ! $p->isDirty($c.'_at')) {
                        $p->{$c.'_at'} = now();
                    }
                }
            }
            $p->unit_label = static::cleanUnit($p->unit_label);
            if ($p->per_carton < 2) {
                $p->retail_enabled = false;
            }
            if ($p->compare_price !== null && $p->compare_price <= $p->price) {
                $p->compare_price = null;
            }
            if ($p->barcode !== null) {
                $p->barcode = trim(en_digits($p->barcode)) ?: null;
            }
            // هر کالا فقط یک کد دارد: کد فعلی هلو. با عوض شدن کد، کد همگام‌سازی هم همان می‌شود (کد قدیمی جایی نمی‌ماند)
            if ($p->isDirty('sku') && $p->sku !== null && $p->sku !== '') {
                if ($p->sync_code !== null) {
                    $p->sync_code = $p->sku;
                }
                $old = trim((string) $p->getOriginal('sku'));
                if ($p->exists && $old !== '' && ! \App\Services\CodeChanges::$silent && \App\Services\CodeChanges::ready()) {
                    $p->codeLog = [$old, (string) $p->sku]; // فقط برای تاریخچه تغییر کدها
                }
            }
            if ($p->isDirty(['name', 'sku', 'barcode', 'category_id']) || ! $p->search_key) {
                $p->search_key = Search::productKey($p);
            }
        });
        // کالای تازه (دستی یا آپلود گروهی): شناسه یکتا به شکل سایت قبلی — /product-شماره/نام
        static::creating(function (Product $p) {
            if (empty($p->legacy_id) && \App\Support\DbSchema::hasColumn('products', 'legacy_id')) {
                $p->legacy_id = \App\Support\LegacyUrls::nextId();
            }
        });
        static::saved(function (Product $p) {
            Cache::forget('search.vocab');
            if ($p->codeLog) {
                [$old, $new] = $p->codeLog;
                $p->codeLog = null;
                try {
                    \Illuminate\Support\Facades\DB::table('product_code_changes')->insert(['product_id' => $p->id, 'old_code' => $old, 'new_code' => $new, 'status' => 'applied',
                        'source' => 'manual', 'score' => 100, 'reason' => 'ویرایش دستی کد', 'user_id' => auth()->id(), 'created_at' => now(), 'updated_at' => now()]);
                } catch (\Throwable) {
                }
            }
        });
    }

    public static function makeSlug(string $text, string $model, ?int $ignoreId = null): string
    {
        $s = str_replace(['ي', 'ك', '‌'], ['ی', 'ک', '-'], trim($text));
        $s = preg_replace('/[^\p{L}\p{N}]+/u', '-', mb_strtolower($s));
        $s = trim($s, '-') ?: 'item';
        $s = mb_substr($s, 0, 150);
        $base = $s;
        $q = fn () => $model::query()->when($ignoreId, fn ($x) => $x->where('id', '!=', $ignoreId));
        if (! $q()->where('slug', $base)->exists()) {
            return $base;
        }
        // به‌جای امتحان یکی‌یکی (کند برای هزاران نام مشابه)، بزرگ‌ترین شماره موجود پیدا می‌شود
        $max = 1;
        foreach ($q()->where('slug', 'like', $base.'-%')->pluck('slug') as $taken) {
            $tail = substr($taken, strlen($base) + 1);
            if ($tail !== '' && ctype_digit($tail)) {
                $max = max($max, (int) $tail);
            }
        }
        $s = $base.'-'.($max + 1);
        while ($q()->where('slug', $s)->exists()) {
            $s = $base.'-'.(++$max + 1);
        }

        return $s;
    }

    /* ---------------- روابط ---------------- */

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function warehouse(): BelongsTo
    {
        return $this->belongsTo(Warehouse::class);
    }

    public function retailWarehouse(): BelongsTo
    {
        return $this->belongsTo(Warehouse::class, 'retail_warehouse_id');
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(Review::class);
    }

    public function attributeValues(): BelongsToMany
    {
        return $this->belongsToMany(AttributeValue::class, 'product_attribute_value')->with('attribute');
    }

    /** ویژگی‌ها گروه‌بندی‌شده: [[attribute, [values]]] */
    public function attributeGroups(): array
    {
        $out = [];
        foreach ($this->attributeValues->sortBy(fn ($v) => [$v->attribute?->sort, $v->sort]) as $v) {
            if (! $v->attribute) {
                continue;
            }
            $out[$v->attribute_id] ??= ['attr' => $v->attribute, 'values' => []];
            $out[$v->attribute_id]['values'][] = $v;
        }

        return array_values($out);
    }

    /**
     * کالاهای مشابه: انتخاب دستی + (در حالت خودکار) کالاهای هم‌نام و هم‌دسته.
     *
     * @return \Illuminate\Support\Collection<int, Product>
     */
    public function relatedProducts(int $limit = 8)
    {
        $manual = array_values(array_filter(array_map('intval', (array) $this->related_ids)));
        $items = collect();
        if ($manual) {
            $items = static::query()->active()->with('category')->whereIn('id', $manual)->get()
                ->sortBy(fn ($p) => array_search($p->id, $manual))->values();
        }
        if ($this->related_auto && $items->count() < $limit) {
            $ids = static::similarIds($this->name, $this->category_id, $this->id, $limit * 2);
            $more = static::query()->active()->available()->with('category')->whereIn('id', array_diff($ids, $items->pluck('id')->all()))->get()
                ->sortBy(fn ($p) => array_search($p->id, $ids));
            $items = $items->concat($more);
            if ($items->count() < $limit && $this->category_id) {
                $items = $items->concat(static::query()->active()->available()->with('category')->where('category_id', $this->category_id)
                    ->whereNotIn('id', $items->pluck('id')->push($this->id)->all())->latest('id')->limit($limit - $items->count())->get());
            }
        }

        return $items->reject(fn ($p) => $p->id === $this->id)->take($limit)->values();
    }

    /**
     * شناسه کالاهای مشابه بر اساس واژه اصلی نام (مثلاً همه «جاپیازی»ها)، با اولویت هم‌دسته‌ها.
     *
     * @return array<int, int>
     */
    public static function similarIds(?string $name, ?int $categoryId = null, ?int $exceptId = null, int $limit = 30): array
    {
        $words = array_values(array_filter(Search::words($name), fn ($w) => mb_strlen($w) >= 3 && ! ctype_digit($w)));
        if (! $words) {
            return [];
        }
        $first = Search::key($words[0]);
        $q = static::query()->where('search_key', 'like', '%|'.$first.'%')
            ->when($exceptId, fn ($x) => $x->whereKeyNot($exceptId));
        $rows = $q->limit(400)->get(['id', 'name', 'category_id']);
        $keys = array_map(fn ($w) => Search::key($w), $words);

        return $rows->map(function ($p) use ($keys, $categoryId) {
            $pk = array_map(fn ($w) => Search::key($w), Search::words($p->name));
            $score = count(array_intersect($keys, $pk)) * 2 + ($categoryId && $p->category_id === $categoryId ? 3 : 0);

            return ['id' => $p->id, 's' => $score];
        })->sortByDesc('s')->take($limit)->pluck('id')->all();
    }

    /** پیشنهاد دسته بر اساس شباهت نام با کالاهای هر دسته و نام دسته‌ها */
    public static function guessCategory(?string $name, ?int $exceptId = null, ?array $only = null): ?int
    {
        $only = $only !== null ? array_flip(array_map('intval', $only)) : null; // فقط همین دسته‌ها (مثلاً زیردسته‌های «بلور»)
        $words = array_values(array_filter(Search::words($name), fn ($w) => mb_strlen($w) >= 3 && ! ctype_digit($w)));
        if (! $words) {
            return null;
        }
        $keys = array_map(fn ($w) => Search::key($w), $words);
        $score = [];
        foreach (Category::query()->get(['id', 'name']) as $c) {
            if ($only !== null && ! isset($only[$c->id])) {
                continue;
            }
            $ck = Search::key($c->name);
            foreach ($keys as $i => $k) {
                if ($ck !== '' && (str_contains($ck, $k) || str_contains($k, $ck))) {
                    $score[$c->id] = ($score[$c->id] ?? 0) + ($i === 0 ? 6 : 3);
                }
            }
        }
        $rows = static::query()->whereNotNull('category_id')->when($exceptId, fn ($x) => $x->whereKeyNot($exceptId))
            ->when($only !== null, fn ($x) => $x->whereIn('category_id', array_keys($only) ?: [0]))
            ->where(function ($w) use ($keys) {
                foreach ($keys as $k) {
                    $w->orWhere('search_key', 'like', '%|'.$k.'%');
                }
            })->limit(500)->get(['id', 'name', 'category_id']);
        foreach ($rows as $p) {
            $pk = array_map(fn ($w) => Search::key($w), Search::words($p->name));
            foreach ($keys as $i => $k) {
                if (in_array($k, $pk, true)) {
                    $score[$p->category_id] = ($score[$p->category_id] ?? 0) + ($i === 0 ? 2 : 1);
                }
            }
        }
        if (! $score) {
            return null;
        }
        arsort($score);

        return (int) array_key_first($score);
    }

    /* ---------------- اسکوپ‌ها ---------------- */

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('is_active', true);
    }

    /** همان شرط scopeAvailable به‌صورت عبارت SQL (برای بردن ناموجودها به انتهای فهرست) */
    public const AVAILABLE_SQL = '(in_stock = 1 AND ((carton_enabled = 1 AND (stock IS NULL OR stock >= per_carton))'
        .' OR (retail_enabled = 1 AND per_carton > 1 AND retail_in_stock = 1 AND (retail_stock IS NULL OR retail_stock > 0))))';

    /** موجودها اول، ناموجودها انتهای فهرست (پیش از بقیه مرتب‌سازی‌ها) */
    public static function availableFirst(Builder $q): Builder
    {
        $base = $q->getQuery();
        $base->orders = array_merge([['type' => 'Raw', 'sql' => 'CASE WHEN '.self::AVAILABLE_SQL.' THEN 0 ELSE 1 END']], (array) $base->orders);

        return $q;
    }

    /** قابل خرید در حداقل یکی از دو حالت */
    public function scopeAvailable(Builder $q): Builder
    {
        return $q->where('in_stock', true)->where(function ($w) {
            $w->where(function ($c) {
                $c->where('carton_enabled', true)->where(fn ($s) => $s->whereNull('stock')->orWhereColumn('stock', '>=', 'per_carton'));
            })->orWhere(function ($r) {
                $r->where('retail_enabled', true)->where('per_carton', '>', 1)->where('retail_in_stock', true)
                    ->where(fn ($s) => $s->whereNull('retail_stock')->orWhere('retail_stock', '>', 0));
            });
        });
    }

    public function scopeOnSale(Builder $q): Builder
    {
        return $q->whereNotNull('compare_price')->whereColumn('compare_price', '>', 'price');
    }

    public function scopeSearch(Builder $q, ?string $term): Builder
    {
        $term = trim((string) $term);

        return $term === '' ? $q : Search::apply($q, $term);
    }

    /** تخفیف زمان‌دار هنوز معتبر است */
    public function offerActive(): bool
    {
        return $this->discountPercent() > 0 && (! $this->offer_ends_at || $this->offer_ends_at->isFuture());
    }

    /* ---------------- منطق فروش ---------------- */

    public function hasCartons(): bool
    {
        return $this->per_carton > 1;
    }

    /** واحد خرید در حالت عمده: «کارتن» یا برای کالای تکی «عدد» */
    public function cartonUnit(): string
    {
        return $this->hasCartons() ? 'کارتن' : $this->unitName();
    }

    /**
     * حالت ثبت در سفارش: کالای «تعداد در کارتن ۱» (مثل جاروشارژی که تک‌عددی فروخته می‌شود ولی کارتن واقعی‌اش بیشتر است)
     * در سفارش «خرده» حساب می‌شود: انبار خرده، کارتابل خرده و ستون عدد اکسل هلو. (تنظیمات سفارش)
     */
    public function orderMode(string $mode): string
    {
        return $mode === self::CARTON && (int) $this->per_carton <= 1 && setting('single_as_retail', true) ? self::RETAIL : $mode;
    }

    public function retailAllowed(): bool
    {
        return $this->retail_enabled && $this->hasCartons();
    }

    public function cartonAvailable(): bool
    {
        if (! $this->carton_enabled || ! $this->in_stock) {
            return false;
        }

        return $this->stock === null || (static::unlimited() && $this->stock > 0) || $this->stock >= $this->buyRule()[0];
    }

    /** بیشترین تعداد (عدد) قابل خرید کارتنی؛ ‎-1 یعنی نامحدود */
    /* ---------------- زمان تنظیم مستقیم موجودی ---------------- */

    protected static ?bool $stockAtCol = null;

    public static function hasStockAt(): bool
    {
        if (static::$stockAtCol === null) {
            try {
                static::$stockAtCol = \Illuminate\Support\Facades\Schema::hasColumn('products', 'stock_at');
            } catch (\Throwable) {
                static::$stockAtCol = false;
            }
        }

        return static::$stockAtCol;
    }

    /**
     * «موجودی بی‌نهایت» (تنظیمات ← سفارش‌ها): کالای موجود سقف تعداد ندارد؛ هر عدد مثبت = بدون محدودیت.
     * فقط ۰ (ناموجود) معنا دارد و کم/زیاد شدن موجودی با سفارش‌ها انجام نمی‌شود.
     */
    public static function unlimited(): bool
    {
        return (bool) setting('stock_unlimited', true);
    }

    /**
     * حالت بی‌نهایت: وضعیت کالا فقط با کلیدهای «موجود» تعیین می‌شود.
     * - عدد مثبت ← بدون محدودیت
     * - «موجود است» روشن شد ← کارتنی هم باز می‌شود (۰ قبلی پاک می‌شود)؛ همین‌طور «تکی موجود است»
     * - موجودی ۰ ← کلید «موجود» خاموش (مگر کالا فقط کارتنی‌اش تمام شده و خرید تکی‌اش باز است؛ آن‌وقت ۰ یعنی «کارتنی ناموجود»)
     */
    public static function onlyStatus(Product $p): void
    {
        foreach (['stock', 'retail_stock'] as $c) {
            if ($p->{$c} !== null && (int) $p->{$c} > 0) {
                $p->{$c} = null;
            }
        }
        if ($p->isDirty('in_stock') && $p->in_stock && ! $p->isDirty('stock')) {
            $p->stock = null;
        }
        if ($p->isDirty('retail_in_stock') && $p->retail_in_stock && ! $p->isDirty('retail_stock')) {
            $p->retail_stock = null;
        }
        if ($p->retail_stock !== null && (int) $p->retail_stock <= 0) {
            $p->retail_stock = null;
            $p->retail_in_stock = false;
        }
        if ($p->stock !== null && (int) $p->stock <= 0) {
            $retailOpen = $p->retail_enabled && (int) $p->per_carton > 1 && $p->retail_in_stock;
            if (! $retailOpen) {
                $p->stock = null;
                $p->in_stock = false;
            } else {
                $p->stock = 0;
            }
        }
    }

    /** کالا (کارتنی یا تکی) در انبار نبود ← ناموجود */
    public static function markOut(int $id, string $col): void
    {
        if (! static::unlimited()) {
            static::query()->whereKey($id)->update(static::stampStock([$col => 0]));

            return;
        }
        $p = static::query()->find($id);
        if (! $p) {
            return;
        }
        $p->{$col} = 0;
        static::onlyStatus($p);
        $p->saveQuietly();
    }

    /** آیا موجودی عددی با سفارش‌ها کم و زیاد شود؟ */
    public static function counts(): bool
    {
        return ! static::unlimited();
    }

    /** در حالت بی‌نهایت، عدد مثبت موجودی ← بدون محدودیت (null) */
    public static function unlimitStock(array $upd): array
    {
        if (static::unlimited()) {
            foreach (['stock', 'retail_stock'] as $c) {
                if (array_key_exists($c, $upd) && $upd[$c] !== null && (int) $upd[$c] > 0) {
                    $upd[$c] = null;
                }
            }
        }

        return $upd;
    }

    /** به آرایه به‌روزرسانی مستقیم موجودی، زمان تنظیم را اضافه می‌کند */
    public static function stampStock(array $upd): array
    {
        $upd = static::unlimitStock($upd);
        if (static::hasStockAt()) {
            foreach (['stock', 'retail_stock'] as $c) {
                if (array_key_exists($c, $upd) && ! array_key_exists($c.'_at', $upd)) {
                    $upd[$c.'_at'] = now();
                }
            }
        }

        return $upd;
    }

    /**
     * آیا سفارشی که در $since ثبت شده می‌تواند موجودی این ستون را برگرداند؟
     * اگر بعد از ثبت سفارش، موجودی مستقیم تنظیم شده (اکسل، اسکن، ناموجودی در انبار، فرم کالا) ← خیر؛
     * وگرنه مثلاً کالایی که در انبار «ناموجود» (۰) شده، با لغو یک سفارش قدیمی دوباره ۱۲ عدد می‌شود و خرید را به ۱ کارتن محدود می‌کند.
     */
    public function stockRestorable(string $col, $since): bool
    {
        if (! static::hasStockAt() || ! $since) {
            return true;
        }
        $at = $this->{$col.'_at'};

        return ! $at || \Illuminate\Support\Carbon::parse($at)->lte(\Illuminate\Support\Carbon::parse($since));
    }

    public function cartonMaxUnits(): int
    {
        if ($this->stock === null || (static::unlimited() && $this->stock > 0)) {
            return -1;
        }
        [$min, $step] = $this->buyRule();
        $s = max(0, (int) $this->stock);

        return $s < $min ? 0 : $min + intdiv($s - $min, $step) * $step;
    }

    /* ---------------- قانون خرید عمده (حداقل خرید و گام) ---------------- */

    public const BUY_MODES = [
        'carton' => 'کارتن کامل',
        'pack' => 'بسته‌ای (هر بار N عدد)',
        'bulk' => 'فله (حداقل N، بعد یکی‌یکی)',
    ];

    /** @var array{0:int,1:int,2:bool}|null */
    protected ?array $buyRuleCache = null;

    /**
     * [حداقل خرید، گام افزایش، آیا با کارتن کامل فرق دارد] در خرید عمده — به عدد.
     * ترتیب: تنظیم خود کالا ← قانون بازه قیمتِ انبار عمده کالا ← کارتن کامل (مثل قبل).
     *
     * @return array{0:int,1:int,2:bool}
     */
    public function buyRule(): array
    {
        $sig = $this->buy_mode.'|'.$this->buy_qty.'|'.$this->per_carton.'|'.$this->price.'|'.$this->warehouse_id;
        if ($this->buyRuleCache !== null && ($this->buyRuleCache[3] ?? null) === $sig) {
            return $this->buyRuleCache;
        }
        $pc = max(1, (int) $this->per_carton);
        $mode = $this->buy_mode;
        $qty = (int) $this->buy_qty;
        if (! $mode && $this->warehouse_id) {
            if ($r = Warehouse::buyRuleFor((int) $this->warehouse_id, (int) $this->price)) {
                [$mode, $qty] = [$r['mode'], (int) ($r['qty'] ?? 0)];
            }
        }
        $n = max(1, $qty ?: $pc);
        [$min, $step] = match ($mode) {
            'pack' => [$n, $n],
            'bulk' => [$n, 1],
            default => [$pc, $pc],
        };

        return $this->buyRuleCache = [$min, $step, ! ($min === $pc && $step === $pc), $sig];
    }

    /** بارکد برای نمایش به مشتری: بارکد، وگرنه کد کالا (کد هلو) */
    public function displayCode(): string
    {
        return trim((string) ($this->barcode ?: ($this->sku ?: $this->sync_code)));
    }

    /** متن کوتاه قانون خرید برای مشتری: «حداقل ۶ عدد، بعد ۱ تا ۱ تا» */
    public function buyRuleText(): ?string
    {
        [$min, $step, $custom] = $this->buyRule();
        if (! $custom) {
            return null;
        }
        $u = $this->unitName();
        if ($min === $step) {
            return 'فروش در بسته‌های '.fa($step).($u === 'عدد' ? ' عددی' : ' تایی ('.$u.')');
        }

        return 'حداقل خرید '.fa($min).' '.$u.'، بعد '.($step === 1 ? 'یکی‌یکی' : fa($step).' تا '.fa($step).' تا');
    }

    public function retailAvailable(): bool
    {
        return $this->retailAllowed() && $this->in_stock && $this->retail_in_stock
            && ($this->retail_stock === null || $this->retail_stock > 0);
    }

    public function retailMaxUnits(): int
    {
        // سقف خرید تکی: مقدار اختصاصی کالا، وگرنه درصدی از تعداد کارتن (پیش‌فرض نصف کارتن؛ از تنظیمات قابل تغییر)
        $pct = max(1, min(100, (int) setting('retail_max_pct', 50)));
        $def = max(1, (int) floor($this->per_carton * $pct / 100));
        $max = ($this->retail_max && $this->retail_max < $this->per_carton) ? $this->retail_max : min($def, max(1, $this->per_carton - 1));
        if ($this->retail_stock !== null && ! (static::unlimited() && $this->retail_stock > 0)) {
            $max = min($max, max(0, $this->retail_stock));
        }

        return max(0, $max);
    }

    public function isAvailable(): bool
    {
        return $this->cartonAvailable() || $this->retailAvailable();
    }

    /* ---------------- واحد فروش ---------------- */

    /** واحد فروش کامل: «جفت»، «دست ۶ عددی»، «پک ۳ عددی» (پیش‌فرض «عدد») */
    public function unitFull(): string
    {
        return $this->unit_label ?: 'عدد';
    }

    /** نام کوتاه واحد برای «هر …» و تعداد: «جفت»، «دست»، «پک» */
    public function unitName(): string
    {
        return static::unitNameOf($this->unit_label);
    }

    public static function unitNameOf(?string $label): string
    {
        $label = trim((string) $label);
        if ($label === '') {
            return 'عدد';
        }

        return preg_split('/\s+/u', $label)[0] ?: 'عدد';
    }

    /** «کارتن ۱۲ جفتی» / «کارتن ۱۲ دست ۶ عددی» / «کارتن ۱۲ عددی» */
    public function cartonText(): string
    {
        $u = $this->unit_label;

        return 'کارتن '.fa($this->per_carton).' '.($u ? (str_contains($u, ' ') ? $u : $u.'ی') : 'عددی');
    }

    public static function cleanUnit(?string $u): ?string
    {
        $u = trim(preg_replace('/\s+/u', ' ', fa((string) $u)));
        $u = trim($u, " \t-–—/|");
        if ($u === '' || in_array($u, ['عدد', 'عددی', 'تا', 'تایی', 'عدد عدد'], true)) {
            return null;
        }

        return mb_substr($u, 0, 40);
    }

    /**
     * واحد از متن «تعداد در کارتن»: «12 جفت» → «جفت»، «12 دست 6 عددی» → «دست ۶ عددی»، «12 عدد» → null
     */
    public static function unitFromText(string $t): ?string
    {
        $t = trim(en_digits(strip_tags($t)));
        if ($t === '' || ! preg_match('/^\s*\d+\s*(.*)$/u', $t, $m)) {
            return null;
        }
        $rest = trim($m[1]);
        // «۱۲ عدد» یا «۱۲ عددی» یا خالی: واحد پیش‌فرض
        if ($rest === '' || preg_match('/^(عدد|عددی|تا|تایی|pcs?)$/iu', $rest)) {
            return null;
        }
        // «۱۲ دست ۶ عددی»، «۱۲ جفت»، «۱۲ پک ۳تایی»
        $rest = preg_replace('/(\p{L})(\d)/u', '$1 $2', $rest);
        $rest = preg_replace('/(\d+)\s*(تایی|عددی|عدد)/u', '$1 عددی', $rest);

        return static::cleanUnit($rest);
    }

    public function unitPrice(string $mode = self::CARTON): int
    {
        if ($mode === self::RETAIL && $this->retail_price) {
            return (int) $this->retail_price;
        }

        return (int) $this->price;
    }

    public function discountPercent(): int
    {
        if (! $this->compare_price || $this->compare_price <= $this->price) {
            return 0;
        }

        return (int) round(100 - ($this->price * 100 / $this->compare_price));
    }

    public function defaultMode(): string
    {
        return $this->cartonAvailable() || ! $this->retailAvailable() ? self::CARTON : self::RETAIL;
    }

    public function warehouseFor(string $mode): ?int
    {
        return $mode === self::RETAIL ? ($this->retail_warehouse_id ?: $this->warehouse_id) : $this->warehouse_id;
    }

    /** داده موردنیاز کارت و صفحه محصول در جاوااسکریپت */
    public function buyData(): array
    {
        return [
            'id' => $this->id,
            'n' => $this->buyRule()[1],      // گام خرید عمده (عدد)
            'mn' => $this->buyRule()[0],     // حداقل خرید عمده (عدد)
            'k' => $this->buyRule()[2] ? 1 : 0, // قانون خاص (نمایش به عدد به جای کارتن)
            'pc' => (int) $this->per_carton,
            'c' => $this->cartonAvailable() ? $this->cartonMaxUnits() : 0,
            'r' => $this->retailAvailable() ? $this->retailMaxUnits() : 0,
            'p' => $this->unitPrice(self::CARTON),
            'rp' => $this->unitPrice(self::RETAIL),
            'name' => $this->name,
            'u' => $this->unitName(),
        ];
    }

    /* ---------------- نمایش ---------------- */

    public function url(): string
    {
        if (\App\Support\LegacyUrls::enabled() && ($u = \App\Support\LegacyUrls::product($this))) {
            return $u;
        }

        return route('product', $this->slug);
    }

    public function images(): array
    {
        return array_values(array_filter(array_merge([$this->image], (array) $this->gallery)));
    }

    public function rating(): array
    {
        $r = $this->reviews()->where('is_approved', true);

        return ['avg' => round((float) $r->avg('rating'), 1), 'count' => $r->count()];
    }
}
