<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * سهم یک سفارش از یک حواله (بیعانه یا تسویه) که مشتری باید به حساب آن حواله واریز کند.
 * awaiting = منتظر واریز | submitted = فیش رسید، منتظر تأیید | confirmed = تأیید | rejected = فیش رد شد | cancelled = باطل
 */
class RemitPayment extends Model
{
    public const STATUSES = ['awaiting' => 'منتظر واریز مشتری', 'submitted' => 'فیش رسید — منتظر تأیید', 'confirmed' => 'تأیید شد', 'rejected' => 'فیش رد شد', 'cancelled' => 'باطل شد'];

    public const COLORS = ['awaiting' => 'warning', 'submitted' => 'info', 'confirmed' => 'success', 'rejected' => 'danger', 'cancelled' => 'gray'];

    public const KINDS = ['deposit' => 'بیعانه', 'settle' => 'تسویه حساب', 'walkin' => 'فیش حضوری'];

    /** وضعیت‌هایی که از ظرفیت حواله کم می‌کنند */
    public const LIVE = ['awaiting', 'submitted', 'confirmed', 'rejected'];

    protected $fillable = ['remittance_id', 'order_id', 'user_id', 'kind', 'amount', 'status', 'receipt_path', 'receipt_files', 'receipt_ref', 'paid_on', 'customer_note', 'reject_reason', 'issued_by', 'reviewed_by', 'submitted_at', 'reviewed_at', 'factory_confirmed_at', 'factory_seen_at', 'walkin_name', 'walkin_mobile', 'walkin_token', 'bounce', 'bounce_of', 'alt_account'];

    protected function casts(): array
    {
        return ['submitted_at' => 'datetime', 'reviewed_at' => 'datetime', 'factory_confirmed_at' => 'datetime', 'factory_seen_at' => 'datetime', 'amount' => 'integer', 'receipt_files' => 'array', 'alt_account' => 'array', 'bounce' => 'boolean'];
    }

    public function remittance(): BelongsTo
    {
        return $this->belongsTo(Remittance::class);
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }

    /** فیش حضوری (بدون سفارش) */
    public function isWalkin(): bool
    {
        return $this->kind === 'walkin' || ! $this->order_id;
    }

    /** نام طرف پرداخت: مشتری سفارش یا نامی که برای فیش حضوری نوشته شده */
    public function partyName(): string
    {
        return $this->isWalkin() ? (string) $this->walkin_name : (string) $this->order?->customer_name;
    }

    public function partyMobile(): ?string
    {
        return $this->isWalkin() ? $this->walkin_mobile : $this->order?->mobile;
    }

    /** «سفارش ۱۱۴۶» یا «فیش حضوری» */
    public function refLabel(): string
    {
        return $this->isWalkin() ? 'فیش حضوری' : 'سفارش '.fa((string) $this->order?->number);
    }

    public function issuer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'issued_by');
    }

    public function statusLabel(): string
    {
        return self::STATUSES[$this->status] ?? $this->status;
    }

    public function kindLabel(): string
    {
        return (self::KINDS[$this->kind] ?? $this->kind).(! empty($this->extra) ? ' (اضافه‌واریز)' : '').(! empty($this->bounce) ? ' — واریز مجدد حواله برگشتی' : '');
    }

    /** حسابی که این مبلغ باید به آن واریز شود: حساب جدید (پول برگشتی) یا حساب حواله */
    public function account(): array
    {
        $a = (array) ($this->alt_account ?? []);
        $r = $this->remittance;

        return ! empty($a['holder']) || ! empty($a['card']) || ! empty($a['sheba'])
            ? ['holder' => (string) ($a['holder'] ?? ''), 'bank' => (string) ($a['bank'] ?? ''), 'card' => (string) ($a['card'] ?? ''), 'sheba' => (string) ($a['sheba'] ?? ''), 'alt' => true]
            : ['holder' => (string) $r?->holder_name, 'bank' => (string) $r?->bank_name, 'card' => (string) $r?->card_number, 'sheba' => (string) $r?->sheba, 'alt' => false];
    }

    public function isPdf(): bool
    {
        return str_ends_with(strtolower((string) $this->receipt_path), '.pdf');
    }

    /** همه تصاویر فیش این پرداخت (واریز خرد = چند فیش) */
    public function files(): array
    {
        $list = array_values(array_filter((array) $this->receipt_files));

        return $list ?: array_values(array_filter([(string) $this->receipt_path]));
    }

    public static function isPdfPath(?string $p): bool
    {
        return str_ends_with(strtolower((string) $p), '.pdf');
    }

    /** مشتری می‌تواند فیش بفرستد یا عوض کند */
    public function payable(): bool
    {
        return in_array($this->status, ['awaiting', 'rejected', 'submitted'], true);
    }
}
