<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** یک کانال ربات (مثلاً «حراجی ۹۹» در بله) */
class BotProfile extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['enabled' => 'boolean', 'only_wholesale' => 'boolean', 'text_fallback' => 'boolean', 'stats' => 'array', 'imported_at' => 'datetime', 'fields' => 'array'];
    }

    public function posts(): HasMany
    {
        return $this->hasMany(BotPost::class, 'profile_id');
    }

    public function collection(): BelongsTo
    {
        return $this->belongsTo(ProductCollection::class, 'collection_id');
    }
}
