<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SmsLog extends Model
{
    public const UPDATED_AT = null;

    protected $fillable = ['event', 'mobile', 'ok', 'message', 'provider'];

    protected function casts(): array
    {
        return ['ok' => 'boolean'];
    }
}
