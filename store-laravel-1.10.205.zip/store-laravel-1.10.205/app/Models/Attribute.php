<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** ویژگی کالا (رنگ‌بندی، جنس، …) */
class Attribute extends Model
{
    protected $fillable = ['name', 'slug', 'type', 'filterable', 'on_card', 'sort'];

    protected function casts(): array
    {
        return ['filterable' => 'boolean', 'on_card' => 'boolean'];
    }

    protected static function booted(): void
    {
        static::saving(fn (Attribute $a) => $a->slug = Product::makeSlug($a->slug ?: $a->name, static::class, $a->id));
    }

    public function values(): HasMany
    {
        return $this->hasMany(AttributeValue::class)->orderBy('sort')->orderBy('id');
    }
}
