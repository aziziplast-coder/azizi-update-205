<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** کد تخفیف */
class Coupon extends Model
{
    public const TYPES = [
        'percent' => 'درصدی',
        'fixed' => 'مبلغ ثابت',
        'shipping' => 'ارسال رایگان',
    ];

    protected $fillable = [
        'code', 'title', 'type', 'amount', 'max_discount', 'min_cart', 'max_uses', 'max_per_user', 'used_count',
        'starts_at', 'ends_at', 'first_order', 'exclude_sale', 'applies_to', 'category_ids', 'product_ids', 'mobiles', 'is_active',
    ];

    protected function casts(): array
    {
        return [
            'starts_at' => 'datetime',
            'ends_at' => 'datetime',
            'first_order' => 'boolean',
            'exclude_sale' => 'boolean',
            'is_active' => 'boolean',
            'category_ids' => 'array',
            'product_ids' => 'array',
        ];
    }

    protected static function booted(): void
    {
        static::saving(fn (Coupon $c) => $c->code = static::clean($c->code));
    }

    public static function clean(?string $code): string
    {
        return strtoupper(preg_replace('/\s+/u', '', en_digits((string) $code)));
    }

    public function usages(): HasMany
    {
        return $this->hasMany(CouponUsage::class);
    }

    public function describe(): string
    {
        return match ($this->type) {
            'percent' => fa($this->amount).'٪ تخفیف'.($this->max_discount ? ' (تا '.money($this->max_discount, true).')' : ''),
            'fixed' => money($this->amount, true).' تخفیف',
            default => 'ارسال رایگان',
        };
    }
}
