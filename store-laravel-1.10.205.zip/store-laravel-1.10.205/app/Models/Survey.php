<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Survey extends Model
{
    protected $fillable = ['title', 'intro', 'questions', 'trigger_status', 'delay_hours', 'send_sms', 'thanks', 'is_active'];

    public const TYPES = ['rating' => 'امتیاز ۱ تا ۵ ستاره', 'choice' => 'چند گزینه‌ای', 'yesno' => 'بله / خیر', 'text' => 'متن آزاد'];

    protected function casts(): array
    {
        return ['questions' => 'array', 'send_sms' => 'boolean', 'is_active' => 'boolean', 'delay_hours' => 'float'];
    }

    public function responses(): HasMany
    {
        return $this->hasMany(SurveyResponse::class);
    }

    /** سؤال‌ها با کلید یکتا */
    public function items(): array
    {
        $out = [];
        foreach ((array) $this->questions as $i => $q) {
            if (trim((string) ($q['label'] ?? '')) === '') {
                continue;
            }
            $q['key'] = ($q['key'] ?? '') ?: 'q'.$i;
            $q['type'] = $q['type'] ?? 'rating';
            $q['options'] = array_values(array_filter(array_map('trim', (array) ($q['options'] ?? []))));
            $q['staff'] = ! empty($q['staff']);
            $q['required'] = ! array_key_exists('required', $q) || ! empty($q['required']);
            $out[] = $q;
        }

        return $out;
    }

    /** وضعیت‌هایی که بعد از وضعیت شروع می‌آیند هم حساب می‌شوند (مثلاً تکمیل‌شده بعد از ارسال‌شده) */
    public function statuses(): array
    {
        $flow = ['on_hold', 'processing', 'settling', 'to_freight', 'shipped', 'completed'];
        $i = array_search($this->trigger_status, $flow, true);

        return $i === false ? [$this->trigger_status] : array_slice($flow, $i);
    }

    /** نظرسنجی معوق یک مشتری (برای پاپ‌آپ) */
    public static function pendingFor(?User $user): ?array
    {
        if (! $user) {
            return null;
        }
        foreach (static::query()->where('is_active', true)->get() as $s) {
            $order = Order::query()->where('user_id', $user->id)->whereIn('status', $s->statuses())
                ->where('status_changed_at', '<=', now()->subMinutes((int) round($s->delay_hours * 60)))
                ->where('created_at', '>=', now()->subDays(60))
                ->whereNotExists(fn ($q) => $q->selectRaw('1')->from('survey_responses')->whereColumn('survey_responses.order_id', 'orders.id')->where('survey_responses.survey_id', $s->id))
                ->latest('id')->first();
            if ($order) {
                return ['survey' => $s, 'order' => $order];
            }
        }

        return null;
    }
}
