<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CrmCustomer extends Model
{
    protected $guarded = [];

    protected function casts(): array
    {
        return ['first_at' => 'date', 'last_at' => 'date', 'birthday' => 'date', 'assigned_at' => 'datetime', 'next_call_at' => 'datetime', 'last_call_at' => 'datetime', 'returned_at' => 'datetime', 'dnc' => 'boolean'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function advisor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'advisor_id');
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function calls(): HasMany
    {
        return $this->hasMany(CrmCall::class)->latest('id');
    }

    public function days(): ?int
    {
        return $this->last_at ? (int) $this->last_at->diffInDays(now()) : null;
    }
}
