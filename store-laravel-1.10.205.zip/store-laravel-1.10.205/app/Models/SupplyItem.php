<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** یک ردیف اکسل خرید: کد کالا، نام و تأمین‌کننده */
class SupplyItem extends Model
{
    public $timestamps = false;

    protected $fillable = ['code', 'code_key', 'name', 'supplier_id', 'product_id', 'sync_item_id', 'row'];

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
