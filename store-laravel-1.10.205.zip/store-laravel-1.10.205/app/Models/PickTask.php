<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** یک حواله در کارتابل انباردار (برای یک سفارش و یک مرحله جمع‌آوری) */
class PickTask extends Model
{
    public const STATUSES = ['open' => 'در انتظار جمع‌آوری', 'saved' => 'ذخیره موقت', 'done' => 'جمع شد'];

    /** مراحل حواله سرپرست‌دار: new (منتظر تقسیم) ← picking (دست جمع‌کننده) ← review (منتظر بررسی بار) ← status=done */
    public const STAGES = ['new' => 'منتظر تقسیم', 'picking' => 'در حال جمع‌آوری', 'review' => 'منتظر بررسی بار', 'desk' => 'بررسی رومیزی', 'hold' => 'انتقالی — منتظر پایان حواله مبدأ'];

    protected $fillable = ['order_id', 'keeper_id', 'round', 'status', 'seen_at', 'started_at', 'saved_at', 'done_at', 'done_by',
        'picker_id', 'stage', 'assigned_at', 'picked_done_at', 'bay', 'checked_by', 'checked_at', 'check_note', 'bags', 'boxes', 'hall', 'packs'];

    protected function casts(): array
    {
        return ['seen_at' => 'datetime', 'started_at' => 'datetime', 'saved_at' => 'datetime', 'done_at' => 'datetime',
            'assigned_at' => 'datetime', 'picked_done_at' => 'datetime', 'checked_at' => 'datetime'];
    }

    protected static function booted(): void
    {
        // حواله‌ای که به سرپرست می‌رسد اول در «جدید» او می‌نشیند تا تقسیمش کند
        static::creating(function (PickTask $t) {
            if ($t->stage === null && $t->keeper_id && User::query()->whereKey($t->keeper_id)->where('pick_role', 'supervisor')->exists()) {
                $t->stage = 'new';
            }
        });
    }

    public function picker(): BelongsTo
    {
        return $this->belongsTo(User::class, 'picker_id');
    }

    public function checker(): BelongsTo
    {
        return $this->belongsTo(User::class, 'checked_by');
    }

    /** حواله تحت نظر سرپرست (تقسیم + بررسی بار) */
    public function supervised(): bool
    {
        return $this->stage !== null || $this->checked_at !== null;
    }

    public function stageLabel(): string
    {
        if ($this->status === 'done') {
            return $this->checked_at ? 'بررسی و تأیید شد' : 'جمع شد';
        }

        return self::STAGES[$this->stage] ?? $this->statusLabel();
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function keeper(): BelongsTo
    {
        return $this->belongsTo(User::class, 'keeper_id');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class, 'pick_task_id');
    }

    public function isDone(): bool
    {
        return $this->status === 'done';
    }

    /** [بررسی‌شده، کل] */
    public function progress(): array
    {
        $items = $this->relationLoaded('items') ? $this->items : $this->items()->get(['id', 'pick_status']);

        return [$items->whereNotNull('pick_status')->count(), $items->count()];
    }

    public function statusLabel(): string
    {
        return self::STATUSES[$this->status] ?? $this->status;
    }
}
