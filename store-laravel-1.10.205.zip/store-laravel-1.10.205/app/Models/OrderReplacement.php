<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** کالای جایگزینی که مشتری به‌جای کالای حذف‌شده انتخاب کرده (تا تأیید مسئول پیگیری) */
class OrderReplacement extends Model
{
    protected $fillable = ['order_id', 'replaces_item_id', 'product_id', 'name', 'mode', 'units', 'per_carton', 'unit_price', 'status'];

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function replaces(): BelongsTo
    {
        return $this->belongsTo(OrderItem::class, 'replaces_item_id');
    }

    public function total(): int
    {
        return (int) $this->unit_price * (int) $this->units;
    }

    public function qtyLabel(): string
    {
        if ($this->mode === Product::RETAIL || $this->per_carton <= 1 || $this->units % $this->per_carton) {
            return fa($this->units).' عدد'.($this->mode === Product::RETAIL ? ' تکی' : '');
        }
        $c = $this->units / $this->per_carton;
        $c = floor($c) == $c ? (int) $c : round($c, 2);

        return fa($c).' کارتن '.fa($this->per_carton).'تایی ('.fa($this->units).' عدد)';
    }
}
