<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** کارخانه‌دار (طرف حواله‌ها) — با موبایل وارد اپ کارخانه‌داران می‌شود */
class Factory extends Model
{
    protected $fillable = ['name', 'mobile', 'company', 'note', 'active', 'last_seen_at', 'kind', 'referred_by'];

    protected function casts(): array
    {
        return ['active' => 'boolean', 'last_seen_at' => 'datetime'];
    }

    public function remittances(): HasMany
    {
        return $this->hasMany(Remittance::class);
    }

    public function accounts(): HasMany
    {
        return $this->hasMany(FactoryAccount::class);
    }

    /** همه فیش‌های حواله‌های این کارخانه‌دار */
    public function payments()
    {
        return RemitPayment::query()->whereIn('remittance_id', $this->remittances()->select('id'));
    }

    /** شخص ثالث: حواله از طرف کارخانه‌دار به او منتقل شده؛ فقط حساب خودش و تأیید فیش‌ها */
    public function isThird(): bool
    {
        return $this->kind === 'third';
    }

    public function referrer(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(self::class, 'referred_by');
    }

    public function label(): string
    {
        return $this->name.($this->company ? ' — '.$this->company : '');
    }
}
