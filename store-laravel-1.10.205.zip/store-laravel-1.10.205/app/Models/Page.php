<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    protected $fillable = ['title', 'slug', 'body', 'is_active', 'in_footer', 'sort', 'seo_description'];

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'in_footer' => 'boolean'];
    }

    protected static function booted(): void
    {
        static::saving(function (Page $p) {
            $p->slug = Product::makeSlug($p->slug ?: $p->title, static::class, $p->id);
        });
    }

    public function url(): string
    {
        return route('page', $this->slug);
    }
}
