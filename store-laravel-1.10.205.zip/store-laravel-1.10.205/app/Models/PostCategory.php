<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PostCategory extends Model
{
    protected $fillable = ['name', 'slug', 'description', 'seo_title', 'seo_description', 'sort'];

    protected static function booted(): void
    {
        static::saving(fn (PostCategory $c) => $c->slug = Product::makeSlug($c->slug ?: $c->name, static::class, $c->id));
    }

    public function posts(): HasMany
    {
        return $this->hasMany(Post::class);
    }

    public function url(): string
    {
        return route('blog.category', $this->slug);
    }
}
