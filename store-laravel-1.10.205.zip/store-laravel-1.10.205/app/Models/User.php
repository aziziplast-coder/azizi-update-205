<?php

namespace App\Models;

use Filament\Models\Contracts\FilamentUser;
use Filament\Models\Contracts\HasName;
use Filament\Panel;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements FilamentUser, HasName
{
    use Notifiable;

    /** هنگام ساخت «مشتری احراز نشده» (فقط درخواست کد تأیید) true می‌شود */
    public static bool $lead = false;

    protected static ?bool $hasVerify = null;

    public static function verifyColumns(): bool
    {
        return static::$hasVerify ??= \App\Support\DbSchema::hasColumn('users', 'mobile_verified_at');
    }

    protected static function booted(): void
    {
        // هر حسابی که از راهی جز درخواست کد ساخته شود (ثبت‌نام، مدیر، سفارش) احراز‌شده است
        static::creating(function (User $u) {
            if (! static::$lead && ! $u->mobile_verified_at && static::verifyColumns()) {
                $u->mobile_verified_at = now();
            }
        });
    }

    public function scopeVerified($query)
    {
        return static::verifyColumns() ? $query->whereNotNull('mobile_verified_at') : $query;
    }

    public function isVerified(): bool
    {
        return ! static::verifyColumns() || $this->mobile_verified_at !== null;
    }

    public const ROLES = [
        'admin' => 'مدیر کل',
        'staff' => 'کارمند',
        'keeper' => 'انباردار',
        'customer' => 'مشتری',
    ];

    /** بخش‌هایی که به کارمندان داده می‌شود. */
    public const PERMISSIONS = [
        'orders' => 'سفارش‌ها',
        'orders_edit' => 'تغییر وضعیت و ویرایش سفارش',
        'chats' => 'گفتگو با مشتری (گفتگوی سفارش‌ها)',
        'followups' => 'پیگیری‌های عقب‌افتاده',
        'waybills' => 'بیجک و بارگیری',
        'cheque_review' => 'بررسی و تأیید سفارش‌های چکی',
        'desk_check' => 'بررسی رومیزی بار (انبار خرده‌ریز/لوکس) و خروجی هلو',
        'remit_manage' => 'حسابدار کل: ایجاد و مدیریت همه حواله‌ها',
        'remit_assist' => 'کمک‌حسابدار: حواله‌های خودش و تأیید فیش‌ها (فیش آنلاین: بیعانه و مانده حساب سفارش‌ها)',
        'walkin' => 'صدور فیش حضوری (مشتری حضوری بدون سفارش سایت) — همراه با کمک‌حسابدار',
        'wk_desk' => 'فروش حضوری: کارتابل فروش (در حال اسکن، اسکن‌شده، بارگیری‌شده، پایان‌یافته) و دیدن اقلام',
        'wk_returns' => 'فروش حضوری: سربرگ مرجوعی',
        'wk_excel' => 'فروش حضوری: دریافت اکسل هلو',
        'wk_edit' => 'فروش حضوری: اصلاح و افزودن دستی اقلام',
        'wk_finish' => 'فروش حضوری: «پایان» و بازگرداندن فاکتور',
        'wk_delete' => 'فروش حضوری: حذف فاکتور',
        'purchasing' => 'خرید و تأمین (اپ مسئول خرید، کالاهای ناموجود)',
        'live' => 'گفتگوی زنده با بازدیدکنندگان سایت (دیدن آنلاین‌ها و پاسخ به پیام‌ها)',
        'advisor' => 'مشاور فروش: لینک بازاریابی، مشتری‌های خودش، پورسانت، کیف پول و شماره حساب (در اپ مشاور)',
        'advisors' => 'مدیریت مشاوران: پورسانت‌ها، تسویه کیف پول، تأیید شماره حساب و تعیین مشاور مشتری/سفارش',
        'crm' => 'باشگاه مشتریان: دسته‌بندی، فیلتر، ورود اکسل هلو، پرونده مشتری و سپردن فهرست تماس به مشاوران',
        'crm_sms' => 'باشگاه مشتریان: ساخت و ارسال کمپین پیامکی',
        'carts' => 'سبدهای رها شده',
        'surveys' => 'نظرسنجی‌ها',
        'products' => 'محصولات و دسته‌ها',
        'stock' => 'موجودی و ورود از اکسل',
        'bulk_upload' => 'آپلود گروهی محصولات (RAR تصاویر + اکسل)',
        'warehouses' => 'انبارها',
        'customers' => 'مشتریان',
        'reviews' => 'نظرات',
        'pages' => 'صفحات',
        'reports' => 'گزارش‌ها و آمار فروش',
        'stats' => 'آمار بازدید سایت (بازدیدکنندگان، منابع ورود، کالاهای پربازدید، جستجوها)',
        'coupons' => 'کدهای تخفیف',
        'blog' => 'مقالات و وبلاگ',
        'marketing' => 'مجموعه‌ها، شگفت‌انگیز، پاپ‌آپ و اعلان',
        'settings' => 'تنظیمات فروشگاه',
        'sms' => 'پیامک',
        'tools' => 'ابزار سایت (بکاپ، به‌روزرسانی، سلامت)',
    ];

    /**
     * درخت دسترسی‌ها برای فرم کارکنان (کشویی): سرفصل ← بخش ← زیربخش.
     * تیک سرفصل = همه زیرمجموعه‌ها؛ تیک یک زیربخش، بخش بالاترش را هم می‌دهد.
     */
    public const PERM_TREE = [
        ['t' => 'فروش و سفارش‌ها', 'i' => '🛒', 'c' => [
            ['k' => 'orders', 'c' => [['k' => 'orders_edit']]],
            ['k' => 'cheque_review'], ['k' => 'chats'], ['k' => 'followups'], ['k' => 'waybills'], ['k' => 'live'],
            ['k' => 'desk_check'], ['k' => 'customers'], ['k' => 'carts'], ['k' => 'surveys'],
        ]],
        ['t' => 'مشاوران و پورسانت', 'i' => '🤝', 'c' => [['k' => 'advisor'], ['k' => 'advisors']]],
        ['t' => 'باشگاه مشتریان (CRM)', 'i' => '👑', 'c' => [['k' => 'crm', 'c' => [['k' => 'crm_sms']]]]],
        ['t' => 'فروش حضوری (اسکن و تحویل)', 'i' => '🧾', 'c' => [
            ['k' => 'wk_desk', 'c' => [['k' => 'wk_edit'], ['k' => 'wk_finish'], ['k' => 'wk_delete']]],
            ['k' => 'wk_returns'], ['k' => 'wk_excel'],
        ]],
        ['t' => 'حسابداری', 'i' => '💰', 'c' => [
            ['k' => 'remit_manage'],
            ['k' => 'remit_assist', 'c' => [['k' => 'walkin']]],
        ]],
        ['t' => 'کالاها و انبار', 'i' => '📦', 'c' => [
            ['k' => 'products'], ['k' => 'bulk_upload'], ['k' => 'stock'], ['k' => 'warehouses'], ['k' => 'purchasing'], ['k' => 'reviews'],
        ]],
        ['t' => 'بازاریابی و محتوا', 'i' => '📣', 'c' => [
            ['k' => 'marketing'], ['k' => 'coupons'], ['k' => 'sms'], ['k' => 'blog'], ['k' => 'pages'],
        ]],
        ['t' => 'گزارش‌ها', 'i' => '📊', 'c' => [['k' => 'reports'], ['k' => 'stats']]],
        ['t' => 'تنظیمات و ابزار سایت', 'i' => '⚙️', 'c' => [['k' => 'settings'], ['k' => 'tools']]],
    ];

    /** همه کلیدهای زیر یک گره درخت */
    public static function permKeys(array $node): array
    {
        $out = isset($node['k']) ? [$node['k']] : [];
        foreach ($node['c'] ?? [] as $ch) {
            $out = array_merge($out, static::permKeys($ch));
        }

        return $out;
    }

    protected $fillable = [
        'name', 'mobile', 'email', 'password', 'role', 'permissions', 'is_active',
        'company', 'province', 'city', 'address', 'postal_code', 'note', 'last_login_at', 'force_followup', 'receives_orders', 'cheque_allowed', 'messenger',
        'mobile_verified_at', 'otp_sent_at', 'otp_sends', 'pick_role', 'supervisor_id', 'acc_settings', 'advisor_id', 'advisor_src', 'advisor_at',
    ];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'password' => 'hashed',
            'permissions' => 'array',
            'advisor_at' => 'datetime',
            'is_active' => 'boolean',
            'last_login_at' => 'datetime',
            'mobile_verified_at' => 'datetime',
            'otp_sent_at' => 'datetime',
            'force_followup' => 'boolean',
            'receives_orders' => 'boolean',
            'cheque_allowed' => 'boolean',
        ];
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    public function warehouses(): BelongsToMany
    {
        return $this->belongsToMany(Warehouse::class, 'user_warehouse');
    }

    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    public function isKeeper(): bool
    {
        return $this->role === 'keeper';
    }

    /** سرپرست انبار: فاکتورها را بین جمع‌کننده‌ها تقسیم و بار را با بارکدخوان بررسی می‌کند */
    public function isSupervisor(): bool
    {
        return $this->role === 'keeper' && $this->pick_role === 'supervisor';
    }

    /** جمع‌کننده زیر نظر یک سرپرست */
    public function isPicker(): bool
    {
        return $this->role === 'keeper' && $this->pick_role === 'picker';
    }

    public function supervisor(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class, 'supervisor_id');
    }

    /** جمع‌کننده‌های فعال این سرپرست (خود سرپرست جدا حساب می‌شود) */
    public function pickers(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(User::class, 'supervisor_id')->where('role', 'keeper')->where('pick_role', 'picker')->where('is_active', true)->orderBy('name');
    }

    public function isStaffLike(): bool
    {
        return in_array($this->role, ['admin', 'staff', 'keeper'], true);
    }

    /** مشاورِ صاحب این مشتری */
    public function advisor(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class, 'advisor_id');
    }

    public function hasPerm(string $perm): bool
    {
        if (! $this->is_active) {
            return false;
        }
        if ($this->isAdmin()) {
            return true;
        }
        if ($this->isKeeper()) {
            return in_array($perm, ['orders', 'chats', 'followups', 'waybills'], true);
        }

        return $this->role === 'staff' && in_array($perm, (array) $this->permissions, true);
    }

    public function canAccessPanel(Panel $panel): bool
    {
        return $this->is_active && $this->isStaffLike();
    }

    public function getFilamentName(): string
    {
        return $this->name ?: ($this->mobile ?: (string) $this->email);
    }

    public function displayName(): string
    {
        return $this->name ?: fa((string) $this->mobile);
    }
}
