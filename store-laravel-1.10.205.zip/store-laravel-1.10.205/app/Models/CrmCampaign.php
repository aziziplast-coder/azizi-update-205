<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CrmCampaign extends Model
{
    protected $guarded = [];

    protected function casts(): array
    {
        return ['filter' => 'array', 'sent_at' => 'datetime'];
    }
}
