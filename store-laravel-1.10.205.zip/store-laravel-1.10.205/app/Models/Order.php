<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\DB;

class Order extends Model
{
    /**
     * مراحل سفارش (به ترتیب جریان کار):
     * بیعانه ← جمع‌آوری انبار ← تسویه حساب مشتری ← ارسال به باربری ← تکمیل؛ و لغو (با علت)
     */
    public const STATUSES = [
        'on_hold' => 'در انتظار پرداخت بیعانه',
        'processing' => 'در حال جمع‌آوری از انبار',
        'settling' => 'در انتظار تسویه حساب مشتری',
        'to_freight' => 'در صف ارسال به باربری (حذف‌شده)',
        'shipped' => 'در حال ارسال به باربری',
        'completed' => 'تکمیل شده',
        'cancelled' => 'لغو سفارش',
        'pending_payment' => 'در انتظار پرداخت آنلاین',
        'failed' => 'پرداخت ناموفق',
    ];

    public const COLORS = [
        'pending_payment' => 'gray',
        'on_hold' => 'warning',
        'processing' => 'info',
        'settling' => 'primary',
        'to_freight' => 'info',
        'shipped' => 'success',
        'completed' => 'success',
        'cancelled' => 'danger',
        'failed' => 'danger',
    ];

    /** رنگ کامل هر وضعیت برای کادر تغییر وضعیت و برچسب‌ها: [زمینه، متن، حاشیه] */
    public const HEX = [
        'on_hold' => ['#fef3c7', '#92400e', '#f59e0b'],
        'processing' => ['#dbeafe', '#1e40af', '#3b82f6'],
        'settling' => ['#ede9fe', '#5b21b6', '#8b5cf6'],
        'to_freight' => ['#e0f2fe', '#075985', '#0ea5e9'],
        'shipped' => ['#ccfbf1', '#115e59', '#14b8a6'],
        'completed' => ['#dcfce7', '#166534', '#22c55e'],
        'cancelled' => ['#fee2e2', '#991b1b', '#ef4444'],
        'failed' => ['#fee2e2', '#991b1b', '#ef4444'],
        'pending_payment' => ['#f1f5f9', '#334155', '#94a3b8'],
    ];

    /** وضعیت‌هایی که کالا از موجودی کم شده باقی می‌ماند */
    public const HOLDS_STOCK = ['pending_payment', 'on_hold', 'processing', 'settling', 'to_freight', 'shipped', 'completed'];

    protected $fillable = [
        'placed_total',
        'number', 'user_id', 'status', 'customer_name', 'mobile', 'company', 'province', 'city', 'address', 'postal_code', 'note',
        'shipping_method', 'shipping_title', 'shipping_cost', 'shipping_collect', 'payment_method', 'payment_title',
        'payment_status', 'payment_ref', 'payment_meta', 'items_total', 'discount_total', 'fees', 'fees_total', 'total',
        'tracking_code', 'admin_note', 'stock_reduced', 'paid_at', 'alerted_at', 'ip',
        'assignee_id', 'status_changed_at', 'assigned_at', 'coupon_code', 'coupon_discount', 'terms_accepted_at',
        'review_status', 'reviewed_by', 'reviewed_at', 'cheque', 'freight_name', 'freight_dest', 'holoo_bal', 'holoo_dep', 'new_customer', 'guarantee', 'staff_pop', 'messenger', 'edit_locked', 'customer_edited_at', 'survey_notified_at', 'custom_fields',
        'cancel_reason', 'fulfil_status', 'pick_round', 'referred_at', 'referred_by', 'picked_at', 'replace_until', 'replace_submitted_at', 'deposit_amount', 'deposit_ref',
        'freight_fee', 'extra_discount', 'cash_amount', 'cheques_received_at', 'loaded_at', 'loaded_by', 'waybill_path', 'waybill_at', 'waybill_nag_at', 'direct_at', 'driver_phone',
    ];

    public const FULFIL = [
        'picking' => 'در حال جمع‌آوری در انبار',
        'picked' => 'جمع‌آوری شد',
        'replace_review' => 'جایگزین‌های مشتری در انتظار تأیید',
    ];

    public const FULFIL_COLORS = ['picking' => 'info', 'picked' => 'success', 'replace_review' => 'warning'];

    /** وضعیت‌هایی که پیگیری دارند */
    public const OPEN = ['on_hold', 'processing', 'settling', 'to_freight', 'shipped'];

    protected function casts(): array
    {
        return [
            'fees' => 'array',
            'holoo_dep' => 'boolean',
            'new_customer' => 'boolean',
            'guarantee' => 'array',
            'staff_pop' => 'array',
            'deposit_asked_at' => 'datetime',
            'reorder_ok' => 'boolean',
            'payment_meta' => 'array',
            'shipping_collect' => 'boolean',
            'stock_reduced' => 'boolean',
            'paid_at' => 'datetime',
            'alerted_at' => 'datetime',
            'status_changed_at' => 'datetime',
            'assigned_at' => 'datetime',
            'terms_accepted_at' => 'datetime',
            'reviewed_at' => 'datetime',
            'customer_edited_at' => 'datetime',
            'survey_notified_at' => 'datetime',
            'cheque' => 'array',
            'custom_fields' => 'array',
            'edit_locked' => 'boolean',
            'referred_at' => 'datetime',
            'picked_at' => 'datetime',
            'replace_until' => 'datetime',
            'replace_submitted_at' => 'datetime',
            'cheques_received_at' => 'datetime',
            'loaded_at' => 'datetime',
            'waybill_at' => 'datetime',
            'waybill_nag_at' => 'datetime',
            'direct_at' => 'datetime',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (Order $o) {
            $o->status_changed_at ??= now();
        });
        // بار جمع شد و سفارش به «تسویه» رسید: هشدار «به حساب‌های قبلی واریز نکنید» در گفتگو
        static::updated(function (Order $o) {
            if ($o->wasChanged('status') && $o->status === 'settling') {
                \App\Services\Chat::warn($o, 'settle');
            }
        });
        static::creating(function (Order $o) {
            // مبلغ اولیه سفارش (برای مقایسه پس از تغییرات انبار)
            if ($o->placed_total === null && \App\Support\DbSchema::hasColumn('orders', 'placed_total')) {
                $o->placed_total = (int) $o->total;
            }
        });
        static::created(function (Order $o) {
            if (! $o->number) {
                $o->number = setting('order_prefix', '').(1000 + $o->id);
                $o->saveQuietly();
            }
            if (! $o->assignee_id && $o->status !== 'pending_payment' && $o->review_status !== 'pending' && static::autoAssignOn()) {
                $o->autoAssign();
            }
            // مشاور فروش (لینک / صاحب مشتری / گفتگو) و پورسانت
            \App\Services\Advisors::attribute($o);
            \App\Services\Stats::order($o); // آمار بازدید: نرخ تبدیل و درآمد هر منبع ورود
        });
        static::updated(function (Order $o) {
            if ($o->advisor_id && $o->wasChanged(['status', 'items_total', 'coupon_discount', 'extra_discount'])) {
                \App\Services\Advisors::sync($o);
            }
        });
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assignee_id');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function pickTasks(): HasMany
    {
        return $this->hasMany(PickTask::class);
    }

    /** جمع‌آوری انبار تمام شده و فاکتور نهایی (اکسل هلو) آماده است */
    public function holooReady(): bool
    {
        if (in_array($this->fulfil_status, ['picked', 'replace_review'], true)) {
            return true;
        }

        // سیستم انبار خاموش: اکسل هلو از همان تعدادهای سفارش، از «در حال پردازش» به بعد
        $from = \App\Services\Picking::enabled() ? ['settling', 'to_freight', 'shipped', 'completed'] : ['processing', 'settling', 'to_freight', 'shipped', 'completed'];

        return ! $this->fulfil_status && in_array($this->status, $from, true);
    }

    public function remitPayments(): HasMany
    {
        return $this->hasMany(RemitPayment::class);
    }

    public function replacements(): HasMany
    {
        return $this->hasMany(OrderReplacement::class);
    }

    public function fulfilLabel(): ?string
    {
        return $this->fulfil_status ? (self::FULFIL[$this->fulfil_status] ?? $this->fulfil_status) : null;
    }

    /** آیا مشتری هنوز می‌تواند برای کالاهای حذف‌شده جایگزین انتخاب کند؟ */
    public function canReplace(): bool
    {
        return $this->fulfil_status === 'picked' && $this->replace_until && $this->replace_until->isFuture()
            && ! $this->isPaid() && in_array($this->status, ['on_hold', 'processing', 'settling'], true) && (bool) setting('replace_enabled', true);
    }

    public function events(): HasMany
    {
        return $this->hasMany(OrderEvent::class)->latest('id');
    }

    /** سفارش‌هایی که در صف بررسی چک نیستند (در فهرست سفارش‌ها دیده می‌شوند) */
    public function scopeReleased(\Illuminate\Database\Eloquent\Builder $q): \Illuminate\Database\Eloquent\Builder
    {
        return $q->where(fn ($w) => $w->whereNull('review_status')->orWhereIn('review_status', ['approved', 'rejected']));
    }

    public function inReview(): bool
    {
        return $this->review_status === 'pending';
    }

    /** آیا مشتری هنوز می‌تواند اقلام سفارش را تغییر دهد؟ */
    /** «سفارش مجدد»: اجازه این سفارش (دستی توسط اپراتور) یا تنظیم کلی */
    public function reorderAllowed(): bool
    {
        if (! \App\Support\DbSchema::hasColumn('orders', 'reorder_ok')) {
            return false;
        }

        return (bool) $this->reorder_ok;
    }

    /** دکمه «سفارش مجدد» (کپی اقلام به سبد) فقط وقتی مشتری اجازه ثبت سفارش جدید دارد */
    public function canReorder(): bool
    {
        return \App\Support\DbSchema::hasColumn('orders', 'reorder_ok') && setting('reorder_default', true) && $this->user
            && ! \App\Services\Checkout::openBlock($this->user) && $this->status !== 'pending_payment' && $this->review_status !== 'pending'
            && $this->items()->whereNotNull('product_id')->exists();
    }

    public function isOpen(): bool
    {
        return in_array($this->status, \App\Services\Checkout::openStatuses(), true);
    }

    public function customerCanEdit(): bool
    {
        $cfg = (array) setting('order_edit', []);
        // مرحله «پیش از بیعانه فاکتورتان را تغییر می‌دهید؟»: ویرایش حتی اگر ویرایش مشتری در تنظیمات خاموش باشد
        if (in_array($this->deposit_ask, ['ask', 'edit'], true) && ($this->deposit_ask !== 'edit' || \App\Services\OrderWindows::editing($this)) && $this->status === 'on_hold' && ! $this->isPaid() && ! $this->fulfil_status && ! $this->pick_round
            && ! $this->remitPayments()->whereIn('status', ['awaiting', 'submitted', 'confirmed'])->exists()) {
            return true;
        }
        if (empty($cfg['enabled']) || $this->edit_locked || $this->isPaid() || $this->payment_method === 'gateway' || $this->fulfil_status || $this->pick_round) {
            return false;
        }
        if ($this->review_status === 'rejected') {
            return false;
        }

        return in_array($this->status, (array) ($cfg['statuses'] ?? ['on_hold']), true);
    }

    /** تأیید سفارش چکی توسط کارشناس: به سفارش‌های عادی اضافه می‌شود */
    public function approveReview(?string $note = null): void
    {
        $this->review_status = 'approved';
        $this->reviewed_by = auth()->id();
        $this->reviewed_at = now();
        $this->status_changed_at = now();
        $this->alerted_at = now();
        $this->save();
        $this->log('چک‌ها بررسی و سفارش تأیید شد'.($note ? ' — '.$note : ''));
        if (! $this->assignee_id && static::autoAssignOn()) {
            $this->autoAssign();
        }
        \App\Services\Remit::autoDeposit($this);
        \App\Services\Remit::welcome($this->refresh());
        app(\App\Services\WebPush::class)->newOrder($this);
    }

    public function rejectReview(string $reason, string $sms = 'default', ?string $smsText = null): void
    {
        $this->review_status = 'rejected';
        $this->reviewed_by = auth()->id();
        $this->reviewed_at = now();
        $this->save();
        $this->setStatus('cancelled', 'رد خرید چکی: '.$reason, true, $sms === 'custom' ? 'custom' : 'none', $smsText);
        if ($sms === 'default') {
            app(\App\Services\Sms::class)->forOrder($this, 'cheque_rejected');
        }
    }

    /** ترتیب مراحل؛ پس از «در صف ارسال به باربری» سفارش به مرحله قبل برنمی‌گردد */
    public const STATUS_RANK = ['pending_payment' => 0, 'on_hold' => 0, 'processing' => 1, 'settling' => 2, 'to_freight' => 3, 'shipped' => 4, 'completed' => 5];

    /** بار برای بارگیری رفته (یا بارگیری شده): تأییدها و وضعیت دیگر به عقب برنمی‌گردد */
    public function loadingLocked(): bool
    {
        return (self::STATUS_RANK[$this->status] ?? -1) >= 3 || $this->loaded_at !== null;
    }

    /**
     * چرا تغییر وضعیت به $to مجاز نیست (برای کارمندان؛ مدیر کل محدود نیست). null = مجاز.
     * جلوگیری از ضرر: برگشت باری که برای بارگیری رفته، لغو بار پرداخت‌شده، و فرستادن بار پرداخت‌نشده به باربری.
     */
    public function statusBlockReason(string $to, ?User $by = null): ?string
    {
        if ($to === $this->status) {
            return null;
        }
        // «در صف ارسال به باربری» حذف شد: پس از تأیید نهایی، مستقیم «در حال ارسال به باربری»
        if ($to === 'to_freight') {
            return 'این وضعیت حذف شده؛ پس از تأیید نهایی سفارش، «در حال ارسال به باربری» را بزنید.';
        }
        if ($by && $by->isAdmin()) {
            return null;
        }
        $cur = self::STATUS_RANK[$this->status] ?? null;
        $new = self::STATUS_RANK[$to] ?? null;
        if ($this->loadingLocked() && ($new === null || ($cur !== null && $new < $cur))) {
            return 'بار برای بارگیری رفته است؛ برگشت به مرحله قبل یا لغو فقط با مدیر کل ممکن است.';
        }
        // باربری بدون بیجک: «تکمیل شده» با بارگذاری بیجک خودکار می‌خورد (تا بیجک از کارتابل سرپرست جا نماند)
        if ($to === 'completed' && \App\Services\Shipping::needsWaybill($this)) {
            return 'بیجک باربری این سفارش هنوز بارگذاری نشده؛ با بارگذاری بیجک (اپ سرپرست انبار یا صفحه «بیجک») سفارش خودکار تکمیل می‌شود.';
        }
        if ($to === 'cancelled' && $this->remitPayments()->where('status', 'confirmed')->exists()) {
            return 'برای این سفارش واریز تأییدشده هست؛ لغو فقط با مدیر کل ممکن است.';
        }
        if ($new !== null && $new >= 3 && ($cur ?? 0) < 3 && \App\Services\Remit::enabled() && ! $this->isPaid()) {
            return 'پرداخت این سفارش هنوز کامل نشده؛ بار پیش از تسویه به باربری نمی‌رود.';
        }
        if ($new !== null && $new >= 3 && ($cur ?? 0) < 3 && \App\Services\Remit::enabled() && ($why = \App\Services\Remit::finalBlock($this))) {
            return 'تأیید نهایی سفارش انجام نشده: '.$why.' (یا حسابدار کل «تأیید نهایی دستی» بزند).';
        }

        return null;
    }

    /** وضعیت‌هایی که این کاربر می‌تواند انتخاب کند */
    public function allowedStatuses(?User $by = null): array
    {
        return array_filter(self::STATUSES, fn ($label, $k) => $this->statusBlockReason($k, $by) === null, ARRAY_FILTER_USE_BOTH);
    }

    public function statusLabel(): string
    {
        if ($this->status === 'on_hold' && $this->deposit_ask === 'edit' && \App\Services\OrderWindows::editing($this)) {
            return 'در ویرایش مشتری';
        }

        return self::STATUSES[$this->status] ?? $this->status;
    }

    public function isPaid(): bool
    {
        return $this->payment_status === 'paid';
    }

    public function log(string $message, ?int $userId = null): void
    {
        // ستون تاریخچه در دیتابیس‌های قدیمی ۵۰۰ نویسه است: متن بلند (مثلاً ویرایش ۱۳ قلم) نباید کل عملیات را با خطا بشکند
        $max = static::$logMax ??= (setting('order_events_text') ? 4000 : 495);
        if (mb_strlen($message) > $max) {
            $message = mb_substr($message, 0, $max - 1).'…';
        }
        try {
            $this->events()->create(['message' => $message, 'user_id' => $userId ?? auth()->id()]);
        } catch (\Throwable $e) {
            report($e); // ثبت تاریخچه هرگز نباید کار اصلی (که انجام شده) را خطا نشان دهد
        }
    }

    protected static ?int $logMax = null;

    public function fullAddress(): string
    {
        return trim(implode('، ', array_filter([$this->province, $this->city, $this->address])).($this->postal_code ? ' — کد پستی '.$this->postal_code : ''));
    }

    public function shippingLabel(): string
    {
        if ($this->shipping_collect) {
            return $this->shipping_cost ? money($this->shipping_cost).' + کرایه باربری پس‌کرایه' : 'پس‌کرایه';
        }

        return $this->shipping_cost ? money($this->shipping_cost) : 'رایگان';
    }

    /** کم کردن یا برگرداندن موجودی کالاهای این سفارش */
    public function adjustStock(bool $reduce): void
    {
        if ($reduce === $this->stock_reduced) {
            return;
        }
        DB::transaction(function () use ($reduce) {
            foreach ($this->items as $item) {
                if (! $item->product_id) {
                    continue;
                }
                $p = Product::query()->lockForUpdate()->find($item->product_id);
                if (! $p) {
                    continue;
                }
                $col = $item->stockCol();
                if ($p->{$col} !== null && Product::counts() && ($reduce || $p->stockRestorable($col, $this->created_at))) {
                    $p->{$col} = $p->{$col} + ($reduce ? -$item->units : $item->units);
                }
                $p->sales_count = max(0, $p->sales_count + ($reduce ? 1 : -1));
                $p->saveQuietly();
                if (! $reduce) {
                    app(\App\Services\StockNotifier::class)->check($p);
                }
            }
            $this->stock_reduced = $reduce;
            $this->saveQuietly();
        });
    }

    /**
     * تغییر وضعیت با ثبت در تاریخچه، موجودی، هشدار و پیامک
     *
     * @param  string  $sms  default: پیامک پیش‌فرض همین وضعیت | custom: متن دلخواه | none: بدون پیامک
     */
    public function setStatus(string $status, ?string $note = null, bool $notify = true, string $sms = 'default', ?string $smsText = null): void
    {
        $old = $this->status;
        if ($old === $status) {
            return;
        }
        $this->status = $status;
        $this->status_changed_at = now();
        if ($status === 'cancelled' && $note) {
            $this->cancel_reason = mb_substr($note, 0, 500);
        }
        if (in_array($status, ['on_hold', 'processing'], true) && ! $this->alerted_at) {
            $this->alerted_at = now();
        }
        $this->save();
        $this->log('وضعیت: '.(self::STATUSES[$old] ?? $old).' ← '.$this->statusLabel().($note ? ' — '.$note : ''));
        \App\Services\Chat::event($this, 'وضعیت سفارش: '.$this->statusLabel().($status === 'shipped' && $this->tracking_code ? ' — کد رهگیری '.fa($this->tracking_code) : ''));

        $this->adjustStock(in_array($status, self::HOLDS_STOCK, true));
        if ($status === 'cancelled') {
            \App\Services\Remit::orderCancelled($this);
            \App\Services\Picking::orderCancelled($this); // کالای جمع‌شده ← «برگشت به انبار» در میز بررسی / کارتابل سرپرست
        } elseif ($old === 'cancelled') {
            \App\Services\Picking::orderRestored($this);
        }
        if ($status === 'on_hold') {
            \App\Services\Remit::autoDeposit($this);
        }
        // تأیید سفارش (بیعانه/پرداخت/تغییر دستی وضعیت) ← حواله‌ها خودکار در کارتابل انباردارها
        if ($status === 'processing' && $old === 'on_hold') {
            \App\Services\Picking::autoRefer($this, $note ?: 'تأیید سفارش');
        }
        if (in_array($status, ['cancelled', 'failed'], true) && $this->coupon_code) {
            \App\Services\Coupons::release($this);
        }

        if ($status !== 'pending_payment' && ! $this->assignee_id && static::autoAssignOn()) {
            $this->autoAssign();
        }

        if ($notify) {
            if ($sms === 'custom' && trim((string) $smsText) !== '') {
                $res = app(\App\Services\Sms::class)->sendText($this->mobile, \App\Services\Sms::fill((string) $smsText, $this->smsData()));
                $this->log('پیامک دلخواه '.($res['ok'] ? 'ارسال شد' : 'ارسال نشد: '.$res['msg']));
            } elseif ($sms !== 'none') {
                app(\App\Services\Sms::class)->orderStatus($this);
            }
            app(\App\Services\WebPush::class)->orderStatus($this);
        }
    }

    /** متغیرهای قابل استفاده در متن پیامک */
    public function smsData(): array
    {
        return [
            'name' => $this->customer_name,
            'order' => $this->number,
            'total' => number_format((int) $this->total),
            'tracking' => $this->tracking_code ? 'کد رهگیری: '.$this->tracking_code : '',
            'status' => $this->statusLabel(),
            'shop' => store_name(),
            'link' => route('order.show', $this->number),
        ];
    }

    /** سپردن نوبتی سفارش به کارمندانی که «دریافت سفارش» دارند */
    /** تقسیم خودکار سفارش‌ها بین کارکنان، یا انتخاب سفارش توسط خود کارکنان (پیش‌فرض) */
    public static function autoAssignOn(): bool
    {
        return setting('assign_mode', 'self') === 'auto';
    }

    /** کارمند خودش مسئول سفارش می‌شود (فقط اگر هنوز مسئولی ندارد) */
    public function claim(User $u): bool
    {
        $ok = static::query()->whereKey($this->id)->whereNull('assignee_id')->update(['assignee_id' => $u->id, 'assigned_at' => now()]) === 1;
        if ($ok) {
            $this->assignee_id = $u->id;
            $this->assigned_at = now();
            $this->log('مسئول پیگیری: '.$u->displayName().' (خودش برداشت)', $u->id);
            $this->setRelation('assignee', $u);
            \App\Services\Chat::reassigned($this);
            \App\Services\Remit::autoDeposit($this);
        }

        return $ok;
    }

    public function autoAssign(): void
    {
        $staff = User::query()->where('receives_orders', true)->where('is_active', true)->whereIn('role', ['admin', 'staff', 'keeper'])->orderBy('id')->pluck('id')->all();
        if (! $staff) {
            return;
        }
        $last = (int) \App\Models\Setting::query()->where('key', 'assign_last')->value('value');
        $next = $staff[0];
        foreach ($staff as $id) {
            if ($id > $last) {
                $next = $id;
                break;
            }
        }
        \App\Models\Setting::query()->updateOrCreate(['key' => 'assign_last'], ['value' => (string) $next]);
        $this->assignTo($next, null, 'خودکار');
    }

    public function assignTo(?int $userId, ?int $byId = null, string $how = ''): void
    {
        if ((int) $this->assignee_id === (int) $userId) {
            return;
        }
        $this->assignee_id = $userId;
        $this->assigned_at = now();
        $this->saveQuietly();
        $name = $userId ? (User::query()->whereKey($userId)->first()?->displayName() ?? '#'.$userId) : 'هیچ‌کس';
        $this->log('مسئول پیگیری: '.$name.($how ? ' ('.$how.')' : ''), $byId);
        $this->unsetRelation('assignee');
        \App\Services\Chat::reassigned($this);
        \App\Services\Remit::autoDeposit($this);
    }

    /** ساعت مجاز ماندن در هر وضعیت (از تنظیمات) */
    public static function followupHours(): array
    {
        if (! setting('followup_enabled', true)) {
            return []; // پیگیری عقب‌افتاده‌ها خاموش است
        }
        $h = (array) setting('followup_hours', []);

        return [
            'on_hold' => max(0, (float) ($h['on_hold'] ?? 2)),
            'processing' => max(0, (float) ($h['processing'] ?? 24)),
            'settling' => max(0, (float) ($h['settling'] ?? 24)),
            'to_freight' => max(0, (float) ($h['to_freight'] ?? 24)),
            'shipped' => max(0, (float) ($h['shipped'] ?? 0)),
        ];
    }

    /** سفارش‌های عقب‌افتاده یک کارمند (یا همه) */
    public static function overdueQuery(?int $userId = null): \Illuminate\Database\Eloquent\Builder
    {
        $q = static::query()->released();
        if ($userId) {
            $q->where('assignee_id', $userId);
        }

        return $q->where(function ($w) {
            $any = false;
            foreach (static::followupHours() as $status => $hours) {
                if ($hours <= 0) {
                    continue;
                }
                $any = true;
                $w->orWhere(fn ($x) => $x->where('status', $status)->where('status_changed_at', '<', now()->subMinutes((int) round($hours * 60))));
            }
            if (! $any) {
                $w->whereRaw('1 = 0');
            }
        });
    }

    public function isOverdue(): bool
    {
        $h = static::followupHours()[$this->status] ?? 0;

        return $h > 0 && $this->status_changed_at && $this->status_changed_at->lt(now()->subMinutes((int) round($h * 60)));
    }
}
