<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** هر کالای داخل JSON و وضعیتش در سایت */
class SyncItem extends Model
{
    public const STATUSES = [
        'new' => 'جدید',
        'created' => 'ساخته شد',
        'updated' => 'به‌روز شد',
        'unchanged' => 'بدون تغییر',
        'skipped' => 'ساخته نشد',
        'queued' => 'در صف ساخت با تصویر',
        'error' => 'خطا',
        'removed' => 'حذف از JSON',
    ];

    public const REASONS = [
        'no_stock' => 'موجودی هر دو انبار صفر است',
        'no_title' => 'نام کالا خالی است',
        'no_price' => 'قیمت صفر یا خالی است',
        'not_listed' => 'در فهرست اکسل نیست',
        'scope_none' => 'ساخت کالای جدید خاموش است',
        'error' => 'خطای پردازش',
        'no_image' => 'تصویر کالا دریافت نشد؛ تا تصویر نیاید کالا ساخته نمی‌شود',
        'deleted' => 'توسط مدیر حذف شد (دوباره ساخته نمی‌شود)',
    ];

    protected $fillable = [
        'source_id', 'code', 'product_id', 'title', 'category', 'raw_price', 'price', 'retail_price', 'markup', 'stock_retail', 'stock_wholesale',
        'per_carton', 'images', 'extra', 'hash', 'status', 'reason', 'message', 'force', 'markup_override', 'image_status', 'image_error',
        'image_tries', 'price_first', 'price_prev', 'in_feed', 'run', 'price_changed_at', 'full_img',
    ];

    protected function casts(): array
    {
        return ['images' => 'array', 'extra' => 'array', 'in_feed' => 'boolean', 'full_img' => 'boolean', 'price_changed_at' => 'datetime', 'raw_price' => 'float'];
    }

    public function source(): BelongsTo
    {
        return $this->belongsTo(SyncSource::class, 'source_id');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
