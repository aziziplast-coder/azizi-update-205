<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PushSubscription extends Model
{
    protected $fillable = ['user_id', 'hash', 'endpoint', 'p256dh', 'auth', 'is_staff', 'last_ok_at'];

    protected function casts(): array
    {
        return ['is_staff' => 'boolean', 'last_ok_at' => 'datetime'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
