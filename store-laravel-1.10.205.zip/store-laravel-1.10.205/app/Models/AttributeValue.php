<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class AttributeValue extends Model
{
    public $timestamps = false;

    protected $fillable = ['attribute_id', 'value', 'color', 'sort'];

    public function attribute(): BelongsTo
    {
        return $this->belongsTo(Attribute::class);
    }

    public function products(): BelongsToMany
    {
        return $this->belongsToMany(Product::class, 'product_attribute_value');
    }

    public function label(): string
    {
        return ($this->attribute?->name ? $this->attribute->name.': ' : '').$this->value;
    }
}
