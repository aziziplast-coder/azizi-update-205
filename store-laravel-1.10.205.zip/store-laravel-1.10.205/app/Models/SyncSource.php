<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** منبع JSON تأمین‌کننده (مثلاً پخش پلاسکو عزیزی) */
class SyncSource extends Model
{
    protected $fillable = ['name', 'url', 'enabled', 'interval', 'options', 'state', 'stats', 'log', 'last_run_at', 'last_ok_at'];

    protected function casts(): array
    {
        return [
            'enabled' => 'boolean',
            'options' => 'array',
            'state' => 'array',
            'stats' => 'array',
            'log' => 'array',
            'last_run_at' => 'datetime',
            'last_ok_at' => 'datetime',
        ];
    }

    public static function defaultOptions(): array
    {
        return [
            'json_path' => 'products',
            'fields' => [
                'code' => 'code', 'title' => 'title', 'price' => 'price', 'compare_price' => 'old_price', 'available' => 'is_available', 'page_url' => 'url',
                'stock_retail' => 'mojud_anbar_khord', 'stock_wholesale' => 'mojud_anbar_omde',
                'per_carton' => 'tedad_dar_carton', 'step' => 'tedad_afzayesh',
                'image' => 'img', 'gallery' => 'images', 'category' => 'cat', 'barcode' => '', 'description' => '',
                'wh_carton' => 'anbar_omde', 'wh_retail' => 'anbar_khord',
            ],
            'headers' => '',
            'match_by' => 'sku',           // sku | barcode | both
            'price_unit' => 'none',        // none | div10 | mul10
            'markup' => 50,
            'tiers' => [],                 // [{from, to, pct}]
            'cat_rules' => [],             // [{match, pct}]
            'round_step' => 1000,
            'round_mode' => 'nearest',     // nearest | up | down
            'retail_markup' => 0,          // درصد اضافه برای قیمت تکی
            'min_price' => 0,
            'stock_mode' => 'flag',        // flag: ۰/۱ یعنی ناموجود/موجود (بدون شمارش) | count: تعداد واقعی
            'wholesale_unit' => 'unit',    // unit | carton
            'availability' => 'any',       // any | flag | retail_only | strict
            'retail_auto' => true,
            'wh_sync' => true,             // شماره انبار عمده/خرده از JSON به کالا
            'wh_auto_create' => true,      // انبارِ شماره جدید خودکار ساخته شود
            'img_download' => true,
            'img_base' => 'https://aziziplast.com/',
            'img_from' => '',
            'img_to' => '',
            'img_max' => 6,
            'img_auto' => true,
            'img_required' => true,    // کالای جدید فقط همراه تصویرش ساخته شود (یکی‌یکی)
            'img_compress' => true,    // فشرده‌سازی بدون افت کیفیت دیداری
            'img_max_side' => 1600,    // بیشترین طول/عرض تصویر (پیکسل)
            'img_quality' => 88,        // کشف خودکار آدرس درست تصویر
            'img_found' => null,       // الگوی پیداشده: {base, from, to} یا {mode: page}
            'site_base' => 'https://aziziplast.com/',
            'create_scope' => 'stock',     // stock | all | none
            'img_out' => 'main',           // کالای ناموجود: main = فقط یک تصویر سبک تا موجود شدن | full = مثل بقیه
            'new_active' => true,
            'category_root' => '',
            'cat_separator' => '/',
            'update_price' => true,
            'update_stock' => true,
            'update_name' => false,
            'update_category' => false,
            'update_images' => false,
            'missing_policy' => 'none',    // none | outofstock | hide
            'only_listed' => false,
            'fix_arabic' => true,
        ];
    }

    public function opt(string $key, mixed $default = null): mixed
    {
        $o = array_replace(static::defaultOptions(), (array) $this->options);

        return data_get($o, $key, $default);
    }

    public function allOptions(): array
    {
        $o = array_replace(static::defaultOptions(), (array) $this->options);
        $o['fields'] = array_replace(static::defaultOptions()['fields'], (array) ($o['fields'] ?? []));

        return $o;
    }

    public function items(): HasMany
    {
        return $this->hasMany(SyncItem::class, 'source_id');
    }

    public function priceChanges(): HasMany
    {
        return $this->hasMany(SyncPriceChange::class, 'source_id');
    }

    public function isRunning(): bool
    {
        return ($this->state['status'] ?? '') === 'running';
    }

    /** نسخه دائمی آخرین JSON سالم (پس از انتقال دامنه هم می‌ماند) */
    public function archivePath(): string
    {
        return $this->dir().'/feed-archive.json';
    }

    /** ذخیره نسخه دائمی + یک نسخه فشرده تاریخ‌دار در روز (۵ نسخه آخر) */
    public function archive(string $file): void
    {
        try {
            @copy($file, $this->archivePath());
            $day = $this->dir().'/feed-'.date('Ymd').'.json.gz';
            if (! is_file($day) && function_exists('gzopen') && ($in = fopen($file, 'rb')) && ($out = gzopen($day, 'wb6'))) {
                while (! feof($in)) {
                    gzwrite($out, fread($in, 1048576));
                }
                fclose($in);
                gzclose($out);
                $old = glob($this->dir().'/feed-*.json.gz') ?: [];
                rsort($old);
                foreach (array_slice($old, 5) as $f) {
                    @unlink($f);
                }
            }
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function archiveInfo(): ?array
    {
        $f = $this->archivePath();

        return is_file($f) ? ['size' => filesize($f), 'at' => filemtime($f)] : null;
    }

    public function dir(): string
    {
        $d = storage_path('app/sync/'.$this->id);
        if (! is_dir($d)) {
            @mkdir($d, 0755, true);
        }

        return $d;
    }

    public function addLog(string $msg, string $level = 'info'): void
    {
        $log = (array) $this->log;
        $log[] = ['t' => now()->toIso8601String(), 'l' => $level, 'm' => $msg];
        $this->log = array_slice($log, -150);
    }
}
