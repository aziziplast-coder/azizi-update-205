<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrderItem extends Model
{
    public $timestamps = false;

    protected $fillable = ['order_id', 'product_id', 'name', 'barcode', 'image', 'mode', 'units', 'per_carton', 'unit_price', 'compare_price', 'total', 'warehouse_id',
        'pick_task_id', 'pick_status', 'picked_units', 'ordered_units', 'picked_at', 'picked_by', 'pick_note', 'round', 'replaces_item_id', 'scanned_units', 'unit_label', 'appendix'];

    public const PICK = ['ok' => 'جمع شد', 'short' => 'کسری', 'missing' => 'ناموجود'];

    protected function casts(): array
    {
        return ['picked_at' => 'datetime', 'desk_at' => 'datetime'];
    }

    public function pickTask(): BelongsTo
    {
        return $this->belongsTo(PickTask::class);
    }

    /** تعداد سفارش اولیه (پیش از اعمال کسری انبار) */
    public function orderedUnits(): int
    {
        return (int) ($this->ordered_units ?? $this->units);
    }

    /** سقف شمارش/بررسی: سفارش، یا بیشتر اگر جمع‌کننده بیشتر جمع کرده (مثلاً مشتری ۵ خواسته، کارتن ۶تایی ← ۶) */
    public function pickCap(): int
    {
        return max($this->orderedUnits(), (int) $this->picked_units);
    }

    /** حداکثر تعدادی که جمع‌کننده می‌تواند بیشتر از سفارش ثبت کند (جلوگیری از اشتباه تایپی) */
    public function overCap(): int
    {
        $w = $this->orderedUnits();

        return max($w * 2, $w + 2 * max(1, (int) $this->per_carton));
    }

    /** برچسب تعداد برای یک مقدار دلخواه */
    public function unitsLabel(int $units): string
    {
        $u = $this->unitName();
        if ($this->isRetail() || $this->per_carton <= 1) {
            return fa($units).' '.$u;
        }
        $c = intdiv($units, $this->per_carton);
        $r = $units % $this->per_carton;

        return trim(($c ? fa($c).' کارتن' : '').($c && $r ? ' و ' : '').($r ? fa($r).' '.$u : '')) ?: '۰';
    }

    /** واحد فروش هنگام سفارش: «جفت»، «دست» (پیش‌فرض «عدد») */
    public function unitName(): string
    {
        return Product::unitNameOf($this->unit_label);
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function warehouse(): BelongsTo
    {
        return $this->belongsTo(Warehouse::class);
    }

    public function isRetail(): bool
    {
        return $this->mode === 'retail';
    }

    /**
     * حالت واقعی خرید این قلم در سبد.
     * کالای «۱ عدد در کارتن» هنگام ثبت سفارش برای نمایش «تکی» نوشته می‌شود (تنظیم single_as_retail)،
     * ولی در اصل از ردیف کارتنی/عمده خریده شده؛ برای ساختن دوباره سبد و موجودی باید کارتنی دیده شود.
     */
    public function cartMode(): string
    {
        return $this->mode === Product::RETAIL && (int) $this->per_carton <= 1 ? Product::CARTON : (string) $this->mode;
    }

    /** ستون موجودی که هنگام ثبت این قلم کم شده است */
    public function stockCol(): string
    {
        return $this->cartMode() === Product::RETAIL ? 'retail_stock' : 'stock';
    }

    public function modeLabel(): string
    {
        if ($this->isRetail()) {
            return 'خرده';
        }

        return $this->per_carton > 1 ? 'کارتنی' : 'عددی';
    }

    /** «۷ کارتن × ۱۲ = ۸۴ عدد» یا «۳ عدد» */
    public function qtyLabel(): string
    {
        $u = $this->unitName();
        if ($this->isRetail() || $this->per_carton <= 1) {
            return fa($this->units).' '.$u;
        }
        if ($this->units % $this->per_carton) {
            return $this->unitsLabel((int) $this->units).' (کارتن '.fa($this->per_carton).'تایی) = '.fa($this->units).' '.$u;
        }

        return fa(intdiv((int) $this->units, $this->per_carton)).' کارتن × '.fa($this->per_carton).' = '.fa($this->units).' '.$u;
    }

    public function cartons(): float|int
    {
        if ($this->isRetail() || $this->per_carton <= 1) {
            return 0;
        }
        $c = $this->units / $this->per_carton;

        return floor($c) == $c ? (int) $c : round($c, 2);
    }

    /** بارکد برای فاکتور و حواله: بارکد زمان سفارش، وگرنه بارکد یا کد فعلی کالا */
    public function code(): string
    {
        return (string) ($this->barcode ?: ($this->product?->barcode ?: ($this->product?->sku ?: '')));
    }
}
