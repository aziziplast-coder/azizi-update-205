<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** پیام دستی / زمان‌بندی‌شده، خلاصه روزانه یا پیام آزمایشی به کانال‌های ربات */
class BotBroadcast extends Model
{
    public const KINDS = ['manual' => 'پیام دستی', 'daily' => 'خلاصه روزانه', 'test' => 'پیام آزمایشی'];

    public const STATUSES = ['queued' => 'در صف', 'done' => 'ارسال شد', 'cancelled' => 'لغو شد'];

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['product_ids' => 'array', 'profile_ids' => 'array', 'results' => 'array', 'send_at' => 'datetime'];
    }
}
