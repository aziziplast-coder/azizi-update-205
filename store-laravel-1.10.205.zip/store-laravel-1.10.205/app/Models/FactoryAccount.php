<?php

namespace App\Models;

use App\Support\Banks;
use Illuminate\Database\Eloquent\Model;

/** حساب‌های ذخیره‌شده کارخانه‌دار (حساب خودش یا اشخاص دیگر) برای انتخاب سریع */
class FactoryAccount extends Model
{
    protected $fillable = ['factory_id', 'kind', 'holder_name', 'bank_name', 'card_number', 'sheba', 'account_number', 'mobile', 'national_id'];

    public function summary(): string
    {
        return trim($this->holder_name.' — '.($this->bank_name ?: 'بانک').' '.($this->card_number ? Banks::formatCard($this->card_number) : ($this->sheba ? Banks::formatSheba($this->sheba) : '')));
    }
}
