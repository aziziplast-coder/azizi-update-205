<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

/** توکن ورود اپ موبایل؛ خود توکن فقط به شکل هش ذخیره می‌شود */
class ApiToken extends Model
{
    protected $fillable = ['user_id', 'token', 'device', 'platform', 'app_version', 'last_used_at'];

    protected function casts(): array
    {
        return ['last_used_at' => 'datetime'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /** @return array{0: ApiToken, 1: string} [رکورد، توکن خام برای اپ] */
    public static function issue(User $user, ?string $device = null, ?string $platform = null, ?string $version = null): array
    {
        $plain = $user->id.'|'.Str::random(48);
        $t = static::query()->create([
            'user_id' => $user->id, 'token' => hash('sha256', $plain),
            'device' => $device ? mb_substr($device, 0, 120) : null, 'platform' => $platform ? mb_substr($platform, 0, 20) : null,
            'app_version' => $version ? mb_substr($version, 0, 20) : null, 'last_used_at' => now(),
        ]);

        return [$t, $plain];
    }

    public static function findPlain(string $plain): ?static
    {
        return $plain === '' ? null : static::query()->where('token', hash('sha256', $plain))->first();
    }
}
