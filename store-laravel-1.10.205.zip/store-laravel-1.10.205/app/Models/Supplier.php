<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** طرف حساب / کارخانه تأمین‌کننده (از اکسل خرید؛ شماره تماس دستی و ماندگار) */
class Supplier extends Model
{
    protected $fillable = ['name', 'name_key', 'phone', 'contact', 'note', 'items_count', 'in_file'];

    protected function casts(): array
    {
        return ['in_file' => 'boolean'];
    }

    public function items(): HasMany
    {
        return $this->hasMany(SupplyItem::class);
    }

    public function orders(): HasMany
    {
        return $this->hasMany(PurchaseOrder::class);
    }
}
