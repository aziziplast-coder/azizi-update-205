<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** فروش حضوری / مرجوعی حضوری */
class WalkinSale extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['sent_at' => 'datetime', 'delivered_at' => 'datetime', 'excel_at' => 'datetime', 'done_at' => 'datetime'];

    public const STATUSES = ['draft' => 'در حال اسکن', 'scanned' => 'اسکن‌شده', 'loaded' => 'بارگیری‌شده', 'returned' => 'مرجوعی', 'done' => 'پایان‌یافته'];

    public const CONDS = ['ok' => 'سالم', 'factory' => 'ایراد کارخانه', 'waste' => 'ضایعات'];

    public function items(): HasMany
    {
        return $this->hasMany(WalkinItem::class, 'sale_id')->orderBy('id');
    }

    public function scanner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'scanned_by');
    }

    public function deliverer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'delivered_by');
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function finisher(): BelongsTo
    {
        return $this->belongsTo(User::class, 'done_by');
    }

    /** شمارش تحویل ملاک است؟ (پس از ثبت بارگیری) */
    public function delivered(): bool
    {
        return $this->kind === 'sale' && $this->delivered_at !== null;
    }

    /** تعداد ملاک یک ردیف: پس از بارگیری شمارش تحویل، وگرنه اسکن اول */
    public function qtyOf(WalkinItem $i): int
    {
        return $this->delivered() ? (int) ($i->d_units ?? 0) : (int) $i->units;
    }

    public function code(): string
    {
        return ($this->kind === 'return' ? 'R-' : 'H-').(1000 + $this->id);
    }

    public function statusLabel(): string
    {
        return self::STATUSES[$this->status] ?? $this->status;
    }
}
