<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

/**
 * مجموعه کالا (مثل «حراجی ۹۹ تومنی»): با شرط (بازه قیمت، دسته، تخفیف‌دار…) یا انتخاب دستی.
 */
class ProductCollection extends Model
{
    protected $table = 'collections';

    public const SORTS = [
        'newest' => 'جدیدترین',
        'cheap' => 'ارزان به گران',
        'expensive' => 'گران به ارزان',
        'popular' => 'پرفروش‌ترین',
        'views' => 'پربازدیدترین',
        'discount' => 'بیشترین تخفیف',
        'manual' => 'ترتیب انتخاب دستی',
        'random' => 'تصادفی',
    ];

    protected $fillable = [
        'title', 'slug', 'description', 'image', 'mode', 'rules', 'product_ids', 'sort_by', 'home_limit', 'display', 'color',
        'on_home', 'is_active', 'sort', 'seo_title', 'seo_description', 'badge', 'badge_color', 'legacy_key',
    ];

    protected function casts(): array
    {
        return ['rules' => 'array', 'product_ids' => 'array', 'on_home' => 'boolean', 'is_active' => 'boolean'];
    }

    protected static function booted(): void
    {
        static::saving(fn (ProductCollection $c) => $c->slug = Product::makeSlug($c->slug ?: $c->title, static::class, $c->id));
        static::saved(fn () => \Illuminate\Support\Facades\Cache::forget('collection.badges'));
        static::deleted(fn () => \Illuminate\Support\Facades\Cache::forget('collection.badges'));
        static::saved(fn () => \Illuminate\Support\Facades\Cache::forget('home.blocks'));
        static::deleted(fn () => \Illuminate\Support\Facades\Cache::forget('home.blocks'));
    }

    public function url(): string
    {
        return route('collection', $this->slug);
    }

    /** لینک ربات (خروجی هم‌شکل سایت قدیمی): اگر شناسه قدیمی دارد همان لینک قدیمی، وگرنه لینک تازه با bot=1 */
    public function botUrl(): string
    {
        if ($this->legacy_key && str_contains($this->legacy_key, ':')) {
            [$w, $i] = explode(':', $this->legacy_key, 2);

            return url('/index.php').'?'.http_build_query(['p' => 'specificAdds', 'what' => $w, 'id' => $i, 'json' => 'true']);
        }

        return $this->jsonUrl().'?bot=1';
    }

    public function jsonUrl(): string
    {
        return route('collection.json', $this->slug);
    }

    /**
     * برچسب مجموعه برای یک کالا (مثل «حراجی ۹۹»)؛ قوانین مجموعه‌های دارای برچسب یک بار کش و روی هر کالا در PHP بررسی می‌شوند.
     *
     * @return array{text: string, color: string, url: string}|null
     */
    public static function badgeFor(Product $p): ?array
    {
        static $rules = null;
        if ($rules === null) {
            $rules = \Illuminate\Support\Facades\Cache::remember('collection.badges', 600, function () {
                if (! \App\Support\DbSchema::hasColumn('collections', 'badge')) {
                    return [];
                }
                $out = [];
                foreach (static::query()->where('is_active', true)->whereNotNull('badge')->where('badge', '!=', '')->orderBy('sort')->get() as $c) {
                    $r = (array) $c->rules;
                    $cats = [];
                    foreach (Category::query()->whereIn('id', array_filter(array_map('intval', (array) ($r['category_ids'] ?? []))) ?: [0])->get() as $cat) {
                        $cats = array_merge($cats, $cat->descendantIds());
                    }
                    $out[] = [
                        'text' => $c->badge, 'color' => $c->badge_color ?: '#e11d48', 'url' => $c->url(), 'manual' => $c->mode === 'manual',
                        'ids' => array_map('intval', (array) $c->product_ids), 'min' => to_int($r['min_price'] ?? null), 'max' => to_int($r['max_price'] ?? null),
                        'field' => ($r['price_field'] ?? 'price') === 'retail' ? 'retail_price' : 'price', 'cats' => array_values(array_unique($cats)),
                        'on_sale' => ! empty($r['on_sale']), 'featured' => ! empty($r['featured']), 'retail' => ! empty($r['retail']),
                        'keyword' => trim((string) ($r['keyword'] ?? '')), 'new_days' => (int) ($r['new_days'] ?? 0),
                    ];
                }

                return $out;
            });
        }
        foreach ($rules as $b) {
            if (in_array($p->id, $b['ids'], true)) {
                return $b;
            }
            if ($b['manual']) {
                continue;
            }
            $price = (int) ($p->{$b['field']} ?? 0);
            if (($b['min'] && $price < $b['min']) || ($b['max'] && $price > $b['max']) || (($b['min'] || $b['max']) && $price <= 0)) {
                continue;
            }
            if ($b['cats'] && ! in_array((int) $p->category_id, $b['cats'], true)) {
                continue;
            }
            if (($b['on_sale'] && ! ($p->compare_price > $p->price)) || ($b['featured'] && ! $p->is_featured) || ($b['retail'] && ! ($p->retail_enabled && $p->per_carton > 1))) {
                continue;
            }
            if ($b['new_days'] && $p->created_at && $p->created_at->lt(now()->subDays($b['new_days']))) {
                continue;
            }
            if ($b['keyword'] !== '' && ! str_contains(\App\Support\Search::key($p->name), \App\Support\Search::key($b['keyword']))) {
                continue;
            }

            return $b;
        }

        return null;
    }

    /** کوئری کالاهای این مجموعه */
    public function products(): Builder
    {
        $q = Product::query()->active()->with('category');
        $ids = array_values(array_filter(array_map('intval', (array) $this->product_ids)));
        if ($this->mode === 'manual') {
            $q->whereIn('id', $ids ?: [0]);
        } else {
            $r = (array) $this->rules;
            $min = to_int($r['min_price'] ?? null);
            $max = to_int($r['max_price'] ?? null);
            $price = ($r['price_field'] ?? 'price') === 'retail' ? 'retail_price' : 'price';
            if ($min) {
                $q->where($price, '>=', $min);
            }
            if ($max) {
                $q->where($price, '<=', $max);
            }
            $cats = array_filter(array_map('intval', (array) ($r['category_ids'] ?? [])));
            if ($cats) {
                $all = [];
                foreach (Category::query()->whereIn('id', $cats)->get() as $c) {
                    $all = array_merge($all, $c->descendantIds());
                }
                $q->whereIn('category_id', array_unique($all));
            }
            if (! empty($r['on_sale'])) {
                $q->onSale();
            }
            if (! empty($r['featured'])) {
                $q->where('is_featured', true);
            }
            if (! empty($r['retail'])) {
                $q->where('retail_enabled', true)->where('per_carton', '>', 1);
            }
            if (! empty($r['min_discount'])) {
                $d = (int) $r['min_discount'];
                $q->onSale()->whereRaw('compare_price * 100 >= ? * compare_price + price * 100', [$d]);
            }
            if (! empty($r['new_days'])) {
                $q->where('created_at', '>=', now()->subDays((int) $r['new_days']));
            }
            if (! empty($r['keyword'])) {
                $q->search((string) $r['keyword']);
            }
            if ($ids) { // در حالت شرطی، انتخاب دستی هم اضافه می‌شود
                $base = clone $q;
                $q = Product::query()->active()->with('category')->where(fn ($w) => $w->whereIn('id', $base->select('products.id'))->orWhereIn('id', $ids));
            }
        }
        if (empty($this->rules['include_out'])) {
            $q->available();
        }

        return static::applySort($q, $this->sort_by, $ids);
    }

    public static function applySort(Builder $q, ?string $sort, array $manualIds = []): Builder
    {
        $q->reorder();

        return match ($sort) {
            'cheap' => $q->orderBy('price')->orderByDesc('id'),
            'expensive' => $q->orderByDesc('price')->orderByDesc('id'),
            'popular' => $q->orderByDesc('sales_count')->orderByDesc('views')->orderByDesc('id'),
            'views' => $q->orderByDesc('views')->orderByDesc('id'),
            'discount' => $q->orderByRaw('CASE WHEN compare_price > price THEN (compare_price - price) * 100 / compare_price ELSE 0 END DESC'),
            'random' => $q->inRandomOrder(),
            'manual' => $manualIds
                ? $q->orderByRaw('CASE id '.implode(' ', array_map(fn ($id, $i) => 'WHEN '.(int) $id.' THEN '.$i, $manualIds, array_keys($manualIds))).' ELSE 99999 END')
                : $q->orderBy('sort')->latest('id'),
            'sort' => $q->orderBy('sort')->latest('id'),
            default => $q->latest('id'),
        };
    }

    /** خروجی JSON مجموعه (برای اپ یا سایت دیگر) */
    /**
     * خروجی هم‌شکل سایت قدیمی برای ربات (index.php?p=specificAdds&…&json=true):
     * آرایه ساده کالاها با id قدیمی، بارکد، تعداد کارتن، قیمت، عکس‌ها و موجود بودن عمده/تکی.
     */
    public function toLegacyFeed(int $limit = 2000): array
    {
        $img = fn (?string $f) => $f ? url(upload_url($f)) : '';

        return $this->products()->limit($limit)->get()->map(fn (Product $p) => [
            'id' => (int) ($p->legacy_id ?: $p->id),
            'name' => (string) $p->name,
            'barcode' => (string) $p->barcode,
            'carton_count' => (int) $p->per_carton > 0 ? $p->per_carton.' '.$p->unitName() : '',
            'price' => (int) $p->unitPrice(Product::CARTON),
            'main_image' => $img($p->image),
            'other_images' => array_values(array_filter(array_map($img, (array) $p->gallery))),
            'available_wholesale' => $p->cartonAvailable(),
            'available_retail' => $p->retailAllowed() && $p->retailAvailable(),
        ])->values()->all();
    }

    public function toFeed(int $limit = 200): array
    {
        return [
            'title' => $this->title,
            'url' => $this->url(),
            'updated_at' => now()->toIso8601String(),
            'products' => $this->products()->limit($limit)->get()->map(fn (Product $p) => [
                'id' => $p->id,
                'name' => $p->name,
                'url' => $p->url(),
                'image' => $p->image ? url(upload_url($p->image)) : null,
                'price' => (int) $p->price,
                'compare_price' => $p->compare_price ? (int) $p->compare_price : null,
                'retail_price' => $p->retailAllowed() ? $p->unitPrice('retail') : null,
                'per_carton' => $p->per_carton,
                'in_stock' => $p->isAvailable(),
                'category' => $p->category?->name,
                'barcode' => $p->barcode,
            ])->values()->all(),
        ];
    }
}
