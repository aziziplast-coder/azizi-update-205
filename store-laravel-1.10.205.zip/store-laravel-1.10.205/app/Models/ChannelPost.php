<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ChannelPost extends Model
{
    protected $fillable = ['product_id', 'channel', 'kind', 'status', 'attempts', 'message_id', 'error', 'sent_at'];

    public const STATUSES = ['queued' => 'در صف', 'sent' => 'ارسال شد', 'failed' => 'ناموفق', 'skipped' => 'رد شد'];

    protected function casts(): array
    {
        return ['sent_at' => 'datetime'];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
