<?php

namespace App\Models;

use App\Support\Redirects;
use Illuminate\Database\Eloquent\Model;

/** ریدایرکت ۳۰۱ آدرس قدیمی به آدرس تازه */
class Redirect extends Model
{
    protected $fillable = ['from_path', 'to_url', 'hits', 'last_hit_at'];

    protected function casts(): array
    {
        return ['last_hit_at' => 'datetime'];
    }

    protected static function booted(): void
    {
        static::saving(function (Redirect $r) {
            $r->from_path = mb_substr(Redirects::norm((string) $r->from_path), 0, 500);
            $r->from_hash = sha1($r->from_path);
        });
    }
}
