<?php

namespace App\Providers\Filament;

use App\Filament\Auth\Login;
use App\Filament\Pages\Dashboard;
use App\Http\Middleware\EnsureInstalled;
use Filament\FontProviders\LocalFontProvider;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Navigation\MenuItem;
use Filament\Navigation\NavigationGroup;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\Support\Enums\MaxWidth;
use Filament\View\PanelsRenderHook;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->id('admin')
            ->path('admin')
            ->login(Login::class)
            ->profile(\App\Filament\Auth\EditProfile::class, isSimple: false)
            ->brandName(fn () => store_name())
            ->brandLogo(fn () => setting('logo') ? upload_url(setting('logo')) : null)
            ->brandLogoHeight('2.4rem')
            ->favicon(fn () => setting('favicon') ? upload_url(setting('favicon')) : '/pwa-icon-64.png')
            ->colors(fn () => [
                'primary' => Color::hex(setting('brand_color', '#4f4a63')),
                'gray' => Color::Slate,
            ])
            ->font('Vazirmatn', url: '/fonts/fonts.css', provider: LocalFontProvider::class)
            ->darkMode(true)
            ->defaultAvatarProvider(\App\Filament\Support\InitialsAvatar::class)
            ->sidebarCollapsibleOnDesktop()
            ->sidebarWidth('17rem')
            ->maxContentWidth(MaxWidth::Full)
            ->globalSearchKeyBindings(['command+k', 'ctrl+k'])
            // ناوبری SPA خاموش: با «بازگشت» مرورگر صفحه‌ها (جدول کالاها و…) ناقص بازسازی می‌شدند و کلیدهای جدول/دکمه ذخیره گاهی کار نمی‌کرد؛
            // بارگذاری کامل هر صفحه مطمئن است (فایل‌های ثابت پنل در مرورگر کش می‌شوند)
            // دانلودها (پشتیبان، اکسل، PDF، فایل اپ) و صفحه‌های بیرون از پنل با بارگذاری کامل باز شوند، نه ناوبری SPA
            ->spaUrlExceptions(fn (): array => [
                url('/admin-tools').'/*', url('/download').'/*', url('/buyer').'*', url('/keeper').'*', url('/order').'/*',
                '*.zip', '*.xlsx', '*.xls', '*.csv', '*.pdf', '*.apk',
            ])
            ->navigationGroups([
                NavigationGroup::make('فروش'),
                NavigationGroup::make('مشاوران و پورسانت')->collapsed(),
                NavigationGroup::make('باشگاه مشتریان')->collapsed(),
                NavigationGroup::make('حسابداری'),
                NavigationGroup::make('کالاها'),
                NavigationGroup::make('بازاریابی'),
                NavigationGroup::make('محتوا'),
                NavigationGroup::make('گزارش‌ها'),
                NavigationGroup::make('کاربران و دسترسی‌ها'),
                NavigationGroup::make('تنظیمات'),
                NavigationGroup::make('ابزار سایت'),
            ])
            ->userMenuItems([
                MenuItem::make()->label('مشاهده سایت')->url('/', shouldOpenInNewTab: true)->icon('heroicon-o-globe-alt'),
            ])
            ->navigationItems([
                \Filament\Navigation\NavigationItem::make('کارتابل انبار')->url('/keeper', shouldOpenInNewTab: true)->icon('heroicon-o-device-phone-mobile')
                    ->group('فروش')->sort(2)->visible(fn () => (bool) auth()->user()?->hasPerm('orders'))
                    ->badge(function () {
                        try {
                            return auth()->user() ? \App\Support\NavBadge::count('keeper', fn () => \App\Services\Picking::tasksQuery(auth()->user())->where('status', '!=', 'done')->count()) : null;
                        } catch (\Throwable) {
                            return null; // جدول هنوز ساخته نشده (مایگریشن اجرا نشده)
                        }
                    }),
            ])
            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\\Filament\\Resources')
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\\Filament\\Pages')
            ->pages([Dashboard::class])
            ->discoverWidgets(in: app_path('Filament/Widgets'), for: 'App\\Filament\\Widgets')
            ->widgets([])
            ->renderHook(PanelsRenderHook::HEAD_END, fn () => view('filament.head'))
            ->renderHook(PanelsRenderHook::BODY_START, fn () => auth()->check() && (session('m_app') || request('from') === 'app') ? view('manage.panel-bar') : '')
            ->renderHook(PanelsRenderHook::BODY_END, fn () => auth()->check() ? view('filament.order-alert') : '')
            ->renderHook(PanelsRenderHook::BODY_END, fn () => auth()->check() ? view('partials.rcpt-view') : '')
            ->renderHook(PanelsRenderHook::BODY_END, fn () => auth()->check() ? '<datalist id="unit-labels">'.implode('', array_map(fn ($u) => '<option value="'.$u.'">', ['عدد', 'جفت', 'دست', 'دست ۶ عددی', 'دست ۱۲ عددی', 'پک', 'پک ۳ عددی', 'پک ۶ عددی', 'ست', 'بسته', 'جین', 'کیلو'])).'</datalist>' : '')
            ->renderHook(PanelsRenderHook::CONTENT_START, fn () => auth()->check() && ($err = \Illuminate\Support\Facades\Cache::get('schema_error'))
                ? new \Illuminate\Support\HtmlString('<div style="background:#fee2e2;color:#991b1b;border:1px solid #fca5a5;border-radius:10px;padding:10px 14px;margin-bottom:12px;font-size:13px"><b>به‌روزرسانی پایگاه داده کامل نشد.</b> چند دقیقه دیگر خودکار دوباره تلاش می‌شود. متن خطا را برای پشتیبانی بفرستید:<br><code dir="ltr" style="display:block;margin-top:6px;white-space:pre-wrap">'.e($err).'</code></div>') : '')
            ->renderHook(PanelsRenderHook::CONTENT_START, fn () => auth()->check() ? view('filament.followup-banner') : '')
            ->middleware([
                \App\Http\Middleware\ForceHttps::class,
                EnsureInstalled::class,
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                \App\Http\Middleware\AdminAuthenticate::class,
                \App\Http\Middleware\EnforceFollowup::class,
            ]);
    }
}
