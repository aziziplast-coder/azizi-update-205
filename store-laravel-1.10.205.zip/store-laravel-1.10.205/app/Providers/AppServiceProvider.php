<?php

namespace App\Providers;

use App\Models\Category;
use App\Models\Page;
use App\Models\Product;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(\App\Services\Cart::class);
    }

    public function boot(): void
    {
        // سبک و فشرده کردن HTML/پاسخ‌های Livewire (بعد از تزریق اسکریپت Livewire)
        \Illuminate\Support\Facades\Event::listen(\Illuminate\Foundation\Http\Events\RequestHandled::class,
            fn ($e) => \App\Http\Middleware\SlimResponse::apply($e->request, $e->response));

        // کش صفحه مهمان‌ها: با هر تغییر محتوای فروشگاه تازه شود
        foreach ([\App\Models\Product::class, \App\Models\Category::class, \App\Models\Page::class, \App\Models\Post::class, \App\Models\PostCategory::class,
            \App\Models\ProductCollection::class, \App\Models\Review::class, \App\Models\Attribute::class, \App\Models\AttributeValue::class, \App\Models\Redirect::class] as $cls) {
            $cls::saved(fn () => \App\Http\Middleware\GuestPageCache::bump());
            $cls::deleted(fn () => \App\Http\Middleware\GuestPageCache::bump());
        }
        // فیلد «اولویت/ترتیب» خالی در فرم‌ها = ۰ (ستون sort در پایگاه داده خالی نمی‌پذیرد)
        \Illuminate\Support\Facades\Event::listen('eloquent.saving: *', function (string $event, array $models) {
            foreach ($models as $m) {
                if ($m instanceof \Illuminate\Database\Eloquent\Model && array_key_exists('sort', $m->getAttributes()) && $m->getAttributes()['sort'] === null) {
                    $m->setAttribute('sort', 0);
                }
            }
        });
        Schema::defaultStringLength(191);

        // فشرده‌سازی gzip پاسخ‌ها، بعد از همه شنونده‌ها (مثل تزریق اسکریپت Livewire)
        $this->app->booted(function () {
            \Illuminate\Support\Facades\Event::listen(\Illuminate\Foundation\Http\Events\RequestHandled::class, function ($e) {
                try {
                    \App\Http\Middleware\Compress::apply($e->request, $e->response);
                } catch (\Throwable) {
                }
                try {
                    \App\Support\SlowLog::handled($e->request, $e->response);
                } catch (\Throwable) {
                }
            });
        });
        // ثبت درخواست‌های کند (سلامت هاست)
        if (! $this->app->runningInConsole()) {
            \App\Support\SlowLog::boot();
        }

        // مایگریشن‌های اجرانشده (مثلاً به‌روزرسانی نیمه‌کاره) خودکار اجرا شوند
        if (! app()->runningInConsole() && function_exists('installed') && installed()) {
            try {
                \App\Support\SchemaGuard::check();
            } catch (\Throwable) {
            }
        }

        // سایت به دامنه خاصی وابسته نیست: آدرس‌ها (نقشه سایت، لینک‌ها، پیامک، PWA) از دامنه‌ای که باز شده ساخته می‌شوند
        if (! app()->runningInConsole()) {
            try {
                $req = request();
                $host = strtolower((string) $req->getHost());
                if ($host !== '') {
                    $cfg = (string) config('app.url');
                    $cfgHost = strtolower((string) parse_url($cfg, PHP_URL_HOST));
                    // فقط اگر خود درخواست https است (یا CDN اعلام کند)؛ اگر SSL فعال نباشد، فرم‌ها به https نمی‌روند و ورود قفل نمی‌شود
                    $https = $req->isSecure();
                    $port = $req->getPort();
                    $root = ($https ? 'https' : 'http').'://'.$host.(in_array((int) $port, [80, 443, 0], true) ? '' : ':'.$port);
                    config(['app.url' => $root]);
                    URL::forceRootUrl($root);
                    if ($https) {
                        URL::forceScheme('https');
                    }
                }
            } catch (\Throwable) {
            }
        }

        // سبد مهمان بعد از ورود به حساب منتقل می‌شود
        \Illuminate\Support\Facades\Event::listen(\Illuminate\Auth\Events\Login::class, function ($e) {
            if ($e->user instanceof \App\Models\User && ! app()->runningInConsole()) {
                \App\Services\Cart::mergeOnLogin($e->user);
            }
        });

        // اگر افزونه fileinfo روی هاست نیست، نوع فایل‌های آپلودی از روی محتوا/پسوند تشخیص داده می‌شود
        if (! extension_loaded('fileinfo')) {
            \Symfony\Component\Mime\MimeTypes::getDefault()->registerGuesser(new \App\Support\SimpleMimeGuesser);
        }

        // فایل‌های موقت آپلود پنل در پوشه غیرعمومی
        config([
            'livewire.temporary_file_upload.disk' => 'local',
            'livewire.temporary_file_upload.rules' => ['required', 'file', 'max:61440'],
        ]);

        $flushShop = function () {
            Cache::forget('home.blocks');
            Cache::forget('sitemap.xml');
        };
        Product::saved($flushShop);
        Product::deleted($flushShop);
        Product::saved(fn (Product $p) => \App\Services\Channels::onSaved($p));
        Product::saved(fn () => \App\Services\BotHub::dirty());
        // سفارشی که از کلیک پست کانال ربات آمده (برای آمار «سفارش از کانال»)
        \App\Models\Order::creating(function ($o) {
            try {
                $src = (int) request()->cookie('bsrc');
                if ($src > 0 && ! $o->bot_src && \App\Services\BotHub::ready() && \App\Support\DbSchema::hasColumn('orders', 'bot_src')) {
                    $o->bot_src = $src;
                }
            } catch (\Throwable) {
            }
        });
        Product::saved(function (Product $p) {
            if ($p->wasChanged(['in_stock', 'stock', 'retail_stock', 'retail_in_stock', 'is_active'])) {
                app(\App\Services\StockNotifier::class)->check($p);
                // شارژ شد: علامت «سفارش به کارخانه» برداشته می‌شود
                if ($p->restock_at && $p->isAvailable()) {
                    \App\Models\Product::query()->whereKey($p->id)->update(['restock_at' => null, 'restock_by' => null, 'restock_note' => null]);
                }
            }
        });
        $flushCats = function () use ($flushShop) {
            $flushShop();
            Cache::forget('menu.cats');
            Cache::forget('cat.tree.default');
            Cache::forget('cat.tree.legacy');
            Cache::forget('cat.counts');
            Cache::forget('cat.roots');
        };
        Category::saved($flushCats);
        Category::deleted($flushCats);
        Page::saved(fn () => Cache::forget('footer.pages'));
        Page::deleted(fn () => Cache::forget('footer.pages'));
    }
}
