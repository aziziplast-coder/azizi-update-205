<?php

namespace App\Services;

use App\Models\Category;
use App\Models\Product;
use App\Models\Warehouse;
use App\Support\SheetReader;
use Exception;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use OpenSpout\Common\Entity\Row;
use OpenSpout\Common\Entity\Style\Style;
use OpenSpout\Writer\XLSX\Entity\SheetView;
use OpenSpout\Writer\XLSX\Writer;

/**
 * ورود و خروج اکسل محصولات بر اساس بارکد (جایگزین افزونه‌های «ورودی اکسل» و «همگام‌سازی موجودی با بارکد»).
 */
class Excel
{
    /** ستون‌های قابل نگاشت */
    public static function targets(): array
    {
        return [
            'compare_price' => 'قیمت قبل از تخفیف',
            'stock' => 'موجودی انبار عمده (تعداد عدد)',
            'per_carton' => 'تعداد در کارتن',
            'retail_price' => 'قیمت فروش تکی (هر عدد)',
            'retail_stock' => 'موجودی انبار خرده (عدد)',
            'retail_max' => 'حداکثر خرید تکی',
            'category' => 'دسته‌بندی (نام)',
            'warehouse' => 'انبار عمده (نام یا کد)',
            'retail_warehouse' => 'انبار خرده (نام یا کد)',
            'sku' => 'کد کالا (SKU)',
            'short_description' => 'توضیح کوتاه',
            'description' => 'توضیحات کامل',
        ];
    }

    public static function colIndex(string $letters): int
    {
        $letters = strtoupper(preg_replace('/[^A-Za-z]/', '', $letters));
        if ($letters === '') {
            return -1;
        }
        $n = 0;
        foreach (str_split($letters) as $ch) {
            $n = $n * 26 + (ord($ch) - 64);
        }

        return $n - 1;
    }

    public static function barcode(mixed $v): string
    {
        $v = en_digits(trim((string) $v));
        $v = str_replace(["\xC2\xA0", ' ', "'", "\t", "\r", "\n"], '', $v);
        if (preg_match('/^\d+(\.\d+)?[eE][+\-]?\d+$/', $v)) {
            $v = sprintf('%.0f', (float) $v);
        }
        if (preg_match('/^\d+\.0+$/', $v)) {
            $v = preg_replace('/\.0+$/', '', $v);
        }

        return strtoupper($v);
    }

    /** کلید مقایسه: صفرهای ابتدای بارکد عددی نادیده گرفته می‌شود */
    public static function key(string $barcode): string
    {
        if ($barcode === '') {
            return '';
        }

        return ctype_digit($barcode) ? (ltrim($barcode, '0') ?: '0') : $barcode;
    }

    public static function text(mixed $v): string
    {
        $v = str_replace(['ي', 'ك', "\xC2\xA0"], ['ی', 'ک', ' '], (string) $v);

        return trim(preg_replace('/\s+/u', ' ', $v));
    }

    /** دو نام یکی‌اند؟ (ی/ک عربی، رقم فارسی/انگلیسی و فاصله‌ها فرقی ندارد) */
    public static function sameName(string $a, string $b): bool
    {
        $n = fn ($v) => preg_replace('/\s+/u', '', en_digits(static::productName($v)));

        return $n($a) === $n($b);
    }

    /** نام کالا در فایل هلو: «جاپیازی اطلس // 4 عددی» ← «جاپیازی اطلس» (بعد از // خوانده نمی‌شود) */
    public static function productName(mixed $v): string
    {
        $t = static::text($v);
        $t = preg_split('~\s*(?://|／／|\\\\)~u', $t, 2)[0];

        return trim($t, " \t-–—|");
    }

    public static function number(mixed $v, bool $rial = false): ?int
    {
        $s = preg_replace('/[^0-9.\-]/', '', str_replace([',', '٬', ' ', '٫'], ['', '', '', '.'], en_digits((string) $v)));
        if ($s === '' || $s === '.' || $s === '-') {
            return null;
        }
        $n = (float) $s;
        if ($rial) {
            $n = floor($n / 10);
        }

        return (int) round($n);
    }

    /**
     * اجرای ورود از اکسل.
     *
     * @param  array<int, array{path: string, name: string}>  $files
     */
    public function import(array $files, array $o, int $userId): array
    {
        @set_time_limit(300);
        @ini_set('memory_limit', '512M');
        $t0 = microtime(true);
        $map = [
            'barcode' => static::colIndex($o['col_barcode'] ?? 'A'),
            'name' => static::colIndex($o['col_name'] ?? ''),
            'price' => static::colIndex($o['col_price'] ?? ''),
        ];
        if ($map['barcode'] < 0) {
            throw new Exception('ستون بارکد مشخص نشده است.');
        }
        $extras = [];
        foreach ((array) ($o['extra'] ?? []) as $e) {
            $c = static::colIndex((string) ($e['col'] ?? ''));
            if ($c >= 0 && isset(static::targets()[$e['target'] ?? ''])) {
                $extras[] = ['c' => $c, 't' => $e['target']];
            }
        }
        $rial = ! empty($o['rial']);
        // تعداد ردیف‌های بالای جدول (عنوان ستون‌ها و سطرهای عنوان گزارش هلو) که خوانده نمی‌شوند
        $skip = isset($o['skip']) ? max(0, (int) $o['skip']) : (! empty($o['header']) ? 1 : 0);

        $data = [];
        $st = ['rows' => 0, 'dups' => 0, 'invalid' => 0];
        foreach ($files as $f) {
            $seen = 0;
            SheetReader::read($f['path'], $f['name'], function ($row) use (&$data, &$st, &$seen, $skip, $map, $extras) {
                if ($seen++ < $skip) {
                    return;
                }
                $st['rows']++;
                $b = static::barcode($row[$map['barcode']] ?? '');
                $k = static::key($b);
                if ($k === '') {
                    $st['invalid']++;

                    return;
                }
                if (isset($data[$k])) {
                    $st['dups']++;

                    return;
                }
                $x = [];
                foreach ($extras as $e) {
                    $x[$e['t']] = $row[$e['c']] ?? '';
                }
                $data[$k] = [
                    'barcode' => $b,
                    'name' => $map['name'] >= 0 ? static::productName($row[$map['name']] ?? '') : '',
                    'price' => $map['price'] >= 0 ? ($row[$map['price']] ?? '') : '',
                    'x' => $x,
                ];
            });
        }
        if (! $st['rows']) {
            throw new Exception('هیچ ردیفی از فایل خوانده نشد. فایل خالی است یا داده‌ها در شیت دیگری هستند.');
        }
        if (! $data) {
            throw new Exception('ستون بارکد ('.strtoupper($o['col_barcode'] ?? 'A').') در همه ردیف‌ها خالی بود. حرف ستون بارکد را بررسی کنید.');
        }

        $site = [];
        $site = static::siteIndex(['id', 'barcode', 'name', 'price', 'in_stock', 'is_active', 'stock', 'per_carton', 'warehouse_id']);
        $cats = Category::query()->pluck('id', 'name')->all();
        $whs = Warehouse::query()->get();
        $whId = function ($v) use ($whs) {
            $v = trim(en_digits((string) $v));
            foreach ($whs as $w) {
                if (strcasecmp((string) $w->code, $v) === 0 || (string) $w->id === $v || $w->name === $v) {
                    return $w->id;
                }
            }

            return null;
        };

        // پیدا شدن فقط با «کد قبلی» ولی نام کاملاً فرق دارد ← هلو کد قدیمی را به کالای تازه داده؛ کالای قدیمی دست نخورد
        foreach ($data as $k => $d) {
            $p = $site[$k] ?? null;
            if ($p && $d['name'] !== '' && static::key(static::barcode((string) $p->sku)) !== (string) $k && static::key(static::barcode((string) $p->barcode)) !== (string) $k
                && ! static::sameName($d['name'], (string) $p->name) && \App\Services\CodeChanges::similarity($d['name'], (string) $p->name) < 60) {
                unset($site[$k]);
            }
        }
        // کد کالا در هلو عوض شده؟ (کالای سایت با نام یکسان که کد فعلی‌اش در فایل نیست) ← کد سایت هم عوض می‌شود
        $codeChanges = ['applied' => [], 'pending' => []];
        try {
            $codeChanges = \App\Services\CodeChanges::detect($data, $site, $rial);
        } catch (\Throwable $e) {
            report($e);
        }

        $lists = [
            'codechange' => ['head' => ['کد قبلی', 'کد جدید هلو', 'نام کالا'], 'rows' => $codeChanges['applied']],
            'codepending' => ['head' => ['کد فعلی سایت', 'کد در فایل', 'نام کالا (نیاز به تأیید)'], 'rows' => $codeChanges['pending']],
            'unknown' => ['head' => ['بارکد', 'نام در فایل', 'قیمت در فایل'], 'rows' => []],
            'photo' => ['head' => ['ردیف', 'بارکد', 'نام محصول', 'نام انباردار'], 'rows' => []],
            'renamed' => ['head' => ['بارکد', 'نام قبلی', 'نام جدید'], 'rows' => []],
            'price' => ['head' => ['بارکد', 'نام', 'قیمت قبلی', 'قیمت جدید'], 'rows' => []],
            'outofstock' => ['head' => ['بارکد', 'نام'], 'rows' => []],
        ];
        $counts = ['found' => 0, 'created' => 0, 'price' => 0, 'renamed' => 0, 'instock' => 0, 'outofstock' => 0];
        $stockMode = $o['stock_mode'] ?? 'none';
        $matchedIds = [];
        $becameAvailable = [];

        DB::transaction(function () use ($data, $site, $o, $rial, &$cats, $whId, $stockMode, &$lists, &$counts, &$matchedIds, &$becameAvailable) {
            foreach ($data as $k => $d) {
                $price = $d['price'] !== '' ? static::number($d['price'], $rial) : null;
                if (! isset($site[$k])) {
                    $lists['unknown']['rows'][] = [$d['barcode'], $d['name'], $price];
                    $lists['photo']['rows'][] = [count($lists['photo']['rows']) + 1, $d['barcode'], $d['name'], ''];
                    if (! empty($o['create_unknown']) && $d['name'] !== '') {
                        $p = new Product(['name' => $d['name'], 'barcode' => $d['barcode'], 'price' => (int) $price, 'is_active' => ! empty($o['create_active'])]);
                        $this->applyExtras($p, $d['x'], $rial, $cats, $whId);
                        if (\App\Models\Warehouse::isLoose((int) $p->warehouse_id)) { // انبار عددی: کارتن ندارد
                            $p->per_carton = 1;
                            $p->retail_enabled = false;
                        }
                        $p->save();
                        $counts['created']++;
                    }

                    continue;
                }
                $p = $site[$k];
                $matchedIds[] = $p->id;
                $counts['found']++;
                $upd = [];
                if (! empty($o['update_price']) && $price !== null && $price > 0 && $price !== (int) $p->price) {
                    $lists['price']['rows'][] = [$d['barcode'], $p->name, $p->price, $price];
                    $upd['price'] = $price;
                    $counts['price']++;
                }
                if (! empty($o['update_name']) && $d['name'] !== '' && ! static::sameName((string) $p->name, $d['name'])) {
                    $lists['renamed']['rows'][] = [$d['barcode'], $p->name, $d['name']];
                    $upd['name'] = $d['name'];
                    $counts['renamed']++;
                }
                if (in_array($stockMode, ['instock', 'sync'], true)) {
                    $cartonOff = $p->stock !== null && $p->stock < max(1, (int) $p->per_carton);
                    if (! $p->in_stock || $cartonOff) {
                        $upd['in_stock'] = true;
                        if ($cartonOff) {
                            $upd['stock'] = null; // «ناموجود کارتنی» اسکنر هم برداشته شود
                        }
                        $becameAvailable[] = $p->id;
                    }
                }
                if ($stockMode === 'outofstock' && $p->in_stock) {
                    $upd['in_stock'] = false;
                }
                $full = new Product;
                $this->applyExtras($full, $d['x'], $rial, $cats, $whId);
                $upd += array_intersect_key($full->getAttributes(), array_flip(['compare_price', 'stock', 'per_carton', 'retail_price', 'retail_stock', 'retail_max', 'category_id', 'warehouse_id', 'retail_warehouse_id', 'sku', 'short_description', 'description', 'retail_enabled', 'retail_in_stock']));
                // انبار «فروش عددی» (سوله خرده‌ریز / نوید): تعداد در کارتن هلو اعمال نمی‌شود؛ فروش طبق قانون انبار
                // (تعداد در کارتنی که خودتان برای کالای «فقط کارتنی» گذاشته‌اید دست نمی‌خورد)
                if (\App\Models\Warehouse::isLoose((int) ($upd['warehouse_id'] ?? $p->warehouse_id))) {
                    unset($upd['per_carton'], $upd['retail_enabled'], $upd['retail_in_stock']);
                }
                if (array_key_exists('stock', $upd) && $upd['stock'] > 0 && ! $p->in_stock) {
                    $upd['in_stock'] = true;
                    $becameAvailable[] = $p->id;
                }
                if ($upd) {
                    $upd['updated_at'] = now();
                    Product::query()->whereKey($p->id)->update(Product::stampStock($upd));
                }
            }
            if ($stockMode === 'instock' || $stockMode === 'sync') {
                $counts['instock'] = count($matchedIds);
            }
            if ($stockMode === 'sync') {
                // کالاهای دارای بارکد که در فایل نبودند → ناموجود
                $q = Product::query()->whereNotNull('barcode')->where('in_stock', true)->whereNotIn('id', $matchedIds ?: [0]);
                foreach ($q->get(['id', 'barcode', 'name']) as $p) {
                    $lists['outofstock']['rows'][] = [$p->barcode, $p->name];
                }
                $counts['outofstock'] = $q->update(['in_stock' => false, 'updated_at' => now()]);
            }
            if ($stockMode === 'outofstock') {
                $counts['outofstock'] = count($matchedIds);
            }
        });

        // پیامک «موجود شد» فقط وقتی اپراتور تیکش را زده باشد
        if (! empty($o['notify'])) {
            foreach (Product::query()->whereIn('id', array_unique($becameAvailable))->get() as $p) {
                app(StockNotifier::class)->check($p);
            }
        }
        // اپ خرید و تأمین: کالاهای این فایل «موجود / بار رسید» (حتی کالایی که در سایت ساخته نشده)
        if (in_array($stockMode, ['instock', 'sync'], true)) {
            try {
                $keys = array_map('strval', array_keys($data));
                foreach ($data as $k => $d) {
                    if (isset($site[$k])) {
                        foreach ([$site[$k]->sync_code, $site[$k]->sku, $site[$k]->barcode] as $code) {
                            $keys[] = static::key(static::barcode((string) $code));
                        }
                    }
                }
                $counts['arrived'] = Purchasing::markArrived(array_unique($keys));
            } catch (\Throwable $e) {
                report($e);
            }
        }
        Cache::forget('home.blocks');
        if (in_array($stockMode, ['instock', 'sync'], true)) {
            $counts['json'] = static::toJson(array_column($data, 'barcode'), [], $stockMode === 'sync');
        }

        $report = [
            'at' => now()->toIso8601String(),
            'files' => implode('، ', array_column($files, 'name')),
            'stats' => $st + $counts + ['unknown' => count($lists['unknown']['rows']), 'codechange' => count($codeChanges['applied']), 'codepending' => count($codeChanges['pending']), 'seconds' => round(microtime(true) - $t0, 1)],
            'lists' => $lists,
        ];
        Cache::put('excel.report.'.$userId, $report, now()->addDays(7));

        return $report;
    }

    protected function applyExtras(Product $p, array $x, bool $rial, array &$cats, callable $whId): void
    {
        foreach ($x as $t => $raw) {
            $raw = trim((string) $raw);
            if ($raw === '') {
                continue;
            }
            switch ($t) {
                case 'compare_price':
                case 'retail_price':
                    $n = static::number($raw, $rial);
                    if ($n !== null) {
                        $p->{$t} = $n > 0 ? $n : null;
                        if ($t === 'retail_price' && $n > 0) {
                            $p->retail_enabled = true;
                        }
                    }
                    break;
                case 'stock':
                case 'retail_stock':
                case 'retail_max':
                case 'per_carton':
                    $n = static::number($raw);
                    if ($n !== null) {
                        $p->{$t} = $t === 'per_carton' ? max(1, $n) : $n;
                        if ($t === 'retail_stock') {
                            $p->retail_in_stock = $n > 0;
                        }
                    }
                    break;
                case 'category':
                    $name = static::text(preg_split('/[,|،]/u', $raw)[0]);
                    if ($name !== '') {
                        if (! isset($cats[$name])) {
                            $cats[$name] = Category::create(['name' => $name])->id;
                        }
                        $p->category_id = $cats[$name];
                    }
                    break;
                case 'warehouse':
                    if ($id = $whId($raw)) {
                        $p->warehouse_id = $id;
                    }
                    break;
                case 'retail_warehouse':
                    if ($id = $whId($raw)) {
                        $p->retail_warehouse_id = $id;
                    }
                    break;
                default:
                    $p->{$t} = static::text($raw);
            }
        }
    }

    /** شناسه دسته‌ها همراه همه زیردسته‌ها */
    public static function expandCategories(array $ids): array
    {
        $all = [];
        foreach (Category::query()->whereIn('id', array_map('intval', $ids))->get() as $c) {
            $all = array_merge($all, $c->descendantIds());
        }

        return array_values(array_unique($all)) ?: [0];
    }

    /**
     * به‌روزرسانی موجودی یک انبار از اکسل تک‌ستونه (فقط بارکد) یا بارکد + تعداد.
     * انبار عمده → ستون stock، انبار خرده → ستون retail_stock. گزارش هر انبار جدا ذخیره می‌شود.
     *
     * @param  array<int, array{path: string, name: string}>  $files
     */
    /**
     * کالاهای سایت بر اساس بارکد؛ کالایی که بارکد ندارد (مثلاً ساخته‌شده از JSON) با کد کالا (SKU/کد همگام‌سازی) پیدا می‌شود.
     * بارکد بر کد اولویت دارد.
     */
    public static function siteIndex(array $cols, bool $plain = false): array
    {
        $site = [];
        $rows = Product::query()->where(fn ($q) => $q->whereNotNull('barcode')->orWhereNotNull('sku')->orWhereNotNull('sync_code'))
            ->when($plain, fn ($q) => $q->toBase())->get(array_values(array_unique(array_merge($cols, ['sku', 'sync_code', 'barcode']))));
        // فقط کد فعلی هلو (sku)؛ کد قدیمی هیچ کالایی ملاک نیست (هلو گاهی کد قدیمی را به کالای دیگری می‌دهد)
        foreach ($rows as $p) {
            $k = static::key(static::barcode((string) $p->sku));
            if ($k !== '' && ! isset($site[$k])) {
                $site[$k] = $p;
            }
        }
        foreach ($rows as $p) {
            foreach ((trim((string) $p->sku) === '' ? [$p->sync_code] : []) as $code) { // کد همگام‌سازی فقط برای کالای بدون کد هلو
                $k = static::key(static::barcode((string) $code));
                if ($k !== '' && ! isset($site[$k])) {
                    $site[$k] = $p;
                }
            }
        }
        foreach ($rows as $p) {
            $k = static::key(static::barcode((string) $p->barcode));
            if ($k !== '') {
                $site[$k] = $p;
            }
        }

        return $site;
    }

    public function importStock(array $files, array $o, int $userId): array
    {
        @set_time_limit(300);
        @ini_set('memory_limit', '512M');
        $t0 = microtime(true);
        $wh = ($o['warehouse'] ?? 'carton') === 'retail' ? 'retail' : 'carton';
        $col = $wh === 'retail' ? 'retail_stock' : 'stock';
        $bc = static::colIndex($o['col_barcode'] ?? 'A');
        $qc = static::colIndex($o['col_qty'] ?? '');
        $unitCarton = $wh === 'carton' && ($o['qty_unit'] ?? 'unit') === 'carton';
        $missing = $o['missing'] ?? 'keep'; // keep | zero | out
        if ($bc < 0) {
            throw new Exception('ستون بارکد مشخص نشده است.');
        }
        $header = ! empty($o['header']);
        $data = [];
        $st = ['rows' => 0, 'dups' => 0, 'invalid' => 0];
        foreach ($files as $f) {
            $first = true;
            SheetReader::read($f['path'], $f['name'], function ($row) use (&$data, &$st, &$first, $header, $bc, $qc) {
                if ($first) {
                    $first = false;
                    if ($header) {
                        return;
                    }
                }
                $st['rows']++;
                $b = static::barcode($row[$bc] ?? '');
                $k = static::key($b);
                if ($k === '') {
                    $st['invalid']++;

                    return;
                }
                $q = $qc >= 0 ? static::number($row[$qc] ?? '') : null;
                if (isset($data[$k])) {
                    $st['dups']++;
                    if ($q !== null) { // بارکد تکراری: تعدادها جمع می‌شوند
                        $data[$k]['q'] = ($data[$k]['q'] ?? 0) + $q;
                    }

                    return;
                }
                $data[$k] = ['b' => $b, 'q' => $q];
            });
        }
        if (! $data) {
            throw new Exception('هیچ بارکدی در ستون '.strtoupper($o['col_barcode'] ?? 'A').' پیدا نشد.');
        }
        $site = [];
        $site = static::siteIndex(['id', 'barcode', 'name', 'per_carton', 'stock', 'retail_stock', 'in_stock', 'retail_in_stock', 'retail_enabled']);
        $lists = [
            'changed' => ['head' => ['بارکد', 'نام', 'موجودی قبلی (عدد)', 'موجودی جدید (عدد)'], 'rows' => []],
            'unknown' => ['head' => ['بارکد', 'تعداد در فایل'], 'rows' => []],
            'missing' => ['head' => ['بارکد', 'نام', 'موجودی قبلی (عدد)'], 'rows' => []],
            'zero' => ['head' => ['بارکد', 'نام'], 'rows' => []],
        ];
        $counts = ['found' => 0, 'changed' => 0, 'unknown' => 0, 'missing' => 0, 'zero' => 0, 'available' => 0];
        $matched = [];
        $became = [];
        DB::transaction(function () use ($data, $site, $col, $wh, $unitCarton, $missing, &$lists, &$counts, &$matched, &$became) {
            foreach ($data as $k => $d) {
                if (! isset($site[$k])) {
                    $lists['unknown']['rows'][] = [$d['b'], $d['q']];
                    $counts['unknown']++;

                    continue;
                }
                $p = $site[$k];
                $matched[] = $p->id;
                $counts['found']++;
                $upd = [];
                if ($d['q'] !== null) {
                    $new = max(0, $unitCarton ? $d['q'] * max(1, $p->per_carton) : $d['q']);
                    if ((int) $p->{$col} !== $new || $p->{$col} === null) {
                        $lists['changed']['rows'][] = [$d['b'], $p->name, $p->{$col}, $new];
                        $counts['changed']++;
                        $upd[$col] = $new;
                    }
                    if ($new <= 0) {
                        $lists['zero']['rows'][] = [$d['b'], $p->name];
                        $counts['zero']++;
                    }
                }
                $avail = $d['q'] === null || ($d['q'] > 0);
                if ($wh === 'carton') {
                    if ($avail && ! $p->in_stock) {
                        $upd['in_stock'] = true;
                        $became[] = $p->id;
                    }
                } else {
                    if ($avail && ! $p->retail_in_stock) {
                        $upd['retail_in_stock'] = true;
                        $became[] = $p->id;
                    }
                }
                if ($avail) {
                    $counts['available']++;
                }
                if ($upd) {
                    $upd['updated_at'] = now();
                    Product::query()->whereKey($p->id)->update(Product::stampStock($upd));
                }
            }
            if ($missing !== 'keep') {
                $q = Product::query()->whereNotNull('barcode')->whereNotIn('id', $matched ?: [0]);
                if ($wh === 'retail') {
                    $q->where('retail_enabled', true);
                }
                foreach ($q->get(['id', 'barcode', 'name', 'stock', 'retail_stock']) as $p) {
                    $lists['missing']['rows'][] = [$p->barcode, $p->name, $p->{$col}];
                }
                $counts['missing'] = count($lists['missing']['rows']);
                $upd = $missing === 'zero' ? [$col => 0] : [];
                $upd[$wh === 'retail' ? 'retail_in_stock' : 'in_stock'] = false;
                $upd['updated_at'] = now();
                $q->update(Product::stampStock($upd));
            }
        });
        foreach (Product::query()->whereIn('id', array_unique($became))->get() as $p) {
            app(StockNotifier::class)->check($p);
        }
        Cache::forget('home.blocks');
        // کالاهای موجود این اکسل که در سایت نیستند از JSON ساخته می‌شوند
        $avail = [];
        $unavail = [];
        foreach ($data as $d) {
            if ($d['q'] === null || $d['q'] > 0) {
                $avail[] = $d['b'];
            } else {
                $unavail[] = $d['b'];
            }
        }
        $counts['json'] = static::toJson($avail, $unavail, $missing !== 'keep');
        $report = [
            'at' => now()->toIso8601String(),
            'warehouse' => $wh,
            'files' => implode('، ', array_column($files, 'name')),
            'stats' => $st + $counts + ['seconds' => round(microtime(true) - $t0, 1)],
            'lists' => $lists,
        ];
        Cache::put('excel.stock.'.$wh.'.'.$userId, $report, now()->addDays(14));

        return $report;
    }

    /** ارسال کدهای موجود اکسل به همگام‌سازی JSON (ساخت کالاهایی که در سایت نیستند) */
    protected static function toJson(array $available, array $unavailable, bool $replace): int
    {
        try {
            if (! \App\Models\SyncSource::query()->exists()) {
                return 0;
            }

            return \App\Services\Sync\SyncEngine::excelArrived($available, $unavailable, $replace);
        } catch (\Throwable $e) {
            report($e);

            return 0;
        }
    }

    /* ---------------- خروجی ---------------- */

    public function download(string $filename, array $head, iterable $rows)
    {
        $tmp = tempnam(sys_get_temp_dir(), 'xlsx');
        $w = new Writer;
        $w->openToFile($tmp);
        $w->getCurrentSheet()->setSheetView((new SheetView)->setRightToLeft(true));
        $w->addRow(Row::fromValues($head, (new Style)->setFontBold()));
        foreach ($rows as $r) {
            $w->addRow(Row::fromValues(array_map(fn ($v) => $v ?? '', array_values($r))));
        }
        $w->close();

        return response()->download($tmp, $filename, ['Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'])->deleteFileAfterSend();
    }

    public static function exportColumns(): array
    {
        // ترتیب ستون‌ها با پیش‌فرض ورود از اکسل یکی است: A بارکد، B نام، C قیمت
        return ['بارکد', 'نام کالا', 'قیمت (تومان)', 'قیمت قبل از تخفیف', 'دسته', 'تعداد در کارتن', 'موجودی عمده (عدد)', 'موجود؟', 'فروش تکی؟', 'قیمت تکی', 'موجودی خرده', 'حداکثر خرید تکی', 'انبار عمده', 'انبار خرده', 'فعال؟', 'لینک'];
    }

    public function exportProducts(?array $ids = null, ?array $categoryIds = null, bool $onlyActive = false)
    {
        $rows = (function () use ($ids, $categoryIds, $onlyActive) {
            $q = Product::query()->with(['category', 'warehouse', 'retailWarehouse'])->orderBy('id');
            if ($ids) {
                $q->whereIn('id', $ids);
            }
            if ($categoryIds) {
                $q->whereIn('category_id', static::expandCategories($categoryIds));
            }
            if ($onlyActive) {
                $q->where('is_active', true);
            }
            foreach ($q->lazy(500) as $p) {
                yield [
                    $p->barcode, $p->name, $p->price, $p->compare_price, $p->category?->name, $p->per_carton,
                    $p->stock, $p->in_stock ? 'بله' : 'خیر', $p->retail_enabled ? 'بله' : 'خیر', $p->retail_price,
                    $p->retail_stock, $p->retail_max, $p->warehouse?->code ?: $p->warehouse?->name,
                    $p->retailWarehouse?->code ?: $p->retailWarehouse?->name, $p->is_active ? 'بله' : 'خیر', $p->url(),
                ];
            }
        })();

        return $this->download('products-'.now()->format('Y-m-d').'.xlsx', static::exportColumns(), $rows);
    }
}
