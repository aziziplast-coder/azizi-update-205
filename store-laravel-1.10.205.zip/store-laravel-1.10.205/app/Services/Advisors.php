<?php

namespace App\Services;

use App\Models\Order;
use App\Models\User;
use App\Support\Finglish;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

/**
 * مشاوران فروش: لینک بازاریابی، تعلق مشتری، پورسانت پله‌ای، کیف پول، تسویه و شماره حساب
 *
 * - مشتری با لینک مشاور وارد سایت شود ← کوکی چندروزه؛ اگر وارد حساب شد یا خرید کرد، مال همان مشاور می‌شود.
 * - هر سفارش به یک مشاور نسبت داده می‌شود: صاحب مشتری، لینک، یا مشاوری که اخیراً با او گفتگو کرده.
 * - پورسانت «در انتظار» است تا سفارش به وضعیت‌های قطعی برسد؛ آن‌وقت به کیف پول اضافه می‌شود. لغو ← باطل.
 */
class Advisors
{
    public const COOKIE = 'adv';

    public const SRC = ['owner' => 'مشتری خودش', 'link' => 'لینک بازاریابی', 'chat' => 'گفتگو', 'manual' => 'تعیین دستی', 'crm' => 'فهرست تماس'];

    public static function defaults(): array
    {
        return [
            'enabled' => true,
            'link_days' => 30,        // اعتبار کوکی لینک
            'own' => 'forever',       // forever | months
            'own_months' => 12,
            'override' => false,      // لینک مشاور جدید، مشتری مشاور دیگر را عوض کند؟
            'chat_days' => 7,         // خرید تا چند روز پس از گفتگو به نام مشاور
            'priority' => 'owner',    // owner = صاحب مشتری اول | chat = آخرین مشاورِ گفتگو اول
            'mode' => 'bracket',      // bracket = کل مبلغ با درصد پله | progressive = هر بخش با درصد خودش (پلکانی)
            'tiers' => [
                ['from' => 0, 'rate' => 1, 'chat' => 0.5],
                ['from' => 50000000, 'rate' => 1.5, 'chat' => 0.75],
                ['from' => 200000000, 'rate' => 2, 'chat' => 1],
            ],
            'first_bonus' => 0.5,     // درصد اضافه برای اولین خرید مشتری
            'earn' => ['shipped', 'completed'],
            'payout_min' => 0,
            'notify' => true,
        ];
    }

    public static function cfg(): array
    {
        $d = static::defaults();
        $c = (array) setting('advisors', []);
        $out = array_replace($d, array_intersect_key($c, $d));
        $out['tiers'] = array_values(array_filter((array) $out['tiers'], 'is_array'));
        usort($out['tiers'], fn ($a, $b) => (int) ($a['from'] ?? 0) <=> (int) ($b['from'] ?? 0));
        $out['earn'] = array_values((array) $out['earn']);

        return $out;
    }

    public static function enabled(): bool
    {
        try {
            return (bool) static::cfg()['enabled'] && \Illuminate\Support\Facades\Schema::hasTable('advisors');
        } catch (Throwable) {
            return false;
        }
    }

    /* ---------------- مشاور ---------------- */

    public static function isAdvisor(?User $u): bool
    {
        if (! $u || ! $u->is_active) {
            return false;
        }
        if ($u->role === 'staff') {
            return in_array('advisor', (array) $u->permissions, true);
        }

        return $u->isAdmin() && DB::table('advisors')->where('user_id', $u->id)->where('active', true)->exists();
    }

    /** ردیف مشاور (در صورت نبود ساخته می‌شود با کد یکتا از نام) */
    public static function row(User $u): object
    {
        $r = DB::table('advisors')->where('user_id', $u->id)->first();
        if ($r) {
            return $r;
        }
        $base = strtolower(preg_replace('/[^a-z0-9]/i', '', Finglish::make((string) $u->name))) ?: 'a';
        $base = substr($base, 0, 14) ?: 'a';
        $code = $base;
        $i = 1;
        while (DB::table('advisors')->where('code', $code)->exists() || strlen($code) < 3) {
            $code = $base.(++$i);
        }
        DB::table('advisors')->insert(['user_id' => $u->id, 'code' => $code, 'active' => true, 'created_at' => now(), 'updated_at' => now()]);
        Cache::forget('adv.codes');

        return DB::table('advisors')->where('user_id', $u->id)->first();
    }

    /** کد ← شناسه مشاور (کش‌شده) */
    public static function byCode(string $code): ?int
    {
        $map = Cache::remember('adv.codes', 600, fn () => DB::table('advisors')->where('active', true)->pluck('user_id', 'code')->all());

        return isset($map[strtolower($code)]) ? (int) $map[strtolower($code)] : null;
    }

    public static function link(object $row, string $path = ''): string
    {
        $path = ltrim($path, '/');

        return url('/r/'.$row->code.($path !== '' ? '/'.$path : ''));
    }

    /* ---------------- لینک و تعلق مشتری ---------------- */

    /** کلیک روی لینک مشاور (یک بار در روز برای هر مرورگر) */
    public static function click(int $advisorId, bool $fresh): void
    {
        if (! $fresh) {
            return;
        }
        try {
            $day = now()->toDateString();
            $n = DB::table('advisor_stats')->where('advisor_id', $advisorId)->where('day', $day)->increment('clicks');
            if (! $n) {
                DB::table('advisor_stats')->insertOrIgnore(['advisor_id' => $advisorId, 'day' => $day, 'clicks' => 1, 'signups' => 0]);
            }
        } catch (Throwable) {
        }
    }

    /** آیا مالکیت فعلی مشتری هنوز معتبر است؟ */
    public static function ownerOf(User $u): ?int
    {
        if (! $u->advisor_id) {
            return null;
        }
        $c = static::cfg();
        if ($c['own'] === 'months' && $u->advisor_at && $u->advisor_at->lt(now()->subMonths(max(1, (int) $c['own_months'])))) {
            return null;
        }

        return (int) $u->advisor_id;
    }

    /** مشتری مال این مشاور شود (اگر صاحب معتبر دیگری ندارد، یا «جایگزینی» روشن است) */
    public static function own(User $u, int $advisorId, string $src, bool $force = false): bool
    {
        if ($u->isStaffLike() || $u->id === $advisorId) {
            return false;
        }
        $cur = static::ownerOf($u);
        if ($cur === $advisorId) {
            return false;
        }
        if ($cur && ! $force && ! ($src === 'link' && static::cfg()['override'])) {
            return false;
        }
        $u->forceFill(['advisor_id' => $advisorId, 'advisor_at' => now(), 'advisor_src' => $src])->saveQuietly();
        if ($src === 'link') {
            try {
                $day = now()->toDateString();
                if (! DB::table('advisor_stats')->where('advisor_id', $advisorId)->where('day', $day)->increment('signups')) {
                    DB::table('advisor_stats')->insertOrIgnore(['advisor_id' => $advisorId, 'day' => $day, 'clicks' => 0, 'signups' => 1]);
                }
            } catch (Throwable) {
            }
        }

        return true;
    }

    /** مشاور کوکی لینک (اگر هنوز معتبر است) */
    public static function cookieAdvisor(): ?int
    {
        $v = (string) request()->cookie(static::COOKIE);
        if (! preg_match('/^(\d+)\.(\d+)$/', $v, $m)) {
            return null;
        }
        if ((int) $m[2] < time() - 86400 * max(1, (int) static::cfg()['link_days'])) {
            return null;
        }

        return (int) $m[1];
    }

    /** آخرین مشاوری که در چند روز اخیر در گفتگوی زنده به این مشتری جواب داده */
    public static function chatAdvisor(?User $u, ?string $mobile = null): ?int
    {
        if (! \Illuminate\Support\Facades\Schema::hasTable('live_chats')) {
            return null;
        }
        $days = max(1, (int) static::cfg()['chat_days']);
        $q = DB::table('live_chats')->whereNotNull('staff_id')->where('staff_at', '>', now()->subDays($days));
        $q->where(function ($w) use ($u, $mobile) {
            if ($u) {
                $w->orWhere('user_id', $u->id);
            }
            if ($mobile) {
                $w->orWhere('mobile', $mobile);
            }
        });
        if (! $u && ! $mobile) {
            return null;
        }
        $sid = (int) $q->orderByDesc('staff_at')->value('staff_id');
        if (! $sid) {
            return null;
        }
        $staff = User::query()->find($sid);

        return static::isAdvisor($staff) ? $sid : null;
    }

    /* ---------------- سفارش و پورسانت ---------------- */

    /** سفارش تازه ← کدام مشاور؟ */
    public static function attribute(Order $o): void
    {
        if (! static::enabled() || $o->advisor_id) {
            return;
        }
        try {
            $u = $o->user_id ? User::query()->find($o->user_id) : null;
            $c = static::cfg();
            $owner = $u ? static::ownerOf($u) : null;
            $link = static::cookieAdvisor();
            $chat = static::chatAdvisor($u, $o->mobile ?: null);
            $pick = null;
            $src = null;
            if ($c['priority'] === 'chat' && $chat) {
                [$pick, $src] = [$chat, 'chat'];
            } elseif ($owner) {
                [$pick, $src] = [$owner, 'owner'];
            } elseif ($link) {
                [$pick, $src] = [$link, 'link'];
            } elseif ($chat) {
                [$pick, $src] = [$chat, 'chat'];
            }
            if (! $pick) {
                return;
            }
            $adv = User::query()->find($pick);
            if (! static::isAdvisor($adv)) {
                return;
            }
            $o->forceFill(['advisor_id' => $pick, 'advisor_src' => $src])->saveQuietly();
            // خرید با لینک یا گفتگو ← مشتری مال همان مشاور می‌شود (اگر صاحب ندارد)
            if ($u && in_array($src, ['link', 'chat'], true)) {
                static::own($u, $pick, $src);
            }
            static::sync($o);
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** درصد پورسانت برای این مبلغ */
    public static function rateFor(int $base, string $src, ?object $adv, bool $first): float
    {
        $c = static::cfg();
        if ($adv && $adv->rate !== null && $adv->rate !== '') {
            $r = (float) $adv->rate;
        } else {
            $col = $src === 'chat' ? 'chat' : 'rate';
            $r = 0.0;
            foreach ($c['tiers'] as $t) {
                if ($base >= (int) ($t['from'] ?? 0)) {
                    $r = (float) ($t[$col] ?? $t['rate'] ?? 0);
                }
            }
        }

        return $r + ($first ? (float) $c['first_bonus'] : 0);
    }

    /** مبلغ پورسانت (پله‌ای یا پلکانی) */
    public static function amountFor(int $base, string $src, ?object $adv, bool $first): array
    {
        $c = static::cfg();
        $custom = $adv && $adv->rate !== null && $adv->rate !== '';
        if ($c['mode'] === 'progressive' && ! $custom && count($c['tiers']) > 1) {
            $col = $src === 'chat' ? 'chat' : 'rate';
            $amt = 0.0;
            $tiers = $c['tiers'];
            foreach ($tiers as $i => $t) {
                $from = (int) ($t['from'] ?? 0);
                $to = isset($tiers[$i + 1]) ? (int) $tiers[$i + 1]['from'] : PHP_INT_MAX;
                if ($base <= $from) {
                    break;
                }
                $amt += (min($base, $to) - $from) * (float) ($t[$col] ?? $t['rate'] ?? 0) / 100;
            }
            $amt += $first ? $base * (float) $c['first_bonus'] / 100 : 0;
            $rate = $base ? round($amt / $base * 100, 2) : 0;

            return [(int) round($amt), $rate];
        }
        $rate = static::rateFor($base, $src, $adv, $first);

        return [(int) round($base * $rate / 100), $rate];
    }

    /** پورسانت سفارش را با وضعیت و مبلغ فعلی هماهنگ کن (در انتظار / قطعی / باطل) */
    public static function sync(Order $o): void
    {
        if (! $o->advisor_id || ! static::enabled()) {
            return;
        }
        try {
            DB::transaction(function () use ($o) {
                $c = static::cfg();
                $adv = DB::table('advisors')->where('user_id', $o->advisor_id)->first();
                $base = max(0, (int) $o->items_total - (int) $o->coupon_discount - (int) ($o->extra_discount ?? 0));
                $first = $o->user_id && ! Order::query()->where('user_id', $o->user_id)->where('id', '<', $o->id)->whereNotIn('status', ['cancelled', 'failed', 'pending_payment'])->exists();
                [$amount, $rate] = static::amountFor($base, (string) $o->advisor_src, $adv, $first);
                $status = in_array($o->status, ['cancelled', 'failed'], true) ? 'void' : (in_array($o->status, $c['earn'], true) ? 'earned' : 'pending');
                if ($o->status === 'pending_payment') {
                    $status = 'pending';
                }
                $row = DB::table('commissions')->where('order_id', $o->id)->lockForUpdate()->first();
                $data = ['advisor_id' => $o->advisor_id, 'base' => $base, 'rate' => $rate, 'amount' => $status === 'void' ? 0 : $amount, 'status' => $status, 'src' => $o->advisor_src, 'first' => $first, 'updated_at' => now()];
                if ($status === 'earned' && (! $row || $row->status !== 'earned')) {
                    $data['earned_at'] = now();
                }
                if ($row) {
                    // مشاور سفارش عوض شده: پورسانت قبلی از کیف پول مشاور قبلی برمی‌گردد
                    if ((int) $row->advisor_id !== (int) $o->advisor_id) {
                        static::settleTx($row->id, (int) $row->advisor_id, 0);
                    }
                    DB::table('commissions')->where('id', $row->id)->update($data);
                    $id = $row->id;
                } else {
                    $id = DB::table('commissions')->insertGetId($data + ['order_id' => $o->id, 'created_at' => now()]);
                }
                // کیف پول: مجموع تراکنش‌های این پورسانت = مبلغ قطعی
                static::settleTx($id, (int) $o->advisor_id, $status === 'earned' ? $amount : 0, $o);
            });
        } catch (Throwable $e) {
            report($e);
        }
    }

    protected static function settleTx(int $commissionId, int $userId, int $want, ?Order $o = null): void
    {
        $have = (int) DB::table('wallet_tx')->where('commission_id', $commissionId)->where('user_id', $userId)->sum('amount');
        $diff = $want - $have;
        if ($diff === 0) {
            return;
        }
        DB::table('wallet_tx')->insert([
            'user_id' => $userId, 'type' => 'commission', 'amount' => $diff, 'commission_id' => $commissionId,
            'note' => $o ? ($have === 0 ? 'پورسانت سفارش '.fa($o->number) : 'اصلاح پورسانت سفارش '.fa($o->number).($want === 0 ? ' (لغو یا تغییر مشاور)' : ' (تغییر مبلغ)')) : 'برگشت پورسانت (تغییر مشاور)',
            'created_at' => now(),
        ]);
        if ($diff > 0 && $o && static::cfg()['notify']) {
            static::notify($userId, '💰 پورسانت سفارش '.fa($o->number), money($diff).' تومان به کیف پول شما اضافه شد.');
        }
    }

    /** تعیین دستی مشاور سفارش (مدیر) */
    public static function setOrderAdvisor(Order $o, ?int $advisorId): void
    {
        $o->forceFill(['advisor_id' => $advisorId, 'advisor_src' => $advisorId ? 'manual' : null])->saveQuietly();
        if ($advisorId) {
            static::sync($o);
        } else {
            $row = DB::table('commissions')->where('order_id', $o->id)->first();
            if ($row) {
                static::settleTx($row->id, (int) $row->advisor_id, 0);
                DB::table('commissions')->where('id', $row->id)->update(['status' => 'void', 'amount' => 0, 'updated_at' => now()]);
            }
        }
    }

    /* ---------------- کیف پول ---------------- */

    public static function balance(int $uid): int
    {
        return (int) DB::table('wallet_tx')->where('user_id', $uid)->sum('amount');
    }

    public static function pending(int $uid): int
    {
        return (int) DB::table('commissions')->where('advisor_id', $uid)->where('status', 'pending')->sum('amount');
    }

    /** پرداخت (تسویه) به مشاور */
    public static function payout(User $adv, int $amount, string $ref, ?string $receipt, User $by, ?string $note = null): void
    {
        DB::table('wallet_tx')->insert([
            'user_id' => $adv->id, 'type' => 'payout', 'amount' => -abs($amount), 'ref' => mb_substr($ref, 0, 60), 'receipt' => $receipt,
            'note' => $note ? mb_substr($note, 0, 300) : 'واریز به حساب', 'by_id' => $by->id, 'created_at' => now(),
        ]);
        if (static::cfg()['notify']) {
            $msg = money(abs($amount)).' تومان به حساب شما واریز شد'.($ref !== '' ? ' — پیگیری: '.$ref : '').'. '.store_name();
            static::notify($adv->id, '🏦 واریز پورسانت', $msg);
            try {
                if ($adv->mobile) {
                    app(Sms::class)->sendText($adv->mobile, $msg, 'advisor_payout');
                }
            } catch (Throwable) {
            }
        }
    }

    /** پاداش رسیدن به هدف ماهانه (یک بار در هر ماه) */
    public static function monthBonus(User $adv): void
    {
        $row = DB::table('advisors')->where('user_id', $adv->id)->first();
        if (! $row || ! $row->target || ! $row->bonus) {
            return;
        }
        $period = static::monthRange()[2];
        if (DB::table('wallet_tx')->where('user_id', $adv->id)->where('type', 'bonus')->where('period', $period)->exists()) {
            return;
        }
        if (static::monthSales($adv->id) >= (int) $row->target) {
            DB::table('wallet_tx')->insert(['user_id' => $adv->id, 'type' => 'bonus', 'amount' => (int) $row->bonus, 'note' => 'پاداش رسیدن به هدف ماه '.fa($period), 'period' => $period, 'created_at' => now()]);
            static::notify($adv->id, '🏆 به هدف ماه رسیدید!', money((int) $row->bonus).' تومان پاداش به کیف پولتان اضافه شد.');
        }
    }

    /** فروش ماه جاری شمسی (مبنای پورسانت، بدون لغوشده‌ها) */
    public static function monthSales(int $uid): int
    {
        [$from, $to] = static::monthRange();

        return (int) DB::table('commissions')->where('advisor_id', $uid)->where('status', '!=', 'void')->whereBetween('created_at', [$from, $to])->sum('base');
    }

    /** ابتدا و انتهای ماه شمسی جاری */
    public static function monthRange(?\Carbon\Carbon $at = null, int $shift = 0): array
    {
        $t = ($at ?? now())->copy()->timezone('Asia/Tehran');
        [$jy, $jm] = \App\Support\Jalali::fromGregorian((int) $t->format('Y'), (int) $t->format('n'), (int) $t->format('j'));
        $jm += $shift;
        while ($jm < 1) {
            $jm += 12;
            $jy--;
        }
        while ($jm > 12) {
            $jm -= 12;
            $jy++;
        }
        [$ny, $nm] = $jm === 12 ? [$jy + 1, 1] : [$jy, $jm + 1];
        $g1 = \App\Support\Jalali::toGregorian($jy, $jm, 1);
        $g2 = \App\Support\Jalali::toGregorian($ny, $nm, 1);
        $tz = config('app.timezone');
        $from = \Carbon\Carbon::create($g1[0], $g1[1], $g1[2], 0, 0, 0, 'Asia/Tehran')->timezone($tz);
        $to = \Carbon\Carbon::create($g2[0], $g2[1], $g2[2], 0, 0, 0, 'Asia/Tehran')->subSecond()->timezone($tz);

        return [$from, $to, sprintf('%04d-%02d', $jy, $jm)];
    }

    public static function notify(int $uid, string $title, string $body): void
    {
        try {
            app(WebPush::class)->toUsers([$uid], ['title' => $title, 'body' => $body, 'url' => url('/advisor#wallet'), 'tag' => 'adv-'.Str::random(6)]);
        } catch (Throwable) {
        }
    }

    /* ---------------- شماره حساب ---------------- */

    public const BANKS = [
        '010' => 'بانک مرکزی', '011' => 'صنعت و معدن', '012' => 'ملت', '013' => 'رفاه کارگران', '014' => 'مسکن', '015' => 'سپه', '016' => 'کشاورزی',
        '017' => 'ملی ایران', '018' => 'تجارت', '019' => 'صادرات ایران', '020' => 'توسعه صادرات', '021' => 'پست بانک', '022' => 'توسعه تعاون',
        '051' => 'موسسه توسعه', '052' => 'قوامین', '053' => 'کارآفرین', '054' => 'پارسیان', '055' => 'اقتصاد نوین', '056' => 'سامان', '057' => 'پاسارگاد',
        '058' => 'سرمایه', '059' => 'سینا', '060' => 'مهر ایران', '061' => 'شهر', '062' => 'آینده', '063' => 'انصار', '064' => 'گردشگری',
        '065' => 'حکمت ایرانیان', '066' => 'دی', '069' => 'ایران زمین', '070' => 'رسالت', '073' => 'کوثر', '075' => 'ملل', '078' => 'خاورمیانه',
        '079' => 'مهر اقتصاد', '080' => 'نور', '095' => 'ایران و ونزوئلا',
    ];

    public const BINS = [
        '603799' => 'ملی ایران', '589210' => 'سپه', '627648' => 'توسعه صادرات', '207177' => 'توسعه صادرات', '627961' => 'صنعت و معدن', '603770' => 'کشاورزی',
        '639217' => 'کشاورزی', '628023' => 'مسکن', '627760' => 'پست بانک', '502908' => 'توسعه تعاون', '627412' => 'اقتصاد نوین', '622106' => 'پارسیان',
        '639194' => 'پارسیان', '627884' => 'پارسیان', '502229' => 'پاسارگاد', '639347' => 'پاسارگاد', '627488' => 'کارآفرین', '502910' => 'کارآفرین',
        '621986' => 'سامان', '639346' => 'سینا', '639607' => 'سرمایه', '636214' => 'آینده', '502806' => 'شهر', '504706' => 'شهر', '502938' => 'دی',
        '603769' => 'صادرات ایران', '610433' => 'ملت', '991975' => 'ملت', '627353' => 'تجارت', '585983' => 'تجارت', '589463' => 'رفاه کارگران',
        '627381' => 'انصار', '639370' => 'مهر اقتصاد', '505785' => 'ایران زمین', '504172' => 'رسالت', '606373' => 'مهر ایران', '505416' => 'گردشگری',
        '636949' => 'حکمت ایرانیان', '505801' => 'کوثر', '606256' => 'ملل', '628157' => 'موسسه توسعه', '507677' => 'نور', '639599' => 'قوامین',
    ];

    public static function cleanSheba(string $s): string
    {
        $s = strtoupper(preg_replace('/[\s\-]/', '', en_digits($s)));
        if (preg_match('/^\d{24}$/', $s)) {
            $s = 'IR'.$s;
        }

        return $s;
    }

    public static function validSheba(string $s): bool
    {
        if (! preg_match('/^IR\d{24}$/', $s)) {
            return false;
        }
        $r = substr($s, 4).'1827'.substr($s, 2, 2); // I=18, R=27
        $mod = 0;
        foreach (str_split($r) as $ch) {
            $mod = ($mod * 10 + (int) $ch) % 97;
        }

        return $mod === 1;
    }

    public static function validCard(string $c): bool
    {
        if (! preg_match('/^\d{16}$/', $c)) {
            return false;
        }
        $sum = 0;
        foreach (str_split($c) as $i => $d) {
            $d = (int) $d;
            if ($i % 2 === 0) {
                $d *= 2;
                $d = $d > 9 ? $d - 9 : $d;
            }
            $sum += $d;
        }

        return $sum % 10 === 0;
    }

    public static function bankOf(?string $sheba, ?string $card): ?string
    {
        if ($sheba && preg_match('/^IR\d{2}0(\d{2})/', $sheba, $m) && isset(static::BANKS['0'.$m[1]])) {
            return static::BANKS['0'.$m[1]];
        }
        if ($card && isset(static::BINS[substr($card, 0, 6)])) {
            return static::BINS[substr($card, 0, 6)];
        }

        return null;
    }

    /** ثبت/تغییر حساب: اولین بار مستقیم؛ تغییر بعدی تا تأیید مدیر «در انتظار» می‌ماند */
    public static function saveBank(User $u, string $holder, string $sheba, string $card, bool $byAdmin = false): string
    {
        $sheba = static::cleanSheba($sheba);
        $card = preg_replace('/\D/', '', en_digits($card));
        if ($sheba === '' && $card === '') {
            throw new \RuntimeException('شماره شبا یا کارت را وارد کنید.');
        }
        if ($sheba !== '' && ! static::validSheba($sheba)) {
            throw new \RuntimeException('شماره شبا درست نیست (IR و ۲۴ رقم؛ یک رقم را دوباره بررسی کنید).');
        }
        if ($card !== '' && ! static::validCard($card)) {
            throw new \RuntimeException('شماره کارت درست نیست (۱۶ رقم؛ یک رقم را دوباره بررسی کنید).');
        }
        $holder = mb_substr(trim($holder), 0, 80);
        if ($holder === '') {
            throw new \RuntimeException('نام صاحب حساب را بنویسید.');
        }
        $row = static::row($u);
        $data = ['bank_holder' => $holder, 'bank_sheba' => $sheba ?: null, 'bank_card' => $card ?: null, 'bank_name' => static::bankOf($sheba, $card)];
        if ($byAdmin || (! $row->bank_sheba && ! $row->bank_card)) {
            DB::table('advisors')->where('id', $row->id)->update($data + ['bank_new' => null, 'bank_ok_at' => now(), 'updated_at' => now()]);

            return 'saved';
        }
        DB::table('advisors')->where('id', $row->id)->update(['bank_new' => json_encode($data + ['at' => now()->toIso8601String()], JSON_UNESCAPED_UNICODE), 'updated_at' => now()]);
        // خبر به مدیرها
        try {
            $admins = User::query()->where('is_active', true)->where(fn ($q) => $q->where('role', 'admin')->orWhere(fn ($w) => $w->where('role', 'staff')->where('permissions', 'like', '%"advisors"%')))->pluck('id')->all();
            app(WebPush::class)->toUsers($admins, ['title' => '🏦 تغییر شماره حساب مشاور', 'body' => $u->name.' شماره حسابش را عوض کرد؛ تا تأیید شما پرداخت به حساب قبلی است.', 'url' => url('/admin/advisors'), 'tag' => 'adv-bank-'.$u->id]);
        } catch (Throwable) {
        }

        return 'pending';
    }

    public static function approveBank(int $advisorRowId, bool $ok): void
    {
        $row = DB::table('advisors')->find($advisorRowId);
        if (! $row || ! $row->bank_new) {
            return;
        }
        $new = (array) json_decode($row->bank_new, true);
        $upd = ['bank_new' => null, 'updated_at' => now()];
        if ($ok) {
            $upd += array_intersect_key($new, array_flip(['bank_holder', 'bank_sheba', 'bank_card', 'bank_name'])) + ['bank_ok_at' => now()];
        }
        DB::table('advisors')->where('id', $row->id)->update($upd);
        static::notify((int) $row->user_id, $ok ? '✅ شماره حساب جدید تأیید شد' : '❌ تغییر شماره حساب رد شد', $ok ? 'از این به بعد پورسانت به حساب جدید واریز می‌شود.' : 'برای اطلاع بیشتر با مدیر تماس بگیرید.');
    }
}
