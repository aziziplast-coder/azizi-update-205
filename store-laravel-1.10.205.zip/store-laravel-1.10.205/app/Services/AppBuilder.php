<?php

namespace App\Services;

use App\Support\Settings;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * ساخت خودکار اپ اندروید از پنل: درخواست ساخت به GitHub Actions،
 * پیگیری وضعیت، دریافت APK امضاشده و انتشار آن روی همین سایت.
 */
class AppBuilder
{
    public const STATE_KEY = 'mobile_app_build';

    /** تنظیمات ساخت (از پنل) با پیش‌فرض‌های این سایت */
    public static function cfg(): array
    {
        $b = (array) (setting('mobile_app')['build'] ?? []);
        $host = parse_url(url('/'), PHP_URL_HOST) ?: 'store';

        return [
            'repo' => trim((string) ($b['repo'] ?? '')),
            'token' => static::token(),
            'app_name' => trim((string) ($b['app_name'] ?? '')) ?: store_name(),
            'package' => trim((string) ($b['package'] ?? '')) ?: static::packageFromHost($host),
            'brand' => trim((string) ($b['brand'] ?? '')) ?: (string) setting('brand_color', '#4f4a63'),
            'icon' => ! empty($b['icon']) ? url(upload_url($b['icon'])) : route('pwa.icon', 512),
            'scheme' => trim((string) (setting('mobile_app')['scheme'] ?? '')) ?: 'storeapp',
            'base_url' => rtrim(url('/'), '/').'/',
            'mode' => ($b['mode'] ?? 'native') === 'web' ? 'web' : 'native',
        ];
    }

    public static function packageFromHost(string $host): string
    {
        $parts = array_reverse(array_filter(explode('.', preg_replace('/^www\./', '', strtolower($host)))));
        $parts = array_map(fn ($p) => preg_replace('/^(\d)/', 'a$1', preg_replace('/[^a-z0-9_]/', '_', $p)), $parts);
        if (count($parts) < 2) {
            $parts[] = 'store';
        }

        return implode('.', $parts).'.app';
    }

    public static function token(): string
    {
        $t = (string) (setting('mobile_app')['build']['token_enc'] ?? '');
        try {
            return $t !== '' ? Crypt::decryptString($t) : '';
        } catch (\Throwable) {
            return '';
        }
    }

    public static function ready(): bool
    {
        $c = static::cfg();

        return $c['repo'] !== '' && $c['token'] !== '';
    }

    public static function state(): array
    {
        return (array) setting(static::STATE_KEY, []);
    }

    protected static function save(array $s): array
    {
        Settings::set([static::STATE_KEY => $s]);

        return $s;
    }

    public static function running(): bool
    {
        return in_array(static::state()['status'] ?? '', ['queued', 'in_progress', 'downloading'], true);
    }

    protected static function gh(string $token)
    {
        return Http::withToken($token)->acceptJson()->withHeaders(['X-GitHub-Api-Version' => '2022-11-28', 'User-Agent' => 'store-panel'])
            ->timeout(30)->baseUrl('https://api.github.com');
    }

    public static function validPackage(string $p): bool
    {
        return (bool) preg_match('/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/', $p);
    }

    /** شروع ساخت نسخه تازه */
    public static function start(): array
    {
        $c = static::cfg();
        if (! static::ready()) {
            throw new \RuntimeException('نشانی مخزن و کلید دسترسی GitHub را در تنظیمات ساخت وارد کنید.');
        }
        if (! static::validPackage($c['package'])) {
            throw new \RuntimeException('نام بسته معتبر نیست؛ فقط حروف کوچک انگلیسی، عدد و نقطه (مثلاً com.shop.app).');
        }
        $app = (array) setting('mobile_app', []);
        $last = static::state();
        $code = max((int) ($app['version_code'] ?? 0), (int) ($last['version_code'] ?? 0)) + 1;
        $name = '1.'.intdiv($code, 100).'.'.($code % 100);
        $req = 'panel-'.Str::lower(Str::random(10));

        $r = static::gh($c['token'])->post("/repos/{$c['repo']}/actions/workflows/build.yml/dispatches", [
            'ref' => 'main',
            'inputs' => [
                'appName' => $c['app_name'], 'applicationId' => $c['package'], 'baseUrl' => $c['base_url'], 'scheme' => $c['scheme'],
                'versionCode' => (string) $code, 'versionName' => $name, 'brandColor' => strtoupper($c['brand']), 'iconUrl' => $c['icon'],
                'requestId' => $req,
            ] + ($c['mode'] === 'web' ? ['appMode' => 'web'] : []),
        ]);
        if (! $r->successful()) {
            throw new \RuntimeException(static::ghError($r));
        }

        return static::save([
            'status' => 'queued', 'request' => $req, 'version_code' => $code, 'version_name' => $name, 'package' => $c['package'],
            'app_name' => $c['app_name'], 'started_at' => now()->toIso8601String(), 'run_id' => null, 'run_url' => null, 'error' => null,
            'file' => $last['file'] ?? null, 'prev' => ($last['status'] ?? '') === 'success' ? $last : ($last['prev'] ?? null),
        ]);
    }

    protected static function ghError($r): string
    {
        return match ($r->status()) {
            401 => 'کلید دسترسی GitHub نامعتبر یا منقضی است.',
            403 => 'کلید GitHub اجازه اجرای Actions ندارد (دسترسی Actions: Read and write لازم است).',
            404 => 'مخزن یا فایل build.yml پیدا نشد؛ نشانی مخزن و دسترسی کلید را بررسی کنید.',
            422 => 'GitHub درخواست را نپذیرفت: '.($r->json('message') ?? ''),
            default => 'خطای GitHub ('.$r->status().'): '.mb_substr((string) ($r->json('message') ?? $r->body()), 0, 200),
        };
    }

    /** پیگیری وضعیت؛ در پایان موفق، APK دریافت و منتشر می‌شود */
    public static function poll(): array
    {
        $s = static::state();
        if (! static::running()) {
            return $s;
        }
        $c = static::cfg();
        $gh = static::gh($c['token']);
        try {
            if (! $s['run_id']) {
                $runs = $gh->get("/repos/{$c['repo']}/actions/workflows/build.yml/runs", ['event' => 'workflow_dispatch', 'per_page' => 20])->json('workflow_runs') ?? [];
                foreach ($runs as $run) {
                    if (($run['display_title'] ?? '') === $s['request'] || ($run['name'] ?? '') === $s['request']) {
                        $s['run_id'] = $run['id'];
                        $s['run_url'] = $run['html_url'];
                        break;
                    }
                }
                if (! $s['run_id']) {
                    if (now()->diffInMinutes(\Carbon\Carbon::parse($s['started_at'])) > 10) {
                        $s['status'] = 'failed';
                        $s['error'] = 'اجرای ساخت در GitHub پیدا نشد.';
                    }

                    return static::save($s);
                }
            }
            $run = $gh->get("/repos/{$c['repo']}/actions/runs/{$s['run_id']}")->json();
            if (($run['status'] ?? '') !== 'completed') {
                $s['status'] = ($run['status'] ?? '') === 'in_progress' ? 'in_progress' : 'queued';

                return static::save($s);
            }
            $branch = 'apk/'.$s['package'];
            $status = (string) $gh->withHeaders(['Accept' => 'application/vnd.github.raw'])->get("/repos/{$c['repo']}/contents/status.txt", ['ref' => $branch])->body();
            if (! str_contains($status, 'run='.$s['run_id']) || ! str_contains($status, 'code=0')) {
                $err = (string) $gh->withHeaders(['Accept' => 'application/vnd.github.raw'])->get("/repos/{$c['repo']}/contents/errors.txt", ['ref' => $branch])->body();
                $s['status'] = 'failed';
                $s['error'] = 'ساخت ناموفق بود. '.mb_substr(trim($err), 0, 600);

                return static::save($s);
            }
            $s['status'] = 'downloading';
            static::save($s);
            $apk = $gh->withHeaders(['Accept' => 'application/vnd.github.raw'])->timeout(180)->get("/repos/{$c['repo']}/contents/app-release.apk", ['ref' => $branch]);
            $body = $apk->body();
            if (! $apk->successful() || substr($body, 0, 2) !== 'PK') {
                $s['status'] = 'failed';
                $s['error'] = 'دریافت فایل APK از GitHub انجام نشد ('.$apk->status().').';

                return static::save($s);
            }
            $file = 'app/'.$s['package'].'-'.$s['version_name'].'.apk';
            Storage::disk('public')->put($file, $body);
            foreach (Storage::disk('public')->files('app') as $old) { // فقط سه نسخه آخر نگه داشته شود
                if (str_ends_with($old, '.apk') && $old !== $file && ! in_array($old, [$s['prev']['file'] ?? null], true)) {
                    Storage::disk('public')->delete($old);
                }
            }
            $s['status'] = 'success';
            $s['file'] = $file;
            $s['size'] = strlen($body);
            $s['finished_at'] = now()->toIso8601String();
            static::save($s);
            // اعلام نسخه تازه به اپ‌های نصب‌شده
            $app = (array) setting('mobile_app', []);
            $app['version_code'] = $s['version_code'];
            $app['version_name'] = $s['version_name'];
            $app['download_url'] = route('app.download');
            Settings::set(['mobile_app' => $app]);

            return $s;
        } catch (\Throwable $e) {
            report($e);
            $s['poll_error'] = mb_substr($e->getMessage(), 0, 200);

            return static::save($s);
        }
    }

    public static function latestFile(): ?string
    {
        $f = static::state()['file'] ?? null;

        return $f && Storage::disk('public')->exists($f) ? $f : null;
    }
}
