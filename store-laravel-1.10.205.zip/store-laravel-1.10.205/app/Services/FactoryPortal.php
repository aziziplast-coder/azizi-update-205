<?php

namespace App\Services;

use App\Models\Factory;
use App\Models\FactoryAccount;
use App\Models\OtpCode;
use App\Models\RemitDestination;
use App\Models\RemitPayment;
use App\Models\Remittance;
use App\Models\User;
use App\Support\Banks;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\URL;
use Illuminate\Validation\ValidationException;
use Throwable;

/**
 * اپ کارخانه‌داران:
 *  ۱) حسابداری حواله را برای کارخانه‌دار صادر می‌کند (به‌جای چک بانکی).
 *  ۲) کارخانه‌دار تصمیم می‌گیرد: «به حساب خودم» یا «انتقال به شخص دیگر» (یا تقسیم بین چند حساب).
 *  ۳) حسابداری حساب(های) مقصد را تأیید می‌کند ← حواله جاری می‌شود و مبالغ مشتریان به همان حساب‌ها صادر می‌شود.
 *  ۴) فیش مشتری مستقیم برای کارخانه‌دار نمایش داده می‌شود و او فقط «به حسابم نشست» را تأیید می‌کند.
 *     (واریزهای پایا ممکن است ساعت‌ها بعد بنشیند؛ فیش‌های تأییدنشده پس از مهلت برای حسابداری پررنگ می‌شوند.)
 */
class FactoryPortal
{
    /* ---------------- تنظیمات ---------------- */

    public static function cfg(): array
    {
        $c = (array) setting('factory_portal', []);

        return [
            'enabled' => ! array_key_exists('enabled', $c) || ! empty($c['enabled']),
            'late_hours' => max(1, (int) ($c['late_hours'] ?? 24)),          // پس از این مدت فیش تأییدنشده «دیرکرد» است
            'confirm_counts' => ! array_key_exists('confirm_counts', $c) || ! empty($c['confirm_counts']), // تأیید کارخانه‌دار = تأیید فیش
            'remind' => ! array_key_exists('remind', $c) || ! empty($c['remind']), // یادآوری پیامکی روزانه فیش‌های منتظر
            'default_decides' => ! array_key_exists('default_decides', $c) || ! empty($c['default_decides']), // پیش‌فرض: حساب را کارخانه‌دار تعیین می‌کند
            'allow_split' => ! array_key_exists('allow_split', $c) || ! empty($c['allow_split']),
            'max_split' => max(2, min(10, (int) ($c['max_split'] ?? 2))), // حداکثر چند حساب/شماره حواله برای یک حواله
            'name' => trim((string) ($c['name'] ?? '')) ?: 'اپ کارخانه‌داران',
            'chat' => ! array_key_exists('chat', $c) || ! empty($c['chat']), // گفتگو با حسابداری
            'install_required' => ! array_key_exists('install_required', $c) || ! empty($c['install_required']), // روی گوشی فقط از اپ نصب‌شده
            'terms' => trim((string) ($c['terms'] ?? '')) ?: static::TERMS, // شرایط حسابداری که کارخانه‌دار باید «متوجه شدم» بزند
        ];
    }

    public const TERMS = "شرایط واریز از طرف حسابداری پخش:\n"
        ."۱) حسابی که برای واریز معرفی می‌کنید باید پول را بپذیرد. اگر واریزی به حساب شما برگشت بخورد (مثلاً حساب اتباع یا حساب مسدود که هر واریز را برمی‌گرداند)، آن واریز «نرسیده» حساب می‌شود و در حواله شما حساب نمی‌شود.\n"
        ."۲) در این صورت حسابداری از شما حساب جدید می‌گیرد؛ مشتری همان مبلغ را دوباره به حساب جدید می‌ریزد و همان مبلغ در همین حواله حساب می‌شود.\n"
        ."۳) هر واریزی که به حسابتان نشست را همین‌جا «به حسابم نشست» بزنید و اگر چیزی نرسید یا برگشت خورد، همان روز در گفتگو به حسابداری خبر دهید.\n"
        ."۴) تا وقتی واریز برگشتی دوباره انجام نشده، پخش مسئولیتی برای کسری آن مبلغ ندارد.";

    /** نسخه متن شرایط (با تغییر متن، دوباره «متوجه شدم» لازم می‌شود) */
    public static function termsVersion(): string
    {
        return substr(md5(static::cfg()['terms']), 0, 12);
    }

    public static function needsTerms(?Factory $f): bool
    {
        return $f && \App\Support\DbSchema::hasColumn('factories', 'terms_ack_v') && $f->terms_ack_v !== static::termsVersion();
    }

    public static function url(string $path = ''): string
    {
        return url('/factory'.($path ? '/'.ltrim($path, '/') : ''));
    }

    /* ---------------- ورود ---------------- */

    public static function findByMobile(string $mobile): ?Factory
    {
        $m = mobile($mobile);

        return $m ? Factory::query()->where('mobile', $m)->where('active', true)->first() : null;
    }

    /** ارسال کد ورود (فقط برای کارخانه‌دارهای ثبت‌شده) */
    public static function sendCode(string $mobile, string $ip): array
    {
        $m = mobile($mobile);
        if (! $m) {
            return ['ok' => false, 'msg' => 'شماره موبایل درست نیست.'];
        }
        $key = 'fac-otp:'.$m;
        if (RateLimiter::tooManyAttempts($key, 1)) {
            return ['ok' => false, 'msg' => 'لطفاً '.fa(RateLimiter::availableIn($key)).' ثانیه دیگر دوباره تلاش کنید.', 'code_step' => true];
        }
        if (RateLimiter::tooManyAttempts('fac-otp-ip:'.$ip, 30)) {
            return ['ok' => false, 'msg' => 'تعداد درخواست‌ها زیاد است؛ کمی بعد تلاش کنید.'];
        }
        RateLimiter::hit('fac-otp-ip:'.$ip, 3600);
        $f = static::findByMobile($m);
        if (! $f) {
            // پاسخ یکسان نیست تا کارخانه‌دار بداند باید با حسابداری تماس بگیرد
            return ['ok' => false, 'msg' => 'این شماره در فهرست کارخانه‌داران ثبت نشده است؛ با حسابداری شرکت تماس بگیرید.'];
        }
        $code = (string) random_int(10000, 99999);
        OtpCode::query()->where('mobile', $m)->delete();
        OtpCode::create(['mobile' => $m, 'code' => Hash::make($code), 'expires_at' => now()->addMinutes(5)]);
        $res = app(Sms::class)->send('otp', $m, ['code' => $code], true);
        RateLimiter::hit($key, 60);

        return $res['ok'] || ! empty($res['maybe'])
            ? ['ok' => true, 'msg' => 'کد ورود به '.fa($m).' پیامک شد.', 'code_step' => true]
            : ['ok' => false, 'msg' => 'ارسال پیامک انجام نشد؛ اگر کد رسید وارد کنید، وگرنه از حسابداری «لینک ورود» بخواهید.', 'code_step' => true];
    }

    public static function verifyCode(string $mobile, string $code): ?Factory
    {
        $m = mobile($mobile);
        $f = $m ? static::findByMobile($m) : null;
        if (! $f || ! app(Otp::class)->verify($m, $code)) {
            return null;
        }

        return $f;
    }

    /** لینک ورود یک‌باره (حسابداری می‌فرستد؛ ۷ روز اعتبار) */
    public static function loginLink(Factory $f, int $days = 7): string
    {
        // امضای نسبی: با www/بدون www و دامنه تازه هم کار می‌کند
        return url(URL::temporarySignedRoute('factory.magic', now()->addDays($days), ['factory' => $f->id, 'h' => substr(sha1($f->mobile.$f->created_at), 0, 10)], false));
    }

    /* ---------------- حواله‌ها ---------------- */

    /** حواله‌های قابل نمایش برای کارخانه‌دار (حواله‌های تقسیم‌شده زیر حواله اصلی هم می‌آیند) */
    public static function remittances(Factory $f): Collection
    {
        return Remittance::query()->where('factory_id', $f->id)->with('destinations')->orderByRaw("case when status = 'pending' then 0 when status = 'active' then 1 else 2 end")->latest('id')->get();
    }

    public static function needsDecision(Remittance $r): bool
    {
        return $r->status === 'pending' && in_array($r->dest_status, ['awaiting', 'rejected'], true);
    }

    /**
     * کارخانه‌دار مقصد مبلغ حواله را تعیین می‌کند. $rows: [{kind, amount, holder_name, mobile, sheba, card_number, account_number, note, save}]
     *  own   = به حساب خودم ← نام صاحب حساب + شبا (و اختیاری کارت/حساب) ← تأیید حسابداری
     *  other = انتقال به شخص دیگر ← فقط نام و موبایل؛ همان لحظه حواله جدا به نام او ساخته و برایش پیامک می‌شود؛
     *          حساب را خود گیرنده در اپ ثبت می‌کند و فیش‌ها را خودش تأیید می‌کند.
     * شخص ثالث فقط «به حساب خودم» دارد (انتقال دوباره و تقسیم ندارد).
     */
    public static function submitDestinations(Factory $f, Remittance $r, array $rows): void
    {
        abort_unless((int) $r->factory_id === (int) $f->id, 404);
        if (! static::needsDecision($r)) {
            throw ValidationException::withMessages(['dest' => 'برای این حواله قبلاً تصمیم گرفته شده است.']);
        }
        $third = $f->kind === 'third';
        $rows = array_values(array_filter($rows, fn ($x) => is_array($x) && (filled($x['holder_name'] ?? null) || filled($x['mobile'] ?? null) || filled($x['sheba'] ?? null))));
        if (! $rows) {
            throw ValidationException::withMessages(['dest' => 'دست‌کم یک حساب مقصد وارد کنید.']);
        }
        if (count($rows) > 1 && ($third || ! static::cfg()['allow_split'])) {
            throw ValidationException::withMessages(['dest' => 'تقسیم حواله بین چند حساب مجاز نیست.']);
        }
        if (count($rows) > static::cfg()['max_split']) {
            throw ValidationException::withMessages(['dest' => 'حداکثر '.fa(static::cfg()['max_split']).' حساب برای هر حواله می‌توانید تعیین کنید.']);
        }
        $clean = [];
        $sum = 0;
        $mobiles = [];
        foreach ($rows as $i => $x) {
            $n = (count($rows) > 1 ? 'ردیف '.fa($i + 1).': ' : '');
            $kind = ! $third && ($x['kind'] ?? 'own') === 'other' ? 'other' : 'own';
            $amount = count($rows) === 1 ? (int) $r->amount : (int) to_int($x['amount'] ?? 0);
            $holder = trim(mb_substr((string) ($x['holder_name'] ?? ''), 0, 120));
            $e = [];
            if ($amount < 1000) {
                $e[] = 'مبلغ را وارد کنید';
            }
            if ($kind === 'other') {
                $mob = mobile($x['mobile'] ?? '');
                if ($holder === '') {
                    $e[] = 'نام و نام خانوادگی گیرنده لازم است';
                }
                if (! $mob) {
                    $e[] = 'شماره موبایل گیرنده درست نیست';
                } elseif ($mob === $f->mobile) {
                    $e[] = 'موبایل گیرنده نمی‌تواند شماره خودتان باشد؛ «به حساب خودم» را انتخاب کنید';
                } elseif (in_array($mob, $mobiles, true)) {
                    $e[] = 'این گیرنده دو بار وارد شده است';
                }
                if ($e) {
                    throw ValidationException::withMessages(['dest' => $n.implode('، ', $e).'.']);
                }
                $mobiles[] = $mob;
                $sum += $amount;
                $clean[] = ['kind' => 'other', 'amount' => $amount, 'holder_name' => $holder, 'mobile' => $mob, 'note' => mb_substr(trim((string) ($x['note'] ?? '')), 0, 300) ?: null];

                continue;
            }
            $card = Banks::digits($x['card_number'] ?? '');
            $sheba = Banks::digits($x['sheba'] ?? '');
            $acc = mb_substr(preg_replace('/[^\d\-.]/', '', en_digits((string) ($x['account_number'] ?? ''))), 0, 40);
            if ($holder === '') {
                $e[] = 'نام صاحب حساب لازم است';
            }
            if ($sheba === '') {
                $e[] = 'شماره شبا لازم است (برای واریز پایا/ساتنا)';
            } elseif (strlen($sheba) !== 24) {
                $e[] = 'شبا باید ۲۴ رقم بعد از IR باشد';
            } elseif (! Banks::validSheba($sheba)) {
                $e[] = 'شبا معتبر نیست؛ رقم‌ها را دوباره بررسی کنید';
            }
            if ($card !== '' && ! Banks::validCard($card)) {
                $e[] = 'شماره کارت معتبر نیست';
            }
            if ($e) {
                throw ValidationException::withMessages(['dest' => $n.implode('، ', $e).'.']);
            }
            $sum += $amount;
            $clean[] = [
                'kind' => 'own', 'amount' => $amount, 'holder_name' => $holder, 'card_number' => $card ?: null, 'sheba' => 'IR'.$sheba,
                'account_number' => $acc ?: null, 'bank_name' => Banks::fromSheba($sheba) ?: Banks::fromCard($card),
                'note' => mb_substr(trim((string) ($x['note'] ?? '')), 0, 300) ?: null, 'save' => ! empty($x['save']),
            ];
        }
        if ($sum !== (int) $r->amount) {
            throw ValidationException::withMessages(['dest' => 'جمع مبالغ ('.money($sum).') باید با مبلغ حواله ('.money($r->amount).' تومان) برابر باشد؛ اختلاف: '.money(abs($r->amount - $sum)).' تومان.']);
        }
        $own = collect($clean)->where('kind', 'own');
        $transfers = [];
        DB::transaction(function () use ($f, $r, $clean, $own, &$transfers) {
            $r->destinations()->whereNotIn('status', ['approved', 'transferred'])->delete();
            foreach ($clean as $c) {
                if ($c['kind'] === 'other') {
                    // انتقال: حواله جدا به نام شخص ثالث (او حساب خودش را ثبت می‌کند)
                    $tp = Factory::query()->firstOrCreate(['mobile' => $c['mobile']], ['name' => $c['holder_name'], 'kind' => 'third', 'referred_by' => $f->id, 'active' => true]);
                    if (! $tp->active) {
                        $tp->forceFill(['active' => true])->save();
                    }
                    $child = Remittance::create([
                        'title' => $r->title.' — انتقال از '.$f->name, 'amount' => $c['amount'], 'factory_id' => $tp->id, 'factory_phone' => $tp->mobile,
                        'assignee_id' => $r->assignee_id, 'parent_id' => $r->id, 'status' => 'pending', 'dest_status' => 'awaiting', 'sort' => $r->sort,
                        'note' => 'انتقال '.$f->name.' به '.$c['holder_name'].' ('.$c['mobile'].')'.($c['note'] ? ' — '.$c['note'] : ''),
                    ]);
                    $r->destinations()->create($c + ['factory_id' => $f->id, 'status' => 'transferred', 'child_remittance_id' => $child->id]);
                    $transfers[] = [$tp, $child, $c];

                    continue;
                }
                $save = $c['save'];
                unset($c['save']);
                $r->destinations()->create($c + ['factory_id' => $f->id, 'status' => 'submitted']);
                if ($save) {
                    FactoryAccount::query()->updateOrCreate(['factory_id' => $f->id, 'sheba' => $c['sheba']],
                        ['kind' => 'own', 'holder_name' => $c['holder_name'], 'bank_name' => $c['bank_name'], 'card_number' => $c['card_number'], 'account_number' => $c['account_number']]);
                }
            }
            if ($own->isEmpty()) {
                // کل حواله منتقل شد
                $r->forceFill(['status' => 'transferred', 'dest_status' => 'approved', 'dest_reason' => null, 'dest_at' => now()])->save();
            } else {
                // سهم خود کارخانه‌دار روی همین حواله می‌ماند و منتظر تأیید حسابداری است
                $r->forceFill(['amount' => (int) $own->sum('amount'), 'dest_status' => 'review', 'dest_reason' => null, 'dest_at' => now()])->save();
            }
        });
        foreach ($transfers as [$tp, $child, $c]) {
            app(Sms::class)->send('factory_transfer_in', $tp->mobile, ['name' => $c['holder_name'], 'from' => $f->name, 'amount' => number_format($c['amount']),
                'code' => $child->code, 'link' => static::loginLink($tp, 14)]);
        }
        $who = collect($clean)->map(fn ($c) => ($c['kind'] === 'own' ? 'حساب خودش' : 'انتقال به '.$c['holder_name']).' '.money($c['amount']))->implode('، ');
        static::notifyStaff($r, 'تصمیم کارخانه‌دار — حواله '.$r->code, $f->name.': '.$who);
    }

    /**
     * حسابداری: تأیید حساب‌های مقصد. اولین حساب روی خود حواله می‌نشیند؛ بقیه حواله‌های جدا (زیرمجموعه) می‌شوند.
     */
    public static function approve(Remittance $r, ?User $by = null): void
    {
        if ($r->dest_status !== 'review') {
            throw ValidationException::withMessages(['dest' => 'حساب مقصدی منتظر تأیید نیست.']);
        }
        DB::transaction(function () use ($r, $by) {
            $r = Remittance::query()->lockForUpdate()->findOrFail($r->id);
            $ds = $r->destinations()->where('status', 'submitted')->orderBy('id')->get();
            if ($ds->isEmpty() || (int) $ds->sum('amount') !== (int) $r->amount) {
                throw ValidationException::withMessages(['dest' => 'جمع حساب‌ها با مبلغ حواله برابر نیست.']);
            }
            foreach ($ds->values() as $k => $d) {
                $acc = ['holder_name' => $d->holder_name, 'bank_name' => $d->bank_name, 'card_number' => $d->card_number, 'sheba' => $d->sheba, 'account_number' => $d->account_number];
                if ($k === 0) {
                    $r->forceFill($acc + ['amount' => $d->amount, 'status' => 'active', 'dest_status' => 'approved', 'dest_reason' => null])->save();
                    $target = $r;
                } else {
                    $target = Remittance::create($acc + [
                        'title' => $r->title.' — '.$d->holder_name, 'amount' => $d->amount, 'factory_phone' => $r->factory_phone, 'factory_id' => $r->factory_id,
                        'assignee_id' => $r->assignee_id, 'created_by' => $by?->id, 'parent_id' => $r->id, 'status' => 'active', 'sort' => $r->sort,
                        'dest_status' => 'approved', 'note' => 'بخشی از حواله '.$r->code.' ('.$d->kindLabel().')',
                    ]);
                }
                $d->forceFill(['status' => 'approved', 'reviewed_by' => $by?->id, 'reviewed_at' => now(), 'child_remittance_id' => $target->id === $r->id ? null : $target->id])->save();
            }
        });
        $r->refresh();
        static::sms($r, 'factory_dest_ok', ['code' => $r->code, 'amount' => number_format($r->destinations()->sum('amount'))]);
    }

    public static function reject(Remittance $r, string $reason, ?User $by = null): void
    {
        if ($r->dest_status !== 'review') {
            throw ValidationException::withMessages(['dest' => 'حساب مقصدی منتظر تأیید نیست.']);
        }
        $reason = mb_substr(trim($reason), 0, 300);
        $r->destinations()->where('status', 'submitted')->update(['status' => 'rejected', 'reason' => $reason, 'reviewed_by' => $by?->id, 'reviewed_at' => now()]);
        $r->forceFill(['dest_status' => 'rejected', 'dest_reason' => $reason])->save();
        static::sms($r, 'factory_dest_rejected', ['code' => $r->code, 'reason' => $reason]);
    }

    /* ---------------- فیش‌ها ---------------- */

    /** فیش‌هایی که کارخانه‌دار می‌بیند (فیش رسیده یا تأییدشده) */
    public static function payments(Factory $f): \Illuminate\Database\Eloquent\Builder
    {
        return RemitPayment::query()->whereIn('remittance_id', Remittance::query()->where('factory_id', $f->id)->select('id'))
            ->whereIn('status', ['submitted', 'confirmed'])->whereNotNull('submitted_at');
    }

    public static function isLate(RemitPayment $p): bool
    {
        return ! $p->factory_confirmed_at && $p->submitted_at && $p->submitted_at->lt(now()->subHours(static::cfg()['late_hours']));
    }

    /** کارخانه‌دار: «این مبلغ به حسابم نشست» */
    public static function confirmPayment(Factory $f, RemitPayment $p): void
    {
        abort_unless((int) $p->remittance?->factory_id === (int) $f->id, 404);
        if ($p->factory_confirmed_at) {
            return;
        }
        if (! in_array($p->status, ['submitted', 'confirmed'], true)) {
            throw ValidationException::withMessages(['pay' => 'این فیش قابل تأیید نیست.']);
        }
        $p->forceFill(['factory_confirmed_at' => now()])->save();
        $p->order?->log('کارخانه‌دار ('.$f->name.') نشستن '.money($p->amount).' تومان در حساب را تأیید کرد — حواله '.$p->remittance->code, null);
        if ($p->status === 'submitted' && static::cfg()['confirm_counts']) {
            Remit::confirm($p, null);
        }
        // آخرین فیش هم تأیید کارخانه شد ← تأیید نهایی سفارش («در حال ارسال به باربری»)
        try {
            Shipping::recheckFinal($p->order?->fresh());
        } catch (\Throwable $e) {
            report($e);
        }
    }

    /** آمار داشبورد کارخانه‌دار */
    public static function stats(Factory $f): array
    {
        $rs = Remittance::query()->where('factory_id', $f->id)->get();
        $pays = static::payments($f)->get();
        $wait = $pays->whereNull('factory_confirmed_at');

        return [
            'decide' => $rs->filter(fn ($r) => static::needsDecision($r))->count(),
            'review' => $rs->where('dest_status', 'review')->count(),
            'total' => (int) $rs->whereIn('status', ['active', 'filled'])->sum('amount') + (int) $rs->where('status', 'pending')->sum('amount'),
            'received' => (int) $pays->whereNotNull('factory_confirmed_at')->sum('amount'),
            'waiting' => (int) $wait->sum('amount'),
            'waiting_n' => $wait->count(),
            'late_n' => $wait->filter(fn ($p) => static::isLate($p))->count(),
        ];
    }

    /* ---------------- اطلاع‌رسانی ---------------- */

    public static function sms(Remittance $r, string $event, array $data): array
    {
        $phone = $r->factory?->mobile ?: $r->factory_phone;
        if (! $phone) {
            return ['ok' => false, 'msg' => 'موبایل کارخانه‌دار ثبت نشده است.'];
        }

        return app(Sms::class)->send($event, $phone, $data + ['name' => (string) ($r->factory?->name ?? ''), 'link' => static::url('r/'.$r->id)]);
    }

    /** حواله تازه برای کارخانه‌دار (تعیین حساب لازم است یا فقط اطلاع) */
    public static function announce(Remittance $r): array
    {
        return static::sms($r, $r->status === 'pending' ? 'factory_remit_new' : 'factory_remit_info', ['code' => $r->code, 'amount' => number_format($r->amount)]);
    }

    protected static function notifyStaff(Remittance $r, string $title, string $body): void
    {
        $to = User::query()->where('is_active', true)->get()->filter(fn (User $u) => Remit::isChief($u))->pluck('id')->push($r->assignee_id)->filter()->unique()->values()->all();
        try {
            app(WebPush::class)->toUsers($to, ['title' => $title, 'body' => $body, 'url' => url('/admin/factory-desk'), 'tag' => 'fdest-'.$r->id]);
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** یادآوری روزانه: فیش‌های رسیده‌ای که کارخانه‌دار هنوز تأیید نکرده */
    public static function remind(): int
    {
        if (! static::cfg()['enabled'] || ! static::cfg()['remind']) {
            return 0;
        }
        $n = 0;
        Factory::query()->where('active', true)->get()->each(function (Factory $f) use (&$n) {
            $wait = static::payments($f)->whereNull('factory_confirmed_at')->where('submitted_at', '<', now()->subHours(3))->get();
            if ($wait->isEmpty() || \Illuminate\Support\Facades\Cache::has('fac.remind.'.$f->id)) {
                return;
            }
            \Illuminate\Support\Facades\Cache::put('fac.remind.'.$f->id, 1, now()->addHours(20));
            app(Sms::class)->send('factory_pending', $f->mobile, ['name' => $f->name, 'count' => (string) $wait->count(), 'amount' => number_format($wait->sum('amount')), 'link' => static::url()]);
            $n++;
        });

        return $n;
    }
}
