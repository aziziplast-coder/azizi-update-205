<?php

namespace App\Services;

use App\Models\Category;
use App\Models\Coupon;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Collection;

/**
 * بررسی و محاسبه کد تخفیف روی سبد.
 */
class Coupons
{
    public const KEY = 'coupon';

    public static function current(): ?string
    {
        return session(self::KEY) ?: null;
    }

    public static function forget(): void
    {
        session()->forget(self::KEY);
    }

    /**
     * @param  Collection<int, object>  $lines  ردیف‌های سبد
     * @return array{ok: bool, msg: string, coupon: ?Coupon, discount: int, free_shipping: bool}
     */
    public static function evaluate(?string $code, Collection $lines, ?User $user): array
    {
        $fail = fn (string $msg) => ['ok' => false, 'msg' => $msg, 'coupon' => null, 'discount' => 0, 'free_shipping' => false];
        $code = Coupon::clean($code);
        if ($code === '') {
            return $fail('کد تخفیف را وارد کنید.');
        }
        $c = Coupon::query()->where('code', $code)->first();
        if (! $c || ! $c->is_active) {
            return $fail('کد تخفیف «'.$code.'» معتبر نیست.');
        }
        if ($c->starts_at && $c->starts_at->isFuture()) {
            return $fail('این کد از '.jdate($c->starts_at, true).' فعال می‌شود.');
        }
        if ($c->ends_at && $c->ends_at->isPast()) {
            return $fail('مهلت استفاده از این کد تمام شده است.');
        }
        if ($c->max_uses && $c->used_count >= $c->max_uses) {
            return $fail('ظرفیت استفاده از این کد تکمیل شده است.');
        }
        $mobiles = array_filter(array_map(fn ($m) => mobile($m), preg_split('/[\s,،]+/u', (string) $c->mobiles)));
        if ($mobiles) {
            if (! $user) {
                return $fail('برای استفاده از این کد ابتدا وارد شوید.');
            }
            if (! in_array($user->mobile, $mobiles, true)) {
                return $fail('این کد برای حساب شما تعریف نشده است.');
            }
        }
        if ($c->max_per_user || $c->first_order) {
            if (! $user) {
                return $fail('برای استفاده از این کد ابتدا وارد شوید.');
            }
            if ($c->max_per_user && $c->usages()->where('user_id', $user->id)->count() >= $c->max_per_user) {
                return $fail('شما پیش‌تر از این کد استفاده کرده‌اید.');
            }
            if ($c->first_order && Order::query()->where('user_id', $user->id)->whereNotIn('status', ['cancelled', 'failed'])->exists()) {
                return $fail('این کد فقط برای اولین خرید است.');
            }
        }

        // ردیف‌های مشمول
        $cats = array_filter(array_map('intval', (array) $c->category_ids));
        if ($cats) {
            $all = [];
            foreach (Category::query()->whereIn('id', $cats)->get() as $cat) {
                $all = array_merge($all, $cat->descendantIds());
            }
            $cats = array_unique($all);
        }
        $prods = array_filter(array_map('intval', (array) $c->product_ids));
        $eligible = $lines->filter(function ($l) use ($c, $cats, $prods) {
            /** @var Product $p */
            $p = $l->product;
            if ($c->applies_to === 'carton' && $l->retail) {
                return false;
            }
            if ($c->applies_to === 'retail' && ! $l->retail) {
                return false;
            }
            if ($c->exclude_sale && $l->compare_price) {
                return false;
            }
            if ($prods || $cats) {
                return in_array($p->id, $prods, true) || in_array((int) $p->category_id, $cats, true);
            }

            return true;
        });
        $base = (int) $eligible->sum('total');
        $cartTotal = (int) $lines->sum('total');
        if ($c->min_cart && $cartTotal < $c->min_cart) {
            return $fail('این کد برای خرید بالای '.money($c->min_cart, true).' است؛ '.money($c->min_cart - $cartTotal, true).' دیگر اضافه کنید.');
        }
        if ($base <= 0 && $c->type !== 'shipping') {
            return $fail('هیچ‌یک از کالاهای سبد شامل این کد نمی‌شود.');
        }

        $discount = match ($c->type) {
            'percent' => (int) floor($base * min(100, $c->amount) / 100),
            'fixed' => (int) min($c->amount, $base),
            default => 0,
        };
        if ($c->max_discount && $discount > $c->max_discount) {
            $discount = (int) $c->max_discount;
        }

        return [
            'ok' => true,
            'msg' => 'کد «'.$c->code.'» اعمال شد: '.$c->describe(),
            'coupon' => $c,
            'discount' => $discount,
            'free_shipping' => $c->type === 'shipping',
        ];
    }

    /** ثبت استفاده پس از ثبت سفارش */
    public static function record(Coupon $c, Order $order, int $amount): void
    {
        $c->usages()->create(['user_id' => $order->user_id, 'order_id' => $order->id, 'amount' => $amount]);
        $c->increment('used_count');
    }

    /** برگرداندن ظرفیت هنگام لغو سفارش */
    public static function release(Order $order): void
    {
        foreach (\App\Models\CouponUsage::query()->where('order_id', $order->id)->get() as $u) {
            Coupon::query()->whereKey($u->coupon_id)->where('used_count', '>', 0)->decrement('used_count');
            $u->delete();
        }
    }
}
