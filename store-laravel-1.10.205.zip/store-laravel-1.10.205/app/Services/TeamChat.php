<?php

namespace App\Services;

use App\Models\ChatThread;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Throwable;

/**
 * گپ داخلی: اپراتورها ↔ حسابدار کل (یک گفتگو برای هر اپراتور).
 * همان موتور گفتگوی سفارش (پیام، عکس، ویس، ویدیو، پاسخ به پیام، حذف)؛ طرف c = اپراتور، s = حسابدار کل.
 * حسابدار کل = دسترسی «حسابدار کل» (مدیر کل هم). همه حسابدارهای کل همه گفتگوها را می‌بینند.
 */
class TeamChat
{
    public static function ready(): bool
    {
        static $ok = null;

        return $ok ??= Chat::ready() && \App\Support\DbSchema::hasColumn('chat_threads', 'team_user_id');
    }

    public static function enabled(): bool
    {
        return static::ready() && (bool) (setting('team_chat') ?? true);
    }

    protected static function staffUser(?User $u): bool
    {
        return (bool) ($u && $u->is_active && in_array($u->role, ['admin', 'staff'], true));
    }

    public static function isChief(?User $u): bool
    {
        return static::staffUser($u) && Remit::isChief($u);
    }

    /** اپراتور: هر همکاری که حسابدار کل نیست */
    public static function isOperator(?User $u): bool
    {
        return static::enabled() && static::staffUser($u) && ! Remit::isChief($u);
    }

    public static function canChief(?User $u): bool
    {
        return static::enabled() && static::isChief($u);
    }

    /** همکارانی که حسابدار کل می‌تواند با آن‌ها گپ بزند */
    public static function operators(): Collection
    {
        return User::query()->where('is_active', true)->whereIn('role', ['admin', 'staff'])->orderBy('name')->get()
            ->filter(fn (User $u) => ! Remit::isChief($u))->values();
    }

    public static function thread(User $op, bool $create = true): ?ChatThread
    {
        $t = ChatThread::query()->where('team_user_id', $op->id)->first();
        if (! $t && $create) {
            try {
                $t = ChatThread::query()->create(['team_user_id' => $op->id, 'order_id' => null, 'user_id' => null, 'token' => Str::random(32)]);
            } catch (Throwable) {
                $t = ChatThread::query()->where('team_user_id', $op->id)->first();
            }
            if ($t) {
                Chat::signal($t);
            }
        }

        return $t;
    }

    /** خوانده‌نشده‌های حسابدار کل (همه اپراتورها) */
    public static function unreadChief(): int
    {
        return static::ready() ? (int) ChatThread::query()->whereNotNull('team_user_id')->sum('unread_staff') : 0;
    }

    public static function unreadOperator(User $u): int
    {
        return static::ready() ? (int) ChatThread::query()->where('team_user_id', $u->id)->value('unread_customer') : 0;
    }

    public static function state(ChatThread $t, string $side, ?User $u, int $after = 0): array
    {
        $chief = $side === 's';
        $msgs = Chat::messages($t, $after, true);

        return [
            'ok' => true, 'sig' => Chat::signalUrl($t), 'token' => $t->token, 'last' => (int) $t->last_id,
            'read' => (int) ($chief ? $t->customer_read_id : $t->staff_read_id), 'closed' => false, 'off' => null,
            'staff' => null, 'shop' => store_name(), 'order' => '',
            'messages' => $msgs, 'more' => ! $after && count($msgs) >= 60,
            'media' => Chat::mediaCfg(), 'del_min' => Chat::cfg()['del_min'], ...($u ? ['me' => (int) $u->id] : []),
        ];
    }

    /** پیام اپراتور ← اعلان به حسابدارهای کل */
    public static function notifyChiefs(User $op, string $text): void
    {
        try {
            $ids = User::query()->where('is_active', true)->whereIn('role', ['admin', 'staff'])->get()
                ->filter(fn (User $u) => Remit::isChief($u) && (int) $u->id !== (int) $op->id)->pluck('id')->all();
            app(WebPush::class)->toUsers(array_values(array_map('intval', $ids)), [
                'title' => '💬 '.$op->displayName(), 'body' => mb_substr($text, 0, 120),
                'url' => url('/admin/team-chats?u='.$op->id), 'tag' => 'tchat-'.$op->id,
            ]);
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** پیام حسابدار کل ← اعلان به همان اپراتور */
    public static function notifyOperator(User $op, User $by, string $text): void
    {
        try {
            app(WebPush::class)->toUsers([(int) $op->id], [
                'title' => '💬 حسابدار کل — '.$by->displayName(), 'body' => mb_substr($text, 0, 120),
                'url' => url('/admin/team-chat'), 'tag' => 'tchat-me',
            ]);
        } catch (Throwable $e) {
            report($e);
        }
    }
}
