<?php

namespace App\Services;

use App\Models\OtpCode;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;

class Otp
{
    public static function enabled(): bool
    {
        return in_array(setting('login_mode', 'otp'), ['otp', 'both'], true) && Sms::configured();
    }

    public static function passwordEnabled(): bool
    {
        return ! static::enabled() || setting('login_mode') !== 'otp';
    }

    /** @return array{ok: bool, msg: string, wait: int} */
    public function send(string $mobile, string $ip): array
    {
        $wait = max(30, (int) setting('otp_resend', 60));
        $key = 'otp-send:'.$mobile;
        if (RateLimiter::tooManyAttempts($key, 1)) {
            return ['ok' => false, 'msg' => 'لطفاً کمی صبر کنید و دوباره تلاش کنید.', 'wait' => RateLimiter::availableIn($key)];
        }
        // اینترنت همراه در ایران پشت IP مشترک است؛ سقف بالا تا مشتری‌ها جلوی هم را نگیرند
        if (RateLimiter::tooManyAttempts('otp-ip:'.$ip, 60)) {
            return ['ok' => false, 'msg' => 'تعداد درخواست‌ها زیاد است؛ یک ساعت دیگر تلاش کنید.', 'wait' => RateLimiter::availableIn('otp-ip:'.$ip)];
        }
        $len = min(8, max(4, (int) setting('otp_length', 5)));
        $code = (string) random_int(10 ** ($len - 1), (10 ** $len) - 1);
        OtpCode::query()->where('mobile', $mobile)->delete();
        OtpCode::create(['mobile' => $mobile, 'code' => Hash::make($code), 'expires_at' => now()->addSeconds(max(60, (int) setting('otp_ttl', 180)))]);
        $res = app(Sms::class)->send('otp', $mobile, ['code' => $code], true);
        if (! $res['ok']) {
            // کد ذخیره شده است؛ اگر پیامک با وجود پاسخ نامشخص پنل رسیده باشد، مشتری بتواند کد را وارد کند
            RateLimiter::hit($key, 30);
            RateLimiter::hit('otp-ip:'.$ip, 3600);

            return ['ok' => false, 'msg' => ! empty($res['maybe'])
                ? 'ارسال پیامک با تأخیر انجام شد؛ اگر کد به دستتان رسید آن را وارد کنید، وگرنه چند لحظه بعد «ارسال دوباره» را بزنید.'
                : 'ارسال پیامک تأیید نشد. اگر کد به دستتان رسید آن را وارد کنید، وگرنه چند لحظه بعد «ارسال دوباره» را بزنید.', 'wait' => 30, 'codeStep' => true];
        }
        static::trackLead($mobile);
        RateLimiter::hit($key, $wait);
        RateLimiter::hit('otp-ip:'.$ip, 3600);

        return ['ok' => true, 'msg' => 'کد تأیید به '.fa($mobile).' پیامک شد.', 'wait' => $wait];
    }

    /** ثبت درخواست کد: اگر حسابی با این موبایل نیست، «مشتری احراز نشده» ساخته می‌شود */
    public static function trackLead(string $mobile): void
    {
        if (! User::verifyColumns()) {
            return;
        }
        try {
            $u = User::query()->where('mobile', $mobile)->first();
            if (! $u) {
                User::$lead = true;
                try {
                    $u = User::query()->create(['mobile' => $mobile, 'role' => 'customer', 'is_active' => true]);
                } finally {
                    User::$lead = false;
                }
            }
            User::query()->whereKey($u->id)->update(['otp_sent_at' => now(), 'otp_sends' => \Illuminate\Support\Facades\DB::raw('otp_sends + 1')]);
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function verify(string $mobile, string $code): bool
    {
        $row = OtpCode::query()->where('mobile', $mobile)->latest('id')->first();
        if (! $row || $row->expires_at->isPast() || $row->attempts >= 6) {
            return false;
        }
        if (! Hash::check(en_digits(trim($code)), $row->code)) {
            $row->increment('attempts');

            return false;
        }
        $row->delete();

        return true;
    }
}
