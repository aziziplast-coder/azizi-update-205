<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

/** تطبیق ردیف‌های اکسل با مشتریان CRM (کد هلو ← موبایل ← نام) با کش در حافظه */
class CrmMap
{
    protected array $byCode = [];

    protected array $byMobile = [];

    protected array $byName = [];

    protected array $seen = [];

    public int $created = 0;

    public function __construct()
    {
        foreach (DB::table('crm_customers')->get(['id', 'code', 'mobile', 'nkey', 'user_id']) as $r) {
            if ($r->code) {
                $this->byCode[$r->code] = $r->id;
            }
            if ($r->mobile) {
                $this->byMobile[$r->mobile] = $r->id;
            }
            if ($r->nkey) {
                $this->byName[$r->nkey] ??= $r->id;
            }
        }
    }

    public function touched(): int
    {
        return count($this->seen);
    }

    public function resolve(string $code, string $name, ?string $mobile, array $extra, bool $update): int
    {
        $code = mb_substr(en_digits(trim($code)), 0, 40);
        $nk = Crm::nkey($name);
        $id = ($code !== '' ? ($this->byCode[$code] ?? null) : null) ?? ($mobile ? ($this->byMobile[$mobile] ?? null) : null) ?? ($nk !== '' ? ($this->byName[$nk] ?? null) : null);
        $extra = array_filter($extra, fn ($v) => $v !== null && $v !== '');
        foreach (['phone' => 40, 'city' => 80, 'address' => 300, 'company' => 150] as $k => $max) {
            if (isset($extra[$k])) {
                $extra[$k] = mb_substr((string) $extra[$k], 0, $max);
            }
        }
        if (! $id) {
            $id = DB::table('crm_customers')->insertGetId(array_merge(['code' => $code ?: null, 'name' => mb_substr($name ?: $code, 0, 150), 'nkey' => $nk ?: null, 'mobile' => $mobile, 'created_at' => now(), 'updated_at' => now()], $extra));
            $this->created++;
        } elseif ($update || $mobile || $code !== '') {
            $upd = array_merge($update ? $extra : [], array_filter(['code' => $code ?: null, 'mobile' => $mobile, 'name' => $update && $name !== '' ? mb_substr($name, 0, 150) : null, 'nkey' => $update && $nk !== '' ? $nk : null]));
            if ($upd) {
                DB::table('crm_customers')->where('id', $id)->update($upd + ['updated_at' => now()]);
            }
        }
        if ($code !== '') {
            $this->byCode[$code] = $id;
        }
        if ($mobile) {
            $this->byMobile[$mobile] = $id;
        }
        if ($nk !== '') {
            $this->byName[$nk] ??= $id;
        }
        $this->seen[$id] = 1;

        return $id;
    }

    /** مشتری سایت ← ردیف CRM (با شناسه کاربر یا موبایل؛ اگر نبود ساخته می‌شود) */
    public function forUser(int $uid, object $o): ?int
    {
        $id = DB::table('crm_customers')->where('user_id', $uid)->value('id');
        if ($id) {
            return (int) $id;
        }
        $u = DB::table('users')->where('id', $uid)->first(['id', 'name', 'mobile', 'city', 'company']);
        if (! $u) {
            return null;
        }
        $m = $u->mobile ?: ($o->mobile ? mobile($o->mobile) : null);
        if ($m && isset($this->byMobile[$m])) {
            DB::table('crm_customers')->where('id', $this->byMobile[$m])->update(['user_id' => $uid]);

            return $this->byMobile[$m];
        }
        $name = $u->name ?: ($o->customer_name ?: 'مشتری سایت');
        $id = DB::table('crm_customers')->insertGetId(['user_id' => $uid, 'name' => mb_substr($name, 0, 150), 'nkey' => Crm::nkey($name), 'mobile' => $m, 'city' => $u->city ?: ($o->city ?? null), 'company' => $u->company ?: ($o->company ?? null), 'created_at' => now(), 'updated_at' => now()]);
        if ($m) {
            $this->byMobile[$m] = $id;
        }

        return $id;
    }
}
