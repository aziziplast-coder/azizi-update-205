<?php

namespace App\Services;

use App\Models\LiveChat;
use App\Models\LiveMessage;
use App\Models\User;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use Throwable;

/**
 * گفتگوی زنده و پیام هوشمند به بازدیدکنندگان سایت
 *
 * کم‌فشار برای سرور:
 *  - هر بازدید فقط یک درخواست بسیار سبک به public/live.php می‌زند (بدون بارگذاری لاراول و بدون دیتابیس)
 *    که یک فایل کوچک برای همان بازدیدکننده می‌نویسد. «آنلاین‌ها» = فایل‌هایی که در ۲ دقیقه اخیر تغییر کرده‌اند.
 *  - تصمیم پیام خودکار (کدام پیام، کی) در مرورگر خود بازدیدکننده گرفته می‌شود؛ سرور کاری نمی‌کند.
 *  - دیتابیس فقط وقتی درگیر می‌شود که گفتگویی واقعاً شروع شود (بازدیدکننده جواب بدهد یا همکار پیام بفرستد).
 *  - بازدیدکننده فقط وقتی پاسخ تازه‌ای هست (سیگنال در همان فایل سبک) پیام‌ها را از لاراول می‌گیرد.
 */
class Live
{
    public const RULES = [
        'search' => 'جستجوی بی‌نتیجه',
        'repeat' => 'بازدید دوباره از یک کالا',
        'cart' => 'معطل ماندن در سبد خرید',
        'product' => 'ماندن روی صفحه یک کالا',
        'category' => 'گشتن در یک دسته‌بندی',
        'browse' => 'دیدن چند کالا بدون خرید',
        'exit' => 'قصد خروج از سایت (کامپیوتر)',
        'manual' => 'پیام دستی همکار',
    ];

    public static function defaults(): array
    {
        return [
            'enabled' => true,
            'auto' => true,
            'reply' => 'panel',       // panel | bale | both
            'bale' => '',
            'when' => 'always',       // always | online | hours
            'from' => '08:30',
            'to' => '20:00',
            'friday' => false,        // جمعه‌ها هم پیام بدهد
            'agent' => 'مشاور فروش',
            'avatar' => null,
            'max_day' => 2,
            'gap' => 180,
            'mobile' => true,
            'ask_phone' => true,
            'sound' => true,
            'offline_text' => 'پیام شما رسید ✅ همکاران ما به‌زودی همین‌جا جواب می‌دهند.',
            'voice' => true,          // ویس از هر دو طرف
            'voice_sec' => 120,
            'voice_days' => 60,       // ویس‌های قدیمی‌تر پاک می‌شوند
            'own_only' => false,      // هر پاسخگو فقط گفتگوهای خودش و بی‌مسئول‌ها را ببیند
            'assign' => 'first',      // first = اولین پاسخ‌دهنده | round = نوبتی بین پاسخگوهای آنلاین
            'push' => true,           // اعلان به گوشی پاسخگوها
            'faq_on' => true,
            'faq' => [
                ['on' => false, 'q' => 'سرمایه لازم برای شروع / حداقل خرید', 'keys' => "سرمایه\nحداقل خرید\nچقدر پول\nبا چند تومن\nحداقل سفارش", 'a' => 'حداقل خرید از ما … تومان است. (این متن را از «تنظیمات ← گفتگوی زنده ← جواب‌های خودکار» درست کنید و روشنش کنید.)'],
                ['on' => false, 'q' => 'ارسال به شهرستان', 'keys' => "ارسال\nباربری\nشهرستان\nمیفرستید\nپست", 'a' => 'بله، به سراسر کشور با باربری ارسال می‌کنیم؛ کرایه به عهده مشتری است (پس‌کرایه).'],
                ['on' => false, 'q' => 'خرید چکی', 'keys' => "چک\nچکی\nاقساط\nنصف نقد", 'a' => 'بله، خرید با شرایط نقد و چک هم داریم؛ هنگام تکمیل خرید گزینه آن را انتخاب کنید.'],
            ],
            'ai' => ['on' => false, 'url' => 'https://api.avalai.ir/v1', 'key' => '', 'model' => 'gpt-4o-mini', 'about' => '', 'per_chat' => 8, 'per_day' => 300],
            'quick' => "سلام، خوش آمدید 🌹 در خدمتم.\nقیمت‌ها عمده و کارتنی است.\nارسال به سراسر کشور با باربری انجام می‌شود.\nشماره تماستان را بفرستید تا با شما تماس بگیریم.",
            'rules' => [
                'search' => ['on' => true, 'sec' => 6, 'text' => '«{q}» را پیدا نکردید؟ بنویسید دقیقاً چه کالایی می‌خواهید؛ شاید در انبار داشته باشیم.'],
                'repeat' => ['on' => true, 'sec' => 8, 'times' => 2, 'text' => 'سلام{name} 🙂 دوباره به «{product}» سر زدید. اگر برای خریدش سؤالی دارید، همین‌جا بپرسید.'],
                'cart' => ['on' => true, 'sec' => 45, 'text' => 'برای تکمیل سفارش سؤالی دارید؟ شرایط پرداخت، چک و ارسال را همین‌جا بپرسید.'],
                'product' => ['on' => true, 'sec' => 30, 'text' => 'سلام{name} 👋 درباره «{product}» سؤالی دارید؟ قیمت عمده، تعداد در کارتن یا ارسال — همین‌جا بپرسید.'],
                'category' => ['on' => true, 'sec' => 50, 'views' => 4, 'text' => 'دنبال کالای خاصی در «{category}» هستید؟ بنویسید تا سریع پیدایش کنیم.'],
                'browse' => ['on' => true, 'sec' => 10, 'views' => 7, 'text' => 'چند کالا را دیدید{name}؛ کمک می‌خواهید بهترین را انتخاب کنید؟'],
                'exit' => ['on' => false, 'sec' => 20, 'text' => 'قبل از رفتن… سؤالی دارید؟ جوابش یک دقیقه هم طول نمی‌کشد.'],
            ],
        ];
    }

    public static function cfg(): array
    {
        $d = static::defaults();
        $c = (array) setting('live', []);
        $out = array_replace($d, array_intersect_key($c, $d));
        $out['rules'] = $d['rules'];
        $out['ai'] = array_replace($d['ai'], array_intersect_key((array) ($c['ai'] ?? []), $d['ai']));
        $out['faq'] = array_values(array_filter((array) ($c['faq'] ?? $d['faq']), 'is_array'));
        foreach ((array) ($c['rules'] ?? []) as $k => $r) {
            if (isset($d['rules'][$k]) && is_array($r)) {
                $out['rules'][$k] = array_replace($d['rules'][$k], array_intersect_key($r, $d['rules'][$k]));
            }
        }

        return $out;
    }

    public static function enabled(): bool
    {
        try {
            return (bool) static::cfg()['enabled'];
        } catch (Throwable) {
            return false;
        }
    }

    /* ---------------- فایل‌های سبک ---------------- */

    public static function dir(string $sub = ''): string
    {
        $d = storage_path('app/_live'.($sub !== '' ? '/'.$sub : ''));
        if (! is_dir($d)) {
            @mkdir($d, 0775, true);
        }

        return $d;
    }

    public static function key(): string
    {
        $f = static::dir().'/key';
        $k = is_file($f) ? trim((string) @file_get_contents($f)) : '';
        if (strlen($k) < 32) {
            $k = Str::random(40);
            @file_put_contents($f, $k);
            @chmod($f, 0640);
        }

        return $k;
    }

    /** امضای شناسه کاربر واردشده (تا live.php بدون لاراول بفهمد این بازدیدکننده کیست) */
    public static function sign(int $uid): string
    {
        return substr(hash_hmac('sha256', 'u'.$uid, static::key()), 0, 24);
    }

    public static function validVid(?string $v): bool
    {
        return is_string($v) && preg_match('/^[a-z0-9]{16,32}$/', $v);
    }

    /** خبر دادن به بازدیدکننده که پیام تازه دارد (live.php همین را برمی‌گرداند) */
    public static function signal(LiveChat $c, bool $bump = true, int $typing = 0): void
    {
        $f = static::dir('s').'/'.$c->vid.'.json';
        $old = is_file($f) ? (array) json_decode((string) @file_get_contents($f), true) : [];
        $d = ['t' => $bump ? (int) (microtime(true) * 1000) : (int) ($old['t'] ?? 0), 'k' => $c->token, 'n' => (int) $c->unread_visitor, 'ty' => $typing ?: ($bump ? 0 : (int) ($old['ty'] ?? 0))];
        @file_put_contents($f, json_encode($d), LOCK_EX);
    }

    /** همکار در حال نوشتن است ← بازدیدکننده «در حال نوشتن…» می‌بیند؛ همکاران دیگر هم */
    public static function typing(LiveChat $c, User $u): void
    {
        $k = 'live.ty.'.$c->id;
        Cache::put($k, ['i' => $u->id, 'n' => Str::before(trim((string) $u->name), ' ')], 8);
        if (Cache::get($k.'.w') === $u->id) {
            return; // فایل سیگنال هر چند ثانیه یک بار
        }
        Cache::put($k.'.w', $u->id, 4);
        static::signal($c, false, time() + 7);
    }

    public static function typingOf(LiveChat $c): ?array
    {
        return Cache::get('live.ty.'.$c->id);
    }

    /* ---------------- پاسخگوها ---------------- */

    /** این همکار الان صفحه گفتگوی زنده را باز دارد */
    public static function markOnline(User $u): void
    {
        Cache::put('live.on.'.$u->id, time(), 90);
        $ids = (array) Cache::get('live.on.ids', []);
        if (! in_array($u->id, $ids, true)) {
            $ids[] = $u->id;
            Cache::put('live.on.ids', array_slice($ids, -50), 86400);
        }
    }

    /** شناسه پاسخگوهایی که الان آنلاین‌اند */
    public static function onlineStaff(int $within = 60): array
    {
        $out = [];
        foreach ((array) Cache::get('live.on.ids', []) as $id) {
            $t = (int) Cache::get('live.on.'.$id);
            if ($t && $t > time() - $within) {
                $out[] = (int) $id;
            }
        }

        return $out;
    }

    /** همه کسانی که دسترسی گفتگوی زنده دارند */
    public static function agents(bool $withAdmins = false): array
    {
        return Cache::remember('live.agents.'.(int) $withAdmins, 60, fn () => User::query()->where('is_active', true)
            ->where(fn ($q) => $q->where('role', 'staff')->when($withAdmins, fn ($w) => $w->orWhere('role', 'admin')))
            ->orderBy('name')->get(['id', 'name', 'role', 'permissions', 'is_active'])
            ->filter(fn (User $u) => $u->hasPerm('live'))->map(fn (User $u) => ['id' => $u->id, 'name' => $u->name, 'admin' => $u->role === 'admin'])->values()->all());
    }

    /** سپردن گفتگوی تازه: نوبتی بین پاسخگوهای آنلاین (اگر در تنظیمات روشن باشد) */
    public static function autoAssign(LiveChat $c): void
    {
        if ($c->staff_id || static::cfg()['assign'] !== 'round') {
            return;
        }
        $agents = array_column(static::agents(), 'id');
        $on = array_values(array_intersect($agents, static::onlineStaff()));
        if (! $on) {
            return;
        }
        sort($on);
        $last = (int) Cache::get('live.rr', 0);
        $next = $on[0];
        foreach ($on as $id) {
            if ($id > $last) {
                $next = $id;
                break;
            }
        }
        Cache::put('live.rr', $next, 86400 * 30);
        $c->forceFill(['staff_id' => $next, 'assigned_at' => now()])->save();
    }

    /** اعلان به گوشی پاسخگو(ها) وقتی پیام مشتری نیاز به جواب دارد و صفحه را باز ندارند */
    public static function notify(LiveChat $c, string $text): void
    {
        try {
            if (! static::cfg()['push'] || ! WebPush::enabled()) {
                return;
            }
            $to = $c->staff_id ? [(int) $c->staff_id] : array_column(static::agents(true), 'id');
            $to = array_values(array_diff($to, static::onlineStaff(20)));
            if (! $to) {
                return;
            }
            $key = 'live.push.'.$c->id;
            if (Cache::has($key)) {
                return; // هر گفتگو حداکثر هر ۲ دقیقه یک اعلان
            }
            Cache::put($key, 1, 120);
            app(WebPush::class)->toUsers($to, ['title' => '💬 '.$c->label(), 'body' => mb_substr($text, 0, 120), 'url' => url('/advisor#c'.$c->id), 'tag' => 'live-'.$c->id]);
        } catch (Throwable $e) {
            report($e);
        }
    }


    /** همکاری صفحه گفتگوی زنده را باز دارد */
    public static function touchOnline(): void
    {
        @touch(static::dir().'/on');
    }

    public static function staffOnline(): bool
    {
        $f = static::dir().'/on';
        clearstatcache(true, $f);

        return is_file($f) && filemtime($f) > time() - 90;
    }

    /** آیا الان ساعت کاری است؟ (به وقت تهران) */
    public static function inHours(?array $c = null): bool
    {
        $c ??= static::cfg();
        $now = now('Asia/Tehran');
        if ($now->isFriday() && empty($c['friday'])) {
            return false;
        }
        $t = $now->format('H:i');

        return $t >= (string) $c['from'] && $t <= (string) $c['to'];
    }

    /* ---------------- آنلاین‌ها ---------------- */

    /** بازدیدکنندگانی که در $sec ثانیه اخیر فعال بوده‌اند */
    public static function visitors(int $sec = 120): array
    {
        $out = [];
        $dir = static::dir('v');
        $min = time() - $sec;
        foreach (glob($dir.'/*.json') ?: [] as $f) {
            $m = @filemtime($f);
            if (! $m || $m < $min) {
                continue;
            }
            $d = json_decode((string) @file_get_contents($f), true);
            if (! is_array($d) || empty($d['v'])) {
                continue;
            }
            $d['seen'] = $m;
            $out[] = $d;
        }
        // پاک کردن فایل‌های کهنه (گاه‌به‌گاه)
        if (random_int(1, 40) === 1) {
            static::cleanup();
        }
        usort($out, fn ($a, $b) => ($b['at'] ?? 0) <=> ($a['at'] ?? 0));

        return $out;
    }

    public static function visitor(string $vid): ?array
    {
        if (! static::validVid($vid)) {
            return null;
        }
        $f = static::dir('v').'/'.$vid.'.json';
        if (! is_file($f)) {
            return null;
        }
        $d = json_decode((string) @file_get_contents($f), true);
        if (! is_array($d)) {
            return null;
        }
        $d['seen'] = filemtime($f);

        return $d;
    }

    public static function cleanup(): void
    {
        // ویس‌های قدیمی (پوشه‌های ماهانه)
        try {
            $days = max(7, (int) static::cfg()['voice_days']);
            $limit = now()->subDays($days)->format('Y-m');
            foreach (glob(public_path('uploads/live').'/*', GLOB_ONLYDIR) ?: [] as $d) {
                if (basename($d) < $limit) {
                    array_map('unlink', glob($d.'/*') ?: []);
                    @rmdir($d);
                }
            }
        } catch (Throwable) {
        }
        $old = time() - 86400 * 2;
        foreach (['v', 's'] as $sub) {
            foreach (glob(static::dir($sub).'/*.json') ?: [] as $f) {
                if (@filemtime($f) < $old) {
                    @unlink($f);
                }
            }
        }
    }

    /* ---------------- گفتگو ---------------- */

    public static function chatFor(string $vid, bool $create = false, array $attrs = []): ?LiveChat
    {
        $c = LiveChat::query()->where('vid', $vid)->where('status', 'open')->latest('id')->first();
        if (! $c && $create) {
            $c = LiveChat::query()->create(['vid' => $vid, 'token' => Str::random(32), 'status' => 'open'] + $attrs);
        }

        return $c;
    }

    public static function post(LiveChat $c, string $side, string $body, ?User $by = null, array $meta = [], string $kind = 'text', bool $count = true): LiveMessage
    {
        $body = trim(mb_substr($body, 0, 2000));
        $m = $c->messages()->create(['side' => $side, 'kind' => $kind, 'user_id' => $by?->id, 'body' => $body, 'meta' => $meta ?: null, 'created_at' => now()]);
        $c->last_side = $side;
        $c->last_text = $kind === 'voice' ? '🎤 پیام صوتی' : mb_substr(preg_replace('/\s+/u', ' ', $body), 0, 190);
        $c->last_at = now();
        if ($side === 'v') {
            if ($count) {
                $c->unread_staff++;
            }
            $c->status = 'open';
        } else {
            $c->unread_visitor++;
            if ($side === 's' && $by) {
                $c->staff_at = now();
                if (! $c->staff_id) {
                    $c->staff_id = $by->id;
                    $c->assigned_at = now();
                }
            }
        }
        $c->save();
        if ($side !== 'v') {
            static::signal($c);
        }
        Cache::forget('live.unread');

        return $m;
    }

    public static function unread(): int
    {
        try {
            return (int) Cache::remember('live.unread', 20, fn () => LiveChat::query()->where('status', 'open')->where('unread_staff', '>', 0)->count());
        } catch (Throwable) {
            return 0;
        }
    }

    public static function msgJson(LiveMessage $m, ?string $agent = null): array
    {
        $meta = (array) $m->meta;

        return array_filter([
            'id' => $m->id, 's' => $m->side, 'b' => $m->body, 'k' => $m->kind && $m->kind !== 'text' ? $m->kind : null,
            'u' => $m->kind === 'voice' && ! empty($meta['path']) ? asset('uploads/'.$meta['path']) : null,
            'sec' => $meta['sec'] ?? null,
            'bot' => ! empty($meta['ai']) ? 'ai' : (isset($meta['faq']) ? 'faq' : null),
            'ask' => ! empty($meta['ask']) && empty($meta['done']) ? 1 : null,
            'n' => $m->side === 'v' ? null : ($agent ?? static::cfg()['agent']),
            't' => fa($m->created_at?->timezone('Asia/Tehran')->format('H:i') ?? ''),
        ], fn ($v) => $v !== null);
    }

    /* ---------------- ویس ---------------- */

    public static function storeVoice(\Illuminate\Http\UploadedFile $f, int $sec): array
    {
        $c = static::cfg();
        if (empty($c['voice'])) {
            throw new \RuntimeException('ارسال پیام صوتی خاموش است.');
        }
        if (! $f->isValid() || $f->getSize() < 200 || $f->getSize() > 6 * 1024 * 1024) {
            throw new \RuntimeException('پیام صوتی معتبر نیست یا خیلی طولانی است.');
        }
        $head = (string) file_get_contents($f->getRealPath(), false, null, 0, 12);
        $ext = match (true) {
            str_starts_with($head, "\x1A\x45\xDF\xA3") => 'webm',
            str_starts_with($head, 'OggS') => 'ogg',
            substr($head, 4, 4) === 'ftyp' => 'm4a',
            str_starts_with($head, 'ID3') || str_starts_with($head, "\xFF\xFB") => 'mp3',
            default => throw new \RuntimeException('قالب پیام صوتی شناخته نشد.'),
        };
        $rel = 'live/'.date('Y-m').'/'.Str::random(28).'.'.$ext;
        $abs = public_path('uploads/'.$rel);
        is_dir(dirname($abs)) || @mkdir(dirname($abs), 0755, true);
        $f->move(dirname($abs), basename($abs));

        return ['path' => $rel, 'sec' => max(1, min((int) $c['voice_sec'] + 5, $sec))];
    }

    /* ---------------- جواب خودکار: سؤال‌های متداول ---------------- */

    public const STOP = ['از', 'به', 'در', 'با', 'که', 'را', 'رو', 'این', 'اون', 'ان', 'یه', 'یک', 'و', 'هم', 'برای', 'واسه', 'من', 'شما', 'ما', 'هست', 'است', 'اس', 'میشه', 'میشود', 'می', 'چه', 'چی', 'ایا', 'سلام', 'لطفا', 'ممنون', 'مرسی', 'خسته', 'نباشید', 'وقت', 'بخیر', 'ببخشید', 'یا', 'تا', 'اگه', 'اگر', 'دارید', 'دارین', 'داره', 'دارم', 'باید', 'بگید', 'بگین', 'بفرمایید', 'خب', 'خوب'];

    /** یکسان‌سازی متن فارسی (ی/ک عربی، اعداد، اعراب، نیم‌فاصله، حروف کشیده) */
    public static function norm(string $t): string
    {
        $t = mb_strtolower(trim($t));
        $t = strtr($t, ['ي' => 'ی', 'ى' => 'ی', 'ك' => 'ک', 'ة' => 'ه', 'ۀ' => 'ه', 'أ' => 'ا', 'إ' => 'ا', 'آ' => 'ا', 'ؤ' => 'و', "\u{200C}" => ' ', "\u{200D}" => '', 'ـ' => '']);
        $t = en_digits($t);
        $t = preg_replace('/[\x{064B}-\x{065F}\x{0670}]/u', '', $t);
        $t = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $t);
        $t = preg_replace('/(\p{L})\1{2,}/u', '$1', $t); // چقدددر ← چقدر

        return trim(preg_replace('/\s+/u', ' ', $t));
    }

    /** ریشه ساده کلمه (پسوندهای رایج گفتاری و جمع) */
    public static function stem(string $w): string
    {
        if (mb_strlen($w) <= 3) {
            return $w;
        }
        foreach (['هایی', 'های', 'ها', 'ترین', 'تر', 'تون', 'شون', 'مون', 'تان', 'شان', 'مان', 'یی', 'ای', 'ه', 'ی', 'و'] as $suf) {
            if (mb_strlen($w) - mb_strlen($suf) >= 3 && str_ends_with($w, $suf)) {
                return mb_substr($w, 0, mb_strlen($w) - mb_strlen($suf));
            }
        }

        return $w;
    }

    public static function tokens(string $t): array
    {
        $out = [];
        foreach (explode(' ', static::norm($t)) as $w) {
            if ($w === '' || in_array($w, static::STOP, true)) {
                continue;
            }
            // «میخواد» ← «خواد»، «نمیخوام» ← «خوام»
            $w = preg_replace('/^(نمی|می)(?=\p{L}{2,})/u', '', $w);
            $out[] = static::stem($w);
        }

        return $out;
    }

    protected static function near(string $a, string $b): bool
    {
        if ($a === $b) {
            return true;
        }
        $la = mb_strlen($a);
        // پسوند چسبیده: «خریدتون»، «سرمایه‌اش» ← «خرید»، «سرمایه»
        if ($la >= 3 && str_starts_with($b, $a) && mb_strlen($b) - $la <= 3) {
            return true;
        }
        if ($la < 4 || abs($la - mb_strlen($b)) > 1) {
            return false;
        }
        // یک حرف جابه‌جا/کم/زیاد (غلط تایپی)
        $map = [];
        $enc = function (string $s) use (&$map) {
            $o = '';
            foreach (preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY) as $ch) {
                $o .= $map[$ch] ??= chr(33 + count($map) % 200);
            }

            return $o;
        };

        return levenshtein($enc($a), $enc($b)) <= 1;
    }

    /** بهترین سؤال متداول برای این پیام (یا null) */
    public static function matchFaq(string $text): ?array
    {
        $c = static::cfg();
        if (empty($c['faq_on'])) {
            return null;
        }
        $msg = static::tokens($text);
        if (! $msg || count($msg) > 40) {
            return null;
        }
        $best = null;
        $bestScore = 0;
        foreach ($c['faq'] as $i => $f) {
            if (empty($f['on']) || trim((string) ($f['a'] ?? '')) === '') {
                continue;
            }
            $phrases = array_filter(array_map('trim', preg_split('/[\r\n،,]+/u', (string) ($f['keys'] ?? ''))));
            foreach ($phrases as $ph) {
                $pt = static::tokens($ph);
                if (! $pt) {
                    continue;
                }
                $hit = 0;
                foreach ($pt as $w) {
                    foreach ($msg as $m) {
                        if (static::near($w, $m)) {
                            $hit++;
                            break;
                        }
                    }
                }
                if ($hit < count($pt)) {
                    continue; // همه کلمات عبارت باید در پیام باشند
                }
                $score = array_sum(array_map('mb_strlen', $pt)) + count($pt) * 3;
                if ($score > $bestScore) {
                    $bestScore = $score;
                    $best = ['i' => $i, 'q' => (string) ($f['q'] ?? ''), 'a' => (string) $f['a']];
                }
            }
        }

        return $bestScore >= 5 ? $best : null;
    }

    /* ---------------- جواب خودکار: هوش مصنوعی ---------------- */

    public static function aiReady(): bool
    {
        $a = static::cfg()['ai'];

        return ! empty($a['on']) && trim((string) $a['key']) !== '' && trim((string) $a['url']) !== '' && trim((string) $a['model']) !== '';
    }

    /** پاسخ هوش مصنوعی فقط از روی اطلاعات فروشگاه؛ null یعنی «به همکار بسپار» */
    public static function aiReply(LiveChat $c, string $text): ?string
    {
        $cfg = static::cfg();
        $a = $cfg['ai'];
        if (! static::aiReady() || $c->ai_count >= max(1, (int) $a['per_chat'])) {
            return null;
        }
        $dayKey = 'live.ai.'.date('Ymd');
        if ((int) Cache::get($dayKey, 0) >= max(1, (int) $a['per_day'])) {
            return null;
        }
        $ctx = ['نام فروشگاه: '.store_name()];
        foreach (['about' => 'درباره فروشگاه', 'phone' => 'تلفن', 'mobile' => 'موبایل', 'address' => 'آدرس', 'work_hours' => 'ساعت کاری'] as $k => $l) {
            if ($v = trim((string) setting($k))) {
                $ctx[] = $l.': '.$v;
            }
        }
        if (trim((string) $a['about']) !== '') {
            $ctx[] = "اطلاعات و قوانین فروش:\n".trim((string) $a['about']);
        }
        $faq = [];
        foreach ($cfg['faq'] as $f) {
            if (! empty($f['on']) && trim((string) ($f['a'] ?? '')) !== '') {
                $faq[] = '- '.($f['q'] ?? '').': '.$f['a'];
            }
        }
        if ($faq) {
            $ctx[] = "سؤال‌های متداول:\n".implode("\n", $faq);
        }
        // کالای همین صفحه + کالاهای مرتبط با پرسش
        $prods = collect();
        $page = (array) $c->page;
        $vis = static::visitor($c->vid);
        if ($vis && ($vis['p']['k'] ?? '') === 'product') {
            $page = $vis['p'];
        }
        if (($page['k'] ?? '') === 'product' && ! empty($page['i'])) {
            $prods = $prods->merge(\App\Models\Product::query()->whereKey((int) $page['i'])->get());
        }
        try {
            $words = array_slice(array_filter(static::tokens($text), fn ($w) => mb_strlen($w) >= 3), 0, 4);
            if ($words) {
                $q = \App\Models\Product::query()->where('is_active', true)->where(function ($w) use ($words) {
                    foreach ($words as $x) {
                        $w->orWhere('name', 'like', '%'.$x.'%');
                    }
                });
                $prods = $prods->merge($q->limit(6)->get());
            }
        } catch (Throwable) {
        }
        if ($prods->isNotEmpty()) {
            $lines = $prods->unique('id')->take(7)->map(fn (\App\Models\Product $p) => '- '.$p->name.' | قیمت هر عدد: '.number_format((int) $p->price).' تومان | تعداد در کارتن: '.(int) $p->per_carton
                .' | '.($p->isAvailable() ? 'موجود' : 'ناموجود').' | لینک: '.$p->url())->all();
            $ctx[] = (($page['k'] ?? '') === 'product' ? "کالایی که مشتری الان می‌بیند و کالاهای مرتبط:\n" : "کالاهای مرتبط:\n").implode("\n", $lines);
        }
        $sys = 'تو مشاور فروش آنلاین «'.store_name().'» هستی (فروش عمده و کارتنی به مغازه‌داران). '
            .'کوتاه، مودبانه و فارسی جواب بده (حداکثر ۳ جمله). فقط از اطلاعات زیر استفاده کن و هرگز قیمت، شرط یا موجودی از خودت نساز. '
            .'اگر جواب در اطلاعات نیست، یا مشتری می‌خواهد سفارش ثبت کند، تخفیف بگیرد، شکایت دارد یا با آدم صحبت کند، فقط بنویس: [HUMAN]'
            ."\n\n".implode("\n\n", $ctx);
        $hist = $c->messages()->latest('id')->limit(10)->get()->reverse()
            ->filter(fn (LiveMessage $m) => ($m->kind ?: 'text') === 'text')
            ->map(fn (LiveMessage $m) => ['role' => $m->side === 'v' ? 'user' : 'assistant', 'content' => mb_substr($m->body, 0, 800)])->values()->all();
        try {
            $res = \Illuminate\Support\Facades\Http::withToken(trim((string) $a['key']))->acceptJson()->timeout(25)
                ->post(rtrim(trim((string) $a['url']), '/').'/chat/completions', [
                    'model' => trim((string) $a['model']), 'temperature' => 0.2, 'max_tokens' => 350,
                    'messages' => array_merge([['role' => 'system', 'content' => $sys]], $hist),
                ]);
            if (! $res->ok()) {
                Cache::put('live.ai.err', 'HTTP '.$res->status().': '.mb_substr((string) $res->body(), 0, 200), 86400);

                return null;
            }
            $out = trim((string) data_get($res->json(), 'choices.0.message.content'));
        } catch (Throwable $e) {
            Cache::put('live.ai.err', mb_substr($e->getMessage(), 0, 200), 86400);

            return null;
        }
        Cache::forget('live.ai.err');
        Cache::put($dayKey, (int) Cache::get($dayKey, 0) + 1, 86400 * 2);
        $c->increment('ai_count');
        if ($out === '' || str_contains($out, '[HUMAN]')) {
            return null;
        }

        return mb_substr($out, 0, 1200);
    }


    /** پیکربندی که در صفحه سایت (برای اسکریپت پیام هوشمند) گذاشته می‌شود */
    public static function front(array $page): ?array
    {
        try {
            return static::frontCfg($page);
        } catch (Throwable $e) {
            report($e);

            return null; // هر خطایی در گفتگوی زنده نباید صفحه سایت را از کار بیندازد
        }
    }

    protected static function frontCfg(array $page): ?array
    {
        try {
            $c = static::cfg();
        } catch (Throwable) {
            return null;
        }
        if (empty($c['enabled'])) {
            return null;
        }
        $u = auth()->user();
        if ($u && $u->isStaffLike() && ! request()->boolean('livetest')) {
            return null; // همکاران فروشگاه شمرده نمی‌شوند
        }
        $rules = [];
        foreach ($c['rules'] as $k => $r) {
            if (! empty($r['on']) && trim((string) $r['text']) !== '') {
                $rules[$k] = array_filter(['sec' => (int) ($r['sec'] ?? 0), 'times' => (int) ($r['times'] ?? 0), 'views' => (int) ($r['views'] ?? 0), 'text' => (string) $r['text']], fn ($v) => $v !== 0);
            }
        }
        $bale = trim((string) $c['bale']);
        if ($bale !== '' && ! str_starts_with($bale, 'http')) {
            $bale = 'https://ble.ir/'.ltrim($bale, '@');
        }

        return [
            'ping' => url('live.php'), 'send' => route('live.send'), 'msgs' => route('live.msgs'), 'contact' => route('live.contact'), 'act' => route('live.act'),
            'voice' => (bool) $c['voice'] ? max(10, min(600, (int) $c['voice_sec'])) : 0,
            'auto' => (bool) $c['auto'] && $rules ? $rules : null,
            'reply' => $c['reply'], 'bale' => $bale ?: null,
            'when' => $c['when'], 'hours' => $c['when'] === 'hours' ? [$c['from'], $c['to'], (bool) $c['friday']] : null,
            'agent' => (string) $c['agent'], 'av' => $c['avatar'] ? (thumb((string) $c['avatar'], 160) ?: route('pwa.icon', 192)) : route('pwa.icon', 192),
            'max' => max(1, (int) $c['max_day']), 'gap' => max(30, (int) $c['gap']), 'mobile' => (bool) $c['mobile'],
            'phone' => (bool) $c['ask_phone'] && ! $u, 'offline' => (string) $c['offline_text'], 'store' => store_name(),
            'u' => $u ? ['i' => $u->id, 's' => static::sign($u->id), 'n' => Str::before(trim((string) $u->name), ' ')] : null,
            'page' => $page,
        ];
    }

    /** صفحه فعلی برای پیام هوشمند (نوع، شناسه، عنوان) از روی داده‌های همان صفحه */
    public static function pageFrom(array $vars): array
    {
        $r = request();
        $p = ['k' => 'other', 't' => ''];
        try {
            if (($vars['product'] ?? null) instanceof \App\Models\Product && $r->routeIs('product', 'product.legacy')) {
                $x = $vars['product'];
                $p = ['k' => 'product', 'i' => $x->id, 't' => $x->name, 'c' => $x->category?->name, 'ci' => $x->category_id, 'im' => $x->image ? thumb($x->image, 160) : null, 'code' => $x->sku ?: $x->barcode];
            } elseif ($r->routeIs('shop', 'category', 'category.legacy')) {
                $term = trim((string) ($vars['term'] ?? ''));
                $cat = $vars['category'] ?? null;
                $n = isset($vars['products']) && method_exists($vars['products'], 'total') ? $vars['products']->total() : null;
                $orig = trim((string) $r->query('q', '')) ?: $term;
                if (str_contains((string) ($vars['searchNote'] ?? ''), 'نزدیک‌ترین')) {
                    $n = 0; // فقط کالاهای نزدیک پیدا شده ← در آمار «جستجوی بی‌نتیجه»
                }
                if ($term !== '') {
                    $p = ['k' => 'search', 't' => $orig, 'q' => $orig, 'n' => $n];
                } elseif ($cat) {
                    $p = ['k' => 'category', 'i' => $cat->id, 't' => $cat->name];
                } else {
                    $p = ['k' => 'shop', 't' => 'همه محصولات'];
                }
            } elseif ($r->routeIs('cart')) {
                $p = ['k' => 'cart', 't' => 'سبد خرید'];
            } elseif ($r->routeIs('checkout', 'checkout.*')) {
                $p = ['k' => 'checkout', 't' => 'تکمیل خرید'];
            } elseif ($r->routeIs('home')) {
                $p = ['k' => 'home', 't' => 'صفحه اصلی'];
            } elseif ($r->routeIs('login', 'login.*', 'register', 'otp.*')) {
                $p = ['k' => 'login', 't' => 'ورود / ثبت‌نام'];
            } elseif ($r->routeIs('account', 'order.*', 'chats')) {
                $p = ['k' => 'account', 't' => 'حساب کاربری'];
            }
        } catch (Throwable) {
        }

        return $p;
    }
}
