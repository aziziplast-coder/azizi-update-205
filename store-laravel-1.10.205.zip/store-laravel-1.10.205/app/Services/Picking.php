<?php

namespace App\Services;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderReplacement;
use App\Models\PickTask;
use App\Models\Product;
use App\Models\User;
use App\Support\Slips;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Throwable;

/**
 * گردش کار انبار:
 *  ارجاع به انبار ← حواله در کارتابل هر انباردار ← جمع‌آوری (تیک / ضربدر / کسری / انتقال)
 *  ← «جمع شد» همه انباردارها ← ارجاع به مسئول پیگیری و نمایش به مشتری
 *  ← (اختیاری) انتخاب جایگزین توسط مشتری تا مهلت ← تأیید مسئول پیگیری ← حواله مرحله بعد در کارتابل.
 */
class Picking
{
    /* ---------------- دسترسی ---------------- */

    /** مدیر/کارمندِ سفارش‌ها همه حواله‌ها را می‌بیند؛ انباردار فقط حواله‌های خودش */
    public static function seesAll(User $u): bool
    {
        return ! $u->isKeeper() && $u->hasPerm('orders');
    }

    public static function canUse(User $u): bool
    {
        // روال کاغذی: جمع‌کننده‌های انبارهای سرپرست‌دار اپ ندارند
        if ($u->isPicker() && static::paper()) {
            return false;
        }

        return $u->is_active && ($u->isKeeper() || $u->hasPerm('orders'));
    }

    /** انبارهای سرپرست‌دار با فاکتور کاغذی جمع می‌شوند (جمع‌کننده اپ ندارد؛ سرپرست ثبت می‌کند) */
    public static function paper(): bool
    {
        return (bool) setting('pick_paper', true);
    }

    /** بررسی رومیزی (کامپیوتری) پس از جمع‌آوری — دسترسی */
    public static function canDesk(User $u): bool
    {
        return $u->is_active && ($u->hasPerm('desk_check') || $u->isAdmin());
    }

    /** دیدن حواله: مدیر، صاحب حواله (انباردار/سرپرست) یا جمع‌کننده‌ای که حواله دست اوست */
    public static function canAccess(User $u, PickTask $t): bool
    {
        return static::seesAll($u) || (int) $t->keeper_id === (int) $u->id || ((int) $t->picker_id === (int) $u->id && $t->picker_id);
    }

    /**
     * ثبت تیک/ضربدر: در حواله سرپرست‌دار فقط جمع‌کننده (یا سرپرستی که خودش برداشته) در مرحله جمع‌آوری؛
     * سرپرست فقط مشاهده می‌کند.
     */
    public static function canPick(User $u, PickTask $t): bool
    {
        if ($t->isDone()) {
            return false;
        }
        if ($t->stage === null) {
            return static::canAccess($u, $t);
        }

        return $t->stage === 'picking' && ((int) $t->picker_id === (int) $u->id || static::seesAll($u));
    }

    public static function tasksQuery(User $u)
    {
        $q = PickTask::query()->with(['order.assignee:id,name,mobile', 'keeper', 'picker'])->whereHas('order')
            ->where(fn ($w) => $w->whereNull('stage')->orWhere('stage', '!=', 'hold')); // انتقال منتظر پایان حواله مبدأ
        if (static::seesAll($u)) {
            return $q;
        }

        return $u->isPicker() ? $q->where('picker_id', $u->id) : $q->where(fn ($w) => $w->where('keeper_id', $u->id)->orWhere('picker_id', $u->id));
    }

    /** انباردارهایی که می‌توان کالا را برایشان فرستاد */
    public static function keepers(): Collection
    {
        return User::query()->where('is_active', true)->where('role', 'keeper')->where(fn ($q) => $q->whereNull('pick_role')->orWhereNotIn('pick_role', \App\Services\Walkin::ROLES))->orderBy('name')->get();
    }

    /* ---------------- ارجاع به انبار ---------------- */

    /**
     * ارجاع اقلامِ هنوز ارجاع‌نشده سفارش به انبار (هر انباردار یک حواله).
     *
     * @return int تعداد حواله‌های ساخته‌شده
     */
    /**
     * انبار هر قلم از روی انبار فعلی کالا به‌روز می‌شود (عمده: انبار عمده، تکی: انبار خرده).
     * سفارش‌هایی که پیش از تعریف انبار کالاها (مثلاً پیش از دریافت شماره انبار از JSON) ثبت شده‌اند
     * در غیر این صورت «بدون انبار» می‌مانند. فقط اقلامی که هنوز در انبار بررسی نشده‌اند تغییر می‌کنند.
     */
    public static function syncWarehouses(Order $order, bool $onlyUnreferred = true): int
    {
        $items = $order->items()->with('product:id,warehouse_id,retail_warehouse_id')->whereNull('pick_status')
            ->when($onlyUnreferred, fn ($q) => $q->whereNull('pick_task_id'))->get();
        $n = 0;
        foreach ($items as $it) {
            $wid = $it->product?->warehouseFor((string) $it->mode);
            if ($wid && (int) $wid !== (int) $it->warehouse_id) {
                $it->forceFill(['warehouse_id' => $wid])->save();
                $n++;
            }
        }
        if ($n) {
            $order->unsetRelation('items');
        }

        return $n;
    }

    /**
     * تقسیم دوباره حواله‌های بازِ این مرحله بین انباردارها (پس از اصلاح انبار کالاها یا انباردارها).
     * وضعیت اقلامی که بررسی شده‌اند (تیک، ضربدر، تعداد) حفظ می‌شود و فقط حواله‌شان عوض می‌شود.
     */
    public function resplit(Order $order): int
    {
        $round = (int) $order->pick_round;
        $tasks = PickTask::query()->where('order_id', $order->id)->where('round', $round)->where('status', '!=', 'done')->get();
        if ($tasks->isEmpty()) {
            throw ValidationException::withMessages(['refer' => 'حواله بازی برای تقسیم دوباره وجود ندارد.']);
        }
        $items = OrderItem::query()->with('product:id,warehouse_id,retail_warehouse_id')->whereIn('pick_task_id', $tasks->pluck('id'))->get();
        foreach ($items as $it) {
            $wid = $it->product?->warehouseFor((string) $it->mode);
            if ($wid && (int) $wid !== (int) $it->warehouse_id) {
                $it->forceFill(['warehouse_id' => $wid])->save();
            }
        }
        $made = 0;
        DB::transaction(function () use ($order, $tasks, $items, $round, &$made) {
            $reused = [];
            $order->setRelation('items', $items);
            $groups = Slips::groups($order);
            foreach ($groups as $g) {
                $keeperId = $g['key'][0] === 'k' ? (int) substr($g['key'], 1) : null;
                $mine = $items->filter(fn ($it) => in_array((int) $it->warehouse_id, $g['wids'], true));
                if ($mine->isEmpty()) {
                    continue;
                }
                // اگر همین انباردار قبلاً حواله‌ای داشت، همان حفظ می‌شود (تاریخ دیدن/شروع)
                $old = $tasks->first(fn ($t) => (int) $t->keeper_id === (int) $keeperId && ! isset($reused[$t->id]) && $t->stage !== 'hold'); // انتقالیِ منتظر، دوباره تقسیم می‌شود
                if ($old) {
                    $reused[$old->id] = true;
                    $task = $old;
                } else {
                    $started = $mine->contains(fn ($it) => $it->pick_status !== null);
                    $task = PickTask::query()->create(['order_id' => $order->id, 'keeper_id' => $keeperId, 'round' => $round,
                        'status' => $started ? 'saved' : 'open', 'started_at' => $started ? now() : null]);
                }
                OrderItem::query()->whereIn('id', $mine->pluck('id'))->update(['pick_task_id' => $task->id]);
                $made++;
            }
            foreach ($tasks as $t) {
                isset($reused[$t->id]) ? $t->touch() : $t->delete();
            }
            $order->unsetRelation('items');
            $order->log('تقسیم دوباره حواله‌ها بین انباردارها — '.fa($made).' حواله');
        });
        $this->notifyKeepers($order->fresh());

        return $made;
    }

    public function refer(Order $order, array $opts = []): int
    {
        static::syncWarehouses($order);
        $order->load('items');
        $items = $order->items->filter(fn (OrderItem $i) => ! $i->pick_task_id && (int) $i->units > 0);
        if ($items->isEmpty()) {
            throw ValidationException::withMessages(['refer' => 'کالای تازه‌ای برای ارجاع به انبار نیست.']);
        }
        $made = 0;
        DB::transaction(function () use ($order, $items, $opts, &$made) {
            $round = ! empty($opts['round']) ? max((int) $opts['round'], (int) $order->pick_round) : (int) $order->pick_round + 1;
            $groups = Slips::groups($order, $items->pluck('warehouse_id')->map(fn ($v) => (int) $v)->unique()->values()->all());
            foreach ($groups as $g) {
                $keeperId = $g['key'][0] === 'k' ? (int) substr($g['key'], 1) : null;
                $task = PickTask::query()->create(['order_id' => $order->id, 'keeper_id' => $keeperId, 'round' => $round, 'status' => 'open']);
                $made++;
                foreach ($items as $it) {
                    if (in_array((int) $it->warehouse_id, $g['wids'], true)) {
                        $it->forceFill(['pick_task_id' => $task->id, 'round' => $round, 'ordered_units' => $it->ordered_units ?? $it->units, 'pick_status' => null, 'picked_units' => null])->save();
                    }
                }
            }
            if (\App\Support\DbSchema::hasColumn('orders', 'done_rounds') && $order->done_rounds === null) {
                // سفارش قدیمی: مراحل پیشین نهایی‌شده فرض می‌شوند
                $order->done_rounds = implode(',', range(1, max(1, $round - 1)) === [1] && $round <= 1 ? [] : range(1, $round - 1));
            }
            $order->pick_round = $round;
            $order->fulfil_status = 'picking';
            $order->referred_at = now();
            $order->referred_by = auth()->id();
            if (! empty($opts['deposit'])) {
                $order->deposit_amount = (int) $opts['deposit'];
            }
            if (! empty($opts['deposit_ref'])) {
                $order->deposit_ref = mb_substr((string) $opts['deposit_ref'], 0, 120);
            }
            $order->saveQuietly();
            if ($order->status === 'on_hold') {
                $order->setStatus('processing', 'ارجاع به انبار', ! empty($opts['notify']));
            }
            $order->log(($round > 1 ? 'ارجاع جایگزین‌ها به انبار (مرحله '.fa($round).')' : 'ارجاع به انبار')
                .' — '.fa($made).' حواله'.(! empty($opts['deposit']) ? ' — بیعانه '.money((int) $opts['deposit']).' تومان'.(! empty($opts['deposit_ref']) ? ' (پیگیری '.$opts['deposit_ref'].')' : '') : '')
                .(! empty($opts['note']) ? ' — '.$opts['note'] : ''));
        });
        $this->notifyKeepers($order->fresh());

        return $made;
    }

    /**
     * ارجاع خودکار به انبار — فقط بار اول (سفارشی که هنوز به انبار نرفته).
     * پس از تأیید بیعانه یا رفتن سفارش از «در انتظار بررسی» به «در حال آماده‌سازی» صدا زده می‌شود.
     * اگر ارجاع ممکن نباشد علت را در تاریخچه سفارش می‌نویسد تا مدیر دستی ارجاع دهد.
     */
    /** سیستم انبار (ارجاع سفارش به کارتابل انباردارها) روشن است؟ — «تنظیمات ← راه‌اندازی مرحله‌ای» */
    public static function enabled(): bool
    {
        return (bool) setting('module_picking', true);
    }

    public static function autoRefer(Order $o, string $why, array $opts = []): bool
    {
        if (! static::enabled()) {
            return false;
        }
        if ((int) $o->pick_round > 0 || $o->review_status === 'pending' || ! in_array($o->status, ['on_hold', 'processing'], true)) {
            return false;
        }
        if (! $o->items()->whereNull('pick_task_id')->where('units', '>', 0)->exists()) {
            return false;
        }
        try {
            app(static::class)->refer($o, $opts + ['note' => $why.' (ارجاع خودکار)']);

            return true;
        } catch (\Throwable $e) {
            $msg = $e instanceof ValidationException ? collect($e->errors())->flatten()->first() : $e->getMessage();
            $o->log('⚠️ ارجاع خودکار به انبار انجام نشد: '.mb_substr((string) $msg, 0, 200).' — از دکمه «ارجاع به انبار» دستی ارجاع دهید.');
            report($e);

            return false;
        }
    }

    protected function notifyKeepers(Order $order): void
    {
        $ids = PickTask::query()->where('order_id', $order->id)->where('status', '!=', 'done')->whereNotNull('keeper_id')->pluck('keeper_id')->unique()->all();
        if (! $ids) {
            return;
        }
        app(WebPush::class)->toUsers($ids, [
            'title' => 'حواله جدید — سفارش '.fa($order->number),
            'body' => $order->customer_name.($order->city ? ' — '.$order->city : ''),
            'url' => url('/keeper'),
            'tag' => 'pick-'.$order->id,
        ]);
    }

    /* ---------------- کار انباردار ---------------- */

    /**
     * ثبت وضعیت یک قلم: ok (کامل) | missing (ناموجود) | qty (تعداد جمع‌شده) | reset
     */
    public function mark(PickTask $task, OrderItem $item, string $action, ?int $units = null, ?string $note = null): OrderItem
    {
        abort_unless((int) $item->pick_task_id === (int) $task->id, 404);
        if ($task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این حواله «جمع شد» زده شده و بسته است.']);
        }
        $want = $item->orderedUnits();
        switch ($action) {
            case 'ok':
                $item->picked_units = $want;
                $item->pick_status = 'ok';
                break;
            case 'missing':
                $item->picked_units = 0;
                $item->pick_status = 'missing';
                break;
            case 'qty':
                // بیشتر از سفارش هم مجاز است (مشتری ۵ خواسته، کارتن ۶تایی ← ۶ جمع شد)؛ مبلغ فاکتور با پایان جمع‌آوری اصلاح می‌شود
                $u = max(0, min($item->overCap(), (int) $units));
                $item->picked_units = $u;
                $item->pick_status = $u >= $want ? 'ok' : ($u === 0 ? 'missing' : 'short');
                break;
            case 'reset':
                $item->picked_units = null;
                $item->pick_status = null;
                break;
            default:
                abort(422);
        }
        if ($note !== null) {
            $item->pick_note = mb_substr(trim($note), 0, 190) ?: null;
        }
        $item->picked_at = $item->pick_status ? now() : null;
        $item->picked_by = $item->pick_status ? auth()->id() : null;
        $item->save();
        if (! $task->started_at || $task->status === 'saved') {
            $task->forceFill(['started_at' => $task->started_at ?? now(), 'status' => 'open'])->save();
        }

        return $item;
    }

    /** انتقال یک قلم به حواله انباردار دیگر (در همان سفارش و مرحله) */
    public function move(PickTask $task, OrderItem $item, int $keeperId): PickTask
    {
        abort_unless((int) $item->pick_task_id === (int) $task->id, 404);
        if ($task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این حواله بسته است.']);
        }
        $to = User::query()->where('role', 'keeper')->where('is_active', true)->findOrFail($keeperId);
        abort_if((int) $to->id === (int) $task->keeper_id, 422, 'همین انباردار است.');

        $dest = DB::transaction(function () use ($task, $item, $to) {
            $order = $task->order;
            // کالا از انبار مقصد برداشته می‌شود ← انبار ردیف هم انبار مقصد می‌شود (اکسل هلو و برگه همان انباردار)
            $wid = $to->warehouses()->get()->sortBy(fn ($w) => Slips::whKey($w, $w->id))->first()?->id;
            $fromWh = $item->warehouse?->label();
            if (static::hasHold()) {
                // تا «پایان حواله» مبدأ نگه داشته می‌شود؛ بعد همه اقلام منتقل‌شده به یک نفر، یکجا یک حواله می‌شوند
                $dest = PickTask::query()->where('order_id', $task->order_id)->where('keeper_id', $to->id)->where('stage', 'hold')
                    ->where('hold_for', $task->id)->where('status', '!=', 'done')->first()
                    ?? tap(new PickTask(['order_id' => $task->order_id, 'keeper_id' => $to->id, 'round' => $task->round, 'status' => 'open']), function (PickTask $p) use ($task) {
                        $p->forceFill(['stage' => 'hold', 'hold_for' => $task->id])->save();
                    });
            } else {
                $dest = PickTask::query()->where('order_id', $task->order_id)->where('round', $task->round)->where('keeper_id', $to->id)
                    ->where('status', '!=', 'done')->where(fn ($q) => $q->whereNull('stage')->orWhereIn('stage', ['new', 'picking']))->orderByDesc('id')->first()
                    ?? PickTask::query()->create(['order_id' => $task->order_id, 'keeper_id' => $to->id, 'round' => $task->round, 'status' => 'open']);
            }
            $item->forceFill(['pick_task_id' => $dest->id, 'pick_status' => null, 'picked_units' => null, 'picked_at' => null, 'picked_by' => null]
                + ($wid ? ['warehouse_id' => $wid] : []))->save();
            $order->log('انتقال «'.$item->name.'» از '.($task->keeper?->displayName() ?? 'انبار بدون انباردار').($fromWh ? ' ('.$fromWh.')' : '').' به '.$to->displayName()
                .($dest->stage === 'hold' ? ' — بعد از پایان حواله مبدأ، یکجا ارسال می‌شود' : ''));
            if ($order->fulfil_status !== 'picking') {
                $order->forceFill(['fulfil_status' => 'picking'])->saveQuietly();
            }

            return $dest;
        });
        // همه اقلام حواله منتقل شد ← حواله مبدأ خالی است؛ انتقال‌ها همین الان می‌روند
        if (! $task->items()->exists()) {
            static::releaseHolds($task);
            $task->delete();
        } elseif ($dest->stage !== 'hold') {
            app(WebPush::class)->toUsers([$to->id], ['title' => 'کالای منتقل‌شده — سفارش '.fa($task->order->number), 'body' => $item->name, 'url' => url('/keeper/task/'.$dest->id), 'tag' => 'pick-'.$task->order_id]);
        }

        return $dest;
    }

    public static function hasHold(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('pick_tasks', 'hold_for');
    }

    /** اقلام منتقل‌شده از این حواله (منتظر پایان حواله) */
    public static function heldFrom(PickTask $task): Collection
    {
        if (! static::hasHold()) {
            return collect();
        }

        return PickTask::query()->with('keeper')->withCount('items')->where('stage', 'hold')->where('hold_for', $task->id)->where('status', '!=', 'done')->get();
    }

    /**
     * پایان حواله مبدأ: اقلام منتقل‌شده به هر انباردار یکجا یک حواله می‌شوند
     * (اگر برای همان نفر حواله «جدید/در حال جمع‌آوری» همین سفارش باز باشد، به همان اضافه می‌شود).
     */
    public static function releaseHolds(PickTask $task): void
    {
        foreach (static::heldFrom($task) as $h) {
            $order = $h->order;
            $n = (int) $h->items_count;
            $into = PickTask::query()->where('order_id', $h->order_id)->where('round', $h->round)->where('keeper_id', $h->keeper_id)->where('id', '!=', $h->id)
                ->where('status', '!=', 'done')->where(fn ($q) => $q->whereNull('stage')->orWhereIn('stage', ['new', 'picking']))->orderByDesc('id')->first();
            if ($into) {
                OrderItem::query()->where('pick_task_id', $h->id)->update(['pick_task_id' => $into->id]);
                if ($into->status === 'done' || $into->status === 'saved') {
                    $into->forceFill(['status' => 'open'])->save();
                }
                $h->delete();
                $dest = $into;
            } else {
                $sup = $h->keeper_id && User::query()->whereKey($h->keeper_id)->where('pick_role', 'supervisor')->exists();
                $h->forceFill(['stage' => $sup ? 'new' : null, 'hold_for' => null, 'seen_at' => null, 'created_at' => now()])->save();
                $dest = $h;
            }
            $order?->log('اقلام منتقل‌شده از حواله '.($task->keeper?->displayName() ?? '—').' یکجا برای '.($h->keeper?->displayName() ?? '—').' فرستاده شد ('.fa($n).' قلم)');
            $to = $dest->stage === 'picking' && $dest->picker_id ? $dest->picker_id : $dest->keeper_id;
            if ($to) {
                app(WebPush::class)->toUsers([$to], ['title' => 'کالای منتقل‌شده — سفارش '.fa($order?->number), 'body' => fa($n).' قلم از '.($task->keeper?->displayName() ?? ''),
                    'url' => url('/keeper/task/'.$dest->id), 'tag' => 'pick-'.$h->order_id]);
            }
        }
    }

    /** انتقال‌هایی که حواله مبدأشان بسته/حذف شده ولی هنوز آزاد نشده‌اند (احتیاط) */
    public static function sweepHolds(): void
    {
        if (! static::hasHold()) {
            return;
        }
        foreach (PickTask::query()->where('stage', 'hold')->whereNotNull('hold_for')->where('status', '!=', 'done')->pluck('hold_for')->unique() as $src) {
            $t = PickTask::query()->find($src);
            if (! $t) {
                $t = new PickTask;
                $t->id = (int) $src;
            } elseif (! $t->isDone() && ! in_array($t->stage, ['review', 'desk'], true)) {
                continue;
            }
            static::releaseHolds($t);
        }
    }

    /** ذخیره موقت (برای ادامه بعدی) */
    public function save(PickTask $task): void
    {
        if (! $task->isDone()) {
            $task->forceFill(['status' => 'saved', 'saved_at' => now(), 'started_at' => $task->started_at ?? now()])->save();
        }
    }

    /**
     * «جمع شد»: اقلام بررسی‌نشده ناموجود حساب می‌شوند (با تأیید انباردار).
     *
     * @return bool آیا همه حواله‌های این مرحله تمام شد؟
     */
    public function complete(PickTask $task, bool $uncheckedMissing = false, ?string $bay = null): bool
    {
        if ($task->isDone()) {
            return false;
        }
        $bay = $bay !== null ? (mb_substr(trim(strip_tags($bay)), 0, 80) ?: null) : null;
        if ($task->stage === 'review') {
            throw ValidationException::withMessages(['task' => 'این حواله تحویل سرپرست شده و منتظر بررسی است.']);
        }
        if ($task->stage !== null && ! $bay) {
            throw ValidationException::withMessages(['bay' => 'جایگاه بار را بنویسید (مثلاً «سکوی ۳»).']);
        }
        $left = $task->items()->whereNull('pick_status')->get();
        if ($left->isNotEmpty() && ! $uncheckedMissing) {
            throw ValidationException::withMessages(['left' => fa($left->count()).' قلم هنوز بررسی نشده است.']);
        }
        // اقلامی که از این حواله به انباردار دیگری منتقل شده، حالا یکجا (یک حواله) برای او می‌رود
        static::releaseHolds($task);
        if ($task->stage !== null) {
            // حواله سرپرست‌دار: تحویل برای بررسی بار
            DB::transaction(function () use ($task, $left, $bay) {
                foreach ($left as $it) {
                    $it->forceFill(['pick_status' => 'missing', 'picked_units' => 0, 'picked_at' => now(), 'picked_by' => auth()->id()])->save();
                }
                $task->items()->update(['scanned_units' => null, 'manual_units' => null]);
                $task->forceFill(['stage' => 'review', 'picked_done_at' => now(), 'bay' => $bay, 'check_note' => null, 'started_at' => $task->started_at ?? now()])->save();
                [$ok, $short, $miss] = $this->counts($task->items()->get());
                $task->order->log('جمع‌آوری توسط '.($task->picker?->displayName() ?? '—').' تمام شد و در «'.$bay.'» برای بررسی '.($task->keeper?->displayName() ?? 'سرپرست').' گذاشته شد: '
                    .fa($ok).' کامل'.($short ? '، '.fa($short).' کسری' : '').($miss ? '، '.fa($miss).' ناموجود' : ''));
            });
            if ($task->keeper_id && (int) $task->keeper_id !== (int) $task->picker_id) {
                app(WebPush::class)->toUsers([$task->keeper_id], ['title' => 'بار آماده بررسی — سفارش '.fa($task->order->number),
                    'body' => ($task->picker?->displayName() ?? '').' — جایگاه: '.$bay, 'url' => url('/keeper/check/'.$task->id), 'tag' => 'check-'.$task->id]);
            }

            return false;
        }
        if (static::needsDesk($task)) {
            // انبار با بررسی رومیزی: بار روی میز دوباره شمرده/اسکن می‌شود
            $deskIds = [];
            $halls = [];
            $skip = false;
            DB::transaction(function () use ($task, $left, $bay, &$deskIds, &$halls, &$skip) {
                // قفل حواله: دوبار زدن «پایان حواله» (یا اینترنت کند و ارسال دوباره) بررسی تکراری نسازد
                $fresh = PickTask::query()->lockForUpdate()->find($task->id);
                if (! $fresh || $fresh->isDone() || $fresh->stage !== null) {
                    $skip = true;

                    return;
                }
                foreach ($left as $it) {
                    $it->forceFill(['pick_status' => 'missing', 'picked_units' => 0, 'picked_at' => now(), 'picked_by' => auth()->id()])->save();
                }
                $task->items()->update(['desk_units' => null] + (static::hasDeskAt() ? ['desk_at' => null] : []));
                // تقسیم بر اساس سالن بررسی (چند انبار یک سالن = یک بررسی). اگر برای همین سفارش و همین سالن
                // بررسی بازی هست (مثلاً انباردار دیگرِ همان سالن زودتر تمام کرده)، اقلام به همان بررسی اضافه می‌شود.
                $groups = $task->items()->get()->groupBy(fn ($i) => static::itemHall($i, $task) ?? '');
                $usedOrig = false;
                $base = ['picked_done_at' => now(), 'picker_id' => $task->picker_id ?? auth()->id(), 'bay' => $bay ?? $task->bay, 'started_at' => $task->started_at ?? now()];
                $newTask = fn () => PickTask::query()->create(['order_id' => $task->order_id, 'keeper_id' => $task->keeper_id, 'round' => $task->round, 'status' => 'open',
                    'picker_id' => $task->picker_id, 'started_at' => $task->started_at ?? now(), 'seen_at' => now()]);
                foreach ($groups as $hall => $its) {
                    if ($hall !== '') {
                        // بررسی باز همین سفارش و همین سالن (از هر مرحله‌ای، مثلاً کالای افزوده بعد از ویرایش سفارش)
                        $exist = PickTask::query()->where('order_id', $task->order_id)->where('stage', 'desk')
                            ->where('status', '!=', 'done')->where('id', '!=', $task->id)->get()
                            ->first(fn ($x) => static::taskHall($x) === $hall);
                        if ($exist) {
                            OrderItem::query()->whereIn('id', $its->pluck('id'))->update(['pick_task_id' => $exist->id]);
                            $exist->forceFill(['bay' => trim(implode('، ', array_unique(array_filter([$exist->bay, $bay ?? $task->bay]))), '، ') ?: null])->save();
                            $deskIds[] = $exist->id;
                            $halls[$hall] = $exist->id;

                            continue;
                        }
                    }
                    if (! $usedOrig) {
                        $t = $task;
                        $usedOrig = true;
                    } else {
                        $t = $newTask();
                    }
                    OrderItem::query()->whereIn('id', $its->pluck('id'))->update(['pick_task_id' => $t->id]);
                    if ($hall !== '') {
                        $t->forceFill($base + ['stage' => 'desk', 'status' => 'open'] + (static::hasTaskHall() ? ['hall' => $hall] : []))->save();
                        $deskIds[] = $t->id;
                        $halls[$hall] = $t->id;
                    } else {
                        $t->forceFill($base + ['stage' => null, 'status' => 'done', 'done_at' => now(), 'done_by' => auth()->id()])->save();
                    }
                }
                if (! $usedOrig) {
                    // همه اقلام به بررسی باز دیگری رفت: این حواله خالی است
                    $task->forceFill($base + ['stage' => null, 'status' => 'done', 'done_at' => now(), 'done_by' => auth()->id()])->save();
                    if (! $task->items()->exists()) {
                        $task->delete();
                    }
                }
                [$ok, $short, $miss] = $this->counts($task->order->items()->whereIn('pick_task_id', PickTask::query()->where('order_id', $task->order_id)->where('round', $task->round)->pluck('id'))->get());
                $task->order->log('جمع‌آوری حواله '.($task->keeper?->displayName() ?? 'بدون انباردار').' تمام شد و برای بررسی رومیزی رفت ('
                    .implode('، ', array_map(fn ($h) => static::hallName($h), array_keys($halls))).'): '
                    .fa($ok).' کامل'.($short ? '، '.fa($short).' کسری' : '').($miss ? '، '.fa($miss).' ناموجود' : ''));
            });
            if ($skip) {
                return false;
            }
            try {
                $staff = User::query()->where('is_active', true)->whereIn('role', ['admin', 'staff'])->get()->filter(fn (User $u) => $u->hasPerm('desk_check'));
                foreach ($halls as $hall => $tid) {
                    // فقط بررسی‌کنندگان همان سالن (اگر برای سالن کسی تعیین نشده: همه)
                    $ids = $staff->filter(fn (User $u) => static::canHall($u, $hall))->pluck('id')->all();
                    if ($ids) {
                        app(WebPush::class)->toUsers($ids, ['title' => 'بار آماده بررسی — '.static::hallName($hall).' — سفارش '.fa($task->order->number),
                            'body' => ($task->keeper?->displayName() ?? '').' — '.$task->order->customer_name, 'url' => url('/admin/desk-check?t='.$tid), 'tag' => 'desk-'.$tid]);
                    }
                }
            } catch (Throwable $e) {
                report($e);
            }

            return false;
        }
        $all = DB::transaction(function () use ($task, $left, $bay) {
            foreach ($left as $it) {
                $it->forceFill(['pick_status' => 'missing', 'picked_units' => 0, 'picked_at' => now(), 'picked_by' => auth()->id()])->save();
            }
            $task->forceFill(['status' => 'done', 'done_at' => now(), 'done_by' => auth()->id(), 'started_at' => $task->started_at ?? now(), 'bay' => $bay ?? $task->bay])->save();
            $order = $task->order;
            [$ok, $short, $miss] = $this->counts($task->items()->get());
            $order->log('جمع‌آوری حواله '.($task->keeper?->displayName() ?? 'بدون انباردار').': '.fa($ok).' کامل'.($short ? '، '.fa($short).' کسری' : '').($miss ? '، '.fa($miss).' ناموجود' : '').($bay ? ' — جایگاه بار: '.$bay : ''));

            return ! static::roundOpen((int) $task->order_id, (int) $task->round);
        });
        if ($all) {
            $this->finishAll($task->order()->first(), $task);
        }

        return $all;
    }

    /* ---------------- سرپرست: تقسیم و بررسی بار ---------------- */

    /** سپردن فاکتور به جمع‌کننده (یا خود سرپرست). جابه‌جایی بین جمع‌کننده‌ها وضعیت اقلام را حفظ می‌کند. */
    public function assign(PickTask $task, int $pickerId, User $by): PickTask
    {
        if ($task->isDone() || ! in_array($task->stage, ['new', 'picking'], true)) {
            throw ValidationException::withMessages(['task' => 'این فاکتور قابل سپردن نیست (در حال بررسی یا بسته است).']);
        }
        $sup = $task->keeper;
        $picker = User::query()->where('is_active', true)->findOrFail($pickerId);
        $ok = $sup && ((int) $picker->id === (int) $sup->id || ((int) $picker->supervisor_id === (int) $sup->id && $picker->isPicker()));
        if (! $ok) {
            throw ValidationException::withMessages(['picker' => 'این شخص جمع‌کننده این سرپرست نیست.']);
        }
        $prev = $task->picker;
        $task->forceFill(['picker_id' => $picker->id, 'stage' => 'picking', 'assigned_at' => now(), 'seen_at' => null])->save();
        $task->order->log(($prev ? 'انتقال فاکتور از '.$prev->displayName().' به ' : (static::paper() ? 'فاکتور کاغذی تحویل سرپرست شد و به ' : 'سپردن فاکتور به ')).$picker->displayName()
            .(static::paper() && ! $prev ? ' داده شد' : '').' — '.$by->displayName());
        if ((int) $picker->id !== (int) $by->id && ! static::paper()) {
            app(WebPush::class)->toUsers([$picker->id], ['title' => 'فاکتور جدید برای جمع‌آوری — سفارش '.fa($task->order->number),
                'body' => $task->order->customer_name.($task->order->city ? ' — '.$task->order->city : ''), 'url' => url('/keeper/task/'.$task->id), 'tag' => 'pick-'.$task->order_id]);
        }

        return $task;
    }

    /** تقسیم خودکار همه فاکتورهای «جدید» سرپرست بین جمع‌کننده‌ها (کم‌کارترین اول، قدیمی‌ترین فاکتور اول) */
    public function autoAssign(User $sup): int
    {
        $pickers = $sup->pickers()->get();
        if ($pickers->isEmpty()) {
            throw ValidationException::withMessages(['picker' => 'هنوز جمع‌کننده‌ای برای شما تعریف نشده است (پنل ← کارمندان).']);
        }
        $load = PickTask::query()->where('stage', 'picking')->where('status', '!=', 'done')->whereIn('picker_id', $pickers->pluck('id'))
            ->selectRaw('picker_id, count(*) as n')->groupBy('picker_id')->pluck('n', 'picker_id')->all();
        foreach ($pickers as $p) {
            $load[$p->id] = (int) ($load[$p->id] ?? 0);
        }
        $tasks = PickTask::query()->with('order')->where('keeper_id', $sup->id)->where('stage', 'new')->where('status', '!=', 'done')
            ->join('orders', 'orders.id', '=', 'pick_tasks.order_id')->whereNotIn('orders.status', ['cancelled', 'failed'])
            ->orderBy('orders.created_at')->select('pick_tasks.*')->get();
        $n = 0;
        foreach ($tasks as $t) {
            asort($load);
            $pid = (int) array_key_first($load);
            $this->assign($t, $pid, $sup);
            $load[$pid]++;
            $n++;
        }

        return $n;
    }

    /**
     * روال کاغذی: جمع‌کننده فاکتور را برگرداند ← سرپرست «تحویل گرفتم» ← مرحله بررسی.
     * تا ثبت تغییر، همه اقلام «موجود طبق فاکتور» حساب می‌شوند.
     */
    public function received(PickTask $task, User $by): PickTask
    {
        if ($task->isDone() || $task->stage === 'review') {
            return $task;
        }
        if ($task->stage !== 'picking') {
            throw ValidationException::withMessages(['task' => 'این فاکتور هنوز به جمع‌کننده‌ای داده نشده؛ اول «تحویل به جمع‌کننده» را بزنید.']);
        }
        static::releaseHolds($task);
        DB::transaction(function () use ($task, $by) {
            $task->items()->update(['pick_status' => null, 'picked_units' => null, 'scanned_units' => null, 'manual_units' => null, 'picked_at' => null, 'picked_by' => null]);
            $task->forceFill(['stage' => 'review', 'picked_done_at' => now(), 'check_note' => null, 'started_at' => $task->started_at ?? $task->assigned_at ?? now()])->save();
            $task->order->log('فاکتور کاغذی از '.($task->picker?->displayName() ?? 'جمع‌کننده').' تحویل '.$by->displayName().' شد — شروع بررسی');
        });

        return $task;
    }

    /** پیدا کردن فاکتور سرپرست با شماره سفارش (برای «تحویل گرفتم» با تایپ شماره) */
    public static function findForSupervisor(User $sup, string $number): ?PickTask
    {
        $n = trim(en_digits($number));
        if ($n === '') {
            return null;
        }
        $orders = Order::query()->where(fn ($q) => $q->where('number', $n)->orWhere('number', setting('order_prefix', '').$n))->pluck('id');

        return PickTask::query()->whereIn('order_id', $orders)->where('status', '!=', 'done')
            ->when(! static::seesAll($sup), fn ($q) => $q->where('keeper_id', $sup->id))
            ->orderByRaw("CASE stage WHEN 'picking' THEN 0 WHEN 'review' THEN 1 ELSE 2 END")->orderByDesc('round')->first();
    }

    /* ---------------- بررسی رومیزی (انبار خرده‌ریز / لوکس) ---------------- */

    public static function hasDesk(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('warehouses', 'desk_check') && \App\Support\DbSchema::hasColumn('order_items', 'desk_units');
    }

    public static function hasDeskAt(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('order_items', 'desk_at');
    }

    /** زمان نخستین تأیید هر قلم در بررسی رومیزی (ترتیب خروجی هلو = ترتیب بررسی) */
    protected static function deskStamp(OrderItem $item): void
    {
        if (! static::hasDeskAt()) {
            return;
        }
        if ($item->desk_units === null) {
            $item->desk_at = null;
        } elseif (! $item->desk_at) {
            $item->desk_at = now();
        }
    }

    /**
     * سالن‌های بررسی رومیزی: هر سالن چند انبار دارد (مثلاً «سالن لوکس» = انبار ۶ عمده + ۱۰ خرده).
     * انباری که «بررسی رومیزی» دارد ولی در هیچ سالنی نیست، سالن جدای خودش را دارد.
     *
     * @return array<string, array{key:string,name:string,wids:int[]}>
     */
    public static function halls(): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        $out = [];
        $seen = [];
        foreach (static::hallsCfg() as $i => $h) {
            $wids = array_values(array_unique(array_filter(array_map('intval', (array) ($h['wids'] ?? [])))));
            $name = trim((string) ($h['name'] ?? ''));
            if (! $wids || $name === '') {
                continue;
            }
            $key = 'h'.$i;
            $out[$key] = ['key' => $key, 'name' => $name, 'wids' => $wids, 'users' => array_values(array_unique(array_filter(array_map('intval', (array) ($h['users'] ?? []))))),
                'keepers' => array_values(array_unique(array_filter(array_map('intval', (array) ($h['keepers'] ?? []))))),
                // scan = اسکن بارکد (لوکس) | count = شمارش و جستجوی نام با کیسه/کارتن (خرده‌ریز)
                'mode' => in_array($h['mode'] ?? '', ['scan', 'count'], true) ? $h['mode'] : (str_contains($name, 'خرده') ? 'count' : 'scan'),
                'pack_col' => array_key_exists('pack_col', (array) $h) ? (bool) $h['pack_col'] : true];
            foreach ($wids as $w) {
                $seen[$w] = true;
            }
        }
        if (static::hasDesk()) {
            foreach (\App\Models\Warehouse::query()->where('desk_check', true)->get() as $w) {
                if (! isset($seen[$w->id])) {
                    $out['w'.$w->id] = ['key' => 'w'.$w->id, 'name' => $w->label(), 'wids' => [(int) $w->id], 'users' => [], 'keepers' => [], 'mode' => 'scan', 'pack_col' => false];
                }
            }
        }

        return $cache = $out;
    }

    /**
     * تنظیم سالن‌ها؛ اگر هنوز ذخیره نشده، پیش‌فرض: «سالن لوکس» = انبار ۶ عمده + ۱۰ خرده، «سالن خرده‌ریز» = انبار ۷ عمده + ۷ خرده
     */
    public static function hallsCfg(): array
    {
        $cfg = setting('desk_halls');
        if (is_array($cfg)) {
            return array_values($cfg);
        }
        $find = fn (string $code, string $kind) => \App\Models\Warehouse::query()->where('code', $code)->where('kind', $kind)->value('id');
        $def = [
            ['name' => 'سالن لوکس', 'wids' => array_values(array_filter([$find('6', 'carton'), $find('10', 'retail')])), 'mode' => 'scan', 'pack_col' => false],
            ['name' => 'سالن خرده‌ریز', 'wids' => array_values(array_filter([$find('7', 'carton'), $find('7', 'retail')])), 'mode' => 'count', 'pack_col' => true],
        ];

        return array_values(array_filter($def, fn ($h) => $h['wids']));
    }

    /** سالن بررسی یک انبار (null = بدون بررسی رومیزی) */
    public static function hallOf(?int $wid): ?string
    {
        if (! $wid) {
            return null;
        }
        foreach (static::halls() as $k => $h) {
            if (in_array((int) $wid, $h['wids'], true)) {
                return $k;
            }
        }

        return null;
    }

    /**
     * سالن‌هایی که این همکار بررسی می‌کند: مدیر کل همه را می‌بیند؛ بقیه فقط سالن‌هایی که در «سالن‌های بررسی»
     * به آن‌ها سپرده شده (بدون سالن = بدون دسترسی؛ هیچ سالنی به سالن دیگر دسترسی ندارد).
     *
     * @return string[]|null  null = همه
     */
    public static function userHalls(User $u): ?array
    {
        if ($u->isAdmin()) {
            return null;
        }
        return array_keys(array_filter(static::halls(), fn ($h) => in_array((int) $u->id, $h['users'] ?? [], true)));
    }

    public static function canHall(User $u, ?string $hall): bool
    {
        $mine = static::userHalls($u);

        return $mine === null || ($hall !== null && in_array($hall, $mine, true));
    }

    /**
     * سالن یک انباردار: اگر در «سالن‌های بررسی» برای سالنی انتخاب شده همان؛ وگرنه اگر همه انبارهای او
     * (که سالن دارند) در یک سالن‌اند همان سالن. هرچه این انباردار جمع کند به بررسی همین سالن می‌رود.
     */
    public static function keeperHall(?int $userId): ?string
    {
        static $memo = [];
        if (! $userId) {
            return null;
        }
        if (array_key_exists($userId, $memo)) {
            return $memo[$userId];
        }
        foreach (static::halls() as $k => $h) {
            if (in_array($userId, $h['keepers'] ?? [], true)) {
                return $memo[$userId] = $k;
            }
        }
        $u = User::query()->find($userId);
        if (! $u || ! $u->isKeeper() || $u->isSupervisor()) {
            return $memo[$userId] = null;
        }
        $hs = $u->warehouses()->pluck('warehouses.id')->map(fn ($w) => static::hallOf((int) $w))->filter()->unique()->values();

        return $memo[$userId] = $hs->count() === 1 ? $hs[0] : null;
    }

    /** سالن بررسی یک قلم: انبارداری که جمعش کرده ← انباردار حواله ← انبار کالا */
    public static function itemHall(OrderItem $i, ?PickTask $task = null): ?string
    {
        return static::keeperHall((int) $i->picked_by) ?? static::keeperHall((int) ($task?->keeper_id ?? 0)) ?? static::hallOf((int) $i->warehouse_id);
    }

    public static function taskHall(PickTask $t): ?string
    {
        if (! empty($t->hall) && isset(static::halls()[$t->hall])) {
            return $t->hall;
        }

        return static::keeperHall((int) $t->keeper_id) ?? static::hallOf((int) $t->items()->value('warehouse_id'));
    }

    public static function hallName(?string $key): string
    {
        return $key ? (static::halls()[$key]['name'] ?? 'بدون سالن') : 'بدون سالن';
    }

    /** حواله‌ای که بعد از «جمع شد» باید روی میز بررسی شود؟ */
    public static function needsDesk(PickTask $task): bool
    {
        if (! static::hasDesk() || $task->stage !== null) {
            return false;
        }

        return static::keeperHall((int) $task->keeper_id) !== null
            || $task->items()->get()->contains(fn ($i) => static::itemHall($i, $task) !== null);
    }

    /** ثبت تعداد تأییدشده یک قلم در بررسی رومیزی (null = برداشتن تأیید) */
    public function deskSet(PickTask $task, OrderItem $item, ?int $units): OrderItem
    {
        abort_unless((int) $item->pick_task_id === (int) $task->id, 404);
        if ($task->stage !== 'desk' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی رومیزی نیست.']);
        }
        // بررسی‌کننده ممکن است بیشتر از شمارش جمع‌کننده (تا سقف سفارش) یا برای قلم افزوده هر تعدادی ثبت کند
        $item->desk_units = $units === null ? null : max(0, min(max($item->pickCap(), (int) $item->desk_units), $units));
        static::deskStamp($item);
        $item->save();

        return $item;
    }

    /** اسکن بارکد در بررسی رومیزی: هر اسکن یک کارتن (کالای کارتنی) یا یک عدد */
    public function deskScan(PickTask $task, string $code): array
    {
        if ($task->stage !== 'desk' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی رومیزی نیست.']);
        }
        $c = static::normCode($code);
        $items = $task->items()->with('product:id,barcode,sku,sync_code')->get();
        $hit = $c === '' ? collect() : $items->filter(fn (OrderItem $i) => in_array($c, static::itemCodes($i), true));
        if ($hit->isEmpty()) {
            $p = $c === '' ? null : Product::query()->where(fn ($q) => $q->where('barcode', $code)->orWhere('sku', $code)->orWhere('sync_code', $code)
                ->orWhere('barcode', $c)->orWhere('sku', $c)->orWhere('sync_code', $c))->first(['id', 'name']);

            return ['type' => $p ? 'notin' : 'unknown', 'item' => null, 'name' => $p?->name];
        }
        $item = $hit->first(fn (OrderItem $i) => (int) $i->desk_units < $this->target($i)) ?? $hit->first(fn (OrderItem $i) => (int) $i->desk_units < $i->pickCap()) ?? $hit->first();
        $now = (int) $item->desk_units;
        if ($now >= $item->pickCap()) {
            return ['type' => 'extra', 'item' => $item, 'name' => $item->name];
        }
        $item->desk_units = min($item->pickCap(), $now + static::scanStep($item));
        static::deskStamp($item);
        $item->save();

        return ['type' => (int) $item->desk_units > $this->target($item) ? 'over' : 'ok', 'item' => $item, 'name' => $item->name];
    }

    /**
     * تأیید نهایی بررسی رومیزی. $rest: اقلامی که هنوز تأیید نشده‌اند ← picker (طبق جمع‌کننده) | missing (ناموجود)
     *
     * @return bool آیا همه حواله‌های این مرحله تمام شد؟
     */
    public function deskApprove(PickTask $task, User $by, string $rest = 'missing', ?int $bags = null, ?int $boxes = null, ?string $lastPack = null): bool
    {
        if ($task->stage !== 'desk' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی رومیزی نیست.']);
        }
        $all = DB::transaction(function () use ($task, $by, $rest, $bags, $boxes, $lastPack) {
            $fresh = PickTask::query()->lockForUpdate()->find($task->id);
            if (! $fresh || $fresh->isDone() || $fresh->stage !== 'desk') {
                throw ValidationException::withMessages(['task' => 'این بررسی همین الان تأیید شده است.']);
            }
            $diff = 0;
            foreach ($task->items()->get() as $it) {
                $target = $this->target($it);
                $final = $it->desk_units === null ? ($rest === 'picker' ? $target : 0) : min($it->pickCap(), (int) $it->desk_units);
                if ($final !== $target) {
                    $diff++;
                }
                $status = $final >= $it->orderedUnits() ? 'ok' : ($final === 0 ? 'missing' : 'short');
                $it->forceFill(['picked_units' => $final, 'pick_status' => $status])->save();
            }
            // سالن با کیسه/کارتن: اقلامی که بیرون از بسته مانده‌اند (و تأیید طبق جمع‌کننده) در آخرین بسته
            if (static::hasDeskPack() && (static::packsOf($task) || $lastPack)) {
                $left = $task->items()->whereNull('desk_pack')->where('picked_units', '>', 0)->exists();
                if ($left) {
                    $this->deskPackAfter($task, $lastPack ?: 'bag');
                }
                $packs = static::packsOf($task->refresh());
                $bags ??= count(array_filter($packs, fn ($x) => ($x['type'] ?? 'bag') === 'bag')) ?: null;
                $boxes ??= count(array_filter($packs, fn ($x) => ($x['type'] ?? '') === 'box')) ?: null;
            }
            $pack = static::hasPacks() ? ['bags' => $bags, 'boxes' => $boxes] : [];
            $task->forceFill(['status' => 'done', 'done_at' => now(), 'done_by' => $by->id, 'checked_by' => $by->id, 'checked_at' => now(), 'stage' => null] + $pack)->save();
            [$ok, $short, $miss] = $this->counts($task->items()->get());
            $task->order->log('بررسی رومیزی و تأیید نهایی توسط '.$by->displayName().' ('.static::hallName(static::taskHall($task)).')'
                .($bags || $boxes ? ' — بسته‌بندی: '.($bags ? fa($bags).' کیسه' : '').($bags && $boxes ? ' و ' : '').($boxes ? fa($boxes).' کارتن' : '') : '').': '
                .fa($ok).' کامل'.($short ? '، '.fa($short).' کسری' : '').($miss ? '، '.fa($miss).' ناموجود' : '').($diff ? ' — '.fa($diff).' قلم با شمارش جمع‌کننده فرق داشت' : ''));

            return ! static::roundOpen((int) $task->order_id, (int) $task->round);
        });
        if ($all) {
            $this->finishAll($task->order()->first(), $task);
        }

        return $all;
    }

    /**
     * ادغام بررسی‌های باز تکراری یک سفارش در یک سالن (مثلاً ساخته‌شده پیش از نسخه ۱.۱۰.۱۱۴ یا با دو انباردار)
     * در قدیمی‌ترین بررسی؛ تأییدهای ثبت‌شده (desk_units) حفظ می‌شود.
     *
     * @return int تعداد بررسی ادغام‌شده
     */
    public static function mergeDesk(Collection $open): int
    {
        $n = 0;
        // ۱) هر قلم به سالن انبارداری که جمعش کرده (جواد ← خرده‌ریز، حسینی ← لوکس؛ انتقالی ← سالن انباردار مقصد)
        foreach ($open as $t) {
            $hall = static::taskHall($t);
            $items = $t->relationLoaded('items') ? $t->items : $t->items()->get();
            if (static::hasTaskHall() && $hall && $t->hall !== $hall) {
                $t->forceFill(['hall' => $hall])->save();
            }
            $wrong = $items->filter(fn ($i) => ($h = static::itemHall($i, $t)) && $h !== $hall)->groupBy(fn ($i) => static::itemHall($i, $t));
            foreach ($wrong as $h => $its) {
                DB::transaction(function () use ($t, $h, $its, &$n) {
                    $dest = PickTask::query()->where('order_id', $t->order_id)->where('stage', 'desk')->where('status', '!=', 'done')->where('id', '!=', $t->id)->get()
                        ->first(fn ($x) => static::taskHall($x) === $h);
                    if (! $dest) {
                        $dest = PickTask::query()->create(['order_id' => $t->order_id, 'keeper_id' => (int) $its->first()->picked_by ?: $t->keeper_id, 'round' => $t->round, 'status' => 'open',
                            'picker_id' => (int) $its->first()->picked_by ?: $t->picker_id, 'started_at' => $t->started_at ?? now(), 'seen_at' => now()]);
                        $dest->forceFill(['stage' => 'desk', 'picked_done_at' => $t->picked_done_at ?? now(), 'bay' => $t->bay] + (static::hasTaskHall() ? ['hall' => $h] : []))->save();
                    }
                    OrderItem::query()->whereIn('id', $its->pluck('id'))->update(['pick_task_id' => $dest->id]);
                    $t->order?->log(fa($its->count()).' قلم از بررسی '.static::hallName(static::taskHall($t)).' به بررسی '.static::hallName($h).' (سالن انبارداری که جمع کرده) منتقل شد');
                    $n++;
                });
            }
            if ($wrong->isNotEmpty() && ! OrderItem::query()->where('pick_task_id', $t->id)->exists()) {
                $t->delete();
            }
        }
        // ۲) چند بررسی باز یک سفارش در یک سالن ← یکی
        $open = PickTask::query()->with('items')->whereIn('order_id', $open->pluck('order_id')->unique())->where('stage', 'desk')->where('status', '!=', 'done')->get();
        $groups = $open->groupBy(fn (PickTask $t) => $t->order_id.'|'.(static::taskHall($t) ?? ''));
        foreach ($groups as $key => $ts) {
            if ($ts->count() < 2 || str_ends_with((string) $key, '|')) {
                continue;
            }
            DB::transaction(function () use ($ts, &$n) {
                $ts = $ts->sortBy('id')->values();
                $keep = PickTask::query()->lockForUpdate()->find($ts[0]->id);
                if (! $keep || $keep->isDone() || $keep->stage !== 'desk') {
                    return;
                }
                $bays = [$keep->bay];
                foreach ($ts->slice(1) as $t) {
                    $t = PickTask::query()->lockForUpdate()->find($t->id);
                    if (! $t || $t->isDone() || $t->stage !== 'desk') {
                        continue;
                    }
                    OrderItem::query()->where('pick_task_id', $t->id)->update(['pick_task_id' => $keep->id]);
                    $bays[] = $t->bay;
                    $t->delete();
                    $n++;
                }
                $keep->forceFill(['bay' => trim(implode('، ', array_unique(array_filter($bays)))) ?: null])->save();
                $keep->order?->log('بررسی‌های رومیزی تکراری این سفارش در یک بررسی ادغام شد ('.static::hallName(static::taskHall($keep)).')');
            });
        }

        return $n;
    }

    public static function hasTaskHall(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('pick_tasks', 'hall');
    }

    /**
     * پایان جمع‌آوری وقتی است که هیچ حواله بازی (جمع‌آوری یا بررسی) در سفارش نمانده باشد؛
     * بررسی رومیزی ممکن است اقلام چند مرحله را با هم داشته باشد.
     */
    public static function roundOpen(int $orderId, int $round): bool
    {
        if (PickTask::query()->where('order_id', $orderId)->where('status', '!=', 'done')->exists()) {
            return true;
        }
        $open = PickTask::query()->where('order_id', $orderId)->where('status', '!=', 'done')->pluck('id');
        if ($open->isEmpty()) {
            return false;
        }

        return OrderItem::query()->where('order_id', $orderId)->where('round', $round)->whereIn('pick_task_id', $open)->exists()
            || PickTask::query()->whereIn('id', $open)->where('round', $round)->exists();
    }

    public static function hallMode(?string $hall): string
    {
        return $hall ? (static::halls()[$hall]['mode'] ?? 'scan') : 'scan';
    }

    public static function hasDeskPack(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('order_items', 'desk_pack');
    }

    /** کیسه/کارتن‌های بسته‌شده یک بررسی: [{n, type: bag|box}] */
    public static function packsOf(PickTask $t): array
    {
        return static::hasDeskPack() ? array_values(array_filter((array) json_decode((string) $t->packs, true))) : [];
    }

    public static function packName(array $p): string
    {
        return (($p['type'] ?? 'bag') === 'box' ? 'کارتن ' : 'کیسه ').($p['n'] ?? '');
    }

    /** «بستن کیسه/کارتن»: اقلام تأییدشده‌ای که هنوز در بسته‌ای نیستند ← بسته شماره بعدی */
    public function deskPack(PickTask $task, string $type, bool $force = false): ?array
    {
        if ($task->stage !== 'desk' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی رومیزی نیست.']);
        }
        $type = $type === 'box' ? 'box' : 'bag';
        $q = $task->items()->whereNull('desk_pack')->whereNotNull('desk_units')->where('desk_units', '>', 0);
        if (! $force && ! (clone $q)->exists()) {
            throw ValidationException::withMessages(['pack' => 'قلم تأییدشده‌ای بیرون از کیسه/کارتن نیست؛ اول اقلام این بسته را تأیید کنید.']);
        }
        $packs = static::packsOf($task);
        $n = count($packs) + 1;
        $packs[] = ['n' => $n, 'type' => $type];
        (clone $q)->update(['desk_pack' => $n]);
        $task->forceFill(['packs' => json_encode($packs)])->save();

        return end($packs);
    }

    protected function deskPackAfter(PickTask $task, string $type): void
    {
        $packs = static::packsOf($task);
        $n = count($packs) + 1;
        $packs[] = ['n' => $n, 'type' => $type === 'box' ? 'box' : 'bag'];
        $task->items()->whereNull('desk_pack')->where('picked_units', '>', 0)->update(['desk_pack' => $n]);
        $task->forceFill(['packs' => json_encode($packs)])->save();
    }

    /** برداشتن آخرین کیسه/کارتن (اقلامش دوباره «بیرون از بسته» می‌شوند) */
    public function deskUnpack(PickTask $task): void
    {
        if ($task->stage !== 'desk' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی رومیزی نیست.']);
        }
        $packs = static::packsOf($task);
        if (! $packs) {
            return;
        }
        $last = array_pop($packs);
        $task->items()->where('desk_pack', (int) $last['n'])->update(['desk_pack' => null]);
        $task->forceFill(['packs' => $packs ? json_encode($packs) : null])->save();
    }

    /** شروع بررسی از اول (پس از قطعی برق و …) */
    public function deskReset(PickTask $task): void
    {
        if ($task->stage !== 'desk' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی رومیزی نیست.']);
        }
        // اقلامی که بررسی‌کننده خودش اضافه کرده می‌مانند (تأییدشان هم)
        $task->items()->where(fn ($q) => $q->whereNull('pick_note')->orWhere('pick_note', 'not like', '➕%'))
            ->update(['desk_units' => null] + (static::hasDeskAt() ? ['desk_at' => null] : []) + (static::hasDeskPack() ? ['desk_pack' => null] : []));
        if (static::hasDeskPack()) {
            $task->items()->update(['desk_pack' => null]);
            $task->forceFill(['packs' => null])->save();
        }
        $task->order?->log('بررسی رومیزی از اول شروع شد ('.static::hallName(static::taskHall($task)).')');
    }

    public static function hasPacks(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('pick_tasks', 'bags');
    }

    /**
     * بررسی‌کننده رومیزی کالایی خارج از جمع‌شده‌های جمع‌کننده به سفارش اضافه می‌کند (در همین انبار و همین حواله).
     */
    public function deskAdd(PickTask $task, int $productId, int $units, User $by, ?string $mode = null): OrderItem
    {
        if ($task->stage !== 'desk' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی رومیزی نیست.']);
        }
        $p = Product::query()->active()->find($productId);
        if (! $p) {
            throw ValidationException::withMessages(['product' => 'کالا پیدا نشد یا غیرفعال است.']);
        }
        $units = max(1, $units);
        $wid = (int) $task->items()->value('warehouse_id');
        $wh = $wid ? \App\Models\Warehouse::query()->find($wid) : null;
        $mode ??= ($wh?->kind === 'retail' && $p->retailAllowed()) ? Product::RETAIL : Product::CARTON;
        $mode = $mode === Product::RETAIL && $p->retailAllowed() ? Product::RETAIL : Product::CARTON;
        $order = $task->order;

        return DB::transaction(function () use ($task, $p, $units, $by, $mode, $wid, $order) {
            $price = $p->unitPrice($mode);
            // همین کالا قبلاً روی همین میز افزوده شده (و هنوز در کیسه/کارتن نرفته) ← همان ردیف بیشتر می‌شود، نه ردیف تکراری
            $same = $task->items()->where('product_id', $p->id)->where('mode', $mode)->where('pick_note', 'like', '➕%')
                ->when(static::hasDeskPack(), fn ($q) => $q->where(fn ($w) => $w->whereNull('desk_pack')->orWhere('desk_pack', 0)))->first();
            if ($same) {
                $n = (int) $same->units + $units;
                $same->forceFill(['units' => $n, 'ordered_units' => $n, 'picked_units' => $n, 'desk_units' => (int) $same->desk_units + $units,
                    'total' => (int) $same->unit_price * $n] + (static::hasDeskAt() ? ['desk_at' => now()] : []))->save();
                $col = $mode === Product::RETAIL ? 'retail_stock' : 'stock';
                if ($order->stock_reduced && $p->{$col} !== null && Product::counts()) {
                    Product::query()->whereKey($p->id)->update([$col => max(0, (int) $p->{$col} - $units)]);
                }
                static::recalc($order);
                $order->log('بررسی رومیزی ('.$by->displayName().'): «'.$p->name.'» '.fa($units).' عدد دیگر اضافه شد (جمع افزوده: '.fa($n).' عدد)');

                return $same;
            }
            $item = $order->items()->create([
                'product_id' => $p->id, 'name' => $p->name, 'barcode' => $p->barcode, 'image' => $p->image, 'mode' => $mode,
                'units' => $units, 'per_carton' => $p->per_carton, 'unit_label' => $p->unit_label, 'unit_price' => $price, 'compare_price' => null,
                'total' => $price * $units, 'warehouse_id' => $wid ?: $p->warehouseFor($mode), 'ordered_units' => $units, 'round' => $task->round,
                'pick_task_id' => $task->id, 'pick_status' => 'ok', 'picked_units' => $units, 'picked_at' => now(), 'picked_by' => $by->id,
                'pick_note' => '➕ افزوده در بررسی رومیزی',
            ] + (static::hasAppendix() ? ['appendix' => true] : []));
            $item->forceFill(['desk_units' => $units] + (static::hasDeskAt() ? ['desk_at' => now()] : []))->save();
            $col = $mode === Product::RETAIL ? 'retail_stock' : 'stock';
            if ($order->stock_reduced && $p->{$col} !== null && Product::counts()) {
                Product::query()->whereKey($p->id)->update([$col => max(0, (int) $p->{$col} - $units)]);
            }
            static::recalc($order);
            $order->log('بررسی رومیزی ('.$by->displayName().'): «'.$p->name.'» '.fa($units).' عدد خارج از جمع‌شده‌ها به سفارش اضافه شد (پیوست فاکتور)');

            return $item;
        });
    }

    /**
     * اصلاح «تعداد جمع‌شده» توسط بررسی‌کننده رومیزی (وقتی شمارش جمع‌کننده اشتباه ثبت شده است).
     * فقط در مرحله بررسی رومیزی؛ تعداد تأییدشده روی میز (desk_units) و انباردارِ جمع‌کننده (picked_by) دست نمی‌خورد.
     * با «تأیید نهایی» همین عدد (یا شمارش میز) روی فاکتور مشتری اعمال می‌شود.
     */
    public function deskCorrect(PickTask $task, OrderItem $item, int $units, User $by): OrderItem
    {
        abort_unless((int) $item->pick_task_id === (int) $task->id, 404);
        if ($task->stage !== 'desk' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی رومیزی نیست.']);
        }

        return DB::transaction(function () use ($task, $item, $units, $by) {
            $fresh = PickTask::query()->lockForUpdate()->find($task->id);
            if (! $fresh || $fresh->isDone() || $fresh->stage !== 'desk') {
                throw ValidationException::withMessages(['task' => 'این بررسی همین الان تأیید شده است.']);
            }
            $it = OrderItem::query()->lockForUpdate()->find($item->id);
            if (! $it || (int) $it->pick_task_id !== (int) $task->id) {
                throw ValidationException::withMessages(['item' => 'این قلم دیگر در این بررسی نیست.']);
            }
            $want = $it->orderedUnits();
            $old = $this->target($it);
            $new = max(0, min($it->overCap(), $units));
            if ($new === $old && $it->pick_status !== null) {
                return $it;
            }
            $it->forceFill(['picked_units' => $new, 'pick_status' => $new >= $want ? 'ok' : ($new === 0 ? 'missing' : 'short')])->save();
            $task->order?->log('بررسی رومیزی ('.$by->displayName().'): تعداد جمع‌شده «'.$it->name.'» از '.fa($old).' به '.fa($new).' عدد اصلاح شد', $by->id);

            return $it;
        });
    }

    /**
     * حذف یک قلم از بررسی رومیزی: قلم از سفارش و فاکتور مشتری هم برداشته می‌شود، موجودی کالا برمی‌گردد
     * و جمع سفارش دوباره محاسبه می‌شود. آخرین قلم یک بررسی حذف نمی‌شود (برای آن «ناموجود» را بزنید).
     */
    public function deskRemove(PickTask $task, OrderItem $item, User $by): void
    {
        abort_unless((int) $item->pick_task_id === (int) $task->id, 404);
        if ($task->stage !== 'desk' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی رومیزی نیست.']);
        }
        $restored = null;
        DB::transaction(function () use ($task, $item, $by, &$restored) {
            $fresh = PickTask::query()->lockForUpdate()->find($task->id);
            if (! $fresh || $fresh->isDone() || $fresh->stage !== 'desk') {
                throw ValidationException::withMessages(['task' => 'این بررسی همین الان تأیید شده است.']);
            }
            $it = OrderItem::query()->lockForUpdate()->find($item->id);
            if (! $it || (int) $it->pick_task_id !== (int) $task->id) {
                throw ValidationException::withMessages(['item' => 'این قلم دیگر در این بررسی نیست.']);
            }
            if ($task->items()->count() < 2) {
                throw ValidationException::withMessages(['item' => 'این آخرین قلم این بررسی است و حذف نمی‌شود. اگر کالا نبود، دکمه «ناموجود» (✗) را بزنید.']);
            }
            $order = Order::query()->lockForUpdate()->find($task->order_id);
            if (! $order) {
                throw ValidationException::withMessages(['task' => 'سفارش پیدا نشد.']);
            }
            // موجودی سایت: همان تعدادی که هنگام ثبت (یا افزودن) از موجودی کم شده برمی‌گردد
            if ($order->stock_reduced && $it->product_id && (int) $it->units > 0) {
                $p = Product::query()->lockForUpdate()->find($it->product_id);
                $col = $it->stockCol();
                if ($p && $p->{$col} !== null && Product::counts() && $p->stockRestorable($col, $order->created_at)) {
                    $p->{$col} = (int) $p->{$col} + (int) $it->units;
                    $p->saveQuietly();
                    $restored = $p;
                }
            }
            OrderItem::query()->where('replaces_item_id', $it->id)->update(['replaces_item_id' => null]);
            OrderReplacement::query()->where('replaces_item_id', $it->id)->update(['replaces_item_id' => null]);
            $name = $it->name;
            $units = (int) $it->units;
            $it->delete();
            static::recalc($order);
            $order->log('بررسی رومیزی ('.$by->displayName().'): «'.$name.'» ('.fa($units).' عدد) از بررسی و فاکتور سفارش حذف شد. مبلغ سفارش: '.money($order->total).' تومان', $by->id);
        });
        if ($restored) {
            try {
                app(StockNotifier::class)->check($restored);
            } catch (Throwable $e) {
                report($e);
            }
        }
    }

    /**
     * اقلام «جایگزین‌شده»: کالاهایی که مشتری به‌جای کالای کسری/ناموجود انتخاب کرده و مسئول پیگیری تأیید کرده است
     * (به‌جز کالایی که بررسی‌کننده رومیزی خودش اضافه کرده). برای چاپ حواله جایگزین‌ها به انبار.
     */
    public static function replacedItems(Order $order): Collection
    {
        $items = $order->relationLoaded('items') ? $order->items : $order->items()->get();
        $approved = $order->replacements()->where('status', 'approved')->get()->mapWithKeys(fn ($r) => [$r->product_id.'|'.$r->mode => true]);

        return $items->filter(function (OrderItem $i) use ($approved) {
            if ((int) $i->units <= 0) {
                return false;
            }
            if ($i->replaces_item_id) {
                return true;
            }
            if (! static::hasAppendix() || empty($i->appendix) || str_starts_with((string) $i->pick_note, '➕')) {
                return false;
            }

            return $approved->has($i->product_id.'|'.$i->mode);
        })->values();
    }

    /** کلید گروه حواله (برای خروجی هلو همان انبار) */
    public static function groupKey(PickTask $task): string
    {
        if ($task->keeper_id) {
            return 'k'.$task->keeper_id;
        }
        $wid = (int) $task->items()->value('warehouse_id');

        return 'w'.$wid;
    }

    /** کدهای قابل اسکن یک قلم (بارکد سفارش، بارکد و کد کالا) به شکل یکسان‌شده */
    public static function itemCodes(OrderItem $i): array
    {
        $codes = [(string) $i->barcode, (string) $i->product?->barcode, (string) $i->product?->sku, (string) $i->product?->sync_code];

        return array_values(array_unique(array_filter(array_map([static::class, 'normCode'], $codes))));
    }

    public static function normCode(?string $c): string
    {
        $c = strtoupper(preg_replace('/\s+/', '', en_digits((string) $c)));

        return ctype_digit($c) ? (ltrim($c, '0') ?: '0') : $c;
    }

    /** هر اسکن: کالای کارتنی یک کارتن، کالای تکی یک عدد */
    public static function scanStep(OrderItem $i): int
    {
        return ! $i->isRetail() && (int) $i->per_carton > 1 ? (int) $i->per_carton : 1;
    }

    /**
     * اسکن یک بارکد در بررسی بار.
     *
     * @return array{type: string, item: ?OrderItem, name: ?string}
     *   type: ok (ثبت شد) | full (این قلم کامل شده بود) | extra (بیشتر از سفارش مشتری) | notin (در فاکتور نیست) | unknown (بارکد ناشناخته)
     */
    public function scan(PickTask $task, string $code): array
    {
        if ($task->stage !== 'review' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی نیست.']);
        }
        $c = static::normCode($code);
        if ($c === '') {
            return ['type' => 'unknown', 'item' => null, 'name' => null];
        }
        $items = $task->items()->with('product:id,barcode,sku,sync_code')->get();
        $hit = $items->filter(fn (OrderItem $i) => in_array($c, static::itemCodes($i), true));
        if ($hit->isEmpty()) {
            // شاید کالای همین سفارش در حواله انباردار دیگری باشد، یا اصلاً در سفارش نباشد
            $p = Product::query()->where(fn ($q) => $q->where('barcode', $code)->orWhere('sku', $code)->orWhere('sync_code', $code)
                ->orWhere('barcode', $c)->orWhere('sku', $c)->orWhere('sync_code', $c))->first(['id', 'name']);

            return ['type' => $p ? 'notin' : 'unknown', 'item' => null, 'name' => $p?->name];
        }
        // قلمی که هنوز جا دارد، اول
        $item = $hit->first(fn (OrderItem $i) => static::checkedUnits($i) < $this->target($i)) ?? $hit->first(fn (OrderItem $i) => static::checkedUnits($i) < $i->pickCap()) ?? $hit->first();
        $step = static::scanStep($item);
        $now = (int) $item->scanned_units;
        if ($now >= $item->pickCap()) {
            return ['type' => 'extra', 'item' => $item, 'name' => $item->name];
        }
        $item->scanned_units = min($item->pickCap(), $now + $step);
        // اگر تأیید دستی داشت و حالا کارتن کامل اسکن شد، تأیید دستی تا سقف سفارش کم می‌شود
        if ($item->manual_units) {
            $item->manual_units = max(0, min((int) $item->manual_units, $item->pickCap() - (int) $item->scanned_units)) ?: null;
        }
        $item->save();
        $got = static::checkedUnits($item);
        $type = $got > $this->target($item) ? 'over' : ($got >= $this->target($item) ? 'done' : 'ok');

        return ['type' => $type, 'item' => $item, 'name' => $item->name];
    }

    /** تعداد بررسی‌شده هر قلم = اسکن‌شده + تأیید دستی (عددهای بدون برچسب) */
    public static function checkedUnits(OrderItem $i): int
    {
        return min($i->pickCap(), (int) $i->scanned_units + (int) $i->manual_units);
    }

    /** تأیید دستی تعداد عددی یک قلم (مثلاً ۹ عدد کنار ۲ کارتن اسکن‌شده) — $units مقدار نهایی دستی است */
    public function manualCheck(PickTask $task, OrderItem $item, int $units): OrderItem
    {
        abort_unless((int) $item->pick_task_id === (int) $task->id, 404);
        if ($task->stage !== 'review' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی نیست.']);
        }
        $room = max(0, $item->pickCap() - (int) $item->scanned_units);
        $item->manual_units = max(0, min($room, $units)) ?: null;
        $item->save();

        return $item;
    }

    /** تعدادی که جمع‌کننده گفته جمع کرده (هدف اسکن) */
    public function target(OrderItem $i): int
    {
        return $i->picked_units === null ? $i->orderedUnits() : (int) $i->picked_units;
    }

    /** تغییر دستی تعداد اسکن‌شده (برای کارتن بدون برچسب) — delta به تعداد اسکن */
    public function adjustScan(PickTask $task, OrderItem $item, int $delta): OrderItem
    {
        abort_unless((int) $item->pick_task_id === (int) $task->id, 404);
        if ($task->stage !== 'review' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی نیست.']);
        }
        $v = (int) $item->scanned_units + $delta * static::scanStep($item);
        $item->scanned_units = max(0, min($item->pickCap(), $v));
        if ($item->manual_units) {
            $item->manual_units = max(0, min((int) $item->manual_units, $item->pickCap() - (int) $item->scanned_units)) ?: null;
        }
        $item->save();

        return $item;
    }

    /** برگرداندن فاکتور به جمع‌کننده برای اصلاح */
    public function sendBack(PickTask $task, ?string $note): void
    {
        if ($task->stage !== 'review' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی نیست.']);
        }
        $note = mb_substr(trim((string) $note), 0, 190) ?: null;
        $task->forceFill(['stage' => 'picking', 'picked_done_at' => null, 'check_note' => $note])->save();
        $task->order->log('بار برای اصلاح به '.($task->picker?->displayName() ?? 'جمع‌کننده').' برگشت'.($note ? ': '.$note : ''));
        if ($task->picker_id) {
            app(WebPush::class)->toUsers([$task->picker_id], ['title' => 'فاکتور برای اصلاح برگشت — سفارش '.fa($task->order->number),
                'body' => $note ?: 'سرپرست بار را برگرداند.', 'url' => url('/keeper/task/'.$task->id), 'tag' => 'pick-'.$task->order_id]);
        }
    }

    /**
     * تأیید نهایی بار توسط سرپرست.
     * $mode: scanned = تعداد نهایی همان اسکن‌شده‌هاست (اسکن‌نشده = کسری) | picker = اقلام اسکن‌نشده طبق شمارش جمع‌کننده
     *
     * @return bool آیا همه حواله‌های این مرحله تمام شد؟
     */
    public function approve(PickTask $task, User $by, string $mode = 'scanned', ?string $bay = null): bool
    {
        if ($task->stage !== 'review' || $task->isDone()) {
            throw ValidationException::withMessages(['task' => 'این فاکتور در مرحله بررسی نیست.']);
        }
        // روال کاغذی: جمع‌کننده اپ ندارد؛ سرپرست پس از بررسی بار، جایگاه بار را ثبت می‌کند
        $bay = $bay !== null ? (mb_substr(trim(strip_tags($bay)), 0, 80) ?: null) : null;
        if ($mode === 'paper' && ! $bay && ! $task->bay) {
            throw ValidationException::withMessages(['bay' => 'جایگاه بار را بنویسید (مثلاً «سکوی ۳»).']);
        }
        if ($bay) {
            $task->forceFill(['bay' => $bay])->save();
        }
        $all = DB::transaction(function () use ($task, $by, $mode) {
            $diff = 0;
            foreach ($task->items()->get() as $it) {
                $target = $this->target($it);
                $scanned = static::checkedUnits($it); // اسکن + تأیید دستی
                $final = $mode === 'paper' ? $target // روال کاغذی: فقط تغییرات ثبت شده؛ بقیه طبق فاکتور
                    : ($mode === 'picker' && $scanned < $target ? $target : min($it->pickCap(), $scanned));
                if ($final !== $target) {
                    $diff++;
                }
                $status = $final >= $it->orderedUnits() ? 'ok' : ($final === 0 ? 'missing' : 'short');
                $it->forceFill(['picked_units' => $final, 'pick_status' => $status])->save();
            }
            $task->forceFill(['status' => 'done', 'done_at' => now(), 'done_by' => $by->id, 'checked_by' => $by->id, 'checked_at' => now(), 'stage' => null])->save();
            [$ok, $short, $miss] = $this->counts($task->items()->get());
            $task->order->log(($mode === 'paper' ? 'بررسی فاکتور کاغذی و تأیید نهایی توسط ' : 'بررسی بار و تأیید نهایی توسط ').$by->displayName().' (جمع‌کننده: '.($task->picker?->displayName() ?? '—').'، جایگاه: '.($task->bay ?: '—').'): '
                .fa($ok).' کامل'.($short ? '، '.fa($short).' کسری' : '').($miss ? '، '.fa($miss).' ناموجود' : '').($diff ? ' — '.fa($diff).' قلم با شمارش جمع‌کننده فرق داشت' : ''));

            return ! static::roundOpen((int) $task->order_id, (int) $task->round);
        });
        if ($all) {
            $this->finishAll($task->order()->first(), $task);
        }

        return $all;
    }

    /** بازگشایی حواله بسته‌شده (فقط مدیر/کارمند) */
    /** این حواله روی میز بررسی رومیزی تأیید شده؟ (اصلاحش هم باید روی همان میز باشد، نه برگشت به انباردار) */
    public static function deskChecked(PickTask $t): bool
    {
        if (! $t->checked_at || ! static::hasDesk()) {
            return false;
        }
        $role = $t->keeper_id ? User::query()->whereKey($t->keeper_id)->value('pick_role') : null;

        return $role !== 'supervisor' && static::taskHall($t) !== null;
    }

    public function reopen(PickTask $task, ?User $by = null): void
    {
        $o = $task->order;
        if ($o && ($o->isPaid() || $o->loadingLocked() || $o->remitPayments()->where('kind', 'settle')->where('status', 'confirmed')->exists())) {
            throw \Illuminate\Validation\ValidationException::withMessages(['task' => 'تسویه این سفارش انجام شده یا بار برای بارگیری رفته؛ بازگشایی حواله (تغییر اقلام) ممکن نیست.']);
        }
        // بار روی میز بررسی تأیید شده بود ← اصلاح روی همان میز (صف «ویرایش پس از تأیید»)، نه برگشت به کارتابل انباردار
        if (static::deskChecked($task)) {
            $this->deskReopen($task, $by ?? auth()->user() ?? User::query()->where('role', 'admin')->first(), 'بازگشایی از صفحه سفارش برای اصلاح');

            return;
        }
        $k = $task->keeper_id ? User::query()->find($task->keeper_id) : null;
        if ($task->keeper_id && (! $k || ! $k->is_active)) {
            throw \Illuminate\Validation\ValidationException::withMessages(['task' => 'انباردار این حواله ('.($k?->displayName() ?? 'حذف‌شده').') غیرفعال است؛ اول حواله را به انباردار دیگری بسپارید، بعد بازگشایی کنید.']);
        }
        $task->forceFill(['status' => 'open', 'done_at' => null, 'done_by' => null])->save();
        $order = $task->order;
        $order->forceFill(['fulfil_status' => 'picking'])->saveQuietly();
        $order->log('بازگشایی حواله '.($task->keeper?->displayName() ?? 'بدون انباردار').' برای اصلاح');
    }

    protected function counts(Collection $items): array
    {
        return [$items->where('pick_status', 'ok')->count(), $items->where('pick_status', 'short')->count(), $items->where('pick_status', 'missing')->count()];
    }

    /** پایان جمع‌آوری یک مرحله: اعمال تعدادها روی سفارش، ارجاع به مسئول پیگیری و اطلاع به مشتری */
    /** همه حواله‌های سفارش بسته شد: مرحله‌هایی که هنوز نهایی نشده‌اند نهایی می‌شوند (فقط آخری خبر می‌دهد) */
    protected function finishAll(Order $order, PickTask $task): void
    {
        $has = \App\Support\DbSchema::hasColumn('orders', 'done_rounds');
        if ($has && $order->done_rounds !== null) {
            $done = array_map('intval', array_filter(explode(',', (string) $order->done_rounds), 'strlen'));
            $rounds = $order->items()->whereNotNull('pick_task_id')->distinct()->pluck('round')->map(fn ($v) => (int) $v)
                ->push((int) $task->round)->unique()->reject(fn ($r) => in_array($r, $done, true))->sort()->values();
        } else {
            // سفارش‌های قدیمی: فقط مرحله همین حواله و مراحل اقلامش
            $rounds = OrderItem::query()->where('pick_task_id', $task->id)->pluck('round')->push((int) $task->round)->map(fn ($v) => (int) $v)->unique()->sort()->values();
        }
        if ($rounds->isEmpty()) {
            // این مرحله قبلاً نهایی شده بود (حواله یا بررسی رومیزی پس از تأیید دوباره باز و اصلاح شد)
            $this->applyRecheck($order->fresh(), $task);

            return;
        }
        foreach ($rounds as $k => $r) {
            $this->finalize($order->fresh(), (int) $r, $k === $rounds->count() - 1);
        }
    }

    /**
     * اعمال اصلاح پس از بازگشایی: تعداد نهایی اقلام همین حواله روی سفارش، جمع سفارش دوباره محاسبه و تغییرات (قبل ← بعد) در تاریخچه.
     * پیامک «جمع‌آوری تمام شد» دوباره نمی‌رود؛ اگر مانده حساب صادر شده، به مسئول پیگیری برای اصلاح خبر داده می‌شود.
     */
    public function applyRecheck(Order $order, PickTask $task, ?User $by = null): void
    {
        $lines = [];
        $before = (int) $order->total;
        DB::transaction(function () use ($order, $task, &$lines) {
            foreach (OrderItem::query()->where('pick_task_id', $task->id)->lockForUpdate()->get() as $it) {
                if ($it->picked_units === null) {
                    continue;
                }
                $new = (int) $it->picked_units; // بیشتر از سفارش هم (جمع‌آوری اضافه با تأیید)
                if ($new > (int) $it->units) {
                    \App\Services\OrderEdit::moveStock($order, $it->product_id, $it->cartMode(), $new - (int) $it->units, $it->name);
                }
                if ($new !== (int) $it->units) {
                    $lines[] = '«'.$it->name.'» '.fa((int) $it->units).' ← '.fa($new).' عدد';
                    $it->forceFill(['units' => $new, 'total' => (int) $it->unit_price * $new])->save();
                }
            }
            static::recalc($order);
            if (! static::roundOpen((int) $order->id, (int) $task->round) && $order->fulfil_status === 'picking') {
                $order->fulfil_status = 'picked';
            }
            $order->saveQuietly();
        });
        $order->refresh();
        $order->log('اصلاح پس از بازگشایی ('.static::hallName(static::taskHall($task)).($by ? '، '.$by->displayName() : '').'): '
            .($lines ? implode('؛ ', $lines).'. مبلغ سفارش: '.money($before).' ← '.money($order->total).' تومان' : 'تعداد اقلام تغییری نکرد'), $by?->id);
        if ($lines && $order->assignee_id) {
            $settle = \App\Models\RemitPayment::query()->where('order_id', $order->id)->where('kind', 'settle')->whereIn('status', ['awaiting', 'rejected'])->exists();
            try {
                app(WebPush::class)->toUsers([$order->assignee_id], ['title' => 'اقلام سفارش '.fa($order->number).' اصلاح شد',
                    'body' => 'مبلغ جدید '.money($order->total).' تومان'.($settle ? ' — مانده حساب صادرشده را اصلاح کنید' : ''), 'url' => url('/admin/orders/'.$order->id), 'tag' => 'recheck-'.$order->id]);
            } catch (Throwable $e) {
                report($e);
            }
        }
    }

    /** چرا بررسی رومیزی تأییدشده دوباره باز نمی‌شود (null = می‌شود) */
    public static function deskReopenBlock(PickTask $task): ?string
    {
        if (! $task->isDone() || ! $task->checked_at) {
            return 'این بررسی هنوز تأیید نهایی نشده است.';
        }
        $o = $task->order;
        if (! $o || in_array($o->status, ['cancelled', 'failed', 'completed'], true)) {
            return 'این سفارش بسته شده است.';
        }
        if ($o->isPaid() || $o->loadingLocked() || $o->remitPayments()->where('kind', 'settle')->where('status', 'confirmed')->exists()) {
            return 'تسویه این سفارش انجام شده یا بار برای بارگیری رفته؛ ویرایش بررسی ممکن نیست.';
        }

        return null;
    }

    /** چه کسی بررسی تأییدشده را دوباره باز می‌کند: assignee (فقط مسئول پیگیری/مدیر) | checker (بررسی‌کننده هم) */
    public static function deskReopenMode(): string
    {
        return setting('desk_reopen', 'assignee') === 'checker' ? 'checker' : 'assignee';
    }

    public static function canDeskReopenDirect(PickTask $task, User $u): bool
    {
        return $u->isAdmin() || static::deskReopenMode() === 'checker' || (int) $task->order?->assignee_id === (int) $u->id;
    }

    /** بررسی‌کننده اجازه ندارد: درخواست ویرایش برای مسئول پیگیری (در تاریخچه + اعلان) */
    public function deskReopenRequest(PickTask $task, User $by, string $reason): void
    {
        if ($why = static::deskReopenBlock($task)) {
            throw ValidationException::withMessages(['task' => $why]);
        }
        $reason = mb_substr(trim(strip_tags($reason)), 0, 200);
        if (mb_strlen($reason) < 3) {
            throw ValidationException::withMessages(['reason' => 'علت ویرایش را بنویسید.']);
        }
        $o = $task->order;
        if (\App\Support\DbSchema::hasColumn('pick_tasks', 'reopen_req')) {
            $task->forceFill(['reopen_req' => json_encode(['by' => $by->id, 'name' => $by->displayName(), 'why' => $reason, 'at' => now()->timestamp], JSON_UNESCAPED_UNICODE)])->save();
        }
        $o->log('درخواست ویرایش بررسی رومیزی ('.static::hallName(static::taskHall($task)).') از '.$by->displayName().' — علت: '.$reason.'. منتظر اجازه مسئول پیگیری.', $by->id);
        $to = array_values(array_filter([(int) $o->assignee_id]));
        if (! $to) {
            $to = User::query()->where('role', 'admin')->where('is_active', true)->pluck('id')->all();
        }
        try {
            app(WebPush::class)->toUsers($to, ['title' => '✏️ درخواست ویرایش بررسی — سفارش '.fa($o->number),
                'body' => $by->displayName().': '.$reason, 'url' => url('/admin/orders/'.$o->id), 'tag' => 'reopen-req-'.$task->id]);
        } catch (Throwable $e) {
            report($e);
        }
    }

    public static function reopenRequest(PickTask $task): ?array
    {
        $r = $task->reopen_req ?? null;

        return $r ? (array) json_decode((string) $r, true) : null;
    }

    /** ویرایش بررسی رومیزی پس از تأیید نهایی: بررسی دوباره باز می‌شود (شمارش‌های قبلی سر جایش) و با تأیید دوباره اعمال می‌شود */
    public function deskReopen(PickTask $task, User $by, string $reason): void
    {
        if ($why = static::deskReopenBlock($task)) {
            throw ValidationException::withMessages(['task' => $why]);
        }
        $reason = mb_substr(trim(strip_tags($reason)), 0, 200);
        if (mb_strlen($reason) < 3) {
            throw ValidationException::withMessages(['reason' => 'علت ویرایش را بنویسید (مثلاً «یک کالا اشتباه شمرده شد»).']);
        }
        DB::transaction(function () use ($task, $by, $reason) {
            $fresh = PickTask::query()->lockForUpdate()->find($task->id);
            if (! $fresh || ! $fresh->isDone()) {
                throw ValidationException::withMessages(['task' => 'این بررسی همین الان باز شده است.']);
            }
            $upd = ['status' => 'open', 'stage' => 'desk', 'done_at' => null, 'done_by' => null];
            if (\App\Support\DbSchema::hasColumn('pick_tasks', 'reopen_req')) {
                $upd['reopen_req'] = null;
            }
            if (\App\Support\DbSchema::hasColumn('pick_tasks', 'rechecks')) {
                $upd['rechecks'] = (int) $fresh->rechecks + 1;
            }
            $fresh->forceFill($upd)->save();
            $order = $fresh->order;
            $order->forceFill(['fulfil_status' => 'picking'])->saveQuietly();
            $order->log('بازگشایی بررسی رومیزی برای ویرایش ('.static::hallName(static::taskHall($fresh)).') توسط '.$by->displayName().' — علت: '.$reason, $by->id);
        });
    }

    public function finalize(Order $order, int $round, bool $notify = true): void
    {
        if (\App\Support\DbSchema::hasColumn('orders', 'done_rounds')) {
            $done = array_filter(explode(',', (string) $order->done_rounds), 'strlen');
            $done[] = (string) $round;
            $order->forceFill(['done_rounds' => implode(',', array_unique($done))])->saveQuietly();
        }
        $items = $order->items()->where('round', $round)->whereNotNull('pick_task_id')->get();
        $removed = 0;
        DB::transaction(function () use ($order, $items, &$removed) {
            foreach ($items as $it) {
                if ($it->picked_units === null) {
                    continue;
                }
                // تعداد نهایی = جمع‌شده (حداکثر تا سفارش اولیه). پس از «بازگشایی برای اصلاح» تعداد ممکن است بیشتر هم شود.
                // تعداد نهایی = جمع‌شده. بیشتر از سفارش هم ممکن است (مثلاً مشتری ۵ خواسته، کارتن ۶تایی ← ۶)
                $picked = (int) $it->picked_units;
                if ($picked < $it->orderedUnits()) {
                    $removed++;
                }
                if ($picked > (int) $it->units) {
                    OrderEdit::moveStock($order, $it->product_id, $it->cartMode(), $picked - (int) $it->units, $it->name);
                    $order->log('جمع‌آوری بیشتر از سفارش: «'.$it->name.'» '.fa((int) $it->units).' ← '.fa($picked).' عدد (فاکتور اصلاح شد)');
                }
                if ($picked < (int) $it->units) {
                    // موجودی سایت هم با واقعیت انبار یکی می‌شود: کالایی که کم آمد دیگر موجود نیست
                    if ($it->product_id && setting('pick_zero_stock', true)) {
                        $col = $it->stockCol();
                        Product::markOut((int) $it->product_id, $col);
                    }
                }
                if ($picked !== (int) $it->units || (int) $it->total !== (int) $it->unit_price * $picked) {
                    $it->forceFill(['units' => $picked, 'total' => (int) $it->unit_price * $picked])->save();
                }
            }
            static::recalc($order);
            $order->fulfil_status = 'picked';
            $order->picked_at = now();
            $order->alerted_at = now(); // هشدار برای مسئول پیگیری
            $order->replace_submitted_at = null;
            $hours = (float) setting('replace_hours', 6);
            // پنجره جایگزین/افزودن: اگر کالایی حذف شد، یا اولین جمع‌آوری سفارش (مشتری بتواند کالای جدید اضافه کند)
            $first = ! $order->replacements()->exists();
            $order->replace_until = ($removed || ($first && OrderWindows::on())) && setting('replace_enabled', true) && $hours > 0 && ! $order->isPaid() ? now()->addMinutes((int) round($hours * 60)) : null;
            $order->saveQuietly();
        });
        [$ok, $short, $miss] = $this->counts($items);
        // پایان جمع‌آوری ← «در انتظار تسویه حساب مشتری»
        if ($order->status === 'processing' && setting('pick_auto_settle', true)) {
            $order->setStatus('settling', 'پایان جمع‌آوری انبار');
            if ($order->isPaid()) {
                Shipping::afterPaid($order); // پیش‌تر تسویه کرده بود
            }
        }
        $order->log('جمع‌آوری انبار تمام شد و به مسئول پیگیری ارجاع شد: '.fa($ok).' کامل'.($short ? '، '.fa($short).' کسری' : '').($miss ? '، '.fa($miss).' ناموجود' : '')
            .'. مبلغ سفارش: '.money($order->total).' تومان'.($order->replace_until ? ' — مهلت جایگزینی مشتری تا '.jdate($order->replace_until, true) : ''));
        if (! $notify) {
            return;
        }
        OrderWindows::afterPicked($order->fresh());
        try {
            if ($order->assignee_id) {
                app(WebPush::class)->toUsers([$order->assignee_id], ['title' => 'جمع‌آوری انبار تمام شد — سفارش '.fa($order->number),
                    'body' => $order->customer_name.($short + $miss ? ' — '.fa($short + $miss).' قلم کسری/ناموجود' : ' — همه اقلام کامل'), 'url' => url('/admin/orders/'.$order->id), 'tag' => 'picked-'.$order->id]);
            }
            $sms = app(Sms::class);
            $sms->forOrder($order, 'order_picked', [
                'removed' => fa($short + $miss),
                'deadline' => $order->replace_until ? jdate($order->replace_until, true) : '',
            ]);
            app(WebPush::class)->toUsers([$order->user_id], ['title' => 'سفارش '.fa($order->number).' در انبار جمع‌آوری شد',
                'body' => $short + $miss ? fa($short + $miss).' قلم کسری یا ناموجود بود؛ برای انتخاب جایگزین سفارش را ببینید.' : 'همه اقلام آماده است.',
                'url' => route('order.show', $order->number), 'tag' => 'order-'.$order->id]);
        } catch (Throwable $e) {
            report($e);
        }
    }

    /* ---------------- برگشت کالا به انبار پس از لغو سفارش ---------------- */

    public static function hasRet(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('pick_tasks', 'ret_state');
    }

    /** کالای این حواله از قفسه برداشته شده؟ (در دست جمع‌کننده، منتظر بررسی، بسته‌بندی‌شده یا جمع‌شده) */
    public static function hasGoods(PickTask $t): bool
    {
        if ($t->isDone() || in_array($t->stage, ['picking', 'review', 'desk'], true) || $t->started_at || $t->picked_done_at) {
            return true;
        }

        return $t->items()->where(fn ($q) => $q->where('picked_units', '>', 0)->orWhere('desk_units', '>', 0)
            ->orWhere('scanned_units', '>', 0)->orWhere('manual_units', '>', 0))->exists();
    }

    /** این حواله برای برگشت در «میز بررسی» دیده می‌شود (نه کارتابل انباردار/سرپرست) */
    public static function retAtDesk(PickTask $t): bool
    {
        if ($t->stage === 'desk') {
            return true;
        }
        $k = $t->keeper_id ? User::query()->find($t->keeper_id, ['id', 'pick_role', 'is_active', 'role']) : null;
        if ($k?->pick_role === 'supervisor' && $k->is_active) {
            return false; // حواله سرپرست‌دار (فاکتور کاغذی): اپ سرپرست
        }
        if ($t->isDone() && $t->checked_at) {
            return true;
        }
        // انباردار حواله دیگر فعال نیست/ندارد ← میز بررسی همان سالن (تا کارت بی‌صاحب نماند)
        return (! $k || ! $k->is_active) && static::taskHall($t) !== null;
    }

    /** اقلامی که باید به قفسه برگردد (تعداد برداشته‌شده؛ برای حواله نیمه‌کاره «احتمالاً») */
    public static function retItems(PickTask $t): array
    {
        return $t->items()->orderBy('id')->get()->map(function (OrderItem $i) use ($t) {
            $u = (int) ($i->desk_units ?? $i->picked_units ?? 0);
            if (! $u && $t->isDone() && $i->pick_status !== 'missing') {
                $u = (int) $i->units;
            }
            $sure = $u > 0;
            if (! $sure && $i->pick_status === null && ! $t->isDone()) {
                $u = (int) $i->units; // هنوز تیک نخورده: شاید جمع شده باشد
            }

            return $u > 0 ? ['name' => $i->name, 'code' => (string) $i->code(), 'qty' => $i->unitsLabel($u), 'sure' => $sure] : null;
        })->filter()->values()->all();
    }

    /**
     * لغو سفارش: حواله‌هایی که کالایشان از قفسه برداشته شده در صف «برگشت به انبار» می‌روند
     * (میز بررسی سالن، یا کارتابل سرپرست/انباردار). حواله‌ای که هنوز دست نخورده فقط بسته می‌شود.
     */
    public static function orderCancelled(Order $o, bool $notify = true): int
    {
        if (! static::hasRet()) {
            return 0;
        }
        $n = 0;
        $users = [];
        $halls = [];
        foreach (PickTask::query()->where('order_id', $o->id)->whereNull('ret_state')->get() as $t) {
            if (! static::hasGoods($t) || ! static::retItems($t)) {
                continue; // دست نخورده، یا همه اقلامش ناموجود بود: چیزی برای برگرداندن نیست
            }
            $t->forceFill(['ret_state' => 'pending'])->save();
            $n++;
            if (static::retAtDesk($t)) {
                $halls[] = static::hallName(static::taskHall($t));
            } else {
                $users[] = (int) $t->keeper_id;
                $users[] = (int) $t->picker_id;
            }
        }
        if (! $n) {
            return 0;
        }
        $where = array_filter([$halls ? 'میز بررسی '.implode('، ', array_unique($halls)) : null, array_filter($users) ? 'کارتابل انبار' : null]);
        $o->log('⛔ لغو پس از جمع‌آوری: '.fa($n).' حواله که کالایش از قفسه برداشته شده بود برای «برگشت به انبار» در '.(implode(' و ', $where) ?: 'کارتابل انبار').' گذاشته شد');
        if ($notify) {
            try {
                $to = array_values(array_unique(array_filter($users)));
                if ($to) {
                    app(WebPush::class)->toUsers($to, ['title' => '⛔ سفارش '.fa($o->number).' لغو شد', 'body' => $o->customer_name.' — کالاهای جمع‌شده را به انبار برگردانید', 'url' => url('/keeper'), 'tag' => 'ret-'.$o->id]);
                }
            } catch (Throwable $e) {
                report($e);
            }
        }

        return $n;
    }

    /** لغو برگشت خورد (سفارش دوباره باز شد) */
    public static function orderRestored(Order $o): void
    {
        if (! static::hasRet()) {
            return;
        }
        PickTask::query()->where('order_id', $o->id)->where('ret_state', 'pending')->update(['ret_state' => null]);
        $back = PickTask::query()->where('order_id', $o->id)->where('ret_state', 'done')->count();
        if ($back) {
            $o->log('⚠ این سفارش از لغو برگشت، ولی کالاهای '.fa($back).' حواله‌اش قبلاً به انبار برگردانده شده؛ برای ارسال باید دوباره جمع‌آوری شود.');
            try {
                if ($o->assignee_id) {
                    app(WebPush::class)->toUsers([$o->assignee_id], ['title' => 'سفارش '.fa($o->number).' از لغو برگشت', 'body' => 'کالاها قبلاً به انبار برگردانده شده؛ دوباره ارجاع دهید', 'url' => url('/admin/orders/'.$o->id)]);
                }
            } catch (Throwable $e) {
                report($e);
            }
        }
    }

    /** «کالاها به انبار برگشت» */
    public function returned(PickTask $t, User $by): void
    {
        $o = $t->order;
        if ($t->ret_state !== 'pending') {
            throw ValidationException::withMessages(['ret' => 'برگشت این حواله قبلاً ثبت شده است.']);
        }
        if (! $o || $o->status !== 'cancelled') {
            $t->forceFill(['ret_state' => null])->save();
            throw ValidationException::withMessages(['ret' => 'این سفارش دیگر لغو نیست؛ کالاها را برنگردانید.']);
        }
        $t->forceFill(['ret_state' => 'done', 'ret_at' => now(), 'ret_by' => $by->id])->save();
        $o->log('↩️ کالاهای حواله '.static::hallName(static::taskHall($t)).($t->keeper ? ' ('.$t->keeper->displayName().')' : '').' به انبار برگشت داده شد — '.$by->displayName(), $by->id);
    }

    /** حواله‌های منتظر برگشت (برای یک سالن میز بررسی یا کارتابل یک کاربر) */
    public static function pendingReturns(?User $u = null, ?string $hall = null): Collection
    {
        if (! static::hasRet()) {
            return collect();
        }
        $q = PickTask::query()->with(['order', 'keeper', 'picker'])->where('ret_state', 'pending')->whereHas('order', fn ($w) => $w->where('status', 'cancelled'));
        if ($hall !== null) {
            return $q->get()->filter(fn (PickTask $t) => static::retAtDesk($t) && static::taskHall($t) === $hall)->values();
        }
        if ($u) {
            $q = static::seesAll($u) ? $q : $q->where(fn ($w) => $w->where('keeper_id', $u->id)->orWhere('picker_id', $u->id));

            return $q->get()->reject(fn (PickTask $t) => static::retAtDesk($t))->values();
        }

        return $q->get();
    }

    /** داده کارت «برگشت به انبار» */
    public static function retCard(PickTask $t): array
    {
        $o = $t->order;

        return [
            'id' => $t->id,
            'order' => fa((string) $o->number),
            'name' => (string) $o->customer_name,
            'city' => (string) $o->city,
            'reason' => (string) $o->cancel_reason,
            'ago' => fa((string) $o->status_changed_at?->diffForHumans()),
            'bay' => (string) $t->bay,
            'pack' => \App\Http\Controllers\DeskController::packLabel($t),
            'hall' => static::hallName(static::taskHall($t)),
            'keeper' => $t->keeper?->displayName(),
            'picker' => $t->picker?->displayName(),
            'state' => $t->isDone() ? ($t->checked_at ? 'جمع و بررسی شده' : 'جمع شده') : (PickTask::STAGES[$t->stage] ?? 'در حال جمع‌آوری'),
            'holoo' => (bool) \App\Models\OrderEvent::query()->where('order_id', $o->id)->where('message', 'like', 'دریافت اکسل هلو%')->exists(),
            'items' => static::retItems($t),
        ];
    }

    /** محاسبه دوباره جمع سفارش پس از تغییر اقلام (هزینه ارسال، کارمزدها، تخفیف و چک) */
    public static function recalc(Order $order): void
    {
        $before = (int) $order->total;
        $items = $order->items()->get();
        $itemsTotal = (int) $items->sum('total');
        $discount = (int) $items->sum(fn ($i) => $i->compare_price ? max(0, $i->compare_price - $i->unit_price) * $i->units : 0);
        $cartons = (int) $items->sum(fn ($i) => $i->mode === Product::CARTON && $i->per_carton > 0 ? intdiv((int) $i->units, (int) $i->per_carton) : 0);
        $couponOff = min($itemsTotal, (int) $order->coupon_discount);
        $ship = Checkout::shippingMethod($order->shipping_method);
        $shipCost = $ship ? (($order->coupon_code && (int) $order->shipping_cost === 0 && empty($ship['collect'])) ? 0 : Checkout::shippingCost($ship, $itemsTotal)) : (int) $order->shipping_cost;
        $fees = Checkout::fees($itemsTotal, $cartons);
        $feesTotal = (int) array_sum(array_column($fees, 'amount'));
        // کرایه حمل تا باربری (سرپرست انبار / کارشناس) و تخفیف صدور مانده حساب
        $grand = max(0, $itemsTotal - $couponOff + $shipCost + $feesTotal + (int) $order->freight_fee - (int) $order->extra_discount);
        $order->fill([
            'items_total' => $itemsTotal, 'discount_total' => $discount, 'coupon_discount' => $couponOff,
            'shipping_cost' => $shipCost, 'fees' => $fees, 'fees_total' => $feesTotal, 'total' => $grand,
        ]);
        if ($order->cheque) {
            $order->cheque = Cheques::recalc($order->cheque, $grand, $order->created_at);
        }
        $order->saveQuietly();
        if ($grand !== $before) {
            Remit::totalChanged($order, $before); // مانده حساب صادرشده دیگر با فاکتور نمی‌خواند
        }
        if ($order->advisor_id) {
            Advisors::sync($order); // پورسانت مشاور با مبلغ تازه
        }
    }

    /* ---------------- جایگزینی توسط مشتری ---------------- */

    /** کالاهای حذف‌شده یا کسری‌دار که مشتری می‌تواند برایشان جایگزین بگیرد */
    public static function hasAppendix(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('order_items', 'appendix');
    }

    public static function removedItems(Order $order): Collection
    {
        return $order->items->filter(fn (OrderItem $i) => in_array($i->pick_status, ['short', 'missing'], true))->values();
    }

    public function addReplacement(Order $order, int $productId, string $mode, int $units, ?int $replacesId): OrderReplacement
    {
        if (! $order->canReplace() || $order->replace_submitted_at) {
            throw ValidationException::withMessages(['replace' => 'مهلت انتخاب جایگزین تمام شده است.']);
        }
        $p = Product::query()->active()->findOrFail($productId);
        $mode = $mode === Product::RETAIL ? Product::RETAIL : Product::CARTON;
        $cart = app(Cart::class);
        $cart->ignoreReserved = true;
        [$u, $msg] = $cart->clamp($p, $mode, max(1, $units));
        if ($u <= 0) {
            throw ValidationException::withMessages(['replace' => $msg ?: 'این کالا موجود نیست.']);
        }
        $replaces = $replacesId ? $order->items()->whereKey($replacesId)->first() : null;

        return $order->replacements()->updateOrCreate(
            ['product_id' => $p->id, 'mode' => $mode, 'status' => 'draft'],
            ['replaces_item_id' => $replaces?->id, 'name' => $p->name, 'units' => $u, 'per_carton' => max(1, (int) $p->per_carton), 'unit_price' => $p->unitPrice($mode)]
        );
    }

    public function submitReplacements(Order $order): int
    {
        if (! $order->canReplace() || $order->replace_submitted_at) {
            throw ValidationException::withMessages(['replace' => 'مهلت انتخاب جایگزین تمام شده است.']);
        }
        $n = $order->replacements()->where('status', 'draft')->update(['status' => 'submitted']);
        if (! $n) {
            throw ValidationException::withMessages(['replace' => 'هنوز کالای جایگزینی انتخاب نکرده‌اید.']);
        }
        $order->forceFill(['replace_submitted_at' => now(), 'fulfil_status' => 'replace_review', 'alerted_at' => now()])->saveQuietly();
        $sum = (int) $order->replacements()->where('status', 'submitted')->get()->sum(fn ($r) => $r->total());
        $order->log('مشتری '.fa($n).' کالای جایگزین انتخاب کرد ('.money($sum).' تومان) — در انتظار تأیید مسئول پیگیری', $order->user_id);
        if ($order->assignee_id) {
            app(WebPush::class)->toUsers([$order->assignee_id], ['title' => 'جایگزین‌های مشتری — سفارش '.fa($order->number),
                'body' => $order->customer_name.' — '.fa($n).' کالا', 'url' => url('/admin/chats?o='.$order->id), 'tag' => 'repl-'.$order->id]);
        }
        // تنظیم «افزوده‌های مشتری بدون تأیید اپراتور»: همین حالا به سفارش و کارتابل جمع‌کننده‌ها
        if (OrderWindows::autoAdd()) {
            $ids = $order->replacements()->where('status', 'submitted')->pluck('id')->map(fn ($v) => (int) $v)->all();
            $before = (int) $order->total;
            $added = $this->approveReplacements($order, $ids, static::enabled());
            $order->refresh();
            $order->log('افزوده‌های مشتری خودکار (بدون تأیید اپراتور) به سفارش اضافه و به انبار ارجاع شد — '.fa($added).' قلم');
            if ($t = Chat::thread($order)) {
                Chat::post($t, 'x', null, 'event', '✅ '.fa($added).' کالای افزوده/جایگزین شما ('.money($sum).' تومان) به سفارش اضافه شد و برای جمع‌آوری به انبار رفت. مبلغ فاکتور: '.money($before).' ← '.money($order->total).' تومان.'."\n".OrderWindows::WAIT_SETTLE, ['r' => 1]);
                Chat::notifyStaff($t, $order, '➕ مشتری '.fa($added).' کالا ('.money($sum).' تومان) به بارش اضافه کرد؛ خودکار به انبار رفت.');
            }
            OrderWindows::addPop($order, 'addprint', 'مشتری کالا به بارش اضافه کرد', fa($added).' قلم ('.money($sum).' تومان) خودکار به سفارش و کارتابل انبار رفت. می‌خواهید حواله افزوده‌ها را چاپ کنید؟');

            return $n;
        }
        OrderWindows::replSubmitted($order, $n, $sum);

        return $n;
    }

    /**
     * تأیید جایگزین‌ها توسط مسئول پیگیری: افزودن به سفارش و ارجاع به انبار (حواله مرحله بعد)
     *
     * @param  int[]  $approve  شناسه‌های تأییدشده؛ بقیه رد می‌شوند
     */
    public function approveReplacements(Order $order, array $approve, bool $refer = true): int
    {
        $reps = $order->replacements()->whereIn('status', ['submitted', 'draft'])->get();
        $added = 0;
        DB::transaction(function () use ($order, $reps, $approve, &$added) {
            foreach ($reps as $r) {
                if (! in_array($r->id, $approve, true)) {
                    $r->update(['status' => 'rejected']);

                    continue;
                }
                $p = Product::query()->lockForUpdate()->find($r->product_id);
                if (! $p) {
                    $r->update(['status' => 'rejected']);

                    continue;
                }
                $order->items()->create([
                    'product_id' => $p->id, 'name' => $p->name, 'barcode' => $p->barcode, 'image' => $p->image, 'mode' => $r->mode,
                    'units' => $r->units, 'per_carton' => $p->per_carton, 'unit_label' => $p->unit_label, 'unit_price' => $r->unit_price, 'compare_price' => null,
                    'total' => (int) $r->unit_price * (int) $r->units, 'warehouse_id' => $p->warehouseFor($r->mode),
                    'replaces_item_id' => $r->replaces_item_id, 'ordered_units' => $r->units,
                ] + (static::hasAppendix() ? ['appendix' => true] : [])); // پیوست فاکتور
                $col = $r->mode === Product::RETAIL ? 'retail_stock' : 'stock';
                if ($order->stock_reduced && $p->{$col} !== null && Product::counts()) {
                    $p->{$col} -= $r->units;
                    $p->saveQuietly();
                }
                $r->update(['status' => 'approved']);
                $added++;
            }
            static::recalc($order);
            $order->forceFill(['fulfil_status' => 'picked', 'replace_until' => null])->saveQuietly();
            $order->log('مسئول پیگیری '.fa($added).' کالای جایگزین را تأیید کرد'.($reps->count() > $added ? ' و '.fa($reps->count() - $added).' کالا را رد کرد' : '').'. مبلغ سفارش: '.money($order->total).' تومان');
        });
        if ($added && $refer) {
            $this->refer($order->fresh());
        }

        return $added;
    }
}
