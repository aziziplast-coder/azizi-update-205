<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Throwable;

/** وضعیت زنده هاست: رم، دیسک، پردازنده، پایگاه داده و چک‌لیست سلامت */
class HostHealth
{
    protected static function read(string $file): string
    {
        return @is_readable($file) ? (string) @file_get_contents($file) : '';
    }

    public static function bytes(string $v): int
    {
        $v = trim($v);
        if ($v === '' || $v === '-1') {
            return -1;
        }
        $n = (float) $v;

        return (int) match (strtolower(substr($v, -1))) {
            'g' => $n * 1073741824,
            'm' => $n * 1048576,
            'k' => $n * 1024,
            default => $n,
        };
    }

    public static function size(float|int|null $b): string
    {
        if ($b === null || $b < 0) {
            return '—';
        }
        $u = ['بایت', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        while ($b >= 1024 && $i < 4) {
            $b /= 1024;
            $i++;
        }

        return fa(round($b, $i > 1 ? 1 : 0)).' '.$u[$i];
    }

    public static function memory(): ?array
    {
        $max = trim(static::read('/sys/fs/cgroup/memory.max'));
        $cur = trim(static::read('/sys/fs/cgroup/memory.current'));
        if (is_numeric($cur) && is_numeric($max) && (float) $max < 1e15) {
            return ['total' => (float) $max, 'used' => (float) $cur, 'src' => 'سهمیه حساب'];
        }
        $max = trim(static::read('/sys/fs/cgroup/memory/memory.limit_in_bytes'));
        $cur = trim(static::read('/sys/fs/cgroup/memory/memory.usage_in_bytes'));
        if (is_numeric($cur) && is_numeric($max) && (float) $max < 1e15) {
            return ['total' => (float) $max, 'used' => (float) $cur, 'src' => 'سهمیه حساب'];
        }
        $mi = static::read('/proc/meminfo');
        if (preg_match('/MemTotal:\s+(\d+)/', $mi, $t)) {
            $avail = preg_match('/MemAvailable:\s+(\d+)/', $mi, $a) ? (float) $a[1] : (preg_match('/MemFree:\s+(\d+)/', $mi, $f) ? (float) $f[1] : 0);

            return ['total' => (float) $t[1] * 1024, 'used' => ((float) $t[1] - $avail) * 1024, 'src' => 'سرور'];
        }

        return null;
    }

    public static function cpus(): int
    {
        static $n = null;
        if ($n === null) {
            $n = substr_count(static::read('/proc/cpuinfo'), 'processor') ?: 1;
            if (preg_match('/^(\d+)\s+(\d+)$/', trim(static::read('/sys/fs/cgroup/cpu.max')), $m) && (int) $m[2] > 0) {
                $n = max(1, min($n, (int) ceil($m[1] / $m[2])));
            }
        }

        return $n;
    }

    /** تعداد هسته‌های واقعی سرور (نه سهم سایت) از /sys؛ مثلاً «0-31» یعنی ۳۲ هسته */
    public static function serverCpus(): int
    {
        static $n = null;
        if ($n === null) {
            $n = 0;
            foreach (['/sys/devices/system/cpu/present', '/sys/devices/system/cpu/online', '/sys/devices/system/cpu/possible'] as $f) {
                $v = trim(static::read($f));
                if ($v === '') {
                    continue;
                }
                foreach (explode(',', $v) as $part) {
                    $n += preg_match('/^(\d+)-(\d+)$/', $part, $m) ? ((int) $m[2] - (int) $m[1] + 1) : (ctype_digit($part) ? 1 : 0);
                }
                break;
            }
            $n = max($n, static::cpus());
        }

        return $n;
    }

    /** هاست اشتراکی که تعداد هسته‌های سرور را نشان نمی‌دهد (بار سرور قابل تفسیر نیست) */
    public static function sharedUnknown(): bool
    {
        $d = static::disk();

        return static::serverCpus() <= static::cpus() && static::cpus() <= 2 && $d && $d['total'] > 1099511627776;
    }

    public static function disk(): ?array
    {
        $free = function_exists('disk_free_space') ? @disk_free_space(base_path()) : false;
        $total = function_exists('disk_total_space') ? @disk_total_space(base_path()) : false;
        if (! $free || ! $total) {
            return null;
        }

        return ['total' => (float) $total, 'used' => (float) $total - (float) $free, 'free' => (float) $free];
    }

    public static function live(): array
    {
        $t0 = microtime(true);
        try {
            DB::select('select 1');
        } catch (Throwable) {
        }
        $dbMs = (microtime(true) - $t0) * 1000;
        $load = function_exists('sys_getloadavg') ? @sys_getloadavg() : false;
        $mem = static::memory();
        $disk = static::disk();
        $cpus = static::cpus();

        return [
            'mem' => $mem,
            'mem_pct' => $mem ? round($mem['used'] / max(1, $mem['total']) * 100) : null,
            'disk' => $disk,
            'disk_pct' => $disk && $disk['total'] <= 1099511627776 ? round($disk['used'] / max(1, $disk['total']) * 100) : null, // دیسک چند ترابایتی = دیسک مشترک هاست؛ درصدش معنا ندارد
            'load' => $load ? array_map(fn ($v) => round((float) $v, 2), $load) : null,
            'cpu_pct' => $load && ! static::sharedUnknown() ? min(100, round($load[0] / max($cpus, static::serverCpus()) * 100)) : null,
            'cpus' => $cpus,
            'php_mem' => memory_get_peak_usage(true),
            'php_limit' => static::bytes((string) ini_get('memory_limit')),
            'db_ms' => round($dbMs, 1),
            'uptime' => (float) strtok(static::read('/proc/uptime') ?: '0', ' '),
            't' => now()->format('H:i:s'),
        ];
    }

    public static function dirSize(string $dir, float $deadline): float
    {
        $sum = 0.0;
        if (! is_dir($dir)) {
            return 0;
        }
        try {
            $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
            foreach ($it as $f) {
                if ($f->isFile()) {
                    $sum += $f->getSize();
                }
                if (microtime(true) > $deadline) {
                    break;
                }
            }
        } catch (Throwable) {
        }

        return $sum;
    }

    public static function sizes(bool $fresh = false): array
    {
        if ($fresh) {
            Cache::forget('health.sizes');
        }

        return Cache::remember('health.sizes', 3600, function () {
            $deadline = microtime(true) + 12;
            $out = [
                'رسانه گفتگوها (عکس، ویس، ویدیو)' => $chat = static::dirSize(public_path('uploads/chat'), $deadline),
                'تصاویر کالاها و سایت' => max(0, static::dirSize(public_path('uploads'), $deadline) - $chat),
                'فیش‌های واریزی' => static::dirSize(storage_path('app/private/receipts'), $deadline),
                'چک‌ها و بیجک‌ها' => static::dirSize(storage_path('app/private/cheques'), $deadline) + static::dirSize(storage_path('app/private/waybills'), $deadline),
                'پشتیبان‌ها' => static::dirSize(storage_path('app/backups'), $deadline),
                'گزارش خطاها (log)' => static::dirSize(storage_path('logs'), $deadline),
                'کش و نسخه‌های قبلی' => static::dirSize(storage_path('framework'), $deadline) + static::dirSize(storage_path('app/update'), $deadline),
                'کتابخانه‌ها (vendor)' => static::dirSize(base_path('vendor'), $deadline),
            ];
            try {
                if (DB::getDriverName() === 'mysql') {
                    $row = DB::selectOne('SELECT SUM(data_length + index_length) s FROM information_schema.tables WHERE table_schema = ?', [DB::getDatabaseName()]);
                    $out['پایگاه داده'] = (float) ($row->s ?? 0);
                } elseif (DB::getDriverName() === 'sqlite') {
                    $out['پایگاه داده'] = (float) @filesize(DB::getDatabaseName());
                }
            } catch (Throwable) {
            }
            arsort($out);

            return $out;
        });
    }

    public static function info(): array
    {
        $opc = function_exists('opcache_get_status') ? @opcache_get_status(false) : false;
        $db = '—';
        try {
            $db = (DB::getDriverName() === 'mysql' ? (str_contains(strtolower((string) DB::selectOne('select version() v')->v), 'mariadb') ? 'MariaDB ' : 'MySQL ') : DB::getDriverName().' ').DB::selectOne(DB::getDriverName() === 'sqlite' ? 'select sqlite_version() v' : 'select version() v')->v;
        } catch (Throwable) {
        }

        return [
            'نسخه فروشگاه' => config('store.version'),
            'سیستم‌عامل سرور' => php_uname('s').' '.php_uname('r'),
            'وب‌سرور' => $_SERVER['SERVER_SOFTWARE'] ?? '—',
            'نسخه PHP' => PHP_VERSION,
            'پایگاه داده' => $db,
            'Laravel' => app()->version(),
            'حافظه PHP' => (string) ini_get('memory_limit'),
            'حداکثر زمان اجرا' => ini_get('max_execution_time').' ثانیه',
            'حداکثر حجم آپلود' => (string) ini_get('upload_max_filesize'),
            'هسته پردازنده' => (string) static::cpus(),
            'OPcache' => $opc && ! empty($opc['opcache_enabled']) ? 'فعال' : 'غیرفعال',
            'منطقه زمانی' => config('app.timezone'),
        ];
    }

    /** @return array<int, array{0: string, 1: string, 2: string}> عنوان، good|warn|bad، توضیح */
    public static function checks(): array
    {
        $c = [];
        $php = PHP_VERSION;
        $c[] = ['نسخه PHP', version_compare($php, '8.3', '>=') ? 'good' : 'warn', version_compare($php, '8.3', '>=') ? $php.' — به‌روز و سریع.' : $php.' — کار می‌کند؛ برای سرعت بیشتر از پنل هاست 8.3 یا بالاتر را انتخاب کنید.'];
        $ml = static::bytes((string) ini_get('memory_limit'));
        $c[] = ['حافظه PHP', ($ml < 0 || $ml >= 256 * 1048576) ? 'good' : ($ml >= 128 * 1048576 ? 'warn' : 'bad'), ini_get('memory_limit').($ml > 0 && $ml < 256 * 1048576 ? ' — دست‌کم 256M پیشنهاد می‌شود.' : '')];
        if ($d = static::disk()) {
            // روی هاست اشتراکی «کل دیسک» مال همه سایت‌هاست؛ ملاک، فضای آزاد واقعی است نه درصد
            $gb = $d['free'] / 1073741824;
            $c[] = ['فضای دیسک', $gb >= 10 ? 'good' : ($gb >= 2 ? 'warn' : 'bad'), static::size($d['free']).' آزاد'.($d['total'] > 1099511627776 ? ' (دیسک مشترک سرور هاست)' : ' از '.static::size($d['total'])).'.'.($gb < 10 ? ' بکاپ‌های قدیمی را حذف کنید.' : '')];
        }
        if ($m = static::memory()) {
            $pct = $m['used'] / max(1, $m['total']) * 100;
            $c[] = ['رم ('.$m['src'].')', $pct < 80 ? 'good' : ($pct < 92 ? 'warn' : 'bad'), fa(round($pct)).'٪ در حال استفاده.'];
        }
        $load = function_exists('sys_getloadavg') ? @sys_getloadavg() : false;
        if ($load) {
            // load average کل سرور است؛ روی هاست اشتراکی (CloudLinux) سهم سایت ۱ هسته است ولی سرور هسته‌های زیادی دارد
            $phys = static::serverCpus();
            $shared = $phys > static::cpus();
            $d0 = static::disk();
            if (! $shared && static::cpus() <= 2 && $d0 && $d0['total'] > 1099511627776) {
                // هاست اشتراکی که تعداد هسته‌های سرور را نشان نمی‌دهد: عدد بار مال کل سرور است و ملاک سرعت این سایت نیست
                $c[] = ['بار پردازنده کل سرور هاست (۵ دقیقه)', 'good', fa(number_format($load[1], 2)).' — این عدد مربوط به کل سرور اشتراکی (همه سایت‌های هاست) است و ملاک سرعت این سایت نیست (سهم هر سایت روی هاست اشتراکی جدا محدود می‌شود).'];
                $load = false;
            }
        }
        if ($load) {
            $per = $load[1] / max(1, $shared ? $phys : static::cpus());
            $c[] = [$shared ? 'بار پردازنده کل سرور هاست (۵ دقیقه)' : 'بار پردازنده (۵ دقیقه)', $per < 0.8 ? 'good' : ($per < 1.5 ? 'warn' : 'bad'),
                fa(number_format($load[1], 2)).' روی '.fa($shared ? $phys : static::cpus()).' هسته'.($shared ? ' سرور (مشترک با سایت‌های دیگر هاست؛ سهم این سایت '.fa(static::cpus()).' هسته)' : '').'.'
                .($per >= 1.5 ? ($shared ? ' سرور هاست شلوغ است؛ اگر سایت کند شد به پشتیبانی هاست اطلاع دهید.' : ' پردازنده زیر فشار است.') : '')];
        }
        $opc = function_exists('opcache_get_status') ? @opcache_get_status(false) : false;
        $c[] = ['OPcache (کش کد PHP)', $opc && ! empty($opc['opcache_enabled']) ? 'good' : 'warn', $opc && ! empty($opc['opcache_enabled']) ? 'فعال است.' : 'غیرفعال؛ از پشتیبانی هاست بخواهید فعال کنند (سرعت تا ۳ برابر).'];
        $https = str_starts_with((string) config('app.url'), 'https') || request()->isSecure();
        $c[] = ['HTTPS', $https ? 'good' : 'bad', $https ? 'گواهی امنیتی فعال است.' : 'بدون HTTPS، درگاه پرداخت، اینماد و نصب اپ (PWA) کار نمی‌کنند.'];
        $c[] = ['نمایش خطاها', config('app.debug') ? 'bad' : 'good', config('app.debug') ? 'APP_DEBUG روشن است؛ در فایل .env خاموش (false) کنید.' : 'خطاها برای بازدیدکنندگان نمایش داده نمی‌شوند.'];
        $last = Cache::get('cron.last');
        $late = ! $last || abs(now()->diffInMinutes(\Illuminate\Support\Carbon::parse($last))) > 90;
        $c[] = ['کارهای زمان‌بندی‌شده', $late ? 'warn' : 'good', $late ? 'اخیراً اجرا نشده؛ کرون هاست را طبق راهنما تنظیم کنید (یا سایت بازدید داشته باشد).' : 'آخرین اجرا: '.jdate($last, true)];
        foreach (['zip' => 'ZipArchive (بکاپ و به‌روزرسانی)', 'curl' => 'cURL (درگاه و پیامک)', 'mbstring' => 'mbstring (متن فارسی)', 'gd' => 'GD (تصاویر کوچک webp)', 'intl' => 'intl', 'fileinfo' => 'fileinfo (آپلود فایل)'] as $ext => $label) {
            $ok = $ext === 'zip' ? class_exists('ZipArchive') : extension_loaded($ext);
            if ($ext === 'gd') {
                $ok = $ok && function_exists('imagewebp');
            }
            $c[] = ['افزونه PHP: '.$label, $ok ? 'good' : ($ext === 'intl' ? 'warn' : 'bad'), $ok ? 'نصب است.' : 'نصب نیست؛ از پشتیبانی هاست بخواهید.'];
        }
        foreach (['storage' => storage_path(), 'bootstrap/cache' => base_path('bootstrap/cache'), 'public/uploads' => public_path('uploads')] as $label => $dir) {
            $ok = is_dir($dir) && is_writable($dir);
            $c[] = ['دسترسی نوشتن: '.$label, $ok ? 'good' : 'bad', $ok ? 'درست است.' : 'قابل نوشتن نیست؛ دسترسی پوشه را 755 کنید.'];
        }
        $lastBackup = app(Backup::class)->lastTime();
        $c[] = ['آخرین پشتیبان', $lastBackup && $lastBackup->gt(now()->subHours(36)) ? 'good' : ($lastBackup ? 'warn' : 'bad'), $lastBackup ? jdate($lastBackup, true) : 'هنوز پشتیبانی گرفته نشده است.'];
        $sec = static::securityScan();
        $c[] = ['امنیت فایل‌ها', $sec ? 'bad' : 'good', $sec ? fa(count($sec)).' فایل اجرایی مشکوک در پوشه آپلود: '.implode('، ', array_slice($sec, 0, 3)) : 'فایل اجرایی در پوشه آپلود نیست.'];

        return $c;
    }

    /** فایل‌های PHP در پوشه آپلود (نشانه نفوذ) */
    public static function securityScan(): array
    {
        $out = [];
        $dir = public_path('uploads');
        if (! is_dir($dir)) {
            return [];
        }
        try {
            $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
            $n = 0;
            foreach ($it as $f) {
                if (++$n > 50000) {
                    break;
                }
                if ($f->isFile() && preg_match('/\.(php\d?|phtml|phar|pht|cgi|pl|sh)$/i', $f->getFilename())) {
                    $out[] = str_replace($dir.DIRECTORY_SEPARATOR, '', $f->getPathname());
                }
            }
        } catch (Throwable) {
        }

        return $out;
    }

    public static function score(array $checks): int
    {
        $s = 100;
        foreach ($checks as $c) {
            $s -= $c[1] === 'bad' ? 15 : ($c[1] === 'warn' ? 4 : 0);
        }

        return max(0, $s);
    }

    /** آخرین خطاهای ثبت‌شده در گزارش لاراول (جدیدترین اول) */
    public static function recentErrors(int $limit = 15): array
    {
        $files = glob(storage_path('logs/*.log')) ?: [];
        usort($files, fn ($a, $b) => filemtime($b) <=> filemtime($a));
        $out = [];
        foreach (array_slice($files, 0, 3) as $f) {
            $size = @filesize($f) ?: 0;
            $fh = @fopen($f, 'r');
            if (! $fh) {
                continue;
            }
            fseek($fh, max(0, $size - 400000));
            $text = (string) stream_get_contents($fh);
            fclose($fh);
            $parts = preg_split('/^(?=\[\d{4}-\d\d-\d\d[ T]\d\d:\d\d:\d\d)/m', $text) ?: [];
            foreach (array_reverse($parts) as $p) {
                if (! preg_match('/^\[([^\]]+)\]\s+\w+\.(ERROR|CRITICAL|ALERT|EMERGENCY):\s*(.*)$/m', $p, $m)) {
                    continue;
                }
                $msg = preg_replace('/\s*\{"(exception|userId)".*$/s', '', $m[3]);
                $lines = explode("\n", $p);
                $out[] = ['time' => $m[1], 'message' => $msg, 'full' => mb_substr(implode("\n", array_slice($lines, 0, 14)), 0, 4000)];
                if (count($out) >= $limit) {
                    return $out;
                }
            }
        }

        return $out;
    }
}
