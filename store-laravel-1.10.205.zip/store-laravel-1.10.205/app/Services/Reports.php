<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Support\Jalali;
use Illuminate\Database\Query\Builder as QB;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * گزارش‌های فروش. همه مبالغ تومان. سفارش‌های لغوشده، ناموفق و پرداخت‌نشده (درگاه) حساب نمی‌شوند.
 */
class Reports
{
    public const PERIODS = [
        'today' => 'امروز',
        'yesterday' => 'دیروز',
        '7d' => '۷ روز اخیر',
        '30d' => '۳۰ روز اخیر',
        'month' => 'این ماه (شمسی)',
        'last_month' => 'ماه قبل (شمسی)',
        '90d' => '۳ ماه اخیر',
        'year' => 'امسال (شمسی)',
        'all' => 'همه زمان‌ها',
        'custom' => 'بازه دلخواه',
    ];

    public const EXCLUDED = ['cancelled', 'failed', 'pending_payment'];

    public \Carbon\Carbon $from;

    public \Carbon\Carbon $to;

    public function __construct(?string $period = '30d', ?string $from = null, ?string $to = null)
    {
        $now = now();
        [$jy, $jm] = Jalali::fromGregorian((int) $now->format('Y'), (int) $now->format('n'), (int) $now->format('j'));
        $jStart = fn ($y, $m) => Carbon::create(...array_merge(Jalali::toGregorian($y, $m, 1), [0, 0, 0, config('app.timezone')]));
        [$this->from, $this->to] = match ($period) {
            'today' => [$now->copy()->startOfDay(), $now->copy()->endOfDay()],
            'yesterday' => [$now->copy()->subDay()->startOfDay(), $now->copy()->subDay()->endOfDay()],
            '7d' => [$now->copy()->subDays(6)->startOfDay(), $now->copy()->endOfDay()],
            'month' => [$jStart($jy, $jm), $now->copy()->endOfDay()],
            'last_month' => [$jStart($jm === 1 ? $jy - 1 : $jy, $jm === 1 ? 12 : $jm - 1), $jStart($jy, $jm)->subSecond()],
            '90d' => [$now->copy()->subDays(89)->startOfDay(), $now->copy()->endOfDay()],
            'year' => [$jStart($jy, 1), $now->copy()->endOfDay()],
            'all' => [Carbon::create(2000, 1, 1), $now->copy()->endOfDay()],
            'custom' => [
                Jalali::parse($from)?->startOfDay() ?? $now->copy()->subDays(29)->startOfDay(),
                Jalali::parse($to)?->endOfDay() ?? $now->copy()->endOfDay(),
            ],
            default => [$now->copy()->subDays(29)->startOfDay(), $now->copy()->endOfDay()],
        };
    }

    public function label(): string
    {
        return Jalali::format($this->from).' تا '.Jalali::format($this->to);
    }

    protected function orders(): QB
    {
        return DB::table('orders')->whereBetween('orders.created_at', [$this->from, $this->to])->whereNotIn('orders.status', self::EXCLUDED);
    }

    protected function items(): QB
    {
        return DB::table('order_items')->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->whereBetween('orders.created_at', [$this->from, $this->to])->whereNotIn('orders.status', self::EXCLUDED);
    }

    public function summary(): array
    {
        $o = $this->orders();
        $count = (clone $o)->count();
        $sales = (int) (clone $o)->sum('total');
        $items = (int) (clone $o)->sum('items_total');
        $days = max(1, (int) ceil($this->from->diffInDays($this->to)));
        // دوره قبل با همان طول برای مقایسه
        $len = $this->to->getTimestamp() - $this->from->getTimestamp();
        $prev = DB::table('orders')->whereBetween('created_at', [Carbon::createFromTimestamp($this->from->getTimestamp() - $len - 1), $this->from->copy()->subSecond()])
            ->whereNotIn('status', self::EXCLUDED)->sum('total');
        $units = $this->items();

        return [
            'sales' => $sales,
            'orders' => $count,
            'avg' => $count ? (int) round($sales / $count) : 0,
            'items' => $items,
            'units' => (int) (clone $units)->sum('order_items.units'),
            'cartons' => (int) (clone $units)->where('order_items.mode', 'carton')->sum(DB::raw('order_items.units / CASE WHEN order_items.per_carton > 0 THEN order_items.per_carton ELSE 1 END')),
            'retail_sales' => (int) (clone $units)->where('order_items.mode', 'retail')->sum('order_items.total'),
            'discount' => (int) (clone $o)->sum('discount_total'),
            'coupons' => (int) (clone $o)->sum('coupon_discount'),
            'shipping' => (int) (clone $o)->sum('shipping_cost'),
            'customers' => (int) (clone $o)->distinct()->count('user_id'),
            'new_customers' => User::query()->where('role', 'customer')->verified()->whereBetween('created_at', [$this->from, $this->to])->count(),
            'paid' => (int) (clone $o)->where('payment_status', 'paid')->sum('total'),
            'unpaid' => (int) (clone $o)->where('payment_status', '!=', 'paid')->sum('total'),
            'cancelled' => DB::table('orders')->whereBetween('created_at', [$this->from, $this->to])->whereIn('status', ['cancelled', 'failed'])->count(),
            'per_day' => (int) round($sales / $days),
            'prev' => (int) $prev,
            'growth' => $prev > 0 ? round(($sales - $prev) * 100 / $prev, 1) : null,
        ];
    }

    /** فروش روزانه برای نمودار (روزهای بدون فروش صفر) */
    public function daily(): array
    {
        $days = (int) $this->from->copy()->startOfDay()->diffInDays($this->to->copy()->startOfDay()) + 1;
        $group = $days > 120 ? 'month' : 'day';
        $rows = $this->orders()->get(['created_at', 'total']);
        $out = [];
        if ($group === 'day') {
            for ($d = $this->from->copy()->startOfDay(); $d->lte($this->to); $d->addDay()) {
                $out[$d->format('Y-m-d')] = ['label' => Jalali::format($d), 'short' => fa(explode('/', en_digits(Jalali::format($d)))[2]), 'total' => 0, 'count' => 0];
            }
            foreach ($rows as $r) {
                $k = Carbon::parse($r->created_at)->format('Y-m-d');
                if (isset($out[$k])) {
                    $out[$k]['total'] += $r->total;
                    $out[$k]['count']++;
                }
            }
        } else {
            foreach ($rows as $r) {
                $c = Carbon::parse($r->created_at);
                [$y, $m] = Jalali::fromGregorian((int) $c->format('Y'), (int) $c->format('n'), (int) $c->format('j'));
                $k = sprintf('%04d-%02d', $y, $m);
                $out[$k] ??= ['label' => Jalali::months()[$m - 1].' '.fa($y), 'short' => Jalali::months()[$m - 1], 'total' => 0, 'count' => 0];
                $out[$k]['total'] += $r->total;
                $out[$k]['count']++;
            }
            ksort($out);
        }

        return array_values($out);
    }

    /** @return array{head: array, rows: array} */
    public function table(string $key, ?int $productId = null): array
    {
        return match ($key) {
            'products' => $this->products(),
            'product' => $this->product($productId),
            'categories' => $this->categories(),
            'customers' => $this->customers(),
            'staff' => $this->staff(),
            'cities' => $this->cities(),
            'payments' => $this->group('payment_method', 'payment_title', 'شیوه تسویه'),
            'shipping' => $this->group('shipping_method', 'shipping_title', 'شیوه ارسال'),
            'statuses' => $this->statuses(),
            'coupons' => $this->coupons(),
            'stock' => $this->stock(),
            'unsold' => $this->unsold(),
            default => ['head' => [], 'rows' => []],
        };
    }

    protected function products(): array
    {
        $rows = $this->items()->groupBy('order_items.product_id', 'order_items.name')
            ->selectRaw('order_items.product_id, order_items.name, COUNT(DISTINCT orders.id) as orders, SUM(order_items.units) as units,
                SUM(CASE WHEN order_items.mode = ? THEN order_items.units ELSE 0 END) as retail_units, SUM(order_items.total) as total', ['retail'])
            ->orderByDesc('total')->limit(500)->get();
        $sum = max(1, (int) $rows->sum('total'));

        return ['head' => ['کالا', 'سفارش', 'تعداد کل (عدد)', 'تکی (عدد)', 'مبلغ فروش', 'سهم از فروش'], 'rows' => $rows->map(fn ($r) => [
            $r->name, (int) $r->orders, (int) $r->units, (int) $r->retail_units, (int) $r->total, round($r->total * 100 / $sum, 1).'%',
        ])->all(), 'money' => [4]];
    }

    protected function product(?int $id): array
    {
        if (! $id) {
            return ['head' => [], 'rows' => []];
        }
        $rows = $this->items()->where('order_items.product_id', $id)
            ->orderByDesc('orders.created_at')->limit(500)
            ->get(['orders.number', 'orders.created_at', 'orders.customer_name', 'orders.city', 'order_items.mode', 'order_items.units', 'order_items.unit_price', 'order_items.total']);

        return ['head' => ['سفارش', 'تاریخ', 'مشتری', 'شهر', 'نوع', 'تعداد', 'قیمت واحد', 'مبلغ'], 'rows' => $rows->map(fn ($r) => [
            $r->number, Jalali::format($r->created_at, true), $r->customer_name, $r->city, $r->mode === 'retail' ? 'تکی' : 'کارتنی', (int) $r->units, (int) $r->unit_price, (int) $r->total,
        ])->all(), 'money' => [6, 7]];
    }

    protected function categories(): array
    {
        $rows = $this->items()->leftJoin('products', 'products.id', '=', 'order_items.product_id')->leftJoin('categories', 'categories.id', '=', 'products.category_id')
            ->groupBy('categories.id', 'categories.name')
            ->selectRaw('categories.name as name, COUNT(DISTINCT orders.id) as orders, SUM(order_items.units) as units, SUM(order_items.total) as total')
            ->orderByDesc('total')->get();
        $sum = max(1, (int) $rows->sum('total'));

        return ['head' => ['دسته', 'سفارش', 'تعداد (عدد)', 'مبلغ فروش', 'سهم'], 'rows' => $rows->map(fn ($r) => [
            $r->name ?: 'بدون دسته', (int) $r->orders, (int) $r->units, (int) $r->total, round($r->total * 100 / $sum, 1).'%',
        ])->all(), 'money' => [3]];
    }

    protected function customers(): array
    {
        $rows = $this->orders()->groupBy('orders.mobile')
            ->selectRaw('orders.mobile, MAX(orders.customer_name) as name, MAX(orders.company) as company, MAX(orders.city) as city, COUNT(*) as orders, SUM(orders.total) as total, MAX(orders.created_at) as last')
            ->orderByDesc('total')->limit(300)->get();

        return ['head' => ['مشتری', 'فروشگاه', 'موبایل', 'شهر', 'سفارش', 'جمع خرید', 'آخرین خرید'], 'rows' => $rows->map(fn ($r) => [
            $r->name, $r->company, $r->mobile, $r->city, (int) $r->orders, (int) $r->total, Jalali::format($r->last),
        ])->all(), 'money' => [5]];
    }

    protected function staff(): array
    {
        $out = [];
        $base = DB::table('orders')->whereBetween('created_at', [$this->from, $this->to]);
        foreach (User::query()->whereIn('role', ['admin', 'staff', 'keeper'])->orderBy('name')->get() as $u) {
            $mine = (clone $base)->where('assignee_id', $u->id);
            $total = (clone $mine)->count();
            $done = (clone $mine)->whereIn('status', ['completed', 'shipped'])->count();
            $open = Order::query()->where('assignee_id', $u->id)->whereIn('status', Order::OPEN)->count();
            $over = Order::overdueQuery($u->id)->count();
            $events = DB::table('order_events')->where('user_id', $u->id)->whereBetween('created_at', [$this->from, $this->to])->count();
            if (! $total && ! $open && ! $events) {
                continue;
            }
            $out[] = [$u->displayName(), $total, $done, $open, $over, $events, $total ? round($done * 100 / $total).'%' : '—'];
        }

        return ['head' => ['کارمند', 'سفارش سپرده‌شده', 'ارسال/تکمیل', 'باز فعلی', 'عقب‌افتاده فعلی', 'اقدام‌های ثبت‌شده', 'درصد انجام'], 'rows' => $out];
    }

    protected function cities(): array
    {
        $rows = $this->orders()->groupBy('orders.province', 'orders.city')
            ->selectRaw('orders.province, orders.city, COUNT(*) as orders, SUM(orders.total) as total')->orderByDesc('total')->limit(300)->get();

        return ['head' => ['استان', 'شهر', 'سفارش', 'مبلغ'], 'rows' => $rows->map(fn ($r) => [$r->province, $r->city, (int) $r->orders, (int) $r->total])->all(), 'money' => [3]];
    }

    protected function group(string $col, string $title, string $label): array
    {
        $rows = $this->orders()->groupBy($col)->selectRaw("MAX($title) as t, COUNT(*) as orders, SUM(total) as total")->orderByDesc('total')->get();

        return ['head' => [$label, 'سفارش', 'مبلغ'], 'rows' => $rows->map(fn ($r) => [preg_replace('/ — .*/u', '', (string) $r->t), (int) $r->orders, (int) $r->total])->all(), 'money' => [2]];
    }

    protected function statuses(): array
    {
        $rows = DB::table('orders')->whereBetween('created_at', [$this->from, $this->to])->groupBy('status')
            ->selectRaw('status, COUNT(*) as orders, SUM(total) as total')->orderByDesc('orders')->get();

        return ['head' => ['وضعیت', 'سفارش', 'مبلغ'], 'rows' => $rows->map(fn ($r) => [Order::STATUSES[$r->status] ?? $r->status, (int) $r->orders, (int) $r->total])->all(), 'money' => [2]];
    }

    protected function coupons(): array
    {
        $rows = DB::table('coupon_usages')->join('coupons', 'coupons.id', '=', 'coupon_usages.coupon_id')
            ->whereBetween('coupon_usages.created_at', [$this->from, $this->to])->groupBy('coupons.id', 'coupons.code', 'coupons.title')
            ->selectRaw('coupons.code, coupons.title, COUNT(*) as uses, SUM(coupon_usages.amount) as amount')->orderByDesc('uses')->get();

        return ['head' => ['کد', 'عنوان', 'تعداد استفاده', 'مجموع تخفیف'], 'rows' => $rows->map(fn ($r) => [$r->code, $r->title, (int) $r->uses, (int) $r->amount])->all(), 'money' => [3]];
    }

    protected function stock(): array
    {
        $rows = Product::query()->where('is_active', true)->whereNotNull('stock')->whereRaw('stock < per_carton * 2')
            ->orderBy('stock')->limit(300)->get(['name', 'barcode', 'stock', 'per_carton', 'retail_stock', 'sales_count']);

        return ['head' => ['کالا', 'بارکد', 'موجودی عمده (عدد)', 'معادل کارتن', 'موجودی خرده', 'تعداد فروش'], 'rows' => $rows->map(fn ($p) => [
            $p->name, $p->barcode, (int) $p->stock, round($p->stock / max(1, $p->per_carton), 1), $p->retail_stock, (int) $p->sales_count,
        ])->all()];
    }

    protected function unsold(): array
    {
        $sold = $this->items()->distinct()->pluck('order_items.product_id')->filter()->all();
        $rows = Product::query()->where('is_active', true)->whereNotIn('id', $sold ?: [0])->orderByDesc('views')->limit(300)->get(['name', 'barcode', 'price', 'views', 'stock']);

        return ['head' => ['کالا', 'بارکد', 'قیمت', 'بازدید', 'موجودی'], 'rows' => $rows->map(fn ($p) => [$p->name, $p->barcode, (int) $p->price, (int) $p->views, $p->stock])->all(), 'money' => [2]];
    }
}
