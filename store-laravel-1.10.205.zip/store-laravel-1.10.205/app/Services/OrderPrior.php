<?php

namespace App\Services;

use App\Models\Order;
use App\Models\RemitPayment;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\ValidationException;

/**
 * مانده قبلی مشتری در حسابداری هلو (طلب/بدهی) + مشتری جدید و «چک ضمانت»
 *
 * holoo_bal: مثبت = مشتری از قبل بدهکار است (به مبلغ قابل پرداخت اضافه می‌شود)
 *            منفی = مشتری از قبل طلبکار است (از مبلغ قابل پرداخت کم می‌شود)
 * هر دو را اپراتور هنگام صدور بیعانه یا مانده حساب وارد می‌کند (از هلو می‌بیند و دستی می‌نویسد).
 */
class OrderPrior
{
    public const GUAR_ST = [
        'awaiting' => 'منتظر ارسال مشتری', 'submitted' => 'رسید — در حال بررسی', 'confirmed' => 'تأیید شد', 'rejected' => 'تأیید نشد',
    ];

    public static function on(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('orders', 'holoo_bal');
    }

    public static function bal(Order $o): int
    {
        return static::on() ? (int) $o->holoo_bal : 0;
    }

    public static function balLabel(int $bal): string
    {
        return $bal > 0 ? 'بدهی قبلی شما در حسابداری' : 'طلب قبلی شما در حسابداری';
    }

    public static function guarDefault(): int
    {
        return max(0, (int) setting('guarantee_amount', 0));
    }

    /** مقدار پیش‌فرض فرم‌ها */
    public static function fill(Order $o): array
    {
        if (! static::on()) {
            return [];
        }
        $bal = (int) $o->holoo_bal;
        $new = $o->new_customer || ($o->guarantee === null && Cheques::isNewCustomer($o->user, $o->id));

        return [
            'holoo_type' => $bal > 0 ? 'debt' : ($bal < 0 ? 'credit' : 'none'),
            'holoo_amount' => $bal ? abs($bal) : null,
            'new_customer' => $new,
            'guar_amount' => (int) (((array) $o->guarantee)['amount'] ?? 0) ?: (static::guarDefault() ?: null),
        ];
    }

    /** مبلغ امضادار از ورودی فرم (نوع: none | debt | credit) */
    public static function balFrom(?string $type, $amount): ?int
    {
        $a = (int) to_int($amount ?? 0);
        if ($a <= 0 || ! in_array($type, ['debt', 'credit'], true)) {
            return null;
        }

        return $type === 'debt' ? $a : -$a;
    }

    /** ثبت مانده قبلی هلو */
    public static function setBal(Order $o, ?int $bal, ?bool $inDeposit = null, ?User $by = null): void
    {
        if (! static::on()) {
            return;
        }
        $old = (int) $o->holoo_bal;
        $o->holoo_bal = $bal ?: null;
        if ($inDeposit !== null) {
            $o->holoo_dep = $inDeposit && $bal;
        }
        $o->saveQuietly();
        if ($old !== (int) $bal) {
            $o->log($bal ? 'مانده قبلی مشتری در هلو: '.($bal > 0 ? 'بدهکار ' : 'بستانکار ').money(abs($bal)).' تومان' : 'مانده قبلی هلو برداشته شد', $by?->id);
        }
    }

    /** مشتری جدید + مبلغ چک ضمانت (مدارک قبلی همان مبلغ حفظ می‌شود) */
    public static function setNew(Order $o, bool $on, int $amount, ?User $by = null): void
    {
        if (! static::on()) {
            return;
        }
        $g = (array) $o->guarantee;
        if ($on && $amount <= 0) {
            throw ValidationException::withMessages(['guar_amount' => 'مبلغ چک ضمانت مشتری جدید را بنویسید.']);
        }
        $was = (bool) $o->new_customer;
        $oldAmt = (int) ($g['amount'] ?? 0);
        $o->new_customer = $on;
        if ($on) {
            if ((int) ($g['amount'] ?? 0) !== $amount) {
                $g = ['amount' => $amount, 'st' => 'awaiting'];
            }
            $o->guarantee = $g;
        } elseif (($g['st'] ?? '') !== 'confirmed') {
            $o->guarantee = null;
        }
        $o->saveQuietly();
        if ($was !== $on || ($on && $oldAmt !== $amount)) {
            $o->log($on ? 'مشتری جدید — چک ضمانت '.money($amount).' تومان خواسته شد' : 'علامت مشتری جدید برداشته شد', $by?->id);
            if ($on) {
                Chat::event($o, '🛡 چون اولین خرید شماست، یک چک ضمانت به مبلغ '.money($amount).' تومان لازم است؛ در کارت مانده حساب عکس چک را بفرستید.');
            }
        }
    }

    /** سفارش چکی (پرداخت «چک» یا شیوه تسویه بعداً به چک تغییر کرده) ← چک ضمانت مشتری جدید فقط برای همین‌ها، هنگام صدور مانده حساب */
    public static function chequeOrder(Order $o): bool
    {
        $c = (array) $o->cheque;

        return $o->payment_method === 'cheque' || ! empty($c['settle']) || ! empty($c['cheques']);
    }

    /** فرم صدور (پنل یا گفتگو) ← ذخیره؛ مبلغ بیعانه را (اگر خواسته شده) با مانده هلو برمی‌گرداند */
    public static function apply(Order $o, array $d, ?User $by, ?int $deposit = null): ?int
    {
        if (! static::on()) {
            return $deposit;
        }
        $bal = static::balFrom($d['holoo_type'] ?? null, $d['holoo_amount'] ?? null);
        $inDep = $deposit !== null && ! empty($d['holoo_in_dep']);
        if (array_key_exists('holoo_type', $d)) { // فرم بیعانه دیگر مانده هلو ندارد؛ مقدار قبلی دست نخورد
            static::setBal($o, $bal, $deposit !== null ? $inDep : null, $by);
        }
        if (array_key_exists('new_customer', $d)) {
            static::setNew($o, (bool) $d['new_customer'], (int) to_int($d['guar_amount'] ?? 0), $by);
        }

        return $deposit !== null && $inDep && $bal ? max(0, $deposit + $bal) : $deposit;
    }

    /* ---------------- چک ضمانت: ارسال مشتری و بررسی ---------------- */

    public static function submitGuar(Order $o, ?UploadedFile $img): void
    {
        $g = (array) $o->guarantee;
        if (! $o->new_customer || ! $g || ! in_array($g['st'] ?? '', ['awaiting', 'rejected'], true)) {
            throw ValidationException::withMessages(['guar' => 'چک ضمانت الان قابل ارسال نیست.']);
        }
        if (! $img) {
            throw ValidationException::withMessages(['guar' => 'عکس چک ضمانت را انتخاب کنید.']);
        }
        $g['path'] = \App\Support\DocImages::store($img, 'cheques/'.$o->id, 'guar-'.substr(md5(uniqid('', true)), 0, 10));
        $g['st'] = 'submitted';
        $g['reason'] = null;
        $g['at'] = now()->toIso8601String();
        $o->guarantee = $g;
        $o->saveQuietly();
        $o->log('مشتری عکس چک ضمانت را فرستاد');
        if ($t = Chat::thread($o, false)) {
            Chat::notifyStaff($t, $o, '🛡 چک ضمانت مشتری رسید؛ بررسی کنید.');
        }
        static::refresh($o);
    }

    public static function reviewGuar(Order $o, bool $ok, ?string $reason, ?User $by): void
    {
        $g = (array) $o->guarantee;
        abort_unless($g && ($g['st'] ?? '') === 'submitted', 422, 'چک ضمانتی برای بررسی نیست.');
        $g['st'] = $ok ? 'confirmed' : 'rejected';
        $g['reason'] = $ok ? null : mb_substr(trim((string) $reason), 0, 200);
        $g['by'] = $by?->id;
        $o->guarantee = $g;
        $o->saveQuietly();
        $o->log('چک ضمانت '.($ok ? 'تأیید شد' : 'رد شد: '.$g['reason']), $by?->id);
        Chat::event($o, $ok ? '🛡 چک ضمانت شما تأیید شد. ممنون.' : '🛡 چک ضمانت تأیید نشد: '.$g['reason'].' — لطفاً دوباره بفرستید.');
        static::refresh($o);
    }

    /** کارت‌های گفتگو دوباره خوانده شوند */
    public static function refresh(Order $o): void
    {
        if ($t = Chat::thread($o, false)) {
            Chat::signal($t, ['d' => (int) round(microtime(true) * 10)]);
            Chat::staffSignal($t->assignee_id);
        }
    }

    /* ---------------- داده کارت‌های گفتگو ---------------- */

    /** بخش «چک ضمانت» روی کارت مانده حساب */
    public static function guarFor(RemitPayment $p, bool $staff, ?User $u = null): ?array
    {
        $o = $p->order;
        if (! static::on() || ! $o || ! $o->new_customer || ! ($g = (array) $o->guarantee)) {
            return null;
        }
        $all = RemitPayment::query()->where('order_id', $o->id)->where('status', '!=', 'cancelled')->orderBy('id')->get(['id', 'kind', 'status']);
        // چک ضمانت هنگام صدور مانده حساب خواسته می‌شود ← روی (آخرین) کارت مانده حساب؛ سفارش‌های قدیمی که در بیعانه خواسته شده بود، روی بیعانه
        $host = $all->where('kind', 'settle')->last() ?? $all->firstWhere('kind', 'deposit');
        if (! $host || (int) $host->id !== (int) $p->id) {
            return null;
        }
        $st = (string) ($g['st'] ?? 'awaiting');

        return [
            'amount' => money((int) ($g['amount'] ?? 0)), 'st' => $st, 'st_label' => self::GUAR_ST[$st] ?? $st,
            'sayad' => ! empty($g['sayad']) ? fa((string) $g['sayad']) : '', 'reason' => (string) ($g['reason'] ?? ''),
            'url' => ! empty($g['path']) ? ($staff ? route('admin.cheque', [$o->id, 0, 't' => 'guar']) : route('order.cheque.img', [$o->number, 0, 't' => 'guar'])) : null,
            'payee' => Cheques::payeeDefault(),
            'can_send' => ! $staff && in_array($st, ['awaiting', 'rejected'], true),
            'can_review' => $staff && $st === 'submitted' && $u && (Remit::canWork($u) || (int) $o->assignee_id === (int) $u->id),
        ];
    }

    /** توضیح ساده مبلغ کارت: فاکتور ± مانده هلو − واریزی‌های قبلی = قابل پرداخت */
    public static function calc(RemitPayment $p): ?array
    {
        $o = $p->order;
        if (! $o || ! in_array($p->kind, ['deposit', 'settle'], true)) {
            return null;
        }
        $bal = static::bal($o);
        $all = RemitPayment::query()->where('order_id', $o->id)->where('status', '!=', 'cancelled')->orderBy('id')->get(['id', 'kind', 'amount', 'status']);
        $mine = $all->where('kind', $p->kind);
        if ((int) ($mine->first()?->id) !== (int) $p->id) {
            return null; // فقط روی اولین کارت همین بابت
        }
        $sum = (int) $mine->sum('amount');
        $lines = [];
        if ($p->kind === 'deposit') {
            if (! $o->holoo_dep || ! $bal) {
                return null;
            }
            $lines[] = ['بیعانه سفارش', money(max(0, $sum - $bal))];
            $lines[] = [static::balLabel($bal), ($bal > 0 ? '+ ' : '− ').money(abs($bal))];
            $total = 'جمع قابل پرداخت';
        } else {
            $base = $o->cash_amount !== null ? (int) $o->cash_amount : (int) ($o->final_amount ?: $o->total);
            $before = (int) $all->where('kind', '!=', 'settle')->whereIn('status', ['confirmed', 'submitted'])->sum('amount');
            $lines[] = [$o->cash_amount !== null ? 'سهم نقدی فاکتور' : 'مبلغ نهایی فاکتور', money($base)];
            if ($bal) {
                $lines[] = [static::balLabel($bal), ($bal > 0 ? '+ ' : '− ').money(abs($bal))];
            }
            if ($before > 0) {
                $lines[] = ['واریزی‌های قبلی شما (بیعانه)', '− '.money($before)];
            }
            $total = 'مانده قابل پرداخت';
        }
        $lines[] = [$total, money($sum), 1];

        return ['lines' => $lines, 'note' => $mine->count() > 1 ? 'این مبلغ در '.fa($mine->count()).' کارت (به '.fa($mine->count()).' حساب) جدا صادر شده؛ هر کارت را جدا واریز کنید.' : null];
    }
}
