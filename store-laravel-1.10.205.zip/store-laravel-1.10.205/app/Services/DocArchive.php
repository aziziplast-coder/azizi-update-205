<?php

namespace App\Services;

use App\Models\RemitPayment;
use App\Support\ImageCompressor;
use App\Support\Jalali;
use App\Support\Settings;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;
use Throwable;
use ZipArchive;

/**
 * بایگانی فیش‌ها و مدارک: محل ذخیره، حجم، فشرده‌سازی فیش‌های قدیمی، پاک‌کردن اختیاری و دانلود ماهانه.
 *
 * مسیرها (پوشه خصوصی؛ از اینترنت مستقیم باز نمی‌شوند، فقط از پنل با دسترسی):
 *   storage/app/private/receipts/<شناسه سفارش>/   فیش‌های واریزی مشتری‌ها
 *   storage/app/private/cheques/<شناسه سفارش>/    تصویر چک‌ها
 *   storage/app/private/waybills/<شناسه سفارش>/   بیجک‌های باربری
 *   public/uploads/chat/<سال-ماه>/                  عکس، ویس و ویدیوی گفتگوها
 */
class DocArchive
{
    /** فیش قدیمی: کوچک‌تر ولی خوانا */
    public const OLD_SIDE = 1500;

    public const OLD_QUALITY = 72;

    public static function cats(): array
    {
        return [
            'receipts' => ['title' => 'فیش‌های واریزی مشتری‌ها', 'icon' => '🧾', 'path' => 'storage/app/private/receipts/ORDER-ID/', 'abs' => storage_path('app/private/receipts'), 'note' => 'مدرک مالی؛ خودکار پاک نمی‌شود مگر «پاک کردن فیش‌های خیلی قدیمی» را روشن کنید.'],
            'cheques' => ['title' => 'تصویر چک‌ها', 'icon' => '🏦', 'path' => 'storage/app/private/cheques/ORDER-ID/', 'abs' => storage_path('app/private/cheques'), 'note' => 'همیشه نگه داشته می‌شود.'],
            'waybills' => ['title' => 'بیجک‌های باربری', 'icon' => '🚚', 'path' => 'storage/app/private/waybills/ORDER-ID/', 'abs' => storage_path('app/private/waybills'), 'note' => 'همیشه نگه داشته می‌شود.'],
            'chat' => ['title' => 'عکس، ویس و ویدیوی گفتگوها', 'icon' => '💬', 'path' => 'public/uploads/chat/YYYY-MM/', 'abs' => public_path('uploads/chat'), 'note' => 'بعد از '.fa(Chat::cfg()['img_days']).' روز خودکار پاک می‌شود (متن پیام‌ها می‌ماند).'],
        ];
    }

    public static function cfg(): array
    {
        $c = (array) setting('doc_archive', []);

        return [
            'shrink' => (bool) ($c['shrink'] ?? true),
            'shrink_months' => max(1, min(36, (int) ($c['shrink_months'] ?? 6))),
            'delete_years' => max(0, min(10, (int) ($c['delete_years'] ?? 0))), // ۰ = هرگز
        ];
    }

    public static function save(array $c): void
    {
        Settings::set(['doc_archive' => [
            'shrink' => (bool) ($c['shrink'] ?? true),
            'shrink_months' => max(1, min(36, (int) ($c['shrink_months'] ?? 6))),
            'delete_years' => max(0, min(10, (int) ($c['delete_years'] ?? 0))),
        ]]);
    }

    public static function human(float $b): string
    {
        if ($b >= 1073741824) {
            return fa(number_format($b / 1073741824, 2)).' گیگابایت';
        }
        if ($b >= 1048576) {
            return fa(number_format($b / 1048576, 1)).' مگابایت';
        }

        return fa(number_format($b / 1024)).' کیلوبایت';
    }

    /**
     * حجم و تعداد هر پوشه + ماه‌به‌ماه فیش‌ها (کش یک ساعته؛ شمردن با سقف زمان تا فشاری به هاست نیاید)
     */
    public static function stats(bool $fresh = false): array
    {
        if ($fresh) {
            Cache::forget('docarch.stats');
        }

        return Cache::remember('docarch.stats', 3600, function () {
            $deadline = microtime(true) + 10;
            $out = ['cats' => [], 'months' => [], 'at' => now()->timestamp, 'partial' => false];
            foreach (static::cats() as $k => $c) {
                $n = 0;
                $size = 0.0;
                if (is_dir($c['abs'])) {
                    try {
                        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($c['abs'], \FilesystemIterator::SKIP_DOTS)) as $f) {
                            if ($f->isFile() && $f->getFilename()[0] !== '.') {
                                $n++;
                                $size += $f->getSize();
                            }
                            if (microtime(true) > $deadline) {
                                $out['partial'] = true;
                                break;
                            }
                        }
                    } catch (Throwable) {
                    }
                }
                $out['cats'][$k] = ['n' => $n, 'size' => $size];
            }
            // فیش‌ها ماه‌به‌ماه (بر اساس تاریخ ثبت پرداخت)
            try {
                $disk = Storage::disk('local');
                RemitPayment::query()->where(fn ($q) => $q->whereNotNull('receipt_path')->orWhereNotNull('receipt_files'))
                    ->select(['id', 'receipt_path', 'receipt_files', 'status', 'created_at', 'submitted_at'])->orderBy('id')
                    ->chunkById(500, function ($rows) use (&$out, $disk, $deadline) {
                        foreach ($rows as $p) {
                            $files = $p->files();
                            if (! $files) {
                                continue;
                            }
                            $m = static::ym($p->submitted_at ?? $p->created_at);
                            $out['months'][$m] ??= ['n' => 0, 'size' => 0.0, 'confirmed' => 0];
                            foreach ($files as $f) {
                                $out['months'][$m]['n']++;
                                if (microtime(true) < $deadline) {
                                    $out['months'][$m]['size'] += (float) (@filesize($disk->path($f)) ?: 0);
                                }
                            }
                            if ($p->status === 'confirmed') {
                                $out['months'][$m]['confirmed']++;
                            }
                        }
                    });
                krsort($out['months']);
            } catch (Throwable $e) {
                report($e);
            }

            return $out;
        });
    }

    /** «1405-08» */
    public static function ym(mixed $date): string
    {
        $d = Carbon::parse($date ?? now())->timezone('Asia/Tehran');
        [$y, $m] = Jalali::fromGregorian((int) $d->format('Y'), (int) $d->format('n'), (int) $d->format('j'));

        return sprintf('%04d-%02d', $y, $m);
    }

    public static function ymLabel(string $ym): string
    {
        [$y, $m] = array_map('intval', explode('-', $ym) + [0, 0]);

        return (Jalali::months()[$m - 1] ?? $m).' '.fa($y);
    }

    /** بازه میلادی یک ماه شمسی */
    protected static function range(string $ym): array
    {
        [$y, $m] = array_map('intval', explode('-', $ym));
        [$gy, $gm, $gd] = Jalali::toGregorian($y, $m, 1);
        [$ny, $nm] = $m === 12 ? [$y + 1, 1] : [$y, $m + 1];
        [$hy, $hm, $hd] = Jalali::toGregorian($ny, $nm, 1);

        return [Carbon::create($gy, $gm, $gd, 0, 0, 0, 'Asia/Tehran')->utc(), Carbon::create($hy, $hm, $hd, 0, 0, 0, 'Asia/Tehran')->utc()];
    }

    /**
     * فایل zip فیش‌های یک ماه (نام هر فایل: شماره سفارش، مبلغ، وضعیت) — برای بایگانی روی کامپیوتر
     */
    public static function zipMonth(string $ym): ?string
    {
        if (! preg_match('/^\d{4}-\d{2}$/', $ym) || ! class_exists(ZipArchive::class)) {
            return null;
        }
        @set_time_limit(300);
        [$from, $to] = static::range($ym);
        $dir = storage_path('app/tmp');
        @mkdir($dir, 0775, true);
        foreach (glob($dir.'/fish-*.zip') ?: [] as $old) {
            if (@filemtime($old) < time() - 3600) {
                @unlink($old);
            }
        }
        $path = $dir.'/fish-'.$ym.'-'.substr(md5(uniqid('', true)), 0, 6).'.zip';
        $zip = new ZipArchive;
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            return null;
        }
        $disk = Storage::disk('local');
        $st = ['confirmed' => 'تاییدشده', 'submitted' => 'منتظرتایید', 'rejected' => 'ردشده', 'cancelled' => 'باطل', 'awaiting' => 'منتظر'];
        $n = 0;
        $list = "شماره سفارش\tمبلغ\tوضعیت\tکد پیگیری\tتاریخ\tفایل\n";
        RemitPayment::query()->with(['order:id,number'])
            ->whereBetween(\Illuminate\Support\Facades\DB::raw('COALESCE(submitted_at, created_at)'), [$from, $to])
            ->orderBy('id')->chunkById(300, function ($rows) use ($zip, $disk, $st, &$n, &$list) {
                foreach ($rows as $p) {
                    foreach ($p->files() as $i => $f) {
                        $abs = $disk->path($f);
                        if (! is_file($abs)) {
                            continue;
                        }
                        $name = trim(($p->order->number ?? 'o'.$p->order_id).'-'.$p->amount.'-'.($st[$p->status] ?? $p->status).'-p'.$p->id.($i ? '-'.($i + 1) : ''))
                            .'.'.(strtolower(pathinfo($f, PATHINFO_EXTENSION)) ?: 'jpg');
                        $zip->addFile($abs, $name);
                        $list .= ($p->order->number ?? '')."\t".$p->amount."\t".($p->statusLabel())."\t".$p->receipt_ref."\t".Jalali::format($p->submitted_at ?? $p->created_at, true)."\t".$name."\n";
                        $n++;
                    }
                }
            });
        $zip->addFromString('فهرست.txt', "\xEF\xBB\xBF".$list);
        $zip->close();

        if (! $n) {
            @unlink($path);

            return null;
        }

        return $path;
    }

    /**
     * کار روزانه (از زمان‌بند): فشرده‌سازی فیش‌های تأییدشده قدیمی و (اگر روشن باشد) پاک کردن فیش‌های خیلی قدیمی.
     * هر بار تعداد کمی، تا فشاری به هاست نیاید.
     */
    public static function tick(int $max = 15): array
    {
        $c = static::cfg();
        $done = ['shrunk' => 0, 'deleted' => 0, 'saved' => 0];
        try {
            if ($c['shrink'] && ! Cache::get('docarch.shrink.pause')) {
                $done = static::shrinkOld($max) + $done;
            }
            if ($c['delete_years'] > 0 && Cache::add('docarch.del', 1, 86400)) {
                $done['deleted'] = static::deleteOld($c['delete_years']);
            }
        } catch (Throwable $e) {
            report($e);
        }

        return $done;
    }

    /** فیش‌های تأییدشده/باطل که بیش از N ماه از آن‌ها گذشته ← ۱۵۰۰ پیکسل، کیفیت ۷۲ (تقریباً نصف حجم، خوانا) */
    public static function shrinkOld(int $max = 15): array
    {
        $c = static::cfg();
        $disk = Storage::disk('local');
        $cur = (int) Cache::get('docarch.shrink.cur', 0);
        $n = 0;
        $saved = 0;
        $rows = RemitPayment::query()->where('id', '>', $cur)->whereIn('status', ['confirmed', 'cancelled'])
            ->where('created_at', '<', now()->subMonths($c['shrink_months']))
            ->where(fn ($q) => $q->whereNotNull('receipt_path')->orWhereNotNull('receipt_files'))
            ->orderBy('id')->limit(60)->get(['id', 'receipt_path', 'receipt_files']);
        if ($rows->isEmpty()) {
            // دور تمام شد؛ فردا دوباره از اول (فیش‌هایی که تازه قدیمی شده‌اند)
            Cache::put('docarch.shrink.cur', 0, 86400 * 60);
            Cache::put('docarch.shrink.pause', 1, 86400);

            return ['shrunk' => 0, 'saved' => 0];
        }
        foreach ($rows as $p) {
            Cache::put('docarch.shrink.cur', $p->id, 86400 * 60);
            $files = $p->files();
            $changed = false;
            foreach ($files as $i => $f) {
                if (RemitPayment::isPdfPath($f) || ! $disk->exists($f) || $disk->size($f) < 200 * 1024) {
                    continue;
                }
                $body = (string) $disk->get($f);
                if (! @getimagesizefromstring($body)) {
                    continue;
                }
                $r = ImageCompressor::compress($body, self::OLD_SIDE, self::OLD_QUALITY);
                if ($r['after'] >= $r['before'] * 0.9) {
                    continue;
                }
                $to = preg_replace('/\.[^.\/]+$/', '', $f).'.'.$r['ext'];
                $disk->put($to, $r['body']);
                if ($to !== $f) {
                    $disk->delete($f);
                    $files[$i] = $to;
                    $changed = true;
                }
                $saved += $r['before'] - $r['after'];
                $n++;
            }
            if ($changed) {
                $p->forceFill(['receipt_path' => $files[0] ?? null, 'receipt_files' => count($files) > 1 || $p->receipt_files ? $files : null])->save();
            }
            if ($n >= $max) {
                break;
            }
        }
        if ($n) {
            Cache::forget('docarch.stats');
        }

        return ['shrunk' => $n, 'saved' => $saved];
    }

    /** پاک کردن فایل فیش‌های تأییدشده/باطل/ردشده قدیمی‌تر از N سال (رکورد پرداخت و مبلغ می‌ماند) */
    public static function deleteOld(int $years, int $limit = 300): int
    {
        if ($years < 1) {
            return 0;
        }
        $disk = Storage::disk('local');
        $n = 0;
        $rows = RemitPayment::query()->whereIn('status', ['confirmed', 'cancelled', 'rejected'])
            ->where('created_at', '<', now()->subYears($years))
            ->where(fn ($q) => $q->whereNotNull('receipt_path')->orWhereNotNull('receipt_files'))
            ->orderBy('id')->limit($limit)->get();
        foreach ($rows as $p) {
            foreach ($p->files() as $f) {
                $disk->delete($f);
            }
            $p->forceFill(['receipt_path' => null, 'receipt_files' => null])->save();
            $n++;
        }
        if ($n) {
            Cache::forget('docarch.stats');
        }

        return $n;
    }
}
