<?php

namespace App\Services;

use App\Models\Stocktake;
use App\Models\StocktakeItem;
use App\Support\SheetReader;
use Illuminate\Support\Facades\DB;
use RuntimeException;

/**
 * انبارگردانی: کالاهایی که در هلو موجودی زیاد دارند ولی در اسکن بارکد انبار نیستند (احتمال گم شدن بار).
 *  - فایل موجودی هلو: کد کالا (+ بارکد اختیاری)، نام، موجودی، قیمت (اختیاری)
 *  - فایل(های) اسکن انبار: بارکدهایی که در انبار دیده شده‌اند (همان اکسل روزهای زوج)
 *  - فایل(های) خرید شعبه‌ها (شیراز، اهواز): از موجودی هلو کم می‌شود (یا کالا کامل استثنا می‌شود)
 * تطبیق: مستقیم با کد/بارکد، و از طریق کالای سایت (کد کالا، بارکد و کد همگام‌سازی یک کالا یکی حساب می‌شوند).
 * فقط نتیجه ذخیره می‌شود؛ فایل‌ها پس از خواندن پاک می‌شوند.
 */
class StockAudit
{
    /** تشخیص ستون از روی عنوان */
    protected const HEAD = [
        'barcode' => '/بارکد|barcode|bar\s*code/iu',
        'code' => '/^(کد|كد)(\s*کالا|\s*كالا)?$|کد\s*کالا|كد\s*كالا|code|کد/iu',
        'name' => '/نام|شرح|عنوان|name|کالا/iu',
        'qty' => '/موجودی|مانده|مقدار|تعداد|qty|quantity|stock/iu',
        'price' => '/قیمت|فی|نرخ|price/iu',
    ];

    /** خواندن فایل به آرایه ردیف‌ها با تشخیص ستون‌ها (یا ستون‌های داده‌شده با حرف A,B,…) */
    public static function readSheet(string $path, string $name, array $force = [], array $want = ['code', 'barcode', 'name', 'qty', 'price']): array
    {
        $rows = [];
        SheetReader::read($path, $name, function ($r) use (&$rows) {
            if (count($rows) < 300000) {
                $rows[] = array_map(fn ($v) => trim((string) $v), (array) $r);
            }
        });
        if (! $rows) {
            throw new RuntimeException('فایل «'.$name.'» خالی است.');
        }
        // ردیف عنوان: اولین ردیف (از ۱۵ ردیف اول) که دست‌کم دو عنوان شناخته‌شده دارد
        $cols = [];
        $start = 0;
        foreach (array_slice($rows, 0, 15, true) as $i => $r) {
            $found = [];
            foreach ($r as $ci => $v) {
                $v = trim(str_replace(['ي', 'ك'], ['ی', 'ک'], (string) $v));
                if ($v === '' || mb_strlen($v) > 40 || preg_match('/^[\d.,\s]+$/u', $v)) {
                    continue;
                }
                foreach (['barcode', 'qty', 'price', 'code', 'name'] as $k) {
                    if (! isset($found[$k]) && ! in_array($ci, $found, true) && preg_match(static::HEAD[$k], $v)) {
                        $found[$k] = $ci;
                        break;
                    }
                }
            }
            // ستون «موجودی/مانده» بر «تعداد» (مثل تعداد در کارتن) مقدم است
            foreach ($r as $ci => $v) {
                if (preg_match('/موجودی|مانده|stock/iu', (string) $v) && ! preg_match('/کارتن|بسته/u', (string) $v)) {
                    $found['qty'] = $ci;
                    break;
                }
            }
            if (count($found) >= 2) {
                $cols = $found;
                $start = $i + 1;
                break;
            }
        }
        foreach ($force as $k => $letters) {
            $letters = strtoupper(trim((string) $letters));
            if ($letters !== '' && preg_match('/^[A-Z]{1,3}$/', $letters)) {
                $cols[$k] = Excel::colIndex($letters);
            }
        }
        if (! isset($cols['code']) && ! isset($cols['barcode'])) {
            $cols['code'] = 0; // بدون عنوان: ستون A کد/بارکد
        }

        return ['rows' => array_slice($rows, $start), 'cols' => array_intersect_key($cols, array_flip($want))];
    }

    protected static function k(?string $v): string
    {
        return Excel::key(Excel::barcode((string) $v));
    }

    /** نقشه کد ← کالای سایت و کالا ← همه کدهایش */
    protected static function siteMap(): array
    {
        $byKey = [];
        $keys = [];
        foreach (DB::table('products')->select('id', 'sku', 'barcode', 'sync_code', 'name', 'price')->cursor() as $p) {
            foreach (['barcode', 'sku', 'sync_code'] as $f) {
                $k = static::k($p->{$f});
                if ($k !== '' && ! isset($byKey[$k])) {
                    $byKey[$k] = (int) $p->id;
                    $keys[(int) $p->id][] = $k;
                }
            }
        }

        return [$byKey, $keys];
    }

    /**
     * @param  array{path:string,name:string}  $holoo
     * @param  array<int, array{path:string,name:string}>  $scans
     * @param  array<int, array{path:string,name:string}>  $branches
     */
    public static function run(array $holoo, array $scans, array $branches, array $o, ?int $by = null): Stocktake
    {
        @set_time_limit(600);
        @ini_set('memory_limit', '768M');
        $min = max(1, (int) ($o['min'] ?? 100));
        $branchMode = ($o['branch_mode'] ?? 'subtract') === 'exclude' ? 'exclude' : 'subtract';
        [$byKey, $prodKeys] = static::siteMap();

        // ۱) اسکن انبار: هر بارکد دیده‌شده (و کالای سایتش)
        $seen = [];
        $seenProd = [];
        $scanRows = 0;
        foreach ($scans as $f) {
            $s = static::readSheet($f['path'], $f['name'], array_filter(['barcode' => $o['scan_col'] ?? '']), ['barcode', 'code']);
            $c = $s['cols']['barcode'] ?? $s['cols']['code'] ?? 0;
            foreach ($s['rows'] as $r) {
                $k = static::k($r[$c] ?? '');
                if ($k === '') {
                    continue;
                }
                $scanRows++;
                $seen[$k] = true;
                if (isset($byKey[$k])) {
                    $seenProd[$byKey[$k]] = true;
                }
            }
        }
        if (! $seen) {
            throw new RuntimeException('هیچ بارکدی در فایل اسکن انبار پیدا نشد.');
        }

        // ۲) خرید شعبه‌ها: کد ← تعداد (یا استثنای کامل)
        $branchQty = [];
        $branchAll = [];
        foreach ($branches as $f) {
            $s = static::readSheet($f['path'], $f['name'], [], ['code', 'barcode', 'qty']);
            foreach ($s['rows'] as $r) {
                $q = isset($s['cols']['qty']) ? (int) (Excel::number($r[$s['cols']['qty']] ?? '') ?? 0) : null;
                foreach (['code', 'barcode'] as $f2) {
                    if (! isset($s['cols'][$f2])) {
                        continue;
                    }
                    $k = static::k($r[$s['cols'][$f2]] ?? '');
                    if ($k === '') {
                        continue;
                    }
                    if ($branchMode === 'exclude' || $q === null) {
                        $branchAll[$k] = true;
                    } else {
                        $branchQty[$k] = ($branchQty[$k] ?? 0) + max(0, $q);
                    }
                    break; // هر ردیف یک بار
                }
            }
        }
        $branchFor = function (array $keys, ?int $pid) use ($branchQty, $branchAll, $prodKeys): array {
            $all = $keys;
            if ($pid) {
                $all = array_merge($all, $prodKeys[$pid] ?? []);
            }
            $all = array_unique($all);
            $q = 0;
            foreach ($all as $k) {
                if (isset($branchAll[$k])) {
                    return [true, 0];
                }
                $q = max($q, $branchQty[$k] ?? 0); // یک کالا با چند کد فقط یک بار کم شود
            }

            return [false, $q];
        };

        // ۳) موجودی هلو
        $h = static::readSheet($holoo['path'], $holoo['name'], array_filter(['code' => $o['holoo_code'] ?? '', 'qty' => $o['holoo_qty'] ?? '', 'barcode' => $o['holoo_barcode'] ?? '']));
        if (! isset($h['cols']['qty'])) {
            throw new RuntimeException('ستون «موجودی» در فایل هلو پیدا نشد؛ حرف ستون موجودی را در «تنظیم ستون‌ها» وارد کنید.');
        }
        $C = $h['cols'];
        $missing = [];
        $stats = ['holoo_rows' => 0, 'scan_rows' => $scanRows, 'scan_codes' => count($seen), 'excluded' => 0, 'branch_reduced' => 0, 'missing' => 0, 'missing_qty' => 0, 'missing_value' => 0, 'present' => 0, 'below' => 0];
        $holooKeys = [];
        foreach ($h['rows'] as $r) {
            $code = Excel::barcode($r[$C['code'] ?? $C['barcode']] ?? '');
            $bar = isset($C['barcode']) ? Excel::barcode($r[$C['barcode']] ?? '') : '';
            $keys = array_values(array_unique(array_filter([static::k($code), static::k($bar)])));
            if (! $keys) {
                continue;
            }
            $qty = (int) (Excel::number($r[$C['qty']] ?? '') ?? 0);
            $stats['holoo_rows']++;
            foreach ($keys as $k) {
                $holooKeys[$k] = true;
            }
            $pid = null;
            foreach ($keys as $k) {
                if (isset($byKey[$k])) {
                    $pid = $byKey[$k];
                    break;
                }
            }
            if ($qty < $min) {
                $stats['below']++;

                continue;
            }
            $present = (bool) ($pid && isset($seenProd[$pid]));
            foreach ($keys as $k) {
                $present = $present || isset($seen[$k]);
            }
            if ($present) {
                $stats['present']++;

                continue;
            }
            [$excluded, $bq] = $branchFor($keys, $pid);
            if ($excluded) {
                $stats['excluded']++;

                continue;
            }
            $net = $qty - $bq;
            if ($bq > 0) {
                $stats['branch_reduced']++;
            }
            if ($net < $min) {
                continue;
            }
            $price = isset($C['price']) ? (int) (Excel::number($r[$C['price']] ?? '') ?? 0) : 0;
            $missing[] = [
                'kind' => 'missing', 'code' => mb_substr($code ?: $bar, 0, 64), 'barcode' => $bar ? mb_substr($bar, 0, 64) : null,
                'name' => mb_substr(Excel::text($r[$C['name'] ?? -1] ?? ''), 0, 250) ?: null, 'product_id' => $pid,
                'holoo_qty' => $qty, 'branch_qty' => $bq, 'net_qty' => $net, 'price' => max(0, $price), 'value' => max(0, $price) * $net,
            ];
        }
        if (! $stats['holoo_rows']) {
            throw new RuntimeException('هیچ ردیف کالایی در فایل هلو خوانده نشد؛ ستون کد و موجودی را بررسی کنید.');
        }

        // ۴) در انبار دیده شده ولی در فایل هلو نیست (کد ناشناخته برای هلو)
        $extra = [];
        $holooProd = [];
        foreach (array_keys($holooKeys) as $k) {
            if (isset($byKey[$k])) {
                $holooProd[$byKey[$k]] = true;
            }
        }
        foreach (array_keys($seen) as $k) {
            if (isset($holooKeys[$k]) || (isset($byKey[$k]) && isset($holooProd[$byKey[$k]]))) {
                continue;
            }
            $extra[] = ['kind' => 'extra', 'code' => mb_substr((string) $k, 0, 64), 'barcode' => null, 'name' => null, 'product_id' => $byKey[$k] ?? null,
                'holoo_qty' => 0, 'branch_qty' => 0, 'net_qty' => 0, 'price' => 0, 'value' => 0];
            if (count($extra) >= 5000) {
                break;
            }
        }
        $stats['extra'] = count($extra);

        // ۵) تکرار در انبارگردانی قبلی: «چند بار پشت سر هم دیده نشده»
        $prev = Stocktake::query()->latest('id')->first();
        $prevStreak = $prev ? StocktakeItem::query()->where('stocktake_id', $prev->id)->where('kind', 'missing')->pluck('streak', 'code')->all() : [];
        $names = $missing || $extra ? DB::table('products')->whereIn('id', array_filter(array_merge(array_column($missing, 'product_id'), array_column($extra, 'product_id'))))->pluck('name', 'id')->all() : [];
        usort($missing, fn ($a, $b) => [$b['value'], $b['net_qty']] <=> [$a['value'], $a['net_qty']]);

        return DB::transaction(function () use ($missing, $extra, $stats, $o, $by, $prevStreak, $names, $min, $branchMode) {
            $stats['missing'] = count($missing);
            $stats['missing_qty'] = array_sum(array_column($missing, 'net_qty'));
            $stats['missing_value'] = array_sum(array_column($missing, 'value'));
            $stats['repeat'] = 0;
            $st = Stocktake::create(['created_by' => $by, 'settings' => ['min' => $min, 'branch_mode' => $branchMode], 'stats' => $stats]);
            $now = now();
            $batch = [];
            foreach (array_merge($missing, $extra) as $row) {
                if ($row['kind'] === 'missing') {
                    $row['streak'] = ($prevStreak[$row['code']] ?? 0) + 1;
                    $stats['repeat'] += $row['streak'] > 1 ? 1 : 0;
                } else {
                    $row['streak'] = 1;
                }
                $row['name'] = $row['name'] ?: ($row['product_id'] ? ($names[$row['product_id']] ?? null) : null);
                $batch[] = $row + ['stocktake_id' => $st->id, 'created_at' => $now, 'updated_at' => $now];
                if (count($batch) >= 500) {
                    StocktakeItem::query()->insert($batch);
                    $batch = [];
                }
            }
            if ($batch) {
                StocktakeItem::query()->insert($batch);
            }
            $st->update(['stats' => $stats]);
            // فقط ۲۰ انبارگردانی آخر نگه داشته می‌شود
            $old = Stocktake::query()->latest('id')->skip(20)->take(100)->pluck('id');
            if ($old->isNotEmpty()) {
                StocktakeItem::query()->whereIn('stocktake_id', $old)->delete();
                Stocktake::query()->whereIn('id', $old)->delete();
            }

            return $st;
        });
    }
}
