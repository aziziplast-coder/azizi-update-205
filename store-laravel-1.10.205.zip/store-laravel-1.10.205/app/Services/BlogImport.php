<?php

namespace App\Services;

use App\Models\Post;
use DOMDocument;
use DOMElement;
use DOMXPath;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use RuntimeException;
use Throwable;

/**
 * ورود مقاله‌های سایت قبلی (عزیزی‌پلاست: /blog-134/عنوان) پیش از انتقال دامنه:
 * فهرست مقاله‌ها از نقشه سایت یا صفحه وبلاگ پیدا می‌شود، هر مقاله (عنوان، متن، تصویر اصلی و تصاویر داخل متن، تاریخ)
 * خوانده و با همان شناسه ذخیره می‌شود تا لینک قدیمی دقیقاً همان مقاله را باز کند.
 */
class BlogImport
{
    public const KEY = 'blogimp.state';

    public static function state(): array
    {
        return Cache::get(static::KEY, ['urls' => [], 'i' => 0, 'ok' => 0, 'skip' => 0, 'fail' => 0, 'log' => [], 'running' => false, 'base' => '']);
    }

    protected static function save(array $s): void
    {
        $s['log'] = array_slice($s['log'], -60);
        Cache::put(static::KEY, $s, now()->addDays(3));
    }

    protected static function http(string $url): string
    {
        $r = Http::timeout(30)->connectTimeout(10)->withoutVerifying()
            ->withHeaders(['User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36', 'Accept-Language' => 'fa-IR,fa;q=0.9'])
            ->get($url);
        if (! $r->successful()) {
            throw new RuntimeException('HTTP '.$r->status());
        }

        return (string) $r->body();
    }

    /** یافتن لینک مقاله‌ها: نقشه سایت (و نقشه‌های تودرتو)، وگرنه صفحه‌های وبلاگ */
    public static function discover(string $base, string $extra = ''): array
    {
        $base = rtrim(preg_match('#^https?://#', $base) ? $base : 'https://'.$base, '/');
        $found = [];
        $add = function (string $u) use (&$found, $base) {
            $u = html_entity_decode(trim($u));
            if (! preg_match('#^https?://#', $u)) {
                $u = $base.'/'.ltrim($u, '/');
            }
            if (preg_match('#/blog-(\d+)(?:/|$|\?)#u', $u, $m)) {
                $found[(int) $m[1]] ??= $u;
            }
        };
        foreach (preg_split('/\s+/', trim($extra)) as $u) {
            if ($u !== '') {
                $add($u);
            }
        }
        $queue = [$base.'/sitemap.xml', $base.'/sitemap_index.xml'];
        $seen = [];
        while ($queue && count($seen) < 40) {
            $sm = array_shift($queue);
            if (isset($seen[$sm])) {
                continue;
            }
            $seen[$sm] = true;
            try {
                $xml = static::http($sm);
            } catch (Throwable) {
                continue;
            }
            preg_match_all('#<loc>\s*([^<]+?)\s*</loc>#i', $xml, $m);
            foreach ($m[1] as $loc) {
                $loc = html_entity_decode($loc);
                if (preg_match('#\.xml(\?|$)#i', $loc)) {
                    $queue[] = $loc;
                } else {
                    $add($loc);
                }
            }
        }
        // صفحه‌های فهرست وبلاگ (اگر نقشه سایت مقاله‌ها را نداشت)
        foreach (['/blog', '/blogs', '/articles', '/mag'] as $path) {
            for ($page = 1; $page <= 60; $page++) {
                try {
                    $html = static::http($base.$path.($page > 1 ? '?page='.$page : ''));
                } catch (Throwable) {
                    break;
                }
                $before = count($found);
                preg_match_all('#href\s*=\s*["\']([^"\']*/blog-\d+[^"\']*)["\']#iu', $html, $m);
                foreach ($m[1] as $u) {
                    $add($u);
                }
                if (count($found) === $before) {
                    break;
                }
            }
        }
        ksort($found);

        return $found;
    }

    public static function start(string $base, string $extra = ''): array
    {
        $urls = static::discover($base, $extra);
        $s = ['urls' => array_values($urls), 'i' => 0, 'ok' => 0, 'skip' => 0, 'fail' => 0, 'log' => [], 'running' => (bool) $urls, 'base' => $base];
        static::save($s);

        return $s;
    }

    /** چند مقاله بعدی */
    public static function step(int $n = 2): array
    {
        $s = static::state();
        if (! $s['running']) {
            return $s;
        }
        @set_time_limit(120);
        for ($k = 0; $k < $n && $s['i'] < count($s['urls']); $k++) {
            $u = $s['urls'][$s['i']++];
            try {
                $r = static::importOne($u);
                $s[$r['status']]++;
                $s['log'][] = [$r['status'], $r['msg']];
            } catch (Throwable $e) {
                $s['fail']++;
                $s['log'][] = ['fail', urldecode($u).' — '.mb_substr($e->getMessage(), 0, 120)];
            }
        }
        if ($s['i'] >= count($s['urls'])) {
            $s['running'] = false;
        }
        static::save($s);

        return $s;
    }

    public static function stop(): void
    {
        $s = static::state();
        $s['running'] = false;
        static::save($s);
    }

    /** خواندن و ذخیره یک مقاله */
    public static function importOne(string $url): array
    {
        if (! preg_match('#/blog-(\d+)(?:/([^?\#]*))?#u', $url, $m)) {
            return ['status' => 'skip', 'msg' => 'لینک مقاله نیست: '.$url];
        }
        $lid = (int) $m[1];
        $lslug = trim(rawurldecode(str_replace('+', ' ', (string) ($m[2] ?? ''))));
        if ($ex = Post::query()->where('legacy_id', $lid)->first()) {
            return ['status' => 'skip', 'msg' => 'قبلاً وارد شده: '.$ex->title];
        }
        $html = static::http($url);
        $doc = new DOMDocument;
        libxml_use_internal_errors(true);
        $doc->loadHTML('<?xml encoding="UTF-8">'.$html, LIBXML_NOWARNING | LIBXML_NOERROR);
        libxml_clear_errors();
        $xp = new DOMXPath($doc);
        $meta = function (string $q) use ($xp): string {
            $n = $xp->query($q)->item(0);

            return $n instanceof DOMElement ? trim((string) $n->getAttribute('content')) : '';
        };
        $title = $meta('//meta[@property="og:title"]') ?: trim((string) ($xp->query('//h1')->item(0)?->textContent ?? ''))
            ?: trim((string) ($xp->query('//title')->item(0)?->textContent ?? '')) ?: $lslug;
        $title = trim(preg_replace('/\s*[|\-–—]\s*[^|\-–—]{2,40}$/u', '', $title)) ?: $title; // «عنوان | نام سایت»
        $desc = $meta('//meta[@name="description"]') ?: $meta('//meta[@property="og:description"]');
        $ogImg = $meta('//meta[@property="og:image"]');
        $date = $meta('//meta[@property="article:published_time"]') ?: (string) ($xp->query('//time[@datetime]')->item(0)?->getAttribute('datetime') ?? '');

        $node = static::mainNode($xp);
        if (! $node) {
            throw new RuntimeException('متن مقاله پیدا نشد');
        }
        $body = static::cleanBody($doc, $node, $url, $lid);
        if (mb_strlen(strip_tags($body)) < 80) {
            throw new RuntimeException('متن مقاله خیلی کوتاه است');
        }
        $image = $ogImg ? static::download($ogImg, $url, 'posts/legacy/'.$lid.'-cover') : null;
        try {
            $pub = $date ? \Illuminate\Support\Carbon::parse($date) : now();
        } catch (Throwable) {
            $pub = now();
        }
        $post = Post::create([
            'title' => mb_substr($title, 0, 250), 'body' => $body, 'excerpt' => $desc ? mb_substr($desc, 0, 300) : null,
            'seo_description' => $desc ? mb_substr($desc, 0, 300) : null, 'image' => $image, 'image_alt' => $image ? mb_substr($title, 0, 190) : null,
            'is_published' => true, 'published_at' => $pub, 'legacy_id' => $lid, 'legacy_slug' => $lslug ?: null, 'legacy_path' => $url,
        ]);

        return ['status' => 'ok', 'msg' => $post->title];
    }

    /** بزرگ‌ترین بخش متنی صفحه (مقاله) */
    protected static function mainNode(DOMXPath $xp): ?DOMElement
    {
        foreach (['//*[@itemprop="articleBody"]', '//article', '//*[contains(@class,"post-content") or contains(@class,"entry-content") or contains(@class,"blog-content") or contains(@class,"article-content") or contains(@class,"blog-detail") or contains(@class,"post-body")]'] as $q) {
            $best = null;
            $bestLen = 0;
            foreach ($xp->query($q) as $n) {
                $len = mb_strlen(trim($n->textContent));
                if ($len > $bestLen) {
                    $best = $n;
                    $bestLen = $len;
                }
            }
            if ($best && $bestLen > 300) {
                return $best;
            }
        }
        // عنصری که بیشترین متن پاراگراف را مستقیم در خود دارد
        $best = null;
        $bestLen = 0;
        foreach ($xp->query('//div|//section|//main') as $n) {
            $len = 0;
            foreach ($n->childNodes as $c) {
                if ($c instanceof DOMElement && in_array(strtolower($c->tagName), ['p', 'h2', 'h3', 'ul', 'ol', 'blockquote'], true)) {
                    $len += mb_strlen(trim($c->textContent));
                }
            }
            if ($len > $bestLen) {
                $best = $n;
                $bestLen = $len;
            }
        }

        return $bestLen > 200 ? $best : null;
    }

    protected static function cleanBody(DOMDocument $doc, DOMElement $node, string $pageUrl, int $lid): string
    {
        $allowed = ['p', 'br', 'h2', 'h3', 'h4', 'h5', 'ul', 'ol', 'li', 'strong', 'b', 'em', 'i', 'a', 'img', 'blockquote', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'figure', 'figcaption', 'span', 'div', 'h1'];
        $drop = ['script', 'style', 'noscript', 'form', 'nav', 'aside', 'header', 'footer', 'button', 'input', 'select', 'textarea', 'svg', 'iframe'];
        $n = 0;
        $walk = function (\DOMNode $el) use (&$walk, $allowed, $drop, $pageUrl, $lid, &$n): string {
            if ($el->nodeType === XML_TEXT_NODE) {
                return htmlspecialchars($el->textContent, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            }
            if (! $el instanceof DOMElement) {
                return '';
            }
            $tag = strtolower($el->tagName);
            $cls = strtolower($el->getAttribute('class').' '.$el->getAttribute('id'));
            if (in_array($tag, $drop, true) || preg_match('/share|social|comment|related|breadcrumb|tags?-|author-box|rating|newsletter/', $cls)) {
                return '';
            }
            $inner = '';
            foreach ($el->childNodes as $c) {
                $inner .= $walk($c);
            }
            if ($tag === 'img') {
                $src = $el->getAttribute('data-src') ?: $el->getAttribute('src');
                if (! $src || str_starts_with($src, 'data:')) {
                    return '';
                }
                $local = static::download($src, $pageUrl, 'posts/legacy/'.$lid.'-'.(++$n));

                return $local ? '<img src="'.e(upload_url($local)).'" alt="'.e($el->getAttribute('alt')).'" loading="lazy">' : '';
            }
            if (! in_array($tag, $allowed, true) || in_array($tag, ['span', 'div'], true)) {
                // div/span: فقط محتوا (پاراگراف‌بندی از تگ‌های داخلی)
                return in_array($tag, ['div'], true) && trim(strip_tags($inner)) !== '' && ! preg_match('#<(p|h\d|ul|ol|table|img|blockquote)\b#', $inner) ? '<p>'.$inner.'</p>' : $inner;
            }
            if ($tag === 'h1') {
                return ''; // عنوان جدا ذخیره می‌شود
            }
            if ($tag === 'a') {
                $href = $el->getAttribute('href');

                return $href && ! str_starts_with($href, 'javascript:') ? '<a href="'.e($href).'">'.$inner.'</a>' : $inner;
            }
            if (in_array($tag, ['p', 'li', 'h2', 'h3', 'h4', 'h5'], true) && trim(strip_tags($inner, '<img>')) === '' && ! str_contains($inner, '<img')) {
                return '';
            }

            return '<'.$tag.'>'.$inner.'</'.$tag.'>';
        };
        $out = '';
        foreach ($node->childNodes as $c) {
            $out .= $walk($c);
        }
        $out = preg_replace('/(\s*<br>\s*){3,}/', '<br><br>', $out);

        return trim($out);
    }

    /** دانلود تصویر روی همین هاست (پس از انتقال دامنه، تصاویر سایت قبلی در دسترس نیست) */
    protected static function download(string $src, string $pageUrl, string $base): ?string
    {
        try {
            $src = html_entity_decode(trim($src));
            if (str_starts_with($src, '//')) {
                $src = 'https:'.$src;
            } elseif (! preg_match('#^https?://#', $src)) {
                $p = parse_url($pageUrl);
                $src = $p['scheme'].'://'.$p['host'].(isset($p['port']) ? ':'.$p['port'] : '').'/'.ltrim($src, '/');
            }
            $src = preg_replace_callback('/[^\x21-\x7e]+/u', fn ($m) => rawurlencode($m[0]), str_replace(' ', '%20', $src));
            $bin = static::http($src);
            if (strlen($bin) < 200 || strlen($bin) > 15 * 1048576) {
                return null;
            }
            $info = @getimagesizefromstring($bin);
            if (! $info) {
                return null;
            }
            $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'][$info['mime']] ?? null;
            if (! $ext) {
                return null;
            }
            $path = $base.'.'.$ext;
            Storage::disk('public')->put($path, $bin);

            return $path;
        } catch (Throwable) {
            return null;
        }
    }
}
