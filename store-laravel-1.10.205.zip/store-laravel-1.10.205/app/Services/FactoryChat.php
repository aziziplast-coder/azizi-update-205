<?php

namespace App\Services;

use App\Models\ChatThread;
use App\Models\Factory;
use App\Models\User;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Throwable;

/**
 * گفتگوی حسابداری با کارخانه‌دارها (یک گفتگو برای هر کارخانه‌دار).
 * همان موتور گفتگوی سفارش (پیام، عکس، ویس، ویدیو، فایل سیگنال سبک)؛ طرف c = کارخانه‌دار، s = حسابداری.
 * روشن/خاموش: کارتابل حسابداری ← تنظیمات کلی ← اپ کارخانه‌داران ← «گفتگو با کارخانه‌دارها».
 */
class FactoryChat
{
    public static function ready(): bool
    {
        static $ok = null;

        return $ok ??= Chat::ready() && \App\Support\DbSchema::hasColumn('chat_threads', 'factory_id');
    }

    public static function enabled(): bool
    {
        $c = FactoryPortal::cfg();

        return $c['enabled'] && $c['chat'] && static::ready();
    }

    /** همکاران حسابداری (حسابدار کل و کمک‌حسابدارها) */
    public static function canStaff(?User $u): bool
    {
        return static::enabled() && Remit::canWork($u);
    }

    public static function thread(Factory $f, bool $create = true): ?ChatThread
    {
        $t = ChatThread::query()->where('factory_id', $f->id)->first();
        if (! $t && $create) {
            try {
                $t = ChatThread::query()->create(['factory_id' => $f->id, 'order_id' => null, 'token' => Str::random(32)]);
            } catch (Throwable) {
                $t = ChatThread::query()->where('factory_id', $f->id)->first();
            }
            if ($t) {
                Chat::signal($t);
            }
        }

        return $t;
    }

    /** شمارنده خوانده‌نشده‌های همه گفتگوهای کارخانه‌دار (برای منو) */
    public static function unread(): int
    {
        return static::ready() ? (int) ChatThread::query()->whereNotNull('factory_id')->sum('unread_staff') : 0;
    }

    /** وضعیت برای پنجره گفتگو؛ $side = c (کارخانه‌دار) یا s (حسابداری) */
    public static function state(ChatThread $t, Factory $f, string $side, ?User $u, int $after = 0): array
    {
        $staff = $side === 's';
        $msgs = Chat::messages($t, $after, $staff);

        return [
            'ok' => true, 'sig' => Chat::signalUrl($t), 'token' => $t->token, 'last' => (int) $t->last_id,
            'read' => (int) ($staff ? $t->customer_read_id : $t->staff_read_id), 'closed' => false, 'off' => null,
            'staff' => null, 'shop' => store_name(), 'order' => '',
            'messages' => $msgs, 'more' => ! $after && count($msgs) >= 60,
            'media' => Chat::mediaCfg(), 'del_min' => Chat::cfg()['del_min'], ...($staff && $u ? ['me' => (int) $u->id] : []),
        ];
    }

    /** پیام کارخانه‌دار ← اعلان به حسابدار کل و کمک‌حسابدارِ حواله‌های همین کارخانه‌دار */
    public static function notifyStaff(Factory $f, string $text): void
    {
        try {
            $ids = User::query()->where('is_active', true)->whereIn('role', ['admin', 'staff'])->get()
                ->filter(fn (User $u) => $u->hasPerm('remit_manage'))->pluck('id')->all();
            $ids = array_merge($ids, $f->remittances()->whereIn('status', ['pending', 'active'])->whereNotNull('assignee_id')->pluck('assignee_id')->all());
            app(WebPush::class)->toUsers(array_values(array_unique(array_map('intval', $ids))), [
                'title' => '🏭 '.$f->name, 'body' => mb_substr($text, 0, 120),
                'url' => url('/admin/factory-chats?f='.$f->id), 'tag' => 'fchat-'.$f->id,
            ]);
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** پیام حسابداری ← پیامک به کارخانه‌دار (حداکثر هر ۳ ساعت یک بار، وقتی پیام قبلی را هم نخوانده) */
    public static function notifyFactory(ChatThread $t, Factory $f): void
    {
        if (! $f->mobile || ($t->sms_at && $t->sms_at->gt(now()->subHours(3)))) {
            return;
        }
        ChatThread::query()->whereKey($t->id)->update(['sms_at' => now()]);
        $link = FactoryPortal::url('chat');
        \App\Support\AfterResponse::run(function () use ($f, $link) {
            try {
                app(Sms::class)->sendText($f->mobile, 'حسابداری '.store_name().' در '.FactoryPortal::cfg()['name'].' برایتان پیام فرستاد:'."\n".$link, 'factory_chat');
            } catch (Throwable $e) {
                report($e);
            }
        });
    }
}
