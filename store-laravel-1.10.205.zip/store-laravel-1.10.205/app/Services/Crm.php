<?php

namespace App\Services;

use App\Models\User;
use App\Support\Jalali;
use App\Support\SheetReader;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use RuntimeException;
use Throwable;

/**
 * باشگاه مشتریان (CRM)
 *
 * - ورود اکسل‌های هلو (فهرست اشخاص، فاکتورهای فروش، فروش کالا به تفکیک مشتری) — ستون‌ها از روی سرستون پیدا می‌شوند.
 * - خریدهای سایت هم حساب می‌شوند (فقط سفارش‌هایی که هنوز در اکسل هلو نیامده‌اند، تا دوبار شمرده نشوند).
 * - دسته‌بندی خودکار: طلایی، نقره‌ای، برنزی، در خطر (بیشتر از فاصله همیشگی‌اش خرید نکرده)، از دست رفته، تازه.
 * - فهرست تماس روزانه برای مشاوران، ثبت نتیجه تماس و یادآوری، کمپین پیامکی برگشت و گزارش برگشتی‌ها.
 */
class Crm
{
    public const SEGMENTS = [
        'gold' => ['🥇 طلایی', '#ca8a04'], 'silver' => ['🥈 نقره‌ای', '#64748b'], 'bronze' => ['🥉 برنزی', '#b45309'],
        'risk' => ['⚠️ در خطر', '#dc2626'], 'lost' => ['💤 از دست رفته', '#475569'], 'new' => ['🌱 تازه', '#16a34a'],
    ];

    public const RESULTS = [
        'no_answer' => '📵 جواب نداد', 'callback' => '🔁 بعداً تماس بگیر', 'will_buy' => '✅ خرید می‌کند', 'bought' => '🛒 خرید کرد',
        'not_now' => '⏸ فعلاً نیاز ندارد', 'lost' => '❌ دیگر نمی‌خرد', 'wrong' => '☎️ شماره اشتباه', 'dnc' => '🚫 تماس نگیرید',
    ];

    public static function defaults(): array
    {
        return [
            'unit' => 'rial',          // واحد مبالغ اکسل هلو
            'site_orders' => 'auto',   // auto = فقط سفارش‌های بعد از آخرین فاکتور هلو | always | never
            'lost_days' => 365,
            'risk_min' => 60,          // حداقل روزِ بی‌خریدی برای «در خطر»
            'risk_factor' => 2,        // بیشتر از چند برابرِ فاصله همیشگی
            'risk_orders' => 3,        // فقط کسانی که حداقل این تعداد خرید داشته‌اند
            'gold_pct' => 10,
            'silver_pct' => 30,
            'new_days' => 45,
            'calls' => 20,             // فهرست تماس روزانه هر مشاور
            'auto' => true,            // پر شدن خودکار فهرست تماس
            'call_segments' => ['risk', 'lost'],
            'call_min' => 0,           // فقط مشتری‌هایی که دست‌کم این مبلغ خرید داشته‌اند (تومان)
            'recall_days' => 30,
            'return_days' => 30,       // برگشت تا چند روز پس از تماس/کمپین به حساب مشاور/کمپین
        ];
    }

    public static function cfg(): array
    {
        $d = static::defaults();
        $c = (array) setting('crm', []);

        return array_replace($d, array_intersect_key($c, $d));
    }

    public static function ready(): bool
    {
        try {
            return \Illuminate\Support\Facades\Schema::hasTable('crm_customers');
        } catch (Throwable) {
            return false;
        }
    }

    /* =================== ورود اکسل هلو =================== */

    public const COLS = [
        'item_code' => ['کد کالا', 'کد محصول'],
        'item_name' => ['نام کالا', 'شرح کالا', 'عنوان کالا', 'نام محصول', 'کالا'],
        'qty' => ['تعداد', 'مقدار', 'تعداد کل'],
        'code' => ['کد شخص', 'کد طرف حساب', 'کد مشتری', 'کد حساب', 'کد خریدار', 'کد'],
        'family' => ['نام خانوادگی', 'فامیل'],
        'name' => ['نام شخص', 'نام طرف حساب', 'نام مشتری', 'طرف حساب', 'خریدار', 'نام و نام خانوادگی', 'نام خریدار', 'مشتری', 'نام'],
        'mobile' => ['موبایل', 'تلفن همراه', 'همراه', 'شماره همراه', 'شماره موبایل', 'موبایل ۱'],
        'phone' => ['تلفن', 'تلفن ثابت', 'تلفن ۱', 'تلفن1'],
        'city' => ['شهر', 'نام شهر'],
        'address' => ['آدرس', 'نشانی'],
        'company' => ['نام فروشگاه', 'فروشگاه', 'شرکت', 'نام تجاری', 'نام شرکت'],
        'invoice' => ['شماره فاکتور', 'ش فاکتور', 'شماره سند', 'شماره', 'فاکتور'],
        'date' => ['تاریخ فاکتور', 'تاریخ', 'تاریخ سند'],
        'amount' => ['مبلغ کل', 'جمع کل', 'مبلغ فاکتور', 'قابل پرداخت', 'مبلغ خالص', 'خالص فاکتور', 'جمع فاکتور', 'مبلغ نهایی', 'جمع', 'مبلغ'],
        'birthday' => ['تاریخ تولد', 'تولد'],
    ];

    protected static function hnorm(string $s): string
    {
        $s = strtr(trim($s), ['ي' => 'ی', 'ك' => 'ک', "\u{200C}" => ' ', '_' => ' ', '.' => ' ']);
        $s = en_digits($s);

        return trim(preg_replace('/\s+/u', ' ', $s));
    }

    /** نام یکسان‌شده برای تطبیق مشتری بین فایل‌ها */
    public static function nkey(string $name): string
    {
        $s = Live::norm($name);
        $s = preg_replace('/\b(اقای|آقای|خانم|جناب|اقا|اق|اقا ی|حاج|حاجی)\b/u', '', $s);

        return mb_substr(trim(preg_replace('/\s+/u', ' ', $s)), 0, 150);
    }

    /** ردیف سرستون و ستون‌ها */
    protected static function detect(array $rows): array
    {
        $best = [-1, [], 0];
        foreach (array_slice($rows, 0, 25, true) as $i => $r) {
            $cols = [];
            foreach ($r as $ci => $cell) {
                $h = static::hnorm((string) $cell);
                if ($h === '' || mb_strlen($h) > 40) {
                    continue;
                }
                foreach (static::COLS as $key => $names) {
                    if (isset($cols[$key])) {
                        continue;
                    }
                    foreach ($names as $n) {
                        if ($h === $n || ($n !== 'کد' && $n !== 'نام' && $n !== 'شماره' && $n !== 'جمع' && $n !== 'مبلغ' && str_starts_with($h, $n))) {
                            // «کد» و «نام» تنها، فقط اگر دقیقاً همین باشد و ستون دیگری آن را نگرفته باشد
                            if (in_array($ci, $cols, true)) {
                                continue 2;
                            }
                            $cols[$key] = $ci;
                            continue 3;
                        }
                    }
                }
            }
            if (count($cols) > $best[2]) {
                $best = [$i, $cols, count($cols)];
            }
        }
        if ($best[2] < 2) {
            throw new RuntimeException('سرستون‌های فایل شناخته نشد. ردیف اول فایل باید عنوان ستون‌ها باشد (مثلاً «نام مشتری»، «موبایل»، «تاریخ»، «مبلغ کل»).');
        }

        return [$best[0], $best[1]];
    }

    public static function import(string $path, string $fileName, string $kind = 'auto', ?User $by = null): array
    {
        @set_time_limit(900);
        @ini_set('memory_limit', '768M');
        $rows = [];
        SheetReader::read($path, $fileName, function ($r) use (&$rows) {
            $rows[] = $r;
        });
        if (! $rows) {
            throw new RuntimeException('فایل «'.$fileName.'» خالی است.');
        }
        [$h, $cols] = static::detect($rows);
        if ($kind === 'auto') {
            $kind = isset($cols['item_name']) ? 'items' : ((isset($cols['amount']) && (isset($cols['date']) || isset($cols['invoice']))) ? 'invoices' : 'customers');
        }
        if (! isset($cols['name']) && ! isset($cols['code'])) {
            throw new RuntimeException('ستون نام یا کد مشتری پیدا نشد.');
        }
        $rial = static::cfg()['unit'] === 'rial';
        $st = ['kind' => $kind, 'rows' => 0, 'customers_new' => 0, 'customers' => 0, 'skipped' => 0, 'cols' => array_keys($cols)];
        $map = new CrmMap;
        $val = fn ($r, $k) => isset($cols[$k]) ? trim((string) ($r[$cols[$k]] ?? '')) : '';
        $num = function ($v) use ($rial) {
            $n = (int) round((float) str_replace([',', '٬', ' '], '', en_digits((string) $v)));

            return $rial ? intdiv($n, 10) : $n;
        };
        $date = function ($v) {
            $v = trim((string) $v);
            if ($v === '') {
                return null;
            }
            if (is_numeric($v) && (float) $v > 20000 && (float) $v < 80000) { // تاریخ عددی اکسل
                return Carbon::create(1899, 12, 30)->addDays((int) $v)->toDateString();
            }
            $c = Jalali::parse($v);
            if ($c && $c->year > 1900 && $c->year < 2100) {
                return $c->toDateString();
            }
            try {
                $g = Carbon::parse($v);

                return $g->year > 1990 ? $g->toDateString() : null;
            } catch (Throwable) {
                return null;
            }
        };
        $sales = [];
        $items = [];
        DB::transaction(function () use ($rows, $h, $kind, $val, $num, $date, $map, &$st, &$sales, &$items) {
            for ($i = $h + 1, $n = count($rows); $i < $n; $i++) {
                $r = $rows[$i];
                $name = trim($val($r, 'name').' '.$val($r, 'family'));
                $code = $val($r, 'code');
                if ($name === '' && $code === '') {
                    $st['skipped'] += trim(implode('', array_map('strval', $r))) !== '' ? 1 : 0;
                    continue;
                }
                if (preg_match('/^(جمع|مجموع|کل)\b/u', $name)) {
                    continue; // ردیف جمع پایین گزارش
                }
                $st['rows']++;
                $cid = $map->resolve($code, $name, mobile($val($r, 'mobile')) ?: null, [
                    'phone' => $val($r, 'phone') ?: null, 'city' => $val($r, 'city') ?: null, 'address' => $val($r, 'address') ?: null,
                    'company' => $val($r, 'company') ?: null, 'birthday' => $date($val($r, 'birthday')),
                ], $kind === 'customers');
                if ($kind === 'invoices') {
                    $d = $date($val($r, 'date'));
                    $amt = $num($val($r, 'amount'));
                    if (! $d || $amt <= 0) {
                        $st['skipped']++;
                        continue;
                    }
                    $ref = $val($r, 'invoice') ?: ($d.'-'.$cid.'-'.$amt);
                    $k = mb_substr(en_digits($ref), 0, 40);
                    $sales[$k] ??= ['crm_customer_id' => $cid, 'source' => 'holoo', 'ref' => $k, 'day' => $d, 'amount' => 0];
                    $sales[$k]['amount'] += $amt; // فاکتورِ چندردیفه
                } elseif ($kind === 'items') {
                    $nm = mb_substr(trim($val($r, 'item_name')), 0, 200);
                    if ($nm === '') {
                        continue;
                    }
                    $k = $cid.'|'.$nm;
                    $items[$k] ??= ['crm_customer_id' => $cid, 'code' => mb_substr($val($r, 'item_code'), 0, 60) ?: null, 'name' => $nm, 'qty' => 0, 'amount' => 0, 'last_day' => null];
                    $items[$k]['qty'] += max(0, (int) round((float) str_replace([',', '٬', ' '], '', en_digits($val($r, 'qty')))));
                    $items[$k]['amount'] += $num($val($r, 'amount'));
                    $d = $date($val($r, 'date'));
                    if ($d && (! $items[$k]['last_day'] || $d > $items[$k]['last_day'])) {
                        $items[$k]['last_day'] = $d;
                    }
                }
            }
            foreach (array_chunk(array_values($sales), 500) as $ch) {
                DB::table('crm_sales')->upsert($ch, ['source', 'ref'], ['crm_customer_id', 'day', 'amount']);
            }
            foreach (array_chunk(array_values($items), 500) as $ch) {
                DB::table('crm_items')->upsert($ch, ['crm_customer_id', 'name'], ['code', 'qty', 'amount', 'last_day']);
            }
        });
        $st['customers'] = $map->touched();
        $st['customers_new'] = $map->created;
        $st['sales'] = count($sales);
        $st['items'] = count($items);
        DB::table('crm_imports')->insert(['kind' => $kind, 'file' => mb_substr($fileName, 0, 190), 'stats' => json_encode($st, JSON_UNESCAPED_UNICODE), 'by_id' => $by?->id, 'created_at' => now()]);
        static::recompute();

        return $st;
    }

    /* =================== محاسبه دسته‌ها =================== */

    public static function recompute(): array
    {
        @set_time_limit(600);
        $c = static::cfg();
        // خریدهای سایت
        $holooMax = DB::table('crm_sales')->where('source', 'holoo')->max('day');
        if ($c['site_orders'] === 'never') {
            DB::table('crm_sales')->where('source', 'site')->delete();
        } else {
            $map = new CrmMap;
            $q = DB::table('orders')->whereNotIn('status', ['cancelled', 'failed', 'pending_payment'])->whereNotNull('user_id');
            if ($c['site_orders'] === 'auto' && $holooMax) {
                $q->where('created_at', '>', Carbon::parse($holooMax)->endOfDay());
                DB::table('crm_sales')->where('source', 'site')->where('day', '<=', $holooMax)->delete();
            }
            $users = [];
            foreach ($q->orderBy('id')->get(['id', 'number', 'user_id', 'customer_name', 'mobile', 'city', 'company', 'items_total', 'total', 'created_at']) as $o) {
                $users[$o->user_id] ??= $map->forUser((int) $o->user_id, $o);
                if (! $users[$o->user_id]) {
                    continue;
                }
                DB::table('crm_sales')->upsert([['crm_customer_id' => $users[$o->user_id], 'source' => 'site', 'ref' => 'S'.$o->number, 'day' => Carbon::parse($o->created_at)->toDateString(), 'amount' => (int) ($o->total ?: $o->items_total)]], ['source', 'ref'], ['crm_customer_id', 'day', 'amount']);
            }
            foreach (DB::table('orders')->whereIn('status', ['cancelled', 'failed'])->pluck('number')->chunk(500) as $ch) {
                DB::table('crm_sales')->where('source', 'site')->whereIn('ref', $ch->map(fn ($n) => 'S'.$n)->all())->delete();
            }
        }
        // اتصال به حساب سایت با موبایل
        $byMobile = DB::table('users')->where('role', 'customer')->whereNotNull('mobile')->pluck('id', 'mobile');
        foreach (DB::table('crm_customers')->whereNull('user_id')->whereNotNull('mobile')->get(['id', 'mobile']) as $r) {
            if (isset($byMobile[$r->mobile])) {
                DB::table('crm_customers')->where('id', $r->id)->update(['user_id' => $byMobile[$r->mobile]]);
            }
        }
        // جمع‌ها
        $today = now()->toDateString();
        $y1 = now()->subYear()->toDateString();
        $y2 = now()->subYears(2)->toDateString();
        $agg = DB::table('crm_sales')->groupBy('crm_customer_id')
            ->selectRaw('crm_customer_id id, COUNT(*) n, SUM(amount) s, MIN(day) f, MAX(day) l, SUM(CASE WHEN day > ? THEN amount ELSE 0 END) sy, SUM(CASE WHEN day > ? AND day <= ? THEN amount ELSE 0 END) sp', [$y1, $y2, $y1])
            ->get()->keyBy('id');
        $active = [];
        foreach ($agg as $a) {
            if ($a->l && Carbon::parse($a->l)->diffInDays(now()) <= (int) $c['lost_days']) {
                $active[$a->id] = (int) $a->sy;
            }
        }
        arsort($active);
        $nAct = count($active);
        $gold = array_slice(array_keys($active), 0, (int) ceil($nAct * (int) $c['gold_pct'] / 100));
        $silver = array_slice(array_keys($active), count($gold), (int) ceil($nAct * (int) $c['silver_pct'] / 100));
        $gold = array_flip($gold);
        $silver = array_flip($silver);
        $owners = DB::table('users')->whereNotNull('advisor_id')->pluck('advisor_id', 'id');
        $counts = array_fill_keys(array_keys(static::SEGMENTS), 0);
        $returned = 0;
        foreach (DB::table('crm_customers')->get(['id', 'user_id', 'segment', 'last_at', 'assigned_to', 'last_call_at', 'advisor_id']) as $cu) {
            $a = $agg->get($cu->id);
            $n = (int) ($a->n ?? 0);
            $last = $a->l ?? null;
            $days = $last ? Carbon::parse($last)->diffInDays(now()) : null;
            $gap = $n > 1 ? (int) round(Carbon::parse($a->f)->diffInDays(Carbon::parse($a->l)) / ($n - 1)) : null;
            $seg = null;
            if ($n > 0) {
                if ($days > (int) $c['lost_days']) {
                    $seg = 'lost';
                } elseif ($n >= (int) $c['risk_orders'] && $gap && $days > max((int) $c['risk_min'], $gap * (float) $c['risk_factor'])) {
                    $seg = 'risk';
                } elseif ($n === 1 && $days <= (int) $c['new_days']) {
                    $seg = 'new';
                } elseif (isset($gold[$cu->id])) {
                    $seg = 'gold';
                } elseif (isset($silver[$cu->id])) {
                    $seg = 'silver';
                } else {
                    $seg = 'bronze';
                }
                $counts[$seg]++;
            }
            $upd = [
                'orders' => $n, 'total' => (int) ($a->s ?? 0), 'total_year' => (int) ($a->sy ?? 0), 'total_prev' => (int) ($a->sp ?? 0),
                'first_at' => $a->f ?? null, 'last_at' => $last, 'gap' => $gap, 'segment' => $seg,
                'advisor_id' => $cu->user_id && isset($owners[$cu->user_id]) ? (int) $owners[$cu->user_id] : $cu->advisor_id,
            ];
            // برگشت: قبلاً در خطر / از دست رفته بود و حالا خرید تازه دارد
            if (in_array($cu->segment, ['risk', 'lost'], true) && $last && $cu->last_at && $last > $cu->last_at) {
                $upd['returned_at'] = now();
                $upd['prev_segment'] = $cu->segment;
                $by = DB::table('crm_calls')->where('crm_customer_id', $cu->id)->where('created_at', '>', now()->subDays((int) $c['return_days']))->orderByDesc('id')->value('user_id');
                $upd['returned_by'] = $by;
                $returned++;
            }
            DB::table('crm_customers')->where('id', $cu->id)->update($upd);
        }
        // کمپین‌ها: چه کسانی پس از پیامک خرید کردند
        foreach (DB::table('crm_campaign_targets as t')->join('crm_campaigns as c', 'c.id', '=', 't.campaign_id')->whereNull('t.returned_at')->where('t.status', 'sent')
            ->where('t.sent_at', '>', now()->subDays((int) $c['return_days']))->get(['t.id', 't.crm_customer_id', 't.sent_at', 't.campaign_id']) as $t) {
            $rev = (int) DB::table('crm_sales')->where('crm_customer_id', $t->crm_customer_id)->where('day', '>=', Carbon::parse($t->sent_at)->toDateString())->sum('amount');
            if ($rev > 0) {
                DB::table('crm_campaign_targets')->where('id', $t->id)->update(['returned_at' => now(), 'revenue' => $rev]);
            }
        }
        foreach (DB::table('crm_campaigns')->where('status', '!=', 'draft')->pluck('id') as $cid) {
            $q = DB::table('crm_campaign_targets')->where('campaign_id', $cid);
            DB::table('crm_campaigns')->where('id', $cid)->update(['returned' => (clone $q)->whereNotNull('returned_at')->count(), 'revenue' => (int) (clone $q)->sum('revenue'), 'sent' => (clone $q)->where('status', 'sent')->count()]);
        }
        DB::table('crm_snapshots')->upsert([['day' => $today, 'counts' => json_encode($counts)]], ['day'], ['counts']);
        Cache::put('crm.computed', now()->toIso8601String(), 86400 * 30);

        return $counts + ['returned' => $returned];
    }

    /* =================== فهرست تماس =================== */

    public static function advisors()
    {
        return User::query()->where('is_active', true)->where('role', 'staff')->where('permissions', 'like', '%"advisor"%')->get();
    }

    /** پر کردن فهرست تماس امروز هر مشاور */
    public static function assignDaily(?int $onlyUser = null): int
    {
        $c = static::cfg();
        $added = 0;
        foreach (static::advisors() as $adv) {
            if ($onlyUser && $adv->id !== $onlyUser) {
                continue;
            }
            $open = static::queue($adv->id)->count();
            $need = max(0, (int) $c['calls'] - $open);
            if (! $need) {
                continue;
            }
            $ids = DB::table('crm_customers')->where('dnc', false)->whereNotNull('mobile')->whereNull('assigned_to')
                ->whereIn('segment', $c['call_segments'] ?: ['risk', 'lost'])
                ->where('total', '>=', (int) $c['call_min'])
                ->where(fn ($w) => $w->whereNull('advisor_id')->orWhere('advisor_id', $adv->id))
                ->where(fn ($w) => $w->whereNull('last_call_at')->orWhere('last_call_at', '<', now()->subDays((int) $c['recall_days'])))
                ->orderByRaw('CASE WHEN advisor_id = ? THEN 0 ELSE 1 END', [$adv->id])->orderByDesc('total_year')->orderByDesc('total')
                ->limit($need)->pluck('id');
            if ($ids->isNotEmpty()) {
                DB::table('crm_customers')->whereIn('id', $ids)->update(['assigned_to' => $adv->id, 'assigned_at' => now()]);
                $added += $ids->count();
            }
        }

        return $added;
    }

    /** فهرست تماسِ الانِ یک مشاور: سپرده‌شده‌ها که هنوز نوبتشان است */
    public static function queue(int $uid)
    {
        return DB::table('crm_customers')->where('assigned_to', $uid)->where('dnc', false)
            ->where(fn ($w) => $w->whereNull('next_call_at')->orWhere('next_call_at', '<=', now()->endOfDay()));
    }

    public static function record(int $crmId, User $by, string $result, ?string $note, ?string $nextAt): void
    {
        if (! isset(static::RESULTS[$result])) {
            throw new RuntimeException('نتیجه نامعتبر است.');
        }
        $cu = DB::table('crm_customers')->find($crmId);
        if (! $cu) {
            throw new RuntimeException('مشتری پیدا نشد.');
        }
        $next = null;
        if ($nextAt) {
            $na = en_digits(trim($nextAt));
            $next = preg_match('/^(19|20)\d\d-/', $na) ? rescue(fn () => Carbon::parse($na), null, false) : (Jalali::parse($na) ?? rescue(fn () => Carbon::parse($na), null, false));
        }
        $upd = ['last_call_at' => now(), 'last_result' => $result, 'updated_at' => now()];
        switch ($result) {
            case 'no_answer':
                $upd['next_call_at'] = now()->addDay()->startOfDay()->addHours(10);
                break;
            case 'callback':
                $upd['next_call_at'] = $next ?: now()->addDays(3)->startOfDay()->addHours(10);
                break;
            case 'will_buy':
                $upd['next_call_at'] = $next ?: now()->addDays(5)->startOfDay()->addHours(10);
                break;
            case 'bought':
            case 'not_now':
            case 'lost':
                $upd['assigned_to'] = null;
                $upd['next_call_at'] = $result === 'lost' ? now()->addDays(180) : null;
                break;
            case 'wrong':
            case 'dnc':
                $upd['assigned_to'] = null;
                $upd['dnc'] = true;
                $upd['next_call_at'] = null;
                break;
        }
        DB::table('crm_calls')->insert(['crm_customer_id' => $crmId, 'user_id' => $by->id, 'result' => $result, 'note' => $note ? mb_substr($note, 0, 500) : null, 'next_at' => $upd['next_call_at'] ?? null, 'created_at' => now()]);
        DB::table('crm_customers')->where('id', $crmId)->update($upd);
        // نتیجه مثبت ← مشتری مال همین مشاور (اگر حساب سایت دارد و مال کسی نیست)
        if (in_array($result, ['will_buy', 'bought'], true) && $cu->user_id && Advisors::enabled() && Advisors::isAdvisor($by)) {
            $u = User::query()->find($cu->user_id);
            if ($u && Advisors::own($u, $by->id, 'crm')) {
                DB::table('crm_customers')->where('id', $crmId)->update(['advisor_id' => $by->id]);
            }
        }
    }

    /* =================== کمپین =================== */

    /** پرس‌وجوی مشتریان بر اساس فیلتر */
    public static function filtered(array $f)
    {
        $q = DB::table('crm_customers')->where('dnc', false);
        if (! empty($f['segments'])) {
            $q->whereIn('segment', (array) $f['segments']);
        }
        if (! empty($f['city'])) {
            $q->where('city', 'like', '%'.trim($f['city']).'%');
        }
        if (! empty($f['min_total'])) {
            $q->where('total', '>=', (int) $f['min_total']);
        }
        if (! empty($f['days'])) {
            $q->where('last_at', '<', now()->subDays((int) $f['days'])->toDateString());
        }
        if (! empty($f['product'])) {
            $q->whereIn('id', DB::table('crm_items')->where('name', 'like', '%'.trim($f['product']).'%')->select('crm_customer_id'));
        }
        if (! empty($f['advisor'])) {
            $q->where('advisor_id', (int) $f['advisor']);
        }
        if (! empty($f['ids'])) {
            $q->whereIn('id', (array) $f['ids']);
        }

        return $q;
    }

    public static function startCampaign(int $id): int
    {
        $cp = DB::table('crm_campaigns')->find($id);
        if (! $cp || $cp->status !== 'draft') {
            return 0;
        }
        $f = (array) json_decode((string) $cp->filter, true);
        $ids = static::filtered($f)->whereNotNull('mobile')->pluck('id');
        foreach ($ids->chunk(500) as $ch) {
            DB::table('crm_campaign_targets')->insertOrIgnore($ch->map(fn ($cid) => ['campaign_id' => $id, 'crm_customer_id' => $cid, 'status' => 'wait'])->all());
        }
        DB::table('crm_campaigns')->where('id', $id)->update(['status' => 'sending', 'targets' => $ids->count(), 'sent_at' => now(), 'updated_at' => now()]);
        static::sendBatch($id, 60);

        return $ids->count();
    }

    /** ارسال بخشی از پیامک‌های کمپین (بقیه در نوبت‌های بعدی کرون) */
    public static function sendBatch(int $id, int $limit = 80): int
    {
        $cp = DB::table('crm_campaigns')->find($id);
        if (! $cp || $cp->status !== 'sending') {
            return 0;
        }
        $rows = DB::table('crm_campaign_targets as t')->join('crm_customers as c', 'c.id', '=', 't.crm_customer_id')
            ->where('t.campaign_id', $id)->where('t.status', 'wait')->limit($limit)->get(['t.id', 'c.name', 'c.mobile', 'c.user_id', 'c.advisor_id']);
        $sms = app(Sms::class);
        $n = 0;
        foreach ($rows as $r) {
            $link = url('/');
            if ($r->advisor_id && Advisors::enabled()) {
                $a = DB::table('advisors')->where('user_id', $r->advisor_id)->first();
                if ($a) {
                    $link = Advisors::link($a);
                }
            }
            $first = trim(explode(' ', trim(preg_replace('/^(آقای|خانم)\s+/u', '', (string) $r->name)))[0] ?? '');
            $text = strtr((string) $cp->text, ['{name}' => $first, '{fullname}' => (string) $r->name, '{link}' => $link, '{coupon}' => (string) $cp->coupon, '{store}' => store_name()]);
            $ok = false;
            try {
                $res = $sms->sendText((string) $r->mobile, $text, 'crm_campaign');
                $ok = (bool) ($res['ok'] ?? false);
            } catch (Throwable) {
            }
            DB::table('crm_campaign_targets')->where('id', $r->id)->update(['status' => $ok ? 'sent' : 'fail', 'sent_at' => now()]);
            $n++;
        }
        if (! DB::table('crm_campaign_targets')->where('campaign_id', $id)->where('status', 'wait')->exists()) {
            DB::table('crm_campaigns')->where('id', $id)->update(['status' => 'sent', 'updated_at' => now()]);
        }
        DB::table('crm_campaigns')->where('id', $id)->update(['sent' => DB::table('crm_campaign_targets')->where('campaign_id', $id)->where('status', 'sent')->count()]);

        return $n;
    }

    /* =================== کرون =================== */

    public static function tick(): array
    {
        if (! static::ready()) {
            return [];
        }
        $done = [];
        foreach (DB::table('crm_campaigns')->where('status', 'sending')->pluck('id') as $id) {
            $done[] = 'crm-sms:'.static::sendBatch($id, 80);
        }
        $day = now()->toDateString();
        if (Cache::get('crm.day') !== $day && (int) now()->format('G') >= 6 && DB::table('crm_customers')->exists()) {
            Cache::put('crm.day', $day, 86400 * 2);
            $r = static::recompute();
            $done[] = 'crm-recompute';
            if (static::cfg()['auto']) {
                $done[] = 'crm-assign:'.static::assignDaily();
            }
        }

        return $done;
    }
}
