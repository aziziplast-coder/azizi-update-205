<?php

namespace App\Services;

use App\Models\Order;
use App\Models\User;
use RuntimeException;

/**
 * تغییر شیوه تسویه سفارش توسط اپراتور فروش در هر مرحله (مثلاً «تمام نقدی» ← «نقد و چک»).
 * مبلغ نقد و چک‌ها را اپراتور هنگام «صدور / اصلاح مانده حساب» تعیین می‌کند.
 */
class PayMethod
{
    /** شیوه‌هایی که اپراتور می‌تواند انتخاب کند (پرداخت آنلاین درگاه نه) */
    public static function options(): array
    {
        $out = [];
        foreach (Checkout::paymentMethods() as $id => $p) {
            if ($id !== 'gateway') {
                $out[$id] = $p['title'];
            }
        }
        $out['cheque'] ??= 'نقد و چک';
        if (! isset($out['card']) && ! isset($out['offline'])) {
            $out['cash'] = 'تمام نقدی (واریز با حواله)';
        }

        return $out;
    }

    public static function can(User $u, Order $o): bool
    {
        return $u->hasPerm('orders_edit') && ! in_array($o->status, ['cancelled', 'failed'], true);
    }

    public static function isCheque(Order $o): bool
    {
        return $o->payment_method === 'cheque' || ! empty(((array) $o->cheque)['settle']) || ! empty(((array) $o->cheque)['cheques']);
    }

    /** @return string پیام برای اپراتور */
    public static function change(Order $o, string $method, User $by): string
    {
        $opts = static::options();
        if (! isset($opts[$method])) {
            throw new RuntimeException('شیوه تسویه نامعتبر است.');
        }
        if (! static::can($by, $o)) {
            throw new RuntimeException('برای تغییر شیوه تسویه دسترسی «ویرایش سفارش» لازم است.');
        }
        $wasCheque = static::isCheque($o);
        $old = (string) $o->payment_title;
        $toCheque = $method === 'cheque';
        if ($toCheque) {
            $ch = (array) $o->cheque;
            if (empty($ch['settle']) && empty($ch['cheques'])) {
                $ch = ['plan' => 'نقد و چک — مبلغ نقد و چک‌ها را کارشناس تعیین می‌کند', 'manual' => true, 'cash' => 0, 'cheques' => [], 'guarantee' => null];
            }
            $o->cheque = $ch;
            $o->payment_method = 'cheque';
            $o->payment_title = 'نقد و چک (تعیین توسط کارشناس)';
        } else {
            if ($wasCheque) {
                // چکی ← نقدی: مشخصات چک‌ها برداشته می‌شود تا مانده حساب کامل نقدی صادر شود
                $o->cheque = null;
                $o->cash_amount = null;
            }
            $o->payment_method = $method === 'cash' ? 'card' : $method;
            $o->payment_title = $opts[$method];
        }
        $o->save();
        $settleOpen = \App\Models\RemitPayment::query()->where('order_id', $o->id)->where('kind', 'settle')->whereIn('status', ['awaiting', 'rejected'])->exists();
        $o->log('شیوه تسویه توسط '.$by->displayName().' تغییر کرد: «'.$old.'» ← «'.$o->payment_title.'»', $by->id);
        try {
            ChatFinance::note($o, '💳 شیوه تسویه سفارش به «'.$o->payment_title.'» تغییر کرد.'.($toCheque ? ' مبلغ نقد و چک‌ها را کارشناس در صدور مانده حساب اعلام می‌کند.' : ''), true);
        } catch (\Throwable $e) {
            report($e);
        }

        return 'شیوه تسویه: '.$o->payment_title.($settleOpen || $o->final_amount ? ' — مانده حساب قبلاً صادر شده؛ «اصلاح مانده حساب» را بزنید.' : ($toCheque ? ' — مبلغ نقد و چک‌ها را در «صدور مانده حساب» (صفحه سفارش) تعیین کنید.' : ''));
    }
}
