<?php

namespace App\Services;

use App\Models\Product;
use App\Models\StockAlert;

/** ارسال پیامک «کالا موجود شد» برای کسانی که «خبرم کن» زده‌اند. */
class StockNotifier
{
    public function check(Product $product): void
    {
        if (! $product->is_active || ! $product->isAvailable()) {
            return;
        }
        $alerts = StockAlert::query()->where('product_id', $product->id)->whereNull('notified_at')->limit(200)->get();
        foreach ($alerts as $a) {
            app(Sms::class)->send('stock_back', $a->mobile, ['product' => $product->name, 'link' => $product->url()]);
            $a->update(['notified_at' => now()]);
        }
    }
}
