<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * ساخت خودکار دیتابیس و کاربر MySQL روی هاست سی‌پنل با UAPI.
 * رمز سی‌پنل فقط برای همین درخواست استفاده می‌شود و هیچ‌جا ذخیره نمی‌شود.
 */
class CpanelDatabase
{
    protected string $base = '';

    protected array $auth = [];

    protected string $user = '';

    /** نام کاربری سی‌پنل از مسیر پوشه (‎/home/USER/…) */
    public static function guessUser(): string
    {
        if (preg_match('#^/home\d*/([a-z0-9_\-]+)/#i', base_path().'/', $m)) {
            return $m[1];
        }
        if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
            $u = @posix_getpwuid(posix_geteuid());
            if (! empty($u['name']) && $u['name'] !== 'root') {
                return $u['name'];
            }
        }

        return (string) (get_current_user() !== 'root' ? get_current_user() : '');
    }

    /**
     * @return array{host: string, name: string, user: string, pass: string}
     */
    public function create(string $user, string $secret, string $domain): array
    {
        $user = trim($user);
        $secret = trim($secret);
        if ($user === '' || $secret === '') {
            throw new RuntimeException('نام کاربری و رمز سی‌پنل را وارد کنید.');
        }
        $this->user = $user;
        // توکن API (۳۲ حرف و عدد) یا رمز عادی
        $this->auth = preg_match('/^[A-Za-z0-9]{32}$/', $secret) && preg_match('/[0-9]/', $secret) && strtoupper($secret) === $secret
            ? ['Authorization' => 'cpanel '.$user.':'.$secret]
            : ['Authorization' => 'Basic '.base64_encode($user.':'.$secret)];

        $r = $this->connect($domain);
        $restr = (array) ($r['data'] ?? []);
        $prefix = (string) ($restr['prefix'] ?? ($user.'_'));
        $maxDb = (int) ($restr['max_database_name_length'] ?? 64) ?: 64;
        $maxUser = (int) ($restr['max_username_length'] ?? 16) ?: 16;

        $suffix = Str::lower(Str::random(4));
        $dbName = substr($prefix.'shop'.$suffix, 0, $maxDb);
        $dbUser = substr($prefix.'shop'.$suffix, 0, $maxUser);
        $dbPass = 'Sh'.Str::random(18).'#'.random_int(10, 99).'a';

        $this->call('Mysql/create_database', ['name' => $dbName], 'ساخت دیتابیس');
        $this->call('Mysql/create_user', ['name' => $dbUser, 'password' => $dbPass], 'ساخت کاربر دیتابیس');
        $this->call('Mysql/set_privileges_on_database', ['user' => $dbUser, 'database' => $dbName, 'privileges' => 'ALL PRIVILEGES'], 'دسترسی کاربر به دیتابیس');

        return ['host' => 'localhost', 'name' => $dbName, 'user' => $dbUser, 'pass' => $dbPass];
    }

    /** پیدا کردن آدرس سی‌پنل از داخل خود هاست */
    protected function connect(string $domain): array
    {
        $domain = preg_replace('#^https?://#', '', rtrim($domain, '/'));
        $domain = explode('/', explode(':', $domain)[0])[0];
        $candidates = array_unique(array_filter([
            env('CPANEL_API_URL'),
            'https://127.0.0.1:2083',
            'https://localhost:2083',
            $domain ? 'https://'.$domain.':2083' : null,
            $domain ? 'https://cpanel.'.$domain.':2083' : null,
            'http://127.0.0.1:2082',
        ]));
        $last = '';
        foreach ($candidates as $base) {
            try {
                $resp = Http::timeout(12)->withoutVerifying()->withHeaders($this->auth)->acceptJson()
                    ->get($base.'/execute/Mysql/get_restrictions');
            } catch (Throwable $e) {
                $last = $e->getMessage();

                continue;
            }
            if (in_array($resp->status(), [401, 403], true)) {
                $isToken = str_starts_with($this->auth['Authorization'], 'cpanel ');
                throw new RuntimeException('سی‌پنل ورود با نام کاربری «'.$this->user.'» و '.($isToken ? 'این توکن' : 'این رمز').' را نپذیرفت. '
                    .($isToken ? 'توکن را دوباره از Manage API Tokens کپی کنید.' : 'رمز همان رمز ورود به سی‌پنل است (نه رمز هاستینگ یا ایمیل). اگر آن را نمی‌دانید، راهنمای «توکن» زیر خانه رمز را ببینید.')
                    .' توجه: چند تلاش اشتباه پشت‌سرهم ممکن است ورود به سی‌پنل را چند دقیقه قفل کند.');
            }
            $j = $resp->json();
            if ($resp->successful() && is_array($j) && array_key_exists('status', $j)) {
                if (! $j['status']) {
                    throw new RuntimeException('سی‌پنل خطا داد: '.$this->errors($j));
                }
                $this->base = $base;

                return $j;
            }
            $last = 'HTTP '.$resp->status();
        }
        throw new RuntimeException('اتصال به سی‌پنل از داخل هاست برقرار نشد ('.Str::limit($last, 120).'). دیتابیس را دستی بسازید و گزینه «دیتابیس را خودم ساخته‌ام» را انتخاب کنید.');
    }

    protected function call(string $fn, array $params, string $title): array
    {
        try {
            $resp = Http::timeout(30)->withoutVerifying()->withHeaders($this->auth)->acceptJson()
                ->get($this->base.'/execute/'.$fn, $params);
        } catch (Throwable $e) {
            throw new RuntimeException($title.' ناموفق بود: '.$e->getMessage());
        }
        $j = $resp->json();
        if (! is_array($j) || empty($j['status'])) {
            throw new RuntimeException($title.' ناموفق بود: '.(is_array($j) ? $this->errors($j) : 'HTTP '.$resp->status()));
        }

        return $j;
    }

    protected function errors(array $j): string
    {
        $e = $j['errors'] ?? null;

        return Str::limit(strip_tags(is_array($e) ? implode(' ', $e) : (string) ($e ?: 'خطای نامشخص')), 300);
    }
}
