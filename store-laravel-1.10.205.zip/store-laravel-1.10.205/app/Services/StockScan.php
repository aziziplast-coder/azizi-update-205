<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Warehouse;
use App\Support\SheetReader;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use RuntimeException;
use Throwable;

/**
 * به‌روزرسانی روزانه موجودی از خروجی اسکنر انبارها.
 *
 * فایل‌های «omde» (انبار عمده/کارتنی) و «khorde» (انبار خرده) — هر فایل فقط یک ستون کد کالا.
 *  - کالای داخل فایل‌های عمده: فروش کارتنی «موجود»؛ کالایی که نیست: کارتنی «ناموجود»
 *  - کالای داخل فایل‌های خرده: فروش خرده «موجود»؛ کالایی که نیست: خرده «ناموجود»
 * فقط کالاهای انبارهایی که امروز اسکن شده‌اند ناموجود می‌شوند (فایل یک انبار جا مانده باشد، آن انبار دست نمی‌خورد).
 *
 * محافظ‌ها: پیش‌نمایش پیش از اعمال، تشخیص فایل عمده‌ای که اشتباهی در خرده ریخته شده (و برعکس)،
 * هشدار تغییر غیرعادی، و برگرداندن کامل آخرین به‌روزرسانی.
 * فقط فایل عمده داده شود → فقط فروش کارتنی عوض می‌شود و خرده دست نمی‌خورد (و برعکس).
 */
class StockScan
{
    public const PERM = 'stock';

    public static function dir(int $id): string
    {
        return storage_path('app/stockscan/'.$id);
    }

    /** نوع فایل از روی نام: omde/عمده → carton، khorde/خرده → retail */
    public static function kindOf(string $name): ?string
    {
        $n = mb_strtolower($name);
        if (preg_match('/khord|kherd|khurd|خرده|خورده|tak|تکی/u', $n)) {
            return 'retail';
        }
        if (preg_match('/omde|omdeh|omdah|عمده|carton|karton|کارتن/u', $n)) {
            return 'carton';
        }

        return null;
    }

    /** کدهای یک فایل اسکنر (همه ستون‌ها و برگه‌ها؛ خالی و متن‌های عنوان رد می‌شوند) */
    public static function readCodes(string $path, string $name): array
    {
        $codes = [];
        $scans = 0;
        SheetReader::read($path, $name, function ($row) use (&$codes, &$scans) {
            foreach ((array) $row as $v) {
                $b = Excel::barcode($v ?? '');
                if ($b === '' || ! preg_match('/^[A-Z0-9.\-]{2,40}$/', $b) || ! preg_match('/\d/', $b)) {
                    continue;
                }
                $scans++;
                $k = Excel::key($b);
                $codes[$k] ??= $b;
            }
        });

        return [$codes, $scans];
    }

    /** نقشه کد → کالا (کد هلو، کد کالا و بارکد) */
    protected static function index(): array
    {
        $map = [];
        $rows = Product::query()->where(fn ($q) => $q->whereNull('review')->orWhere('review', '!=', 'pending'))
            ->get(['id', 'name', 'sku', 'sync_code', 'barcode', 'per_carton', 'carton_enabled', 'in_stock', 'stock', 'retail_enabled', 'retail_in_stock', 'retail_stock', 'warehouse_id', 'retail_warehouse_id', 'is_active']);
        foreach (['sync_code', 'sku', 'barcode'] as $f) {
            foreach ($rows as $p) {
                $k = Excel::key(Excel::barcode((string) $p->{$f}));
                if ($k !== '') {
                    $map[$k] ??= $p;
                }
            }
        }

        return [$map, $rows];
    }

    protected static function cartonOn(Product $p): bool
    {
        return (bool) $p->carton_enabled && (bool) $p->in_stock && ($p->stock === null || $p->stock >= max(1, $p->per_carton));
    }

    protected static function retailOn(Product $p): bool
    {
        return $p->retailAllowed() && (bool) $p->in_stock && (bool) $p->retail_in_stock && ($p->retail_stock === null || $p->retail_stock > 0);
    }

    /**
     * پیش‌نمایش: چه چیزی عوض می‌شود + هشدارها. هیچ تغییری در کالاها نمی‌دهد.
     * $kinds: نام فایل → carton|retail|skip (انتخاب کاربر)، $scope: covered|all
     */
    public static function analyze(int $id, array $kinds = [], string $scope = 'covered'): array
    {
        @set_time_limit(300);
        @ini_set('memory_limit', '512M');
        $files = [];
        foreach (glob(static::dir($id).'/files/*') ?: [] as $f) {
            $name = basename($f);
            $kind = $kinds[$name] ?? static::kindOf($name);
            [$codes, $scans] = static::readCodes($f, $name);
            $files[$name] = ['name' => $name, 'kind' => $kind, 'codes' => $codes, 'scans' => $scans];
        }
        if (! $files) {
            throw new RuntimeException('فایلی پیدا نشد.');
        }
        [$map, $all] = static::index();
        $whNames = Warehouse::query()->pluck('name', 'id')->all();

        $carton = $retail = [];
        $warn = [];
        foreach ($files as $name => &$f) {
            $known = [];
            foreach ($f['codes'] as $k => $b) {
                if (isset($map[$k])) {
                    $known[$k] = $map[$k];
                }
            }
            $kn = count($known);
            // کالای انبار «عددی» (سوله خرده‌ریز/نوید) خرده حساب نمی‌شود؛ عمده بدون کارتن است
            $retailish = count(array_filter($known, fn (Product $p) => $p->retailAllowed() || ($p->per_carton <= 1 && ! Warehouse::isLoose((int) $p->warehouse_id))));
            $f['unique'] = count($f['codes']);
            $f['known'] = $kn;
            $f['unknown'] = $f['unique'] - $kn;
            $f['retail_rate'] = $kn ? round($retailish * 100 / $kn) : 0;
            $f['flags'] = [];
            if ($f['kind'] === null) {
                $f['flags'][] = ['bad', 'نوع فایل از نامش معلوم نیست؛ «عمده» یا «خرده» را انتخاب کنید.'];
            }
            if ($f['unique'] >= 10 && $f['unknown'] / max(1, $f['unique']) > 0.4) {
                $f['flags'][] = ['wa', fa(round($f['unknown'] * 100 / $f['unique'])).'٪ کدهای این فایل در سایت پیدا نشد؛ شاید فایل اشتباه است.'];
            }
            // فایل عمده‌ای که اشتباهی در «خرده» گذاشته شده: بیشتر کالاهایش اصلاً فروش خرده ندارند
            if ($f['kind'] === 'retail' && $kn >= 15 && $f['retail_rate'] < 80) {
                $f['flags'][] = ['bad', 'فقط '.fa($f['retail_rate']).'٪ کالاهای این فایل فروش خرده دارند؛ به احتمال زیاد این فایل «عمده» است، نه «خرده».'];
            }
            // تشخیص انبار فایل: بیشتر کالاهای فایل از کدام انبار است (و اگر عمده عددی است، گفته شود)
            if ($kn >= 5) {
                $byWh = [];
                foreach ($known as $p) {
                    $w = (int) ($f['kind'] === 'retail' ? ($p->retail_warehouse_id ?: $p->warehouse_id) : $p->warehouse_id);
                    $byWh[$w] = ($byWh[$w] ?? 0) + 1;
                }
                arsort($byWh);
                $top = (int) array_key_first($byWh);
                $pct = (int) round(reset($byWh) * 100 / $kn);
                if ($top && $pct >= 50) {
                    $f['flags'][] = ['ok', fa($pct).'٪ کالاهای این فایل از «'.($whNames[$top] ?? '?').'» است'
                        .(Warehouse::isLoose($top) ? ' — عمده عددی (بدون کارتن): موجود/ناموجود طبق همین فایل، فروش طبق قانون انبار.' : '.')];
                }
            }
            if ($f['kind'] === 'carton') {
                foreach ($known as $k => $p) {
                    $carton[$k] = $p;
                }
            } elseif ($f['kind'] === 'retail') {
                foreach ($known as $k => $p) {
                    $retail[$k] = $p;
                }
            }
            unset($f['codes_known']);
        }
        unset($f);
        // فایل خرده‌ای که اشتباهی در «عمده» گذاشته شده: تقریباً همه کدهایش در فایل‌های خرده هم هست
        $retailSet = [];
        foreach ($files as $f) {
            if ($f['kind'] === 'retail') {
                $retailSet += $f['codes'];
            }
        }
        foreach ($files as $name => &$f) {
            if ($f['kind'] === 'carton' && $retailSet && $f['unique'] >= 15) {
                $both = count(array_intersect_key($f['codes'], $retailSet));
                if ($both / $f['unique'] > 0.7 && $f['retail_rate'] > 90) {
                    $f['flags'][] = ['bad', fa(round($both * 100 / $f['unique'])).'٪ کدهای این فایل در فایل‌های خرده هم هست؛ شاید این فایل «خرده» است، نه «عمده».'];
                }
            }
            // دو فایل یکسان
            foreach ($files as $n2 => $g) {
                if ($n2 !== $name && $n2 > $name && $f['unique'] >= 10 && $g['unique'] >= 10) {
                    $inter = count(array_intersect_key($f['codes'], $g['codes']));
                    if ($inter / max($f['unique'], $g['unique']) > 0.95) {
                        $f['flags'][] = ['bad', 'تقریباً عین فایل «'.$n2.'» است؛ شاید یک فایل دو بار گذاشته شده.'];
                    }
                }
            }
        }
        unset($f);

        $hasCarton = (bool) array_filter($files, fn ($f) => $f['kind'] === 'carton');
        $hasRetail = (bool) array_filter($files, fn ($f) => $f['kind'] === 'retail');

        // پوشش انبارها: انباری «اسکن‌شده» است که دست‌کم ۱۰٪ کالاهای موجودش (و حداقل ۵ کالا) در فایل‌ها آمده باشد
        $cover = function (array $scanned, callable $whOf, callable $isOn, callable $eligible) use ($all) {
            $hits = $avail = $total = [];
            foreach ($all as $p) {
                if (! $eligible($p)) {
                    continue;
                }
                $w = (int) ($whOf($p) ?? 0);
                $total[$w] = ($total[$w] ?? 0) + 1;
                if ($isOn($p)) {
                    $avail[$w] = ($avail[$w] ?? 0) + 1;
                }
            }
            foreach ($scanned as $p) {
                if ($eligible($p)) {
                    $w = (int) ($whOf($p) ?? 0);
                    $hits[$w] = ($hits[$w] ?? 0) + 1;
                }
            }
            $out = [];
            foreach ($total as $w => $t) {
                $h = $hits[$w] ?? 0;
                $a = $avail[$w] ?? 0;
                $out[$w] = ['hits' => $h, 'avail' => $a, 'total' => $t, 'covered' => $w > 0 && $h >= max(5, (int) ceil($a * 0.1))];
            }

            return $out;
        };
        $cWh = fn (Product $p) => $p->warehouse_id;
        $rWh = fn (Product $p) => $p->retail_warehouse_id ?: $p->warehouse_id;
        $cartonCover = $hasCarton ? $cover($carton, $cWh, fn ($p) => static::cartonOn($p), fn ($p) => (bool) $p->carton_enabled) : [];
        $retailCover = $hasRetail ? $cover($retail, $rWh, fn ($p) => static::retailOn($p), fn ($p) => $p->retailAllowed()) : [];

        // برنامه تغییرات
        $plan = [];
        $c = ['c_on' => 0, 'c_off' => 0, 'c_same' => 0, 'c_skip' => 0, 'r_on' => 0, 'r_off' => 0, 'r_same' => 0, 'r_skip' => 0, 'buy_on' => 0, 'buy_off' => 0,
            'c_total' => 0, 'r_total' => 0, 'all_total' => 0];
        $lists = ['c_on' => [], 'c_off' => [], 'r_on' => [], 'r_off' => []];
        $cartonIds = [];
        foreach ($carton as $p) {
            $cartonIds[$p->id] = true;
        }
        $retailIds = [];
        foreach ($retail as $p) {
            $retailIds[$p->id] = true;
        }
        foreach ($all as $p) {
            $oldC = static::cartonOn($p);
            $oldR = static::retailOn($p);
            $newC = $oldC;
            $newR = $oldR;
            $single = (int) $p->per_carton <= 1;
            // کارتنی
            // کالای تکی/عددی که فقط در فایل خرده آمده هم موجود می‌شود (حتی اگر امروز فایل عمده نیامده)
            if (($hasCarton || ($single && $hasRetail && isset($retailIds[$p->id]))) && $p->carton_enabled) {
                $in = isset($cartonIds[$p->id]) || ($single && isset($retailIds[$p->id])); // کالای تکی در هر کدام از فایل‌ها = موجود
                $covered = $scope === 'all' || ($cartonCover[(int) $p->warehouse_id]['covered'] ?? false);
                if ($in) {
                    $newC = true;
                } elseif ($covered) {
                    $newC = false;
                } else {
                    $c['c_skip'] += $oldC ? 1 : 0;
                }
            }
            // خرده
            if ($hasRetail && $p->retailAllowed()) {
                $in = isset($retailIds[$p->id]);
                $covered = $scope === 'all' || ($retailCover[(int) $rWh($p)]['covered'] ?? false);
                if ($in) {
                    $newR = true;
                } elseif ($covered) {
                    $newR = false;
                } else {
                    $c['r_skip'] += $oldR ? 1 : 0;
                }
            }
            // کل موجودها پس از اعمال (تازه موجودشده + از قبل موجود و بدون تغییر)
            $c['c_total'] += $newC ? 1 : 0;
            $c['r_total'] += $newR ? 1 : 0;
            $c['all_total'] += ($newC || $newR) ? 1 : 0;
            if ($newC === $oldC && $newR === $oldR) {
                $c['c_same'] += $hasCarton && $p->carton_enabled ? 1 : 0;
                $c['r_same'] += $hasRetail && $p->retailAllowed() ? 1 : 0;

                continue;
            }
            $row = ['n' => $p->name, 'c' => (string) ($p->sku ?: $p->sync_code ?: $p->barcode), 'w' => $whNames[$p->warehouse_id] ?? ''];
            if ($newC !== $oldC) {
                $k = $newC ? 'c_on' : 'c_off';
                $c[$k]++;
                $lists[$k][] = $row;
            }
            if ($newR !== $oldR) {
                $k = $newR ? 'r_on' : 'r_off';
                $c[$k]++;
                $lists[$k][] = $row + ['rw' => $whNames[$rWh($p)] ?? ''];
            }
            $buyOld = $oldC || $oldR;
            $buyNew = $newC || $newR;
            if ($buyOld !== $buyNew) {
                $c[$buyNew ? 'buy_on' : 'buy_off']++;
            }
            // [کارتنی، خرده، فایل عمده داده شده؟، فایل خرده داده شده؟] — بخشی که فایلش داده نشده دست نمی‌خورد
            $plan[$p->id] = [$newC ? 1 : 0, $newR ? 1 : 0, $hasCarton ? 1 : 0, $hasRetail ? 1 : 0];
        }

        // تغییر غیرعادی: ناموجود شدن ناگهانی بخش بزرگی از کالاهای موجود
        $cNow = count(array_filter($all->all(), fn ($p) => static::cartonOn($p)));
        $rNow = count(array_filter($all->all(), fn ($p) => static::retailOn($p)));
        if ($cNow >= 50 && $c['c_off'] > $cNow * 0.25) {
            $warn[] = ['bad', fa($c['c_off']).' کالا از '.fa($cNow).' کالای موجودِ کارتنی ('.fa(round($c['c_off'] * 100 / $cNow)).'٪) ناموجود می‌شود. اگر فایل همه انبارها را نداده‌اید یا فایلی ناقص است، اعمال نکنید.'];
        }
        if ($rNow >= 30 && $c['r_off'] > $rNow * 0.3) {
            $warn[] = ['bad', fa($c['r_off']).' کالا از '.fa($rNow).' کالای موجودِ خرده ('.fa(round($c['r_off'] * 100 / $rNow)).'٪) ناموجود می‌شود. فایل‌های خرده را بررسی کنید.'];
        }
        foreach ($files as $f) {
            foreach ($f['flags'] as $fl) {
                if ($fl[0] === 'bad') {
                    $warn[] = ['bad', '«'.$f['name'].'»: '.$fl[1]];
                }
            }
        }

        $covList = function (array $cov) use ($whNames) {
            $out = [];
            foreach ($cov as $w => $x) {
                if (! $x['hits'] && ! $x['avail']) {
                    continue;
                }
                $out[] = ['name' => $w ? ($whNames[$w] ?? 'انبار '.$w) : 'بدون انبار', 'id' => $w] + $x;
            }
            usort($out, fn ($a, $b) => [$b['covered'], $b['hits']] <=> [$a['covered'], $a['hits']]);

            return $out;
        };
        $unknown = [];
        foreach ($files as $f) {
            foreach ($f['codes'] as $k => $b) {
                if (! isset($map[$k])) {
                    $unknown[$k] = [$b, $f['name']];
                }
            }
        }
        $stats = [
            'counts' => $c, 'carton_now' => $cNow, 'retail_now' => $rNow, 'scope' => $scope,
            'files' => array_values(array_map(fn ($f) => array_diff_key($f, ['codes' => 1]), $files)),
            'carton_cover' => $covList($cartonCover), 'retail_cover' => $covList($retailCover),
            'warnings' => $warn, 'unknown' => count($unknown),
            'has' => ['carton' => $hasCarton, 'retail' => $hasRetail],
        ];
        // کدهای موجود در انبار عمده برای اپ خرید و تأمین: همه کدهای فایل‌های عمده (حتی کالایی که در سایت ساخته نشده)
        // + کدهای دیگر همان کالا در سایت، + کالای «تعداد در کارتن ۱» که در فایل خرده آمده (همان قاعده سایت)
        // کدهای انبار عمده برای اپ خرید و تأمین: فقط فایل‌های عمده (خرید از کارخانه فقط بر اساس انبار کارتنی است)
        // + کدهای دیگر (کد کالا/بارکد) همان کالا در سایت
        $buy = [];
        foreach ($files as $f) {
            if ($f['kind'] === 'carton') {
                foreach ($f['codes'] as $k => $b) {
                    $buy[$k] = 1;
                }
            }
        }
        foreach ($carton as $p) {
            foreach ([$p->sync_code, $p->sku, $p->barcode] as $code) {
                $k = Excel::key(Excel::barcode((string) $code));
                if ($k !== '') {
                    $buy[$k] = 1;
                }
            }
        }
        file_put_contents(static::dir($id).'/plan.json', json_encode(['plan' => $plan, 'lists' => $lists, 'unknown' => array_values($unknown), 'buy' => $hasCarton ? array_keys($buy) : null], JSON_UNESCAPED_UNICODE));
        DB::table('stock_scans')->where('id', $id)->update(['status' => 'preview', 'stats' => json_encode($stats, JSON_UNESCAPED_UNICODE), 'options' => json_encode(['kinds' => $kinds, 'scope' => $scope]), 'updated_at' => now()]);

        return $stats + ['samples' => array_map(fn ($l) => array_slice($l, 0, 150), $lists)];
    }

    /** اعمال برنامه پیش‌نمایش؛ وضعیت قبلی برای برگشت ذخیره می‌شود */
    public static function apply(int $id): array
    {
        @set_time_limit(300);
        $lock = Cache::lock('stock-scan-apply', 300);
        if (! $lock->get()) {
            throw new RuntimeException('یک به‌روزرسانی موجودی دیگر در حال اجراست؛ چند لحظه بعد دوباره بزنید.');
        }
        try {
            $data = json_decode((string) @file_get_contents(static::dir($id).'/plan.json'), true);
            if (! $data) {
                throw new RuntimeException('اول «بررسی» را بزنید.');
            }
            $scan = DB::table('stock_scans')->where('id', $id)->first();
            if (! $scan || $scan->status === 'applied') {
                throw new RuntimeException('این به‌روزرسانی قبلاً اعمال شده است.');
            }
            $plan = (array) $data['plan'];
            $ids = array_map('intval', array_keys($plan));
            $snapshot = [];
            $groups = [];
            $stamp = now()->format('Y-m-d H:i:s');
            foreach (array_chunk($ids, 500) as $chunk) {
                foreach (Product::query()->whereIn('id', $chunk)->get(['id', 'per_carton', 'carton_enabled', 'retail_enabled', 'in_stock', 'stock', 'retail_in_stock', 'retail_stock']) as $p) {
                    [$c, $r, $hc, $hr] = array_pad($plan[$p->id], 4, 1);
                    $snapshot[$p->id] = [(int) $p->in_stock, $p->stock, (int) $p->retail_in_stock, $p->retail_stock];
                    $retailOk = $p->retailAllowed();
                    $pc = max(1, (int) $p->per_carton);
                    $upd = ['stock' => $p->stock, 'retail_in_stock' => (bool) $p->retail_in_stock, 'retail_stock' => $p->retail_stock];
                    // کارتنی: فقط اگر فایل عمده داده شده (موجود = بدون شمارش، ناموجود = ۰)
                    if ($hc) {
                        $upd['stock'] = $c ? ($p->stock !== null && $p->stock >= $pc ? $p->stock : null) : ($p->carton_enabled ? 0 : $p->stock);
                        $cEff = (bool) $c;
                    } else {
                        $cEff = (bool) $p->carton_enabled && (bool) $p->in_stock && ($p->stock === null || $p->stock >= $pc);
                    }
                    // خرده: فقط اگر فایل خرده داده شده
                    if ($hr && $retailOk) {
                        $upd['retail_in_stock'] = (bool) $r;
                        $upd['retail_stock'] = $r && $p->retail_stock !== null && $p->retail_stock <= 0 ? null : $p->retail_stock;
                    }
                    $rEff = $retailOk && $upd['retail_in_stock'] && ($upd['retail_stock'] === null || $upd['retail_stock'] > 0);
                    $upd['in_stock'] = $cEff || $rEff;
                    // اگر کالا با خرده «موجود» شد ولی کارتنی‌اش ناموجود بود، کارتنی ناموجود بماند
                    if ($upd['in_stock'] && ! $cEff && $p->carton_enabled && $upd['stock'] === null) {
                        $upd['stock'] = 0;
                    }
                    // تعداد موجودی مستقیم عوض شد ← زمانش ثبت می‌شود (سفارش‌های قبلی هنگام لغو آن را بالا نمی‌برند)
                    if (Product::hasStockAt()) {
                        if ($upd['stock'] !== $p->stock) {
                            $upd['stock_at'] = $stamp;
                        }
                        if ($upd['retail_stock'] !== $p->retail_stock) {
                            $upd['retail_stock_at'] = $stamp;
                        }
                    }
                    $groups[json_encode($upd)][] = $p->id;
                }
            }
            file_put_contents(static::dir($id).'/snapshot.json', json_encode($snapshot));
            $now = now();
            DB::transaction(function () use ($groups, $now) {
                foreach ($groups as $upd => $gids) {
                    $u = json_decode($upd, true) + ['updated_at' => $now, 'changed_at' => $now];
                    foreach (array_chunk($gids, 500) as $ch) {
                        DB::table('products')->whereIn('id', $ch)->update($u);
                    }
                }
            });
            // پیامک «موجود شد» از این بخش فرستاده نمی‌شود (فقط از «اطلاعات کالا» با تیک مربوط)
            \App\Http\Middleware\GuestPageCache::bump();
            Cache::forget('home.blocks');
            Cache::forget('api.home');
            $stats = (array) json_decode((string) $scan->stats, true);
            DB::table('stock_scans')->where('id', $id)->update(['status' => 'applied', 'applied_at' => $now, 'updated_at' => $now]);
            static::cleanupFiles($id);
            // ملاک موجودی اپ خرید و تأمین: آخرین فایل‌های عمده اعمال‌شده
            if (! empty($data['buy'])) {
                file_put_contents(static::dir($id).'/buy.json', json_encode(array_map('strval', $data['buy'])));
                try {
                    Purchasing::onCartonScan(array_fill_keys(array_map('strval', $data['buy']), 1), $now); // بار خریده‌شده‌ای که در اسکن نیامد
                } catch (Throwable $e) {
                    report($e);
                }
            } else {
                @unlink(static::dir($id).'/buy.json');
            }
            Purchasing::flush();

            return ['ok' => true, 'counts' => $stats['counts'] ?? [], 'changed' => count($plan)];
        } finally {
            $lock->release();
        }
    }

    /** برگرداندن یک به‌روزرسانی اعمال‌شده به وضعیت پیش از آن */
    public static function undo(int $id): int
    {
        $scan = DB::table('stock_scans')->where('id', $id)->first();
        if (! $scan || $scan->status !== 'applied') {
            throw new RuntimeException('فقط به‌روزرسانی اعمال‌شده قابل برگشت است.');
        }
        if (DB::table('stock_scans')->where('status', 'applied')->where('id', '>', $id)->exists()) {
            throw new RuntimeException('بعد از این، به‌روزرسانی دیگری هم اعمال شده؛ اول آن را برگردانید.');
        }
        $snap = json_decode((string) @file_get_contents(static::dir($id).'/snapshot.json'), true);
        if (! is_array($snap)) {
            throw new RuntimeException('اطلاعات برگشت این به‌روزرسانی پیدا نشد.');
        }
        $now = now();
        DB::transaction(function () use ($snap, $now) {
            foreach ($snap as $pid => [$in, $stock, $rin, $rstock]) {
                DB::table('products')->where('id', (int) $pid)->update(Product::unlimitStock(['in_stock' => (bool) $in, 'stock' => $stock, 'retail_in_stock' => (bool) $rin, 'retail_stock' => $rstock]) + ['updated_at' => $now, 'changed_at' => $now]);
            }
        });
        DB::table('stock_scans')->where('id', $id)->update(['status' => 'reverted', 'reverted_at' => $now, 'updated_at' => $now]);
        if (is_file(static::dir($id).'/buy.json') && $scan->applied_at) {
            try {
                Purchasing::onScanUndo(\Illuminate\Support\Carbon::parse($scan->applied_at));
            } catch (Throwable $e) {
                report($e);
            }
        }
        Purchasing::flush();
        \App\Http\Middleware\GuestPageCache::bump();
        Cache::forget('home.blocks');
        Cache::forget('api.home');

        return count($snap);
    }

    /**
     * کدهای موجود در انبار عمده طبق آخرین اسکن اعمال‌شده‌ای که فایل عمده داشته (برای اپ خرید و تأمین).
     * null = هنوز اسکنی نیست (اپ مثل قبل از موجودی کالای سایت می‌خواند).
     *
     * @return array{id: int, at: string, keys: array<string, int>}|null
     */
    public static function buyKeys(): ?array
    {
        if (! \App\Support\DbSchema::hasTable('stock_scans')) {
            return null;
        }
        // اسکن فقط-خرده ملاک را عوض نمی‌کند: آخرین اسکنی که فایل عمده داشته
        foreach (DB::table('stock_scans')->where('status', 'applied')->orderByDesc('id')->limit(60)->get(['id', 'applied_at']) as $s) {
            $f = static::dir((int) $s->id).'/buy.json';
            if (is_file($f) && is_array($keys = json_decode((string) file_get_contents($f), true)) && $keys) {
                return ['id' => (int) $s->id, 'at' => (string) $s->applied_at, 'keys' => array_fill_keys(array_map('strval', $keys), 1)];
            }
        }

        return null;
    }

    public static function lists(int $id): array
    {
        return (array) json_decode((string) @file_get_contents(static::dir($id).'/plan.json'), true);
    }

    protected static function cleanupFiles(int $id): void
    {
        foreach (glob(static::dir($id).'/files/*') ?: [] as $f) {
            @unlink($f);
        }
        @rmdir(static::dir($id).'/files');
    }

    /** پاک کردن پوشه‌های قدیمی (بیش از ۶۰ روز) */
    public static function prune(): void
    {
        foreach (DB::table('stock_scans')->where('created_at', '<', now()->subDays(60))->pluck('id') as $id) {
            $d = static::dir((int) $id);
            foreach (glob($d.'/{files/*,*.json}', GLOB_BRACE) ?: [] as $f) {
                @unlink($f);
            }
            @rmdir($d.'/files');
            @rmdir($d);
        }
    }
}
