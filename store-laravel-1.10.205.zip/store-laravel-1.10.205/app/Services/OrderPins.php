<?php

namespace App\Services;

use App\Models\Order;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * یادداشت‌های داخلی پین‌شده سفارش: بالای گفتگو برای همکاران (مشتری نمی‌بیند).
 * متن یا صدا؛ اضافه، ویرایش و حذف؛ به سفارش وصل است، پس با سپردن به همکار دیگر هم می‌ماند.
 */
class OrderPins
{
    public static function on(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasTable('order_pins');
    }

    public static function add(Order $o, User $u, string $kind, ?string $text, array $voice = [], ?int $msgId = null): void
    {
        if (! static::on()) {
            return;
        }
        DB::table('order_pins')->insert([
            'order_id' => $o->id, 'user_id' => $u->id, 'kind' => $kind === 'voice' ? 'voice' : 'text',
            'body' => $text !== null ? mb_substr($text, 0, 3000) : null, 'path' => $voice['path'] ?? null, 'sec' => $voice['sec'] ?? null,
            'msg_id' => $msgId, 'created_at' => now(), 'updated_at' => now(),
        ]);
    }

    public static function edit(Order $o, User $u, int $id, string $text): void
    {
        $text = trim($text);
        if ($text === '') {
            throw ValidationException::withMessages(['text' => 'متن یادداشت خالی است.']);
        }
        $row = static::row($o, $id);
        if ($row->kind !== 'text') {
            throw ValidationException::withMessages(['text' => 'یادداشت صوتی ویرایش نمی‌شود؛ حذف کنید و دوباره ضبط کنید.']);
        }
        DB::table('order_pins')->where('id', $id)->update(['body' => mb_substr($text, 0, 3000), 'edited_by' => $u->id, 'updated_at' => now()]);
        $o->log('📌 یادداشت داخلی ویرایش شد — '.$u->displayName(), $u->id);
    }

    public static function delete(Order $o, User $u, int $id): void
    {
        $row = static::row($o, $id);
        DB::table('order_pins')->where('id', $id)->delete();
        $o->log('📌 یادداشت داخلی حذف شد'.($row->kind === 'text' ? ': «'.mb_substr((string) $row->body, 0, 120).'»' : ' (صوتی)').' — '.$u->displayName(), $u->id);
    }

    protected static function row(Order $o, int $id): object
    {
        $row = static::on() ? DB::table('order_pins')->where('order_id', $o->id)->where('id', $id)->first() : null;
        if (! $row) {
            throw ValidationException::withMessages(['pin' => 'یادداشت پیدا نشد (شاید همکار دیگری حذفش کرده).']);
        }

        return $row;
    }

    /** برای گفتگو (همکار) */
    public static function list(Order $o, User $u, bool $can): array
    {
        if (! static::on()) {
            return [];
        }
        $rows = DB::table('order_pins')->where('order_id', $o->id)->orderBy('id')->get();
        $names = User::query()->whereIn('id', $rows->pluck('user_id')->merge($rows->pluck('edited_by'))->filter()->unique())->get()->keyBy('id');

        return $rows->map(fn ($r) => [
            'id' => (int) $r->id, 'kind' => $r->kind, 'text' => (string) $r->body,
            'url' => $r->path ? upload_url($r->path) : null, 'sec' => (int) $r->sec,
            'by' => $names[$r->user_id]?->displayName() ?? '—', 'at' => jdate(\Illuminate\Support\Carbon::parse($r->created_at), true),
            'ed' => $r->edited_by ? ($names[$r->edited_by]?->displayName() ?? '') : null,
            'can' => $can || (int) $r->user_id === (int) $u->id,
        ])->values()->all();
    }
}
