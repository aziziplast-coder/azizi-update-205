<?php

namespace App\Services;

use App\Models\SyncItem;
use App\Services\Sync\SyncEngine;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Throwable;

/**
 * تصویر کوچک کالاها برای اپ خرید.
 * هر تصویر یک بار ساخته و به‌صورت فایل ثابت در public/uploads/_buyer ذخیره می‌شود تا وب‌سرور مستقیم
 * (بدون PHP) و فوری آن را بدهد. کلید: p{id} = کالای سایت، s{id} = ردیف فید JSON.
 * تصاویر کالاهای ناموجود در پس‌زمینه (کرون/بازدیدها) از قبل آماده می‌شوند تا اپ تأخیر نداشته باشد.
 */
class BuyerImages
{
    public const DIR = 'uploads/_buyer';

    public static function path(string $key): string
    {
        return public_path(static::DIR.'/'.$key.'.jpg');
    }

    public static function url(string $key): string
    {
        return '/'.static::DIR.'/'.$key.'.jpg';
    }

    protected static function missFile(string $key): string
    {
        return storage_path('app/buyer-img/'.$key.'.miss');
    }

    public static function missed(string $key): bool
    {
        $f = static::missFile($key);

        return is_file($f) && filemtime($f) > time() - 6 * 3600;
    }

    /** ساخت تصویر کوچک؛ true اگر فایل آماده باشد */
    public static function ensureDir(): void
    {
        if (! is_dir(public_path(static::DIR))) {
            @mkdir(public_path(static::DIR), 0755, true);
        }
        if (! is_file(public_path(static::DIR.'/.htaccess'))) {
            // فقط در حافظه همان نوبت مرورگر (نه ذخیره روی گوشی)؛ اسکریپت هم اجرا نمی‌شود
            @file_put_contents(public_path(static::DIR.'/.htaccess'), "<IfModule mod_headers.c>\n    Header set Cache-Control \"no-store\"\n</IfModule>\n<FilesMatch \"\\.(php\\d?|phtml|phar|cgi|pl|py|sh)$\">\n    Require all denied\n</FilesMatch>\n");
        }
    }

    public static function make(string $key): bool
    {
        static::ensureDir();
        if (is_file(static::path($key))) {
            return true;
        }
        if (! preg_match('/^([ps])(\d+)$/', $key, $m) || static::missed($key)) {
            return false;
        }
        [$type, $id] = [$m[1], (int) $m[2]];
        @is_dir(storage_path('app/buyer-img')) || @mkdir(storage_path('app/buyer-img'), 0755, true);
        $body = null;
        $saved = null;
        try {
            if ($type === 'p') {
                $img = (string) DB::table('products')->where('id', $id)->value('image');
                if ($img !== '' && ! preg_match('#^(https?:)?//#i', $img)) {
                    $local = public_path('uploads/'.ltrim($img, '/'));
                    $body = is_file($local) ? @file_get_contents($local) : null;
                } elseif ($img !== '') {
                    $body = static::fetch(str_starts_with($img, '//') ? 'https:'.$img : $img);
                }
            } else {
                $item = SyncItem::query()->with('source')->find($id);
                if ($item && $item->source) {
                    try {
                        $saved = (new SyncEngine($item->source))->mainImageFor($item);
                    } catch (Throwable) {
                        $saved = null;
                    }
                    if ($saved && is_file(public_path('uploads/'.$saved))) {
                        $body = @file_get_contents(public_path('uploads/'.$saved));
                    } else {
                        foreach (array_slice((array) $item->images, 0, 2) as $u) {
                            if (is_string($u) && ($body = static::fetch($u))) {
                                break;
                            }
                        }
                    }
                }
            }
            $src = $body ? @imagecreatefromstring($body) : false;
            if (! $src) {
                @touch(static::missFile($key));

                return false;
            }
            $w = imagesx($src);
            $h = imagesy($src);
            $k = min(1, 240 / max($w, $h));
            $dst = imagecreatetruecolor(max(1, (int) round($w * $k)), max(1, (int) round($h * $k)));
            imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
            imagecopyresampled($dst, $src, 0, 0, 0, 0, imagesx($dst), imagesy($dst), $w, $h);
            $tmp = static::path($key).'.tmp';
            imagejpeg($dst, $tmp, 78);
            @rename($tmp, static::path($key));
            imagedestroy($src);
            imagedestroy($dst);

            return is_file(static::path($key));
        } catch (Throwable) {
            @touch(static::missFile($key));

            return false;
        } finally {
            // فایل بزرگی که فقط برای پیش‌نمایش خرید دریافت شد پاک می‌شود (کالا هنوز ساخته نشده)
            if ($saved && is_file(public_path('uploads/'.$saved)) && ! DB::table('products')->where('image', $saved)->exists()) {
                @unlink(public_path('uploads/'.$saved));
            }
        }
    }

    public static function fetch(string $url): ?string
    {
        if (! preg_match('#^https?://#i', $url)) {
            return null;
        }
        $host = parse_url($url, PHP_URL_SCHEME).'://'.parse_url($url, PHP_URL_HOST).'/';
        foreach (array_unique([$url, preg_replace('#^https://#i', 'http://', $url)]) as $u) {
            try {
                $r = Http::timeout(15)->connectTimeout(6)->withoutVerifying()->withHeaders([
                    'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
                    'Accept' => 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
                    'Referer' => $host,
                ])->get($u);
                if ($r->successful() && strlen($r->body()) < 10_000_000 && @getimagesizefromstring($r->body())) {
                    return $r->body();
                }
            } catch (Throwable) {
            }
        }

        return null;
    }

    /**
     * آماده‌سازی پس‌زمینه: تصاویرِ کالاهای فهرست خرید که هنوز ساخته نشده‌اند (اول پرفروش‌ها و سبد خرید).
     * با بودجه زمانی کوتاه تا بار هاست بالا نرود؛ در اجراهای بعدی ادامه می‌یابد.
     */
    public static function warm(float $budget = 20, int $max = 80): int
    {
        if (! Purchasing::ready() || ! Cache::add('buyer:img:warm', 1, (int) ceil($budget) + 30)) {
            return 0;
        }
        $t0 = microtime(true);
        $n = 0;
        try {
            $ds = Purchasing::dataset();
            $items = $ds['items'];
            $cart = array_flip(DB::table('purchase_marks')->where('cartons', '>', 0)->pluck('code_key')->all());
            usort($items, fn ($a, $b) => (isset($cart[$b[8] ?: $b[1]]) <=> isset($cart[$a[8] ?: $a[1]])) ?: ($b[7] <=> $a[7]));
            foreach ($items as $it) {
                $u = (string) ($it[10] ?? '');
                if (! preg_match('#/buyer/img/([ps]\d+)$#', $u, $m) || is_file(static::path($m[1])) || static::missed($m[1])) {
                    continue;
                }
                static::make($m[1]);
                $n++;
                if ($n >= $max || microtime(true) - $t0 > $budget) {
                    break;
                }
            }
            if ($n && Cache::add('buyer:img:flush', 1, 900)) {
                Purchasing::flush(); // حداکثر هر ۱۵ دقیقه: آدرس‌ها به فایل ثابت تغییر کنند
            }
        } catch (Throwable $e) {
            report($e);
        } finally {
            Cache::forget('buyer:img:warm');
        }

        return $n;
    }
}
