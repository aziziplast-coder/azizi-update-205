<?php

namespace App\Services;

use App\Models\RemitPayment;
use App\Models\Remittance;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * فیش حضوری: مشتری حضوری (فاکتورش در هلو) بدون سفارش سایت مبلغی را به حساب یک حواله واریز می‌کند.
 * کمک‌حسابدار فیش را صادر و با فیش‌پرینتر چاپ می‌کند؛ عکس فیش واریز را خود مشتری (با لینک/QR روی فیش)
 * یا کمک‌حسابدار (با گوشی/پنل) بارگذاری می‌کند و پس از دیدن مبلغ در حساب تأیید می‌شود.
 */
class WalkinReceipt
{
    public static function on(): bool
    {
        return \App\Support\DbSchema::hasColumn('remit_payments', 'walkin_token');
    }

    /** حواله‌هایی که این همکار می‌تواند برایشان فیش صادر کند (با ظرفیت آزاد) */
    public static function remits(User $u): Collection
    {
        return Remittance::query()->where('status', 'active')
            ->when(! Remit::isChief($u), fn ($q) => $q->where('assignee_id', $u->id))
            ->orderBy('sort')->orderBy('id')->get()
            ->map(function (Remittance $r) {
                $r->setAttribute('free', (int) $r->stats()['free']);

                return $r;
            })->filter(fn ($r) => $r->free > 0)->values();
    }

    public static function issue(User $by, string $name, ?string $mobile, int $amount, int $remitId, ?string $note = null): RemitPayment
    {
        $name = trim(strip_tags($name));
        if (mb_strlen($name) < 2) {
            throw ValidationException::withMessages(['name' => 'نام مشتری را بنویسید.']);
        }
        if ($amount < 1000) {
            throw ValidationException::withMessages(['amount' => 'مبلغ را درست بنویسید.']);
        }
        if (! $by->hasPerm('walkin')) {
            throw ValidationException::withMessages(['name' => 'دسترسی صدور فیش حضوری به شما داده نشده است.']);
        }
        $mobile = $mobile ? (mobile($mobile) ?: null) : null;

        return DB::transaction(function () use ($by, $name, $mobile, $amount, $remitId, $note) {
            $r = Remittance::query()->whereKey($remitId)->where('status', 'active')->lockForUpdate()->first();
            if (! $r || (! Remit::isChief($by) && (int) $r->assignee_id !== (int) $by->id)) {
                throw ValidationException::withMessages(['remit' => 'این حواله در دسترس شما نیست.']);
            }
            $free = (int) $r->stats()['free'];
            if ($amount > $free) {
                throw ValidationException::withMessages(['amount' => 'ظرفیت آزاد حواله '.fa($r->code).' فقط '.money($free).' تومان است؛ مبلغ را کمتر کنید یا حواله دیگری انتخاب کنید.']);
            }
            $p = RemitPayment::query()->create([
                'remittance_id' => $r->id, 'order_id' => null, 'user_id' => null, 'kind' => 'walkin', 'amount' => $amount, 'status' => 'awaiting',
                'issued_by' => $by->id, 'walkin_name' => mb_substr($name, 0, 120), 'walkin_mobile' => $mobile,
                'walkin_token' => Str::lower(Str::random(24)), 'customer_note' => $note ? mb_substr(trim($note), 0, 300) : null,
            ]);
            Remit::checkFilled($r->fresh());

            return $p;
        });
    }

    /** لینک بارگذاری فیش برای خود مشتری (روی فیش چاپی به صورت QR) */
    public static function link(RemitPayment $p): string
    {
        return route('walkin.show', $p->walkin_token);
    }

    public static function byToken(string $token): ?RemitPayment
    {
        return static::on() && strlen($token) >= 16 ? RemitPayment::query()->with('remittance')->where('walkin_token', $token)->first() : null;
    }

    /** اطلاعات حساب مقصد برای فیش چاپی و صفحه مشتری */
    public static function account(RemitPayment $p): array
    {
        $r = $p->remittance;

        return [
            'holder' => (string) $r?->holder_name, 'bank' => (string) $r?->bank_name,
            'card' => $r?->card_number ? \App\Support\Banks::formatCard($r->card_number) : '', 'sheba' => $r?->sheba ? \App\Support\Banks::formatSheba($r->sheba) : '',
            'account' => (string) ($r?->account_number ?? ''), 'code' => (string) $r?->code,
        ];
    }
}
