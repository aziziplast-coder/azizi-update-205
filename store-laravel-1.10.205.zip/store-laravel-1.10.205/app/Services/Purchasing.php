<?php

namespace App\Services;

use App\Models\PurchaseOrder;
use App\Models\Supplier;
use App\Models\SupplyItem;
use App\Models\User;
use App\Support\Search;
use App\Support\SheetReader;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use RuntimeException;

/**
 * خرید و تأمین کالاهای ناموجود.
 *
 * اکسل تأمین‌کنندگان (کد کالا، نام کالا، نام طرف حساب) جدا از محصولات سایت نگه داشته می‌شود و هر بار جایگزین می‌شود.
 * هر کد فقط برای خواندن «موجودی» به کالای سایت (کد هلو/SKU/بارکد) یا ردیف فید JSON وصل می‌شود.
 * مسئول خرید کالاهای ناموجود هر کارخانه را می‌بیند، تعداد کارتن می‌زند، موارد ناخواسته را حذف می‌کند
 * و برای هر کارخانه سفارش خرید (گزارش PDF/تصویر) می‌سازد.
 */
class Purchasing
{
    public const PERM = 'purchasing';

    /** با هر تغییر در ساختار داده اپ عوض شود تا کش سرور و گوشی‌ها تازه شود */
    public const FORMAT = 'f8';

    /** حالت کالا در فهرست: o = ناموجود، l = کم‌موجود، n = در سایت/فید پیدا نشد */
    public const STATES = ['o' => 'ناموجود', 'l' => 'کم‌موجود', 'n' => 'نامشخص'];

    public static function ready(): bool
    {
        return \App\Support\DbSchema::hasTable('supply_items') && \App\Support\DbSchema::hasTable('purchase_marks');
    }

    public static function canUse(?User $u): bool
    {
        return (bool) $u?->is_active && $u->hasPerm(self::PERM);
    }

    /** موجودی و تصویر از فید JSON سایت قبلی خوانده شود؟ (پیش‌فرض خاموش: فقط کالاهای خود سایت) */
    public static function useFeed(): bool
    {
        return (bool) setting('buy_use_feed', false) && \App\Support\DbSchema::hasTable('sync_items');
    }

    public static function cfg(): array
    {
        return [
            'low' => max(0, min(50, (int) setting('buy_low_cartons', 0))),
            'hide_ordered_days' => max(0, min(120, (int) setting('buy_ordered_days', 21))),
            'app_name' => setting('buy_app_name') ?: 'اپ خرید و تأمین',
            'report_note' => (string) setting('buy_report_note', 'لطفاً موجودی و زمان ارسال را اعلام بفرمایید.'),
            'report_phone' => (string) (setting('buy_report_phone') ?: setting('store_phone') ?: ''),
            'unload_rules' => (string) setting('buy_unload_rules', ''),
            'report_name' => trim((string) setting('buy_report_name', '')),   // نام روی گزارش کارخانه؛ خالی = بدون نام
            'report_logo' => (bool) setting('buy_report_logo', false),
            'report_images' => (bool) setting('buy_report_images', false),   // پیش‌فرض: تصویر فقط برای اپراتور
            'report_total' => (bool) setting('buy_report_total', true),
            'price_unit' => (string) (setting('buy_price_unit') ?: 'ریال'),
        ];
    }

    /* =================== ورود اکسل =================== */

    /**
     * ورود یک فایل اکسل؛ نوع فایل از روی سرستون‌ها تشخیص داده می‌شود:
     *  - فایل کالاها: بارکد/کد کالا + نام کالا + تأمین‌کننده (+ تعداد در کارتن) → جایگزینی کامل فهرست
     *  - فایل فروش: بارکد/کد کالا + فروش (یک یا چند ستون فروش، مثلاً حضوری و آنلاین، جمع زده می‌شوند) → جایگزینی آمار فروش
     */
    public static function import(string $path, string $fileName, ?User $by = null): array
    {
        @set_time_limit(600);
        @ini_set('memory_limit', '512M');

        $rows = [];
        SheetReader::read($path, $fileName, function ($r) use (&$rows) {
            $rows[] = $r;
        });
        if (! $rows) {
            throw new RuntimeException('فایل «'.$fileName.'» خالی است.');
        }
        [$cols, $start, $kind] = static::detectColumns($rows);

        $stats = $kind === 'sales'
            ? static::importSales($rows, $cols, $start)
            : static::importSupply($rows, $cols, $start);

        DB::table('supply_imports')->insert([
            'kind' => $kind, 'file_name' => mb_substr($fileName, 0, 190), 'user_id' => $by?->id, 'created_at' => now(), 'updated_at' => now(),
            'rows' => $stats['rows'], 'suppliers' => $stats['suppliers'] ?? 0, 'matched' => $stats['matched'], 'feed_only' => $stats['feed_only'] ?? 0,
            'unmatched' => $stats['unmatched'], 'skipped' => $stats['skipped'],
        ]);
        static::flush();

        return $stats + ['kind' => $kind, 'file' => $fileName];
    }

    protected static function importSupply(array &$rows, array $cols, int $start): array
    {
        $items = [];
        $skipped = 0;
        $supNames = [];
        for ($i = $start, $n = count($rows); $i < $n; $i++) {
            $r = $rows[$i];
            $code = Excel::barcode($r[$cols['code']] ?? '');
            $name = static::clean($r[$cols['name']] ?? '');
            $sup = static::cleanSupplier($r[$cols['supplier']] ?? '');
            if ($code === '' || $sup === '') {
                if (trim(implode('', array_map('strval', $r))) !== '') {
                    $skipped++;
                }
                continue;
            }
            $pc = isset($cols['pc']) ? (int) Excel::number($r[$cols['pc']] ?? '') : 0;
            $price = isset($cols['price']) ? (int) Excel::number($r[$cols['price']] ?? '') : 0;
            $key = Excel::key($code);
            $sk = mb_substr(Search::normalize($sup), 0, 190) ?: $sup;
            $supNames[$sk] ??= $sup;
            $items[$key] = ['code' => mb_substr($code, 0, 60), 'code_key' => mb_substr($key, 0, 60), 'name' => mb_substr($name ?: $code, 0, 250), 'sk' => $sk, 'row' => $i + 1, 'pc' => $pc > 0 ? min($pc, 100000) : null, 'price' => $price > 0 ? $price : null];
        }
        $rows = [];
        if (! $items) {
            throw new RuntimeException('هیچ ردیف معتبری پیدا نشد. ستون‌های لازم: بارکد (کد کالا)، نام کالا، تأمین‌کننده.');
        }
        // محافظ: اگر بیشتر «تأمین‌کننده‌ها» فقط عدد باشند، این فایل فهرست تأمین‌کننده نیست (مثلاً گزارش فروش با ستون تعداد)
        $numeric = count(array_filter($supNames, fn ($n) => is_numeric(str_replace([',', '٬'], '', en_digits((string) $n)))));
        if (count($supNames) >= 5 && $numeric > count($supNames) * 0.5) {
            throw new RuntimeException('این فایل شبیه فهرست «کالاها بر اساس تأمین‌کننده» نیست: در ستون تأمین‌کننده به‌جای نام، عدد آمده است. اگر گزارش فروش است، سرستون ستون تعداد را «تعداد» یا «فروش» بگذارید. فهرست فعلی دست نخورد.');
        }

        // تطبیق کد با کالای سایت و ردیف فید (فقط برای خواندن موجودی انبار عمده)
        $pmap = static::productCodeMap();
        $smap = [];
        if (\App\Support\DbSchema::hasTable('sync_items')) {
            foreach (DB::table('sync_items')->select('id', 'code', 'product_id')->orderBy('id')->cursor() as $s) {
                $smap[Excel::key(Excel::barcode($s->code))] = [$s->id, $s->product_id];
            }
        }
        $stats = ['rows' => count($items), 'suppliers' => count($supNames), 'matched' => 0, 'feed_only' => 0, 'unmatched' => 0, 'skipped' => $skipped, 'with_pc' => 0, 'with_price' => 0];

        DB::transaction(function () use ($items, $supNames, $pmap, $smap, &$stats) {
            $sup = Supplier::query()->pluck('id', 'name_key')->all();
            $now = now();
            foreach ($supNames as $k => $name) {
                if (! isset($sup[$k])) {
                    $sup[$k] = Supplier::query()->create(['name' => $name, 'name_key' => $k])->id;
                } else {
                    Supplier::query()->whereKey($sup[$k])->update(['name' => $name, 'updated_at' => $now]);
                }
            }
            Supplier::query()->update(['in_file' => false, 'items_count' => 0]);

            DB::table('supply_items')->delete();
            $buf = [];
            $count = [];
            foreach ($items as $k => $it) {
                $pid = $pmap[$k] ?? null;
                $sync = $smap[$k] ?? null;
                $pid ??= $sync[1] ?? null;
                if ($pid) {
                    $stats['matched']++;
                } elseif ($sync) {
                    $stats['feed_only']++;
                } else {
                    $stats['unmatched']++;
                }
                if ($it['pc']) {
                    $stats['with_pc']++;
                }
                if ($it['price']) {
                    $stats['with_price']++;
                }
                $sid = $sup[$it['sk']];
                $count[$sid] = ($count[$sid] ?? 0) + 1;
                $buf[] = ['code' => $it['code'], 'code_key' => $it['code_key'], 'name' => $it['name'], 'supplier_id' => $sid, 'product_id' => $pid, 'sync_item_id' => $sync[0] ?? null, 'row' => $it['row'], 'per_carton' => $it['pc'], 'last_price' => $it['price']];
                if (count($buf) >= 400) {
                    DB::table('supply_items')->insert($buf);
                    $buf = [];
                }
            }
            if ($buf) {
                DB::table('supply_items')->insert($buf);
            }
            foreach ($count as $sid => $c) {
                Supplier::query()->whereKey($sid)->update(['items_count' => $c, 'in_file' => true]);
            }
            // علامت کالاهایی که دیگر در فایل نیستند پاک می‌شود (کارتن/حذف بقیه می‌ماند)
            DB::table('purchase_marks')->whereNotIn('code_key', DB::table('supply_items')->select('code_key'))->delete();
        });

        return $stats;
    }

    /** فایل فروش: جمع همه ستون‌های فروش برای هر بارکد؛ آمار قبلی کامل جایگزین می‌شود */
    protected static function importSales(array &$rows, array $cols, int $start): array
    {
        $sales = [];
        $skipped = 0;
        for ($i = $start, $n = count($rows); $i < $n; $i++) {
            $r = $rows[$i];
            $code = Excel::barcode($r[$cols['code']] ?? '');
            if ($code === '') {
                if (trim(implode('', array_map('strval', $r))) !== '') {
                    $skipped++;
                }
                continue;
            }
            $q = 0;
            foreach ($cols['sales'] as $c) {
                $q += max(0, (int) Excel::number($r[$c] ?? ''));
            }
            $k = mb_substr(Excel::key($code), 0, 60);
            $sales[$k] = ($sales[$k] ?? 0) + $q;
        }
        $rows = [];
        if (! $sales) {
            throw new RuntimeException('در فایل فروش هیچ ردیفی با بارکد پیدا نشد.');
        }
        $known = array_flip(DB::table('supply_items')->pluck('code_key')->all());
        $matched = count(array_intersect_key($sales, $known));

        DB::transaction(function () use ($sales) {
            DB::table('supply_sales')->delete();
            foreach (array_chunk($sales, 500, true) as $chunk) {
                DB::table('supply_sales')->insert(array_map(fn ($k, $v) => ['code_key' => (string) $k, 'qty' => $v], array_keys($chunk), $chunk));
            }
        });

        return ['rows' => count($sales), 'matched' => $matched, 'unmatched' => count($sales) - $matched, 'skipped' => $skipped, 'columns' => count($cols['sales'])];
    }

    /** پیدا کردن ستون‌ها و نوع فایل از روی سرستون‌ها */
    protected static function detectColumns(array $rows): array
    {
        $want = [
            'supplier' => ['طرف حساب', 'تامین کننده', 'تامینکننده', 'تهیه کننده', 'کارخانه', 'فروشنده', 'تولید کننده', 'تولیدکننده'],
            'price' => ['مبلغ آخرین خرید', 'آخرین خرید', 'اخرین خرید', 'مبلغ خرید', 'قیمت خرید', 'فی خرید', 'قیمت', 'مبلغ'],
            'pc' => ['تعداد در کارتن', 'تعداد درکارتن', 'در کارتن', 'درکارتن', 'تعداد کارتن', 'کارتن'],
            'code' => ['بارکد', 'کد کالا', 'کدکالا', 'کد محصول', 'کد'],
            'name' => ['نام کالا', 'نام محصول', 'شرح کالا', 'عنوان کالا', 'نام', 'شرح', 'عنوان'],
        ];
        foreach (array_slice($rows, 0, 15) as $i => $r) {
            $norm = [];
            foreach ($r as $c => $v) {
                $v = trim((string) $v);
                if ($v !== '' && mb_strlen($v) < 60 && ! is_numeric(en_digits($v))) {
                    $norm[$c] = Search::normalize($v);
                }
            }
            if (count($norm) < 2) {
                continue;
            }
            $found = [];
            $used = [];
            foreach ($want as $f => $words) {
                // برای تأمین‌کننده ستون «نام …» بر «کد …» مقدم است (مثل «نام طرف حساب» در برابر «کد طرف حساب»)
                $cells = $f === 'supplier' ? array_filter($norm, fn ($v) => str_contains($v, 'نام')) + $norm : $norm;
                foreach ($words as $w) {
                    foreach ($cells as $c => $v) {
                        if (! isset($used[$c]) && str_contains($v, $w)) {
                            $found[$f] = $c;
                            $used[$c] = 1;
                            break 2;
                        }
                    }
                }
            }
            $sales = [];
            foreach ($norm as $c => $v) {
                if (! isset($used[$c]) && (str_contains($v, 'فروش') || str_contains($v, 'تعداد فروخته'))) {
                    $sales[] = $c;
                }
            }
            // گزارش فروش هلو با سرستون ساده «تعداد» / «مقدار» (بدون ستون تأمین‌کننده): کد کالا، نام کالا، تعداد
            if (! $sales && isset($found['code']) && ! isset($found['supplier'])) {
                foreach ($norm as $c => $v) {
                    $t = trim($v);
                    if (! isset($used[$c]) && $c !== ($found['pc'] ?? null) && ! str_contains($t, 'کارتن')
                        && in_array($t, ['تعداد', 'مقدار', 'تعداد کل', 'جمع تعداد', 'تعداد فروش', 'مجموع تعداد'], true)) {
                        $sales[] = $c;
                    }
                }
            }
            if (isset($found['code'], $found['supplier'])) {
                $found['name'] ??= $found['code'] + 1;

                return [$found, $i + 1, 'supply'];
            }
            if (isset($found['code']) && $sales) {
                return [['code' => $found['code'], 'sales' => $sales], $i + 1, 'sales'];
            }
        }
        // بدون سرستون: دو ستون (کد، عدد) = فروش؛ وگرنه کد، نام، تأمین‌کننده، تعداد در کارتن (با ستون «ردیف» اختیاری)
        $first = array_values(array_filter($rows[0], fn ($v) => trim((string) $v) !== ''));
        if (count($first) === 2 && is_numeric(str_replace(',', '', en_digits((string) $first[1])))) {
            return [['code' => 0, 'sales' => [1]], 0, 'sales'];
        }
        $shift = count($first) >= 4 && ctype_digit(en_digits(trim((string) ($rows[0][0] ?? '')))) && ! is_numeric(en_digits(trim((string) ($rows[0][3] ?? 'x')))) ? 1 : 0;

        return [['code' => $shift, 'name' => $shift + 1, 'supplier' => $shift + 2, 'pc' => $shift + 3], 0, 'supply'];
    }

    public static function clean(mixed $v): string
    {
        return Excel::text(str_replace(['ى', 'ة'], ['ی', 'ه'], (string) $v));
    }

    public static function cleanSupplier(mixed $v): string
    {
        return trim(static::clean($v), " *\t-_");
    }

    /** نقشه کد → شناسه کالای سایت (کد هلو مقدم بر SKU و بارکد) */
    protected static function productCodeMap(): array
    {
        $map = [];
        $put = function (array &$m, ?string $code, int $id) {
            $k = Excel::key(Excel::barcode((string) $code));
            if ($k !== '' && ! isset($m[$k])) {
                $m[$k] = $id;
            }
        };
        $rows = DB::table('products')->select('id', 'sync_code', 'sku', 'barcode')->orderByDesc('is_active')->orderBy('id')->get();
        foreach (['sync_code', 'sku', 'barcode'] as $f) {
            foreach ($rows as $p) {
                $put($map, $p->{$f}, (int) $p->id);
            }
        }

        return $map;
    }

    /* =================== داده اپ =================== */

    public static function flush(): void
    {
        Cache::forget('buy:ver');
        Cache::forever('buy:gen', (int) Cache::get('buy:gen', 0) + 1); // داده اپ حتماً از نو ساخته شود
    }

    /** روزهایی که کالای خریده‌شده‌ای که در اسکن عمده نیامد، منتظر بررسی مسئول خرید «موجود» می‌ماند */
    public const ARRIVAL_GRACE_DAYS = 3;

    public static function arrivalsReady(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasTable('buy_arrivals');
    }

    /**
     * بارهای خریداری‌شده ۴۵ روز اخیر.
     *
     * @return array<string, object>
     */
    public static function arrivals(): array
    {
        if (! static::arrivalsReady()) {
            return [];
        }

        return DB::table('buy_arrivals')->where('arrived_at', '>=', now()->subDays(45))->get()->keyBy('code_key')->all();
    }

    /** کالای خریده‌شده‌ای که در اسکن عمده نیامده و منتظر بررسی است (سفارش‌دادنش بسته است) */
    public static function arrivalWaiting(?object $a): bool
    {
        return $a && ! $a->seen_at && ! $a->resolution && $a->missed_since
            && \Illuminate\Support\Carbon::parse($a->missed_since)->gt(now()->subDays(static::ARRIVAL_GRACE_DAYS));
    }

    /** @return array<string, true> */
    public static function waitingKeys(): array
    {
        $out = [];
        foreach (static::arrivals() as $k => $a) {
            if (static::arrivalWaiting($a)) {
                $out[(string) $k] = true;
            }
        }

        return $out;
    }

    /** آیا کالای خریده‌شده (فارغ از اسکن) فعلاً موجود حساب شود؟ */
    protected static function arrivalHolds(?object $a): bool
    {
        if (! $a || $a->seen_at || $a->resolution === 'gone') {
            return false; // اسکن بعد از خرید آن را دیده (ملاک دوباره اسکن است) یا بررسی شده که تمام شده
        }
        if (! $a->missed_since) {
            return true; // هنوز اسکن عمده‌ای بعد از خرید نیامده
        }
        $grace = now()->subDays(static::ARRIVAL_GRACE_DAYS);
        if ($a->resolution === 'here') {
            return \Illuminate\Support\Carbon::parse($a->resolved_at)->gt($grace);
        }

        return \Illuminate\Support\Carbon::parse($a->missed_since)->gt($grace); // منتظر بررسی
    }

    /**
     * کالاهای یک فایل خرید (اطلاعات کالا با «موجود شوند») در اپ خرید «موجود/رسیده» می‌شوند،
     * حتی اگر در سایت ساخته نشده باشند؛ از اسکن عمده بعدی دوباره اسکن ملاک است.
     */
    public static function markArrived(array $keys): int
    {
        $keys = array_values(array_unique(array_filter(array_map(fn ($k) => mb_substr((string) $k, 0, 60), $keys), fn ($k) => $k !== '')));
        if (! $keys || ! static::arrivalsReady()) {
            return 0;
        }
        $now = now();
        foreach (array_chunk($keys, 500) as $chunk) {
            DB::table('buy_arrivals')->upsert(
                array_map(fn ($k) => ['code_key' => $k, 'arrived_at' => $now, 'seen_at' => null, 'missed_since' => null, 'resolution' => null, 'resolved_by' => null, 'resolved_at' => null, 'created_at' => $now, 'updated_at' => $now], $chunk),
                ['code_key'], ['arrived_at', 'seen_at', 'missed_since', 'resolution', 'resolved_by', 'resolved_at', 'updated_at']
            );
        }
        DB::table('buy_arrivals')->where('arrived_at', '<', now()->subDays(60))->delete();
        static::flush();

        return count($keys);
    }

    /**
     * پس از اعمال هر اسکن عمده: کالای خریده‌شده‌ای که در اسکن آمد «دیده شد»؛
     * نیامد = گزارش به مسئول خرید (تا بررسی یا پایان مهلت، موجود می‌ماند).
     */
    public static function onCartonScan(array $keys, \DateTimeInterface $at): int
    {
        if (! static::arrivalsReady()) {
            return 0;
        }
        $rows = DB::table('buy_arrivals')->where('arrived_at', '>=', now()->subDays(45))->where('arrived_at', '<', $at)
            ->whereNull('seen_at')->where(fn ($q) => $q->whereNull('resolution')->orWhere('resolution', 'here'))->get(['id', 'code_key', 'missed_since', 'resolution']);
        $seen = $missed = [];
        foreach ($rows as $r) {
            if (isset($keys[$r->code_key])) {
                $seen[] = $r->id;
            } elseif (! $r->missed_since && ! $r->resolution) {
                $missed[] = $r->id;
            }
        }
        foreach (array_chunk($seen, 500) as $c) {
            DB::table('buy_arrivals')->whereIn('id', $c)->update(['seen_at' => $at, 'updated_at' => now()]);
        }
        foreach (array_chunk($missed, 500) as $c) {
            DB::table('buy_arrivals')->whereIn('id', $c)->update(['missed_since' => $at, 'updated_at' => now()]);
        }
        static::flush();
        if ($missed) {
            static::notifyBuyers('⚠️ '.fa(count($missed)).' کالای خریده‌شده در اسکن انبار نیامد', 'دیروز بارش خریده شده ولی امروز در اسکن انبار عمده نیست؛ در اپ خرید بررسی کنید.');
        }

        return count($missed);
    }

    /** برگرداندن یک اسکن: اثرش روی بارهای خریداری‌شده هم برمی‌گردد */
    public static function onScanUndo(\DateTimeInterface $at): void
    {
        if (! static::arrivalsReady()) {
            return;
        }
        DB::table('buy_arrivals')->where('seen_at', '>=', $at)->update(['seen_at' => null]);
        DB::table('buy_arrivals')->where('missed_since', '>=', $at)->whereNull('resolution')->update(['missed_since' => null]);
        static::flush();
    }

    /** بررسی مسئول خرید: here = در انبار هست (اسکن جا مانده)، gone = واقعاً تمام شده */
    public static function resolveArrival(string $key, string $how, ?User $by): void
    {
        abort_unless(in_array($how, ['here', 'gone'], true) && static::arrivalsReady(), 422);
        $n = DB::table('buy_arrivals')->where('code_key', $key)->update(['resolution' => $how, 'resolved_by' => $by?->id, 'resolved_at' => now(), 'updated_at' => now()]);
        if (! $n) {
            throw new RuntimeException('این مورد پیدا نشد.');
        }
        static::flush();
    }

    /** کالاهای خریده‌شده‌ای که در اسکن عمده نیامده‌اند و هنوز بررسی نشده‌اند */
    public static function arrivalAlerts(): array
    {
        if (! static::arrivalsReady()) {
            return [];
        }
        $grace = now()->subDays(static::ARRIVAL_GRACE_DAYS);
        $rows = DB::table('buy_arrivals as a')->leftJoin('supply_items as i', 'i.code_key', '=', 'a.code_key')
            ->whereNotNull('a.missed_since')->whereNull('a.seen_at')->whereNull('a.resolution')->where('a.missed_since', '>', $grace)
            ->orderBy('a.missed_since')->limit(500)
            ->get(['a.code_key', 'a.arrived_at', 'a.missed_since', 'i.code', 'i.name', 'i.supplier_id']);
        $names = [];
        $miss = $rows->filter(fn ($r) => ! $r->name)->pluck('code_key')->all();
        if ($miss) {
            $map = static::productCodeMap();
            $ids = array_filter(array_map(fn ($k) => $map[$k] ?? null, $miss));
            $pn = $ids ? DB::table('products')->whereIn('id', $ids)->pluck('name', 'id')->all() : [];
            foreach ($miss as $k) {
                $names[$k] = $pn[$map[$k] ?? 0] ?? null;
            }
        }

        return $rows->map(fn ($r) => [
            (string) $r->code_key, (string) ($r->code ?: $r->code_key), (string) ($r->name ?: ($names[$r->code_key] ?? '') ?: 'کالای '.$r->code_key), (int) $r->supplier_id,
            \App\Support\Jalali::format($r->arrived_at, false), \App\Support\Jalali::format($r->missed_since, false),
            max(0, (int) ceil((strtotime((string) $r->missed_since) + static::ARRIVAL_GRACE_DAYS * 86400 - time()) / 86400)),
        ])->values()->all();
    }

    protected static function version(): string
    {
        return Cache::remember('buy:ver', 120, function () {
            $imp = (int) DB::table('supply_imports')->max('id');
            $p = (string) DB::table('products')->max('updated_at');
            $s = \App\Support\DbSchema::hasTable('sync_items') ? (string) DB::table('sync_items')->max('updated_at') : '';

            $scan = (StockScan::buyKeys()['id'] ?? 0).'-'.(static::arrivalsReady() ? DB::table('buy_arrivals')->max('updated_at').'-'.DB::table('buy_arrivals')->count() : '');

            return md5(static::FORMAT.'|'.(int) static::useFeed().'|'.(int) Cache::get('buy:gen', 0).'|'.$imp.'|'.$p.'|'.$s.'|'.$scan.'|'.json_encode(static::cfg()).'|'.date('Y-m-d-H'));
        });
    }

    /**
     * کالاهای اکسل که برای خرید مجدد باید دیده شوند — ملاک فقط موجودی «کارتنی» کالای سایت است:
     *  - کالای سایت با خرید کارتنی موجود → موجود (در فهرست نمی‌آید)
     *  - کالای سایت که کارتنی ناموجود است (حتی اگر خرده موجود باشد) → ناموجود (o)
     *  - کالای اکسل که در سایت نیست → ناموجود (m)
     * خروجی فشرده هر کالا: [id, کد, نام, کارخانه, حالت, تعداد در کارتن, موجودی عمده, فروش, کلید, مبلغ آخرین خرید]
     */
    public static function dataset(bool $withUnknown = false): array
    {
        $key = 'buy:ds:'.static::version();
        $hit = Cache::get($key);
        if (is_array($hit)) {
            return $hit;
        }
        $cfg = static::cfg();
        $hasPrice = \App\Support\DbSchema::hasColumn('supply_items', 'last_price');
        $hasSync = \App\Support\DbSchema::hasTable('sync_items');
        $q = DB::table('supply_items as i')->leftJoin('supply_sales as ss', 'ss.code_key', '=', 'i.code_key')
            ->select('i.id', 'i.code', 'i.code_key', 'i.name', 'i.supplier_id', 'i.product_id', 'i.per_carton as x_pc',
                'p.id as pid', 'p.stock', 'p.in_stock', 'p.carton_enabled', 'p.per_carton', 'p.image', 'ss.qty');
        if ($hasSync) {
            // کالایی که بعد از ورود اکسل از JSON ساخته شده هم از طریق ردیف فید پیدا می‌شود
            $q->leftJoin('sync_items as s', 's.id', '=', 'i.sync_item_id')
                ->leftJoin('products as p', 'p.id', '=', DB::raw('COALESCE(i.product_id, s.product_id)'))
                ->addSelect('s.id as sid_feed', 's.stock_wholesale', 's.in_feed', DB::raw("CASE WHEN s.images IS NOT NULL AND s.images <> '[]' THEN 1 ELSE 0 END as s_img"));
            // پیوند ردیف فید فقط برای پیدا کردن کالای سایت است؛ موجودی و تصویر فید فقط وقتی «خواندن از JSON» روشن باشد
            $feed = static::useFeed();
        } else {
            $q->leftJoin('products as p', 'p.id', '=', 'i.product_id');
        }
        if ($hasPrice) {
            $q->addSelect('i.last_price');
        }

        $items = [];
        $sup = [];
        // ملاک اصلی: آخرین فایل‌های اسکنر انبار عمده (ورود از اکسل ← موجودی روزانه).
        // کد در فایل عمده = موجود (حتی اگر کالا در سایت ساخته یا عکاسی نشده)، نبود = ناموجود؛ موجودی سایت نقشی ندارد.
        $scan = StockScan::buyKeys();
        // بارهای خریداری‌شده‌ای که شب در «اطلاعات کالا» با «موجود شوند» وارد شده‌اند — تا اسکن عمده بعدی موجودند
        $arr = static::arrivals();
        foreach ($q->orderBy('i.id')->cursor() as $r) {
            $sitePc = max(1, (int) $r->per_carton);
            $a = $arr[(string) $r->code_key] ?? null;
            $wait = static::arrivalWaiting($a);
            if (! $wait && static::arrivalHolds($a)) {
                continue;
            }
            if ($wait) {
                // روی خود کالا: «خریده شد، در اسکن نیامد» — تا بررسی نشود سفارش داده نمی‌شود
                $items[] = [0, (string) $r->code, (string) $r->name, (int) $r->supplier_id, 'w',
                    (int) ($r->x_pc ?: ($r->pid ? $sitePc : 0)), 0, (int) $r->qty, $r->code_key === $r->code ? '' : (string) $r->code_key, (int) ($hasPrice ? $r->last_price : 0),
                    static::imageUrl($r->image ?? null, null, $r->pid ? (int) $r->pid : null),
                    [\App\Support\Jalali::format($a->arrived_at, false), \App\Support\Jalali::format($a->missed_since, false),
                        max(0, (int) ceil((strtotime((string) $a->missed_since) + static::ARRIVAL_GRACE_DAYS * 86400 - time()) / 86400))]];
                $sup[$r->supplier_id] = true;

                continue;
            }
            if ($scan) {
                if (isset($scan['keys'][(string) $r->code_key])) {
                    continue;
                }
                $units = 0;
                $st = 'o';
            } elseif ($r->pid) {
                // همان قاعده «خرید کارتنی» سایت: کارتنی فعال، موجود و موجودی عمده حداقل یک کارتن
                if (! $r->in_stock || ! $r->carton_enabled) {
                    $units = 0;
                } elseif ($r->stock === null) {
                    continue;
                } else {
                    $units = max(0, (int) $r->stock);
                    if ($units < $sitePc) {
                        $units = 0;
                    }
                }
                if ($units <= 0) {
                    $st = 'o';
                } elseif ($cfg['low'] > 0 && $units < $sitePc * $cfg['low']) {
                    $st = 'l';
                } else {
                    continue;
                }
            } else {
                // کالا در سایت ساخته نشده. سایت فقط کالاهای موجودِ JSON را می‌سازد، پس:
                //  - در JSON با موجودی عمده ولی بدون کالای سایت → «ناموجود - عکاسی نشده» (m)
                //  - در JSON بدون موجودی، یا اصلاً در JSON نیست → «ناموجود» (o)
                $units = 0;
                $st = (! empty($feed) && $r->sid_feed && $r->in_feed && (int) $r->stock_wholesale > 0) ? 'm' : 'o';
            }
            // شناسه (۰) و کلید برابر با کد ('') برای سبکی پاسخ خالی فرستاده می‌شوند
            $items[] = [0, (string) $r->code, (string) $r->name, (int) $r->supplier_id, $st,
                (int) ($r->x_pc ?: ($r->pid ? $sitePc : 0)), $units, (int) $r->qty, $r->code_key === $r->code ? '' : (string) $r->code_key, (int) ($hasPrice ? $r->last_price : 0),
                static::imageUrl($r->image ?? null, ! empty($feed) && ! empty($r->s_img) ? (int) $r->sid_feed : null, $r->pid ? (int) $r->pid : null)];
            $sup[$r->supplier_id] = true;
        }

        $suppliers = Supplier::query()->whereIn('id', array_keys($sup))->orderBy('name')->get(['id', 'name', 'phone', 'contact', 'items_count'])
            ->map(fn ($s) => [(int) $s->id, (string) $s->name, (string) $s->phone, (string) $s->contact, (int) $s->items_count])->values()->all();

        $data = [
            'v' => static::version(),
            'items' => $items,
            'suppliers' => $suppliers,
            'cfg' => $cfg,
            'import' => static::lastImport('supply'),
            'sales_import' => static::lastImport('sales'),
            'total' => (int) DB::table('supply_items')->count(),
            'alerts' => static::arrivalAlerts(),
            'scan' => $scan ? ['at' => \App\Support\Jalali::format($scan['at'], true), 'codes' => count($scan['keys']), 'ts' => strtotime((string) $scan['at'])] : null,
            // آخرین فایل «اطلاعات کالا» با «موجود شوند» (بار رسید) — برای نوار «آخرین به‌روزرسانی» بالای اپ
            'arrived' => ($la = static::arrivalsReady() ? DB::table('buy_arrivals')->max('arrived_at') : null) ? ['at' => \App\Support\Jalali::format($la, true), 'ts' => strtotime((string) $la)] : null,
        ];
        Cache::put($key, $data, 900);

        return $data;
    }

    /** تصویر کوچک کالا: تصویر کالای سایت، وگرنه اولین تصویر فید JSON (از طریق /buyer/img که روی سرور کش می‌شود) */
    public static function imageUrl(?string $image, ?int $syncId, ?int $productId = null): string
    {
        $key = $image && $productId ? 'p'.$productId : ($syncId ? 's'.$syncId : null);
        if (! $key) {
            return '';
        }

        // فایل آماده = آدرس ثابت (فوری، بدون PHP)؛ وگرنه یک بار از طریق سرور ساخته می‌شود
        return is_file(BuyerImages::path($key)) ? BuyerImages::url($key) : '/buyer/img/'.$key;
    }

    public static function lastImport(string $kind): ?array
    {
        $q = DB::table('supply_imports')->orderByDesc('id');
        if (\App\Support\DbSchema::hasColumn('supply_imports', 'kind')) {
            $q->where('kind', $kind);
        } elseif ($kind === 'sales') {
            return null;
        }
        $imp = $q->first();

        return $imp ? ['at' => \App\Support\Jalali::format($imp->created_at, true), 'ts' => strtotime((string) $imp->created_at), 'rows' => (int) $imp->rows, 'matched' => (int) $imp->matched, 'file' => (string) $imp->file_name, 'days' => (int) now()->diffInDays($imp->created_at, true)] : null;
    }

    /** علامت‌های مشترک مسئولان خرید (کارتن، حذف، یادداشت) و سفارش‌های باز */
    public static function state(): array
    {
        $marks = [];
        $hasPrice = \App\Support\DbSchema::hasColumn('supply_items', 'last_price');
        $rows = DB::table('purchase_marks as m')->leftJoin('supply_items as i', 'i.code_key', '=', 'm.code_key')->leftJoin('products as p', 'p.id', '=', 'i.product_id')
            ->where(fn ($q) => $q->where('m.cartons', '>', 0)->orWhere('m.excluded', true)->orWhereNotNull('m.note'))
            ->get(array_merge(['m.code_key', 'm.cartons', 'm.excluded', 'm.note', 'm.user_id', 'm.updated_at', 'i.supplier_id', 'i.per_carton as x_pc', 'p.per_carton'], $hasPrice ? ['i.last_price'] : []));
        $users = [];
        $editing = []; // چه کسی در سبد هر کارخانه کارتن زده (برای جلوگیری از تداخل چند مسئول خرید)
        foreach ($rows as $m) {
            // [کارتن، حذف‌شده، یادداشت، کارخانه، مبلغ هر کارتن، کاربر]
            $marks[$m->code_key] = [(int) $m->cartons, (bool) $m->excluded, (string) $m->note, (int) $m->supplier_id,
                max(1, (int) ($m->x_pc ?: $m->per_carton ?: 1)) * (int) ($m->last_price ?? 0), (int) $m->user_id];
            if ($m->user_id) {
                $users[$m->user_id] = true;
                if ($m->cartons > 0 && ! $m->excluded) {
                    $e = &$editing[(int) $m->supplier_id][(int) $m->user_id];
                    $e = max((int) $e, strtotime((string) $m->updated_at) ?: 0);
                    unset($e);
                }
            }
        }
        $open = [];
        $cfg = static::cfg();
        $supOpen = []; // آخرین سفارش باز هر کارخانه: [شماره، روز گذشته، ثبت‌کننده، قلم، کارتن]
        $orders = PurchaseOrder::query()->where('status', 'sent')->where('created_at', '>=', now()->subDays(120))->orderBy('id')->get(['id', 'number', 'lines', 'created_at', 'supplier_id', 'created_by', 'items_count', 'total_cartons']);
        foreach ($orders as $o) {
            $age = (int) $o->created_at->diffInDays(now(), true);
            foreach ((array) $o->lines as $l) {
                $open[$l['k']] = [$o->number, $age, (int) $l['q']];
            }
            if ($o->supplier_id) {
                $supOpen[$o->supplier_id] = [$o->number, $age, (int) $o->created_by, (int) $o->items_count, (int) $o->total_cartons, $o->created_at->diffForHumans()];
                $users[(int) $o->created_by] = true;
            }
        }
        $names = User::query()->whereIn('id', array_keys(array_filter($users)))->get()->mapWithKeys(fn ($u) => [$u->id => $u->displayName()])->all();
        $now = time();
        foreach ($editing as $sid => $list) {
            $editing[$sid] = collect($list)->map(fn ($ts, $uid) => [(int) $uid, max(0, (int) round(($now - $ts) / 60))])->values()->all();
        }

        $sids = array_values(array_unique(array_filter(array_column($marks, 3))));
        $sups = $sids ? Supplier::query()->whereIn('id', $sids)->get(['id', 'name', 'phone', 'contact', 'items_count'])
            ->map(fn ($s) => [(int) $s->id, (string) $s->name, (string) $s->phone, (string) $s->contact, (int) $s->items_count])->values()->all() : [];

        return ['marks' => (object) $marks, 'open' => (object) $open, 'sups' => $sups, 'names' => (object) $names, 'sup_open' => (object) $supOpen, 'editing' => (object) $editing, 'hide_days' => $cfg['hide_ordered_days'], 'sig' => static::stateSig()];
    }

    public static function stateSig(): string
    {
        return md5((string) DB::table('purchase_marks')->max('updated_at').'|'.DB::table('purchase_marks')->count().'|'.(string) DB::table('purchase_orders')->max('updated_at'));
    }

    public static function mark(string $key, array $data, ?User $by): array
    {
        $item = SupplyItem::query()->where('code_key', $key)->first();
        if (! $item) {
            throw new RuntimeException('این کالا در فهرست خرید نیست.');
        }
        $row = DB::table('purchase_marks')->where('code_key', $key)->first();
        if ((int) ($data['cartons'] ?? 0) > 0 && isset(static::waitingKeys()[$key])) {
            throw new RuntimeException('این کالا دیروز خریده شده و در اسکن انبار نیامده؛ اول بررسی کنید (در انبار هست / تمام شده).');
        }
        $vals = [
            'cartons' => array_key_exists('cartons', $data) ? max(0, min(9999, (int) $data['cartons'])) : (int) ($row->cartons ?? 0),
            'excluded' => array_key_exists('excluded', $data) ? (bool) $data['excluded'] : (bool) ($row->excluded ?? false),
            'note' => array_key_exists('note', $data) ? (mb_substr(trim((string) $data['note']), 0, 190) ?: null) : ($row->note ?? null),
            'user_id' => $by?->id, 'updated_at' => now(),
        ];
        if ($vals['excluded']) {
            $vals['cartons'] = 0;
        }
        if ($row) {
            DB::table('purchase_marks')->where('id', $row->id)->update($vals);
        } else {
            DB::table('purchase_marks')->insert($vals + ['code_key' => $key, 'created_at' => now()]);
        }

        return [$vals['cartons'], $vals['excluded'], (string) $vals['note']];
    }

    /** اقلام پیش‌نویس (کارتن‌دار) یک کارخانه به ترتیب پرفروش‌ترین */
    public static function draftLines(int $supplierId): array
    {
        $hasSync = \App\Support\DbSchema::hasTable('sync_items');
        $q = DB::table('supply_items as i')->join('purchase_marks as m', 'm.code_key', '=', 'i.code_key');
        if ($hasSync) {
            $q->leftJoin('sync_items as s', 's.id', '=', 'i.sync_item_id')->leftJoin('products as p', 'p.id', '=', DB::raw('COALESCE(i.product_id, s.product_id)'));
        } else {
            $q->leftJoin('products as p', 'p.id', '=', 'i.product_id');
        }

        return $q
            ->leftJoin('supply_sales as ss', 'ss.code_key', '=', 'i.code_key')
            ->where('i.supplier_id', $supplierId)->where('m.cartons', '>', 0)->where('m.excluded', false)
            ->when(static::waitingKeys(), fn ($q, $w) => $q->whereNotIn('i.code_key', array_keys($w)))
            ->orderByDesc('ss.qty')->orderBy('i.name')
            ->get(array_merge(['i.code', 'i.code_key', 'i.name', 'i.per_carton as x_pc', 'm.cartons', 'm.note', 'p.id as pid', 'p.per_carton', 'p.image', 'ss.qty'], \App\Support\DbSchema::hasColumn('supply_items', 'last_price') ? ['i.last_price'] : [],
                $hasSync ? ['s.id as sid_feed', DB::raw("CASE WHEN s.images IS NOT NULL AND s.images <> '[]' THEN 1 ELSE 0 END as s_img")] : []))
            ->map(fn ($r) => [
                'c' => (string) $r->code, 'k' => (string) $r->code_key, 'n' => (string) $r->name, 'q' => (int) $r->cartons,
                'pc' => max(1, (int) ($r->x_pc ?: $r->per_carton ?: 1)), 'note' => (string) $r->note,
                'p' => (int) ($r->last_price ?? 0), 's' => (int) $r->qty,
                'img' => static::imageUrl($r->image, static::useFeed() && ! empty($r->s_img) ? (int) $r->sid_feed : null, $r->pid ? (int) $r->pid : null),
            ])->values()->all();
    }

    /** ثبت سفارش خرید از پیش‌نویس یک کارخانه؛ کارتن‌های پیش‌نویس صفر می‌شوند */
    public static function placeOrder(int $supplierId, ?string $note, ?User $by): PurchaseOrder
    {
        return DB::transaction(function () use ($supplierId, $note, $by) {
            $s = Supplier::query()->lockForUpdate()->findOrFail($supplierId);
            $lines = static::draftLines($supplierId);
            if (! $lines) {
                throw new RuntimeException('برای این کارخانه هنوز تعداد کارتنی وارد نشده است.');
            }
            $po = PurchaseOrder::query()->create([
                'supplier_id' => $s->id, 'supplier_name' => $s->name, 'status' => 'sent',
                'lines' => $lines,
                'total_cartons' => array_sum(array_column($lines, 'q')), 'items_count' => count($lines),
                'total_amount' => static::amount($lines),
                'note' => $note ? mb_substr($note, 0, 500) : null, 'created_by' => $by?->id,
            ]);
            DB::table('purchase_marks')->whereIn('code_key', array_column($lines, 'k'))->update(['cartons' => 0, 'note' => null, 'updated_at' => now()]);
            \App\Services\Restock::sync(); // کالاهای ناموجود این سفارش در سایت: «سفارش دادیم از کارخانه»
            static::notifyBuyers('سفارش '.$po->number.' برای «'.$s->name.'» ثبت شد', ($by?->displayName() ?? 'یک مسئول خرید').' — '.count($lines).' قلم، '.$po->total_cartons.' کارتن', $by);

            return $po->refresh();
        });
    }

    /**
     * تغییر وضعیت سفارش خرید (بار رسید / لغو / برگشت به «در انتظار بار»).
     * فقط برچسب سفارش است: موجودی کالاهای سایت هیچ تغییری نمی‌کند (موجودی فقط از اکسل/JSON انبار می‌آید).
     */
    public static function setOrderStatus(PurchaseOrder $po, string $status): void
    {
        abort_unless(isset(PurchaseOrder::STATUSES[$status]), 422);
        $po->update(['status' => $status, 'closed_at' => $status === 'sent' ? null : now()]);
        \App\Services\Restock::sync();
    }

    /** اعلان به بقیه مسئولان خرید (تا دو نفر برای یک کارخانه سفارش تکراری ندهند) */
    public static function notifyBuyers(string $title, string $body, ?User $except = null): void
    {
        try {
            $ids = User::query()->where('is_active', true)->where(fn ($q) => $q->where('role', 'admin')->orWhere(fn ($w) => $w->where('role', 'staff')->where('permissions', 'like', '%purchasing%')))
                ->when($except, fn ($q) => $q->whereKeyNot($except->id))->pluck('id')->all();
            if ($ids) {
                app(WebPush::class)->toUsers($ids, ['title' => $title, 'body' => $body, 'url' => url('/buyer'), 'tag' => 'buyer-po']);
            }
        } catch (\Throwable $e) {
            report($e);
        }
    }

    /** کلید کالاهایی که هنوز ناموجودند (هر چه در این فهرست نیست = رسیده) */
    public static function outKeys(): array
    {
        $out = [];
        foreach (static::dataset()['items'] as $it) {
            if ($it[4] !== 'w') { // خریده‌شده و منتظر بررسی = رسیده
                $out[$it[8] ?: $it[1]] = true;
            }
        }

        return $out;
    }

    /** اقلام یک سفارش با وضعیت رسیدن: ok = رسیده (کالا در سایت موجود شد) */
    public static function arrival(PurchaseOrder $po): array
    {
        $out = static::outKeys();
        $arr = static::arrivals();
        $lines = array_values((array) $po->lines);
        $keys = array_column($lines, 'k');
        $prod = [];
        $codes = static::productCodeMap();
        foreach ($keys as $k) {
            if (isset($codes[$k])) {
                $prod[$k] = $codes[$k];
            }
        }
        $pm = $prod ? DB::table('products')->whereIn('id', array_values($prod))->get(['id', 'stock', 'per_carton', 'image', 'updated_at'])->keyBy('id') : collect();
        $rows = [];
        foreach ($lines as $l) {
            $p = isset($prod[$l['k']]) ? $pm->get($prod[$l['k']]) : null;
            $ok = ! isset($out[$l['k']]);
            $rows[] = $l + [
                'ok' => $ok,
                'stock' => $p && $p->stock !== null ? intdiv(max(0, (int) $p->stock), max(1, (int) $p->per_carton)) : null,
                'img' => $l['img'] ?? ($p && $p->image ? static::imageUrl($p->image, null, (int) $p->id) : ''),
                'at' => ! $ok ? null : (isset($arr[$l['k']]) && \Illuminate\Support\Carbon::parse($arr[$l['k']]->arrived_at)->gte($po->created_at) ? \App\Support\Jalali::format($arr[$l['k']]->arrived_at, false)
                    : ($p && $p->updated_at && \Illuminate\Support\Carbon::parse($p->updated_at)->gte($po->created_at) ? \App\Support\Jalali::format($p->updated_at, false) : null)),
            ];
        }
        // نرسیده‌ها اول
        usort($rows, fn ($a, $b) => [(int) $a['ok'], $b['q']] <=> [(int) $b['ok'], $a['q']]);

        return $rows;
    }

    /** خلاصه سفارش‌های خرید با میزان رسیدن بار (کالایی که دیگر ناموجود نیست = رسیده) */
    public static function orders(int $limit = 60, ?int $supplierId = null): array
    {
        $out = static::outKeys();
        $q = PurchaseOrder::query()->with('creator:id,name,mobile')->orderByDesc('id')->limit($limit);
        if ($supplierId) {
            $q->where('supplier_id', $supplierId);
        }

        return $q->get()->map(function (PurchaseOrder $o) use ($out) {
            $lines = (array) $o->lines;
            $arrived = count(array_filter($lines, fn ($l) => ! isset($out[$l['k']])));

            return [
                'id' => $o->id, 'number' => $o->number, 'sid' => $o->supplier_id, 'supplier' => $o->supplier_name, 'status' => $o->status,
                'status_label' => PurchaseOrder::STATUSES[$o->status] ?? $o->status, 'cartons' => $o->total_cartons, 'items' => $o->items_count, 'amount' => (int) ($o->total_amount ?? 0),
                'arrived' => $arrived, 'dots' => implode('', array_map(fn ($l) => isset($out[$l['k']]) ? '0' : '1', array_slice($lines, 0, 60))), 'date' => \App\Support\Jalali::format($o->created_at, true), 'age' => (int) $o->created_at->diffInDays(now(), true),
                'by' => $o->creator?->displayName(), 'note' => (string) $o->note,
            ];
        })->all();
    }

    /** مدل گزارش برای چاپ/تصویر/PDF: از سفارش ثبت‌شده یا پیش‌نویس جاری */
    public static function report(?PurchaseOrder $po = null, ?Supplier $s = null): array
    {
        $s ??= $po?->supplier;
        $lines = $po ? (array) $po->lines : static::draftLines((int) $s?->id);

        return [
            'number' => $po?->number, 'date' => \App\Support\Jalali::format($po?->created_at ?? now(), false, true),
            'supplier' => $po?->supplier_name ?? $s?->name, 'phone' => (string) $s?->phone, 'contact' => (string) $s?->contact,
            'note' => (string) ($po?->note ?? ''), 'lines' => array_values($lines),
            'total' => array_sum(array_map(fn ($l) => (int) $l['q'], $lines)),
            'amount' => static::amount($lines), // فقط برای اپراتور؛ در گزارش کارخانه چاپ نمی‌شود
        ];
    }

    /** جمع مبلغ تقریبی سفارش = تعداد کارتن × تعداد در کارتن × مبلغ آخرین خرید */
    public static function amount(array $lines): int
    {
        return (int) array_sum(array_map(fn ($l) => (int) $l['q'] * max(1, (int) ($l['pc'] ?? 1)) * (int) ($l['p'] ?? 0), $lines));
    }

    /** نام کالا برای گزارش کارخانه: بخش «//۱۲عددی» آخر نام حذف می‌شود (تعداد در کارتن ستون جدا دارد) */
    public static function cleanName(string $n): string
    {
        $c = trim(preg_replace('#\s*//.*$#u', '', $n));

        return $c !== '' ? $c : $n;
    }

    /** متن ساده سفارش برای پیام‌رسان‌ها (بدون بارکد و مبلغ) */
    public static function reportText(array $r): string
    {
        $name = static::cfg()['report_name'];
        $t = 'سفارش خرید'.($name !== '' ? ' '.$name : '').($r['number'] ? ' — شماره '.fa($r['number']) : '')."\n";
        $t .= 'تاریخ: '.$r['date']."\nطرف حساب: ".$r['supplier']."\n\n";
        foreach ($r['lines'] as $i => $l) {
            $t .= fa($i + 1).') '.static::cleanName($l['n']).' — '.fa($l['q']).' کارتن  '.fa(max(1, (int) ($l['pc'] ?? 1))).' عددی'.($l['note'] ? ' ('.$l['note'].')' : '')."\n";
        }
        if (static::cfg()['report_total']) {
            $t .= "\nجمع: ".fa(count($r['lines'])).' قلم، '.fa($r['total']).' کارتن';
        }
        $c = static::cfg();
        if ($c['report_note']) {
            $t .= "\n".$c['report_note'];
        }
        if (trim($c['unload_rules']) !== '') {
            $t .= "\n\nقوانین تخلیه بار:\n".trim($c['unload_rules']);
        }
        if (($cr = \App\Support\Credit::text()) !== '') {
            $t .= "\n\n".$cr;
        }

        return $t;
    }

    public static function draftAmount(): int
    {
        if (! \App\Support\DbSchema::hasColumn('supply_items', 'last_price')) {
            return 0;
        }
        $pc = 'COALESCE(NULLIF(i.per_carton, 0), p.per_carton, 1)';

        return (int) DB::table('purchase_marks as m')->join('supply_items as i', 'i.code_key', '=', 'm.code_key')->leftJoin('products as p', 'p.id', '=', 'i.product_id')
            ->where('m.cartons', '>', 0)->where('m.excluded', false)->sum(DB::raw("m.cartons * $pc * COALESCE(i.last_price, 0)"));
    }

    public static function stats(): array
    {
        if (! static::ready()) {
            return [];
        }
        $ds = static::dataset();
        $c = ['o' => 0, 'l' => 0, 'm' => 0];
        foreach ($ds['items'] as $it) {
            $c[$it[4]] = ($c[$it[4]] ?? 0) + 1;
        }

        return [
            'total' => $ds['total'], 'out' => $c['o'] + $c['m'], 'missing' => $c['m'], 'low' => $c['l'], 'suppliers' => count($ds['suppliers']), 'import' => $ds['import'], 'sales_import' => $ds['sales_import'], 'scan' => $ds['scan'] ?? null, 'alerts' => count($ds['alerts'] ?? []),
            'draft' => (int) DB::table('purchase_marks')->where('cartons', '>', 0)->where('excluded', false)->count(),
            'draft_amount' => static::draftAmount(),
            'open' => (int) PurchaseOrder::query()->where('status', 'sent')->count(),
        ];
    }
}
