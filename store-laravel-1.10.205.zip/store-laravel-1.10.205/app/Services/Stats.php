<?php

namespace App\Services;

use App\Models\Order;
use App\Support\Settings;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

/**
 * آمار بازدید پیشرفته.
 * جمع‌آوری: public/st.php (بدون لاراول) فقط یک خط به فایل روز اضافه می‌کند.
 * جمع‌بندی: ingest() هر چند دقیقه (Scheduler) خط‌های تازه را می‌خواند و در دو جدول کوچک می‌ریزد:
 *   stat_sessions (هر نشست یک ردیف) و stat_counts (شمارنده روزانه کالا/دسته/جستجو/نوع صفحه/ساعت).
 * صفحه پنل فقط همین جدول‌ها را می‌خواند (با کش ۲ دقیقه‌ای)؛ فشاری روی سایت نیست.
 */
class Stats
{
    public const CHANNELS = [
        'direct' => 'ورود مستقیم',
        'search' => 'موتور جستجو (گوگل و…)',
        'social' => 'شبکه‌های اجتماعی',
        'referral' => 'سایت‌های دیگر',
        'advisor' => 'لینک مشاوران',
        'sms' => 'پیامک',
        'ads' => 'تبلیغات',
        'campaign' => 'کمپین (لینک UTM)',
    ];

    public const DEVICES = ['m' => 'موبایل', 'd' => 'کامپیوتر', 't' => 'تبلت'];

    public const OS = ['android' => 'اندروید', 'ios' => 'آیفون (iOS)', 'windows' => 'ویندوز', 'mac' => 'مک', 'linux' => 'لینوکس', 'other' => 'سایر'];

    public const BROWSERS = ['chrome' => 'کروم', 'safari' => 'سافاری', 'samsung' => 'مرورگر سامسونگ', 'firefox' => 'فایرفاکس', 'edge' => 'اج', 'opera' => 'اپرا', 'instagram' => 'داخل اینستاگرام', 'webview' => 'داخل اپ', 'other' => 'سایر'];

    public const KINDS = ['home' => 'صفحه اصلی', 'product' => 'صفحه کالا', 'category' => 'دسته‌بندی', 'search' => 'نتیجه جستجو', 'shop' => 'همه محصولات', 'cart' => 'سبد خرید', 'checkout' => 'تکمیل خرید', 'login' => 'ورود / ثبت‌نام', 'account' => 'حساب کاربری', 'other' => 'سایر صفحات'];

    public const WEEKDAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

    public static function cfg(): array
    {
        return array_replace(['enabled' => true, 'keep' => 400], (array) setting('visit_stats', []));
    }

    public static function dir(): string
    {
        $d = storage_path('app/_stats');
        if (! is_dir($d)) {
            @mkdir($d, 0775, true);
        }

        return $d;
    }

    public static function setEnabled(bool $on): void
    {
        Settings::set(['visit_stats' => ['enabled' => $on] + static::cfg()]);
        $off = static::dir().'/off';
        $on ? @unlink($off) : @touch($off);
    }

    /** تنظیمات اسکریپت آمار برای صفحه فروشگاه (یا null یعنی ثبت نشود) */
    public static function front(array $page): ?array
    {
        try {
            if (empty(static::cfg()['enabled'])) {
                return null;
            }
            $u = auth()->user();
            if ($u && $u->isStaffLike()) {
                return null; // همکاران فروشگاه در آمار شمرده نمی‌شوند
            }
            $p = array_intersect_key($page, array_flip(['k', 'i', 'ci', 't', 'q', 'n']));

            return ['url' => url('st.php'), 'p' => $p, 'u' => $u ? ['i' => $u->id, 's' => Live::sign($u->id)] : null];
        } catch (Throwable) {
            return null;
        }
    }

    /** سفارش ثبت‌شده از سایت ← به نشست همان بازدیدکننده نسبت داده می‌شود */
    public static function order(Order $o): void
    {
        try {
            if (app()->runningInConsole() || empty(static::cfg()['enabled']) || ! (request()->routeIs('checkout.place') || str_ends_with(request()->path(), 'checkout/place'))) {
                return;
            }
            $v = (string) ($_COOKIE['_stv'] ?? '');
            $s = (string) ($_COOKIE['_sts'] ?? '');
            if (! preg_match('/^[a-z0-9]{12,32}$/', $v)) {
                return;
            }
            $line = ['t' => time(), 'e' => 'o', 'v' => $v, 's' => preg_match('/^[a-z0-9]{12,32}$/', $s) ? $s : '', 'amt' => (int) $o->total, 'oid' => $o->id];
            @file_put_contents(static::dir().'/q-'.date('Ymd').'.log', json_encode($line)."\n", FILE_APPEND | LOCK_EX);
        } catch (Throwable) {
        }
    }

    /** کار دوره‌ای: جمع‌بندی خط‌های تازه + پاک‌سازی روزانه */
    public static function tick(): array
    {
        $done = [];
        $n = static::ingest();
        if ($n) {
            $done[] = 'stats:'.$n;
        }
        if (Cache::add('stats.prune', 1, 86400)) {
            $keep = max(30, (int) static::cfg()['keep']);
            DB::table('stat_sessions')->where('day', '<', now()->subDays($keep)->toDateString())->delete();
        }

        return $done;
    }

    /* ------------------------------------------------------------------ جمع‌بندی */

    public static function ingest(int $max = 30000): int
    {
        $dir = static::dir();
        $lk = @fopen($dir.'/ingest.lock', 'c');
        if (! $lk || ! flock($lk, LOCK_EX | LOCK_NB)) {
            return 0;
        }
        try {
            $stateF = $dir.'/state.json';
            $state = is_file($stateF) ? (array) json_decode((string) file_get_contents($stateF), true) : [];
            $events = [];
            $files = glob($dir.'/q-*.log') ?: [];
            sort($files);
            foreach ($files as $f) {
                $name = basename($f);
                $off = (int) ($state[$name] ?? 0);
                $size = (int) @filesize($f);
                if ($size > $off && count($events) < $max) {
                    $fh = fopen($f, 'rb');
                    fseek($fh, $off);
                    while (count($events) < $max && ($line = fgets($fh)) !== false) {
                        if (! str_ends_with($line, "\n")) {
                            break; // خط ناقص (در حال نوشتن)؛ دفعه بعد
                        }
                        $off += strlen($line);
                        $e = json_decode($line, true);
                        if (is_array($e) && isset($e['t'], $e['e'], $e['v'])) {
                            $events[] = $e;
                        }
                    }
                    fclose($fh);
                    $state[$name] = $off;
                }
                // فایل‌های تمام‌شده بیش از ۲ روز پیش پاک می‌شوند
                if (($state[$name] ?? 0) >= $size && filemtime($f) < time() - 2 * 86400) {
                    @unlink($f);
                    unset($state[$name]);
                }
            }
            if ($events) {
                static::apply($events);
            }
            file_put_contents($stateF, json_encode($state), LOCK_EX);
            if ($events) {
                Cache::forget('stats.ver');
                Cache::forever('stats.ver', time());
            }

            return count($events);
        } catch (Throwable $e) {
            report($e);

            return 0;
        } finally {
            flock($lk, LOCK_UN);
            fclose($lk);
        }
    }

    protected static function apply(array $events): void
    {
        usort($events, fn ($a, $b) => $a['t'] <=> $b['t']);
        $sids = array_values(array_unique(array_filter(array_map(fn ($e) => (string) ($e['s'] ?? ''), $events))));
        $S = [];
        foreach (array_chunk($sids, 500) as $ch) {
            foreach (DB::table('stat_sessions')->whereIn('sid', $ch)->get() as $r) {
                $row = (array) $r;
                $row['seen'] = (array) json_decode((string) $row['seen'], true);
                $S[$row['sid']] = $row;
            }
        }
        $dirty = [];
        $C = [];
        $cnt = function (string $day, string $kind, string $key, int $n = 0, int $u = 0, int $a = 0) use (&$C) {
            $k = $day."\x1F".$kind."\x1F".$key;
            $C[$k] ??= [0, 0, 0];
            $C[$k][0] += $n;
            $C[$k][1] += $u;
            $C[$k][2] += $a;
        };

        foreach ($events as $e) {
            $t = (int) $e['t'];
            $day = date('Y-m-d', $t);
            $sid = (string) ($e['s'] ?? '');
            $type = $e['e'];

            if ($type === 'o') {
                // سفارش: نشست همان کوکی، وگرنه آخرین نشست همان بازدیدکننده
                if ($sid === '' || ! isset($S[$sid])) {
                    $r = DB::table('stat_sessions')->where('vid', $e['v'])->orderByDesc('last_at')->first();
                    if (! $r || $r->last_at < $t - 3 * 86400) {
                        continue;
                    }
                    $row = (array) $r;
                    $row['seen'] = (array) json_decode((string) $row['seen'], true);
                    $S[$row['sid']] = $row;
                    $sid = $row['sid'];
                }
                $S[$sid]['orders']++;
                $S[$sid]['revenue'] += max(0, (int) ($e['amt'] ?? 0));
                $dirty[$sid] = 1;

                continue;
            }
            if ($sid === '') {
                continue;
            }
            if (! isset($S[$sid])) {
                if ($type !== 'p') {
                    continue; // خروج/افزودن بدون بازدید ثبت‌شده
                }
                [$ch, $src, $med, $camp] = static::channel($e);
                $dt = Carbon::createFromTimestamp($t, config('app.timezone'));
                $S[$sid] = [
                    'sid' => $sid, 'vid' => (string) $e['v'], 'day' => $day, 'user_id' => null, 'started_at' => $t, 'last_at' => $t,
                    'hour' => (int) $dt->format('G'), 'wd' => ((int) $dt->dayOfWeek + 1) % 7, 'pv' => 0, 'dur' => 0,
                    'channel' => $ch, 'source' => $src, 'medium' => $med, 'campaign' => $camp,
                    'landing' => (string) ($e['k'] ?? 'other'), 'landing_t' => Str::limit((string) ($e['tt'] ?? ''), 115, ''), 'exit_t' => null,
                    'device' => $e['d'] ?? null, 'os' => $e['os'] ?? null, 'browser' => $e['br'] ?? null, 'app' => min(2, max(0, (int) ($e['app'] ?? 0))),
                    'is_new' => ! empty($e['nv']) ? 1 : 0, 'products' => 0, 'searches' => 0, 'adds' => 0, 'cart' => 0, 'checkout' => 0, 'orders' => 0, 'revenue' => 0,
                    'seen' => [], '_new' => 1,
                ];
            }
            $s = &$S[$sid];
            $dirty[$sid] = 1;
            if ($type === 'p') {
                $k = (string) ($e['k'] ?? 'other');
                $s['pv']++;
                $s['last_at'] = max($s['last_at'], $t);
                $s['exit_t'] = Str::limit((string) ($e['tt'] ?? ''), 115, '');
                if (! empty($e['u'])) {
                    $s['user_id'] = (int) $e['u'];
                }
                if (! $s['device'] && ! empty($e['d'])) {
                    $s['device'] = $e['d'];
                    $s['os'] = $e['os'] ?? null;
                    $s['browser'] = $e['br'] ?? null;
                }
                $cnt($day, 'kind', $k, 1);
                $cnt($day, 'hour', (string) (int) date('G', $t), 1);
                if ($k === 'product' && ($pid = (int) ($e['i'] ?? 0)) > 0) {
                    $s['products']++;
                    $first = ! in_array($pid, $s['seen']['p'] ?? [], true);
                    if ($first && count($s['seen']['p'] ?? []) < 300) {
                        $s['seen']['p'][] = $pid;
                    }
                    $cnt($day, 'product', (string) $pid, 1, $first ? 1 : 0);
                    if (($ci = (int) ($e['ci'] ?? 0)) > 0) {
                        $cnt($day, 'pcat', (string) $ci, 1); // بازدید کالاهای هر دسته
                    }
                } elseif ($k === 'category' && ($cid = (int) ($e['i'] ?? 0)) > 0) {
                    $first = ! in_array($cid, $s['seen']['c'] ?? [], true);
                    if ($first && count($s['seen']['c'] ?? []) < 100) {
                        $s['seen']['c'][] = $cid;
                    }
                    $cnt($day, 'cat', (string) $cid, 1, $first ? 1 : 0);
                } elseif ($k === 'search') {
                    $q = static::normQ((string) ($e['q'] ?? $e['tt'] ?? ''));
                    if ($q !== '') {
                        $s['searches']++;
                        $first = ! in_array($q, $s['seen']['q'] ?? [], true);
                        if ($first && count($s['seen']['q'] ?? []) < 50) {
                            $s['seen']['q'][] = $q;
                        }
                        if ($first) {
                            $cnt($day, 'search', $q, 1, 1, isset($e['n']) && (int) $e['n'] === 0 ? 1 : 0);
                        }
                    }
                } elseif ($k === 'cart') {
                    $s['cart'] = 1;
                } elseif ($k === 'checkout') {
                    $s['checkout'] = 1;
                    $s['cart'] = 1;
                }
            } elseif ($type === 'x') {
                $s['dur'] = min(6 * 3600, $s['dur'] + max(0, min(1800, (int) ($e['dur'] ?? 0))));
                $s['last_at'] = max($s['last_at'], $t);
            } elseif ($type === 'a') {
                $s['adds']++;
                $s['cart'] = 1;
                if (($pid = (int) ($e['i'] ?? 0)) > 0) {
                    $cnt($day, 'product', (string) $pid, 0, 0, 1);
                }
            }
            unset($s);
        }

        DB::transaction(function () use ($S, $dirty, $C) {
            $ins = [];
            foreach (array_keys($dirty) as $sid) {
                $row = $S[$sid];
                $isNew = ! empty($row['_new']);
                unset($row['_new'], $row['id']);
                $row['seen'] = $row['seen'] ? json_encode($row['seen'], JSON_UNESCAPED_UNICODE) : null;
                if ($isNew) {
                    $ins[] = $row;
                } else {
                    DB::table('stat_sessions')->where('sid', $sid)->update($row);
                }
            }
            foreach (array_chunk($ins, 200) as $ch) {
                DB::table('stat_sessions')->insertOrIgnore($ch);
            }
            foreach ($C as $k => [$n, $u, $a]) {
                [$day, $kind, $key] = explode("\x1F", $k, 3);
                $w = ['day' => $day, 'kind' => $kind, 'key' => Str::limit($key, 118, '')];
                $q = DB::table('stat_counts')->where($w);
                $upd = $q->update(['n' => DB::raw('n + '.(int) $n), 'u' => DB::raw('u + '.(int) $u), 'a' => DB::raw('a + '.(int) $a)]);
                if (! $upd && ! DB::table('stat_counts')->where($w)->exists()) {
                    DB::table('stat_counts')->insert($w + ['n' => $n, 'u' => $u, 'a' => $a]);
                }
            }
        });
    }

    /** منبع ورود: کانال، منبع، رسانه، کمپین */
    public static function channel(array $e): array
    {
        $us = Str::lower(trim((string) ($e['us'] ?? '')));
        $um = Str::lower(trim((string) ($e['um'] ?? '')));
        $uc = trim((string) ($e['uc'] ?? ''));
        $r = preg_replace('/^(www|m|l|lm)\./', '', Str::lower((string) ($e['r'] ?? '')));
        $social = '/(^|\.)(instagram\.com|t\.me|telegram\.(org|me)|web\.telegram|whatsapp\.com|wa\.me|eitaa\.com|rubika\.ir|ble\.ir|bale\.ai|web\.bale|aparat\.com|facebook\.com|fb\.com|twitter\.com|x\.com|t\.co|linkedin\.com|youtube\.com|youtu\.be|splus\.ir|igap\.net|soroush|pinterest\.|tiktok\.com|threads\.net)$/';
        $search = '/(^|\.)(google\.[a-z.]+|bing\.com|yandex\.[a-z.]+|duckduckgo\.com|yahoo\.com|ecosia\.org|zarebin\.ir|parsijoo\.ir|yaani\.ir|search\.brave\.com|baidu\.com)$/';
        if ($us === 'advisor' || $um === 'advisor') {
            $ch = 'advisor';
        } elseif (preg_match('/sms|پیامک/u', $um.' '.$us)) {
            $ch = 'sms';
        } elseif ($us !== '' && preg_match('/cpc|ppc|paid|ads|banner|display|yektanet|tapsell|mediaad/', $um.' '.$us)) {
            $ch = 'ads';
        } elseif ($us !== '' && preg_match($social, $us.'.com')) {
            $ch = 'social';
        } elseif ($us !== '') {
            $ch = preg_match('/insta|telegram|whatsapp|eitaa|rubika|bale|aparat|social/', $us.' '.$um) ? 'social' : 'campaign';
        } elseif ($r === '' && ($e['br'] ?? '') === 'instagram') {
            $ch = 'social'; // مرورگر داخل اینستاگرام (بدون ارجاع)
            $r = 'instagram.com';
        } elseif ($r !== '' && preg_match($search, $r)) {
            $ch = 'search';
        } elseif ($r !== '' && preg_match($social, $r)) {
            $ch = 'social';
        } elseif ($r !== '') {
            $ch = preg_match('/^(android-app|ios-app)/', (string) ($e['r'] ?? '')) ? 'social' : 'referral';
        } else {
            $ch = 'direct';
        }
        $src = $us !== '' ? $us : ($r !== '' ? $r : null);

        return [$ch, $src ? Str::limit($src, 78, '') : null, $um !== '' ? Str::limit($um, 38, '') : null, $uc !== '' ? Str::limit($uc, 78, '') : null];
    }

    public static function normQ(string $q): string
    {
        $q = str_replace(['ي', 'ك', 'ة', '‌'], ['ی', 'ک', 'ه', ' '], $q);
        $q = preg_replace('/\s+/u', ' ', trim(Str::lower(en_digits($q))));

        return Str::limit($q, 80, '');
    }

    /* ------------------------------------------------------------------ گزارش‌ها */

    protected static function cached(string $k, \Closure $fn, int $ttl = 120)
    {
        return Cache::remember('stats.'.md5($k.'|'.Cache::get('stats.ver', 0)), $ttl, $fn);
    }

    protected static function sess(string $from, string $to)
    {
        return DB::table('stat_sessions')->whereBetween('day', [$from, $to]);
    }

    /** خلاصه بازه */
    public static function summary(string $from, string $to): array
    {
        return static::cached("sum|$from|$to", function () use ($from, $to) {
            $r = static::sess($from, $to)->selectRaw('COUNT(*) s, COUNT(DISTINCT vid) v, SUM(pv) pv, SUM(dur) dur, SUM(CASE WHEN pv = 1 THEN 1 ELSE 0 END) b,
                SUM(is_new) nw, SUM(CASE WHEN products > 0 THEN 1 ELSE 0 END) pr, SUM(cart) ct, SUM(checkout) ck, SUM(CASE WHEN orders > 0 THEN 1 ELSE 0 END) os,
                SUM(orders) o, SUM(revenue) rev, SUM(adds) ad, COUNT(DISTINCT user_id) us, SUM(searches) sr, SUM(CASE WHEN app > 0 THEN 1 ELSE 0 END) ap')->first();
            $s = (int) $r->s;

            return [
                'sessions' => $s, 'visitors' => (int) $r->v, 'pageviews' => (int) $r->pv, 'new' => (int) $r->nw,
                'pps' => $s ? round($r->pv / $s, 1) : 0, 'dur' => $s ? (int) round($r->dur / $s) : 0,
                'bounce' => $s ? round($r->b * 100 / $s, 1) : 0,
                'product_s' => (int) $r->pr, 'cart_s' => (int) $r->ct, 'checkout_s' => (int) $r->ck, 'order_s' => (int) $r->os,
                'orders' => (int) $r->o, 'revenue' => (int) $r->rev, 'adds' => (int) $r->ad, 'users' => (int) $r->us, 'searches' => (int) $r->sr, 'app' => (int) $r->ap,
                'conv' => $s ? round($r->os * 100 / $s, 2) : 0,
            ];
        });
    }

    /** روند روزانه (یا ماهانه برای بازه‌های بلند) */
    public static function series(string $from, string $to): array
    {
        return static::cached("ser|$from|$to", function () use ($from, $to) {
            $rows = static::sess($from, $to)->selectRaw('day, COUNT(*) s, COUNT(DISTINCT vid) v, SUM(pv) pv, SUM(CASE WHEN orders > 0 THEN 1 ELSE 0 END) o')
                ->groupBy('day')->get()->keyBy(fn ($r) => (string) substr((string) $r->day, 0, 10));
            $out = [];
            for ($d = Carbon::parse($from); $d->toDateString() <= $to; $d->addDay()) {
                $k = $d->toDateString();
                $r = $rows[$k] ?? null;
                $out[] = ['day' => $k, 'label' => \App\Support\Jalali::format($d), 'v' => (int) ($r->v ?? 0), 's' => (int) ($r->s ?? 0), 'pv' => (int) ($r->pv ?? 0), 'o' => (int) ($r->o ?? 0)];
                if (count($out) > 800) {
                    break;
                }
            }

            return $out;
        });
    }

    /** ورود بر اساس ساعت و روز هفته (نقشه حرارتی) */
    public static function heat(string $from, string $to): array
    {
        return static::cached("heat|$from|$to", function () use ($from, $to) {
            $m = array_fill(0, 7, array_fill(0, 24, 0));
            foreach (static::sess($from, $to)->selectRaw('wd, hour, COUNT(*) n')->groupBy('wd', 'hour')->get() as $r) {
                $m[(int) $r->wd][(int) $r->hour] = (int) $r->n;
            }

            return $m;
        });
    }

    /** گروه‌بندی نشست‌ها بر اساس یک ستون (کانال، دستگاه، …) با سفارش و درآمد */
    public static function by(string $col, string $from, string $to, int $limit = 12, ?string $where = null, ?string $whereVal = null): array
    {
        abort_unless(in_array($col, ['channel', 'device', 'os', 'browser', 'source', 'campaign', 'landing', 'landing_t', 'exit_t', 'app', 'is_new', 'medium'], true), 400);

        return static::cached("by|$col|$from|$to|$limit|$where|$whereVal", function () use ($col, $from, $to, $limit, $where, $whereVal) {
            $q = static::sess($from, $to)->selectRaw("$col k, COUNT(*) s, COUNT(DISTINCT vid) v, SUM(pv) pv, SUM(dur) dur, SUM(CASE WHEN pv = 1 THEN 1 ELSE 0 END) b, SUM(CASE WHEN orders > 0 THEN 1 ELSE 0 END) os, SUM(orders) o, SUM(revenue) rev, SUM(adds) ad")
                ->groupBy($col)->orderByDesc('s')->limit($limit);
            if ($where) {
                $q->where($where, $whereVal);
            }
            if (in_array($col, ['source', 'campaign', 'landing_t', 'exit_t', 'medium'], true)) {
                $q->whereNotNull($col)->where($col, '!=', '');
            }

            return $q->get()->map(fn ($r) => [
                'k' => (string) $r->k, 's' => (int) $r->s, 'v' => (int) $r->v, 'pv' => (int) $r->pv, 'dur' => $r->s ? (int) round($r->dur / $r->s) : 0,
                'bounce' => $r->s ? round($r->b * 100 / $r->s) : 0, 'os' => (int) $r->os, 'o' => (int) $r->o, 'rev' => (int) $r->rev, 'ad' => (int) $r->ad,
                'conv' => $r->s ? round($r->os * 100 / $r->s, 1) : 0,
            ])->all();
        });
    }

    /** شمارنده‌ها (کالا، دسته، جستجو، نوع صفحه، ساعت) */
    public static function counts(string $kind, string $from, string $to, int $limit = 20, string $order = 'n', bool $zeroOnly = false): array
    {
        return static::cached("cnt|$kind|$from|$to|$limit|$order|$zeroOnly", function () use ($kind, $from, $to, $limit, $order, $zeroOnly) {
            $q = DB::table('stat_counts')->where('kind', $kind)->whereBetween('day', [$from, $to])
                ->selectRaw('`key` k, SUM(n) n, SUM(u) u, SUM(a) a')->groupBy('key')->orderByDesc($order)->limit($limit);
            if ($zeroOnly) {
                $q->having(DB::raw('SUM(a)'), '>', 0);
            }

            return $q->get()->map(fn ($r) => ['k' => (string) $r->k, 'n' => (int) $r->n, 'u' => (int) $r->u, 'a' => (int) $r->a])->all();
        });
    }

    /** مشتریان واردشده‌ای که بیشترین بازدید را داشته‌اند */
    public static function customers(string $from, string $to, int $limit = 15): array
    {
        return static::cached("cus|$from|$to|$limit", function () use ($from, $to, $limit) {
            $rows = static::sess($from, $to)->whereNotNull('user_id')
                ->selectRaw('user_id, COUNT(*) s, SUM(pv) pv, SUM(products) pr, SUM(adds) ad, SUM(orders) o, MAX(last_at) la')
                ->groupBy('user_id')->orderByDesc('s')->limit($limit)->get();
            $users = DB::table('users')->whereIn('id', $rows->pluck('user_id'))->get(['id', 'name', 'mobile', 'city'])->keyBy('id');

            return $rows->map(fn ($r) => ['id' => (int) $r->user_id, 'name' => $users[$r->user_id]->name ?? ('#'.$r->user_id), 'mobile' => $users[$r->user_id]->mobile ?? '',
                'city' => $users[$r->user_id]->city ?? '', 's' => (int) $r->s, 'pv' => (int) $r->pv, 'pr' => (int) $r->pr, 'ad' => (int) $r->ad, 'o' => (int) $r->o, 'la' => (int) $r->la])->all();
        });
    }

    /** الان در سایت: از ۵ دقیقه آخر فایل امروز (بدون دیتابیس) */
    public static function online(): array
    {
        return Cache::remember('stats.online', 20, function () {
            $f = static::dir().'/q-'.date('Ymd').'.log';
            $since = time() - 300;
            $v = [];
            $kinds = [];
            $pages = [];
            if (is_file($f)) {
                $fh = fopen($f, 'rb');
                $size = filesize($f);
                fseek($fh, max(0, $size - 1_500_000));
                if ($size > 1_500_000) {
                    fgets($fh);
                }
                while (($line = fgets($fh)) !== false) {
                    $e = json_decode($line, true);
                    if (! is_array($e) || (int) ($e['t'] ?? 0) < $since || ($e['e'] ?? '') === 'o') {
                        continue;
                    }
                    if (($e['e'] ?? '') === 'p') {
                        $v[$e['v']] = ['k' => $e['k'] ?? 'other', 't' => $e['tt'] ?? '', 'at' => (int) $e['t']];
                    } else {
                        $v[$e['v']] ??= ['k' => 'other', 't' => '', 'at' => (int) $e['t']];
                    }
                }
                fclose($fh);
            }
            foreach ($v as $x) {
                $kinds[$x['k']] = ($kinds[$x['k']] ?? 0) + 1;
                if ($x['t'] !== '') {
                    $pages[$x['t']] = ($pages[$x['t']] ?? 0) + 1;
                }
            }
            arsort($kinds);
            arsort($pages);

            return ['n' => count($v), 'kinds' => $kinds, 'pages' => array_slice($pages, 0, 8, true)];
        });
    }

    /** نام کالا/دسته برای شناسه‌ها */
    public static function names(string $table, array $ids): array
    {
        $ids = array_values(array_filter(array_map('intval', $ids)));
        if (! $ids) {
            return [];
        }

        return DB::table($table)->whereIn('id', $ids)->pluck('name', 'id')->all();
    }

    public static function dur(int $sec): string
    {
        if ($sec < 60) {
            return fa($sec).' ثانیه';
        }
        $m = intdiv($sec, 60);
        $s = $sec % 60;

        return fa($m).':'.fa(str_pad((string) $s, 2, '0', STR_PAD_LEFT)).' دقیقه';
    }
}
