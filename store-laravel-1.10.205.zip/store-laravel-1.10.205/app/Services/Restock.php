<?php

namespace App\Services;

use App\Models\Product;
use App\Models\PurchaseOrder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * کالای ناموجودی که مسئولان خرید در اپ خرید برایش سفارش به کارخانه ثبت کرده‌اند (سفارش «در انتظار بار»):
 * در سایت «سفارش دادیم از کارخانه؛ به‌زودی شارژ می‌شود» + «خبرم کن» نمایش داده می‌شود.
 * با لغو سفارش برداشته می‌شود؛ وقتی کالا موجود شد خودکار برداشته می‌شود و برای «خبرم کن»‌ها پیامک می‌رود.
 */
class Restock
{
    /** شناسه کالاهای سایت برای کدهای اقلام سفارش خرید */
    protected static function productIds(array $keys): array
    {
        if (! $keys || ! \App\Support\DbSchema::hasTable('supply_items')) {
            return [];
        }
        $q = DB::table('supply_items as i')->whereIn('i.code_key', $keys);
        if (\App\Support\DbSchema::hasTable('sync_items')) {
            $q->leftJoin('sync_items as s', 's.id', '=', 'i.sync_item_id')->select(DB::raw('COALESCE(i.product_id, s.product_id) as pid'));
        } else {
            $q->select('i.product_id as pid');
        }

        return array_values(array_unique(array_filter(array_map('intval', $q->pluck('pid')->all()))));
    }

    /** وضعیت «سفارش داده شده» همه کالاها از روی سفارش‌های خرید «در انتظار بار» */
    public static function sync(): void
    {
        try {
            $keys = PurchaseOrder::query()->where('status', 'sent')->get(['lines'])
                ->flatMap(fn ($po) => collect((array) $po->lines)->pluck('k'))->filter()->unique()->values()->all();
            $ids = static::productIds($keys);
            if ($ids) {
                Product::query()->whereIn('id', $ids)->whereNull('restock_at')->update(['restock_at' => now()]);
            }
            Product::query()->whereNotNull('restock_at')->when($ids, fn ($q) => $q->whereNotIn('id', $ids))->update(['restock_at' => null, 'restock_by' => null, 'restock_note' => null]);
        } catch (Throwable $e) {
            report($e);
        }
    }
}
