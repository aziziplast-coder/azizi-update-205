<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * تغییر کد کالا در هلو.
 * وقتی مسئول خرید کد کالایی را در هلو عوض می‌کند، در فایل شبانه «اطلاعات کالا» آن کالا با کد تازه می‌آید
 * و کد قدیمی دیگر نمی‌آید. این سرویس همان‌جا کالای سایت را از روی «نام یکسان» پیدا می‌کند و کدش را عوض می‌کند
 * (هر کالا فقط یک کد دارد: کد فعلی هلو؛ تغییرها فقط در تاریخچه ثبت می‌شوند). مواردی که مطمئن نیست «در انتظار تأیید» می‌مانند.
 */
class CodeChanges
{
    /** وقتی خود این سرویس کد را عوض می‌کند، رویداد ذخیره کالا دوباره ثبت نکند */
    public static bool $silent = false;

    public static function ready(): bool
    {
        static $ok = null;

        return $ok ??= Schema::hasTable('product_code_changes');
    }

    public static function cfg(): array
    {
        return array_replace(['auto' => true, 'suggest' => true], (array) setting('code_changes', []));
    }

    /** نام برای مقایسه (فاصله، ی/ک، رقم فارسی، «// ۴ عددی») */
    public static function nameKey(string $n): string
    {
        return mb_strtolower(preg_replace('/[\s\-_.،,()\/]+/u', '', en_digits(Excel::productName($n))));
    }

    /** واژه‌های نام (برای شباهت) */
    public static function words(string $n): array
    {
        $t = mb_strtolower(en_digits(Excel::productName($n)));
        $t = preg_replace('/(\d)(\p{L})/u', '$1 $2', preg_replace('/(\p{L})(\d)/u', '$1 $2', $t));

        return array_values(array_unique(array_filter(preg_split('/[\s\-_.،,()\/]+/u', $t), fn ($w) => $w !== '')));
    }

    public static function similarity(string $a, string $b): int
    {
        $wa = static::words($a);
        $wb = static::words($b);
        if (! $wa || ! $wb) {
            return 0;
        }
        $common = count(array_intersect($wa, $wb));
        $jac = $common / count(array_unique(array_merge($wa, $wb)));
        similar_text(static::nameKey($a), static::nameKey($b), $pct);

        return (int) round(max($jac * 100, $pct * 0.9));
    }

    /**
     * پیش از ورود فایل: کدهای ناشناخته فایل را به کالای سایت با کد قدیمی وصل می‌کند.
     *
     * @param  array<string, array{barcode:string,name:string,price:mixed}>  $data  ردیف‌های فایل (کلید = کد)
     * @param  array<string, object>  $site  نمایه کد ← کالا (به‌روز می‌شود)
     * @return array{applied: array, pending: array}
     */
    public static function detect(array $data, array &$site, bool $rial, string $fileLabel = ''): array
    {
        $out = ['applied' => [], 'pending' => []];
        if (! static::ready()) {
            return $out;
        }
        $cfg = static::cfg();
        $unknown = array_filter($data, fn ($d, $k) => ! isset($site[$k]) && $d['name'] !== '', ARRAY_FILTER_USE_BOTH);
        if (! $unknown) {
            return $out;
        }
        // کالاهایی که کد اصلی‌شان (کد هلو) در این فایل نیامده ← نامزد «کد عوض شده»
        $byName = [];
        $byWord = [];
        $all = [];
        $covered = 0;
        foreach (Product::query()->whereNotNull('sku')->toBase()->get(['id', 'name', 'sku', 'price', 'per_carton']) as $p) {
            $all[$p->id] = $p;
            $byName[static::nameKey((string) $p->name)][] = $p->id;
            $byWord[static::words((string) $p->name)[0] ?? ''][] = $p->id;
            if (isset($data[Excel::key(Excel::barcode((string) $p->sku))])) {
                $covered++;
            }
        }
        $inFile = fn ($p) => isset($data[Excel::key(Excel::barcode((string) $p->sku))]);
        // پیشنهاد «نام شبیه» فقط وقتی فایل کامل است (بیشتر کالاهای سایت در آن هست)؛ در فایل‌های کوچک، نبودن کد معنایی ندارد
        $fullFile = $all && $covered / count($all) >= 0.5;
        $nameCountFile = [];
        foreach ($data as $d) {
            if ($d['name'] !== '') {
                $nameCountFile[static::nameKey($d['name'])] = ($nameCountFile[static::nameKey($d['name'])] ?? 0) + 1;
            }
        }
        $taken = [];
        $pendingOpen = DB::table('product_code_changes')->where('status', 'pending')->pluck('new_code')->flip()->all();
        $rejected = DB::table('product_code_changes')->where('status', 'rejected')->get(['product_id', 'new_code'])
            ->map(fn ($r) => $r->product_id.'|'.$r->new_code)->flip()->all();

        foreach ($unknown as $k => $d) {
            $nk = static::nameKey($d['name']);
            $price = $d['price'] !== '' ? Excel::number($d['price'], $rial) : null;
            $cands = array_values(array_filter($byName[$nk] ?? [], fn ($id) => ! $inFile($all[$id]) && ! isset($taken[$id])));
            if (count($byName[$nk] ?? []) === 1 && count($cands) === 1 && ($nameCountFile[$nk] ?? 0) === 1) {
                $p = $all[$cands[0]];
                if (isset($rejected[$p->id.'|'.$d['barcode']])) {
                    continue;
                }
                // قیمت خیلی متفاوت (بیش از ۳ برابر) ← مطمئن نیستیم
                $priceOk = ! $price || ! $p->price || ($price / max(1, $p->price) < 3 && $p->price / max(1, $price) < 3);
                if ($cfg['auto'] && $priceOk) {
                    $model = Product::find($p->id);
                    if ($model && static::apply($model, $d['barcode'], 'auto', $d['name'], $price, 'نام یکسان در فایل و سایت؛ کد قبلی در فایل نبود')) {
                        $site[$k] = $model; // ردیف فایل حالا «پیدا شده» است (قیمت/موجودی معمول به‌روز می‌شود)
                        $taken[$p->id] = 1;
                        $out['applied'][] = [$p->sku, $d['barcode'], $model->name];
                    }

                    continue;
                }
                if (! isset($pendingOpen[$d['barcode']])) {
                    static::suggest($p->id, (string) $p->sku, $d['barcode'], $d['name'], $price, 95, $priceOk ? 'نام یکسان (تغییر خودکار خاموش است)' : 'نام یکسان ولی قیمت خیلی متفاوت');
                    $out['pending'][] = [$p->sku, $d['barcode'], $p->name];
                }

                continue;
            }
            if (! $cfg['suggest'] || ! $fullFile || isset($pendingOpen[$d['barcode']]) || count($out['pending']) >= 300) {
                continue;
            }
            // نام کمی فرق دارد: بهترین نامزد شبیه (فقط پیشنهاد، با تأیید شما)
            $best = null;
            $bestS = 0;
            $w = static::words($d['name']);
            $first = $w[0] ?? '';
            if ($first === '') {
                continue;
            }
            foreach ($byWord[$first] ?? [] as $pid) {
                $p = $all[$pid];
                if (isset($taken[$p->id]) || $inFile($p)) {
                    continue;
                }
                $s = static::similarity($d['name'], (string) $p->name);
                if ($s > $bestS) {
                    [$best, $bestS] = [$p, $s];
                }
            }
            if ($best && $bestS >= 80 && ! isset($rejected[$best->id.'|'.$d['barcode']])) {
                $priceOk = ! $price || ! $best->price || abs($price - $best->price) / max($price, $best->price) <= 0.35;
                if ($priceOk) {
                    static::suggest($best->id, (string) $best->sku, $d['barcode'], $d['name'], $price, $bestS, 'نام شبیه ('.$bestS.'٪)');
                    $out['pending'][] = [$best->sku, $d['barcode'], $best->name];
                    $pendingOpen[$d['barcode']] = 1;
                }
            }
        }

        return $out;
    }

    protected static function suggest(int $pid, string $old, string $new, string $fileName, ?int $price, int $score, string $reason): void
    {
        DB::table('product_code_changes')->insert([
            'product_id' => $pid, 'old_code' => $old, 'new_code' => $new, 'file_name' => mb_substr($fileName, 0, 190), 'file_price' => $price,
            'status' => 'pending', 'source' => 'auto', 'score' => min(100, $score), 'reason' => $reason, 'created_at' => now(), 'updated_at' => now(),
        ]);
    }

    /** عوض کردن کد کالا؛ کد قبلی در old_codes می‌ماند */
    public static function apply(Product $p, string $new, string $source, ?string $fileName = null, ?int $price = null, ?string $reason = null, ?int $userId = null): bool
    {
        $new = trim(en_digits($new));
        if ($new === '' || $new === (string) $p->sku) {
            return false;
        }
        // کد تازه مال کالای دیگری است؟
        $other = Product::query()->where('id', '!=', $p->id)->where('sku', $new)->first(['id', 'name']);
        if ($other) {
            return false;
        }
        try {
            DB::transaction(function () use ($p, $new, $source, $fileName, $price, $reason, $userId) {
                $old = (string) $p->sku;
                $p->sku = $new;
                static::$silent = true;
                try {
                    $p->save();
                } finally {
                    static::$silent = false;
                }
                DB::table('product_code_changes')->insert([
                    'product_id' => $p->id, 'old_code' => $old ?: null, 'new_code' => $new, 'file_name' => $fileName ? mb_substr($fileName, 0, 190) : null,
                    'file_price' => $price, 'status' => 'applied', 'source' => $source, 'score' => 100, 'reason' => $reason,
                    'user_id' => $userId ?? auth()->id(), 'created_at' => now(), 'updated_at' => now(),
                ]);
                // پیشنهادهای باز همین کد/کالا بسته شوند
                DB::table('product_code_changes')->where('status', 'pending')->where(fn ($q) => $q->where('new_code', $new)->orWhere('product_id', $p->id))
                    ->update(['status' => 'rejected', 'reason' => 'با تغییر دیگری بسته شد', 'updated_at' => now()]);
            });

            return true;
        } catch (Throwable $e) {
            report($e);

            return false;
        }
    }

    /** برگرداندن یک تغییر */
    public static function undo(int $changeId): bool
    {
        $c = DB::table('product_code_changes')->find($changeId);
        if (! $c || $c->status !== 'applied' || ! $c->old_code) {
            return false;
        }
        $p = Product::find($c->product_id);
        if (! $p || (string) $p->sku !== (string) $c->new_code) {
            return false;
        }
        if (Product::query()->where('id', '!=', $p->id)->where('sku', $c->old_code)->exists()) {
            return false;
        }
        $p->sku = $c->old_code;
        static::$silent = true;
        try {
            $p->save();
        } finally {
            static::$silent = false;
        }
        DB::table('product_code_changes')->where('id', $c->id)->update(['status' => 'undone', 'updated_at' => now()]);
        // کد اشتباه دوباره پیشنهاد نشود
        DB::table('product_code_changes')->insert(['product_id' => $p->id, 'old_code' => $c->old_code, 'new_code' => $c->new_code, 'status' => 'rejected', 'source' => 'manual',
            'reason' => 'برگردانده شد', 'user_id' => auth()->id(), 'created_at' => now(), 'updated_at' => now()]);

        return true;
    }

    public static function approve(int $changeId): bool
    {
        $c = DB::table('product_code_changes')->find($changeId);
        if (! $c || $c->status !== 'pending' || ! ($p = Product::find($c->product_id))) {
            return false;
        }
        $ok = static::apply($p, (string) $c->new_code, 'assign', $c->file_name, $c->file_price, 'تأیید پیشنهاد: '.$c->reason, auth()->id());
        if ($ok) {
            DB::table('product_code_changes')->where('id', $c->id)->delete(); // ردیف «انجام‌شده» جایش ثبت شد
        }

        return $ok;
    }

    public static function reject(int $changeId): void
    {
        DB::table('product_code_changes')->where('id', $changeId)->where('status', 'pending')
            ->update(['status' => 'rejected', 'user_id' => auth()->id(), 'updated_at' => now()]);
    }

    public static function pendingCount(): int
    {
        try {
            return static::ready() ? (int) DB::table('product_code_changes')->where('status', 'pending')->count() : 0;
        } catch (Throwable) {
            return 0;
        }
    }

    public static function addOld(?string $list, string $old, string $new): ?string
    {
        $codes = array_values(array_filter(explode('|', (string) $list)));
        if ($old !== '' && $old !== $new && ! in_array($old, $codes, true)) {
            array_unshift($codes, $old);
        }
        $codes = array_values(array_filter($codes, fn ($c) => $c !== $new));
        $codes = array_slice($codes, 0, 10);

        return $codes ? '|'.implode('|', $codes).'|' : null;
    }

    public static function removeOld(?string $list, string $code): ?string
    {
        $codes = array_values(array_filter(explode('|', (string) $list), fn ($c) => $c !== '' && $c !== $code));

        return $codes ? '|'.implode('|', $codes).'|' : null;
    }

    /** «|43307|12|» ← [43307, 12] */
    public static function list(?string $list): array
    {
        return array_values(array_filter(explode('|', (string) $list)));
    }
}
