<?php

namespace App\Services;

use App\Models\ChannelPost;
use App\Models\Product;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Throwable;

/**
 * ارسال خودکار کالاها به کانال‌های تلگرام، بله، ایتا و روبیکا.
 * کالاهای جدید در صف قرار می‌گیرند و با فاصله و سقف ساعتی ارسال می‌شوند تا کانال شلوغ و ربات مسدود نشود.
 */
class Channels
{
    public const TYPES = [
        'telegram' => 'تلگرام',
        'bale' => 'بله',
        'eitaa' => 'ایتا (ایتایار)',
        'rubika' => 'روبیکا',
    ];

    public const HELP = [
        'telegram' => 'از @BotFather ربات بسازید و توکن را وارد کنید. ربات را مدیر کانال کنید. شناسه کانال: ‎@نام_کانال یا عدد ‎-100…‎. چون تلگرام روی بیشتر هاست‌های ایران مسدود است، در صورت نیاز آدرس واسط (پروکسی/Worker) را در «آدرس API» بگذارید.',
        'bale' => 'در بله به @botfather پیام دهید، ربات بسازید و توکن را وارد کنید. ربات را مدیر کانال کنید. شناسه کانال: ‎@نام_کانال یا شناسه عددی.',
        'eitaa' => 'در eitaayar.ir ثبت‌نام کنید، کانال را اضافه کنید و توکن ایتایار را بردارید. شناسه کانال همان نام کاربری کانال (بدون @) یا شناسه عددی است.',
        'rubika' => 'در روبیکا به @BotFather پیام دهید، ربات بسازید و توکن را بردارید. ربات را مدیر کانال کنید. شناسه کانال (chat_id) را با ارسال یک پیام در کانال و دکمه «پیدا کردن شناسه» به‌دست آورید.',
    ];

    /** متغیرهای قالب پیام */
    public const VARS = [
        '{name}' => 'نام کالا',
        '{price}' => 'قیمت هر عدد',
        '{old_price}' => 'قیمت قبل از تخفیف',
        '{old_price_line}' => 'خط «قیمت قبل» فقط اگر تخفیف دارد',
        '{discount}' => 'درصد تخفیف',
        '{carton_price}' => 'قیمت کارتن',
        '{per_carton}' => 'تعداد در کارتن',
        '{carton_line}' => '«کارتن ۱۲ عددی» یا «فروش تکی»',
        '{retail_price}' => 'قیمت تکی',
        '{category}' => 'نام دسته',
        '{code}' => 'کد کالا',
        '{barcode}' => 'بارکد',
        '{short}' => 'توضیح کوتاه',
        '{link}' => 'لینک کالا',
        '{stock}' => 'موجود / ناموجود',
        '{hashtags}' => 'هشتگ دسته و نام',
        '{shop}' => 'نام فروشگاه',
    ];

    public static function rules(): array
    {
        $r = (array) setting('channel_rules', []);

        return [
            'auto_new' => ! array_key_exists('auto_new', $r) || ! empty($r['auto_new']),
            'need_image' => ! array_key_exists('need_image', $r) || ! empty($r['need_image']),
            'need_stock' => ! array_key_exists('need_stock', $r) || ! empty($r['need_stock']),
            'per_hour' => max(1, (int) ($r['per_hour'] ?? 20)),
            'gap' => max(0, (float) ($r['gap'] ?? 2)),
            'quiet_from' => (int) ($r['quiet_from'] ?? 0),
            'quiet_to' => (int) ($r['quiet_to'] ?? 7),
            'button' => trim((string) ($r['button'] ?? 'مشاهده و خرید')),
            'template' => (string) (($r['template'] ?? '') ?: "🛍 {name}\n\n💰 قیمت: {price} تومان{old_price_line}\n📦 {carton_line}\n\n🔗 {link}\n\n{hashtags}"),
        ];
    }

    /** کانال‌های تعریف‌شده */
    public static function channels(bool $onlyEnabled = true): array
    {
        $out = [];
        foreach ((array) setting('channels', []) as $c) {
            if (empty($c['type']) || empty($c['token']) || empty($c['chat_id'])) {
                continue;
            }
            if ($onlyEnabled && empty($c['enabled'])) {
                continue;
            }
            $c['key'] = ($c['key'] ?? '') ?: substr(md5($c['type'].$c['chat_id']), 0, 10);
            $c['label'] = ($c['label'] ?? '') ?: (self::TYPES[$c['type']] ?? $c['type']).' '.$c['chat_id'];
            $out[$c['key']] = $c;
        }

        return $out;
    }

    /** آیا این کالا شرایط ارسال خودکار را دارد؟ */
    public static function eligible(Product $p): bool
    {
        $r = static::rules();
        if (! $p->is_active) {
            return false;
        }
        if ($r['need_image'] && ! $p->image) {
            return false;
        }
        if ($r['need_stock'] && ! $p->isAvailable()) {
            return false;
        }

        return $p->price > 0;
    }

    /** افزودن کالا به صف همه کانال‌ها */
    public static function queue(Product $p, string $kind = 'new', bool $force = false): int
    {
        $n = 0;
        foreach (static::channels() as $key => $c) {
            if (! $force && ChannelPost::query()->where('product_id', $p->id)->where('channel', $key)->where('kind', $kind)->whereIn('status', ['queued', 'sent'])->exists()) {
                continue;
            }
            ChannelPost::create(['product_id' => $p->id, 'channel' => $key, 'kind' => $kind, 'status' => 'queued']);
            $n++;
        }
        if ($n && ! $p->channel_posted_at) {
            $p->channel_posted_at = now();
            $p->saveQuietly();
        }

        return $n;
    }

    /** بعد از ذخیره کالا (ساخت دستی یا همگام‌سازی) */
    public static function onSaved(Product $p): void
    {
        try {
            if ($p->wasRecentlyCreated) {
                $p = $p->fresh() ?? $p; // مقادیر پیش‌فرض ستون‌ها
            }
            if ($p->channel_posted_at || ! static::rules()['auto_new'] || ! static::channels() || ! static::eligible($p)) {
                return;
            }
            // فقط کالاهای تازه (ساخته‌شده در ۷ روز اخیر)؛ کالاهای قدیمی با فعال شدن دوباره ارسال نمی‌شوند
            if ($p->created_at && $p->created_at->lt(now()->subDays(7))) {
                return;
            }
            static::queue($p, 'new');
        } catch (Throwable $e) {
            report($e);
        }
    }

    public static function caption(Product $p, ?string $tpl = null): string
    {
        $r = static::rules();
        $tpl ??= $r['template'];
        $cat = $p->category?->name ?? '';
        $tags = array_filter([$cat, Str::of($p->name)->explode(' ')->take(2)->implode(' ')]);
        $hashtags = implode(' ', array_map(fn ($t) => '#'.preg_replace('/[\s\x{200C}\-]+/u', '_', trim($t)), array_unique($tags)));
        $vars = [
            '{name}' => $p->name,
            '{price}' => money($p->price),
            '{old_price}' => $p->compare_price > $p->price ? money($p->compare_price) : '',
            '{old_price_line}' => $p->compare_price > $p->price ? "\n❌ قیمت قبل: ".money($p->compare_price).' تومان ('.fa($p->discountPercent()).'٪ تخفیف)' : '',
            '{discount}' => $p->discountPercent() ? fa($p->discountPercent()).'٪' : '',
            '{carton_price}' => money($p->price * max(1, $p->per_carton)),
            '{per_carton}' => fa($p->per_carton),
            '{carton_line}' => $p->hasCartons() ? 'کارتن '.fa($p->per_carton).' عددی'.($p->retailAvailable() ? ' — امکان خرید تکی' : '') : 'فروش تکی',
            '{retail_price}' => $p->retail_enabled ? money($p->retail_price ?: $p->price) : '',
            '{category}' => $cat,
            '{code}' => (string) ($p->sku ?: $p->sync_code ?: $p->id),
            '{barcode}' => \App\Services\BotHub::code($p) ?: '—',
            '{short}' => trim(strip_tags((string) $p->short_description)),
            '{link}' => rawurldecode($p->url()),
            '{stock}' => $p->isAvailable() ? '✅ موجود' : '⛔️ ناموجود',
            '{hashtags}' => $hashtags,
            '{shop}' => store_name(),
        ];
        $text = strtr($tpl, $vars);
        $text = preg_replace("/[ \t]+\n/u", "\n", $text);
        $text = preg_replace("/\n{3,}/u", "\n\n", trim($text));

        return mb_substr($text, 0, 1000);
    }

    /** علت آماده نشدن تصویر آخرین کالا (برای پیام خطا) */
    protected static string $photoWhy = '';

    /**
     * تصویر مناسب ارسال (JPEG حداکثر ۱۲۸۰ پیکسل). اگر GD هاست نتواند فرمت را بخواند (مثلاً webp)،
     * خود فایل اصلی فرستاده می‌شود؛ تصویر با آدرس اینترنتی هم یک بار دانلود و نگه داشته می‌شود.
     */
    protected static function photo(Product $p): ?string
    {
        static::$photoWhy = '';
        $img = trim((string) $p->image);
        if ($img === '') {
            static::$photoWhy = 'کالا تصویر ندارد';

            return null;
        }
        $dir = storage_path('app/channel-tmp');
        if (! is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        if (preg_match('#^(https?:)?//#', $img)) {
            $src = $dir.'/r-'.substr(md5($img), 0, 12).'.img';
            if (! is_file($src) || filesize($src) < 200) {
                try {
                    $u = str_starts_with($img, '//') ? 'https:'.$img : $img;
                    $r = Http::timeout(25)->connectTimeout(8)->withHeaders(['User-Agent' => 'Mozilla/5.0'])->get($u);
                    if (! $r->successful() || strlen($r->body()) < 200 || ! @getimagesizefromstring($r->body())) {
                        static::$photoWhy = 'دانلود تصویر از آدرس اینترنتی آن نشد (HTTP '.$r->status().')';

                        return null;
                    }
                    file_put_contents($src, $r->body());
                } catch (Throwable $e) {
                    static::$photoWhy = 'دانلود تصویر از آدرس اینترنتی آن نشد';

                    return null;
                }
            }
        } else {
            $src = public_path('uploads/'.ltrim($img, '/'));
            if (! is_file($src)) {
                static::$photoWhy = 'فایل تصویر روی هاست پیدا نشد (uploads/'.ltrim($img, '/').')';

                return null;
            }
        }
        $dest = $dir.'/'.$p->id.'-'.substr(md5($img.filemtime($src)), 0, 8).'.jpg';
        if (is_file($dest) && filesize($dest) > 0) {
            return $dest;
        }
        $info = @getimagesize($src);
        try {
            $w0 = (int) ($info[0] ?? 0);
            $h0 = (int) ($info[1] ?? 0);
            // تصویر خیلی بزرگ ممکن است حافظه هاست را تمام کند؛ همان فایل اصلی فرستاده می‌شود
            $im = ($w0 * $h0 > 0 && $w0 * $h0 <= 25_000_000 && function_exists('imagecreatetruecolor')) ? match ($info[2] ?? 0) {
                IMAGETYPE_JPEG => @imagecreatefromjpeg($src),
                IMAGETYPE_PNG => @imagecreatefrompng($src),
                IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($src) : null,
                IMAGETYPE_GIF => @imagecreatefromgif($src),
                default => null,
            } : null;
            if ($im) {
                $w = imagesx($im);
                $h = imagesy($im);
                $s = min(1, 1280 / max($w, $h));
                $nw = max(1, (int) round($w * $s));
                $nh = max(1, (int) round($h * $s));
                $out = imagecreatetruecolor($nw, $nh);
                imagefill($out, 0, 0, imagecolorallocate($out, 255, 255, 255));
                imagecopyresampled($out, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
                $ok = @imagejpeg($out, $dest, 88);
                imagedestroy($im);
                imagedestroy($out);
                if ($ok && is_file($dest) && filesize($dest) > 0) {
                    return $dest;
                }
            }
        } catch (Throwable) {
        }
        // GD نتوانست؛ خود فایل (jpg/png/webp/gif تا ۱۰ مگ) فرستاده می‌شود
        if ($info && in_array($info[2] ?? 0, [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP, IMAGETYPE_GIF], true) && filesize($src) <= 10 * 1024 * 1024) {
            return $src;
        }
        static::$photoWhy = 'فرمت تصویر قابل ارسال نیست';

        return null;
    }

    protected static function fname(string $f): string
    {
        $t = @getimagesize($f)[2] ?? 0;

        return 'photo.'.match ($t) { IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif', default => 'jpg' };
    }

    /**
     * ارسال یک کالا به یک کانال
     *
     * @return array{ok: bool, msg: string, id: ?string}
     */
    public static function send(array $c, Product $p, ?string $text = null): array
    {
        $text ??= static::caption($p);
        $photo = static::photo($p);
        $rules = static::rules();
        $btn = $rules['button'];
        if (! $photo && $rules['need_image']) {
            return ['ok' => false, 'msg' => 'بدون تصویر ارسال نشد: '.(static::$photoWhy ?: 'تصویر آماده نشد'), 'id' => null];
        }
        try {
            return match ($c['type']) {
                'telegram', 'bale' => static::sendBotApi($c, $text, $photo, $btn !== '' ? ['text' => $btn, 'url' => $p->url()] : null),
                'eitaa' => static::sendEitaa($c, $text, $photo),
                'rubika' => static::sendRubika($c, $text, $photo),
                default => ['ok' => false, 'msg' => 'نوع کانال نامعتبر است.', 'id' => null],
            };
        } catch (Throwable $e) {
            return ['ok' => false, 'msg' => 'خطای اتصال: '.$e->getMessage(), 'id' => null];
        }
    }

    /** پیام متنی آزمایشی */
    public static function test(array $c): array
    {
        $text = '✅ اتصال '.store_name().' به این کانال برقرار است.';
        try {
            return match ($c['type']) {
                'telegram', 'bale' => static::sendBotApi($c, $text, null, null),
                'eitaa' => static::sendEitaa($c, $text, null),
                'rubika' => static::sendRubika($c, $text, null),
                default => ['ok' => false, 'msg' => 'نوع کانال نامعتبر است.', 'id' => null],
            };
        } catch (Throwable $e) {
            return ['ok' => false, 'msg' => 'خطای اتصال: '.$e->getMessage(), 'id' => null];
        }
    }

    protected static function botBase(array $c): string
    {
        if ($c['type'] === 'bale') {
            return 'https://tapi.bale.ai/bot'.trim($c['token']);
        }
        $base = rtrim(trim((string) ($c['api_base'] ?? '')), '/') ?: 'https://api.telegram.org';

        return $base.'/bot'.trim($c['token']);
    }

    /** تلگرام و بله (API یکسان) */
    protected static function sendBotApi(array $c, string $text, ?string $photo, ?array $button): array
    {
        $base = static::botBase($c);
        $markup = $button ? json_encode(['inline_keyboard' => [[$button]]], JSON_UNESCAPED_UNICODE) : null;
        $do = function (?string $markup) use ($base, $c, $text, $photo) {
            $params = ['chat_id' => trim($c['chat_id'])];
            if ($markup) {
                $params['reply_markup'] = $markup;
            }
            if ($photo) {
                $params['caption'] = $text;

                return Http::timeout(40)->attach('photo', file_get_contents($photo), static::fname($photo))->post($base.'/sendPhoto', $params);
            }
            $params['text'] = $text;

            return Http::timeout(25)->asForm()->post($base.'/sendMessage', $params);
        };
        $r = $do($markup);
        $j = $r->json() ?: [];
        if (empty($j['ok']) && $markup && str_contains(strtolower((string) ($j['description'] ?? '')), 'markup')) {
            $r = $do(null);
            $j = $r->json() ?: [];
        }
        if (! empty($j['ok'])) {
            return ['ok' => true, 'msg' => 'ارسال شد', 'id' => (string) ($j['result']['message_id'] ?? '')];
        }

        return ['ok' => false, 'msg' => static::errText($j['description'] ?? null, $r->status()), 'id' => null];
    }

    /** ایتا از طریق ایتایار */
    protected static function sendEitaa(array $c, string $text, ?string $photo): array
    {
        $base = 'https://eitaayar.ir/api/'.trim($c['token']);
        $chat = ltrim(trim($c['chat_id']), '@');
        $r = $photo
            ? Http::timeout(40)->attach('file', file_get_contents($photo), static::fname($photo))->post($base.'/sendFile', ['chat_id' => $chat, 'caption' => $text])
            : Http::timeout(25)->asForm()->post($base.'/sendMessage', ['chat_id' => $chat, 'text' => $text]);
        $j = $r->json() ?: [];
        if (! empty($j['ok'])) {
            return ['ok' => true, 'msg' => 'ارسال شد', 'id' => (string) ($j['result']['message_id'] ?? '')];
        }

        return ['ok' => false, 'msg' => static::errText($j['description'] ?? null, $r->status()), 'id' => null];
    }

    /** روبیکا (Bot API نسخه ۳) */
    protected static function sendRubika(array $c, string $text, ?string $photo): array
    {
        $base = 'https://botapi.rubika.ir/v3/'.trim($c['token']);
        $chat = trim($c['chat_id']);
        if ($photo) {
            $r = Http::timeout(25)->post($base.'/requestSendFile', ['type' => 'Image']);
            $j = $r->json() ?: [];
            $url = $j['data']['upload_url'] ?? null;
            if (! $url) {
                return ['ok' => false, 'msg' => static::errText($j['status'] ?? null, $r->status()), 'id' => null];
            }
            $u = Http::timeout(60)->attach('file', file_get_contents($photo), static::fname($photo))->post($url);
            $fid = $u->json('data.file_id');
            if (! $fid) {
                return ['ok' => false, 'msg' => 'آپلود تصویر در روبیکا ناموفق بود (HTTP '.$u->status().')', 'id' => null];
            }
            $r = Http::timeout(25)->post($base.'/sendFile', ['chat_id' => $chat, 'file_id' => $fid, 'text' => $text]);
        } else {
            $r = Http::timeout(25)->post($base.'/sendMessage', ['chat_id' => $chat, 'text' => $text]);
        }
        $j = $r->json() ?: [];
        if (strtoupper((string) ($j['status'] ?? '')) === 'OK') {
            return ['ok' => true, 'msg' => 'ارسال شد', 'id' => (string) ($j['data']['message_id'] ?? '')];
        }

        return ['ok' => false, 'msg' => static::errText(($j['status'] ?? '').' '.($j['dev_message'] ?? ''), $r->status()), 'id' => null];
    }

    /** پیدا کردن شناسه گفتگوها از آخرین پیام‌های ربات (برای روبیکا، بله و تلگرام) */
    public static function discover(array $c): array
    {
        try {
            if ($c['type'] === 'rubika') {
                $j = Http::timeout(20)->post('https://botapi.rubika.ir/v3/'.trim($c['token']).'/getUpdates', ['limit' => 50])->json() ?: [];
                $out = [];
                foreach ((array) ($j['data']['updates'] ?? []) as $u) {
                    if (! empty($u['chat_id'])) {
                        $out[$u['chat_id']] = trim(($u['new_message']['text'] ?? '') ?: ($u['type'] ?? ''));
                    }
                }

                return $out;
            }
            if (in_array($c['type'], ['telegram', 'bale'], true)) {
                $j = Http::timeout(20)->get(static::botBase($c).'/getUpdates')->json() ?: [];
                $out = [];
                foreach ((array) ($j['result'] ?? []) as $u) {
                    $chat = $u['channel_post']['chat'] ?? $u['message']['chat'] ?? $u['my_chat_member']['chat'] ?? null;
                    if ($chat) {
                        $out[$chat['id']] = trim(($chat['title'] ?? '') ?: ($chat['username'] ?? '') ?: ($chat['first_name'] ?? ''));
                    }
                }

                return $out;
            }
        } catch (Throwable $e) {
            return ['_error' => $e->getMessage()];
        }

        return [];
    }

    protected static function errText(?string $desc, int $status): string
    {
        $desc = trim((string) $desc);
        $hint = match (true) {
            $status === 401 || str_contains(strtolower($desc), 'unauthorized') || str_contains(strtolower($desc), 'invalid_access') => ' — توکن ربات نادرست است.',
            $status === 403 || str_contains(strtolower($desc), 'not enough rights') || str_contains(strtolower($desc), 'forbidden') => ' — ربات مدیر کانال نیست یا اجازه ارسال ندارد.',
            str_contains(strtolower($desc), 'chat not found') || str_contains(strtolower($desc), 'invalid_input') => ' — شناسه کانال نادرست است.',
            $status === 429 => ' — ارسال زیاد؛ کمی بعد خودکار تکرار می‌شود.',
            $status === 0 => ' — سرور پیام‌رسان از هاست در دسترس نیست.',
            default => '',
        };

        return ($desc !== '' ? $desc : 'پاسخ نامعتبر').' (HTTP '.$status.')'.$hint;
    }

    /** پردازش صف (از زمان‌بند) */
    public static function tick(): int
    {
        $channels = static::channels();
        if (! $channels || ! ChannelPost::query()->where('status', 'queued')->exists()) {
            return 0;
        }
        $r = static::rules();
        $hour = (int) now()->setTimezone('Asia/Tehran')->format('G');
        if ($r['quiet_from'] !== $r['quiet_to']) {
            $quiet = $r['quiet_from'] < $r['quiet_to']
                ? ($hour >= $r['quiet_from'] && $hour < $r['quiet_to'])
                : ($hour >= $r['quiet_from'] || $hour < $r['quiet_to']);
            if ($quiet) {
                return 0;
            }
        }
        $sent = 0;
        foreach ($channels as $key => $c) {
            $last = ChannelPost::query()->where('channel', $key)->whereNotNull('sent_at')->max('sent_at');
            if ($last && \Illuminate\Support\Carbon::parse($last)->gt(now()->subSeconds((int) round($r['gap'] * 60)))) {
                continue;
            }
            if (ChannelPost::query()->where('channel', $key)->where('status', 'sent')->where('sent_at', '>', now()->subHour())->count() >= $r['per_hour']) {
                continue;
            }
            $post = ChannelPost::query()->where('channel', $key)->where('status', 'queued')
                ->where(fn ($q) => $q->where('attempts', 0)->orWhere('updated_at', '<', now()->subMinutes(10)))
                ->orderBy('id')->first();
            if (! $post) {
                continue;
            }
            $p = $post->product;
            if (! $p || ($post->kind === 'new' && ! static::eligible($p))) {
                $post->update(['status' => 'skipped', 'error' => $p ? 'شرایط ارسال (فعال، تصویر، موجودی) را ندارد.' : 'کالا حذف شده است.']);

                continue;
            }
            $res = static::send($c, $p);
            $post->attempts++;
            if ($res['ok']) {
                $post->fill(['status' => 'sent', 'sent_at' => now(), 'message_id' => $res['id'], 'error' => null])->save();
                $sent++;
            } else {
                $post->fill(['status' => $post->attempts >= 3 ? 'failed' : 'queued', 'error' => $res['msg']])->save();
            }
        }

        return $sent;
    }
}
