<?php

namespace App\Services\Sync;

use App\Models\Category;
use App\Models\Product;
use App\Models\SyncItem;
use App\Models\SyncPriceChange;
use App\Models\SyncSource;
use App\Support\ImageCompressor;
use App\Support\JsonStream;
use App\Support\Search;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * موتور همگام‌سازی با JSON:
 *  ۱) دریافت JSON → تبدیل به صف سبک (NDJSON) با نگاشت فیلدها
 *  ۲) پردازش مرحله‌ای (هر بار چند ثانیه) → ساخت/به‌روزرسانی محصول، قیمت‌گذاری، موجودی دو انبار
 *  ۳) دانلود تصاویر در مرحله جدا با تلاش دوباره و ثبت علت شکست
 *  ۴) پاکسازی کالاهایی که دیگر در JSON نیستند (طبق تنظیمات)
 */
class SyncEngine
{
    public const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Safari/537.36';

    protected array $o = [];

    protected array $catCache = [];

    /** پاسخ تصاویری که هم‌زمان (موازی) دانلود شده‌اند: url => body */
    protected array $pre = [];

    /** تصویر سبک (کالای ناموجود): کوچک‌تر و فشرده‌تر */
    protected bool $small = false;

    /** کالای ناموجود فقط با یک تصویر اصلی سبک ساخته شود؛ گالری و تصویر کامل وقتی موجود شد */
    public function lightOut(): bool
    {
        return ($this->o['img_out'] ?? 'main') === 'main';
    }

    /** حجم تصاویر پیش و پس از فشرده‌سازی در همین اجرا [قبل، بعد] */
    protected array $bytes = [0, 0];

    /** کالاهای جدیدی که باید همراه تصویرشان ساخته شوند (حالت «اول تصویر») */
    protected array $candidates = [];

    protected ?array $excelIn = null;

    public function __construct(protected SyncSource $src)
    {
        $this->o = $src->allOptions();
    }

    /** کالای جدید فقط همراه تصویرش ساخته شود (یکی‌یکی، به ترتیب) */
    public function strictImages(): bool
    {
        return (bool) $this->o['img_download'] && (bool) ($this->o['img_required'] ?? true);
    }

    /** کدهایی که از اکسل کالاهای خودمان آمده‌اند = موجود */
    public function isExcelIn(array $r): bool
    {
        $this->excelIn ??= array_flip(array_map('strval', (array) $this->src->opt('excel_in', [])));
        if (! $this->excelIn) {
            return false;
        }

        return isset($this->excelIn[$this->codeKey($r['c'])]) || ($r['b'] !== '' && isset($this->excelIn[$this->codeKey($r['b'])]));
    }

    public static function for(SyncSource $src): static
    {
        return new static($src);
    }

    /* ================= دریافت ================= */

    protected function feedHeaders(): array
    {
        $headers = ['Accept' => 'application/json, text/plain, */*', 'User-Agent' => self::UA, 'Accept-Encoding' => 'gzip, deflate'];
        foreach (preg_split('/\R/', (string) $this->o['headers']) as $line) {
            if (str_contains($line, ':')) {
                [$k, $v] = array_map('trim', explode(':', $line, 2));
                if ($k !== '') {
                    $headers[$k] = $v;
                }
            }
        }

        return $headers;
    }

    /**
     * دانلود JSON مستقیم روی دیسک (بدون بارگذاری در حافظه) با تلاش دوباره.
     * فایل کامل اول با نام موقت ذخیره و بعد جایگزین می‌شود تا فایل نیمه‌کاره هرگز پردازش نشود.
     */
    public function fetchToFile(): string
    {
        @set_time_limit(600);
        $dir = $this->src->dir();
        $tmp = $dir.'/feed.download';
        $final = $dir.'/feed.json';
        // حالت بایگانی: بدون اتصال به سایت قبلی، از نسخه ذخیره‌شده JSON
        if (! empty(((array) $this->src->options)['offline'])) {
            $arch = $this->src->archivePath();
            if (! is_file($arch)) {
                throw new RuntimeException('نسخه ذخیره‌شده JSON پیدا نشد.');
            }
            @copy($arch, $final);

            return $final;
        }
        $last = null;
        for ($try = 1; $try <= 3; $try++) {
            @unlink($tmp);
            try {
                $req = Http::timeout(300)->connectTimeout(25)->withHeaders($this->feedHeaders())->withOptions(['sink' => $tmp, 'decode_content' => true]);
                if ($try > 1) {
                    $req = $req->withoutVerifying(); // بعضی هاست‌ها گواهی SSL ناقص دارند
                }
                $resp = $req->get($this->src->url);
                if (! $resp->successful()) {
                    $last = 'سرور JSON پاسخ معتبر نداد (کد '.$resp->status().').';
                    if ($resp->status() >= 400 && $resp->status() < 500) {
                        break;
                    }

                    continue;
                }
                // بعد از انتقال دامنه، این آدرس ممکن است خروجی خود همین سایت باشد؛ خواندن آن قیمت‌ها را چرخه‌ای بالا می‌برد
                if ($resp->header('X-Store-Self-Feed') !== '') {
                    @unlink($tmp);
                    throw new RuntimeException('این آدرس JSON خروجی خود همین سایت است (دامنه منتقل شده). همگام‌سازی این منبع را خاموش کنید؛ قیمت و موجودی را از «ورود از اکسل» به‌روز کنید.');
                }
                clearstatcache(true, $tmp);
                $size = (int) @filesize($tmp);
                if ($size < 2) {
                    $last = 'پاسخ JSON خالی بود.';

                    continue;
                }
                // بررسی پایان فایل: JSON کامل باید با } یا ] تمام شود
                $fh = fopen($tmp, 'rb');
                fseek($fh, max(0, $size - 64));
                $tail = rtrim((string) fread($fh, 64));
                fclose($fh);
                if ($tail === '' || ! in_array(substr($tail, -1), ['}', ']'], true)) {
                    $last = 'دانلود JSON ناقص ماند ('.round($size / 1048576, 1).' مگابایت)؛ دوباره تلاش می‌شود.';

                    continue;
                }
                @rename($tmp, $final);
                $this->src->archive($final);

                return $final;
            } catch (Throwable $e) {
                if (str_contains($e->getMessage(), 'خروجی خود همین سایت')) {
                    throw $e;
                }
                $last = 'اتصال به آدرس JSON برقرار نشد: '.Str::limit($e->getMessage(), 200);
                usleep(700000 * $try);
            }
        }
        @unlink($tmp);
        throw new RuntimeException($last ?: 'دریافت JSON ناموفق بود.');
    }

    /** پیش‌نمایش اتصال: تعداد کالاها و اولین کالا (جریانی، حتی برای فایل‌های بسیار بزرگ) */
    public function preview(): array
    {
        $file = $this->fetchToFile();
        $js = new JsonStream($file);
        $first = null;
        $n = 0;
        $js->each($js->locate(trim((string) $this->o['json_path'])), function ($row) use (&$first, &$n) {
            $first ??= $row;
            $n++;
        });

        return ['count' => $n, 'first' => $first ?? [], 'size' => (int) filesize($file)];
    }

    /** سازگاری با نسخه قبل (برای فایل‌های کوچک) */
    public function download(): array
    {
        $file = $this->fetchToFile();
        $js = new JsonStream($file);
        $rows = [];
        $js->each($js->locate(trim((string) $this->o['json_path'])), function ($row) use (&$rows) {
            $rows[] = $row;
        });

        return $rows;
    }

    /** پیدا کردن آرایه کالاها در JSON (مسیر تنظیم‌شده یا تشخیص خودکار) */
    public function listFrom(array $data): array
    {
        $path = trim((string) $this->o['json_path']);
        if ($path !== '' && is_array($l = data_get($data, $path))) {
            return array_values($l);
        }
        if (array_is_list($data)) {
            return $data;
        }
        foreach (['products', 'data', 'items', 'result', 'records'] as $k) {
            if (isset($data[$k]) && is_array($data[$k])) {
                return array_values($data[$k]);
            }
        }
        foreach ($data as $v) {
            if (is_array($v) && array_is_list($v) && isset($v[0]) && is_array($v[0])) {
                return $v;
            }
        }
        throw new RuntimeException('فهرست کالاها در JSON پیدا نشد. «مسیر فهرست کالاها» را در تنظیمات اتصال بررسی کنید.');
    }

    /** تبدیل یک ردیف خام به ساختار استاندارد */
    public function normalize(array $p): ?array
    {
        $f = $this->o['fields'];
        $get = fn (string $k) => ($f[$k] ?? '') !== '' ? data_get($p, $f[$k]) : null;
        $code = trim((string) $get('code'));
        if ($code === '') {
            return null;
        }
        $num = fn ($v) => $v === null || $v === '' ? 0 : (float) str_replace([',', '٬', ' '], '', en_digits((string) $v));
        $per = 0;
        foreach (['step', 'per_carton'] as $k) {
            $v = $get($k);
            if ($v !== null && $v !== '' && preg_match('/\d+/', en_digits((string) $v), $m) && (int) $m[0] > 0) {
                $per = (int) $m[0];
                break;
            }
        }
        $gallery = $get('gallery');
        $gallery = is_array($gallery) ? array_values($gallery) : (is_string($gallery) && $gallery !== '' ? preg_split('/[,|]/', $gallery) : []);

        return [
            'c' => $code,
            't' => $this->txt((string) $get('title')),
            'p' => $num($get('price')),
            'cp' => $num($get('compare_price')),
            's' => (int) $num($get('stock_retail')),
            'w' => (int) $num($get('stock_wholesale')),
            'a' => max(1, $per ?: 1),
            'i' => $get('image'),
            'g' => $gallery,
            'k' => $this->txt((string) $get('category')),
            'b' => trim(en_digits((string) $get('barcode'))),
            'd' => (string) $get('description'),
            'f' => ($f['available'] ?? '') === '' || $get('available') === null ? null : filter_var($get('available'), FILTER_VALIDATE_BOOLEAN),
            'u' => (string) $get('page_url'),
            'ct' => is_scalar($get('per_carton')) ? $this->txt((string) $get('per_carton')) : '',
            'wo' => static::whCode($get('wh_carton')),
            'wr' => static::whCode($get('wh_retail')),
        ];
    }

    /** شماره انبار JSON → کد استاندارد («08» → «8»، خالی/۰ → '') */
    public static function whCode(mixed $v): string
    {
        if (! is_scalar($v)) {
            return '';
        }
        $v = trim(en_digits((string) $v));
        if ($v === '' || $v === '0') {
            return '';
        }

        return ctype_digit($v) ? (string) (int) $v : mb_substr($v, 0, 30);
    }

    protected array $whCache = [];

    /**
     * شناسه انبار با این شماره در نوع داده‌شده (carton = عمده، retail = خرده)؛
     * شماره‌ها در هر نوع جدا هستند: انبار ۷ عمده با انبار ۷ خرده فرق دارد. در صورت نیاز ساخته می‌شود.
     */
    public function warehouseId(string $code, string $kind = 'carton'): ?int
    {
        if ($code === '') {
            return null;
        }
        $key = $kind.':'.$code;
        if (array_key_exists($key, $this->whCache)) {
            return $this->whCache[$key];
        }
        if (! $this->whCache) {
            $this->whCache['_'] = null;
            foreach (\App\Models\Warehouse::query()->whereNotNull('kind')->orderBy('id')->get(['id', 'code', 'kind']) as $w) {
                $k = $w->kind.':'.static::whCode($w->code);
                $this->whCache[$k] ??= $w->id;
            }
            if (array_key_exists($key, $this->whCache)) {
                return $this->whCache[$key];
            }
        }
        $id = null;
        if ($this->o['wh_auto_create'] ?? true) {
            $name = ($kind === 'retail' ? 'انبار خرده ' : 'انبار عمده ').fa($code);
            $id = \App\Models\Warehouse::query()->create(['name' => $name, 'code' => $code, 'kind' => $kind, 'is_active' => true])->id;
            $this->src->addLog('«'.$name.'» از JSON ساخته شد؛ انباردارش را در «انبارها» تعیین کنید.', 'ok');
        }

        return $this->whCache[$key] = $id;
    }

    /** انبار عمده و خرده کالا از روی شماره‌های JSON */
    protected function applyWarehouses(Product $p, array $r): void
    {
        if (! ($this->o['wh_sync'] ?? true)) {
            return;
        }
        if (($r['wo'] ?? '') !== '' && ($id = $this->warehouseId($r['wo'], 'carton'))) {
            $p->warehouse_id = $id;
        }
        if (($r['wr'] ?? '') !== '' && ($id = $this->warehouseId($r['wr'], 'retail'))) {
            $p->retail_warehouse_id = $id;
        }
    }

    protected function txt(string $s): string
    {
        $v = trim(strip_tags(html_entity_decode($s, ENT_QUOTES, 'UTF-8')));
        if ($this->o['fix_arabic']) {
            $v = strtr($v, ['ي' => 'ی', 'ك' => 'ک', 'ى' => 'ی']);
        }

        return trim(preg_replace('/\s+/u', ' ', $v));
    }

    /* ================= شروع و مراحل ================= */

    /**
     * شروع یک اجرا. $codes = فقط این کدها (مثلاً از اکسل)
     *
     * @return string started | same
     */
    /**
     * شروع بدون انتظار: فقط در صف قرار می‌گیرد و دانلود و پردازش در پس‌زمینه (کارگر/کرون) انجام می‌شود.
     * برای دکمه‌های پنل تا صفحه بلافاصله جواب بدهد.
     */
    public function queue(bool $force = false, ?array $codes = null, string $mode = 'full', array $repair = [], bool $forceCreate = false): string
    {
        $lock = Cache::lock('sync.step.'.$this->src->id, 300);
        if (! $lock->block(10)) {
            throw new RuntimeException('یک اجرای دیگر همین حالا در حال پردازش است؛ چند ثانیه دیگر دوباره امتحان کنید.');
        }
        try {
            $this->src->refresh();
            $prev = (array) $this->src->state;
            if (($prev['status'] ?? '') === 'running') {
                return 'running';
            }
            $dir = $this->src->dir();
            @unlink($dir.'/req-codes.json');
            if ($codes !== null) {
                file_put_contents($dir.'/req-codes.json', json_encode(array_values(array_map('strval', $codes)), JSON_UNESCAPED_UNICODE));
            }
            $this->src->state = [
                'status' => 'running', 'phase' => 'fetch', 'mode' => $repair ? 'repair' : $mode, 'started' => now()->toIso8601String(),
                'req' => ['force' => $force || (bool) $repair, 'codes' => $codes !== null, 'mode' => $mode, 'repair' => $repair, 'force_create' => $forceCreate],
                'last_hash' => $prev['last_hash'] ?? null, 'last_total' => $prev['last_total'] ?? 0, 'total' => 0, 'done' => 0,
                'c' => ['created' => 0, 'updated' => 0, 'unchanged' => 0, 'skipped' => 0, 'failed' => 0, 'removed' => 0, 'prices' => 0, 'images' => 0, 'images_failed' => 0],
            ];
            $this->src->last_run_at = now();
            $this->src->save();
            SyncWorker::markActive();
        } finally {
            $lock->release();
        }
        SyncWorker::kick(false, true);

        return 'queued';
    }

    /** مرحله دریافت JSON برای اجرایی که با queue() در صف قرار گرفته */
    protected function stepFetch(): void
    {
        $fl = Cache::lock('sync.fetch.'.$this->src->id, 900);
        if (! $fl->get()) {
            return;
        }
        try {
            $st = (array) $this->src->state;
            $req = (array) ($st['req'] ?? []);
            $codes = null;
            if (! empty($req['codes'])) {
                $codes = json_decode((string) @file_get_contents($this->src->dir().'/req-codes.json'), true) ?: [];
            }
            $repair = (array) ($req['repair'] ?? []);
            try {
                $r = $this->doStart((bool) ($req['force'] ?? false), $codes, $repair ? 'repair' : (string) ($req['mode'] ?? 'full'));
            } catch (Throwable $e) {
                $this->src->refresh();
                $tries = (int) ($st['fetch_tries'] ?? 0) + 1;
                if ($tries < 6) {
                    // قطعی موقت (اینترنت هاست یا سایت تأمین‌کننده): چند بار با فاصله دوباره تلاش می‌شود
                    $st['fetch_tries'] = $tries;
                    $st['fetch_wait'] = time() + 60 * $tries;
                    $this->src->state = $st;
                    $this->src->addLog('دریافت JSON ناموفق بود (تلاش '.fa($tries).' از ۵)؛ '.fa($tries).' دقیقه دیگر دوباره تلاش می‌شود: '.Str::limit($e->getMessage(), 200), 'warn');
                } else {
                    $this->src->state = ['status' => 'idle', 'last_hash' => $st['last_hash'] ?? null, 'last_total' => $st['last_total'] ?? 0];
                    $this->src->addLog('خطا در دریافت JSON (پس از ۶ تلاش): '.$e->getMessage(), 'error');
                }
                $this->src->save();

                return;
            }
            @unlink($this->src->dir().'/req-codes.json');
            if ($r === 'started') {
                $st = (array) $this->src->state;
                if ($repair) {
                    $st['repair'] = $repair;
                    $fix = $this->preRepair($repair);
                    $this->src->addLog('حالت تعمیر: '.implode('، ', array_filter([
                        ! empty($repair['stock']) ? 'موجودی و کارتن' : null, ! empty($repair['images']) ? 'تصاویر' : null,
                        ! empty($repair['category']) ? 'دسته‌های خالی' : null, ! empty($repair['links']) ? 'پیوندها و تکراری‌ها' : null,
                    ])).($fix ? ' — '.$fix : ''), 'warn');
                }
                if (! empty($req['force_create'])) {
                    $st['force_create'] = true;
                }
                $this->src->state = $st;
                $this->src->save();
            }
        } finally {
            $fl->release();
        }
    }

    public function start(bool $force = false, ?array $codes = null, string $mode = 'full', array $repair = []): string
    {
        // با قفل مشترک «مرحله»: دو شروع هم‌زمان (دو کلیک، کرون و پنل) فایل صف همدیگر را پاک نمی‌کنند
        $lock = Cache::lock('sync.step.'.$this->src->id, 300);
        if (! $lock->block(25)) {
            throw new RuntimeException('یک اجرای دیگر همین حالا در جریان است؛ چند ثانیه دیگر دوباره امتحان کنید.');
        }
        try {
            $r = $this->doStart($force || $repair, $codes, $repair ? 'repair' : $mode);
            if ($r === 'started' && $repair) {
                $st = (array) $this->src->state;
                $st['repair'] = $repair;
                $fix = $this->preRepair($repair);
                $this->src->state = $st;
                $this->src->addLog('حالت تعمیر: '.implode('، ', array_filter([
                    ! empty($repair['stock']) ? 'موجودی و کارتن' : null, ! empty($repair['images']) ? 'تصاویر' : null,
                    ! empty($repair['category']) ? 'دسته‌های خالی' : null, ! empty($repair['links']) ? 'پیوندها و تکراری‌ها' : null,
                ])).($fix ? ' — '.$fix : ''), 'warn');
                $this->src->save();
            }

            return $r;
        } finally {
            $lock->release();
        }
    }

    protected function doStart(bool $force, ?array $codes, string $mode): string
    {
        $this->src->refresh();
        $prev = (array) $this->src->state;
        $feed = $this->fetchToFile();
        $dir = $this->src->dir();
        foreach (array_merge(glob($dir.'/queue-*.ndjson') ?: [], glob($dir.'/codes-*.json') ?: [], glob($dir.'/found-*.txt') ?: [], glob($dir.'/create-*.ndjson') ?: []) as $old) {
            @unlink($old);
        }
        $hash = md5_file($feed).'|'.md5(json_encode($this->o)).($codes !== null ? '|'.md5(json_encode($codes)) : '');
        if (! $force && $mode === 'full' && $hash === ($prev['last_hash'] ?? null)) {
            $this->src->addLog('JSON نسبت به اجرای قبل تغییری نکرده بود.');
            $this->src->last_run_at = now();
            $this->src->state = array_merge($prev, ['status' => 'idle']);
            $this->src->save();

            return 'same';
        }
        $offset = (new JsonStream($feed))->locate(trim((string) $this->o['json_path']));
        $run = Str::lower(Str::random(10));
        if ($codes !== null) {
            file_put_contents($dir.'/codes-'.$run.'.json', json_encode(array_values(array_map('strval', $codes)), JSON_UNESCAPED_UNICODE));
        }
        $this->src->state = [
            'status' => 'running', 'phase' => 'parse', 'mode' => $mode, 'run' => $run,
            'feed' => $feed, 'feed_off' => $offset, 'feed_size' => (int) filesize($feed),
            'file' => $dir.'/queue-'.$run.'.ndjson', 'pos' => 0, 'total' => 0, 'done' => 0, 'img_done' => 0,
            'started' => now()->toIso8601String(), 'hash' => $hash,
            'last_hash' => $prev['last_hash'] ?? null, 'last_total' => $prev['last_total'] ?? 0,
            'not_found' => [], 'codes' => $codes !== null, 'cq_pos' => 0, 'cq_total' => 0, 'cq_done' => 0, 'bytes' => [0, 0],
            'c' => ['created' => 0, 'updated' => 0, 'unchanged' => 0, 'skipped' => 0, 'failed' => 0, 'removed' => 0, 'prices' => 0, 'images' => 0, 'images_failed' => 0],
        ];
        $this->src->last_run_at = now();
        SyncWorker::markActive();
        $this->src->addLog(($mode === 'excel' ? 'اجرای اکسل' : ($mode === 'repair' ? 'تعمیر' : 'همگام‌سازی')).' آغاز شد؛ JSON '.fa(round(filesize($feed) / 1048576, 1)).' مگابایت دریافت شد.');
        $this->src->save();

        return 'started';
    }

    /** مرحله خواندن جریانی JSON و ساخت صف سبک (قابل ادامه از هر نقطه) */
    protected function stepParse(array &$st, float $t0, float $budget): void
    {
        $dir = $this->src->dir();
        $wanted = null;
        if (! empty($st['codes'])) {
            $list = json_decode((string) @file_get_contents($dir.'/codes-'.$st['run'].'.json'), true) ?: [];
            $wanted = array_flip(array_map(fn ($c) => $this->codeKey((string) $c), $list));
        }
        $js = new JsonStream($st['feed']);
        $fh = fopen($st['file'], 'ab');
        $found = $wanted !== null ? fopen($dir.'/found-'.$st['run'].'.txt', 'ab') : null;
        $n = 0;
        $next = $js->each((int) $st['feed_off'], function (array $p) use ($fh, $found, $wanted, &$n) {
            if (! ($r = $this->normalize($p))) {
                return;
            }
            if ($wanted !== null) {
                $k = $this->codeKey($r['c']);
                $kb = $r['b'] !== '' ? $this->codeKey($r['b']) : null;
                if (! isset($wanted[$k]) && ! ($kb && isset($wanted[$kb]))) {
                    return;
                }
                fwrite($found, $k."\n".($kb ? $kb."\n" : ''));
            }
            fwrite($fh, json_encode($r, JSON_UNESCAPED_UNICODE)."\n");
            $n++;
        }, $t0 + $budget);
        fclose($fh);
        if ($found) {
            fclose($found);
        }
        $st['total'] += $n;
        $st['feed_off'] = $next;
        if ($next !== null) {
            return;
        }
        // پایان خواندن
        if ($wanted !== null) {
            $got = array_flip(array_filter(explode("\n", (string) @file_get_contents($dir.'/found-'.$st['run'].'.txt'))));
            $st['not_found'] = array_slice(array_map('strval', array_keys(array_diff_key($wanted, $got))), 0, 500);
            // کدهایی که در JSON نبودند ردیف خالی نسازند
            foreach (array_chunk($st['not_found'], 500) as $part) {
                SyncItem::query()->where('source_id', $this->src->id)->whereNull('title')->whereNull('product_id')->whereIn('code', $part)->delete();
            }
            @unlink($dir.'/found-'.$st['run'].'.txt');
        }
        if (! $st['total']) {
            @unlink($st['file']);
            $st['status'] = 'idle';
            $st['phase'] = '';
            $this->src->addLog($wanted !== null ? 'هیچ‌کدام از کدهای فایل در JSON پیدا نشد.' : 'هیچ کالای دارای کد در JSON نبود. نگاشت فیلد «کد کالا» را بررسی کنید.', 'error');

            return;
        }
        $st['phase'] = 'products';
        $st['pos'] = 0;
        $this->src->addLog('خواندن JSON تمام شد: '.fa($st['total']).' کالا'.($st['not_found'] ? '، '.fa(count($st['not_found'])).' کد اکسل در JSON نبود' : '').'.');
    }

    public function stop(string $why = 'متوقف شد.'): void
    {
        $st = (array) $this->src->state;
        if (($st['status'] ?? '') === 'running') {
            @unlink($st['file'] ?? '');
            @unlink($this->createQueue($st));
            $st['status'] = 'idle';
            $this->src->state = $st;
            $this->src->addLog($why, 'warn');
            $this->src->save();
        }
    }

    /** یک مرحله پردازش با بودجه زمانی (ثانیه) */
    public function step(float $budget = 8): array
    {
        $lock = Cache::lock('sync.step.'.$this->src->id, (int) ceil($budget) + 45);
        if (! $lock->get()) {
            return (array) $this->src->state;
        }
        try {
            @set_time_limit(120);
            $t0 = microtime(true);
            $this->src->refresh();
            $st = (array) $this->src->state;
            if (($st['status'] ?? '') !== 'running') {
                return $st;
            }
            if (($st['phase'] ?? '') === 'fetch') {
                if ((int) ($st['fetch_wait'] ?? 0) > time()) {
                    return $st;
                }
                $this->stepFetch();
                $this->src->refresh();
                $st = (array) $this->src->state;
                if (($st['status'] ?? '') !== 'running' || ($st['phase'] ?? '') === 'fetch') {
                    return $st;
                }
            }
            if ($st['phase'] === 'parse') {
                $this->stepParse($st, $t0, $budget);
                $this->checkpoint($st);
            }
            if ($st['phase'] === 'products' && microtime(true) - $t0 < $budget) {
                // بخشی از زمان هر مرحله صرف تصاویر کالاهای تازه ساخته‌شده می‌شود تا تصاویر تا آخر کار نمانند
                $imgShare = $this->o['img_download'] ? ($this->strictImages() ? 0.2 : 0.35) : 0;
                $this->stepProducts($st, $t0, $budget * (1 - $imgShare));
                if ($imgShare && $st['phase'] === 'products' && microtime(true) - $t0 < $budget) {
                    $this->stepImages($st, $t0, $budget, false);
                    // اگر تصویری در صف نبود، باقی زمان صرف کالاها می‌شود
                    if ($st['phase'] === 'products' && microtime(true) - $t0 < $budget - 1) {
                        $this->stepProducts($st, $t0, $budget);
                    }
                }
            }
            if ($st['phase'] === 'images' && microtime(true) - $t0 < $budget) {
                $this->stepImages($st, $t0, $budget);
            }
            if ($st['phase'] === 'cleanup' && microtime(true) - $t0 < $budget) {
                $this->cleanup($st);
            }
            if ($this->bytes[0]) {
                $b = (array) ($st['bytes'] ?? [0, 0]);
                $st['bytes'] = [(int) ($b[0] ?? 0) + $this->bytes[0], (int) ($b[1] ?? 0) + $this->bytes[1]];
                $this->bytes = [0, 0];
            }
            $this->src->state = $st;
            $this->src->save();
            Cache::forget('home.blocks');

            return $st;
        } finally {
            $lock->release();
        }
    }

    /** ذخیره میانی وضعیت (اگر درخواست وسط کار قطع شود، از همین‌جا ادامه می‌یابد) */
    protected function checkpoint(array $st): void
    {
        $this->src->state = $st;
        $this->src->saveQuietly();
    }

    protected function createQueue(array $st): string
    {
        return $this->src->dir().'/create-'.($st['run'] ?? 'x').'.ndjson';
    }

    protected function stepProducts(array &$st, float $t0, float $budget): void
    {
        if (! is_file($st['file'] ?? '')) {
            $this->src->addLog('فایل صف پیدا نشد؛ اجرا متوقف شد.', 'error');
            $st['status'] = 'idle';

            return;
        }
        $cq = $this->createQueue($st);
        while (microtime(true) - $t0 < $budget) {
            // اول کالاهای جدید صف ساخت (هر کالا همراه تصویرش و به ترتیب)؛ تا تمام نشوند دسته بعد خوانده نمی‌شود
            clearstatcache(true, $cq);
            if (is_file($cq) && (int) ($st['cq_pos'] ?? 0) < filesize($cq)) {
                $this->stepCreate($st, $cq, $t0, $budget);

                continue;
            }
            $fh = fopen($st['file'], 'r');
            fseek($fh, (int) $st['pos']);
            $rows = [];
            while (count($rows) < 150 && ($line = fgets($fh)) !== false) {
                if (is_array($d = json_decode($line, true))) {
                    $rows[] = $d;
                }
            }
            $next = ftell($fh);
            fclose($fh);
            if (! $rows) {
                @unlink($st['file']);
                @unlink($cq);
                $st['phase'] = $this->o['img_download'] ? 'images' : 'cleanup';

                return;
            }
            // محافظ: اگر یک دسته سه بار پشت سر هم کار را از کار انداخت (خطای مرگبار/زمان)، رد می‌شود
            if (($st['guard_pos'] ?? -1) === (int) $st['pos']) {
                $st['guard_n'] = ($st['guard_n'] ?? 1) + 1;
            } else {
                $st['guard_pos'] = (int) $st['pos'];
                $st['guard_n'] = 1;
            }
            if ($st['guard_n'] > 3) {
                $this->src->addLog('دسته‌ای از '.fa(count($rows)).' کالا (کدهای '.implode('، ', array_slice(array_column($rows, 'c'), 0, 5)).'…) سه بار باعث توقف شد و رد شد.', 'error');
                $st['c']['failed'] += count($rows);
            } else {
                $this->checkpoint($st);
                $this->candidates = [];
                DB::transaction(function () use (&$rows, &$st) {
                    $this->processRows($rows, $st);
                });
                if ($this->candidates) {
                    file_put_contents($cq, implode('', array_map(fn ($r) => json_encode($r, JSON_UNESCAPED_UNICODE)."\n", $this->candidates)), FILE_APPEND | LOCK_EX);
                    $st['cq_total'] = ($st['cq_total'] ?? 0) + count($this->candidates);
                    $this->candidates = [];
                }
            }
            $st['pos'] = $next;
            $st['done'] += count($rows);
            $this->checkpoint($st);
        }
    }

    /** ساخت کالاهای صف: تصاویر چند کالای بعدی موازی دریافت می‌شوند ولی هر کالا فقط همراه تصویرش و به ترتیب ساخته می‌شود */
    protected function stepCreate(array &$st, string $cq, float $t0, float $budget): void
    {
        $fh = fopen($cq, 'r');
        fseek($fh, (int) ($st['cq_pos'] ?? 0));
        $rows = [];
        $ends = [];
        while (count($rows) < 16 && ($line = fgets($fh)) !== false) {
            $rows[] = json_decode($line, true);
            $ends[] = ftell($fh);
        }
        fclose($fh);
        // تصویر اصلی ۱۶ کالای بعدی هم‌زمان (۸ اتصال موازی) دریافت می‌شود؛ ساخت کالاها همچنان یکی‌یکی و به ترتیب
        $urls = [];
        foreach ($rows as $r) {
            if (is_array($r) && ($u = $this->imageUrls($r))) {
                $urls[] = $u[0];
            }
        }
        $this->prefetchUrls($urls, 16);
        foreach ($rows as $i => $r) {
            if ($i > 0 && microtime(true) - $t0 >= $budget) {
                break;
            }
            $pos = (int) ($st['cq_pos'] ?? 0);
            if (($st['cq_guard'] ?? -1) === $pos) {
                $st['cq_n'] = ($st['cq_n'] ?? 1) + 1;
            } else {
                $st['cq_guard'] = $pos;
                $st['cq_n'] = 1;
            }
            if ($st['cq_n'] > 3) {
                $this->src->addLog('ساخت کالای '.(is_array($r) ? $r['c'] : '؟').' سه بار باعث توقف شد و رد شد.', 'error');
                $st['c']['failed']++;
            } elseif (is_array($r)) {
                $this->checkpoint($st);
                $this->createQueued($r, $st);
            }
            $st['cq_pos'] = $ends[$i];
            $st['cq_done'] = ($st['cq_done'] ?? 0) + 1;
            $this->checkpoint($st);
        }
        $this->pre = [];
    }

    /** ساخت یک کالای جدید فقط در صورت دریافت موفق تصویر */
    protected function createQueued(array $r, array &$st): bool
    {
        $sid = $this->src->id;
        $item = SyncItem::query()->where('source_id', $sid)->where('code', $r['c'])->first()
            ?? new SyncItem(['source_id' => $sid, 'code' => $r['c'], 'image_tries' => 0]);
        // اگر در این فاصله ساخته شده (اجرای تکراری)، کالای دوم ساخته نمی‌شود
        $m = $this->matchProducts([$r]);
        if ($p = $m[$this->codeKey($r['c'])] ?? ($r['b'] !== '' ? ($m[$this->codeKey($r['b'])] ?? null) : null)) {
            if ($item->product_id !== $p->id) {
                $item->fill(['product_id' => $p->id, 'status' => 'updated', 'reason' => null, 'message' => null, 'run' => $st['run'] ?? $item->run])->save();
            }

            return true;
        }
        try {
            $force = $item->force ?? ($this->isExcelIn($r) ? 'in' : null);
            $pr = $this->price((float) $r['p'], $r['k'], $item->markup_override);
            [$whole, $retail, $in] = $this->stock($r, $force);
            // فقط تصویر اصلی پیش از ساخت؛ بقیه گالری بعداً در پس‌زمینه
            // کالای ناموجود: فقط تصویر اصلی سبک؛ گالری و تصویر کامل وقتی موجود شد (حجم و فشار کمتر روی هاست)
            $light = ! $in && $this->lightOut() && ! $item->full_img; // «ساخت با تصویر کامل» دستی
            $this->small = $light;
            try {
                [$saved, $error, $urls] = $this->obtainImages($r, $item, true);
            } finally {
                $this->small = false;
            }
            $item->images = $urls;
            $item->image_tries = (int) $item->image_tries + 1;
            $gallery = count($urls) > 1;
            $item->run = $st['run'] ?? $item->run;
            if (! $saved) {
                $item->fill(['status' => 'skipped', 'reason' => 'no_image', 'message' => SyncItem::REASONS['no_image'] ?? null,
                    'image_status' => 'failed', 'image_error' => Str::limit($error ?: 'آدرس تصویری نبود', 290)])->save();
                $st['c']['skipped']++;
                $st['c']['images_failed']++;

                return false;
            }
            try {
                DB::transaction(function () use ($r, $pr, $whole, $retail, $in, $saved, $item, $gallery, $light) {
                    $p = $this->createProduct($r, $pr, $whole, $retail, $in, $saved);
                    $item->fill(['product_id' => $p->id, 'status' => 'created', 'reason' => null, 'message' => null, 'price_first' => $pr['final'],
                        'image_status' => $light ? 'later' : ($gallery ? 'gallery' : 'ok'), 'image_error' => null])->save();
                });
            } catch (Throwable $e) {
                foreach ($saved as $rel) { // تصویر بدون کالا باقی نماند
                    @unlink(public_path('uploads/'.$rel));
                    @unlink(\App\Support\Watermark::origPath($rel));
                }
                throw $e;
            }
            $st['c']['created']++;
            $st['c']['images']++;
            $st['img_done'] = ($st['img_done'] ?? 0) + 1;

            return true;
        } catch (Throwable $e) {
            $st['c']['failed']++;
            $item->fill(['status' => 'error', 'reason' => 'error', 'message' => Str::limit($e->getMessage(), 480)])->save();
            report($e);

            return false;
        }
    }

    /* ================= قیمت و موجودی ================= */

    public function price(float $raw, string $category = '', ?float $override = null): array
    {
        $base = $raw;
        if ($this->o['price_unit'] === 'div10') {
            $base /= 10;
        } elseif ($this->o['price_unit'] === 'mul10') {
            $base *= 10;
        }
        $pct = (float) $this->o['markup'];
        $why = 'پیش‌فرض';
        foreach ((array) $this->o['tiers'] as $t) {
            $from = (float) to_int($t['from'] ?? 0);
            $to = (float) to_int($t['to'] ?? 0);
            if ($base >= $from && ($to <= 0 || $base < $to)) {
                $pct = (float) ($t['pct'] ?? $pct);
                $why = 'بازه قیمت';
                break;
            }
        }
        foreach ((array) $this->o['cat_rules'] as $r) {
            $m = trim((string) ($r['match'] ?? ''));
            if ($m !== '' && $category !== '' && str_contains(Search::key($category), Search::key($m))) {
                $pct = (float) ($r['pct'] ?? $pct);
                $why = 'دسته «'.$m.'»';
                break;
            }
        }
        if ($override !== null) {
            $pct = $override;
            $why = 'اختصاصی';
        }
        $final = $this->round($base * (1 + $pct / 100));
        if ($this->o['min_price'] && $final < (int) $this->o['min_price']) {
            $final = 0;
        }
        $retail = (float) $this->o['retail_markup'] > 0 ? $this->round($final * (1 + (float) $this->o['retail_markup'] / 100)) : null;

        return ['base' => $base, 'pct' => $pct, 'why' => $why, 'final' => (int) $final, 'retail' => $retail];
    }

    protected function round(float $v): int
    {
        $step = max(0, (int) $this->o['round_step']);
        if ($step <= 1) {
            return (int) round($v);
        }

        return (int) (match ($this->o['round_mode']) {
            'up' => ceil($v / $step),
            'down' => floor($v / $step),
            default => round($v / $step),
        } * $step);
    }

    /** موجودی: [عمده (عدد)، خرده (عدد)، موجود؟] */
    protected function stock(array $r, ?string $force): array
    {
        $per = max(1, (int) $r['a']);
        $whole = (int) $r['w'];
        $retail = (int) $r['s'];
        if ($this->flagStock()) {
            // ۰/۱: فقط موجود بودن
            $whole = $whole > 0 ? 1 : 0;
            $retail = $retail > 0 ? 1 : 0;
        } elseif ($this->o['wholesale_unit'] === 'carton') {
            $whole *= $per;
        }
        $in = match ($this->o['availability']) {
            'flag' => $r['f'] ?? ($retail > 0 || $whole > 0),
            'flag_and_stock' => ($r['f'] ?? true) && ($retail > 0 || $whole > 0),
            'retail_only' => $retail > 0,
            'strict' => $retail > 0 || ($whole > 0 && $per === 1),
            default => $retail > 0 || $whole > 0,
        };
        if ($force === 'in') {
            $in = true;
        } elseif ($force === 'out') {
            $in = false;
        }

        return [$whole, $retail, $in];
    }

    protected function hasImageFile(Product $p): bool
    {
        $img = (string) $p->image;

        return $img !== '' && (preg_match('#^(https?:)?//#', $img) || is_file(public_path('uploads/'.ltrim($img, '/'))));
    }

    public function flagStock(): bool
    {
        return ($this->o['stock_mode'] ?? 'count') === 'flag';
    }

    /** اعمال موجودی روی کالا (حالت شمارشی یا فقط موجود/ناموجود) */
    protected function applyStock(Product $p, array $r, int $whole, int $retail, bool $in): void
    {
        $per = \App\Models\Warehouse::isLoose((int) $p->warehouse_id) ? ($p->buy_mode === 'carton' ? max(1, (int) $p->per_carton) : 1) : max(1, (int) $r['a']);
        $p->per_carton = $per;
        $p->in_stock = $in;
        $p->carton_enabled = true;
        if ($this->flagStock()) {
            $p->stock = null;              // بدون شمارش
            $p->retail_stock = null;
            $p->retail_in_stock = $retail > 0;
            if ($per > 1 && $this->o['retail_auto'] && $retail > 0) {
                $p->retail_enabled = true;
            }
            // عمده ناموجود ولی خرده موجود: خرید کارتنی بسته، تکی باز
            if ($whole <= 0 && $retail > 0 && $per > 1) {
                $p->carton_enabled = false;
                $p->retail_enabled = true;
                $p->in_stock = true;
            }
        } else {
            $p->stock = $whole;
            if ($per > 1) {
                $p->retail_stock = $retail;
                $p->retail_in_stock = $retail > 0;
                if ($this->o['retail_auto'] && $retail > 0) {
                    $p->retail_enabled = true;
                }
            }
        }
        if ($r['ct'] ?? '') {
            $specs = (array) $p->specs;
            $specs['تعداد در کارتن'] = $r['ct'];
            $p->specs = $specs;
            // واحد فروش (جفت، دست ۶ عددی…) با تغییر «تعداد در کارتن» JSON خودکار عوض می‌شود، مگر مدیر دستی تعیین کرده باشد
            if (! $p->unit_manual) {
                $p->unit_label = Product::unitFromText((string) $r['ct']);
            }
        }
    }

    /* ================= پردازش کالاها ================= */

    protected function codeKey(string $c): string
    {
        $c = strtoupper(trim(en_digits($c)));

        return ctype_digit($c) ? (ltrim($c, '0') ?: '0') : $c;
    }

    protected function processRows(array $rows, array &$st): void
    {
        $sid = $this->src->id;
        $codes = array_column($rows, 'c');
        $items = SyncItem::query()->where('source_id', $sid)->whereIn('code', $codes)->get()->keyBy('code');
        $products = $this->matchProducts($rows);
        $listed = $this->o['only_listed'] ? array_flip((array) $this->src->opt('listed_codes', [])) : null;
        $bulk = [];

        foreach ($rows as $r) {
            $item = $items->get($r['c']) ?? new SyncItem(['source_id' => $sid, 'code' => $r['c'], 'image_tries' => 0]);
            if (($r['wo'] ?? '') === '' && ($r['wr'] ?? '') === '') {
                $st['c']['wh_none'] = ($st['c']['wh_none'] ?? 0) + 1;
            }
            try {
                $pr = $this->price((float) $r['p'], $r['k'], $item->markup_override);
                $excel = $this->isExcelIn($r);
                $force = $item->force ?? ($excel ? 'in' : null);
                [$whole, $retail, $in] = $this->stock($r, $force);
                $imgs = $this->imageUrls($r);
                $hash = md5(json_encode([$r, $pr['final'], $pr['retail'], $in, $force, $item->markup_override]));
                $item->fill([
                    'title' => Str::limit($r['t'], 250, ''), 'category' => Str::limit($r['k'], 250, ''), 'raw_price' => $r['p'],
                    'price' => $pr['final'], 'retail_price' => $pr['retail'], 'markup' => $pr['pct'],
                    'stock_retail' => $retail, 'stock_wholesale' => $whole, 'per_carton' => $r['a'], 'images' => $imgs,
                    'extra' => array_filter(['barcode' => $r['b'], 'compare' => $r['cp'] ?: null, 'r' => $r]), 'in_feed' => true, 'run' => $st['run'],
                ]);
                /** @var Product|null $p */
                $p = $products[$this->codeKey($r['c'])] ?? ($r['b'] !== '' ? ($products[$this->codeKey($r['b'])] ?? null) : null);

                if ($p) {
                    $item->product_id = $p->id;
                    if ($item->hash === $hash && $item->status !== 'error' && $p->sync_code && empty($st['repair'])) {
                        $item->status = 'unchanged';
                        $st['c']['unchanged']++;
                        // شماره انبار حتی برای ردیف بدون تغییر هم بررسی می‌شود (کالاهای ساخته‌شده پیش از دریافت شماره انبار)
                        $this->applyWarehouses($p, $r);
                        \App\Support\LegacyUrls::apply($p, $r['u'] ?? null);
                        if ($p->isDirty(['warehouse_id', 'retail_warehouse_id', 'legacy_id'])) {
                            $p->saveQuietly();
                            $st['c']['wh'] = ($st['c']['wh'] ?? 0) + 1;
                        }
                    } else {
                        $changed = $this->updateProduct($p, $r, $pr, $whole, $retail, $in, $item, $st);
                        $item->status = $changed ? 'updated' : 'unchanged';
                        $st['c'][$changed ? 'updated' : 'unchanged']++;
                    }
                    $item->reason = null;
                    $item->message = null;
                } else {
                    $reason = match (true) {
                        $item->reason === 'deleted' && empty($st['force_create']) => 'deleted',
                        $listed !== null && ! isset($listed[$this->codeKey($r['c'])]) && ! $excel && empty($st['force_create']) => 'not_listed',
                        $this->o['create_scope'] === 'none' && ($st['mode'] ?? '') !== 'excel' && ! $excel && empty($st['force_create']) => 'scope_none',
                        $r['t'] === '' => 'no_title',
                        $pr['final'] <= 0 => 'no_price',
                        ! $in && $this->o['create_scope'] === 'stock' && $force !== 'in' && empty($st['force_create']) => 'no_stock',
                        $this->strictImages() && ! $imgs && ($this->o['img_found']['mode'] ?? '') !== 'page' => 'no_image',
                        $this->strictImages() && $item->reason === 'no_image' && $item->image_tries >= 3 && empty($st['repair']['images']) && empty($st['force_create']) => 'no_image',
                        default => null,
                    };
                    if ($reason) {
                        $item->status = 'skipped';
                        $item->reason = $reason;
                        $item->message = SyncItem::REASONS[$reason] ?? null;
                        $st['c']['skipped']++;
                    } elseif ($this->strictImages()) {
                        // ساخت در صف «همراه تصویر» (بلافاصله بعد از همین دسته)
                        if ($item->reason === 'no_image' && (! empty($st['repair']['images']) || ! empty($st['force_create']))) {
                            $item->image_tries = 0;
                        }
                        $this->candidates[] = $r;
                        $item->status = 'queued';
                        $item->reason = null;
                        $item->message = null;
                    } else {
                        $p = $this->createProduct($r, $pr, $whole, $retail, $in);
                        $item->product_id = $p->id;
                        $item->status = 'created';
                        $item->reason = null;
                        $item->message = null;
                        $item->price_first = $pr['final'];
                        $st['c']['created']++;
                    }
                }
                if (! empty($st['repair']['images']) && $item->product_id && $imgs && $item->image_status === 'ok' && $p && ! $this->hasImageFile($p)) {
                    $item->image_status = 'pending'; // فایل تصویر روی هاست نیست
                    $item->image_tries = 0;
                }
                if (! empty($st['repair']['images']) && in_array($item->image_status, ['failed', 'none'], true) && $imgs) {
                    $item->image_tries = 0;
                    $item->image_status = 'pending';
                }
                // کالای ناموجودی که فقط تصویر سبک داشت و حالا موجود شد (یا تنظیم «همه تصاویر» انتخاب شد) ← تصویر کامل و گالری
                if ($item->image_status === 'later' && ($in || ! $this->lightOut() || $item->full_img) && $item->product_id && $this->o['img_download'] && $imgs) {
                    $item->image_status = 'pending';
                    $item->image_tries = 0;
                }
                if ($item->product_id && $this->o['img_download'] && $imgs && ! in_array($item->image_status, ['ok', 'gallery', 'later'], true) && $item->image_tries < 3) {
                    $item->image_status = 'pending';
                } elseif (! $imgs) {
                    $item->image_status = $item->image_status === 'ok' ? 'ok' : 'none';
                }
                $item->hash = $hash;
                // ردیف‌های بدون تغییر یک‌جا به‌روز می‌شوند (به‌جای هزاران UPDATE جدا)
                if ($item->exists && ! array_diff(array_keys($item->getDirty()), ['run', 'in_feed', 'updated_at'])) {
                    $bulk[] = $item->id;
                } else {
                    $item->save();
                }
            } catch (Throwable $e) {
                $st['c']['failed']++;
                $item->status = 'error';
                $item->reason = 'error';
                $item->message = Str::limit($e->getMessage(), 480);
                $item->run = $st['run'];
                $item->save();
                report($e);
            }
        }
        foreach (array_chunk($bulk, 500) as $ids) {
            SyncItem::query()->whereIn('id', $ids)->update(['run' => $st['run'], 'in_feed' => true, 'updated_at' => now()]);
        }
    }

    /**
     * پردازش دوباره چند ردیف ذخیره‌شده (بدون دانلود JSON) — برای ساخت دستی، اصلاح موجودی یا درصد اختصاصی
     *
     * @param  iterable<SyncItem>  $items
     */
    public function reprocess(iterable $items, bool $forceCreate = false, bool $images = true): array
    {
        $rows = [];
        foreach ($items as $it) {
            if (! empty($it->extra['r'])) {
                $rows[] = $it->extra['r'];
            }
        }
        $st = ['run' => (string) ($this->src->state['run'] ?? 'manual'), 'mode' => 'manual', 'force_create' => $forceCreate,
            'c' => ['created' => 0, 'updated' => 0, 'unchanged' => 0, 'skipped' => 0, 'failed' => 0, 'removed' => 0, 'prices' => 0, 'images' => 0, 'images_failed' => 0]];
        foreach (array_chunk($rows, 60) as $chunk) {
            // هش پاک می‌شود تا حتماً دوباره اعمال شود
            SyncItem::query()->where('source_id', $this->src->id)->whereIn('code', array_column($chunk, 'c'))->update(['hash' => null]);
            $this->candidates = [];
            $this->processRows($chunk, $st);
            // ساخت فوری کالاهای جدید همراه تصویر
            foreach (array_chunk($this->candidates, 8) as $part) {
                $urls = [];
                foreach ($part as $r) {
                    $urls = array_merge($urls, array_slice($this->imageUrls($r), 0, 1));
                }
                $this->prefetchUrls($urls, 16);
                foreach ($part as $r) {
                    $this->createQueued($r, $st);
                }
                $this->pre = [];
            }
            $this->candidates = [];
        }
        if ($images && $this->o['img_download']) {
            $t0 = microtime(true);
            foreach (SyncItem::query()->where('source_id', $this->src->id)->whereIn('code', array_column($rows, 'c'))->where('image_status', 'pending')->get() as $it) {
                if (microtime(true) - $t0 > 25) {
                    break;
                }
                $this->downloadFor($it, $st);
            }
        }
        Cache::forget('home.blocks');

        return $st['c'] + ['rows' => count($rows)];
    }

    /** @return array<string, Product> کلید = کد نرمال‌شده */
    protected function matchProducts(array $rows): array
    {
        $codes = [];
        foreach ($rows as $r) {
            $codes[] = $r['c'];
            if ($r['b'] !== '') {
                $codes[] = $r['b'];
            }
        }
        $by = $this->o['match_by'];
        $q = Product::query()->where(function ($w) use ($codes, $by) {
            $w->where(fn ($x) => $x->where('sync_source_id', $this->src->id)->whereIn('sync_code', $codes));
            if (in_array($by, ['sku', 'both'], true)) {
                $w->orWhereIn('sku', $codes);
            }
            if (in_array($by, ['barcode', 'both'], true)) {
                $w->orWhereIn('barcode', $codes);
            }
        });
        $out = [];
        foreach ($q->get() as $p) {
            foreach (array_filter([$p->sync_source_id === $this->src->id ? $p->sync_code : null, $p->sku, $p->barcode]) as $c) {
                $out[$this->codeKey((string) $c)] ??= $p;
            }
        }

        return $out;
    }

    protected function createProduct(array $r, array $pr, int $whole, int $retail, bool $in, array $images = []): Product
    {
        $p = new Product([
            'name' => $r['t'],
            'sku' => $this->o['match_by'] === 'barcode' ? null : $r['c'],
            'barcode' => $r['b'] !== '' ? $r['b'] : ($this->o['match_by'] === 'barcode' ? $r['c'] : null),
            'price' => $pr['final'],
            'retail_enabled' => false,
            'retail_price' => $pr['retail'],
            'is_active' => (bool) $this->o['new_active'],
            'category_id' => $this->categoryId($r['k']),
            'description' => $r['d'] !== '' ? $r['d'] : null,
            'sync_source_id' => $this->src->id,
            'sync_code' => $r['c'],
        ]);
        $this->applyStock($p, $r, $whole, $retail, $in);
        $this->applyWarehouses($p, $r);
        \App\Support\LegacyUrls::apply($p, $r['u'] ?? null); // لینک هم‌شکل سایت قبلی
        if ($r['cp'] > $r['p'] && $r['cp'] > 0) {
            $p->compare_price = $this->price((float) $r['cp'], $r['k'])['final'];
        }
        if ($p->barcode && Product::query()->where('barcode', $p->barcode)->exists()) {
            $p->barcode = null;
        }
        if ($images) {
            $p->image = $images[0];
            $p->gallery = array_slice($images, 1);
        }
        $p->save();

        return $p;
    }

    protected function updateProduct(Product $p, array $r, array $pr, int $whole, int $retail, bool $in, SyncItem $item, array &$st): bool
    {
        $old = (int) $p->price;
        $p->sync_source_id ??= $this->src->id;
        $p->sync_code ??= $r['c'];
        \App\Support\LegacyUrls::apply($p, $r['u'] ?? null);
        if ($this->o['update_price'] && ! $p->sync_locked && $pr['final'] > 0) {
            $p->price = $pr['final'];
            if ($pr['retail']) {
                $p->retail_price = $pr['retail'];
            }
        }
        $repair = (array) ($st['repair'] ?? []);
        if ($this->o['update_stock'] || ! empty($repair['stock'])) {
            $this->applyStock($p, $r, $whole, $retail, $in);
        }
        $this->applyWarehouses($p, $r);
        if (! empty($repair['category']) && ! $p->category_id && $r['k'] !== '' && ($cid = $this->categoryId($r['k']))) {
            $p->category_id = $cid;
        }
        if ($this->o['update_name'] && ! $p->sync_locked && $r['t'] !== '') {
            $p->name = $r['t'];
        }
        if ($this->o['update_category'] && $r['k'] !== '' && ($cid = $this->categoryId($r['k']))) {
            $p->category_id = $cid;
        }
        $dirty = $p->isDirty();
        if ($dirty) {
            $p->save();
        }
        if ($old !== (int) $p->price) {
            $item->price_prev = $old;
            $item->price_changed_at = now();
            $item->price_first ??= $old;
            $st['c']['prices']++;
            SyncPriceChange::query()->create([
                'source_id' => $this->src->id, 'code' => $r['c'], 'product_id' => $p->id, 'title' => Str::limit($p->name, 250, ''),
                'raw_old' => $item->getOriginal('raw_price'), 'raw_new' => $r['p'], 'old_price' => $old, 'new_price' => $p->price,
            ]);
        }

        return $dirty;
    }

    /** دسته از مسیر «ظروف / جاپیازی» (ساخت خودکار زیردسته‌ها) */
    public function categoryId(string $path): ?int
    {
        $path = trim($path);
        $root = trim((string) $this->o['category_root']);
        if ($path === '' && $root === '') {
            return null;
        }
        $key = $root.'>'.$path;
        if (array_key_exists($key, $this->catCache)) {
            return $this->catCache[$key];
        }
        $sep = (string) ($this->o['cat_separator'] ?: '/');
        $parts = array_values(array_filter(array_map('trim', explode($sep, $path)), 'strlen'));
        if ($root !== '') {
            array_unshift($parts, $root);
        }
        $parent = null;
        foreach ($parts as $name) {
            $c = Category::query()->where('name', $name)->where('parent_id', $parent)->first()
                ?? Category::query()->create(['name' => $name, 'parent_id' => $parent]);
            $parent = $c->id;
        }

        return $this->catCache[$key] = $parent;
    }

    /* ================= تصاویر ================= */

    public function imageUrls(array $r): array
    {
        $urls = [];
        foreach (array_merge([$r['i']], (array) $r['g']) as $v) {
            if (is_array($v)) {
                $v = $v['img'] ?? $v['url'] ?? $v['src'] ?? $v['image'] ?? '';
            }
            if (($u = $this->imageUrl((string) $v)) && ! in_array($u, $urls, true)) {
                $urls[] = $u;
            }
        }

        return array_slice($urls, 0, max(1, (int) $this->o['img_max']));
    }

    public function imageUrl(string $name, bool $useFound = true): string
    {
        $name = trim(str_replace('\\', '/', $name));
        if ($name === '' || $name === 'null') {
            return '';
        }
        $found = $useFound ? (array) ($this->o['img_found'] ?? []) : [];
        if (! empty($found['base']) && ! preg_match('~^(https?:)?//~i', $name)) {
            $name = preg_replace('/\?.*$/', '', $name);
            if (($found['from'] ?? '') !== '') {
                $name = preg_replace('~(^|/)'.preg_quote($found['from'], '~').'~', '$1'.($found['to'] ?? ''), $name, 1);
            }

            return $this->encodeUrl(rtrim($found['base'], '/').'/'.ltrim($name, '/'));
        }
        $from = (string) $this->o['img_from'];
        if ($from !== '') {
            $to = (string) $this->o['img_to'];
            $name = preg_replace_callback('~(^|/)'.preg_quote($from, '~').'~', fn ($m) => $m[1].$to, $name, 1);
        }
        if (! preg_match('~^https?://~i', $name)) {
            if (str_starts_with($name, '//')) {
                $name = 'https:'.$name;
            } else {
                $name = rtrim((string) $this->o['img_base'], '/').'/'.ltrim($name, '/');
            }
        }

        return $this->encodeUrl($name);
    }

    /** کدگذاری بخش‌های مسیر (فاصله و حروف فارسی) بدون خراب کردن آدرس‌های کدشده */
    public function encodeUrl(string $url): string
    {
        $p = parse_url($url);
        if (! $p || empty($p['host'])) {
            return $url;
        }
        $path = implode('/', array_map(fn ($seg) => rawurlencode(rawurldecode($seg)), explode('/', $p['path'] ?? '')));

        return ($p['scheme'] ?? 'https').'://'.$p['host'].(isset($p['port']) ? ':'.$p['port'] : '').$path.(isset($p['query']) ? '?'.$p['query'] : '');
    }

    /**
     * دانلود یک تصویر؛ خروجی: [مسیر نسبی در uploads یا null، توضیح خطا]
     *
     * @return array{0: ?string, 1: string}
     */
    /** دانلود هم‌زمان اولین تصویر چند کالا (تا ۸ اتصال موازی) */
    protected function prefetch($items): void
    {
        if (($this->o['img_found']['mode'] ?? '') === 'page') {
            return;
        }
        $urls = [];
        foreach ($items as $it) {
            $r = (array) ($it->extra['r'] ?? []);
            $list = $r ? $this->imageUrls($r) : (array) $it->images;
            foreach (($it->image_status === 'gallery' ? array_slice($list, 1, 3) : array_slice($list, 0, 2)) as $u) {
                $urls[$u] = true;
            }
        }
        $this->prefetchUrls(array_keys($urls), 24);
    }

    /** دانلود موازی چند تصویر (۸ اتصال هم‌زمان) در حافظه */
    protected function prefetchUrls(array $urls, int $max = 16): void
    {
        if (($this->o['img_found']['mode'] ?? '') === 'page') {
            return;
        }
        $urls = array_slice(array_values(array_unique(array_filter($urls))), 0, $max);
        if (count($urls) < 2) {
            return;
        }
        $headers = ['User-Agent' => self::UA, 'Accept' => 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8', 'Referer' => rtrim((string) $this->o['img_base'], '/').'/'];
        try {
            $resps = Http::pool(function ($pool) use ($urls, $headers) {
                foreach ($urls as $u) {
                    $pool->as($u)->timeout(20)->connectTimeout(8)->withoutVerifying()->withHeaders($headers)->get($u);
                }
            }, 8);
            foreach ($resps as $u => $r) {
                if ($r instanceof \Illuminate\Http\Client\Response && $r->successful()) {
                    $this->pre[$u] = $r->body();
                }
            }
        } catch (Throwable) {
            // در صورت خطا، دانلود عادی یکی‌یکی انجام می‌شود
        }
    }

    /** فشرده‌سازی (بدون افت کیفیت دیداری) و ذخیره؛ خروجی مسیر نسبی یا null */
    protected function saveImage(string $u, string $name, string $body): ?string
    {
        $ext = match (@getimagesizefromstring($body)[2] ?? 0) {
            IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif', default => 'jpg',
        };
        if ($this->o['img_compress'] ?? true) {
            $side = (int) ($this->o['img_max_side'] ?? 1600);
            $qual = (int) ($this->o['img_quality'] ?? 88);
            if ($this->small) {
                [$side, $qual] = [min($side, 800), min($qual, 80)];
            }
            $c = ImageCompressor::compress($body, $side, $qual);
            $this->bytes[0] += $c['before'];
            $this->bytes[1] += $c['after'];
            $body = $c['body'];
            $ext = $c['ext'];
        }
        $rel = 'products/sync/'.$this->src->id.'/'.preg_replace('/[^A-Za-z0-9_\-]/', '', $name).'-'.substr(md5($u), 0, 8).'.'.$ext;
        $abs = public_path('uploads/'.$rel);
        if (! is_dir(dirname($abs))) {
            @mkdir(dirname($abs), 0755, true);
        }
        // نسخه اصلی جدا نگه داشته و نسخه نهایی (با نشان فروشگاه در صورت فعال بودن) ساخته می‌شود
        if (\App\Support\Watermark::store($rel, $body) || @file_put_contents($abs, $body) !== false) {
            // تصویر کوچک فهرست‌ها همین حالا ساخته می‌شود (اولین بازدید صفحه‌ها کند نمی‌شود)
            if (str_ends_with($name, '-0')) {
                \App\Http\Controllers\ThumbController::warm($rel);
            }

            return $rel;
        }

        return null;
    }

    public function fetchImage(string $url, string $name): array
    {
        $tries = [$url];
        if (str_starts_with($url, 'https://')) {
            $tries[] = 'http://'.substr($url, 8);
        }
        $err = '';
        foreach ($tries as $u) {
            if (isset($this->pre[$u])) {
                $body = $this->pre[$u];
                unset($this->pre[$u]);
                if (@getimagesizefromstring($body) && ($rel = $this->saveImage($u, $name, $body))) {
                    return [$rel, ''];
                }
            }
            try {
                $resp = Http::timeout(25)->connectTimeout(8)->withoutVerifying()->withHeaders([
                    'User-Agent' => self::UA,
                    'Accept' => 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
                    'Referer' => rtrim((string) $this->o['img_base'], '/').'/',
                ])->get($u);
            } catch (Throwable $e) {
                $err = 'اتصال ناموفق: '.Str::limit($e->getMessage(), 120);

                continue;
            }
            if (! $resp->successful()) {
                $err = 'سرور تصویر کد '.$resp->status().' داد'.($resp->status() === 404 ? ' (فایل وجود ندارد؛ آدرس پایه یا جایگزینی نام را بررسی کنید)' : ($resp->status() === 403 ? ' (دسترسی مسدود است)' : ''));

                continue;
            }
            $body = $resp->body();
            $info = @getimagesizefromstring($body);
            if (! $info) {
                $err = 'پاسخ تصویر نبود ('.Str::limit((string) $resp->header('Content-Type'), 40).'، '.fa(strlen($body)).' بایت)';

                continue;
            }
            if (! ($rel = $this->saveImage($u, $name, $body))) {
                return [null, 'ذخیره فایل در پوشه uploads ممکن نشد (دسترسی پوشه)'];
            }

            return [$rel, ''];
        }

        return [null, $err ?: 'نامشخص'];
    }

    protected function stepImages(array &$st, float $t0, float $budget, bool $final = true): void
    {
        $q = SyncItem::query()->where('source_id', $this->src->id)->whereIn('image_status', ['pending', 'gallery'])->whereNotNull('product_id');
        $batch = collect();
        while (microtime(true) - $t0 < $budget) {
            if ($batch->isEmpty()) {
                $batch = (clone $q)->orderBy('id')->limit(8)->get();
                $this->prefetch($batch);
            }
            $item = $batch->shift();
            if (! $item) {
                if ($final) {
                    $st['phase'] = 'cleanup';
                }

                return;
            }
            $this->downloadFor($item, $st);
        }
    }

    public function downloadFor(SyncItem $item, ?array &$st = null): bool
    {
        $p = Product::query()->find($item->product_id);
        if (! $p) {
            $item->update(['image_status' => 'none']);

            return false;
        }
        if ($item->image_status === 'gallery') {
            // تصویر اصلی هنگام ساخت گرفته شده؛ فقط بقیه گالری
            $urls = array_slice(array_values((array) $item->images), 1);
            [$saved, $error] = $this->fetchAll($urls, $item->code.'g');
            if ($saved) {
                $p->gallery = array_values(array_unique(array_merge((array) $p->gallery, $saved)));
                $p->saveQuietly();
            }
            $item->fill(['image_status' => 'ok', 'image_error' => $saved || ! $urls ? null : Str::limit('گالری: '.$error, 290)])->save();
            if ($st !== null && $saved) {
                $st['img_done'] = ($st['img_done'] ?? 0) + 1;
            }

            return true;
        }
        if ($p->image && ! str_starts_with((string) $p->image, 'products/sync/') && ! $this->o['update_images']) {
            $item->update(['image_status' => 'ok']);

            return true;
        }
        $light = $this->lightOut() && ! $item->full_img && ! Product::query()->whereKey($p->id)->available()->exists();
        $this->small = $light;
        try {
            [$saved, $error, $urls] = $this->obtainImages((array) ($item->extra['r'] ?? []), $item, $light);
        } finally {
            $this->small = false;
        }
        $item->images = $urls;
        if ($saved) {
            if (! $p->image || str_starts_with((string) $p->image, 'products/sync/') || $this->o['update_images']) {
                $old = array_filter(array_merge([(string) $p->image], (array) $p->gallery), fn ($f) => str_starts_with((string) $f, 'products/sync/'));
                $p->image = $saved[0];
                $p->gallery = array_slice($saved, 1);
                $p->saveQuietly();
                // تصویر سبکِ قبلی (زمان ناموجودی) پاک شود تا فایل اضافه روی هاست نماند
                foreach (array_diff($old, $saved) as $f) {
                    if (! Product::query()->where('image', $f)->exists()) {
                        @unlink(public_path('uploads/'.$f));
                        @unlink(\App\Support\Watermark::origPath($f));
                    }
                }
            }
            $item->fill(['image_status' => $light ? 'later' : 'ok', 'image_error' => null, 'image_tries' => $item->image_tries + 1])->save();
            if ($st !== null) {
                $st['c']['images']++;
                $st['img_done'] = ($st['img_done'] ?? 0) + 1;
            }

            return true;
        }
        // ناموفق: در اجرای بعدی (تا ۳ بار) دوباره تلاش می‌شود
        $item->fill(['image_status' => 'failed', 'image_error' => Str::limit($error ?: 'آدرس تصویری نبود', 290), 'image_tries' => $item->image_tries + 1])->save();
        if ($st !== null) {
            $st['c']['images_failed']++;
        }

        return false;
    }

    /**
     * آدرس‌های تصویر یک کالا و دانلود آن‌ها (با کشف خودکار الگوی آدرس در صورت نیاز)
     *
     * @return array{0: array, 1: string, 2: array}
     */
    protected function obtainImages(array $r, SyncItem $item, bool $mainOnly = false): array
    {
        $page = ($this->o['img_found']['mode'] ?? '') === 'page';
        $urls = $page ? $this->pageImages($r) : ($r ? $this->imageUrls($r) : (array) $item->images);
        [$saved, $error] = $mainOnly ? $this->fetchMain($urls, $item->code) : $this->fetchAll($urls, $item->code);

        // آدرس‌ها جواب ندادند: الگوی درست را خودکار پیدا کن (حداکثر ۳ بار در ساعت؛ هر کشف ده‌ها درخواست است)
        $dk = 'sync.discover.'.$this->src->id;
        if (! $saved && $this->o['img_auto'] && empty($this->o['img_found']) && $r && (int) Cache::get($dk, 0) < 3) {
            Cache::put($dk, (int) Cache::get($dk, 0) + 1, 3600);
            if ($found = $this->discover($r)) {
                $o = (array) $this->src->options;
                $o['img_found'] = $found;
                $this->src->options = $o;
                $this->src->addLog('الگوی آدرس تصاویر خودکار پیدا شد: '.(($found['mode'] ?? '') === 'page' ? 'از صفحه محصول' : $found['base'].($found['from'] !== '' ? ' («'.$found['from'].'» ← «'.$found['to'].'»)' : '')), 'ok');
                $this->src->saveQuietly();
                $this->o['img_found'] = $found;
                $urls = ($found['mode'] ?? '') === 'page' ? $this->pageImages($r) : $this->imageUrls($r);
                [$saved, $error] = $mainOnly ? $this->fetchMain($urls, $item->code) : $this->fetchAll($urls, $item->code);
            }
        }

        return [$saved, $error, $urls];
    }

    /**
     * تصویر اصلی یک ردیف فید برای نمایش (مثلاً در اپ خرید) با همان قواعد دریافت همگام‌سازی
     * (آدرس پایه، جایگزینی نام، حالت «از صفحه محصول»، Referer). خروجی: مسیر نسبی فایل ذخیره‌شده در uploads یا null
     */
    public function mainImageFor(SyncItem $item): ?string
    {
        $r = (array) (($item->extra['r'] ?? null) ?: []);
        [$saved] = $this->obtainImages($r, $item, true);

        return $saved[0] ?? null;
    }

    /** اولین تصویر سالم (حداکثر ۳ آدرس امتحان می‌شود) */
    protected function fetchMain(array $urls, string $code): array
    {
        $error = '';
        foreach (array_slice(array_values($urls), 0, 3) as $i => $u) {
            [$rel, $err] = $this->fetchImage($u, preg_replace('/[^A-Za-z0-9]/', '', $code).'-'.$i);
            if ($rel) {
                return [[$rel], ''];
            }
            $error = $error ?: $err.' — '.$u;
        }

        return [[], $error];
    }

    /** @return array{0: array, 1: string} */
    protected function fetchAll(array $urls, string $code): array
    {
        $saved = [];
        $error = '';
        foreach (array_values($urls) as $i => $u) {
            [$rel, $err] = $this->fetchImage($u, preg_replace('/[^A-Za-z0-9]/', '', $code).'-'.$i);
            if ($rel) {
                $saved[] = $rel;
            } elseif (! $error) {
                $error = $err.' — '.$u;
            }
        }

        return [$saved, $error];
    }

    /** ریشه سایت تأمین‌کننده */
    protected function origin(): string
    {
        foreach ([(string) $this->o['site_base'], (string) $this->o['img_base'], (string) $this->src->url] as $u) {
            $p = parse_url($u);
            if (! empty($p['host'])) {
                return ($p['scheme'] ?? 'https').'://'.$p['host'].(isset($p['port']) ? ':'.$p['port'] : '');
            }
        }

        return '';
    }

    /** آزمایش سریع وجود تصویر */
    protected function isImage(string $url): bool
    {
        try {
            $resp = Http::timeout(10)->withoutVerifying()->withHeaders(['User-Agent' => self::UA, 'Accept' => 'image/*,*/*;q=0.8', 'Referer' => $this->origin().'/'])->get($url);

            return $resp->successful() && @getimagesizefromstring($resp->body()) !== false;
        } catch (Throwable) {
            return false;
        }
    }

    /**
     * کشف الگوی آدرس تصاویر: پوشه‌های رایج × نسخه بزرگ/کوچک، و در نهایت صفحه محصول.
     *
     * @return array{base?: string, from?: string, to?: string, mode?: string}|null
     */
    public function discover(array $r): ?array
    {
        $raw = is_array($r['i'] ?? null) ? ($r['i']['img'] ?? $r['i']['url'] ?? '') : (string) ($r['i'] ?? '');
        if ($raw === '' && ! empty($r['g'])) {
            $g = $r['g'][0];
            $raw = is_array($g) ? ($g['img'] ?? $g['url'] ?? '') : (string) $g;
        }
        $name = preg_replace('/\?.*$/', '', trim($raw));
        $origin = $this->origin();
        if ($name !== '' && $origin !== '' && ! preg_match('~^(https?:)?//~i', $name)) {
            $file = basename($name);
            $dir = trim(dirname($name), './');
            $bases = array_values(array_unique(array_filter([
                rtrim((string) $this->o['img_base'], '/'), $origin, $origin.'/upload', $origin.'/uploads', $origin.'/images', $origin.'/image', $origin.'/img',
                $origin.'/upload/product', $origin.'/upload/products', $origin.'/uploads/products', $origin.'/files', $origin.'/media', $origin.'/Content/upload',
            ])));
            // نسخه بزرگ‌تر اول: sm123.jpg → lg123.jpg / 123.jpg / …
            $variants = [['', '']];
            if (preg_match('/^(sm|small|thumb|th|s)[_\-]?(.+)$/i', $file, $m)) {
                $pre = $m[1];
                $variants = [[$pre, 'lg'], [$pre, 'big'], [$pre, ''], [$pre, 'md'], [$pre, 'org'], ['', '']];
            }
            $tries = 0;
            foreach ($variants as [$from, $to]) {
                foreach ($bases as $base) {
                    if (++$tries > 70) {
                        break 2;
                    }
                    $f = $from !== '' ? preg_replace('/^'.preg_quote($from, '/').'/', $to, $file, 1) : $file;
                    $url = $this->encodeUrl($base.'/'.($dir !== '' ? $dir.'/' : '').$f);
                    if ($this->isImage($url)) {
                        return ['base' => $base.($dir !== '' ? '/'.$dir : ''), 'from' => $from, 'to' => $to];
                    }
                }
            }
        }
        if (! empty($r['u']) && $this->pageImages($r)) {
            return ['mode' => 'page'];
        }

        return null;
    }

    /** تصاویر از صفحه محصول تأمین‌کننده (og:image و تصاویر گالری) */
    public function pageImages(array $r): array
    {
        $u = trim((string) ($r['u'] ?? ''));
        if ($u === '') {
            return [];
        }
        $url = preg_match('~^https?://~i', $u) ? $u : $this->origin().'/'.ltrim($u, '/');
        try {
            $html = Http::timeout(20)->withoutVerifying()->withHeaders(['User-Agent' => self::UA, 'Accept' => 'text/html'])->get($this->encodeUrl($url))->body();
        } catch (Throwable) {
            return [];
        }
        $out = [];
        if (preg_match_all('~<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)~i', $html, $m)) {
            $out = array_merge($out, $m[1]);
        }
        $file = preg_replace('/\?.*$/', '', basename((string) (is_array($r['i'] ?? null) ? '' : ($r['i'] ?? ''))));
        $core = preg_replace('/^(sm|small|thumb|th|s)[_\-]?/i', '', pathinfo($file, PATHINFO_FILENAME));
        if ($core !== '' && preg_match_all('~(?:src|href|data-src|data-zoom-image)=["\']([^"\']*'.preg_quote($core, '~').'[^"\']*)~i', $html, $m2)) {
            $out = array_merge($out, $m2[1]);
        }
        $abs = [];
        foreach ($out as $x) {
            $x = html_entity_decode($x);
            $x = preg_match('~^https?://~i', $x) ? $x : (str_starts_with($x, '//') ? 'https:'.$x : $this->origin().'/'.ltrim($x, '/'));
            $abs[] = $this->encodeUrl($x);
        }
        // نسخه‌های بزرگ‌تر جلوتر
        usort($abs, fn ($a, $b) => (int) preg_match('~/sm|thumb~i', $a) <=> (int) preg_match('~/sm|thumb~i', $b));

        return array_slice(array_values(array_unique($abs)), 0, max(1, (int) $this->o['img_max']));
    }

    /* ================= پایان ================= */

    protected function cleanup(array &$st): void
    {
        $removed = 0;
        if (($st['mode'] ?? 'full') === 'full') {
            $stale = SyncItem::query()->where('source_id', $this->src->id)->where('in_feed', true)->where(fn ($w) => $w->whereNull('run')->orWhere('run', '!=', $st['run']));
            $count = (clone $stale)->count();
            $total = SyncItem::query()->where('source_id', $this->src->id)->count();
            $safe = ! ($st['last_total'] && $st['total'] < $st['last_total'] * 0.5);
            if ($count && $this->o['missing_policy'] !== 'none' && $safe) {
                $ids = (clone $stale)->whereNotNull('product_id')->pluck('product_id')->all();
                $upd = $this->o['missing_policy'] === 'hide' ? ['is_active' => false] : ['in_stock' => false];
                foreach (array_chunk($ids, 500) as $part) {
                    $removed += Product::query()->whereIn('id', $part)->update($upd + ['updated_at' => now()]);
                }
            } elseif ($count && ! $safe) {
                $this->src->addLog('تعداد کالاهای JSON بیش از نصف کم شده؛ برای ایمنی، کالاهای حذف‌شده دست نخوردند.', 'warn');
            }
            (clone $stale)->update(['in_feed' => false, 'status' => 'removed']);
        }
        $st['c']['removed'] = $removed;
        $st['status'] = 'idle';
        $st['phase'] = '';
        $st['finished'] = now()->toIso8601String();
        if (! $st['c']['failed']) {
            $st['last_hash'] = $st['hash'];
            $st['last_total'] = $st['total'];
        }
        $c = $st['c'];
        $b = (array) ($st['bytes'] ?? [0, 0]);
        if (($b[0] ?? 0) > 0) {
            $this->src->addLog('فشرده‌سازی تصاویر: '.fa(round($b[0] / 1048576, 1)).' مگابایت ← '.fa(round($b[1] / 1048576, 1)).' مگابایت ('.fa((int) round(100 - $b[1] * 100 / $b[0])).'٪ سبک‌تر).', 'ok');
        }
        $this->src->stats = $c + ['total' => $st['total'], 'at' => $st['finished'], 'mode' => $st['mode'] ?? 'full', 'not_found' => count((array) ($st['not_found'] ?? []))];
        $this->src->last_ok_at = now();
        $this->src->addLog('پایان: '.fa($c['created']).' ساخته، '.fa($c['updated']).' به‌روز، '.fa($c['unchanged']).' بدون تغییر، '.fa($c['skipped']).' ساخته‌نشده، '
            .fa($c['prices']).' تغییر قیمت، '.fa($c['images']).' تصویر'.($c['images_failed'] ? ' ('.fa($c['images_failed']).' ناموفق)' : '').($removed ? '، '.fa($removed).' کالای حذف‌شده از JSON' : '').($c['failed'] ? '، '.fa($c['failed']).' خطا' : '').'.', $c['failed'] ? 'warn' : 'ok');
        if (! empty($c['wh'])) {
            $this->src->addLog('شماره انبار '.fa($c['wh']).' کالای بدون تغییر نشانده یا اصلاح شد.', 'ok');
        }
        if (! empty($c['wh_none']) && ($this->o['wh_sync'] ?? true)) {
            $this->src->addLog(fa($c['wh_none']).' ردیف JSON شماره انبار نداشت (فیلدهای «'.($this->o['fields']['wh_carton'] ?? '').'» و «'.($this->o['fields']['wh_retail'] ?? '').'» خالی یا ناموجود)؛ این کالاها انبار نمی‌گیرند.', 'warn');
        }
        $whNone = Product::query()->whereNotNull('sync_code')->whereNull('warehouse_id')->whereNull('retail_warehouse_id')->count();
        if ($whNone) {
            $this->src->addLog(fa($whNone).' کالای سایت هنوز هیچ شماره انباری ندارد.', 'warn');
        }
        Cache::forget('search.vocab'); // کلید جستجوی هر کالا هنگام ذخیره ساخته می‌شود
    }

    /** اجرای کامل در یک درخواست (برای کرون) با سقف زمان */
    public function runUntil(float $seconds): array
    {
        $t0 = microtime(true);
        do {
            $st = $this->step(min(15, $seconds));
        } while (($st['status'] ?? '') === 'running' && microtime(true) - $t0 < $seconds);

        return $st;
    }

    /**
     * حذف کالاهایی که این منبع JSON ساخته است
     *
     * @param  string  $scope  all | not_in_feed | out_of_stock | items
     * @return array{deleted: int, disabled: int, files: int}
     */
    public function deleteProducts(string $scope = 'all', bool $files = true, bool $keepOrdered = true, bool $block = true, ?array $itemIds = null): array
    {
        @set_time_limit(600);
        $q = Product::query()->where('sync_source_id', $this->src->id);
        if ($scope === 'orphans') {
            // کالاهای منبع‌های JSON که حذف شده‌اند
            $q = Product::query()->whereNotNull('sync_source_id')->whereNotIn('sync_source_id', SyncSource::query()->pluck('id')->all() ?: [0]);
        }
        if ($scope === 'items' && $itemIds !== null) {
            $q->whereIn('id', SyncItem::query()->whereIn('id', $itemIds)->whereNotNull('product_id')->pluck('product_id'));
        } elseif ($scope === 'not_in_feed') {
            $q->whereIn('id', SyncItem::query()->where('source_id', $this->src->id)->where('in_feed', false)->whereNotNull('product_id')->pluck('product_id'));
        } elseif ($scope === 'out_of_stock') {
            $q->where(fn ($w) => $w->where('in_stock', false)->orWhere('stock', '<=', 0));
        }
        $res = ['deleted' => 0, 'disabled' => 0, 'files' => 0];
        $q->select(['id', 'image', 'gallery'])->chunkById(300, function ($chunk) use (&$res, $files, $keepOrdered, $block) {
            $ids = $chunk->pluck('id')->all();
            $ordered = $keepOrdered ? DB::table('order_items')->whereIn('product_id', $ids)->distinct()->pluck('product_id')->all() : [];
            $del = array_values(array_diff($ids, $ordered));
            if ($ordered) {
                Product::query()->whereIn('id', $ordered)->update(['is_active' => false]);
                $res['disabled'] += count($ordered);
            }
            if ($del) {
                if ($files) {
                    foreach ($chunk->whereIn('id', $del) as $p) {
                        foreach (array_filter(array_merge([$p->image], (array) $p->gallery)) as $rel) {
                            if (! str_starts_with((string) $rel, 'products/sync/')) {
                                continue; // فقط تصاویری که همگام‌سازی دانلود کرده
                            }
                            $res['files'] += (int) @unlink(public_path('uploads/'.$rel));
                            @unlink(\App\Support\Watermark::origPath($rel));
                            \App\Support\Watermark::clearThumbs($rel);
                        }
                    }
                }
                foreach (['product_attribute_value', 'reviews', 'stock_alerts', 'channel_posts'] as $t) {
                    try {
                        DB::table($t)->whereIn('product_id', $del)->delete();
                    } catch (\Throwable) {
                    }
                }
                DB::table('order_items')->whereIn('product_id', $del)->update(['product_id' => null]);
                Product::query()->whereIn('id', $del)->delete();
                $res['deleted'] += count($del);
                SyncItem::query()->where('source_id', $this->src->id)->whereIn('product_id', $del)->update([
                    'product_id' => null,
                    'status' => 'skipped',
                    'reason' => $block ? 'deleted' : null,
                    'message' => $block ? SyncItem::REASONS['deleted'] : null,
                    'image_status' => null,
                    'image_tries' => 0,
                    'hash' => null,
                ]);
            }
        });
        Cache::forget('home.blocks');
        Cache::forget('sitemap.xml');
        $this->src->addLog('حذف کالاهای ساخته‌شده از JSON: '.fa($res['deleted']).' حذف'.($res['disabled'] ? '، '.fa($res['disabled']).' کالای دارای سفارش غیرفعال شد' : '').($res['files'] ? '، '.fa($res['files']).' فایل تصویر پاک شد' : '').'.', 'warn');
        $this->src->save();

        return $res;
    }

    /** تعمیر پیش از اجرا: پیوندهای شکسته و کالاهای تکراری */
    protected function preRepair(array $repair): string
    {
        if (empty($repair['links'])) {
            return '';
        }
        $sid = $this->src->id;
        // ردیف‌هایی که به کالای حذف‌شده اشاره می‌کنند
        $broken = 0;
        SyncItem::query()->where('source_id', $sid)->whereNotNull('product_id')->select(['id', 'product_id'])->chunkById(1000, function ($chunk) use (&$broken) {
            $exists = Product::query()->whereIn('id', $chunk->pluck('product_id'))->pluck('id')->flip();
            $gone = $chunk->filter(fn ($i) => ! isset($exists[$i->product_id]))->pluck('id')->all();
            if ($gone) {
                $broken += SyncItem::query()->whereIn('id', $gone)->update(['product_id' => null, 'status' => 'new', 'hash' => null, 'image_status' => null]);
            }
        });
        // کالاهای تکراری با یک کد
        $dups = 0;
        $codes = Product::query()->where('sync_source_id', $sid)->whereNotNull('sync_code')->select('sync_code')->groupBy('sync_code')->havingRaw('count(*) > 1')->pluck('sync_code');
        foreach ($codes as $code) {
            $list = Product::query()->where('sync_source_id', $sid)->where('sync_code', $code)->orderBy('id')->get(['id']);
            foreach ($list->slice(1) as $extra) {
                if (\Illuminate\Support\Facades\DB::table('order_items')->where('product_id', $extra->id)->exists()) {
                    Product::query()->whereKey($extra->id)->update(['is_active' => false, 'sync_code' => null, 'sync_source_id' => null]);
                } else {
                    \Illuminate\Support\Facades\DB::table('product_attribute_value')->where('product_id', $extra->id)->delete();
                    Product::query()->whereKey($extra->id)->delete();
                }
                $dups++;
            }
        }

        return fa($broken).' پیوند شکسته اصلاح، '.fa($dups).' کالای تکراری حذف/غیرفعال شد';
    }

    /**
     * پاک‌سازی کامل: همه کالاهای ساخته‌شده از این JSON، تصاویرشان، ردیف‌ها و سوابق همگام‌سازی
     * (سفارش‌های قبلی با نام و قیمت ثبت‌شده باقی می‌مانند). بعد از آن اجرای بعدی از صفر شروع می‌شود.
     */
    public static function orphanCount(): int
    {
        return Product::query()->whereNotNull('sync_source_id')->whereNotIn('sync_source_id', SyncSource::query()->pluck('id')->all() ?: [0])->count();
    }

    public function purgeAll(bool $keepExcel = true, bool $emptyCategories = false, bool $orphans = true): array
    {
        @set_time_limit(900);
        // هم‌زمان با مرحله‌ای که کرون در حال اجراست انجام نشود
        $lock = Cache::lock('sync.step.'.$this->src->id, 900);
        if (! $lock->block(90)) {
            throw new RuntimeException('یک اجرای همگام‌سازی در حال پردازش است؛ یک دقیقه دیگر دوباره امتحان کنید.');
        }
        try {
            return $this->doPurge($keepExcel, $emptyCategories, $orphans);
        } finally {
            $lock->release();
        }
    }

    protected function doPurge(bool $keepExcel, bool $emptyCategories, bool $orphans): array
    {
        $this->stop('برای پاک‌سازی کامل متوقف شد.');
        $this->src->refresh();
        $res = $this->deleteProducts('all', true, false, false);
        if ($orphans) {
            $o = $this->deleteProducts('orphans', true, false, false);
            $res['deleted'] += $o['deleted'];
            $res['files'] += $o['files'];
            $res['orphans'] = $o['deleted'];
            // پوشه تصاویر منبع‌های حذف‌شده
            $ids = SyncSource::query()->pluck('id')->all();
            foreach (glob(public_path('uploads/products/sync/*'), GLOB_ONLYDIR) ?: [] as $d) {
                if (ctype_digit(basename($d)) && ! in_array((int) basename($d), $ids, true)) {
                    $res['files'] += static::rmTree($d);
                    static::rmTree(\App\Support\Watermark::origPath('products/sync/'.basename($d)));
                }
            }
        }
        $sid = $this->src->id;
        // ردیف‌های همگام‌سازی (درصد اختصاصی و «موجود» اکسل در صورت انتخاب حفظ می‌شود)
        $q = SyncItem::query()->where('source_id', $sid);
        if ($keepExcel) {
            (clone $q)->where(fn ($w) => $w->whereNotNull('markup_override')->orWhereNotNull('force'))->update([
                'product_id' => null, 'title' => null, 'category' => null, 'raw_price' => 0, 'price' => 0, 'retail_price' => null, 'markup' => null,
                'stock_retail' => 0, 'stock_wholesale' => 0, 'per_carton' => 1, 'images' => null, 'extra' => null, 'hash' => null,
                'status' => 'new', 'reason' => null, 'message' => null, 'image_status' => null, 'image_error' => null, 'image_tries' => 0,
                'in_feed' => false, 'run' => null, 'price_first' => null, 'price_prev' => null, 'price_changed_at' => null,
            ]);
            $q->whereNull('markup_override')->whereNull('force');
        }
        $res['items'] = 0;
        do {
            $ids = (clone $q)->limit(2000)->pluck('id')->all();
            $res['items'] += $ids ? SyncItem::query()->whereIn('id', $ids)->delete() : 0;
        } while ($ids);
        SyncPriceChange::query()->where('source_id', $sid)->delete();
        // پوشه تصاویر این منبع (اصلی، نهایی و بندانگشتی‌ها)
        $dirs = [public_path('uploads/products/sync/'.$sid), \App\Support\Watermark::origPath('products/sync/'.$sid)];
        foreach (glob(public_path('uploads/_t/*'), GLOB_ONLYDIR) ?: [] as $t) {
            $dirs[] = $t.'/products/sync/'.$sid;
        }
        foreach ($dirs as $d) {
            $res['files'] += static::rmTree($d);
        }
        if ($emptyCategories) {
            $res['categories'] = static::deleteEmptyCategories();
        }
        foreach (glob($this->src->dir().'/*') ?: [] as $f) {
            if (is_file($f)) {
                @unlink($f);
            }
        }
        $o = (array) $this->src->options;
        unset($o['excel_pending'], $o['excel_pending_codes']); // الگوی کشف‌شده آدرس تصاویر (تنظیمات) حفظ می‌شود
        if (! $keepExcel) {
            unset($o['excel_in']);
        }
        $this->src->options = $o;
        $this->src->state = ['status' => 'idle'];
        $this->src->stats = null;
        $this->src->log = [];
        $this->src->last_run_at = null;
        $this->src->last_ok_at = null;
        $this->src->addLog('پاک‌سازی کامل: '.fa($res['deleted']).' کالا، '.fa($res['items']).' ردیف همگام‌سازی و '.fa($res['files']).' فایل تصویر حذف شد'
            .(! empty($res['categories']) ? '، '.fa($res['categories']).' دسته خالی' : '').'. اجرای بعدی از صفر شروع می‌شود.', 'warn');
        $this->src->save();
        Cache::forget('search.vocab');

        return $res;
    }

    protected static function rmTree(string $dir): int
    {
        if (! is_dir($dir)) {
            return 0;
        }
        $n = 0;
        $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($it as $f) {
            if ($f->isDir()) {
                @rmdir($f->getPathname());
            } else {
                $n += (int) @unlink($f->getPathname());
            }
        }
        @rmdir($dir);

        return $n;
    }

    /** حذف دسته‌هایی که نه کالا دارند نه زیردسته‌ای با کالا */
    public static function deleteEmptyCategories(): int
    {
        $n = 0;
        for ($round = 0; $round < 10; $round++) {
            $used = Product::query()->whereNotNull('category_id')->distinct()->pluck('category_id')->all();
            $parents = Category::query()->whereNotNull('parent_id')->distinct()->pluck('parent_id')->all();
            $q = Category::query()->whereNotIn('id', array_merge($used, $parents) ?: [0]);
            $ids = $q->pluck('id')->all();
            if (! $ids) {
                break;
            }
            Category::query()->whereIn('id', $ids)->delete();
            $n += count($ids);
        }
        Cache::forget('home.blocks');

        return $n;
    }

    /**
     * کالاهای اکسل خودمان رسید (موجود): در همه منابع JSON «موجود» حساب و در صورت نبودن در سایت، از JSON ساخته می‌شوند
     *
     * @param  array<string>  $available  کد/بارکدهای موجود
     * @param  array<string>  $unavailable  کد/بارکدهایی که اکسل ناموجود اعلام کرد
     * @param  bool  $replace  فایل فهرست کامل است (جایگزین فهرست قبلی)
     */
    public static function excelArrived(array $available, array $unavailable = [], bool $replace = false): int
    {
        $started = 0;
        $norm = function (array $codes) {
            $out = [];
            foreach ($codes as $c) {
                $c = strtoupper(trim(en_digits((string) $c)));
                if ($c !== '') {
                    $out[ctype_digit($c) ? (ltrim($c, '0') ?: '0') : $c] = true;
                }
            }

            return $out;
        };
        $add = $norm($available);
        $del = $norm($unavailable);
        foreach (SyncSource::query()->get() as $s) {
            try {
                $o = (array) $s->options;
                $list = $replace ? [] : array_flip(array_map('strval', (array) ($o['excel_in'] ?? [])));
                $list = array_diff_key($list + $add, $del);
                $o['excel_in'] = array_map('strval', array_keys($list));
                // همگام‌سازی JSON خاموش است: فقط فهرست ذخیره می‌شود، هیچ اجرایی راه نمی‌افتد
                // (قبلاً ورود اکسل با «موجود شوند» همگام‌سازی خاموش را هم اجرا می‌کرد)
                if (! $s->enabled) {
                    unset($o['excel_pending'], $o['excel_pending_codes']);
                    $s->options = $o;
                    $s->save();

                    continue;
                }
                if (! $add) {
                    $s->options = $o;
                    $s->save();

                    continue;
                }
                $codes = array_map('strval', array_keys($add));
                if ($s->isRunning()) {
                    $o['excel_pending'] = true;
                    $o['excel_pending_codes'] = array_values(array_unique(array_merge((array) ($o['excel_pending_codes'] ?? []), $codes)));
                    $s->options = $o;
                    $s->addLog('اکسل کالاهای موجود رسید ('.fa(count($codes)).' کد)؛ بعد از پایان اجرای فعلی ساخته می‌شوند.');
                    $s->save();

                    continue;
                }
                $s->options = $o;
                $s->addLog('اکسل کالاهای موجود رسید: '.fa(count($codes)).' کد؛ کالاهای موجود در JSON «موجود» حساب و در صورت نیاز ساخته می‌شوند.');
                $s->save();
                if (static::for($s->fresh())->queue(true, $codes, 'excel') === 'queued') {
                    $started++;
                }
            } catch (Throwable $e) {
                report($e);
            }
        }

        return $started;
    }

    /** اجازه ساخت دوباره کالاهای حذف‌شده */
    public function unblockDeleted(): int
    {
        return SyncItem::query()->where('source_id', $this->src->id)->where('reason', 'deleted')->update(['reason' => null, 'message' => null, 'status' => 'new', 'hash' => null]);
    }

    /**
     * برای درخواست‌های وب (بدون کرون): کار سنگین این‌جا انجام نمی‌شود؛ فقط اجرای موعددار در صف می‌رود
     * و کارگر پس‌زمینه راه می‌افتد تا پاسخ بازدیدکننده کند نشود.
     */
    public static function dispatchDue(): void
    {
        foreach (SyncSource::query()->get() as $s) {
            try {
                if ($s->isRunning() || ($s->enabled && $s->opt('excel_pending'))) {
                    SyncWorker::markActive();

                    continue;
                }
                if ($s->enabled && (! $s->last_run_at || $s->last_run_at->lt(now()->subMinutes(max(5, $s->interval))))) {
                    static::for($s)->queue(false);
                }
            } catch (Throwable $ex) {
                report($ex);
            }
        }
        SyncWorker::ensure();
    }

    /** اجرای خودکار منابع فعال (از زمان‌بند) */
    public static function tick(float $budget = 20): void
    {
        foreach (SyncSource::query()->get() as $s) {
            try {
                $e = static::for($s);
                // اجرایی که ورود اکسل برای همگام‌سازیِ خاموش راه انداخته بود: متوقف شود
                if ($s->isRunning() && ! $s->enabled && ($s->state['mode'] ?? '') === 'excel') {
                    $e->stop('همگام‌سازی JSON خاموش است؛ اجرای خودکار پس از ورود اکسل متوقف شد.');

                    continue;
                }
                if ($s->isRunning()) {
                    $e->step($budget);

                    continue;
                }
                // کالاهای اکسلی که وسط اجرای قبلی رسیده بودند (فقط اگر همگام‌سازی روشن باشد)
                if ($s->opt('excel_pending') && $s->enabled) {
                    $o = (array) $s->options;
                    $codes = (array) ($o['excel_pending_codes'] ?? []);
                    unset($o['excel_pending'], $o['excel_pending_codes']);
                    $s->options = $o;
                    $s->save();
                    if ($codes && $e->start(true, $codes, 'excel') === 'started') {
                        $e->step($budget);
                    }

                    continue;
                }
                if ($s->enabled && (! $s->last_run_at || $s->last_run_at->lt(now()->subMinutes(max(5, $s->interval))))) {
                    if ($e->start() === 'started') {
                        $e->step($budget);
                    }
                }
            } catch (Throwable $ex) {
                $s->refresh();
                $s->last_run_at = now();
                $s->addLog('خطا: '.$ex->getMessage(), 'error');
                $s->save();
            }
        }
    }
}
