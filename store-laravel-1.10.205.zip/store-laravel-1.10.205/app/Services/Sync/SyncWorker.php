<?php

namespace App\Services\Sync;

use App\Models\SyncSource;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Throwable;

/**
 * کارگر پس‌زمینه همگام‌سازی، بدون نیاز به باز بودن صفحه و حتی بدون کرون:
 * هر اجرا حدود ۵۰ ثانیه کار می‌کند و پیش از پایان، اجرای بعدی را با یک درخواست داخلی (به خود سایت) شروع می‌کند.
 * اگر زنجیره قطع شود (راه‌اندازی دوباره هاست، خطا)، با اولین بازدید سایت، کرون یا باز کردن پنل دوباره راه می‌افتد
 * و کار از آخرین نقطه ذخیره‌شده ادامه پیدا می‌کند.
 */
class SyncWorker
{
    public const BEAT = 'sync.worker.beat';

    public const ACTIVE = 'sync.active';

    public static function token(): string
    {
        return substr(hash_hmac('sha256', 'sync-worker', (string) config('app.key')), 0, 32);
    }

    /** کارگر در ۷۵ ثانیه اخیر فعال بوده؟ */
    public static function alive(): bool
    {
        $b = Cache::get(static::BEAT);

        return $b && (time() - (int) $b) < 75;
    }

    /** آیا اجرای در جریانی هست؟ (بدون کوئری دیتابیس در هر درخواست) */
    public static function active(): bool
    {
        return (bool) Cache::get(static::ACTIVE);
    }

    public static function markActive(): void
    {
        Cache::put(static::ACTIVE, 1, 86400 * 3);
    }

    /** درخواست داخلی به خود سایت کار نمی‌کند؟ (در این صورت صفحه باز، خودش کار را جلو می‌برد) */
    public static function broken(): bool
    {
        return (bool) Cache::get('sync.worker.broken');
    }

    /** اگر کاری در جریان است و کارگری فعال نیست، کارگر را راه بینداز */
    public static function ensure(): void
    {
        try {
            if (static::active() && ! static::alive()) {
                static::kick();
            }
        } catch (Throwable $e) {
            report($e);
        }
    }

    public static function kick(bool $chain = false, bool $now = false): bool
    {
        // $now: شروع تازه از پنل؛ اگر کارگری مشغول باشد، درخواست دوم فقط «busy» برمی‌گرداند
        if (! $chain && ! $now && (static::alive() || ! Cache::add('sync.worker.kick', 1, 25))) {
            return false;
        }
        $kicked = (int) Cache::get('sync.worker.kicked_at');
        // راه‌اندازی قبلی جواب نداده (کارگری شروع نشد)؛ ۱۰ دقیقه صفحه باز خودش کار می‌کند
        if (! $chain && $kicked && time() - $kicked > 40 && time() - $kicked < 300 && ! static::alive()) {
            Cache::put('sync.worker.broken', 1, 600);
        }
        if (! $chain) {
            Cache::put('sync.worker.kicked_at', time(), 600);
        }

        return static::fire(route('sync.worker', ['token' => static::token()]));
    }

    /** درخواست بدون انتظار برای پاسخ */
    public static function fire(string $url): bool
    {
        $p = parse_url($url);
        if (empty($p['host'])) {
            return false;
        }
        $https = ($p['scheme'] ?? 'http') === 'https';
        $port = (int) ($p['port'] ?? ($https ? 443 : 80));
        $path = ($p['path'] ?? '/').(isset($p['query']) ? '?'.$p['query'] : '');
        $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'SNI_enabled' => true, 'peer_name' => $p['host']]]);
        $fp = @stream_socket_client(($https ? 'ssl://' : 'tcp://').$p['host'].':'.$port, $errno, $err, 5, STREAM_CLIENT_CONNECT, $ctx);
        if ($fp) {
            $req = "GET {$path} HTTP/1.1\r\nHost: {$p['host']}".(isset($p['port']) ? ':'.$port : '')."\r\nUser-Agent: Mozilla/5.0 (StoreSyncWorker)\r\nAccept: */*\r\nConnection: close\r\n\r\n";
            @fwrite($fp, $req);
            @fflush($fp);
            usleep(300000); // فرصت رسیدن درخواست به سرور
            @fclose($fp);

            return true;
        }
        try { // روش دوم
            Http::timeout(2)->connectTimeout(3)->withoutVerifying()->get($url);
        } catch (Throwable) {
            // پاسخ منتظر نمی‌ماند؛ خطای زمان طبیعی است
        }

        return true;
    }

    /** اجرای کارگر (داخل درخواست داخلی) */
    public static function run(): string
    {
        @ignore_user_abort(true);
        @set_time_limit(0);
        $lock = Cache::lock('sync.worker.run', 90);
        if (! $lock->get()) {
            return 'busy';
        }
        Cache::forget('sync.worker.broken');
        Cache::forget('sync.worker.kicked_at');
        Cache::put(static::BEAT, time(), 600);
        $more = false;
        try {
            $limit = (int) ini_get('max_execution_time');
            $budget = $limit > 0 ? max(8, min(50, $limit - 12)) : 50;
            $t0 = microtime(true);
            // حالت آرام (پیش‌فرض): کار در تکه‌های کوتاه و بین آن‌ها استراحت هم‌اندازه، تا پردازنده هاست
            // برای پنل، کارتابل انبار و بازدیدکننده‌ها آزاد بماند (همگام‌سازی کمی کندتر ولی سایت روان)
            $gentle = (bool) setting('sync_gentle', true);
            do {
                $t = microtime(true);
                $left = $budget - (microtime(true) - $t0);
                SyncEngine::tick(max(5, $gentle ? min(6, $left) : $left));
                Cache::put(static::BEAT, time(), 600);
                $running = SyncSource::query()->get()->contains(fn (SyncSource $s) => $s->isRunning());
                $spent = microtime(true) - $t;
                if ($running && $spent < 1) {
                    sleep(3); // منتظر تلاش دوباره یا قفل: درخواست‌های پشت‌سرهم بی‌فایده ساخته نشود
                } elseif ($running && $gentle) {
                    usleep((int) (min(8, $spent) * 1_000_000));
                    Cache::put(static::BEAT, time(), 600);
                }
            } while ($running && microtime(true) - $t0 < $budget - 3);
            $more = SyncSource::query()->get()->contains(fn (SyncSource $s) => $s->isRunning() || ($s->enabled && $s->opt('excel_pending')));
            if (! $more) {
                Cache::forget(static::ACTIVE);
                Cache::forget(static::BEAT); // کارگر تمام شد؛ اجرای بعدی بلافاصله کارگر تازه می‌گیرد
            }
        } catch (Throwable $e) {
            report($e);
            $more = true;
        } finally {
            $lock->release();
        }
        if ($more) {
            static::kick(true); // ادامه زنجیره
        }

        return $more ? 'continue' : 'done';
    }
}
