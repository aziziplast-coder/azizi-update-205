<?php

namespace App\Services;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use RuntimeException;
use Throwable;

/**
 * ویرایش اقلام سفارش توسط کارشناس از داخل گفتگو: کم و زیاد کردن تعداد، حذف و افزودن کالا.
 * موجودی انبار، جمع سفارش، حواله‌های انبار و تاریخچه همگی به‌روز می‌شوند.
 */
class OrderEdit
{
    /** مراحلی که سفارش در آن‌ها قابل ویرایش است */
    public const STATUSES = ['on_hold', 'processing', 'settling'];

    /** چرا این همکار الان نمی‌تواند سفارش را ویرایش کند (null = می‌تواند) */
    public static function why(Order $o, User $u): ?string
    {
        if (! $u->hasPerm('orders_edit')) {
            return 'برای ویرایش سفارش دسترسی «ویرایش سفارش» لازم است.';
        }
        if (! $u->isAdmin() && (int) $o->assignee_id !== (int) $u->id) {
            return 'فقط مسئول همین سفارش می‌تواند آن را ویرایش کند.';
        }
        if ($o->review_status === 'pending') {
            return 'سفارش در صف بررسی چک است.';
        }
        if (! in_array($o->status, self::STATUSES, true) || $o->loaded_at) {
            return 'سفارش در مرحله «'.$o->statusLabel().'» است و دیگر قابل ویرایش نیست.';
        }
        if ($o->isPaid()) {
            return 'پرداخت این سفارش کامل شده و دیگر از گفتگو ویرایش نمی‌شود.';
        }

        return null;
    }

    /** در «تسویه حساب» انبار کارش را تمام کرده: فقط کم کردن و حذف */
    public static function onlyReduce(Order $o): bool
    {
        return $o->status === 'settling';
    }

    public static function packSize(OrderItem $i): int
    {
        $pc = max(1, (int) $i->per_carton);

        // ردیفی که با قانون خرید (بسته‌ای/فله) مضرب کارتن نیست، به عدد ویرایش می‌شود
        return $i->mode === Product::CARTON && (int) $i->units % $pc === 0 ? $pc : 1;
    }

    /** برچسب تعداد برای نمایش: «۳ کارتن (۳۶ عدد)» یا «۵ عدد» */
    public static function label(string $mode, int $units, int $pc): string
    {
        // کمتر از کارتن / غیرمضرب کارتن (مثلاً ۵۰ عدد از کارتن ۱۲تایی) = فقط عدد
        if ($mode === Product::CARTON && $pc > 1 && $units > 0 && $units % $pc === 0) {
            return fa(intdiv($units, $pc)).' کارتن ('.fa($units).' عدد)';
        }

        return fa($units).' عدد';
    }

    /**
     * @param  array<int,int>  $lines  شناسه قلم ← تعداد تازه (کارتن یا عدد؛ ۰ = حذف)
     * @param  array<int,array{pid:int,mode:string,qty:int}>  $adds
     * @return string متن تغییرات برای گفتگو و تاریخچه
     */
    public static function apply(Order $o, array $lines, array $adds, User $u, bool $short = false): string
    {
        if ($why = static::why($o, $u)) {
            throw new RuntimeException($why);
        }
        $reduceOnly = static::onlyReduce($o);
        // اصلاح فاکتور در مرحله تسویه هم باز است (افزودن کالا هم)؛ بعد از ثبت «اصلاح مانده حساب» لازم است
        $before = (int) $o->total;
        $notes = [];
        $added = false;
        $shorts = 0;
        // همان ویرایش دو بار پشت هم (مثلاً پس از خطا «ثبت» دوباره زده شد) ← بار دوم پذیرفته نمی‌شود (سفارش ۱۱۳۸: اقلام سه بار اضافه شده بود)
        $dupKey = 'oedit.'.$o->id.'.'.md5(json_encode([$lines, $adds, $short]));
        if ($adds && \Illuminate\Support\Facades\Cache::has($dupKey)) {
            throw new RuntimeException('همین ویرایش همین الان روی سفارش ثبت شده است؛ صفحه را تازه کنید و اقلام فاکتور را ببینید، دوباره اضافه نکنید.');
        }

        DB::transaction(function () use ($o, $lines, $adds, $reduceOnly, $short, &$notes, &$added, &$shorts) {
            $o->load('items');
            foreach ($lines as $id => $qty) {
                /** @var OrderItem|null $it */
                $it = $o->items->firstWhere('id', (int) $id);
                if (! $it) {
                    continue;
                }
                $pc = static::packSize($it);
                // ['u' => تعداد عدد] = اصلاح آزاد به عدد (مثلاً کارتن ۱۲تایی ← ۵ عدد)؛ عدد ساده = کارتن/عدد مثل قبل
                $new = is_array($qty) ? max(0, (int) ($qty['u'] ?? 0)) : max(0, (int) $qty) * $pc;
                $old = (int) $it->units;
                if ($new === $old) {
                    continue;
                }
                $picked = $it->pick_status !== null;
                if ($picked && $it->pick_task_id && \App\Models\PickTask::query()->whereKey($it->pick_task_id)->where('status', '!=', 'done')->exists()) {
                    throw new RuntimeException('«'.$it->name.'» همین الان در دست انباردار است؛ بعد از پایان جمع‌آوری آن انبار اصلاح کنید.');
                }
                if ($picked && ! ($short && $new < $old)) {
                    // قلمی که انبار جمع کرده: اصلاح مستقیم تعداد (به درخواست مشتری یا اشتباه شمارش)
                    static::moveStock($o, $it->product_id, $it->cartMode(), $new - $old, $it->name);
                    $lbl = static::label($it->mode, $old, (int) $it->per_carton).' ← '.static::label($it->mode, $new, (int) $it->per_carton);
                    if ($new === 0) {
                        $it->delete();
                        $notes[] = '«'.$it->name.'» حذف شد (پس از جمع‌آوری انبار)';
                    } else {
                        $it->forceFill(['units' => $new, 'picked_units' => $new, 'ordered_units' => $new, 'pick_status' => 'ok', 'total' => (int) $it->unit_price * $new])->save();
                        $notes[] = '«'.$it->name.'»: '.$lbl.($new > $old ? ' (پس از جمع‌آوری انبار — اضافه را به انبار خبر دهید)' : '');
                    }

                    continue;
                }
                if ($short && $new < $old) {
                    // کسری انبار (از روی فاکتور کاغذی): قلم با «کسری/ناموجود» می‌ماند تا مشتری جایگزین انتخاب کند.
                    // موجودی سایت برنمی‌گردد (کالا واقعاً در انبار نبود)؛ مثل جمع‌آوری انبار، موجودی کالا صفر می‌شود.
                    if ($it->product_id && setting('pick_zero_stock', true)) {
                        Product::markOut((int) $it->product_id, $it->stockCol());
                    }
                    $it->forceFill(['units' => $new, 'picked_units' => $new, 'ordered_units' => $old, 'total' => (int) $it->unit_price * $new,
                        'pick_status' => $new === 0 ? 'missing' : 'short', 'picked_at' => now()])->save();
                    $notes[] = '«'.$it->name.'» '.($new === 0 ? 'ناموجود' : 'کسری: '.static::label($it->mode, $old, (int) $it->per_carton).' ← '.static::label($it->mode, $new, (int) $it->per_carton));
                    $shorts++;

                    continue;
                }
                static::moveStock($o, $it->product_id, $it->cartMode(), $new - $old, $it->name);
                if ($new === 0) {
                    $it->delete();
                    $notes[] = '«'.$it->name.'» حذف شد';
                } else {
                    $it->forceFill(['units' => $new, 'total' => (int) $it->unit_price * $new, 'ordered_units' => $new])->save();
                    $notes[] = '«'.$it->name.'»: '.static::label($it->mode, $old, (int) $it->per_carton).' ← '.static::label($it->mode, $new, (int) $it->per_carton);
                }
            }
            foreach ($adds as $a) {
                $p = Product::query()->active()->find((int) ($a['pid'] ?? 0));
                if (! $p) {
                    throw new RuntimeException('کالا پیدا نشد یا غیرفعال است.');
                }
                $mode = ($a['mode'] ?? '') === Product::RETAIL && $p->retailAllowed() ? Product::RETAIL : Product::CARTON;
                $pc = $mode === Product::CARTON ? max(1, (int) $p->per_carton) : 1;
                $units = max(1, (int) ($a['qty'] ?? 1)) * $pc;
                // همین کالا با تعداد، روی حواله‌ای هست که هنوز جمع نشده ← دوباره اضافه نشود (سفارش ۱۱۳۸: سه قلم دو بار در دو حواله رفت)
                $live = $o->items()->where('product_id', $p->id)->whereNull('pick_status')->whereNotNull('pick_task_id')->where('units', '>', 0)
                    ->whereIn('pick_task_id', \App\Models\PickTask::query()->where('order_id', $o->id)->where('status', '!=', 'done')->select('id'))->first();
                if ($live && empty($a['force'])) {
                    throw new RuntimeException('«'.$p->name.'» همین الان در فاکتور هست ('.static::label($live->mode, (int) $live->units, (int) $live->per_carton)
                        .') و روی حواله انبار است که هنوز جمع نشده؛ دوباره اضافه نکنید. اگر مشتری بیشتر می‌خواهد، تعداد همان ردیف را زیاد کنید.');
                }
                $same = $o->items()->where('product_id', $p->id)->where('mode', $mode)->whereNull('pick_status')->whereNull('pick_task_id')->first();
                static::moveStock($o, $p->id, $mode, $units, $p->name);
                if ($same) {
                    $same->forceFill(['units' => $same->units + $units, 'total' => (int) $same->unit_price * ($same->units + $units), 'ordered_units' => $same->units + $units])->save();
                } else {
                    $price = $p->unitPrice($mode);
                    $o->items()->create([
                        'product_id' => $p->id, 'name' => $p->name, 'barcode' => $p->barcode, 'image' => $p->image, 'mode' => $mode,
                        'units' => $units, 'per_carton' => $p->per_carton, 'unit_label' => $p->unit_label, 'unit_price' => $price, 'compare_price' => null,
                        'total' => $price * $units, 'warehouse_id' => $p->warehouseFor($mode), 'ordered_units' => $units,
                    ] + ($o->fulfil_status && Picking::hasAppendix() ? ['appendix' => true] : [])); // پس از کسری انبار = پیوست فاکتور
                }
                $added = true;
                $notes[] = '«'.$p->name.'» '.static::label($mode, $units, $pc).' اضافه شد';
            }
            if (! $notes) {
                throw new RuntimeException('تغییری داده نشد.');
            }
            if (! $o->items()->where('units', '>', 0)->exists()) {
                throw new RuntimeException('سفارش نمی‌تواند خالی شود؛ برای لغو، وضعیت سفارش را «لغو» کنید.');
            }
            Picking::recalc($o);
            if ($shorts) {
                // مثل پایان جمع‌آوری انبار: مهلت انتخاب جایگزین برای مشتری
                $hours = (float) setting('replace_hours', 6);
                $o->forceFill(['fulfil_status' => 'picked', 'picked_at' => now(), 'replace_submitted_at' => null,
                    'replace_until' => setting('replace_enabled', true) && $hours > 0 && ! $o->isPaid() ? now()->addMinutes((int) round($hours * 60)) : null])->saveQuietly();
            }
        });
        if ($adds) {
            \Illuminate\Support\Facades\Cache::put($dupKey, 1, now()->addMinutes(2)); // اقلام ثبت شد؛ تکرار همین درخواست رد شود
        }
        if ($shorts) {
            $o->refresh();
            OrderWindows::afterPicked($o);
            try {
                app(Sms::class)->forOrder($o, 'order_picked', ['removed' => fa($shorts), 'deadline' => $o->replace_until ? jdate($o->replace_until, true) : '']);
                if ($o->user_id) {
                    app(WebPush::class)->toUsers([$o->user_id], ['title' => 'سفارش '.fa($o->number).': '.fa($shorts).' قلم کسری/ناموجود',
                        'body' => $o->replace_until ? 'تا '.jdate($o->replace_until, true).' می‌توانید جایگزین انتخاب کنید یا کالای دیگری اضافه کنید.' : 'جزئیات در صفحه سفارش',
                        'url' => route('order.show', $o->number).'#replace', 'tag' => 'order-'.$o->id]);
                }
            } catch (Throwable $e) {
                report($e);
            }
        }

        $o->refresh();
        // کالای تازه در سفارشی که به انبار رفته ← حواله تازه برای انباردار
        if ($added && $o->pick_round && Picking::enabled() && in_array($o->status, ['on_hold', 'processing'], true)) {
            try {
                app(Picking::class)->refer($o, ['note' => 'کالای افزوده‌شده از گفتگو']);
                $o->refresh();
            } catch (Throwable $e) {
                report($e);
            }
        }
        $text = ($shorts ? 'کسری انبار ثبت شد: ' : 'سفارش ویرایش شد: ').implode('، ', $notes).'. مبلغ سفارش: '.money($before).' ← '.money($o->total).' تومان'
            .($shorts && $o->replace_until ? ' — مشتری تا '.jdate($o->replace_until, true).' می‌تواند به‌جای کالاهای کسری جایگزین انتخاب کند یا کالای دیگری اضافه کند (پیوست فاکتور).' : '');
        $o->log('از گفتگو توسط '.$u->displayName().' — '.$text, $u->id);

        return $text;
    }

    /**
     * اقلامی که در ویرایش سبد از سفارش بیرون افتاده‌اند (از روی سبدهای ثبت‌شده همین سفارش).
     * suspect = کالای «۱ عدد در کارتن» که به‌خاطر خطای نسخه‌های پیش از ۱.۱۰.۱۴۹ در ویرایش سبد بی‌صدا حذف می‌شد.
     *
     * @return array<int, array{pid:int, mode:string, units:int, price:int, name:string, now:int, ok:bool, suspect:bool}>
     */
    protected static array $lostMemo = [];

    public static function lostItems(Order $o): array
    {
        return static::$lostMemo[$o->id] ??= static::findLost($o);
    }

    protected static function findLost(Order $o): array
    {
        $carts = \App\Models\CartRecord::query()->where('order_id', $o->id)->orderBy('id')->get(['id', 'items', 'prices']);
        if ($carts->count() < 2) {
            return []; // بدون ویرایش سبد چیزی جا نیفتاده است
        }
        $have = $o->items()->whereNotNull('product_id')->pluck('product_id')->map(fn ($v) => (int) $v)->flip();
        $seen = [];
        $bug = []; // کالایی که خطای سیستم (نه خود مشتری) از سبد ویرایش انداخته
        $prevItems = null;
        foreach ($carts as $c) {
            $prices = (array) $c->prices;
            $items = (array) $c->items;
            if ($prevItems !== null) {
                $now = [];
                foreach (array_keys($items) as $k) {
                    $now[(int) explode(':', (string) $k)[0]] = true;
                }
                foreach (array_keys($prevItems) as $k) {
                    [$pid, $mode] = array_pad(explode(':', (string) $k), 2, Product::CARTON);
                    $pid = (int) $pid;
                    if (isset($now[$pid])) {
                        unset($bug[$pid]); // دوباره در سبد آمد
                    } else {
                        // نشانه خطا: ردیف کارتنی سبد قبل، در سبد ویرایش بعدی با کلید «تکی» بارگذاری شد و بی‌صدا افتاد
                        $bug[$pid] = $mode === Product::CARTON && array_key_exists($pid.':'.Product::RETAIL, $prices);
                    }
                }
            }
            foreach ($items as $k => $u) {
                [$pid, $mode] = array_pad(explode(':', (string) $k), 2, Product::CARTON);
                $pid = (int) $pid;
                if ($pid && (int) $u > 0 && ! isset($have[$pid])) {
                    $seen[$pid] = ['pid' => $pid, 'mode' => $mode === Product::RETAIL ? Product::RETAIL : Product::CARTON, 'units' => (int) $u, 'price' => (int) ($prices[$k] ?? 0)];
                }
            }
            $prevItems = $items;
        }
        if (! $seen) {
            return [];
        }
        $products = Product::query()->whereIn('id', array_keys($seen))->get()->keyBy('id');
        $out = [];
        foreach ($seen as $pid => $s) {
            $p = $products->get($pid);
            if (! $p) {
                continue;
            }
            $out[$pid] = $s + [
                'name' => (string) $p->name,
                'now' => (int) $p->unitPrice($s['mode']),
                'ok' => (bool) $p->is_active,
                'suspect' => ! empty($bug[$pid]),
            ];
        }

        return $out;
    }

    /** بازگردانی اقلام جاافتاده به سفارش (با قیمت زمان سفارش یا قیمت فعلی) */
    public static function restoreLost(Order $o, User $u, array $pids, bool $oldPrice = true): string
    {
        if ($why = static::why($o, $u)) {
            throw new RuntimeException($why);
        }
        unset(static::$lostMemo[$o->id]);
        $lost = static::lostItems($o);
        $pids = array_values(array_intersect(array_map('intval', $pids), array_keys($lost)));
        if (! $pids) {
            throw new RuntimeException('قلمی برای بازگردانی انتخاب نشد.');
        }
        $before = (int) $o->total;
        $added = 0;
        $skip = [];
        DB::transaction(function () use ($o, $lost, $pids, $oldPrice, &$added, &$skip) {
            foreach ($pids as $pid) {
                $l = $lost[$pid];
                $p = Product::query()->active()->find($pid);
                if (! $p) {
                    $skip[] = $l['name'].' (غیرفعال)';

                    continue;
                }
                $mode = $l['mode'] === Product::RETAIL && $p->retailAllowed() ? Product::RETAIL : Product::CARTON;
                $units = (int) $l['units'];
                $price = $oldPrice && $l['price'] > 0 ? (int) $l['price'] : (int) $p->unitPrice($mode);
                $show = $p->orderMode($mode); // مثل ثبت سفارش: کالای ۱عددی «تکی» نوشته می‌شود
                static::moveStock($o, $p->id, $mode, $units, $p->name);
                $o->items()->create([
                    'product_id' => $p->id, 'name' => $p->name, 'barcode' => $p->barcode, 'image' => $p->image, 'mode' => $show,
                    'units' => $units, 'per_carton' => $p->per_carton, 'unit_label' => $p->unit_label, 'unit_price' => $price, 'compare_price' => null,
                    'total' => $price * $units, 'warehouse_id' => $p->warehouseFor($show), 'ordered_units' => $units,
                ] + ($o->fulfil_status && Picking::hasAppendix() ? ['appendix' => true] : []));
                $added++;
            }
            if ($added) {
                Picking::recalc($o);
            }
        });
        unset(static::$lostMemo[$o->id]);
        if (! $added) {
            throw new RuntimeException('هیچ قلمی برنگشت: '.implode('، ', $skip));
        }
        $o->refresh();
        // سفارش به انبار رفته (حتی «در انتظار تسویه» پس از جمع‌آوری) ← حواله تازه برای همین اقلام
        if ($o->pick_round && Picking::enabled() && in_array($o->status, ['on_hold', 'processing', 'settling'], true)) {
            try {
                app(Picking::class)->refer($o, ['note' => 'بازگردانی اقلام جاافتاده در ویرایش سبد']);
                $o->refresh();
            } catch (Throwable $e) {
                report($e);
            }
        }
        $text = fa($added).' قلم جاافتاده به سفارش برگشت ('.($oldPrice ? 'قیمت زمان سفارش' : 'قیمت فعلی').'). مبلغ سفارش: '.money($before).' ← '.money($o->total).' تومان'
            .($skip ? ' — برنگشت: '.implode('، ', $skip) : '');
        $o->log('توسط '.$u->displayName().' — '.$text, $u->id);

        return $text;
    }

    /** موجودی: کم یا زیاد کردن به اندازه تغییر (فقط وقتی موجودی سفارش کم شده است) */
    public static function moveStock(Order $o, ?int $productId, string $mode, int $delta, string $name): void
    {
        if (! $delta || ! $productId || ! $o->stock_reduced) {
            return;
        }
        $p = Product::query()->lockForUpdate()->find($productId);
        if (! $p) {
            return;
        }
        $col = $mode === Product::RETAIL ? 'retail_stock' : 'stock';
        if ($p->{$col} === null || ! Product::counts() || ($delta < 0 && ! $p->stockRestorable($col, $o->created_at))) {
            return;
        }
        // اصلاح فاکتور توسط اپراتور به موجودی سایت وابسته نیست (اصلاح ممکن است چند روز بعد زده شود)؛
        // موجودی منفی نمی‌شود، فقط تا صفر کم می‌شود
        $p->{$col} = max(0, (int) $p->{$col} - $delta);
        $p->saveQuietly();
        if ($delta < 0) {
            app(StockNotifier::class)->check($p);
        }
    }
}
