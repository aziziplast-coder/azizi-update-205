<?php

namespace App\Services;

use App\Models\Order;
use App\Models\SmsLog;
use Illuminate\Support\Facades\Http;
use Throwable;

/**
 * ارسال پیامک با چند پنل (در صورت خطای پنل اول، پنل بعدی امتحان می‌شود).
 */
class Sms
{
    public static function types(): array
    {
        return [
            'iranpayamak' => ['label' => 'فراز اس‌ام‌اس / ایران پیامک (پنل جدید)', 'help' => 'کلید API ثابت را از پنل (وب‌سرویس ← کلید API) بردارید، نه توکن ورود. شماره فرستنده خالی = خط ۹۰۰۰۸۳۶۱. کد الگو همان UID پترن است و نام متغیرها (سمت چپ = در بخش پیام‌ها) باید دقیقاً با متغیرهای پترن یکی باشد و همه متغیرهای پترن ارسال شوند. طول متغیرها را در پنل به اندازه بلندترین مقدار بگذارید وگرنه پیامک به صف تأیید دستی می‌رود.'],
            'faraz' => ['label' => 'فراز اس‌ام‌اس / IPPanel (وب‌سرویس edge قبلی)', 'help' => 'فقط اگر حساب شما هنوز روی پنل قدیمی ippanel است. برای پنل جدید گزینه «ایران پیامک (پنل جدید)» را انتخاب کنید.'],
            'ippanel' => ['label' => 'فراز اس‌ام‌اس / IPPanel (وب‌سرویس قدیمی api2)', 'help' => 'اگر کلید شما مربوط به نسخه قدیمی وب‌سرویس است.'],
            'kavenegar' => ['label' => 'کاوه‌نگار', 'help' => 'نام الگو (template) از بخش اعتبارسنجی؛ متغیرها به ترتیب token، token2، token3 ارسال می‌شوند.'],
            'melipayamak' => ['label' => 'ملی پیامک', 'help' => 'کد الگو همان bodyId وب‌سرویس خدماتی اشتراکی است؛ متغیرها به ترتیب {0}، {1}، …'],
            'smsir' => ['label' => 'SMS.ir', 'help' => 'کد الگو همان templateId ارسال سریع است؛ نام متغیرها باید با قالب یکی باشد.'],
            'custom' => ['label' => 'پنل دیگر (آدرس دلخواه)', 'help' => 'آدرس GET با {to} و {text}؛ مثال: https://panel.ir/send?user=..&pass=..&to={to}&text={text}'],
        ];
    }

    public static function events(): array
    {
        return [
            'otp' => ['title' => 'کد تأیید ورود و ثبت‌نام', 'vars' => 'code={code}', 'text' => "کد تأیید شما در {shop}: {code}\nاین کد را به کسی ندهید.", 'when' => 'وقتی مشتری برای ورود کد می‌خواهد.', 'on' => true],
            'customer_on_hold' => ['title' => 'سفارش ثبت شد — در انتظار پرداخت بیعانه (مشتری)', 'vars' => "name={name}\norder={order}\ntotal={total}", 'text' => '{name} عزیز، سفارش {order} به مبلغ {total} تومان ثبت شد. مبلغ بیعانه و شماره حساب به‌زودی در سایت (تب گفتگوی سفارش) برایتان صادر و پیامک می‌شود؛ تا آن زمان واریزی انجام ندهید. {shop}', 'when' => 'بلافاصله بعد از ثبت سفارش (هنوز بیعانه صادر نشده).', 'on' => true],
            'customer_processing' => ['title' => 'بیعانه دریافت شد — در حال جمع‌آوری از انبار (مشتری)', 'vars' => "name={name}\norder={order}\ntotal={total}", 'text' => '{name} عزیز، سفارش {order} در حال جمع‌آوری از انبار است. پس از جمع شدن بار، مانده حساب و شماره حساب واریز در تب گفتگوی سفارش برایتان صادر و پیامک می‌شود؛ تا آن زمان واریزی انجام ندهید. {shop}', 'when' => 'وقتی بیعانه تأیید شد و سفارش به «در حال جمع‌آوری از انبار» رفت (یا سفارش بدون بیعانه ثبت شد).', 'on' => true],
            'customer_settling' => ['title' => 'سفارش جمع‌آوری شد — در انتظار تسویه حساب (مشتری)', 'vars' => "name={name}\norder={order}\ntotal={total}", 'text' => '{name} عزیز، بار سفارش {order} در انبار جمع شد. لطفاً هنوز واریز نکنید؛ مانده حساب و شماره حساب واریز به‌زودی در تب گفتگوی سفارش برایتان صادر و پیامک می‌شود. {shop}', 'when' => 'وقتی انبار جمع‌آوری را تمام کرد. هنوز مانده حساب صادر نشده؛ پس نباید از مشتری پول خواست.', 'on' => true],
            'cheque_doc_rejected' => ['title' => 'مدرک چک تأیید نشد (مشتری)', 'vars' => "name={name}\norder={order}\ndoc={doc}\nreason={reason}\nlink={link}", 'text' => '{name} عزیز، {doc} سفارش {order} تأیید نشد: {reason}. لطفاً تصویر درست را بفرستید: {link} {shop}', 'when' => 'وقتی مدرک چک مشتری رد شد.', 'on' => true],
            'customer_to_freight' => ['title' => '(قدیمی، استفاده نمی‌شود) تسویه کامل — در صف ارسال به باربری', 'vars' => "name={name}\norder={order}", 'text' => '{name} عزیز، تسویه سفارش {order} کامل شد و بار در صف ارسال به باربری است. {shop}', 'when' => 'وقتی پرداخت کامل شد و بار به صف باربری رفت.', 'on' => true],
            'customer_waybill' => ['title' => 'بیجک باربری بارگذاری شد (مشتری)', 'vars' => "name={name}\norder={order}\nlink={link}", 'text' => '{name} عزیز، بیجک باربری سفارش {order} آماده است: {link} {shop}', 'when' => 'وقتی عکس بیجک باربری بارگذاری شد.', 'on' => true],
            'customer_direct' => ['title' => 'بار مستقیم ارسال شد (مشتری)', 'vars' => "name={name}\norder={order}\ndriver={driver}", 'text' => '{name} عزیز، بار سفارش {order} بارگیری و مستقیم به سمت مغازه شما ارسال شد. شماره تماس راننده: {driver} {shop}', 'when' => 'وقتی در صفحه «بیجک» گزینه «ارسال مستقیم» زده شد و شماره راننده وارد شد (بدون شماره راننده پیامکی نمی‌رود).', 'on' => true],
            'customer_shipped' => ['title' => 'تأیید نهایی — در حال ارسال به باربری (مشتری)', 'vars' => "name={name}\norder={order}\ntracking={tracking}", 'text' => '{name} عزیز، سفارش {order} تأیید نهایی شد و در حال ارسال به باربری است. {tracking} {shop}', 'when' => 'وقتی سفارش تأیید نهایی شد و «در حال ارسال به باربری» شد.', 'on' => true],
            'customer_completed' => ['title' => 'سفارش تکمیل شد (مشتری)', 'vars' => "name={name}\norder={order}", 'text' => '{name} عزیز، سفارش {order} تکمیل شد. از خرید شما سپاسگزاریم. {shop}', 'when' => 'وقتی وضعیت «تکمیل شده» شد.', 'on' => false],
            'customer_cancelled' => ['title' => 'سفارش لغو شد (مشتری)', 'vars' => "name={name}\norder={order}", 'text' => '{name} عزیز، سفارش {order} لغو شد. برای پیگیری با ما تماس بگیرید. {shop}', 'when' => 'وقتی سفارش لغو شد.', 'on' => true],
            'stock_back' => ['title' => 'کالا موجود شد (خبرم کن)', 'vars' => "product={product}", 'text' => 'کالای «{product}» موجود شد. {link} — {shop}', 'when' => 'وقتی کالایی که مشتری «خبرم کن» زده موجود شد.', 'on' => true],
            'survey' => ['title' => 'دعوت به نظرسنجی بعد از تحویل (مشتری)', 'vars' => "name={name}\norder={order}\nlink={link}", 'text' => '{name} عزیز، نظر شما درباره سفارش {order} برای ما مهم است: {link} — {shop}', 'when' => 'بعد از تحویل سفارش (دعوت به نظرسنجی).', 'on' => false],
            'order_picked' => ['title' => 'سفارش در انبار جمع‌آوری شد (مشتری)', 'vars' => "name={name}\norder={order}\nremoved={removed}\nlink={link}", 'text' => '{name} عزیز، سفارش {order} در انبار جمع‌آوری شد. {removed} قلم کسری یا ناموجود بود؛ برای انتخاب جایگزین: {link} — {shop}', 'when' => 'وقتی انبار جمع‌آوری را تمام کرد و کالایی کسری/ناموجود بود (در کنار پیامک «جمع‌آوری شد»).', 'on' => false],
            'remit_deposit' => ['title' => 'مبلغ بیعانه و حساب واریز اعلام شد (مشتری)', 'vars' => "name={name}\norder={order}\namount={amount}\nacct={acct}\nlink={link}", 'text' => '{name} عزیز، بیعانه سفارش {order}: {amount} تومان. لطفاً فقط {acct} واریز کنید؛ شماره حساب و ارسال فیش در سایت، تب گفتگوی سفارش. {shop}', 'when' => 'وقتی کارت بیعانه (با شماره حساب) در گفتگو صادر شد — اولین جایی که مشتری باید واریز کند.', 'on' => true],
            'remit_settle' => ['title' => 'مانده حساب سفارش اعلام شد (مشتری)', 'vars' => "name={name}\norder={order}\namount={amount}\nacct={acct}\nlink={link}", 'text' => '{name} عزیز، مانده حساب سفارش {order}: {amount} تومان. لطفاً فقط {acct} واریز کنید؛ شماره حساب و ارسال فیش در سایت، تب گفتگوی سفارش. {shop}', 'when' => 'وقتی کارت مانده حساب (با شماره حساب جدید) در گفتگو صادر شد — فقط از این لحظه مشتری باید مانده را واریز کند.', 'on' => true],
            'remit_rejected' => ['title' => 'فیش واریزی تأیید نشد (مشتری)', 'vars' => "name={name}\norder={order}\namount={amount}\nreason={reason}\nlink={link}", 'text' => '{name} عزیز، فیش {amount} تومانی سفارش {order} تأیید نشد: {reason}. لطفاً فیش درست را در تب گفتگوی سفارش بفرستید. {shop}', 'when' => 'وقتی فیش مشتری رد شد.', 'on' => true],
            'factory_receipt' => ['title' => 'فیش تازه به حساب کارخانه (به کارخانه‌دار)', 'vars' => "code={code}\namount={amount}\norder={order}\nlink={link}", 'text' => 'حواله {code}: واریز {amount} تومان بابت سفارش {order} به حساب شما. پس از نشستن در حساب، تأیید کنید: {link} {shop}', 'on' => true],
            'factory_status' => ['title' => 'خلاصه وضعیت حواله (به کارخانه‌دار)', 'vars' => "code={code}\npaid={paid}\nleft={left}\ncount={count}", 'text' => 'حواله {code}: تاکنون {paid} تومان در {count} فیش واریز و تأیید شده؛ مانده {left} تومان. {shop}', 'on' => true],
            'factory_remit_new' => ['title' => 'حواله تازه — تعیین حساب (به کارخانه‌دار)', 'vars' => "name={name}\ncode={code}\namount={amount}\nlink={link}", 'text' => '{name} عزیز، حواله {code} به مبلغ {amount} تومان برای شما صادر شد. برای تعیین حساب واریز (حساب خودتان یا شخص دیگر) وارد شوید: {link} {shop}', 'on' => true],
            'factory_remit_info' => ['title' => 'حواله تازه — اطلاع (به کارخانه‌دار)', 'vars' => "name={name}\ncode={code}\namount={amount}\nlink={link}", 'text' => '{name} عزیز، حواله {code} به مبلغ {amount} تومان برای شما صادر شد. پیگیری واریزها: {link} {shop}', 'on' => true],
            'factory_dest_ok' => ['title' => 'حساب مقصد تأیید شد (به کارخانه‌دار)', 'vars' => "name={name}\ncode={code}\namount={amount}\nlink={link}", 'text' => 'حساب‌های مقصد حواله {code} تأیید شد؛ واریزها از این پس به همین حساب‌ها انجام می‌شود. {link} {shop}', 'on' => true],
            'factory_dest_rejected' => ['title' => 'حساب مقصد رد شد (به کارخانه‌دار)', 'vars' => "name={name}\ncode={code}\nreason={reason}\nlink={link}", 'text' => 'حساب مقصد حواله {code} تأیید نشد: {reason}. لطفاً اصلاح کنید: {link} {shop}', 'on' => true],
            'factory_transfer_in' => ['title' => 'حواله منتقل‌شده به شخص ثالث', 'vars' => "name={name}\nfrom={from}\namount={amount}\ncode={code}\nlink={link}", 'text' => '{name} عزیز، حواله {code} به مبلغ {amount} تومان از طرف {from} به شما منتقل شد. برای ثبت شماره شبا و پیگیری واریزها وارد شوید: {link} {shop}', 'on' => true],
            'factory_pending' => ['title' => 'یادآوری فیش‌های منتظر تأیید (به کارخانه‌دار)', 'vars' => "name={name}\ncount={count}\namount={amount}\nlink={link}", 'text' => '{name} عزیز، {count} فیش به مبلغ {amount} تومان منتظر تأیید نشستن در حساب شماست: {link} {shop}', 'on' => true],
            'factory_filled' => ['title' => 'حواله تکمیل شد (به کارخانه‌دار)', 'vars' => "code={code}\npaid={paid}\ncount={count}", 'text' => 'حواله {code} تکمیل شد: {paid} تومان در {count} فیش. فیش‌ها در روبیکا ارسال می‌شود. {shop}', 'on' => true],
            'cheque_rejected' => ['title' => 'رد خرید چکی (مشتری)', 'vars' => "name={name}\norder={order}", 'text' => '{name} عزیز، امکان تأیید خرید چکی سفارش {order} فراهم نشد. برای هماهنگی با ما تماس بگیرید. {shop}', 'when' => 'وقتی خرید چکی رد شد.', 'on' => true],
            'admin_new_order' => ['title' => 'سفارش جدید (به مدیر)', 'vars' => "order={order}\ntotal={total}\nname={name}", 'text' => 'سفارش جدید {order} از {name} به مبلغ {total} تومان.', 'when' => 'به موبایل مدیران، بعد از هر سفارش جدید.', 'on' => true],
        ];
    }

    public static function eventConfig(string $event): ?array
    {
        $def = static::events()[$event] ?? null;
        if (! $def) {
            return null;
        }
        $saved = (array) (setting('sms_events', [])[$event] ?? []);

        return array_merge($def, array_filter($saved, fn ($v) => $v !== null));
    }

    public static function gateways(bool $onlyEnabled = true): array
    {
        $list = array_values((array) setting('sms_gateways', []));
        if ($onlyEnabled) {
            $list = array_values(array_filter($list, fn ($g) => ! empty($g['enabled'])));
        }

        return $list;
    }

    public static function configured(): bool
    {
        return count(static::gateways()) > 0;
    }

    public static function fill(string $tpl, array $data): string
    {
        $rep = [];
        foreach ($data as $k => $v) {
            $rep['{'.$k.'}'] = (string) $v;
        }

        return trim(strtr($tpl, $rep));
    }

    public static function parseVars(string $lines, array $data): array
    {
        $out = [];
        foreach (preg_split('/\r\n|\r|\n/', $lines) as $line) {
            if (! str_contains($line, '=')) {
                continue;
            }
            [$name, $val] = array_map('trim', explode('=', $line, 2));
            if ($name !== '') {
                $out[$name] = static::fill($val, $data);
            }
        }

        return $out;
    }

    /** @return array{ok: bool, msg: string} */
    /**
     * پیامک مربوط به یک سفارش؛ اگر ارسال نشد علتش در تاریخچه همان سفارش نوشته می‌شود
     * (تا معلوم باشد چرا مشتری پیامک نگرفته: الگو تعریف نشده، اعتبار، پنل غیرفعال و…)
     */
    public function forOrder(Order $o, string $event, array $extra = []): array
    {
        // داده همین لحظه گرفته می‌شود؛ خود ارسال پس از پاسخ به کاربر انجام می‌شود
        $data = $o->smsData() + $extra;
        $mobile = (string) $o->mobile;
        \App\Support\AfterResponse::run(fn () => $this->forOrderNow($o, $event, $mobile, $data));

        return ['ok' => true, 'msg' => 'در صف ارسال', 'maybe' => true];
    }

    protected function forOrderNow(Order $o, string $event, string $mobile, array $data): array
    {
        $res = $this->send($event, $mobile, $data);
        if (empty($res['ok']) && empty($res['maybe']) && ($res['msg'] ?? '') !== 'این پیام غیرفعال است.') {
            try {
                $o->log(mb_substr('⚠️ پیامک «'.(static::eventConfig($event)['title'] ?? $event).'» ارسال نشد: '.($res['msg'] ?? ''), 0, 495), null);
            } catch (Throwable) {
            }
        }

        return $res;
    }

    public function send(string $event, string $to, array $data, bool $force = false): array
    {
        $to = mobile($to);
        if (! $to) {
            return $this->log($event, '', false, 'شماره موبایل نامعتبر است.', '');
        }
        $ev = static::eventConfig($event);
        if (! $ev) {
            return ['ok' => false, 'msg' => 'نوع پیام نامعتبر است.'];
        }
        if (! $force && empty($ev['on'])) {
            return ['ok' => false, 'msg' => 'این پیام غیرفعال است.'];
        }
        $gws = static::gateways();
        if (! $gws) {
            return $this->log($event, $to, false, 'هیچ پنل پیامکی فعالی تعریف نشده است.', '');
        }
        $data = array_merge(['shop' => store_name()], $data);
        // لینک‌ها کوتاه و بدون https (پیامک دارای لینک بلند را پنل/اپراتور رد می‌کند)
        foreach ($data as $k => $v) {
            if (is_string($v) && preg_match('~^https?://~i', $v)) {
                $data[$k] = \App\Support\ShortLink::forSms($v);
            }
        }
        $vars = static::parseVars((string) $ev['vars'], $data);
        $text = static::fill((string) $ev['text'], $data);
        if ($event === 'otp' && setting('webotp', true) && isset($data['code'])) {
            $text .= "\n\n@".parse_url(config('app.url'), PHP_URL_HOST).' #'.$data['code'];
        }
        $res = ['ok' => false, 'msg' => ''];
        $name = '';
        $last = count($gws) - 1;
        foreach ($gws as $i => $gw) {
            $pattern = trim((string) ($gw['patterns'][$event] ?? ''));
            $name = ($gw['label'] ?? '') ?: ($gw['type'] ?? '');
            try {
                $res = $this->dispatch($gw, $to, $pattern, $vars, $text);
            } catch (Throwable $e) {
                $res = ['ok' => false, 'msg' => 'خطا: '.$e->getMessage()];
            }
            $res = $this->recheck($res);
            if ($res['ok'] || ! empty($res['maybe']) || $i === $last) {
                break;
            }
            $this->log($event, $to, false, $res['msg'].' — تلاش با پنل بعدی', $name);
        }

        return $this->log($event, $to, $res['ok'], $res['msg'], $name) + ['maybe' => ! empty($res['maybe'])];
    }

    /** نتیجه ناموفق را با پاسخ خام پنل دوباره می‌سنجد (پاسخ غیرمعمول ولی موفق / پاسخ دیررس) */
    protected function recheck(array $res): array
    {
        if ($res['ok']) {
            return $res;
        }
        $r = $this->lastResp;
        if (static::looksSent($r)) {
            return ['ok' => true, 'msg' => 'ارسال شد (پاسخ پنل: '.mb_substr(json_encode(array_diff_key($r, ['_http' => 1]), JSON_UNESCAPED_UNICODE), 0, 250).')'];
        }
        if (! empty($r['_timeout'])) {
            return ['ok' => false, 'maybe' => true, 'msg' => 'پاسخ پنل دیر رسید؛ ممکن است پیامک ارسال شده باشد. '.$res['msg']];
        }
        if ($r && ! isset($r['_error'])) {
            $res['msg'] .= ' | پاسخ پنل: '.mb_substr(json_encode(array_diff_key($r, ['_http' => 1]), JSON_UNESCAPED_UNICODE), 0, 300).' (HTTP '.($r['_http'] ?? '?').')';
        }

        return $res;
    }

    /** ارسال متن دلخواه (بدون الگو). در پنل‌های ایرانی پیامک غیرالگو ممکن است به صف تأیید اپراتور برود. */
    public function sendText(string $to, string $text, string $event = 'custom'): array
    {
        $to = mobile($to);
        if (! $to || trim($text) === '') {
            return ['ok' => false, 'msg' => 'شماره یا متن نامعتبر است.'];
        }
        $gws = static::gateways();
        if (! $gws) {
            return $this->log($event, $to, false, 'هیچ پنل پیامکی فعالی تعریف نشده است.', '');
        }
        $res = ['ok' => false, 'msg' => ''];
        $name = '';
        foreach ($gws as $i => $gw) {
            $name = ($gw['label'] ?? '') ?: ($gw['type'] ?? '');
            try {
                $res = $this->dispatch($gw, $to, '', [], $text);
            } catch (Throwable $e) {
                $res = ['ok' => false, 'msg' => 'خطا: '.$e->getMessage()];
            }
            if ($res['ok']) {
                break;
            }
        }

        return $this->log($event, $to, $res['ok'], $res['msg'], $name);
    }

    protected function log(string $event, string $to, bool $ok, string $msg, string $gw): array
    {
        try {
            SmsLog::create(['event' => $event, 'mobile' => $to ?: null, 'ok' => $ok, 'message' => mb_substr($msg, 0, 990), 'provider' => $gw ?: null]);
        } catch (Throwable) {
        }

        return ['ok' => $ok, 'msg' => $msg];
    }

    /* ---------------- رویدادهای سفارش ---------------- */

    protected function orderData(Order $o): array
    {
        return [
            'name' => $o->customer_name,
            'order' => $o->number,
            'total' => number_format($o->total),
            'tracking' => $o->tracking_code ? 'کد رهگیری: '.$o->tracking_code : '',
            'status' => $o->statusLabel(),
        ];
    }

    public function newOrder(Order $o): void
    {
        $data = $this->orderData($o);
        $status = $o->status;
        $mobile = (string) $o->mobile;
        \App\Support\AfterResponse::run(fn () => $this->newOrderNow($status, $mobile, $data));
    }

    protected function newOrderNow(string $status, string $mobile, array $data): void
    {
        $o = (object) ['status' => $status, 'mobile' => $mobile];
        $this->send($o->status === 'processing' ? 'customer_processing' : 'customer_on_hold', $o->mobile, $data);
        foreach (preg_split('/[\s,،]+/u', (string) setting('admin_mobiles', '')) as $m) {
            if (mobile($m)) {
                $this->send('admin_new_order', $m, $data);
            }
        }
    }

    public function orderStatus(Order $o): void
    {
        $event = match ($o->status) {
            'processing' => 'customer_processing',
            'settling' => 'customer_settling',
            'to_freight' => 'customer_to_freight',
            'shipped' => 'customer_shipped',
            'completed' => 'customer_completed',
            'cancelled' => 'customer_cancelled',
            default => null,
        };
        if ($event) {
            $this->forOrder($o, $event, $this->orderData($o));
        }
    }

    /* ---------------- درایورها ---------------- */

    protected function dispatch(array $gw, string $to, string $pattern, array $vars, string $text): array
    {
        $type = $gw['type'] ?? '';
        $key = trim((string) ($gw['apikey'] ?? ''));
        $sender = trim((string) ($gw['sender'] ?? ''));
        if ($type !== 'custom' && $key === '') {
            return ['ok' => false, 'msg' => 'کلید API وارد نشده است.'];
        }
        if ($pattern === '' && trim($text) === '') {
            return ['ok' => false, 'msg' => 'برای این پیام نه کد الگو تعریف شده و نه متن.'];
        }
        $rcpt = '+98'.substr($to, 1);
        $vars = array_map('strval', $vars);

        switch ($type) {
            case 'iranpayamak':
                $line = static::ipLine($sender);
                $base = 'https://api.iranpayamak.com/ws/v1';
                $h = ['Api-Key' => $key];
                if ($pattern !== '') {
                    $r = $this->http('POST', $base.'/sms/pattern', $h, ['code' => $pattern, 'attributes' => (object) $vars, 'recipient' => $to, 'line_number' => $line, 'number_format' => 'english']);
                } else {
                    $r = $this->http('POST', $base.'/sms/simple', $h, ['text' => $text, 'recipients' => [$to], 'line_number' => $line, 'number_format' => 'english']);
                }
                $ok = ! isset($r['_error']) && strtolower((string) ($r['status'] ?? '')) === 'success';
                if ($ok) {
                    $id = is_array($r['data'] ?? null) ? ($r['data']['id'] ?? '') : ($r['data'] ?? '');

                    return ['ok' => true, 'msg' => ($pattern !== '' ? 'ثبت شد' : 'ثبت شد (ارسال ساده؛ منتظر تأیید اپراتور)').($id !== '' ? ' — شناسه '.$id : '')];
                }

                return ['ok' => false, 'msg' => static::ipError($r)];

            case 'faraz':
                $sender = static::e164Line($sender);
                $body = $pattern !== ''
                    ? ['sending_type' => 'pattern', 'from_number' => $sender, 'code' => $pattern, 'recipients' => [$rcpt], 'params' => (object) $vars]
                    : ['sending_type' => 'webservice', 'from_number' => $sender, 'message' => $text, 'params' => ['recipients' => [$rcpt]]];
                $r = $this->http('POST', 'https://edge.ippanel.com/v1/api/send', ['Authorization' => trim(preg_replace('/^(Bearer|AccessKey)\s+/i', '', $key))], $body);
                $ok = ! empty($r['meta']['status']);
                if ($ok) {
                    return ['ok' => true, 'msg' => 'ارسال شد'.(! empty($r['data']['message_outbox_ids'][0]) ? ' — شناسه '.$r['data']['message_outbox_ids'][0] : '')];
                }
                $errs = [];
                array_walk_recursive($r['meta']['errors'] ?? [], function ($x) use (&$errs) { $errs[] = (string) $x; });
                $hint = match ((string) ($r['meta']['message_code'] ?? '')) {
                    '400-1' => ' (کلید API اشتباه یا منقضی است؛ در پنل فراز: توسعه‌دهندگان ← کلیدهای دسترسی)',
                    default => (int) ($r['_http'] ?? 0) === 401 ? ' (کلید API نادرست)' : '',
                };

                return ['ok' => false, 'msg' => $this->err($r, ['meta', 'message']).($errs ? ' — '.implode('، ', array_unique($errs)) : '').$hint
                    .' [خط: '.$sender.($pattern !== '' ? '، الگو: '.$pattern.'، متغیرها: '.implode('، ', array_keys($vars)) : '، بدون الگو').']'];

            case 'ippanel':
                $r = $pattern !== ''
                    ? $this->http('POST', 'https://api2.ippanel.com/api/v1/sms/pattern/normal/send', ['apikey' => $key], ['code' => $pattern, 'sender' => $sender, 'recipient' => $rcpt, 'variable' => (object) $vars])
                    : $this->http('POST', 'https://api2.ippanel.com/api/v1/sms/send/webservice/single', ['apikey' => $key], ['recipient' => [$rcpt], 'sender' => $sender, 'message' => $text, 'description' => 'site']);
                $ok = isset($r['data']['message_id']) || strtoupper((string) ($r['status'] ?? '')) === 'OK';

                return ['ok' => $ok, 'msg' => $ok ? 'ارسال شد' : $this->err($r, ['error_message'])];

            case 'kavenegar':
                $base = 'https://api.kavenegar.com/v1/'.rawurlencode($key);
                if ($pattern !== '') {
                    $q = ['receptor' => $to, 'template' => $pattern];
                    $slots = ['token', 'token2', 'token3'];
                    $i = 0;
                    foreach ($vars as $n => $v) {
                        if (in_array($n, ['token', 'token2', 'token3', 'token10', 'token20'], true)) {
                            $k = $n;
                        } elseif (isset($slots[$i])) {
                            $k = $slots[$i++];
                        } else {
                            continue;
                        }
                        $q[$k] = in_array($k, ['token10', 'token20'], true) ? $v : str_replace(' ', "\u{200C}", $v);
                    }
                    $r = $this->http('POST', $base.'/verify/lookup.json', [], $q, 'form');
                } else {
                    $r = $this->http('POST', $base.'/sms/send.json', [], ['receptor' => $to, 'sender' => $sender, 'message' => $text], 'form');
                }
                $ok = (int) ($r['return']['status'] ?? 0) === 200;

                return ['ok' => $ok, 'msg' => $ok ? 'ارسال شد' : $this->err($r, ['return', 'message'])];

            case 'melipayamak':
                $k = rawurlencode($key);
                $r = $pattern !== ''
                    ? $this->http('POST', 'https://console.melipayamak.com/api/send/shared/'.$k, [], ['bodyId' => (int) $pattern, 'to' => $to, 'args' => array_values($vars)])
                    : $this->http('POST', 'https://console.melipayamak.com/api/send/simple/'.$k, [], ['from' => $sender, 'to' => $to, 'text' => $text]);
                $ok = isset($r['recId']) && (float) $r['recId'] > 100 && empty($r['status']);

                return ['ok' => $ok, 'msg' => $ok ? 'ارسال شد' : $this->err($r, ['status'])];

            case 'smsir':
                if ($pattern !== '') {
                    $params = [];
                    foreach ($vars as $n => $v) {
                        $params[] = ['name' => (string) $n, 'value' => $v];
                    }
                    $r = $this->http('POST', 'https://api.sms.ir/v1/send/verify', ['X-API-KEY' => $key], ['mobile' => $to, 'templateId' => (int) $pattern, 'parameters' => $params]);
                } else {
                    $r = $this->http('POST', 'https://api.sms.ir/v1/send/bulk', ['X-API-KEY' => $key], ['lineNumber' => (int) preg_replace('/\D/', '', $sender), 'messageText' => $text, 'mobiles' => [$to]]);
                }
                $ok = (int) ($r['status'] ?? 0) === 1;

                return ['ok' => $ok, 'msg' => $ok ? 'ارسال شد' : $this->err($r, ['message'])];

            case 'custom':
                $url = trim((string) ($gw['url'] ?? ''));
                if (! $url) {
                    return ['ok' => false, 'msg' => 'آدرس ارسال وارد نشده است.'];
                }
                if (trim($text) === '') {
                    $text = implode(' ', $vars);
                }
                $url = str_replace(['{to}', '{text}', '{code}'], [rawurlencode($to), rawurlencode($text), rawurlencode($vars['code'] ?? '')], $url);
                $resp = Http::timeout(10)->get($url);

                return ['ok' => $resp->successful(), 'msg' => 'کد پاسخ '.$resp->status()];
        }

        return ['ok' => false, 'msg' => 'نوع پنل نامعتبر است.'];
    }

    /** اعتبار حساب پنل (متن قابل نمایش) */
    public function credit(array $gw): string
    {
        $k = trim((string) ($gw['apikey'] ?? ''));
        if ($k === '') {
            return '';
        }
        try {
            switch ($gw['type'] ?? '') {
                case 'iranpayamak':
                    $r = $this->http('GET', 'https://api.iranpayamak.com/ws/v1/account/balance', ['Api-Key' => $k]);
                    if (strtolower((string) ($r['status'] ?? '')) !== 'success') {
                        return static::ipError($r);
                    }
                    $d = $r['data'] ?? null;
                    $n = is_numeric($d) ? $d : (is_array($d) ? ($d['balance'] ?? $d['credit'] ?? $d['amount'] ?? $d['wallet'] ?? null) : null);

                    return is_numeric($n) ? 'اتصال برقرار است — موجودی: '.fa(number_format((float) $n)).' ریال' : 'اتصال برقرار است — '.mb_substr(json_encode($d, JSON_UNESCAPED_UNICODE), 0, 200);
                case 'faraz':
                case 'ippanel':
                    $r = $this->http('GET', 'https://api2.ippanel.com/api/v1/sms/accounting/credit/show', ['apikey' => $k]);

                    return isset($r['data']['credit']) ? fa(number_format((float) $r['data']['credit'])).' ریال' : $this->err($r, ['error_message']);
                case 'kavenegar':
                    $r = $this->http('GET', 'https://api.kavenegar.com/v1/'.rawurlencode($k).'/account/info.json');

                    return isset($r['entries']['remaincredit']) ? fa(number_format((float) $r['entries']['remaincredit'])).' ریال' : $this->err($r, ['return', 'message']);
                case 'melipayamak':
                    $r = $this->http('GET', 'https://console.melipayamak.com/api/receive/credit/'.rawurlencode($k));

                    return isset($r['amount']) ? fa(number_format((float) $r['amount'], 1)).' پیامک' : $this->err($r, ['status']);
                case 'smsir':
                    $r = $this->http('GET', 'https://api.sms.ir/v1/credit', ['X-API-KEY' => $k]);

                    return isset($r['data']) && is_numeric($r['data']) ? fa(number_format((float) $r['data'], 1)).' پیامک' : $this->err($r, ['message']);
            }
        } catch (Throwable $e) {
            return 'خطا: '.$e->getMessage();
        }

        return '';
    }

    /** خط فرستنده ایران پیامک: فقط رقم، بدون +98 */
    public static function ipLine(string $sender): string
    {
        $d = preg_replace('/\D/', '', strtr($sender, array_combine(['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'], range(0, 9))));
        if (str_starts_with($d, '0098')) {
            $d = substr($d, 4);
        } elseif (str_starts_with($sender, '+98') && str_starts_with($d, '98')) {
            $d = substr($d, 2);
        }

        return $d !== '' ? $d : '90008361';
    }

    /** پیام خطای خوانا از پاسخ ایران پیامک */
    /** شماره خط ارسال به قالب بین‌المللی (+98…) که پنل جدید فراز/آی‌پی‌پنل می‌خواهد */
    public static function e164Line(string $line): string
    {
        $d = preg_replace('/\D/', '', en_digits($line));
        if ($d === '') {
            return $line;
        }
        if (str_starts_with($d, '0098')) {
            $d = substr($d, 4);
        } elseif (str_starts_with($d, '98')) {
            $d = substr($d, 2);
        } elseif (str_starts_with($d, '0')) {
            $d = substr($d, 1);
        }

        return '+98'.$d;
    }

    public static function ipError(array $r): string
    {
        if (isset($r['_error'])) {
            return $r['_error'];
        }
        $http = (int) ($r['_http'] ?? 0);
        $parts = [];
        foreach (['message', 'messages', 'errors', 'data'] as $k) {
            $v = $r[$k] ?? null;
            if (is_string($v) && $v !== '') {
                $parts[] = $v;
            } elseif (is_array($v) && $k !== 'data') {
                array_walk_recursive($v, function ($x) use (&$parts) {
                    if (is_scalar($x) && (string) $x !== '') {
                        $parts[] = (string) $x;
                    }
                });
            }
        }
        $msg = $parts ? implode(' — ', array_unique($parts)) : 'خطای نامشخص';
        $hint = match ($http) {
            401, 403 => ' | کلید API نادرست است یا به‌جای کلید API ثابت، توکن ورود وارد شده.',
            404 => ' | کد الگو (UID پترن) یا خط فرستنده پیدا نشد.',
            422 => ' | فیلدها نامعتبر است: نام متغیرهای الگو، کد الگو یا شماره خط را بررسی کنید.',
            429 => ' | بیش از ۶۰ درخواست در دقیقه؛ کمی بعد دوباره امتحان کنید.',
            default => '',
        };

        return strip_tags($msg).($http ? ' (HTTP '.$http.')' : '').$hint;
    }

    /**
     * پاسخ HTML به‌جای JSON (معمولاً صفحه خطای فایروال): عنوان صفحه + علت احتمالی + IP سرور
     */
    public static function htmlError(int $status, string $body, string $url): string
    {
        $host = (string) parse_url($url, PHP_URL_HOST);
        $title = preg_match('~<title[^>]*>(.*?)</title>~is', $body, $m) ? trim(html_entity_decode(strip_tags($m[1]))) : '';
        $text = trim(preg_replace('/\s+/u', ' ', strip_tags(preg_replace('~<(script|style)\b.*?</\1>~is', '', $body))));
        $low = strtolower($body);
        $who = match (true) {
            str_contains($low, 'arvancloud') || str_contains($low, 'arvan') => 'فایروال ابر آروان',
            str_contains($low, 'cloudflare') => 'فایروال Cloudflare',
            str_contains($low, 'imunify') || str_contains($low, 'mod_security') || str_contains($low, 'modsecurity') => 'فایروال هاست (Imunify/ModSecurity)',
            str_contains($low, 'litespeed') => 'وب‌سرور LiteSpeed',
            default => '',
        };
        $msg = 'پاسخ نامعتبر از '.$host.' (HTTP '.$status.')'.($who ? ' — '.$who : '').($title ? ' — «'.mb_substr($title, 0, 80).'»' : ($text ? ' — '.mb_substr($text, 0, 120) : ''));
        if (in_array($status, [401, 403, 451], true)) {
            $ip = static::serverIp();
            $msg .= ' | درخواست سایت پیش از رسیدن به وب‌سرویس رد شد (صفحه HTML به‌جای پاسخ پنل). علت‌های رایج: '
                .'۱) در پنل پیامک «محدودیت IP» برای کلید API فعال است و IP سرور سایت'.($ip ? ' ('.$ip.')' : '').' در فهرست مجاز نیست؛ '
                .'۲) سرور سایت خارج از ایران است و پنل پیامک درخواست‌های خارجی را نمی‌پذیرد؛ '
                .'۳) فایروال هاست ارتباط خروجی را بسته است. IP سرور سایت (در «تنظیمات پیامک ← اعتبار و اتصال پنل‌ها») را برای پشتیبانی پنل پیامک بفرستید.';
        }

        return $msg;
    }

    /** IP خروجی سرور سایت (برای ثبت در «IP مجاز» پنل پیامک) */
    public static function serverIp(): string
    {
        return (string) \Illuminate\Support\Facades\Cache::remember('server.out_ip', 3600, function () {
            foreach (['https://api.ipify.org', 'https://ifconfig.me/ip', 'https://icanhazip.com'] as $u) {
                try {
                    $r = Http::timeout(5)->connectTimeout(4)->get($u);
                    $ip = trim((string) $r->body());
                    if ($r->successful() && filter_var($ip, FILTER_VALIDATE_IP)) {
                        return $ip;
                    }
                } catch (Throwable) {
                }
            }

            return (string) ($_SERVER['SERVER_ADDR'] ?? '');
        });
    }

    /** آخرین پاسخ خام پنل (برای تشخیص ارسال موفق با پاسخ غیرمعمول و ثبت در گزارش) */
    public ?array $lastResp = null;

    protected function http(string $method, string $url, array $headers = [], ?array $body = null, string $format = 'json'): array
    {
        $this->lastResp = null;
        try {
            $req = Http::timeout(20)->connectTimeout(6)->acceptJson()
                ->withHeaders(['User-Agent' => 'Mozilla/5.0 (compatible; StoreSms/1.0; +'.config('app.url').')'] + $headers);
            if ($format === 'form') {
                $req = $req->asForm();
            }
            $resp = $method === 'GET' ? $req->get($url) : $req->post($url, $body ?? []);
        } catch (\Illuminate\Http\Client\RequestException $e) {
            $resp = $e->response;
        } catch (Throwable $e) {
            $m = $e->getMessage();
            // درخواست فرستاده شده ولی پاسخ دیر رسیده: ممکن است پیامک ارسال شده باشد
            $timeout = str_contains($m, 'cURL error 28') && ! str_contains($m, 'Connection timed out') && ! str_contains($m, 'Resolving timed out');

            return $this->lastResp = ['_error' => 'اتصال برقرار نشد: '.mb_substr($m, 0, 200), '_timeout' => $timeout];
        }
        $json = $resp->json();
        if (! is_array($json)) {
            return $this->lastResp = ['_error' => static::htmlError($resp->status(), (string) $resp->body(), $url), '_http' => $resp->status(), '_raw' => mb_substr($resp->body(), 0, 300)];
        }
        $json['_http'] = $resp->status();

        return $this->lastResp = $json;
    }

    /**
     * پاسخ پنل نشان می‌دهد پیام پذیرفته شده، حتی اگر قالبش با آنچه انتظار داشتیم فرق کند
     * (پنل‌ها گاهی قالب پاسخ را عوض می‌کنند). فقط با کد HTTP موفق و بدون نشانه خطا.
     */
    public static function looksSent(?array $r): bool
    {
        if (! $r || isset($r['_error']) || (int) ($r['_http'] ?? 0) < 200 || (int) ($r['_http'] ?? 0) >= 300) {
            return false;
        }
        $flat = [];
        array_walk_recursive($r, function ($v, $k) use (&$flat) {
            $flat[strtolower((string) $k)][] = $v;
        });
        foreach (['status', 'state', 'result', 'success', 'ok', 'statuscode', 'status_code', 'code'] as $k) {
            foreach ($flat[$k] ?? [] as $v) {
                $sv = strtolower(trim((string) (is_bool($v) ? ($v ? 'true' : 'false') : $v)));
                if (in_array($sv, ['error', 'failed', 'fail', 'false', 'unauthorized', 'forbidden'], true)) {
                    return false;
                }
            }
        }
        foreach (['status', 'state', 'result', 'success', 'ok'] as $k) {
            foreach ($flat[$k] ?? [] as $v) {
                $sv = strtolower(trim((string) (is_bool($v) ? ($v ? 'true' : 'false') : $v)));
                if (in_array($sv, ['success', 'successful', 'ok', 'true', '1', '200', 'sent', 'done', 'queued', 'accepted'], true)) {
                    return true;
                }
            }
        }
        foreach (['message_id', 'messageid', 'messageids', 'recid', 'bulk_id', 'bulkid', 'packid', 'pack_id', 'messageid', 'id'] as $k) {
            foreach ($flat[$k] ?? [] as $v) {
                if (is_numeric($v) ? (float) $v > 0 : (is_string($v) && strlen($v) > 6)) {
                    return true;
                }
            }
        }

        return false;
    }

    protected function err(array $r, array $path): string
    {
        if (isset($r['_error'])) {
            return $r['_error'];
        }
        $v = $r;
        foreach ($path as $p) {
            if (! is_array($v) || ! isset($v[$p])) {
                $v = null;
                break;
            }
            $v = $v[$p];
        }
        if (is_array($v)) {
            $v = json_encode($v, JSON_UNESCAPED_UNICODE);
        }
        $msg = $v ? strip_tags((string) $v) : 'خطای نامشخص';

        return isset($r['_http']) ? $msg.' (HTTP '.$r['_http'].')' : $msg;
    }
}
