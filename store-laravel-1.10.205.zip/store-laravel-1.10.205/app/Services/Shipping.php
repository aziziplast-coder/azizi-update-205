<?php

namespace App\Services;

use App\Models\Order;
use App\Models\User;
use App\Support\DocImages;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Throwable;

/**
 * مسیر پس از تسویه:
 *   تسویه نقدی کامل + تأیید نهایی (همه فیش‌ها تأیید کارخانه‌دار / حواله بی‌کارخانه‌دار / تأیید دستی حسابدار کل)
 *     ← «در حال ارسال به باربری» (یا «در انتظار رسیدن چک» برای خرید نقد و چک)
 *   رسیدن و تأیید چک‌ها ← «در حال ارسال به باربری»
 *   بارگیری (سرپرست انبار، سربرگ «آماده ارسال») ← ثبت زمان بارگیری (وضعیت همان می‌ماند)
 *   بارگذاری بیجک (پنل یا اپ انبار) ← مشتری می‌بیند؛ بیجکِ دیرکرده در «بیجک ارسال نشده» با یادآوری مکرر
 * و کرایه حمل از شرکت تا باربری (هنگام تأیید نهایی بار یا بعداً) که به حساب مشتری اضافه می‌شود.
 */
class Shipping
{
    /** سفارش با باربری ارسال می‌شود؟ */
    public static function isFreight(Order $o): bool
    {
        $m = Checkout::shippingMethod((string) $o->shipping_method);
        if (! empty($m['freight']) || filled($o->freight_name) || $o->shipping_collect) {
            return true;
        }
        // سفارش‌هایی که شناسه شیوه ارسال ندارند (ثبت دستی/اپ) یا نام شیوه عوض شده: از روی عنوان
        $title = (string) ($o->shipping_title ?: ($m['title'] ?? ''));

        return (bool) preg_match('/باربر|پس[\x{200c}\s-]?کرایه|ترابری/u', $title);
    }

    /** خرید نقد و چک با چک‌هایی که باید برسد */
    public static function hasCheques(Order $o): bool
    {
        $c = (array) $o->cheque;

        return ! empty($c['settle']) || ($o->payment_method === 'cheque' && ! empty($c['cheques']));
    }

    /* ---------------- کرایه حمل تا باربری ---------------- */

    public static function setFreightFee(Order $o, ?int $fee, ?User $by = null): void
    {
        if (! static::isFreight($o)) {
            $fee = null; // تحویل حضوری از انبار / پست: کرایه باربری صفر
        }
        $old = $o->freight_fee;
        $o->freight_fee = $fee !== null && $fee > 0 ? $fee : null;
        if ((int) $old === (int) $o->freight_fee) {
            return;
        }
        $o->saveQuietly();
        Picking::recalc($o->fresh());
        $o->refresh();
        $o->log(($o->freight_fee ? 'کرایه حمل تا باربری '.money($o->freight_fee).' تومان' : 'کرایه حمل تا باربری حذف شد')
            .' ثبت شد — مبلغ سفارش: '.money($o->total).' تومان', $by?->id);
        // مانده صادرشده و واریزنشده قدیمی شده است
        $issued = \App\Models\RemitPayment::query()->where('order_id', $o->id)->where('kind', 'settle')->whereIn('status', ['awaiting', 'rejected'])->exists();
        if ($issued && $o->assignee_id) {
            app(WebPush::class)->toUsers([$o->assignee_id], ['title' => 'کرایه حمل سفارش '.fa($o->number).' ثبت شد',
                'body' => 'مانده حساب صادرشده را با «اصلاح مانده حساب» به‌روز کنید.', 'url' => url('/admin/orders/'.$o->id), 'tag' => 'freight-'.$o->id]);
        }
    }

    /* ---------------- وضعیت خودکار پس از تسویه ---------------- */

    /** پس از کامل شدن پرداخت نقدی */
    public static function afterPaid(Order $o): void
    {
        if ($o->status !== 'settling') {
            return;
        }
        if (static::hasCheques($o)) {
            // خرید نقد و چک: کارشناس پس از تأیید بیجک پستی چک‌ها یا رسیدن چک‌ها تصمیم می‌گیرد بار برای بارگیری برود یا نه
            $o->log('پرداخت نقدی کامل شد — ارسال برای بارگیری پس از تأیید بیجک پستی یا رسیدن چک‌ها (با تأیید کارشناس)');
            if ($o->assignee_id) {
                app(WebPush::class)->toUsers([$o->assignee_id], ['title' => 'نقد سفارش '.fa($o->number).' کامل شد',
                    'body' => 'پس از تأیید بیجک پستی یا رسیدن چک‌ها، «ارسال برای بارگیری» را تأیید کنید.', 'url' => url('/admin/orders/'.$o->id), 'tag' => 'paid-'.$o->id]);
            }

            return;
        }
        // تأیید نهایی: همه فیش‌ها به تأیید کارخانه‌دار رسیده؟ (یا حواله بی‌کارخانه‌دار / تأیید دستی حسابدار کل)
        if ($why = Remit::finalBlock($o)) {
            if (Cache::add('final-wait.'.$o->id, 1, 3600)) {
                $o->log('تسویه کامل است؛ «در حال ارسال به باربری» پس از تأیید نهایی — '.$why);
            }

            return;
        }
        $o->setStatus('shipped', 'تأیید نهایی سفارش (تسویه کامل و تأیید فیش‌ها)');
        static::notifyReady($o);
    }

    /** کارخانه‌دار فیشی را تأیید کرد / تأیید دستی ← اگر سفارش منتظر تأیید نهایی بود، جلو برود */
    public static function recheckFinal(?Order $o): void
    {
        if ($o && $o->status === 'settling' && $o->isPaid() && ! static::hasCheques($o)) {
            static::afterPaid($o);
        }
    }

    /** کارشناس: بار برای بارگیری (در صف ارسال به باربری) برود */
    public static function sendToLoading(Order $o, ?User $by = null, string $why = ''): void
    {
        if (! $o->isPaid()) {
            throw ValidationException::withMessages(['order' => 'پرداخت نقدی این سفارش هنوز کامل نشده است؛ پس از تأیید فیش‌ها دوباره تلاش کنید.']);
        }
        if (! in_array($o->status, ['settling', 'processing'], true)) {
            return;
        }
        if ($block = Remit::finalBlock($o)) {
            throw ValidationException::withMessages(['order' => 'تأیید نهایی سفارش انجام نشده: '.$block.'. پس از تأیید کارخانه‌دار (یا تأیید دستی حسابدار کل) دوباره بزنید.']);
        }
        $o->setStatus('shipped', trim('تأیید نهایی سفارش — ارسال برای بارگیری'.($why ? ' — '.$why : '').($by ? ' — '.$by->displayName() : '')));
        static::notifyReady($o);
    }

    /** رسیدن و تأیید چک‌ها (+ تصمیم ارسال برای بارگیری) */
    public static function chequesReceived(Order $o, ?User $by = null, bool $load = false): void
    {
        $o->forceFill(['cheques_received_at' => now()])->saveQuietly();
        $o->log('چک‌ها رسید و تأیید شد', $by?->id);
        if ($load) {
            static::sendToLoading($o, $by, 'چک‌ها رسید');
        }
    }

    /** خبر به سرپرست‌های انبار: باری برای ارسال آماده است */
    protected static function notifyReady(Order $o): void
    {
        try {
            $ids = User::query()->where('role', 'keeper')->where('pick_role', 'supervisor')->where('is_active', true)->pluck('id')->all();
            if ($ids) {
                app(WebPush::class)->toUsers($ids, ['title' => 'آماده ارسال — سفارش '.fa($o->number),
                    'body' => $o->customer_name.($o->freight_name ? ' — باربری '.$o->freight_name : '').($o->city ? ' — '.$o->city : ''),
                    'url' => url('/keeper?tab=ship'), 'tag' => 'ship-'.$o->id]);
            }
        } catch (Throwable $e) {
            report($e);
        }
    }

    /* ---------------- بارگیری و بیجک ---------------- */

    public static function markLoaded(Order $o, ?User $by = null, ?int $fee = null): void
    {
        if (! in_array($o->status, ['to_freight', 'shipped'], true) || $o->loaded_at) {
            throw ValidationException::withMessages(['order' => 'این سفارش آماده بارگیری نیست (یا قبلاً بارگیری شده).']);
        }
        if ($fee !== null) {
            static::setFreightFee($o, $fee, $by);
            $o->refresh();
        }
        $o->forceFill(['loaded_at' => now(), 'loaded_by' => $by?->id])->saveQuietly();
        if ($o->status === 'to_freight') {
            $o->setStatus('shipped', 'بارگیری و تحویل به باربری'.($by ? ' — '.$by->displayName() : ''));
        } else {
            $o->log('بارگیری و تحویل به باربری'.($by ? ' — '.$by->displayName() : ''), $by?->id);
        }
    }

    public static function uploadWaybill(Order $o, UploadedFile $file, ?User $by = null): void
    {
        $old = $o->waybill_path;
        $path = DocImages::store($file, 'waybills/'.$o->id, 'waybill-'.now()->format('YmdHis'));
        $first = ! $o->waybill_path;
        $o->forceFill(['waybill_path' => $path, 'waybill_at' => now(), 'waybill_nag_at' => null])->saveQuietly();
        if ($old && $old !== $path) {
            Storage::disk('local')->delete($old);
        }
        $o->log('بیجک باربری بارگذاری شد', $by?->id);
        // بیجک بارگذاری شد = بار تحویل باربری شده و سفارش تمام است
        if (in_array($o->status, ['to_freight', 'shipped'], true)) {
            if (! $o->loaded_at) {
                $o->forceFill(['loaded_at' => now(), 'loaded_by' => $by?->id])->saveQuietly();
            }
            $o->setStatus('completed', 'تکمیل خودکار پس از بارگذاری بیجک باربری', true, 'none');
        }
        if ($first) {
            app(Sms::class)->forOrder($o, 'customer_waybill');
            try {
                app(WebPush::class)->toUsers([$o->user_id], ['title' => 'بیجک سفارش '.fa($o->number), 'body' => 'بیجک باربری بارگذاری شد.',
                    'url' => route('order.show', $o->number), 'tag' => 'order-'.$o->id]);
            } catch (Throwable $e) {
                report($e);
            }
        }
        Cache::forget('waybill.overdue.count');
    }

    public static function hasDirect(): bool
    {
        return \App\Support\DbSchema::hasColumn('orders', 'direct_at');
    }

    /**
     * ارسال مستقیم: خاور باربری از انبار بار را مستقیم تا درِ مغازه مشتری می‌برد (بیجک باربری ندارد).
     * بارنامه و شماره راننده هر دو اختیاری‌اند؛ با شماره راننده به مشتری پیامک می‌رود.
     */
    public static function markDirect(Order $o, ?UploadedFile $file = null, ?string $driver = null, ?User $by = null): void
    {
        $driver = \App\Support\Banks::digits((string) $driver) ?: null;
        if ($driver && ! mobile($driver) && strlen($driver) < 8) {
            throw \Illuminate\Validation\ValidationException::withMessages(['driver' => 'شماره راننده درست نیست.']);
        }
        $data = ['direct_at' => now(), 'driver_phone' => $driver, 'waybill_nag_at' => null];
        if ($file) {
            $old = $o->waybill_path;
            $data['waybill_path'] = DocImages::store($file, 'waybills/'.$o->id, 'direct-'.now()->format('YmdHis'));
            $data['waybill_at'] = now();
            if ($old && $old !== $data['waybill_path']) {
                Storage::disk('local')->delete($old);
            }
        }
        $o->forceFill($data)->saveQuietly();
        $o->log('ارسال مستقیم (خاور تا درِ مغازه)'.($file ? ' — بارنامه بارگذاری شد' : '').($driver ? ' — راننده: '.fa($driver) : ''), $by?->id);
        if (in_array($o->status, ['to_freight', 'shipped'], true)) {
            if (! $o->loaded_at) {
                $o->forceFill(['loaded_at' => now(), 'loaded_by' => $by?->id])->saveQuietly();
            }
            $o->setStatus('completed', 'ارسال مستقیم به مشتری', true, 'none');
        }
        if ($driver) {
            app(Sms::class)->forOrder($o, 'customer_direct', ['driver' => fa($driver)]);
        }
        Cache::forget('waybill.overdue.count');
    }

    /** بایگانی: بیجک‌های بارگذاری‌شده و ارسال‌های مستقیم */
    public static function archiveQuery(): \Illuminate\Database\Eloquent\Builder
    {
        return Order::query()->where(fn ($q) => $q->whereNotNull('waybill_path')->when(static::hasDirect(), fn ($w) => $w->orWhereNotNull('direct_at')));
    }

    public static function waybillFile(Order $o): ?string
    {
        return $o->waybill_path && Storage::disk('local')->exists($o->waybill_path) ? Storage::disk('local')->path($o->waybill_path) : null;
    }

    /* ---------------- بیجک ارسال نشده ---------------- */

    public static function waybillHours(): int
    {
        return max(1, (int) setting('waybill_hours', 24));
    }

    /** سفارش‌های تحویل‌شده به باربری که در مهلت، بیجکشان بارگذاری نشده */
    public static function overdueQuery(): \Illuminate\Database\Eloquent\Builder
    {
        $limit = now()->subHours(static::waybillHours());

        return Order::query()->whereNull('waybill_path')->when(static::hasDirect(), fn ($q) => $q->whereNull('direct_at'))
            ->where(fn ($w) => $w->where('status', 'shipped')->orWhere(fn ($c) => static::completedNoWaybill($c)))
            ->where(fn ($q) => $q->where('loaded_at', '<=', $limit)->orWhere(fn ($w) => $w->whereNull('loaded_at')->where('status', 'completed')->where('status_changed_at', '<=', $limit)))
            ->where('status_changed_at', '>=', now()->subDays(60)); // سفارش‌های خیلی قدیمی (پیش از این امکان) یادآوری نمی‌شوند
    }

    /** سفارش‌هایی که هنوز در مهلت‌اند (برای نمایش زمان باقی‌مانده) */
    public static function pendingQuery(): \Illuminate\Database\Eloquent\Builder
    {
        return Order::query()->whereNull('waybill_path')->when(static::hasDirect(), fn ($q) => $q->whereNull('direct_at'))->where('status_changed_at', '>=', now()->subDays(60))
            ->where(fn ($w) => $w->where('status', 'shipped')->orWhere(fn ($c) => static::completedNoWaybill($c)));
    }

    /** سفارش باربری که دستی «تکمیل شده» خورده ولی بیجکش هنوز بارگذاری نشده (۳۰ روز اخیر) */
    public static function completedNoWaybill($q)
    {
        // فقط سفارش‌هایی که از کارتابل انبار رد شده‌اند (سفارش‌های قدیمیِ پیش از این روال جدا رسیدگی شده‌اند)
        return static::freightScope($q->where('status', 'completed')->where('status_changed_at', '>=', now()->subDays(30))
            ->where(fn ($w) => $w->where('pick_round', '>', 0)->orWhereNotNull('loaded_at')));
    }

    /** شرط SQL «ارسال با باربری» (هم‌معنی isFreight) */
    public static function freightScope($q)
    {
        $ids = collect(Checkout::shippingMethods())->filter(fn ($m) => ! empty($m['freight']))->keys()->all();

        return $q->where(fn ($w) => $w->whereIn('shipping_method', $ids ?: ['__none__'])
            ->orWhere(fn ($x) => $x->whereNotNull('freight_name')->where('freight_name', '!=', ''))
            ->orWhere('shipping_collect', true)
            ->orWhere('shipping_title', 'like', '%باربر%')->orWhere('shipping_title', 'like', '%کرایه%')->orWhere('shipping_title', 'like', '%ترابری%'));
    }

    /** بیجک این سفارش هنوز لازم است؟ (باربری، بیجک ندارد، ارسال مستقیم هم نشده) */
    public static function needsWaybill(Order $o): bool
    {
        return static::isFreight($o) && ! $o->waybill_path && ! (static::hasDirect() && $o->direct_at);
    }

    public static function overdueCount(): int
    {
        return (int) Cache::remember('waybill.overdue.count', 120, fn () => static::overdueQuery()->count());
    }

    /** مهلت بیجک یک سفارش */
    public static function deadline(Order $o): ?\Illuminate\Support\Carbon
    {
        $from = $o->loaded_at ?? $o->status_changed_at;

        return $from?->copy()->addHours(static::waybillHours());
    }

    /** یادآوری مکرر (هر ۳ ساعت) به مسئول سفارش و کسانی که دسترسی سفارش دارند */
    public static function nagWaybills(): void
    {
        if (! Cache::add('waybill.nag.tick', 1, 600)) {
            return;
        }
        $every = max(1, (int) setting('waybill_nag_hours', 3));
        $list = static::overdueQuery()->where(fn ($q) => $q->whereNull('waybill_nag_at')->orWhere('waybill_nag_at', '<=', now()->subHours($every)))->limit(30)->get();
        if ($list->isEmpty()) {
            return;
        }
        $admins = User::query()->where('role', 'admin')->where('is_active', true)->pluck('id')->all();
        foreach ($list as $o) {
            $to = array_values(array_unique(array_filter(array_merge([$o->assignee_id, $o->loaded_by], $admins))));
            try {
                app(WebPush::class)->toUsers($to, ['title' => '⚠️ بیجک ارسال نشده — سفارش '.fa($o->number),
                    'body' => $o->customer_name.' — '.fa((int) now()->diffInHours($o->loaded_at ?? $o->status_changed_at)).' ساعت از تحویل به باربری گذشته',
                    'url' => url('/admin/waybills'), 'tag' => 'waybill-'.$o->id]);
            } catch (Throwable $e) {
                report($e);
            }
            $o->forceFill(['waybill_nag_at' => now()])->saveQuietly();
        }
    }
}
