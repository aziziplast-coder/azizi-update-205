<?php

namespace App\Services;

use App\Models\Order;
use App\Models\PushSubscription;
use App\Models\Setting;
use Illuminate\Support\Facades\Http;
use RuntimeException;
use Throwable;

/**
 * اعلان مرورگر (Web Push) بدون کتابخانه بیرونی: VAPID (ES256) + رمزنگاری aes128gcm (RFC 8291).
 */
class WebPush
{
    /** کلیدهای VAPID؛ اولین بار ساخته و در تنظیمات ذخیره می‌شود */
    public static function keys(): array
    {
        $saved = setting('push_vapid');
        if (is_array($saved) && ! empty($saved['public']) && ! empty($saved['private'])) {
            return $saved;
        }
        $key = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
        if (! $key) {
            throw new RuntimeException('ساخت کلید اعلان ممکن نشد (افزونه OpenSSL).');
        }
        openssl_pkey_export($key, $pem);
        $d = openssl_pkey_get_details($key)['ec'];
        $keys = ['public' => static::b64(static::point($d['x'], $d['y'])), 'private' => $pem];
        \App\Support\Settings::set(['push_vapid' => $keys]);

        return $keys;
    }

    public static function supported(): bool
    {
        return function_exists('openssl_pkey_new') && function_exists('openssl_pkey_derive') && in_array('aes-128-gcm', openssl_get_cipher_methods(), true);
    }

    public static function enabled(): bool
    {
        return (bool) setting('push_enabled', false) && static::supported();
    }

    /* ---------------- ارسال ---------------- */

    /**
     * @param  iterable<PushSubscription>  $subs
     * @return array{sent: int, failed: int}
     */
    public function send(iterable $subs, array $payload): array
    {
        $sent = 0;
        $failed = 0;
        $errors = [];
        $json = json_encode($payload + ['icon' => route('pwa.icon', 192), 'badge' => route('pwa.icon', 96)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        foreach ($subs as $sub) {
            $r = $this->attempt($sub->endpoint, $sub->p256dh, $sub->auth, $json);
            if ($r['ok']) {
                $sent++;
                $sub->forceFill(['last_ok_at' => now()])->saveQuietly();
            } else {
                $failed++;
                $errors[$r['reason']] = ($errors[$r['reason']] ?? 0) + 1;
                if (in_array($r['status'], [404, 410], true)) {
                    $sub->delete(); // اشتراک منقضی شده
                }
            }
        }
        if ($errors) {
            \Illuminate\Support\Facades\Cache::put('push.last_errors', ['at' => now()->toIso8601String(), 'errors' => $errors], 86400 * 7);
        }

        return ['sent' => $sent, 'failed' => $failed, 'errors' => $errors];
    }

    /**
     * ارسال با گزارش علت خطا
     *
     * @return array{ok: bool, status: int, reason: string, service: string}
     */
    public function attempt(string $endpoint, string $p256dh, string $auth, string $json): array
    {
        $service = static::service($endpoint);
        try {
            $body = static::encrypt($json, static::unb64($p256dh), static::unb64($auth));
            $keys = static::keys();
            $parts = parse_url($endpoint);
            $aud = $parts['scheme'].'://'.$parts['host'].(isset($parts['port']) ? ':'.$parts['port'] : '');
            $resp = Http::connectTimeout(5)->timeout(12)->withHeaders([
                'TTL' => '86400',
                'Urgency' => 'normal',
                'Content-Encoding' => 'aes128gcm',
                'Content-Type' => 'application/octet-stream',
                'Authorization' => 'vapid t='.static::jwt($aud, $keys['private']).', k='.$keys['public'],
            ])->withBody($body, 'application/octet-stream')->post($endpoint);
        } catch (\Illuminate\Http\Client\ConnectionException $e) {
            return ['ok' => false, 'status' => 0, 'service' => $service, 'reason' => 'سرور سایت به سرویس اعلان '.$service.' دسترسی ندارد (اتصال برقرار نشد). روی هاست‌های داخل ایران دسترسی به سرویس اعلان گوگل/موزیلا معمولاً بسته است.'];
        } catch (Throwable $e) {
            if (preg_match('/status code (\d{3})/', $e->getMessage(), $m)) {
                $resp = null;
                $st = (int) $m[1];
            } else {
                return ['ok' => false, 'status' => 0, 'service' => $service, 'reason' => 'خطا: '.$e->getMessage()];
            }
        }
        $st = isset($resp) && $resp ? $resp->status() : ($st ?? 0);
        if ($st >= 200 && $st < 300) {
            return ['ok' => true, 'status' => $st, 'service' => $service, 'reason' => ''];
        }
        $msg = isset($resp) && $resp ? trim(strip_tags(mb_substr((string) $resp->body(), 0, 160))) : '';
        $reason = match (true) {
            in_array($st, [404, 410], true) => 'اشتراک منقضی شده بود و حذف شد (کاربر باید دوباره اعلان را فعال کند).',
            $st === 403 => 'سرویس '.$service.' درخواست را رد کرد (403). اگر هاست در ایران است، گوگل درخواست‌های آی‌پی ایران را نمی‌پذیرد؛ یا کلیدهای اعلان عوض شده‌اند.',
            $st === 401 => 'امضای VAPID پذیرفته نشد (401). کلیدها عوض شده‌اند؛ کاربران باید دوباره عضو شوند.',
            $st === 413 => 'متن اعلان بیش از حد بلند است.',
            $st === 429 => 'ارسال زیاد؛ سرویس اعلان موقتاً محدود کرده است.',
            default => 'پاسخ '.$st.' از '.$service.($msg !== '' ? ': '.$msg : ''),
        };

        return ['ok' => false, 'status' => $st, 'service' => $service, 'reason' => $reason];
    }

    public static function service(string $endpoint): string
    {
        $h = strtolower((string) parse_url($endpoint, PHP_URL_HOST));

        return match (true) {
            str_contains($h, 'googleapis') => 'گوگل (کروم/اندروید)',
            str_contains($h, 'mozilla') => 'موزیلا (فایرفاکس)',
            str_contains($h, 'apple') => 'اپل (سافاری/آیفون)',
            str_contains($h, 'windows') || str_contains($h, 'notify') => 'مایکروسافت (اج)',
            default => $h,
        };
    }

    /** ارسال به یک اشتراک؛ خروجی کد HTTP */
    public function sendOne(string $endpoint, string $p256dh, string $auth, string $payload, int $ttl = 86400): int
    {
        $body = static::encrypt($payload, static::unb64($p256dh), static::unb64($auth));
        $keys = static::keys();
        $parts = parse_url($endpoint);
        $aud = $parts['scheme'].'://'.$parts['host'].(isset($parts['port']) ? ':'.$parts['port'] : '');
        $jwt = static::jwt($aud, $keys['private']);
        $resp = Http::connectTimeout(5)->timeout(12)->withHeaders([
            'TTL' => (string) $ttl,
            'Urgency' => 'normal',
            'Content-Encoding' => 'aes128gcm',
            'Content-Type' => 'application/octet-stream',
            'Authorization' => 'vapid t='.$jwt.', k='.$keys['public'],
        ])->withBody($body, 'application/octet-stream')->post($endpoint);

        return $resp->status();
    }

    /* ---------------- رمزنگاری (RFC 8291) ---------------- */

    public static function encrypt(string $payload, string $uaPublic, string $authSecret, ?string $salt = null, $asKey = null): string
    {
        $salt ??= random_bytes(16);
        $asKey ??= openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
        $d = openssl_pkey_get_details($asKey)['ec'];
        $asPublic = static::point($d['x'], $d['y']);
        $shared = openssl_pkey_derive(static::publicKeyFromPoint($uaPublic), $asKey, 32);
        if ($shared === false) {
            throw new RuntimeException('ECDH failed');
        }
        $shared = str_pad($shared, 32, "\0", STR_PAD_LEFT);
        $prkKey = hash_hmac('sha256', $shared, $authSecret, true);
        $ikm = hash_hmac('sha256', "WebPush: info\0".$uaPublic.$asPublic."\x01", $prkKey, true);
        $prk = hash_hmac('sha256', $ikm, $salt, true);
        $cek = substr(hash_hmac('sha256', "Content-Encoding: aes128gcm\0\x01", $prk, true), 0, 16);
        $nonce = substr(hash_hmac('sha256', "Content-Encoding: nonce\0\x01", $prk, true), 0, 12);
        $tag = '';
        $cipher = openssl_encrypt($payload."\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16);

        return $salt.pack('N', 4096).chr(strlen($asPublic)).$asPublic.$cipher.$tag;
    }

    /** رمزگشایی (فقط برای آزمون؛ کار مرورگر را شبیه‌سازی می‌کند) */
    public static function decrypt(string $body, $uaKey, string $authSecret): string
    {
        $salt = substr($body, 0, 16);
        $idlen = ord($body[20]);
        $asPublic = substr($body, 21, $idlen);
        $rest = substr($body, 21 + $idlen);
        $d = openssl_pkey_get_details($uaKey)['ec'];
        $uaPublic = static::point($d['x'], $d['y']);
        $shared = str_pad(openssl_pkey_derive(static::publicKeyFromPoint($asPublic), $uaKey, 32), 32, "\0", STR_PAD_LEFT);
        $prkKey = hash_hmac('sha256', $shared, $authSecret, true);
        $ikm = hash_hmac('sha256', "WebPush: info\0".$uaPublic.$asPublic."\x01", $prkKey, true);
        $prk = hash_hmac('sha256', $ikm, $salt, true);
        $cek = substr(hash_hmac('sha256', "Content-Encoding: aes128gcm\0\x01", $prk, true), 0, 16);
        $nonce = substr(hash_hmac('sha256', "Content-Encoding: nonce\0\x01", $prk, true), 0, 12);
        $plain = openssl_decrypt(substr($rest, 0, -16), 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, substr($rest, -16));

        return rtrim((string) $plain, "\x02\0");
    }

    public static function jwt(string $aud, string $privatePem): string
    {
        $sub = setting('email') ? 'mailto:'.setting('email') : url('/');
        $h = static::b64(json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
        $c = static::b64(json_encode(['aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => $sub], JSON_UNESCAPED_SLASHES));
        openssl_sign($h.'.'.$c, $der, $privatePem, OPENSSL_ALGO_SHA256);

        return $h.'.'.$c.'.'.static::b64(static::derToRaw($der));
    }

    /** امضای DER به r||s (۶۴ بایت) */
    public static function derToRaw(string $der): string
    {
        $pos = 2;
        if (ord($der[1]) & 0x80) {
            $pos += ord($der[1]) & 0x7F;
        }
        $out = '';
        for ($i = 0; $i < 2; $i++) {
            $pos++; // 0x02
            $len = ord($der[$pos++]);
            $int = substr($der, $pos, $len);
            $pos += $len;
            $out .= str_pad(ltrim($int, "\0"), 32, "\0", STR_PAD_LEFT);
        }

        return $out;
    }

    protected static function point(string $x, string $y): string
    {
        return "\x04".str_pad($x, 32, "\0", STR_PAD_LEFT).str_pad($y, 32, "\0", STR_PAD_LEFT);
    }

    protected static function publicKeyFromPoint(string $point)
    {
        $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200').$point;
        $pem = "-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($der), 64, "\n")."-----END PUBLIC KEY-----\n";

        return openssl_pkey_get_public($pem);
    }

    public static function b64(string $bin): string
    {
        return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
    }

    public static function unb64(string $s): string
    {
        $s = strtr($s, '-_', '+/');

        return (string) base64_decode($s.str_repeat('=', (4 - strlen($s) % 4) % 4));
    }

    /* ---------------- رویدادها ---------------- */

    /** اعلان تغییر وضعیت سفارش به مشتری */
    public function orderStatus(Order $order): void
    {
        if (! static::enabled() || ! setting('push_order_status', true) || ! $order->user_id) {
            return;
        }
        // سرویس اعلان (گوگل/موزیلا) ممکن است تا ۱۷ ثانیه طول بکشد ← بعد از پاسخ به کارمند
        $data = ['title' => 'سفارش '.fa($order->number).': '.$order->statusLabel(), 'body' => store_name().($order->tracking_code ? ' — کد رهگیری '.fa($order->tracking_code) : ''),
            'url' => route('order.show', $order->number), 'tag' => 'order-'.$order->id];
        $uid = (int) $order->user_id;
        \App\Support\AfterResponse::run(function () use ($uid, $data) {
            try {
                $subs = PushSubscription::query()->where('user_id', $uid)->get();
                if ($subs->isNotEmpty()) {
                    $this->send($subs, $data);
                }
            } catch (Throwable $e) {
                report($e);
            }
        });

    }

    /** اعلان سفارش جدید به کارکنان */
    public function newOrder(Order $order): void
    {
        \App\Support\AfterResponse::run(fn () => $this->newOrderNow($order));
    }

    protected function newOrderNow(Order $order): void
    {
        if (! static::enabled() || ! setting('push_staff_orders', true)) {
            return;
        }
        $subs = PushSubscription::query()->where('is_staff', true)->get();
        if ($subs->isEmpty()) {
            return;
        }
        try {
            $this->send($subs, [
                'title' => 'سفارش جدید '.fa($order->number),
                'body' => $order->customer_name.' — '.money($order->total).' تومان',
                'url' => url('/admin/orders/'.$order->id),
                'tag' => 'new-order-'.$order->id,
            ]);
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** اعلان به کاربران مشخص (انباردار، مسئول پیگیری، مشتری) روی همه دستگاه‌هایشان */
    public function toUsers(array $userIds, array $payload): void
    {
        $userIds = array_values(array_filter(array_map('intval', $userIds)));
        if (! $userIds || ! static::enabled()) {
            return;
        }
        \App\Support\AfterResponse::run(fn () => $this->toUsersNow($userIds, $payload));
    }

    protected function toUsersNow(array $userIds, array $payload): void
    {
        try {
            $subs = PushSubscription::query()->whereIn('user_id', $userIds)->get();
            if ($subs->isNotEmpty()) {
                $this->send($subs, $payload);
            }
        } catch (Throwable $e) {
            report($e);
        }
    }
}
