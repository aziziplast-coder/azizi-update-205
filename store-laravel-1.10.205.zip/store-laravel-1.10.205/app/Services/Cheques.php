<?php

namespace App\Services;

use App\Models\Order;
use App\Models\User;
use App\Support\Jalali;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

/**
 * خرید چکی: شرایط فعال بودن، طرح‌های پرداخت (نقد + چک)، مدارک چک (تصویر / شناسه صیادی) و صف بررسی.
 */
class Cheques
{
    public const DOCS = [
        'none' => 'مدرکی لازم نیست',
        'image_or_sayad' => 'تصویر چک یا شناسه صیادی (یکی کافی است)',
        'image' => 'تصویر چک الزامی',
        'sayad' => 'شناسه صیادی ۱۶ رقمی الزامی',
        'both' => 'هم تصویر و هم شناسه صیادی',
    ];

    public static function config(): array
    {
        $c = (array) setting('pay_cheque', []);
        $c['enabled'] = ! empty($c['enabled']);
        $c['min_total'] = (int) to_int($c['min_total'] ?? 0);
        $c['audience'] = ($c['audience'] ?? 'approved') === 'all' ? 'all' : 'approved';
        $c['first_order'] = ! empty($c['first_order']);
        $c['docs'] = array_key_exists($c['docs'] ?? '', self::DOCS) ? $c['docs'] : 'image_or_sayad';
        $c['docs_for'] = ($c['docs_for'] ?? 'new') === 'all' ? 'all' : 'new';
        $c['review'] = in_array($c['review'] ?? 'new', ['off', 'new', 'all'], true) ? $c['review'] : 'new';
        $c['national_id'] = ! array_key_exists('national_id', $c) || ! empty($c['national_id']);
        // اعتبارسنجی چک: مشتری پس از صدور مانده حساب تصویر/شناسه صیادی چک‌ها را بارگذاری می‌کند (+ بررسی سفارش چکی)
        $c['validation'] = ! array_key_exists('validation', $c) || ! empty($c['validation']);
        if (! $c['validation']) {
            $c['docs'] = 'none';
            $c['national_id'] = false;
            $c['review'] = 'off';
        }
        // فیلدهای طرح‌ها (اعمال و نمایش) — هر کدام جدا قابل خاموش کردن
        foreach (['f_cash', 'f_count', 'f_first', 'f_interval'] as $f) {
            $c[$f] = ! array_key_exists($f, $c) || ! empty($c[$f]);
        }
        // دریافت تصویر چک + تصویر ثبت صیاد از مشتری پس از صدور مانده حساب (مستقل از «اعتبارسنجی چک»)
        $c['settle_docs'] = ! array_key_exists('settle_docs', $c) || ! empty($c['settle_docs']);
        $c['guarantee_on'] = ! empty($c['guarantee_on']);   // چک ضمانت (پیش‌فرض خاموش)
        $c['show_calc'] = ! empty($c['show_calc']);         // نمایش مبلغ نقد/چک/سررسید به مشتری هنگام ثبت سفارش

        return $c;
    }

    /** محاسبه خودکار مبلغ نقد و چک‌ها ممکن است؟ (درصد نقد و تعداد چک هر دو فعال) */
    public static function calcOn(): bool
    {
        $c = static::config();

        return $c['f_cash'] && $c['f_count'];
    }

    /** @return array<int, array{title: string, cash: float, count: int, first: int, interval: int, guarantee: bool, desc: string}> */
    public static function plans(): array
    {
        $out = [];
        $c = static::config();
        foreach ((array) ($c['plans'] ?? []) as $p) {
            $title = trim((string) ($p['title'] ?? ''));
            if ($title === '') {
                continue;
            }
            $out[] = [
                'title' => $title,
                'cash' => $c['f_cash'] ? max(0, min(100, (float) en_digits((string) ($p['cash'] ?? 0)))) : null,
                'count' => $c['f_count'] ? max(0, min(24, (int) to_int($p['count'] ?? 1))) : 0,
                'first' => $c['f_first'] ? max(0, (int) to_int($p['first'] ?? 30)) : null,
                'interval' => $c['f_interval'] ? max(1, (int) to_int($p['interval'] ?? 30)) : null,
                'guarantee' => $c['guarantee_on'] && ! empty($p['guarantee']),
                'desc' => trim((string) ($p['desc'] ?? '')),
            ];
        }

        return $out;
    }

    /** مشتری جدید = تا حالا سفارش ارسال‌شده یا تکمیل‌شده نداشته */
    public static function isNewCustomer(?User $user, ?int $exceptOrderId = null): bool
    {
        if (! $user) {
            return true;
        }

        return ! Order::query()->where('user_id', $user->id)->whereIn('status', ['processing', 'settling', 'to_freight', 'shipped', 'completed'])
            ->when($exceptOrderId, fn ($q) => $q->whereKeyNot($exceptOrderId))
            ->where(fn ($q) => $q->whereNull('review_status')->orWhere('review_status', 'approved'))
            ->exists();
    }

    /**
     * وضعیت خرید چکی برای این مشتری و این مبلغ
     *
     * @return array{show: bool, ok: bool, reason: string}
     */
    public static function availability(?User $user, int $itemsTotal): array
    {
        $c = static::config();
        if (! $c['enabled'] || ! static::plans()) {
            return ['show' => false, 'ok' => false, 'reason' => ''];
        }
        if ($c['audience'] === 'approved' && ! ($user?->cheque_allowed)) {
            return ['show' => true, 'ok' => false, 'reason' => 'خرید چکی برای حساب شما فعال نیست؛ برای فعال‌سازی با فروشگاه تماس بگیرید.'];
        }
        if (! $c['first_order'] && static::isNewCustomer($user) && ! ($user?->cheque_allowed)) {
            return ['show' => true, 'ok' => false, 'reason' => 'خرید چکی از خرید دوم به بعد فعال می‌شود.'];
        }
        if ($c['min_total'] > 0 && $itemsTotal < $c['min_total']) {
            return ['show' => true, 'ok' => false, 'reason' => 'خرید چکی برای سفارش‌های '.money($c['min_total'], true).' به بالا فعال است.'];
        }

        return ['show' => true, 'ok' => true, 'reason' => ''];
    }

    public static function needsDocs(?User $user): bool
    {
        $c = static::config();

        return $c['validation'] && $c['docs'] !== 'none' && ($c['docs_for'] === 'all' || static::isNewCustomer($user));
    }

    public static function needsReview(?User $user): bool
    {
        $c = static::config();

        return $c['review'] === 'all' || ($c['review'] === 'new' && static::isNewCustomer($user));
    }

    /** محاسبه مبلغ نقد و چک‌ها با سررسید */
    public static function schedule(array $plan, int $total, ?\DateTimeInterface $from = null): array
    {
        // محاسبه خاموش است: مبلغ نقد و چک‌ها را کارشناس فروش پس از جمع‌آوری انبار تعیین می‌کند
        if (! static::calcOn() || $plan['cash'] === null) {
            return ['cash' => null, 'cheques' => [], 'guarantee' => ! empty($plan['guarantee']) ? $total : 0];
        }
        $from = $from ? \Illuminate\Support\Carbon::instance($from) : now();
        $cash = (int) round($total * $plan['cash'] / 100);
        $count = (int) $plan['count'];
        $rest = $total - $cash;
        if ($count <= 0) {
            $cash = $total;
            $rest = 0;
        }
        $cheques = [];
        $each = $count > 0 ? intdiv($rest, $count) : 0;
        for ($i = 0; $i < $count; $i++) {
            $amount = $i === $count - 1 ? $rest - $each * ($count - 1) : $each;
            if ($plan['first'] === null) {
                $cheques[] = ['amount' => $amount, 'due' => null, 'due_fa' => '']; // سررسید را کارشناس تعیین می‌کند
                continue;
            }
            $due = $from->copy()->addDays($plan['first'] + $i * (int) ($plan['interval'] ?? 30));
            $cheques[] = ['amount' => $amount, 'due' => $due->toDateString(), 'due_fa' => Jalali::format($due)];
        }

        return ['cash' => $cash, 'cheques' => $cheques, 'guarantee' => $plan['guarantee'] ? $total : 0];
    }

    public static function validNationalId(string $code): bool
    {
        $code = en_digits($code);
        if (! preg_match('/^\d{10}$/', $code) || preg_match('/^(\d)\1{9}$/', $code)) {
            return false;
        }
        $sum = 0;
        for ($i = 0; $i < 9; $i++) {
            $sum += (int) $code[$i] * (10 - $i);
        }
        $r = $sum % 11;
        $c = (int) $code[9];

        return ($r < 2 && $c === $r) || ($r >= 2 && $c === 11 - $r);
    }

    /**
     * اعتبارسنجی فرم چک در صفحه تسویه و آماده‌سازی داده برای ذخیره
     *
     * @return array اطلاعات چک برای ستون cheque سفارش (بدون تصاویر)
     */
    public static function fromRequest(\Illuminate\Http\Request $request, ?User $user, int $total): array
    {
        $plans = static::plans();
        $idx = (int) $request->input('cheque_plan', -1);
        if (! isset($plans[$idx])) {
            throw ValidationException::withMessages(['cheque_plan' => 'شرایط پرداخت چکی را انتخاب کنید.']);
        }
        $plan = $plans[$idx];
        $c = static::config();
        $data = ['plan' => $plan['title'], 'plan_data' => $plan, 'docs' => [], 'national_id' => null] + static::schedule($plan, $total);

        // مدارک چک (تصویر، شناسه صیادی، کد ملی) دیگر هنگام ثبت سفارش گرفته نمی‌شود؛
        // پس از جمع‌آوری انبار و صدور مانده حساب، مشتری در صفحه سفارش برای هر چک بارگذاری می‌کند.
        return $data;
    }

    /** گیرنده پیش‌فرض چک‌ها (ثبت در سامانه صیاد): کد/شناسه ملی و نام صاحب حساب */
    public static function payeeDefault(): array
    {
        $c = static::config();

        return ['nid' => preg_replace('/\D/', '', en_digits((string) ($c['payee_nid'] ?? ''))), 'name' => trim((string) ($c['payee_name'] ?? ''))];
    }

    /** انواع مدرک هر چک + بیجک پستی کل چک‌ها */
    public const DOC_TYPES = ['cheque' => 'تصویر چک', 'sayad' => 'تصویر ثبت چک در سامانه صیاد'];

    public const DOC_STATUS = ['submitted' => 'در انتظار بررسی', 'approved' => 'تأیید شد', 'rejected' => 'رد شد'];

    /** مشتری باید برای چک‌های صادرشده در «صدور مانده حساب» مدرک بارگذاری کند؟ */
    public static function settleDocsNeeded(Order $o): bool
    {
        return static::config()['settle_docs'] && ! empty(((array) $o->cheque)['settle']);
    }

    /** مدرکی که هنوز فرستاده نشده یا رد شده (مشتری باید بفرستد) */
    public static function docsMissing(Order $o): bool
    {
        if (! static::settleDocsNeeded($o)) {
            return false;
        }
        foreach ((array) ($o->cheque['settle'] ?? []) as $r) {
            foreach (array_keys(static::DOC_TYPES) as $t) {
                if (in_array($r['docs'][$t]['st'] ?? null, [null, 'rejected'], true)) {
                    return true;
                }
            }
        }

        return false;
    }

    /** مدارکی که منتظر بررسی کارشناس است */
    public static function docsPending(Order $o): int
    {
        $n = 0;
        $ch = (array) $o->cheque;
        foreach ((array) ($ch['settle'] ?? []) as $r) {
            foreach ((array) ($r['docs'] ?? []) as $d) {
                $n += ($d['st'] ?? '') === 'submitted' ? 1 : 0;
            }
        }

        return $n + ((($ch['post']['st'] ?? '') === 'submitted') ? 1 : 0);
    }

    /**
     * مشتری: تصویر چک و تصویر ثبت صیاد هر چک (جدا) و در صورت ارسال پستی، تصویر بیجک پست.
     * فقط مدارکی که تأیید نشده‌اند قابل ارسال/تعویض‌اند.
     */
    public static function submitSettleDocs(Order $o, \Illuminate\Http\Request $request): void
    {
        $c = static::config();
        $ch = (array) $o->cheque;
        $rows = (array) ($ch['settle'] ?? []);
        if (! $rows) {
            throw ValidationException::withMessages(['cheque_docs' => 'هنوز مشخصات چک‌ها اعلام نشده است.']);
        }
        if ($c['national_id'] && $request->filled('cheque_nid')) {
            $nid = trim(en_digits((string) $request->input('cheque_nid')));
            if (! static::validNationalId($nid)) {
                throw ValidationException::withMessages(['cheque_docs' => 'کد ملی صاحب چک معتبر نیست (۱۰ رقم).']);
            }
            $ch['owner_nid'] = $nid;
        }
        $n = 0;
        $store = function (UploadedFile $f, string $name) use ($o): string {
            if (! $f->isValid() || ! in_array(strtolower($f->getClientOriginalExtension()), ['jpg', 'jpeg', 'png', 'webp', 'heic', 'pdf'], true) || $f->getSize() > 12 * 1024 * 1024) {
                throw ValidationException::withMessages(['cheque_docs' => 'تصویر باید عکس یا PDF و حداکثر ۱۲ مگابایت باشد.']);
            }

            return \App\Support\DocImages::store($f, 'cheques/'.$o->id, $name.'-'.substr(md5(uniqid('', true)), 0, 8));
        };
        foreach (array_keys(static::DOC_TYPES) as $t) {
            foreach ((array) $request->file($t.'_img', []) as $i => $f) {
                if (! isset($rows[$i]) || ! $f instanceof UploadedFile) {
                    continue;
                }
                $old = $rows[$i]['docs'][$t] ?? null;
                if (($old['st'] ?? '') === 'approved') {
                    continue;
                }
                $rows[$i]['docs'][$t] = ['path' => $store($f, $t.$i), 'st' => 'submitted', 'reason' => null, 'at' => now()->toDateTimeString()];
                if (! empty($old['path'])) {
                    Storage::disk('local')->delete($old['path']);
                }
                $n++;
            }
        }
        $pf = $request->file('post_img');
        if ($pf instanceof UploadedFile && (($ch['post']['st'] ?? '') !== 'approved')) {
            $old = $ch['post']['path'] ?? null;
            $ch['post'] = ['path' => $store($pf, 'post'), 'st' => 'submitted', 'reason' => null, 'at' => now()->toDateTimeString()];
            if ($old) {
                Storage::disk('local')->delete($old);
            }
            $n++;
        }
        if (! $n && ! $request->filled('cheque_nid')) {
            throw ValidationException::withMessages(['cheque_docs' => 'تصویری انتخاب نشده است.']);
        }
        $ch['settle'] = $rows;
        $o->cheque = $ch;
        $o->saveQuietly();
        $o->log('مشتری '.fa($n).' مدرک چک فرستاد');
        ChatFinance::note($o, '📎 '.fa($n).' مدرک چک رسید — در حال بررسی');
        if ($o->assignee_id) {
            app(WebPush::class)->toUsers([$o->assignee_id], ['title' => 'مدارک چک — سفارش '.fa($o->number), 'body' => $o->customer_name.' '.fa($n).' تصویر برای بررسی فرستاد.',
                'url' => url('/admin/orders/'.$o->id), 'tag' => 'cheque-docs-'.$o->id]);
        }
    }

    /**
     * کارشناس: تأیید یا رد یک مدرک ($i = شماره چک؛ $type = cheque|sayad|post)
     */
    public static function reviewDoc(Order $o, string $type, ?int $i, bool $approve, ?string $reason = null, ?User $by = null): void
    {
        $ch = (array) $o->cheque;
        if ($type === 'post') {
            $doc = $ch['post'] ?? null;
        } else {
            $doc = $ch['settle'][$i]['docs'][$type] ?? null;
        }
        if (! $doc || empty($doc['path'])) {
            throw ValidationException::withMessages(['doc' => 'مدرکی برای بررسی نیست.']);
        }
        // پس از رفتن بار برای بارگیری، تأیید هیچ مدرکی پس گرفته نمی‌شود (جز مدیر کل)
        if (! $approve && ($doc['st'] ?? '') === 'approved' && $o->loadingLocked() && ! $by?->isAdmin()) {
            throw ValidationException::withMessages(['doc' => 'بار برای بارگیری رفته است؛ رد مدرک تأییدشده ممکن نیست.']);
        }
        $doc['st'] = $approve ? 'approved' : 'rejected';
        $doc['reason'] = $approve ? null : mb_substr(trim((string) $reason) ?: 'نامعتبر', 0, 190);
        $doc['by'] = $by?->id;
        $doc['rev_at'] = now()->toDateTimeString();
        if ($type === 'post') {
            $ch['post'] = $doc;
            $label = 'بیجک پستی چک‌ها';
        } else {
            $ch['settle'][$i]['docs'][$type] = $doc;
            $label = static::DOC_TYPES[$type].' چک '.fa($i + 1);
        }
        $o->cheque = $ch;
        $o->saveQuietly();
        $o->log($label.' '.($approve ? 'تأیید شد' : 'رد شد: '.$doc['reason']), $by?->id);
        ChatFinance::note($o, $approve ? '✅ '.$label.' تأیید شد.' : '❌ '.$label.' تأیید نشد: '.$doc['reason'].' — لطفاً تصویر درست را روی کارت چک‌ها بفرستید.', ! $approve);
        if (! $approve) {
            app(Sms::class)->forOrder($o, 'cheque_doc_rejected', ['doc' => $label, 'reason' => $doc['reason']]);
        }
    }

    /** ذخیره تصاویر چک در پوشه خصوصی (فقط مدیر می‌بیند) */
    public static function storeFiles(Order $order, array $cheque): array
    {
        foreach ((array) ($cheque['docs'] ?? []) as $i => $d) {
            $file = $d['_file'] ?? null;
            unset($cheque['docs'][$i]['_file']);
            if ($file instanceof UploadedFile) {
                $path = \App\Support\DocImages::store($file, 'cheques/'.$order->id, $i.'-'.substr(md5(uniqid('', true)), 0, 10));
                $cheque['docs'][$i]['image'] = $path;
            }
        }

        return $cheque;
    }

    /** محاسبه دوباره مبالغ پس از ویرایش سفارش */
    public static function recalc(array $cheque, int $total, ?\DateTimeInterface $from = null): array
    {
        if (empty($cheque['plan_data'])) {
            return $cheque;
        }
        $s = static::schedule($cheque['plan_data'], $total, $from);
        $cheque['cash'] = $s['cash'];
        $cheque['guarantee'] = $s['guarantee'];
        foreach ($s['cheques'] as $i => $ch) {
            $cheque['cheques'][$i] = $ch;
        }

        return $cheque;
    }
}
