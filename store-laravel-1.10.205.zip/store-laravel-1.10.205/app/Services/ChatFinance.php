<?php

namespace App\Services;

use App\Models\ChatThread;
use App\Models\Order;
use App\Models\RemitPayment;
use App\Models\User;
use App\Support\Banks;
use Illuminate\Support\Collection;
use Throwable;

/**
 * امور مالی داخل گفتگوی سفارش (جایگزین فرستادن فیش و چک در روبیکا).
 *
 * هر مبلغ صادرشده (بیعانه / مانده حساب) یک «کارت حواله» زنده در گفتگوست؛ فیش فقط روی همان کارت فرستاده می‌شود
 * و مستقیم در همان سیستم حواله‌ها (کارتابل فیش‌ها، اپ کارخانه‌داران، تاریخچه سفارش، پیامک‌ها) ثبت می‌شود.
 * تأیید/رد/اصلاح از کارتابل یا از گفتگو، هر دو همین کارت و تاریخچه را به‌روز می‌کنند.
 */
class ChatFinance
{
    public static function on(): bool
    {
        return Chat::enabled() && (bool) setting('chat_finance', true);
    }

    public static function remitOn(): bool
    {
        return static::on() && Remit::enabled();
    }

    protected static function thread(Order $o, bool $create = true): ?ChatThread
    {
        if (! static::on() || ! $o->user_id) {
            return null;
        }

        return Chat::thread($o, $create);
    }

    /** کارت حواله برای هر مبلغ تازه صادرشده */
    public static function issued(Order $o, Collection $made): void
    {
        try {
            if (! static::remitOn() || $made->isEmpty() || ! ($t = static::thread($o))) {
                return;
            }
            foreach ($made as $p) {
                Chat::post($t, 'x', null, 'pay', null, ['pid' => (int) $p->id, 'label' => $p->kindLabel().' '.money($p->amount).' تومان']);
            }
            $sum = (int) $made->sum('amount');
            $due = Remit::depositDue($made->first());
            if ($due) {
                $c = Remit::depCfg();
                Chat::post($t, 'x', null, 'event', '⏰ مهلت واریز بیعانه: تا '.jdate($due, true).' ('.fa(rtrim(rtrim(number_format($c['hours'], 1), '0'), '.')).' ساعت)'
                    .($c['cancel'] ? '؛ در صورت عدم واریز، سفارش به‌طور سیستمی لغو خواهد شد.' : '.'), ['r' => 1]);
            }
            static::push($o, '💳 '.$made->first()->kindLabel().' '.money($sum).' تومان صادر شد', 'شماره حساب و ارسال فیش در گفتگوی سفارش'.($due ? ' — مهلت تا '.jdate($due, true) : ''));
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** خط خبری مالی در گفتگو (کارت‌های مالی هم با آن تازه می‌شوند) */
    public static function note(Order $o, string $text, bool $push = false): void
    {
        try {
            if (! static::on() || ! ($t = static::thread($o, false))) {
                return;
            }
            Chat::post($t, 'x', null, 'event', $text, ['r' => 1]);
            if ($push) {
                static::push($o, $text, 'سفارش '.fa($o->number));
            }
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** کارت چک‌ها (یک بار؛ تغییرات بعدی فقط خط خبری) */
    public static function chequeCard(Order $o): void
    {
        try {
            if (! static::on() || empty(((array) $o->cheque)['settle']) || ! ($t = static::thread($o))) {
                return;
            }
            $has = \App\Models\ChatMessage::query()->where('thread_id', $t->id)->where('kind', 'cheq')->exists();
            if ($has) {
                Chat::post($t, 'x', null, 'event', '🧾 مشخصات چک‌ها به‌روز شد.', ['r' => 1]);
            } else {
                Chat::post($t, 'x', null, 'cheq', null, ['label' => 'مشخصات چک‌ها']);
            }
            static::push($o, '🧾 مشخصات چک‌های سفارش اعلام شد', 'تصویر چک و ثبت صیاد را در گفتگو بفرستید');
        } catch (Throwable $e) {
            report($e);
        }
    }

    protected static function push(Order $o, string $title, string $body): void
    {
        if ($o->user_id) {
            app(WebPush::class)->toUsers([(int) $o->user_id], ['title' => $title, 'body' => $body, 'url' => route('order.show', $o->number).'#chat', 'tag' => 'chat-'.$o->id]);
        }
    }

    /** وقتی مبلغی منتظر واریز است، مشتری عکس معمولی نمی‌فرستد (فیش فقط روی کارت حواله) */
    public static function blocksImages(Order $o): bool
    {
        return static::remitOn() && RemitPayment::query()->where('order_id', $o->id)->whereIn('status', ['awaiting', 'rejected'])->exists();
    }

    /* ======================= داده کارت‌ها ======================= */

    /**
     * @param  array<int>  $ids
     * @return array<int, array>
     */
    public static function payCards(array $ids, bool $staff): array
    {
        if (! $ids) {
            return [];
        }
        $rows = RemitPayment::query()->with(['remittance', 'order'])->whereIn('id', $ids)->get(); // سفارش کامل: توضیح مبلغ، مانده هلو، چک ضمانت و باربری
        $u = auth()->user();
        $out = [];
        foreach ($rows as $p) {
            $out[$p->id] = static::payCard($p, $staff, $u);
        }

        return $out;
    }

    public static function payCard(RemitPayment $p, bool $staff, ?User $u = null): array
    {
        $r = $p->remittance;
        $o = $p->order;
        $files = [];
        foreach ($p->files() as $i => $f) {
            $files[] = ['url' => $staff ? route('admin.remit.receipt', [$p->id, 'i' => $i, 'v' => substr(md5((string) $p->updated_at), 0, 8)]) : route('order.receipt.show', [$o->number, $p->id, 'i' => $i, 'v' => substr(md5((string) $p->updated_at), 0, 8)]), 'pdf' => RemitPayment::isPdfPath($f)];
        }
        $st = [
            'awaiting' => $staff ? 'منتظر واریز مشتری' : 'منتظر واریز شما', 'submitted' => 'فیش رسید — در حال بررسی', 'confirmed' => 'تأیید شد',
            'rejected' => 'فیش تأیید نشد', 'cancelled' => 'باطل شد',
        ][$p->status] ?? $p->status;
        $acc = $p->account();
        $card = [
            'pid' => (int) $p->id, 'kind' => $p->kindLabel(), 'amount' => money($p->amount), 'raw' => (int) $p->amount, 'rial' => (int) $p->amount * 10,
            'st' => $p->status, 'st_label' => $st, 'holder' => $acc['holder'], 'bank' => $acc['bank'],
            'card' => $acc['card'] ? fa(Banks::formatCard($acc['card'])) : '', 'card_raw' => $acc['card'],
            'sheba' => $acc['sheba'] ? Banks::formatSheba($acc['sheba']) : '', 'sheba_raw' => $acc['sheba'],
            'bounce' => ! empty($p->bounce), 'alt' => $acc['alt'],
            'reason' => (string) $p->reject_reason, 'files' => $files, 'mix' => $p->status === 'submitted' && Remit::mixedSources($p),
            'st_up' => $p->status === 'submitted' && in_array('st', array_column((array) json_decode((string) ($p->receipt_hashes ?? ''), true), 's'), true), 'payable' => $p->payable(), 'ref' => fa((string) $p->receipt_ref),
            'at' => $p->submitted_at ? \App\Support\Jalali::format($p->submitted_at, true) : '',
        ];
        if (! $staff && $o && $p->kind === 'settle' && $p->payable() && Shipping::isFreight($o)) {
            $card['freight'] = ['name' => (string) $o->freight_name, 'dest' => (string) (OrderPrior::on() ? ($o->freight_dest ?: $o->city) : $o->city)];
        }
        if (OrderPrior::on() && $o) {
            if ($calc = OrderPrior::calc($p)) {
                $card['calc'] = $calc;
            }
            if ($g = OrderPrior::guarFor($p, $staff, $u)) {
                $card['guar'] = $g;
            }
        }
        if ($staff) {
            $review = $u && static::canReview($u, $p);
            $card['code'] = (string) $r?->code;
            $card['can'] = [
                'review' => $review && in_array($p->status, ['submitted', 'awaiting', 'rejected'], true),
                'edit' => $review && $p->payable(),
                'cancel' => $review && $p->payable() && empty($p->bounce), // کارت واریز مجدد حواله برگشتی باطل نمی‌شود
                'upload' => $p->payable() && $u && ($review || ($o && (int) $o->assignee_id === (int) $u->id)),
                // جایگزینی / حذف تصویر تکراری فیش (حتی پس از تأیید)
                'fix' => $review && in_array($p->status, ['submitted', 'confirmed'], true),
            ];
        }

        return $card;
    }

    public static function canReview(User $u, RemitPayment $p): bool
    {
        if (Remit::isChief($u)) {
            return true;
        }

        return $u->hasPerm('remit_assist') && ((int) $p->remittance?->assignee_id === (int) $u->id || (int) $p->order?->assignee_id === (int) $u->id);
    }

    /** کارت چک‌ها */
    public static function chequeData(Order $o, bool $staff): ?array
    {
        $ch = (array) $o->cheque;
        if (empty($ch['settle'])) {
            return null;
        }
        $c = Cheques::config();
        $payee = array_filter((array) ($ch['payee'] ?? [])) ?: Cheques::payeeDefault();
        $docsOn = Cheques::settleDocsNeeded($o);
        $img = function (array $q) use ($staff, $o) {
            $i = (int) ($q['i'] ?? 0);
            unset($q['i']);

            return $staff ? route('admin.cheque', array_merge(['order' => $o->id, 'i' => $i], $q)) : route('order.cheque.img', array_merge(['number' => $o->number, 'i' => $i], $q));
        };
        $doc = function (?array $d, array $q) use ($img) {
            if (! $d || empty($d['path'])) {
                return ['st' => null, 'label' => 'ارسال نشده'];
            }

            return ['st' => $d['st'], 'label' => Cheques::DOC_STATUS[$d['st']] ?? $d['st'], 'reason' => (string) ($d['reason'] ?? ''),
                'url' => $img($q + ['v' => substr(md5($d['path']), 0, 8)]), 'pdf' => str_ends_with(strtolower($d['path']), '.pdf')];
        };
        $rows = [];
        foreach ((array) $ch['settle'] as $i => $r) {
            $docs = [];
            foreach (Cheques::DOC_TYPES as $t => $label) {
                $docs[$t] = ['title' => $label] + $doc($r['docs'][$t] ?? null, ['i' => $i, 't' => 'doc', 'k' => $t]);
            }
            $rows[] = ['i' => $i, 'amount' => money((int) $r['amount']), 'due' => (string) ($r['due_fa'] ?? ''), 'docs' => $docs];
        }
        $u = auth()->user();

        return [
            'payee' => ['name' => (string) ($payee['name'] ?? ''), 'nid' => fa((string) ($payee['nid'] ?? ''))],
            'rows' => $rows, 'docs_on' => $docsOn, 'nid_needed' => $docsOn && ! empty($c['national_id']), 'owner_nid' => (string) ($ch['owner_nid'] ?? ''),
            'post' => ['title' => 'بیجک پستی چک‌ها (اگر چک‌ها را پست کرده‌اید)'] + $doc($ch['post'] ?? null, ['i' => 0, 't' => 'post']),
            'cash' => (int) $o->cash_amount > 0 ? money((int) $o->cash_amount) : null,
            'can_review' => $staff && $u && $u->hasPerm('orders_edit'),
        ];
    }

    /* ======================= خلاصه کنار گفتگو ======================= */

    public static function summary(Order $o, User $u): array
    {
        $all = RemitPayment::query()->with('remittance')->where('order_id', $o->id)->where('status', '!=', 'cancelled')->orderBy('id')->get();
        $sum = fn (array $st) => (int) $all->whereIn('status', $st)->sum('amount');
        $final = (int) ($o->final_amount ?: $o->total);
        $list = $all->map(fn (RemitPayment $p) => [
            'pid' => $p->id, 'kind' => $p->kindLabel(), 'amount' => money($p->amount), 'raw' => (int) $p->amount, 'st' => $p->status, 'st_label' => RemitPayment::STATUSES[$p->status] ?? $p->status,
            'code' => (string) $p->remittance?->code, 'n' => count($p->files()),
            'thumb' => $p->files() && ! RemitPayment::isPdfPath($p->files()[0]) ? route('admin.remit.receipt', [$p->id, 'i' => 0, 'v' => substr(md5((string) $p->updated_at), 0, 8)]) : null,
        ])->values()->all();
        $canWork = Remit::enabled() && Remit::canWork($u);
        $isCheque = OrderPrior::chequeOrder($o);
        $depositOk = $canWork && $o->status === 'on_hold' && $o->review_status !== 'pending' && $all->where('kind', 'deposit')->isEmpty();
        $settleOk = $canWork && ! $o->isPaid() && in_array($o->status, ['processing', 'settling', 'to_freight', 'shipped'], true) && $o->fulfil_status !== 'picking';
        // «در ویرایش مشتری» / جایگزین‌های در انتظار تأیید یا در حال جمع‌آوری: صدور بسته
        $why = $depositOk ? OrderWindows::issueBlock($o, 'deposit') : ($settleOk || $o->fulfil_status === 'picking' ? OrderWindows::issueBlock($o, 'settle') : null);
        $depositOk = $depositOk && ! $why;
        $settleOk = $settleOk && ! $why;

        return [
            'on' => static::remitOn(), 'final' => money($final), 'final_label' => $o->final_amount ? 'مبلغ نهایی' : 'مبلغ سفارش',
            'confirmed' => money($sum(['confirmed'])), 'submitted' => money($sum(['submitted'])), 'due' => money($sum(['awaiting', 'rejected'])),
            'nums' => ['final' => $final, 'confirmed' => $sum(['confirmed']), 'submitted' => $sum(['submitted']), 'due' => $sum(['awaiting', 'rejected'])],
            'left' => money(max(0, ($o->cash_amount !== null ? (int) $o->cash_amount : $final) - $sum(['confirmed']))), 'paid' => $o->isPaid(),
            'list' => $list, 'open' => $all->whereIn('status', ['awaiting', 'rejected', 'submitted'])->map(fn ($p) => ['pid' => $p->id, 'label' => $p->kindLabel().' '.money($p->amount).' — '.$p->remittance?->holder_name.($p->status === 'submitted' ? ' ⚠ مشتری '.fa(count($p->files())).' فیش روی کارت فرستاده' : ''), 'sub' => $p->status === 'submitted' ? count($p->files()) : 0])->values()->all(),
            'cheques' => ! empty(((array) $o->cheque)['settle']) ? Cheques::docsPending($o) : null,
            'issue' => [
                'deposit' => $depositOk, 'settle' => $settleOk, 'why' => $why, 'suggest' => $depositOk ? Remit::suggestDeposit($o, $o->assignee ?? $u) : 0,
                'cheque_order' => $isCheque, 'freight' => Shipping::isFreight($o), 'freight_fee' => (int) $o->freight_fee, 'total' => money((int) $o->total + (int) $o->extra_discount),
                'settle_again' => $all->where('kind', 'settle')->isNotEmpty(), 'reasons' => array_values(Remit::rejectReasons()),
                'prior' => OrderPrior::on() ? OrderPrior::fill($o) : null,
            ],
        ];
    }
}
