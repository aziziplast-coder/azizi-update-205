<?php

namespace App\Services;

use App\Models\Order;
use App\Models\RemitDestination;
use App\Models\RemitPayment;
use App\Models\Remittance;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Throwable;

/**
 * پر کردن حواله‌های کارخانه با واریز مستقیم مشتریان.
 *
 * جریان: حسابدار کل حواله می‌سازد و به کمک‌حسابدار می‌سپارد ← سفارشی که کمک‌حسابدار مسئول آن است
 * «بیعانه» می‌گیرد (خودکار یا دستی) و مبلغ از حواله‌های باز او صادر می‌شود ← مشتری واریز و فیش را بارگذاری می‌کند
 * ← کمک‌حسابدار تأیید می‌کند ← سفارش خودکار به انبار ارجاع می‌شود ← پس از جمع‌آوری، «مانده حساب» صادر می‌شود
 * ← با تأیید فیش تسویه، سفارش «پرداخت شده» است. هر حواله وقتی کامل تأیید شد «پر شده» می‌شود.
 */
class Remit
{
    public static function enabled(): bool
    {
        return (bool) setting('remit_enabled', false);
    }

    /** حسابدار کل (مدیریت همه حواله‌ها) */
    public static function isChief(?User $u): bool
    {
        return (bool) $u?->hasPerm('remit_manage');
    }

    /** کمک‌حسابدار یا حسابدار کل */
    public static function canWork(?User $u): bool
    {
        return (bool) ($u && ($u->hasPerm('remit_manage') || $u->hasPerm('remit_assist')));
    }

    /** کارکنانی که می‌توانند حواله بگیرند */
    public static function assistants(): Collection
    {
        return User::query()->where('is_active', true)->whereIn('role', ['admin', 'staff'])->get()
            ->filter(fn (User $u) => $u->hasPerm('remit_assist') || $u->hasPerm('remit_manage'))->values();
    }

    /** تنظیمات بیعانه هر کمک‌حسابدار */
    public static function cfg(?User $u): array
    {
        $def = [
            'mode' => setting('remit_mode', 'manual'),
            'percent' => (float) setting('remit_percent', 30),
            'fixed' => 0,
            'round' => (int) setting('remit_round', 100000),
            'min' => 0,
        ];
        $mine = $u ? (array) json_decode((string) $u->acc_settings, true) : [];

        return array_merge($def, array_filter($mine, fn ($v) => $v !== null && $v !== ''));
    }

    public static function saveCfg(User $u, array $cfg): void
    {
        $u->forceFill(['acc_settings' => json_encode([
            'mode' => in_array($cfg['mode'] ?? '', ['auto', 'manual'], true) ? $cfg['mode'] : 'manual',
            'percent' => max(0, min(100, (float) ($cfg['percent'] ?? 30))),
            'fixed' => max(0, (int) ($cfg['fixed'] ?? 0)),
            'round' => max(0, (int) ($cfg['round'] ?? 0)),
            'min' => max(0, (int) ($cfg['min'] ?? 0)),
        ])])->save();
    }

    /** مبلغ پیشنهادی بیعانه یک سفارش طبق تنظیمات کمک‌حسابدار */
    public static function suggestDeposit(Order $o, ?User $u = null): int
    {
        $c = static::cfg($u ?? $o->assignee);
        $amt = $c['fixed'] > 0 ? (int) $c['fixed'] : (int) round($o->total * $c['percent'] / 100);
        if ($c['round'] > 0) {
            $amt = (int) (ceil($amt / $c['round']) * $c['round']);
        }
        $amt = max($amt, (int) $c['min']);

        return (int) min($amt, (int) $o->total);
    }

    /** پرداخت‌های زنده یک سفارش */
    public static function payments(Order $o, ?string $kind = null): Collection
    {
        return RemitPayment::query()->with('remittance')->where('order_id', $o->id)
            ->when($kind, fn ($q) => $q->where('kind', $kind))
            ->whereIn('status', RemitPayment::LIVE)->orderBy('id')->get();
    }

    public static function confirmedSum(Order $o, ?string $kind = null): int
    {
        return (int) RemitPayment::query()->where('order_id', $o->id)->where('status', 'confirmed')
            ->when($kind, fn ($q) => $q->where('kind', $kind))->sum('amount');
    }

    /** حواله‌های باز یک کمک‌حسابدار با ظرفیت آزاد (به ترتیب اولویت و قدمت) */
    public static function openFor(?int $userId): Collection
    {
        return Remittance::query()->where('status', 'active')
            ->when($userId, fn ($q) => $q->where('assignee_id', $userId))
            ->orderBy('sort')->orderBy('id')->get()
            ->map(fn (Remittance $r) => tap($r, fn ($r) => $r->setAttribute('free', $r->stats()['free'])))
            ->filter(fn (Remittance $r) => $r->free > 0)->values();
    }

    /**
     * صدور مبلغ برای مشتری از حواله‌ها (اگر یک حواله کافی نباشد، باقی از حواله بعدی).
     *
     * @param  int[]|null  $remitIds  حواله‌های انتخابی (خالی = خودکار از حواله‌های مسئول سفارش)
     * @return Collection<RemitPayment>
     */
    public static function issue(Order $o, string $kind, int $amount, ?array $remitIds = null, ?User $by = null): Collection
    {
        if ($amount <= 0) {
            throw ValidationException::withMessages(['amount' => 'مبلغ باید بیشتر از صفر باشد.']);
        }
        if ($kind === 'deposit' && ($why = OrderWindows::issueBlock($o, 'deposit'))) {
            throw ValidationException::withMessages(['amount' => $why]);
        }

        return DB::transaction(function () use ($o, $kind, $amount, $remitIds, $by) {
            $q = Remittance::query()->where('status', 'active')->lockForUpdate()->orderBy('sort')->orderBy('id');
            if ($remitIds) {
                $q->whereIn('id', $remitIds);
                // ترتیب انتخاب کاربر حفظ شود
                $list = $q->get()->sortBy(fn ($r) => array_search($r->id, $remitIds))->values();
            } else {
                if (! $o->assignee_id) {
                    throw ValidationException::withMessages(['amount' => 'اول مسئول پیگیری سفارش تعیین شود؛ مبلغ از حواله‌های او صادر می‌شود.']);
                }
                $list = $q->where('assignee_id', $o->assignee_id)->get();
            }
            $left = $amount;
            $made = collect();
            foreach ($list as $r) {
                $free = $r->stats()['free'];
                if ($free <= 0) {
                    continue;
                }
                $part = min($free, $left);
                $made->push(RemitPayment::query()->create([
                    'remittance_id' => $r->id, 'order_id' => $o->id, 'user_id' => $o->user_id, 'kind' => $kind,
                    'amount' => $part, 'status' => 'awaiting', 'issued_by' => $by?->id ?? auth()->id(),
                ]));
                $left -= $part;
                if ($left <= 0) {
                    break;
                }
            }
            if ($left > 0) {
                $have = $amount - $left;
                throw ValidationException::withMessages(['amount' => 'ظرفیت حواله‌های باز کافی نیست: '.money($have).' تومان آزاد است و '.money($amount).' تومان لازم است. از حسابدار کل حواله تازه بگیرید.']);
            }
            $o->log(RemitPayment::KINDS[$kind].' '.money($amount).' تومان صادر شد: '.$made->map(fn ($p) => $p->remittance->code.' ('.money($p->amount).')')->implode('، '), $by?->id);
            ChatFinance::issued($o, $made);

            return $made;
        });
    }

    /** بیعانه خودکار (اگر تنظیم کمک‌حسابدار «خودکار» باشد) */
    public static function autoDeposit(Order $o): void
    {
        if (! static::enabled() || ! $o->assignee_id || $o->status !== 'on_hold' || $o->review_status === 'pending' || $o->isPaid()) {
            return;
        }
        if (static::payments($o, 'deposit')->isNotEmpty() || static::confirmedSum($o) > 0) {
            return;
        }
        $u = $o->assignee;
        if (! $u || static::cfg($u)['mode'] !== 'auto') {
            return;
        }
        $amount = static::suggestDeposit($o, $u);
        if ($amount <= 0) {
            // بیعانه صفر: بدون انتظار، مستقیم «در حال جمع‌آوری از انبار» (و ارجاع خودکار به انبار)
            $o->setStatus('processing', 'بیعانه لازم نیست (صفر)');

            return;
        }
        // پیش از صدور: «می‌خواهید فاکتورتان را تغییر دهید؟» در گفتگو (اگر روشن باشد)
        if ($o->deposit_ask !== 'done' && static::depCfg()['confirm'] && static::canAskDeposit($o)) {
            if ($o->deposit_ask === null) {
                static::depCfg()['welcome'] ? static::welcome($o) : static::askDeposit($o, $u);
            }

            return; // منتظر پاسخ یا ثبت تغییرات مشتری
        }
        try {
            static::issue($o, 'deposit', $amount, null, $u);
            static::notifyCustomer($o, 'deposit');
        } catch (ValidationException $e) {
            $o->log('بیعانه خودکار صادر نشد: '.collect($e->errors())->flatten()->first());
            app(WebPush::class)->toUsers([$u->id], ['title' => 'بیعانه سفارش '.fa($o->number).' صادر نشد', 'body' => 'حواله باز با ظرفیت کافی ندارید.', 'url' => url('/admin/orders/'.$o->id), 'tag' => 'remit-'.$o->id]);
        }
    }

    /* ---------- تأیید مشتری پیش از بیعانه و مهلت واریز ---------- */

    public const DEP_TEXT = "سفارش شما بررسی شد ✅\nاگر قصد دارید سفارش را کم یا زیاد کنید، قبل از واریز بیعانه تغییرات فاکتور خود را اعمال کنید.\nمی‌خواهید فاکتورتان را تغییر دهید؟";

    public const DEP_YES = 'بله، فاکتور را تغییر می‌دهم';

    public const DEP_NO = 'نه، بیعانه را صادر کنید';

    public const WEL_TEXT_OLD = "سلام، ارادت 🌹\nسفارش شما به شماره {number} دریافت شد.\nآیا سفارشتان نیاز به ویرایش دارد؟\nاگر می‌خواهید کالایی را کم یا زیاد کنید «بله» را بزنید تا اقلام در سبد خرید قرار بگیرد و تغییرات را ثبت کنید؛ اگر تغییری ندارید «نه، تغییری ندارم» را بزنید تا همکاران ما بیعانه را برایتان صادر کنند.";

    public const WEL_TEXT = "سلام، ارادت 🌹\nسفارش شما به شماره {number} دریافت شد.\nمی‌خواهید به فاکتورتان تغییری بدهید؟ (کم و زیاد کردن یا افزودن اقلام جدید)\nتوجه: تا وقتی این سفارش باز است، امکان ثبت سفارش جدید ندارید؛ پس اگر کالای دیگری هم می‌خواهید، همین حالا به همین سفارش اضافه کنید.\nاگر «بله» بزنید، {hours} ساعت فرصت دارید در سایت بچرخید، اقلام را کم و زیاد یا اضافه کنید و «ثبت تغییرات سفارش» را بزنید.\nاگر تغییری ندارید «نه، تغییری ندارم» را بزنید تا بیعانه برایتان صادر شود.";

    public const WEL_YES = 'بله، سفارشم را ویرایش می‌کنم';

    public const WEL_NO = 'نه، تغییری ندارم';

    public static function depCfg(): array
    {
        // off | order (پیام خوش‌آمد هنگام ثبت سفارش) | deposit (پیش از صدور بیعانه)
        $when = (string) setting('dep_when', '');
        if (! in_array($when, ['off', 'order', 'deposit'], true)) {
            $when = setting('dep_confirm', false) ? 'deposit' : 'off';
        }

        return [
            'when' => $when,
            'confirm' => $when !== 'off',
            'welcome' => $when === 'order',
            'text' => trim((string) setting('dep_confirm_text')) ?: self::DEP_TEXT,
            'wel_text' => ($w = trim((string) setting('order_welcome_text'))) && $w !== self::WEL_TEXT_OLD ? $w : self::WEL_TEXT,
            'ask_hours' => max(0, (float) setting('dep_ask_hours', 2)),   // بی‌پاسخ ← بیعانه خودکار صادر شود (۰ = منتظر بماند)
            'hours' => max(0, (float) setting('dep_hours', 0)),           // مهلت واریز بیعانه (۰ = بدون مهلت)
            'cancel' => (bool) setting('dep_cancel', true),               // پایان مهلت ← لغو خودکار سفارش
        ];
    }

    /** سؤال فقط وقتی معنا دارد که مشتری گفتگو دارد و هنوز می‌تواند فاکتور را تغییر دهد */
    public static function canAskDeposit(Order $o): bool
    {
        return ChatFinance::on() && $o->user_id && ! $o->fulfil_status && ! $o->pick_round && $o->status === 'on_hold'
            && \App\Support\DbSchema::hasColumn('orders', 'deposit_ask');
    }

    public static function askDeposit(Order $o, ?User $u): void
    {
        try {
            $t = Chat::thread($o);
            if (! $t) {
                return;
            }
            $c = static::depCfg();
            $o->forceFill(['deposit_ask' => 'ask', 'deposit_asked_at' => now()])->saveQuietly();
            Chat::post($t, 's', $u, 'confirm', $c['text'], ['opts' => [self::DEP_YES, self::DEP_NO], 'k' => 'dep']);
            Chat::notifyCustomer($t->refresh(), $o, '🧾 پیش از صدور بیعانه: می‌خواهید فاکتورتان را تغییر دهید؟', $u);
            $o->log('سؤال «تغییر فاکتور پیش از بیعانه» در گفتگو برای مشتری فرستاده شد'.($c['ask_hours'] > 0 ? '؛ اگر تا '.fa(rtrim(rtrim(number_format($c['ask_hours'], 1), '0'), '.')).' ساعت پاسخ ندهد، بیعانه خودکار صادر می‌شود' : ''));
        } catch (Throwable $e) {
            report($e);
            $o->forceFill(['deposit_ask' => 'done'])->saveQuietly();
        }
    }

    /**
     * پیام خوش‌آمد هنگام ثبت سفارش (از طرف همکار مسئول): «سفارشتان نیاز به ویرایش دارد؟»
     * پاسخ «نه» یا ثبت تغییرات ← بیعانه (خودکار یا توسط همکاران)
     */
    public static function welcome(Order $o): void
    {
        $c = static::depCfg();
        if (! $c['welcome'] || ! static::enabled() || $o->deposit_ask !== null || $o->review_status === 'pending' || $o->isPaid() || ! static::canAskDeposit($o)) {
            return;
        }
        try {
            $t = Chat::thread($o);
            if (! $t) {
                return;
            }
            $u = $o->assignee;
            $o->forceFill(['deposit_ask' => 'ask', 'deposit_asked_at' => now()])->saveQuietly();
            $text = strtr($c['wel_text'], ['{number}' => fa((string) $o->number), '{name}' => trim((string) $o->customer_name), '{hours}' => OrderWindows::hoursTxt()]);
            Chat::post($t, 's', $u, 'confirm', $text, ['opts' => [self::WEL_YES, self::WEL_NO], 'k' => 'dep']);
            Chat::notifyCustomer($t->refresh(), $o, '🌹 سفارش '.fa((string) $o->number).' دریافت شد — آیا نیاز به ویرایش دارد؟', $u);
            $o->log('پیام «سفارش دریافت شد؛ نیاز به ویرایش دارد؟» در گفتگو برای مشتری فرستاده شد');
        } catch (Throwable $e) {
            report($e);
            $o->forceFill(['deposit_ask' => 'done'])->saveQuietly();
        }
    }

    /**
     * پاسخ مشتری: بله ← اقلام سفارش به سبد (صفحه ویرایش)؛ نه ← بیعانه همین حالا صادر می‌شود.
     * خروجی: آدرسی که مشتری باید برود (یا null)
     */
    public static function depositAnswer(Order $o, bool $edit, Cart $cart): ?string
    {
        if ($edit && $o->customerCanEdit()) {
            OrderWindows::startEdit($o);
            $cart->loadOrder($o->load('items'));
            $o->log('مشتری می‌خواهد پیش از بیعانه فاکتور را تغییر دهد (اقلام به سبد منتقل شد)', $o->user_id);

            return route('cart');
        }
        static::depositGo($o, $edit ? 'سفارش دیگر قابل ویرایش نبود' : 'مشتری تغییری نخواست');

        return null;
    }

    /** پایان مرحله سؤال ← صدور بیعانه */
    public static function depositGo(Order $o, string $why = ''): void
    {
        if ($o->deposit_ask === 'done') {
            return;
        }
        $o->forceFill(['deposit_ask' => 'done'])->saveQuietly();
        if ($why) {
            $o->log('صدور بیعانه: '.$why);
        }
        static::autoDeposit($o->refresh());
        // صدور دستی: به مشتری اطمینان و به همکار مسئول اعلان «آماده صدور بیعانه»
        $o->refresh();
        if ($o->status === 'on_hold' && ! $o->isPaid() && static::payments($o, 'deposit')->isEmpty() && static::confirmedSum($o) <= 0) {
            try {
                if (static::depCfg()['welcome'] && ($t = Chat::thread($o))) {
                    Chat::post($t, 's', $o->assignee, 'text', 'ممنون از شما 🌹 همکاران ما به‌زودی بیعانه سفارش را برایتان صادر می‌کنند و همین‌جا اطلاع می‌دهیم.');
                }
                if ($o->assignee_id) {
                    app(WebPush::class)->toUsers([$o->assignee_id], ['title' => 'سفارش '.fa((string) $o->number).' آماده صدور بیعانه', 'body' => $o->customer_name.' — '.($why ?: 'تأیید مشتری'), 'url' => url('/admin/orders/'.$o->id), 'tag' => 'dep-ready-'.$o->id]);
                }
            } catch (Throwable $e) {
                report($e);
            }
        }
    }

    /** مهلت واریز بیعانه برای یک پرداخت (null = بدون مهلت) */
    public static function depositDue(RemitPayment $p): ?\Illuminate\Support\Carbon
    {
        $h = static::depCfg()['hours'];

        return $p->kind === 'deposit' && empty($p->bounce) && $h > 0 && $p->created_at ? $p->created_at->copy()->addMinutes((int) round($h * 60)) : null;
    }

    /**
     * زمان‌بند: سؤال‌های بی‌پاسخ ← صدور بیعانه؛ یادآوری یک ساعت مانده؛ پایان مهلت واریز ← لغو خودکار سفارش
     */
    public static function depositTick(): array
    {
        $done = ['issued' => 0, 'cancelled' => 0, 'reminded' => 0];
        if (! static::enabled() || ! \App\Support\DbSchema::hasColumn('orders', 'deposit_ask')) {
            return $done;
        }
        $c = static::depCfg();
        if ($c['ask_hours'] > 0) {
            foreach (Order::query()->where('deposit_ask', 'ask')->where('deposit_asked_at', '<', now()->subMinutes((int) round($c['ask_hours'] * 60)))->limit(30)->get() as $o) {
                static::depositGo($o, 'مشتری در مهلت پاسخ نداد');
                $done['issued']++;
            }
        }
        // «در ویرایش مشتری»: پایان مهلت ← سؤال «بیعانه صادر کنیم؟» (بیعانه خودکار صادر نمی‌شود)
        $done['issued'] += OrderWindows::tick();
        if ($c['hours'] <= 0) {
            return $done;
        }
        $mins = (int) round($c['hours'] * 60);
        $rows = RemitPayment::query()->with('order')->where('kind', 'deposit')->whereIn('status', ['awaiting', 'rejected'])->when(static::hasBounce(), fn ($q) => $q->where('bounce', false))
            ->where('created_at', '<', now()->subMinutes(max(1, $mins - 60)))->orderBy('id')->limit(100)->get();
        foreach ($rows->groupBy('order_id') as $oid => $pays) {
            $o = $pays->first()->order;
            if (! $o || $o->status !== 'on_hold' || $o->isPaid()) {
                continue;
            }
            // فیشی رسیده و منتظر تأیید است، یا بخشی تأیید شده: لغو نمی‌شود
            if (RemitPayment::query()->where('order_id', $o->id)->whereIn('status', ['submitted', 'confirmed'])->exists()) {
                continue;
            }
            $due = $pays->min('created_at')->copy()->addMinutes($mins);
            if ($due->isFuture()) {
                if (\Illuminate\Support\Facades\Cache::add('dep.remind.'.$o->id, 1, 7200)) {
                    ChatFinance::note($o, '⏰ یادآوری: مهلت واریز بیعانه تا '.jdate($due, true).' است؛ پس از آن سفارش به‌طور خودکار لغو می‌شود.', true);
                    $done['reminded']++;
                }

                continue;
            }
            if (! $c['cancel']) {
                if (\Illuminate\Support\Facades\Cache::add('dep.late.'.$o->id, 1, 86400) && $o->assignee_id) {
                    app(WebPush::class)->toUsers([$o->assignee_id], ['title' => 'مهلت بیعانه سفارش '.fa($o->number).' تمام شد', 'body' => $o->customer_name.' — هنوز واریز نکرده', 'url' => url('/admin/orders/'.$o->id), 'tag' => 'dep-late-'.$o->id]);
                }

                continue;
            }
            try {
                ChatFinance::note($o, '⛔ مهلت واریز بیعانه تمام شد و سفارش به‌طور خودکار لغو شد. اگر هنوز کالاها را می‌خواهید، سفارش تازه ثبت کنید یا در همین گفتگو پیام بدهید.', true);
                $o->setStatus('cancelled', 'لغو خودکار: بیعانه در مهلت '.fa(rtrim(rtrim(number_format($c['hours'], 1), '0'), '.')).' ساعته واریز نشد');
                $done['cancelled']++;
            } catch (Throwable $e) {
                report($e);
            }
        }

        return $done;
    }

    /** صدور مانده حساب: مبلغ نهایی − تأییدشده‌ها − صادرشده‌های قبلی تسویه (منتظر واریزهای قبلی باطل می‌شوند) */
    public static function settle(Order $o, int $final, ?array $remitIds = null, ?User $by = null): ?Collection
    {
        if ($why = OrderWindows::issueBlock($o, 'settle')) {
            throw ValidationException::withMessages(['amount' => $why]);
        }

        return DB::transaction(function () use ($o, $final, $remitIds, $by) {
            // تسویه‌های قبلی که هنوز واریز نشده باطل می‌شوند تا مبلغ تازه جایگزین شود
            // کارت «واریز مجدد حواله برگشتی» باطل نمی‌شود (حساب جدید کارخانه) و مبلغش «در راه» حساب می‌شود
            RemitPayment::query()->where('order_id', $o->id)->where('kind', 'settle')->whereIn('status', ['awaiting', 'rejected'])
                ->when(static::hasBounce(), fn ($q) => $q->where('bounce', false))->update(['status' => 'cancelled']);
            $o->final_amount = $final;
            $o->saveQuietly();
            $paid = static::confirmedSum($o) + (int) RemitPayment::query()->where('order_id', $o->id)->where('status', 'submitted')->sum('amount')
                + (static::hasBounce() ? (int) RemitPayment::query()->where('order_id', $o->id)->where('bounce', true)->whereIn('status', ['awaiting', 'rejected'])->sum('amount') : 0);
            // خرید نقد و چک: فقط سهم نقدی با حواله‌ها گرفته می‌شود (بقیه با چک)
            // + مانده قبلی مشتری در هلو (بدهی اضافه، طلب کم می‌شود)
            $prior = OrderPrior::bal($o);
            $left = ($o->cash_amount !== null ? (int) $o->cash_amount : $final) + $prior - $paid;
            if ($prior) {
                $o->log('مانده حساب با '.($prior > 0 ? 'بدهی' : 'طلب').' قبلی هلو ('.money(abs($prior)).' تومان) حساب شد', $by?->id);
            }
            if ($left <= 0) {
                $o->log('مبلغ نهایی '.money($final).' تومان ثبت شد؛ '.($left < 0 ? 'مشتری '.money(-$left).' تومان بستانکار است.' : 'مانده‌ای ندارد.'), $by?->id);
                static::checkPaid($o);

                return null;
            }
            if ($o->isPaid()) {
                // اصلاح پس از پرداخت کامل و مبلغ بیشتر شد: سفارش دوباره «پرداخت‌نشده» تا مانده تازه واریز شود
                $o->forceFill(['payment_status' => 'unpaid', 'paid_at' => null])->saveQuietly();
                $o->log('با اصلاح مانده حساب، '.money($left).' تومان دیگر باید پرداخت شود؛ وضعیت پرداخت سفارش «پرداخت‌نشده» شد.', $by?->id);
            }

            return static::issue($o, 'settle', $left, $remitIds, $by);
        });
    }

    /**
     * صدور مانده حساب با تخفیف و (برای خرید نقد و چک) سهم نقدی + مشخصات چک‌ها
     *
     * @param  array<int, array{amount: int, due: string, nid: string}>|null  $cheques  null = خرید نقدی
     */
    public static function settleFull(Order $o, int $discount, ?int $cash, ?array $cheques, ?array $remitIds = null, ?User $by = null): ?Collection
    {
        if ($why = OrderWindows::issueBlock($o, 'settle')) {
            throw ValidationException::withMessages(['amount' => $why]);
        }

        return DB::transaction(function () use ($o, $discount, $cash, $cheques, $remitIds, $by) {
            $before = static::settleSnap($o);
            $o->extra_discount = max(0, $discount);
            $o->saveQuietly();
            Picking::recalc($o);
            $o->refresh();
            $final = (int) $o->total;
            if ($cheques !== null) {
                $rows = [];
                foreach ($cheques as $c) {
                    $amt = (int) to_int($c['amount'] ?? 0);
                    if ($amt <= 0) {
                        continue;
                    }
                    $due = \App\Support\Jalali::parse((string) ($c['due'] ?? ''));
                    if (! $due) {
                        throw ValidationException::withMessages(['cheques' => 'تاریخ سررسید چک '.money($amt).' تومانی را به شکل ۱۴۰۵/۰۸/۳۰ بنویسید.']);
                    }
                    $nid = preg_replace('/\D/', '', en_digits((string) ($c['nid'] ?? '')));
                    if ($nid !== '' && ! in_array(strlen($nid), [10, 11], true)) {
                        throw ValidationException::withMessages(['cheques' => 'کد ملی / شناسه ملی ثبت چک باید ۱۰ یا ۱۱ رقم باشد.']);
                    }
                    $rows[] = ['amount' => $amt, 'due' => $due->toDateString(), 'due_fa' => \App\Support\Jalali::format($due), 'nid' => $nid ?: null,
                        'name' => mb_substr(trim((string) ($c['name'] ?? '')), 0, 120) ?: null];
                }
                $sum = (int) $cash + array_sum(array_column($rows, 'amount'));
                if ($sum !== $final) {
                    throw ValidationException::withMessages(['cheques' => 'جمع نقد و چک‌ها ('.money($sum).') با مبلغ نهایی سفارش ('.money($final).' تومان) برابر نیست؛ اختلاف: '.money(abs($final - $sum)).' تومان.']);
                }
                $ch = (array) $o->cheque;
                // مدارک قبلیِ هر چک (عکس/صیاد) فقط اگر مبلغ و تاریخ همان چک عوض نشده باشد حفظ می‌شود
                foreach ($rows as $k => $r) {
                    $old = $ch['settle'][$k] ?? null;
                    if (! empty($old['docs']) && (int) ($old['amount'] ?? 0) === (int) $r['amount'] && (string) ($old['due'] ?? '') === (string) $r['due']) {
                        $rows[$k]['docs'] = $old['docs'];
                    }
                }
                $ch['settle'] = $rows;
                $ch['payee'] = ['nid' => $rows[0]['nid'] ?? null, 'name' => $rows[0]['name'] ?? null];
                $o->cheque = $ch;
                $o->cash_amount = (int) $cash;
                $o->saveQuietly();
                $o->log('مانده حساب: نقد '.money((int) $cash).' تومان + '.fa(count($rows)).' چک ('.collect($rows)->map(fn ($r) => money($r['amount']).' — '.$r['due_fa'])->implode('، ').')'
                    .($o->extra_discount ? ' — تخفیف '.money($o->extra_discount).' تومان' : ''), $by?->id);
                ChatFinance::chequeCard($o);
            } else {
                if ($o->cash_amount !== null) {
                    $o->cash_amount = null;
                    $o->saveQuietly();
                }
                if ($o->extra_discount) {
                    $o->log('تخفیف '.money($o->extra_discount).' تومان در صدور مانده حساب لحاظ شد', $by?->id);
                }
            }

            if ($before && ($diff = static::settleDiff($before, static::settleSnap($o->refresh())))) {
                $o->log('✏️ اصلاح مانده حساب'.($by ? ' توسط '.$by->displayName() : '').': '.implode('؛ ', $diff), $by?->id);
                ChatFinance::note($o, "✏️ مانده حساب سفارش شما اصلاح شد:\n• ".implode("\n• ", $diff)."\nلطفاً طبق کارت‌های تازه همین گفتگو اقدام کنید.", true);
            }

            return static::settle($o, $final, $remitIds, $by);
        });
    }

    /** وضعیت مانده حساب (برای ثبت تغییرات): فقط اگر قبلاً صادر شده */
    protected static function settleSnap(Order $o): ?array
    {
        if (! $o->final_amount && empty(((array) $o->cheque)['settle'])) {
            return null;
        }

        return [
            'final' => (int) $o->final_amount, 'disc' => (int) $o->extra_discount, 'cash' => $o->cash_amount,
            'cheques' => collect((array) (((array) $o->cheque)['settle'] ?? []))->map(fn ($r) => ['amount' => (int) ($r['amount'] ?? 0), 'due' => (string) ($r['due_fa'] ?? '')])->values()->all(),
        ];
    }

    /** خط‌های فارسی تغییرات مانده حساب (قبل ← بعد) */
    protected static function settleDiff(array $a, array $b): array
    {
        $out = [];
        if ($a['final'] && $a['final'] !== $b['final']) {
            $out[] = 'مبلغ نهایی فاکتور '.money($a['final']).' ← '.money($b['final']).' تومان';
        }
        if ($a['disc'] !== $b['disc']) {
            $out[] = 'تخفیف '.money($a['disc']).' ← '.money($b['disc']).' تومان';
        }
        if ($a['cash'] !== null && $b['cash'] !== null && (int) $a['cash'] !== (int) $b['cash']) {
            $out[] = 'مبلغ نقدی '.money((int) $a['cash']).' ← '.money((int) $b['cash']).' تومان';
        }
        $n = max(count($a['cheques']), count($b['cheques']));
        for ($i = 0; $i < $n; $i++) {
            $x = $a['cheques'][$i] ?? null;
            $y = $b['cheques'][$i] ?? null;
            $lbl = 'چک '.fa($i + 1);
            if ($x && ! $y) {
                $out[] = $lbl.' ('.money($x['amount']).' — '.fa($x['due']).') حذف شد';
            } elseif (! $x && $y) {
                $out[] = $lbl.' تازه: '.money($y['amount']).' تومان — سررسید '.fa($y['due']);
            } elseif ($x['amount'] !== $y['amount'] || $x['due'] !== $y['due']) {
                $out[] = $lbl.': '.money($x['amount']).' — '.fa($x['due']).' ← '.money($y['amount']).' — '.fa($y['due'])
                    .' (عکس و ثبت صیاد این چک دوباره لازم است)';
            }
        }

        return $out;
    }

    /**
     * اصلاح مبلغ صادرشده (بیعانه/تسویه) پیش از تأیید واریز — مثلاً مشتری کل مبلغ را به یکی از دو حواله زده است.
     * $rebalance: جمع کل همان بابت ثابت می‌ماند؛ اختلاف از پرداخت‌های بازِ دیگر این سفارش کم/به آن‌ها اضافه می‌شود
     * (پرداختی که صفر شود باطل می‌شود و کمبود ظرفیت با صدور تازه جبران می‌شود). همه تغییرات در تاریخچه ثبت می‌شود.
     */
    public static function editPayment(RemitPayment $p, int $amount, ?int $remitId = null, bool $rebalance = true, ?User $by = null): void
    {
        if (! in_array($p->status, ['awaiting', 'rejected', 'submitted'], true)) {
            throw ValidationException::withMessages(['amount' => 'فقط مبلغی که هنوز تأیید نشده قابل اصلاح است.']);
        }
        if ($amount <= 0) {
            throw ValidationException::withMessages(['amount' => 'مبلغ باید بیشتر از صفر باشد (برای حذف، «ابطال» را بزنید).']);
        }
        DB::transaction(function () use ($p, $amount, $remitId, $rebalance, $by) {
            $p = RemitPayment::query()->lockForUpdate()->findOrFail($p->id);
            $o = $p->order;
            $oldAmount = (int) $p->amount;
            $oldRemit = $p->remittance;
            $target = $remitId ? Remittance::query()->lockForUpdate()->findOrFail($remitId) : $oldRemit;
            if ($target->status !== 'active' && $target->id !== $oldRemit->id) {
                throw ValidationException::withMessages(['amount' => 'حواله '.$target->code.' باز نیست.']);
            }
            $room = $target->stats()['free'] + ($target->id === $oldRemit->id ? $oldAmount : 0);
            if ($amount > $room) {
                throw ValidationException::withMessages(['amount' => 'ظرفیت آزاد حواله '.$target->code.' فقط '.money($room).' تومان است.']);
            }
            $p->forceFill(['amount' => $amount, 'remittance_id' => $target->id])->save();
            $msg = 'اصلاح '.$p->kindLabel().': '.money($oldAmount).' تومان (حواله '.$oldRemit->code.') ← '.money($amount).' تومان (حواله '.$target->code.')';
            $delta = $amount - $oldAmount;
            if ($rebalance && $delta !== 0) {
                $others = RemitPayment::query()->with('remittance')->where('order_id', $p->order_id)->where('kind', $p->kind)
                    ->whereKeyNot($p->id)->whereIn('status', ['awaiting', 'rejected'])->when(static::hasBounce(), fn ($q) => $q->where('bounce', false))->orderByDesc('id')->lockForUpdate()->get();
                $changes = [];
                if ($delta > 0) {
                    // مبلغ این حواله بیشتر شد ← از بقیه کم شود
                    $need = $delta;
                    foreach ($others as $q) {
                        if ($need <= 0) {
                            break;
                        }
                        $cut = min($need, (int) $q->amount);
                        $need -= $cut;
                        if ($cut >= (int) $q->amount) {
                            $q->forceFill(['status' => 'cancelled'])->save();
                            $changes[] = $q->remittance->code.' باطل شد ('.money($cut).')';
                        } else {
                            $q->forceFill(['amount' => (int) $q->amount - $cut])->save();
                            $changes[] = $q->remittance->code.' −'.money($cut);
                        }
                    }
                } else {
                    // کمتر شد ← به بقیه اضافه شود (تا ظرفیت آزاد) و باقی‌مانده صادر شود
                    $add = -$delta;
                    foreach ($others as $q) {
                        if ($add <= 0) {
                            break;
                        }
                        $free = $q->remittance->stats()['free'];
                        $put = min($add, $free);
                        if ($put > 0) {
                            $q->forceFill(['amount' => (int) $q->amount + $put])->save();
                            $add -= $put;
                            $changes[] = $q->remittance->code.' +'.money($put);
                        }
                    }
                    if ($add > 0) {
                        $made = static::issue($o, $p->kind, $add, null, $by);
                        $changes[] = 'صدور تازه '.money($add).' ('.$made->map(fn ($m) => $m->remittance->code)->implode('، ').')';
                    }
                }
                if ($changes) {
                    $msg .= ' — خودکار: '.implode('، ', $changes);
                }
            }
            $o->log($msg, $by?->id ?? auth()->id());
            if ($oldAmount !== $amount) {
                ChatFinance::note($o, '✏️ مبلغ '.$p->kindLabel().' اصلاح شد: '.money($oldAmount).' ← '.money($amount).' تومان');
            }
            if ($p->status === 'submitted' || $oldRemit->id !== $target->id) {
                static::checkFilled($oldRemit->fresh());
            }
        });
    }

    /**
     * مشتری (یا کارمند به‌جای او) فیش واریز را می‌فرستد — چند تصویر (واریزهای خرد)
     * فیشی که «در حال بررسی» است: تصاویر تازه به قبلی‌ها اضافه می‌شوند؛ رد شده/منتظر: جایگزین می‌شوند.
     *
     * @param  UploadedFile|array<UploadedFile>  $files
     */
    public static function submit(RemitPayment $p, UploadedFile|array $files, ?string $ref = null, ?string $paidOn = null, ?string $note = null, bool $append = true): void
    {
        if (! $p->payable()) {
            throw ValidationException::withMessages(['receipt' => 'این پرداخت دیگر قابل تغییر نیست.']);
        }
        $files = array_values(array_filter(is_array($files) ? $files : [$files], fn ($f) => $f instanceof UploadedFile));
        if (! $files) {
            throw ValidationException::withMessages(['receipt' => 'تصویر فیش را انتخاب کنید.']);
        }
        $old = $p->files();
        $keep = $append && $p->status === 'submitted' ? $old : [];
        $hashes = static::receiptDupCheck($p, $files, $append && $p->status === 'submitted', $note && str_starts_with($note, 'بارگذاری توسط') ? 'st' : 'cu');
        $new = [];
        foreach ($files as $k => $file) {
            // عکس فیش با حجم کم و بدون افت خوانایی (عکس چندمگابایتی گوشی ← چندصد کیلوبایت)
            $new[] = \App\Support\DocImages::store($file, 'receipts/'.($p->order_id ?: 'walkin'), $p->id.'-'.now()->format('YmdHis').'-'.$k.substr(md5(uniqid('', true)), 0, 4));
        }
        $all = array_values(array_merge($keep, $new));
        $p->forceFill([
            'receipt_path' => $all[0], 'receipt_files' => $all,
        ] + ($hashes !== null ? ['receipt_hashes' => json_encode($hashes)] : []) + [
            'receipt_ref' => $ref ? mb_substr(en_digits($ref), 0, 80) : $p->receipt_ref,
            'paid_on' => $paidOn ? mb_substr($paidOn, 0, 30) : $p->paid_on, 'customer_note' => $note ? mb_substr($note, 0, 300) : $p->customer_note,
            'status' => 'submitted', 'submitted_at' => now(), 'reject_reason' => null,
        ])->save();
        foreach (array_diff($old, $all) as $gone) {
            Storage::disk('local')->delete($gone);
        }
        $o = $p->order;
        if (! $o) { // فیش حضوری (بدون سفارش)
            static::smsFactory($p->remittance, 'receipt', $p);
            if ($to = array_filter([$p->remittance->assignee_id, $p->issued_by])) {
                app(WebPush::class)->toUsers(array_values(array_unique($to)), ['title' => 'فیش حضوری رسید — '.$p->walkin_name,
                    'body' => money($p->amount).' تومان — حواله '.$p->remittance->code, 'url' => url('/manage/receipts?tab=submitted'), 'tag' => 'rcpt-'.$p->id]);
            }

            return;
        }
        $o->log(($note && str_starts_with($note, 'بارگذاری توسط') ? $note.': ' : 'مشتری ').fa(count($new)).' تصویر فیش '.$p->kindLabel().' '.money($p->amount).' تومان (حواله '.$p->remittance->code.') را فرستاد'.(count($all) > count($new) ? ' — جمعاً '.fa(count($all)).' تصویر' : ''));
        static::smsFactory($p->remittance, 'receipt', $p);
        ChatFinance::note($o, '📎 '.($note && str_starts_with($note, 'بارگذاری توسط') ? 'فیش' : 'فیش شما').' '.$p->kindLabel().' '.money($p->amount).' تومان رسید'.(count($all) > 1 ? ' ('.fa(count($all)).' تصویر)' : '').' — در حال بررسی');
        $to = array_filter([$p->remittance->assignee_id, $o->assignee_id]);
        if ($to) {
            app(WebPush::class)->toUsers(array_values(array_unique($to)), ['title' => 'فیش واریزی تازه — سفارش '.fa($o->number),
                'body' => $o->customer_name.' — '.money($p->amount).' تومان '.$p->kindLabel(), 'url' => url('/admin/remit-payments?tableFilters[status][value]=submitted'), 'tag' => 'rcpt-'.$p->id]);
        }
    }

    /**
     * فیش تکراری: اثر انگشت فایل اصلی (محتوا) و نام+حجم. تکرار در همین ارسال، در فیش‌های همین کارت،
     * یا فیشی که قبلاً برای پرداخت دیگری از همین مشتری فرستاده شده ← خطا.
     *
     * @return array|null اثر انگشت‌هایی که باید ذخیره شود (null = ستون نیست)
     */
    public static function receiptDupCheck(RemitPayment $p, array $files, bool $append, string $src = 'cu'): ?array
    {
        if (! \App\Support\DbSchema::hasColumn('remit_payments', 'receipt_hashes')) {
            return null;
        }
        $mine = $append ? (array) json_decode((string) $p->receipt_hashes, true) : [];
        $seen = [];
        foreach ($mine as $h) {
            $seen[$h['h'] ?? ''] = true;
            $seen['n:'.($h['n'] ?? '')] = true;
        }
        unset($seen[''], $seen['n:']);
        $out = $mine;
        foreach ($files as $f) {
            $h = @sha1_file($f->getRealPath()) ?: '';
            $sig = mb_strtolower((string) $f->getClientOriginalName()).'|'.(int) $f->getSize();
            if (($h && isset($seen[$h])) || isset($seen['n:'.$sig])) {
                throw ValidationException::withMessages(['receipt' => 'فیش تکراری است («'.$f->getClientOriginalName().'»). هر فیش را فقط یک بار بارگذاری کنید.']);
            }
            // همین فیش برای پرداخت دیگری از همین مشتری؟
            if ($h && $p->order_id) {
                $other = RemitPayment::query()->where('id', '!=', $p->id)->where('receipt_hashes', 'like', '%"'.$h.'"%')
                    ->whereHas('order', fn ($q) => $q->where('user_id', $p->order?->user_id))->with('order:id,number')->first();
                if ($other) {
                    throw ValidationException::withMessages(['receipt' => 'این فیش قبلاً برای '.$other->kindLabel().' سفارش '.fa((string) $other->order?->number).' بارگذاری شده است؛ فیش تکراری قابل قبول نیست.']);
                }
            }
            $seen[$h] = true;
            $seen['n:'.$sig] = true;
            $out[] = ['h' => $h, 'n' => $sig, 's' => $src];
        }

        return $out;
    }

    /**
     * فیش این کارت هم از طرف همکار (مثلاً عکس گفتگو) و هم از طرف خود مشتری ثبت شده؟ ← احتمال تکرار؛ فقط هشدار برای بررسی‌کننده
     * (تشخیص خودکار از روی تصویر قابل اعتماد نیست: فیش‌های دو واریز جدا از یک بانک تقریباً یکسان‌اند)
     */
    public static function mixedSources(RemitPayment $p): bool
    {
        $src = array_filter(array_column((array) json_decode((string) ($p->receipt_hashes ?? ''), true), 's'));

        return in_array('st', $src, true) && in_array('cu', $src, true);
    }

    /** تأیید فیش توسط کمک‌حسابدار */
    public static function confirm(RemitPayment $p, ?User $by = null): void
    {
        if ($p->status === 'confirmed') {
            return;
        }
        $p->forceFill(['status' => 'confirmed', 'reviewed_by' => $by?->id ?? auth()->id(), 'reviewed_at' => now(), 'reject_reason' => null])->save();
        $o = $p->order;
        $r = $p->remittance;
        if (! $o) { // فیش حضوری
            static::checkFilled($r);

            return;
        }
        $o->log('فیش '.$p->kindLabel().' '.money($p->amount).' تومان (حواله '.$r->code.') تأیید شد', $by?->id);
        ChatFinance::note($o, '✅ فیش '.$p->kindLabel().' '.money($p->amount).' تومان تأیید شد.', true);
        static::checkFilled($r);
        static::afterConfirm($o->fresh(), $p->kind);
    }

    /** پس از تأیید: بیعانه کامل ← ارجاع خودکار به انبار؛ تسویه کامل ← پرداخت‌شده */
    protected static function afterConfirm(Order $o, string $kind): void
    {
        $open = RemitPayment::query()->where('order_id', $o->id)->where('kind', $kind)->whereIn('status', ['awaiting', 'submitted', 'rejected'])->exists();
        if ($open) {
            return;
        }
        $dep = static::confirmedSum($o, 'deposit');
        $o->forceFill(['deposit_amount' => $dep])->saveQuietly();
        if ($kind === 'deposit' && in_array($o->status, ['on_hold', 'processing'], true)) {
            $refs = RemitPayment::query()->where('order_id', $o->id)->where('kind', 'deposit')->where('status', 'confirmed')->pluck('receipt_ref')->filter()->implode('، ');
            if ($refs) {
                $o->forceFill(['deposit_ref' => mb_substr($refs, 0, 120)])->saveQuietly();
            }
            // «در انتظار بررسی» ← «در حال آماده‌سازی» خودش ارجاع خودکار به انبار را انجام می‌دهد (Order::setStatus)
            if ($o->status === 'on_hold') {
                $o->setStatus('processing', 'بیعانه '.money($dep).' تومان تأیید شد');
            } else {
                Picking::autoRefer($o, 'بیعانه تأیید شد');
            }
        }
        if ($kind === 'deposit') {
            Chat::warn($o, 'deposit');
        }
        if ($kind === 'settle' || $o->final_amount) {
            static::checkPaid($o);
        }
    }

    /**
     * اصلاح فیش تأییدشده‌ای که پولش کامل نرسیده (مثلاً کارخانه‌دار تأیید نمی‌کند: ۶ میلیون تأیید شده ولی ۶۰۰ هزار واریز شده).
     * مبلغ فیش به مبلغ واقعی کم می‌شود (اگر ۰: فیش «رد» می‌شود تا مشتری دوباره بفرستد)، کسری به‌صورت مبلغ تازه «منتظر واریز»
     * روی همان حواله (یا حواله آزاد دیگر) صادر می‌شود، «پرداخت‌شده» بودن سفارش برمی‌گردد، و به مشتری در گفتگو گفته می‌شود.
     */
    public static function hasBounce(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('remit_payments', 'bounce');
    }

    /**
     * پول برگشتی: واریز به حساب کارخانه برگشت خورده (هیچ مبلغی نرسیده). فیش قبلی باطل و کارت «واریز مجدد حواله برگشتی»
     * با همان مبلغ در همان حواله صادر می‌شود — به همان حساب یا به حساب جدیدی که حسابدار ارشد وارد کرده.
     * این کارت را اپراتور نمی‌تواند باطل کند؛ فقط فیش را بارگذاری می‌کند و برای کارخانه می‌رود.
     *
     * @param  array{dest: string, holder?: string, bank?: string, card?: string, sheba?: string}  $bounce
     */
    public static function bounce(RemitPayment $p, array $bounce, string $reason, ?User $by = null): RemitPayment
    {
        $new = ($bounce['dest'] ?? 'same') === 'new';
        $acc = null;
        if ($new) {
            $acc = ['holder' => mb_substr(trim((string) ($bounce['holder'] ?? '')), 0, 120), 'bank' => mb_substr(trim((string) ($bounce['bank'] ?? '')), 0, 60),
                'card' => \App\Support\Banks::digits((string) ($bounce['card'] ?? '')), 'sheba' => strtoupper(preg_replace('/\s+/', '', en_digits((string) ($bounce['sheba'] ?? ''))))];
            if ($acc['holder'] === '' || ($acc['card'] === '' && $acc['sheba'] === '')) {
                throw ValidationException::withMessages(['holder' => 'برای حساب جدید، نام صاحب حساب و شماره کارت یا شبا را بنویسید.']);
            }
            if ($acc['sheba'] !== '' && ! str_starts_with($acc['sheba'], 'IR')) {
                $acc['sheba'] = 'IR'.$acc['sheba'];
            }
        }

        return DB::transaction(function () use ($p, $acc, $reason, $by) {
            $p = RemitPayment::query()->lockForUpdate()->findOrFail($p->id);
            $o = $p->order;
            $r = $p->remittance;
            $who = $by?->displayName() ?? 'سیستم';
            $p->forceFill(['status' => 'cancelled', 'reject_reason' => 'واریز برگشت خورد — '.$reason, 'factory_confirmed_at' => null, 'reviewed_by' => $by?->id, 'reviewed_at' => now()])->save();
            $n = new RemitPayment([
                'remittance_id' => $r->id, 'order_id' => $p->order_id, 'user_id' => $p->user_id, 'kind' => $p->kind, 'amount' => (int) $p->amount,
                'status' => 'awaiting', 'issued_by' => $by?->id, 'walkin_name' => $p->walkin_name ?? null, 'walkin_mobile' => $p->walkin_mobile ?? null,
            ]);
            $n->forceFill(['bounce' => true, 'bounce_of' => $p->id, 'alt_account' => $acc])->save();
            $to = $acc ? 'حساب جدید '.$acc['holder'].($acc['bank'] ? ' ('.$acc['bank'].')' : '') : 'همان حساب '.$r->holder_name;
            $msg = '🔁 پول برگشتی: واریز '.$p->kindLabel().' '.money($p->amount).' تومان به حساب '.$r->holder_name.' (حواله '.$r->code.') برگشت خورد — علت: '.$reason
                .'. کارت «واریز مجدد حواله برگشتی» برای '.$to.' صادر شد (در همان حواله حساب می‌شود) — '.$who;
            if ($o) {
                if ($o->isPaid()) {
                    $o->forceFill(['payment_status' => 'unpaid', 'paid_at' => null])->saveQuietly();
                    $msg .= '. سفارش از «پرداخت‌شده» خارج شد';
                    if ($o->status === 'to_freight' && ! $o->loaded_at) {
                        $o->forceFill(['status' => 'settling', 'status_changed_at' => now()])->saveQuietly();
                        $msg .= ' و به «در انتظار تسویه» برگشت';
                    } elseif ($o->loadingLocked()) {
                        $msg .= ' (⚠ بار برای بارگیری رفته؛ پیش از تحویل پیگیری کنید)';
                    }
                }
                if ($p->kind === 'deposit') {
                    $o->forceFill(['deposit_amount' => static::confirmedSum($o, 'deposit')])->saveQuietly();
                }
                $o->log($msg, $by?->id);
                ChatFinance::note($o, '⚠ واریز '.money($p->amount).' تومانی شما به حساب '.$r->holder_name.' برگشت خورده و به حساب نرسیده است. لطفاً همین مبلغ را '
                    .($acc ? 'به حساب جدید زیر (به نام '.$acc['holder'].')' : 'دوباره به همان حساب').' واریز و فیشش را روی کارت تازه بفرستید.', true);
                ChatFinance::issued($o, collect([$n]));
                try {
                    if ($o->assignee_id) {
                        app(\App\Services\WebPush::class)->toUsers([$o->assignee_id], ['title' => '🔁 واریز برگشتی — سفارش '.fa($o->number), 'body' => money($p->amount).' تومان باید دوباره واریز شود ('.$to.')', 'url' => url('/admin/chats?o='.$o->id), 'tag' => 'bounce-'.$n->id]);
                    }
                } catch (\Throwable $e) {
                    report($e);
                }
            }
            static::checkFilled($r->fresh());

            return $n;
        });
    }

    public static function fixConfirmed(RemitPayment $p, int $actual, string $reason, ?User $by = null, ?array $bounce = null): array
    {
        if ($p->status !== 'confirmed') {
            throw ValidationException::withMessages(['amount' => 'فقط فیش تأییدشده با این روش اصلاح می‌شود.']);
        }
        $reason = mb_substr(trim(strip_tags($reason)), 0, 200);
        if (mb_strlen($reason) < 3) {
            throw ValidationException::withMessages(['reason' => 'علت را بنویسید (مثلاً «کارخانه‌دار فقط ۶۰۰ هزار دریافت کرده»).']);
        }
        if ($actual < 0 || $actual >= (int) $p->amount) {
            throw ValidationException::withMessages(['amount' => 'مبلغ واقعی واریز باید کمتر از '.money($p->amount).' تومان باشد.']);
        }
        if ($actual === 0 && $bounce && static::hasBounce()) {
            $n = static::bounce($p, $bounce, $reason, $by);

            return ['short' => (int) $p->amount, 'new' => $n, 'bounce' => true];
        }

        return DB::transaction(function () use ($p, $actual, $reason, $by) {
            $p = RemitPayment::query()->lockForUpdate()->findOrFail($p->id);
            $o = $p->order;
            $r = $p->remittance;
            $old = (int) $p->amount;
            $short = $old - $actual;
            $who = $by?->displayName() ?? 'سیستم';
            $new = null;
            if ($actual === 0) {
                // هیچ پولی نرسیده: فیش رد می‌شود؛ مشتری فیش درست را برای همین مبلغ می‌فرستد
                $p->forceFill(['status' => 'rejected', 'reject_reason' => 'واریز به حساب نرسیده — '.$reason, 'factory_confirmed_at' => null, 'reviewed_by' => $by?->id, 'reviewed_at' => now()])->save();
                $msg = 'اصلاح فیش تأییدشده '.$p->kindLabel().' '.money($old).' تومان (حواله '.$r->code.'): هیچ مبلغی به حساب نرسیده؛ فیش رد شد و دوباره منتظر واریز است — علت: '.$reason.' — '.$who;
            } else {
                $p->forceFill(['amount' => $actual])->save();
                $new = RemitPayment::query()->create([
                    'remittance_id' => $r->id, 'order_id' => $p->order_id, 'user_id' => $p->user_id, 'kind' => $p->kind, 'amount' => $short,
                    'status' => 'awaiting', 'issued_by' => $by?->id, 'walkin_name' => $p->walkin_name ?? null, 'walkin_mobile' => $p->walkin_mobile ?? null,
                ]);
                $msg = 'اصلاح فیش تأییدشده '.$p->kindLabel().' (حواله '.$r->code.'): '.money($old).' ← '.money($actual).' تومان (مبلغ واقعی واریز)؛ کسری '.money($short).' تومان دوباره صادر شد و منتظر واریز است — علت: '.$reason.' — '.$who;
            }
            if ($o) {
                if ($o->isPaid()) {
                    $o->forceFill(['payment_status' => 'unpaid', 'paid_at' => null])->saveQuietly();
                    $msg .= '. سفارش از «پرداخت‌شده» خارج شد';
                    if ($o->status === 'to_freight' && ! $o->loaded_at) {
                        $o->forceFill(['status' => 'settling', 'status_changed_at' => now()])->saveQuietly();
                        $msg .= ' و به «در انتظار تسویه» برگشت';
                    } elseif ($o->loadingLocked()) {
                        $msg .= ' (⚠ بار برای بارگیری رفته؛ پیش از تحویل پیگیری کنید)';
                    }
                }
                if ($p->kind === 'deposit') {
                    $o->forceFill(['deposit_amount' => static::confirmedSum($o, 'deposit')])->saveQuietly();
                }
                $o->log($msg, $by?->id);
                ChatFinance::note($o, '⚠ از فیش '.money($old).' تومانی شما، '.($actual ? 'فقط '.money($actual).' تومان' : 'هیچ مبلغی').' به حساب '.$r->holder_name.' رسیده است. لطفاً '
                    .money($short).' تومان باقی‌مانده را به همان حساب واریز و فیشش را همین‌جا بفرستید.', true);
            }
            static::checkFilled($r->fresh());
            if ($by && $o) {
                try {
                    if ($o->assignee_id && $o->assignee_id !== $by->id) {
                        app(\App\Services\WebPush::class)->toUsers([$o->assignee_id], ['title' => 'کسری فیش سفارش '.fa($o->number), 'body' => money($short).' تومان دوباره صادر شد', 'url' => url('/admin/orders/'.$o->id), 'tag' => 'fix-'.$p->id]);
                    }
                } catch (\Throwable $e) {
                    report($e);
                }
            }

            return ['short' => $short, 'new' => $new];
        });
    }

    /**
     * لغو تأیید کارخانه‌دار (اشتباه زده: «به حسابم نشست» ولی هنوز ننشسته).
     * فیش به حالت پیش از کلیک برمی‌گردد: تأیید کارخانه پاک می‌شود و اگر همان کلیک فیش را خودکار تأیید کرده بود
     * (تنظیم «تأیید کارخانه‌دار = تأیید فیش»)، فیش دوباره «منتظر بررسی» می‌شود. به مشتری چیزی گفته نمی‌شود
     * (شاید پول فقط دیر برسد)؛ اگر مطمئنید نرسیده، بعد از این «⚠ کسری» را بزنید.
     */
    public static function undoFactory(RemitPayment $p, string $reason, ?User $by = null, ?string $factoryName = null): void
    {
        if (! $p->factory_confirmed_at) {
            throw ValidationException::withMessages(['pay' => 'کارخانه‌دار این فیش را تأیید نکرده است.']);
        }
        $reason = mb_substr(trim(strip_tags($reason)), 0, 200);
        if (mb_strlen($reason) < 3) {
            throw ValidationException::withMessages(['reason' => 'علت را بنویسید (مثلاً «کارخانه‌دار اشتباه تأیید کرده؛ هنوز به حسابش ننشسته»).']);
        }
        DB::transaction(function () use ($p, $reason, $by, $factoryName) {
            $p = RemitPayment::query()->lockForUpdate()->findOrFail($p->id);
            $auto = $p->status === 'confirmed' && ! $p->reviewed_by; // همان کلیک کارخانه‌دار فیش را تأیید کرده بود
            $upd = ['factory_confirmed_at' => null];
            if ($auto) {
                $upd += ['status' => 'submitted', 'reviewed_at' => null];
            }
            $p->forceFill($upd)->save();
            $o = $p->order;
            $r = $p->remittance;
            $who = $factoryName ? 'کارخانه‌دار ('.$factoryName.')' : ($by?->displayName() ?? 'سیستم');
            $msg = '↩ تأیید کارخانه‌دار برای فیش '.$p->kindLabel().' '.money($p->amount).' تومان (حواله '.$r?->code.') لغو شد'
                .($auto ? '؛ فیش دوباره «منتظر بررسی» است' : '؛ فیش همچنان با تأیید اپراتور می‌ماند')
                .' — علت: '.$reason.' — '.$who;
            if ($o && $auto) {
                if ($o->isPaid()) {
                    $o->forceFill(['payment_status' => 'unpaid', 'paid_at' => null])->saveQuietly();
                    $msg .= '. سفارش از «پرداخت‌شده» خارج شد';
                    if ($o->status === 'to_freight' && ! $o->loaded_at) {
                        $o->forceFill(['status' => 'settling', 'status_changed_at' => now()])->saveQuietly();
                        $msg .= ' و به «در انتظار تسویه» برگشت';
                    } elseif ($o->loadingLocked()) {
                        $msg .= ' (⚠ بار برای بارگیری رفته؛ پیش از تحویل پیگیری کنید)';
                    }
                }
                if ($p->kind === 'deposit' && $o->fulfil_status) {
                    $msg .= ' (⚠ سفارش با همین بیعانه به انبار رفته است؛ تا نشستن پول پیگیری کنید)';
                }
            }
            $o?->log($msg, $by?->id);
            if ($r && $r->status === 'filled' && $r->stats()['confirmed'] < (int) $r->amount) {
                $r->forceFill(['status' => 'active', 'filled_at' => null])->save(); // حواله با این فیش پر شده بود
            }
            try {
                $to = array_values(array_unique(array_filter([(int) $o?->assignee_id, (int) $r?->assignee_id])));
                if ($to) {
                    app(WebPush::class)->toUsers($to, ['title' => '↩ لغو تأیید کارخانه‌دار — '.money($p->amount).' تومان', 'body' => ($o ? 'سفارش '.fa($o->number).' — ' : '').$reason,
                        'url' => $o ? url('/admin/orders/'.$o->id) : url('/admin/remit-payments'), 'tag' => 'undo-'.$p->id]);
                }
            } catch (Throwable $e) {
                report($e);
            }
        });
    }

    /** در حین صدور/اصلاح مانده حساب، تغییر مبلغ هشدار جدا نمی‌دهد (همان لحظه مانده تازه صادر می‌شود) */
    public static bool $quiet = false;

    /**
     * مبلغ سفارش پس از صدور مانده حساب عوض شد (جایگزین تأییدشده، کالای افزوده، کرایه حمل و …):
     * مانده قبلی دیگر معتبر نیست؛ مسئول پیگیری باید «اصلاح مانده حساب» بزند.
     */
    public static function totalChanged(Order $o, int $before): void
    {
        if (static::$quiet || ! $o->final_amount || (int) $o->total === (int) $o->final_amount || (int) $o->total === $before) {
            return;
        }
        $diff = (int) $o->total - (int) $o->final_amount;
        $msg = '⚠ مبلغ سفارش پس از صدور مانده حساب '.($diff > 0 ? 'بیشتر' : 'کمتر').' شد: '.money($o->final_amount).' ← '.money($o->total).' تومان؛ «اصلاح مانده حساب» را بزنید'
            .($diff > 0 ? ' تا '.money($diff).' تومان باقی‌مانده از مشتری گرفته شود.' : ' (مشتری '.money(-$diff).' تومان بستانکار می‌شود).');
        if ($diff > 0 && $o->isPaid()) {
            $o->forceFill(['payment_status' => 'unpaid', 'paid_at' => null])->saveQuietly();
            $msg .= ' وضعیت پرداخت «پرداخت‌نشده» شد.';
        }
        $o->log($msg);
        try {
            if ($o->assignee_id) {
                app(WebPush::class)->toUsers([$o->assignee_id], ['title' => 'سفارش '.fa($o->number).': مبلغ بعد از صدور مانده عوض شد',
                    'body' => money($o->final_amount).' ← '.money($o->total).' تومان — مانده حساب را اصلاح کنید', 'url' => url('/admin/orders/'.$o->id), 'tag' => 'stale-'.$o->id]);
            }
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** مانده حساب صادرشده با مبلغ فعلی سفارش نمی‌خواند (مبلغ بعد از صدور بیشتر شده) */
    public static function staleFinal(Order $o): bool
    {
        return $o->final_amount && (int) $o->total > (int) $o->final_amount;
    }

    /** اگر کل مبلغ نهایی تأیید شده باشد، سفارش «پرداخت شده» */
    /** این حواله تأیید کارخانه‌دار لازم دارد؟ (شماره کارخانه‌دار ثبت نشده = تأیید اپراتور کافی است) */
    public static function needsFactory(?Remittance $r): bool
    {
        return $r && (bool) (($r->factory_id ? $r->factory?->mobile : null) ?: $r->factory_phone);
    }

    public static function hasFinal(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('orders', 'final_ok_at');
    }

    /**
     * تأیید نهایی سفارش: چرا هنوز نه؟ (null = تأیید نهایی است)
     * همه فیش‌های تأییدشده (بیعانه و تسویه) باید به تأیید کارخانه‌دار رسیده باشند؛ حواله بدون شماره کارخانه‌دار ← تأیید اپراتور کافی است؛
     * حسابدار کل می‌تواند دستی تأیید نهایی کند.
     */
    public static function finalBlock(Order $o): ?string
    {
        if (static::hasFinal() && $o->final_ok_at) {
            return null;
        }
        $wait = RemitPayment::query()->with('remittance.factory')->where('order_id', $o->id)->where('status', 'confirmed')->whereNull('factory_confirmed_at')->get()
            ->filter(fn (RemitPayment $p) => static::needsFactory($p->remittance));
        if ($wait->isEmpty()) {
            return null;
        }

        return fa($wait->count()).' فیش هنوز تأیید کارخانه‌دار نشده ('.$wait->map(fn ($p) => $p->kindLabel().' '.money($p->amount).' — حواله '.$p->remittance?->code)->implode('، ').')';
    }

    /** فیش‌هایی که کارخانه‌دار هنوز «نشستن در حساب» را تأیید نکرده (برای کارتابل حسابدار کل) */
    public static function factoryWaiting()
    {
        return RemitPayment::query()->with(['remittance.factory', 'order'])->whereIn('status', ['submitted', 'confirmed'])
            ->whereNotNull('submitted_at')->whereNull('factory_confirmed_at')->oldest('submitted_at')->limit(300)->get()
            ->filter(fn (RemitPayment $p) => static::needsFactory($p->remittance))->values();
    }

    /**
     * حسابدار کل به‌جای کارخانه‌دار: «این مبلغ به حساب کارخانه نشسته است».
     * فیش بررسی‌نشده هم همزمان تأیید می‌شود؛ اگر آخرین فیش سفارش باشد، سفارش «در حال ارسال به باربری» می‌شود.
     */
    public static function chiefFactoryConfirm(RemitPayment $p, User $by): void
    {
        if (! static::isChief($by)) {
            throw ValidationException::withMessages(['pay' => 'تأیید به‌جای کارخانه‌دار فقط با حسابدار کل است.']);
        }
        if ($p->factory_confirmed_at) {
            return;
        }
        if (! in_array($p->status, ['submitted', 'confirmed'], true)) {
            throw ValidationException::withMessages(['pay' => 'این فیش دیگر منتظر تأیید نیست.']);
        }
        if ($p->status === 'submitted') {
            static::confirm($p, $by);
        }
        $p->forceFill(['factory_confirmed_at' => now()] + (\App\Support\DbSchema::hasColumn('remit_payments', 'factory_ok_by') ? ['factory_ok_by' => $by->id] : []))->save();
        $p->order?->log('✅ حسابدار کل ('.$by->displayName().') به‌جای کارخانه‌دار نشستن '.money($p->amount).' تومان را تأیید کرد — حواله '.$p->remittance?->code, $by->id);
        try {
            Shipping::recheckFinal($p->order?->fresh());
        } catch (\Throwable $e) {
            report($e);
        }
    }

    /** حسابدار کل: تأیید نهایی دستی (کارخانه‌دار تأیید نکرده) */
    public static function finalConfirm(Order $o, User $by): void
    {
        if (! static::isChief($by)) {
            throw ValidationException::withMessages(['order' => 'تأیید نهایی دستی فقط با حسابدار کل است.']);
        }
        if (static::hasFinal()) {
            $o->forceFill(['final_ok_at' => now(), 'final_ok_by' => $by->id])->saveQuietly();
        }
        $o->log('✅ تأیید نهایی سفارش به‌صورت دستی توسط حسابدار کل'.(($w = static::finalBlockRaw($o)) ? ' (به‌جای تأیید کارخانه‌دار: '.$w.')' : '').' — '.$by->displayName(), $by->id);
        if ($o->isPaid()) {
            Shipping::afterPaid($o->refresh());
        }
    }

    protected static function finalBlockRaw(Order $o): ?string
    {
        $f = $o->final_ok_at;
        $o->final_ok_at = null;
        $r = static::finalBlock($o);
        $o->final_ok_at = $f;

        return $r;
    }

    public static function checkPaid(Order $o): void
    {
        if ($o->isPaid() || ! $o->final_amount) {
            return;
        }
        // مبلغ سفارش بعد از صدور مانده بیشتر شده: با واریز مانده قدیمی «تسویه کامل» نمی‌شود
        if (static::staleFinal($o)) {
            if (\Illuminate\Support\Facades\Cache::add('stale-final.'.$o->id, 1, 1800)) {
                $o->log('واریزها با مانده قدیمی ('.money($o->final_amount).') کامل است ولی مبلغ فعلی سفارش '.money($o->total).' تومان است؛ تا «اصلاح مانده حساب» تسویه کامل حساب نمی‌شود.');
            }

            return;
        }
        // خرید نقد و چک: فقط سهم نقدی از طریق حواله‌ها پرداخت می‌شود
        $target = $o->cash_amount !== null ? (int) $o->cash_amount : (int) $o->final_amount;
        if (static::confirmedSum($o) >= $target) {
            $o->forceFill(['payment_status' => 'paid', 'paid_at' => now()])->saveQuietly();
            $o->log(($o->cash_amount !== null ? 'پرداخت نقدی کامل شد' : 'تسویه کامل شد').' — '.money(static::confirmedSum($o)).' تومان از طریق حواله‌ها پرداخت شد.');
            ChatFinance::note($o, '🎉 پرداخت سفارش کامل شد؛ ممنون از شما.', true);
            Shipping::afterPaid($o); // «در صف ارسال به باربری» یا «در انتظار رسیدن چک»
        }
    }

    /**
     * حذف تصویر تکراری از فیشِ منتظر بررسی (مثلاً همکار عکس چت را ثبت کرده و مشتری هم همان را روی کارت فرستاده).
     * فایل روی هاست می‌ماند (بایگانی)؛ فقط از این فیش جدا می‌شود. آخرین تصویر حذف نمی‌شود (برای آن «رد» بزنید).
     */
    public static function removeReceipt(RemitPayment $p, array $idx, User $by): int
    {
        if (! in_array($p->status, ['submitted', 'confirmed'], true)) {
            throw ValidationException::withMessages(['file' => 'فقط از فیشِ منتظر بررسی یا تأییدشده می‌شود تصویر حذف کرد.']);
        }
        $files = $p->files();
        $idx = array_values(array_unique(array_filter(array_map('intval', $idx), fn ($i) => isset($files[$i]))));
        if (! $idx) {
            throw ValidationException::withMessages(['file' => 'تصویری انتخاب نشد.']);
        }
        if (count($idx) >= count($files)) {
            throw ValidationException::withMessages(['file' => 'حداقل یک تصویر باید بماند؛ اگر هیچ‌کدام درست نیست «رد» بزنید.']);
        }
        $hashes = \App\Support\DbSchema::hasColumn('remit_payments', 'receipt_hashes') ? (array) json_decode((string) $p->receipt_hashes, true) : null;
        $keep = [];
        $keepH = [];
        foreach ($files as $i => $f) {
            if (! in_array($i, $idx, true)) {
                $keep[] = $f;
                if ($hashes !== null && count($hashes) === count($files) && isset($hashes[$i])) {
                    $keepH[] = $hashes[$i];
                }
            }
        }
        $upd = ['receipt_files' => $keep, 'receipt_path' => $keep[0]];
        if ($hashes !== null && count($hashes) === count($files)) {
            $upd['receipt_hashes'] = json_encode($keepH);
        }
        $p->forceFill($upd)->save();
        $p->order?->log('🗑 '.fa(count($idx)).' تصویر تکراری از فیش '.$p->kindLabel().' '.money($p->amount).' تومان حذف شد ('.fa(count($keep)).' تصویر ماند) — '.$by->displayName(), $by->id);

        return count($keep);
    }

    /**
     * جایگزینی تصویر فیش (حتی پس از تأیید): فیش اشتباه بارگذاری شده، یا پول برگشت خورده و مشتری فیش تازه فرستاده.
     * replace=true: تصویرهای قبلی کنار گذاشته می‌شوند (در بایگانی هاست می‌مانند)؛ false: به فیش اضافه می‌شود.
     * فیش تأییدشده: تأیید کارخانه‌دار پاک می‌شود تا فیش تازه را دوباره تأیید کند (و به او پیامک می‌رود).
     */
    public static function replaceReceipt(RemitPayment $p, UploadedFile|array $files, User $by, string $reason, bool $replace = true, ?string $ref = null): void
    {
        if (! in_array($p->status, ['submitted', 'confirmed'], true)) {
            throw ValidationException::withMessages(['receipt' => 'جایگزینی فقط برای فیشِ منتظر بررسی یا تأییدشده است؛ برای بقیه «ثبت فیش» را بزنید.']);
        }
        $reason = mb_substr(trim(strip_tags($reason)), 0, 200);
        if (mb_strlen($reason) < 3) {
            throw ValidationException::withMessages(['reason' => 'علت جایگزینی را بنویسید (مثلاً «واریز قبلی برگشت خورد»).']);
        }
        $files = array_values(array_filter(is_array($files) ? $files : [$files], fn ($f) => $f instanceof UploadedFile));
        if (! $files) {
            throw ValidationException::withMessages(['receipt' => 'تصویر فیش تازه را انتخاب کنید.']);
        }
        $old = $p->files();
        $oldHashes = \App\Support\DbSchema::hasColumn('remit_payments', 'receipt_hashes') ? (array) json_decode((string) $p->receipt_hashes, true) : null;
        // تکراری بودن با فیش‌های دیگر همین مشتری چک می‌شود (نه با تصویرهای همین فیش که قرار است عوض شوند)
        $hashes = static::receiptDupCheck($p, $files, false, 'st');
        $new = [];
        foreach ($files as $k => $file) {
            $new[] = \App\Support\DocImages::store($file, 'receipts/'.($p->order_id ?: 'walkin'), $p->id.'-r'.now()->format('YmdHis').'-'.$k.substr(md5(uniqid('', true)), 0, 4));
        }
        $all = $replace ? $new : array_values(array_merge($old, $new));
        $upd = ['receipt_path' => $all[0], 'receipt_files' => $all, 'receipt_ref' => $ref ? mb_substr(en_digits($ref), 0, 80) : $p->receipt_ref];
        if ($hashes !== null) {
            $upd['receipt_hashes'] = json_encode($replace ? $hashes : array_merge((array) $oldHashes, $hashes));
        }
        $wasFactory = (bool) $p->factory_confirmed_at;
        if ($p->status === 'confirmed' && \App\Support\DbSchema::hasColumn('remit_payments', 'factory_confirmed_at')) {
            $upd['factory_confirmed_at'] = null; // کارخانه‌دار باید فیش تازه را ببیند و تأیید کند
            if (\App\Support\DbSchema::hasColumn('remit_payments', 'factory_seen_at')) {
                $upd['factory_seen_at'] = null;
            }
        }
        $p->forceFill($upd)->save();
        $o = $p->order;
        $msg = '🔁 فیش '.$p->kindLabel().' '.money($p->amount).' تومان (حواله '.$p->remittance?->code.') '.($replace ? 'جایگزین شد' : 'تصویر تازه گرفت')
            .' — '.fa(count($new)).' تصویر تازه'.($replace && $old ? '، '.fa(count($old)).' تصویر قبلی کنار رفت' : '').' — علت: '.$reason.' — '.$by->displayName()
            .($p->status === 'confirmed' ? ($wasFactory ? ' — تأیید قبلی کارخانه‌دار پاک شد؛ باید فیش تازه را تأیید کند.' : ' — کارخانه‌دار باید فیش تازه را تأیید کند.') : '');
        $o?->log($msg, $by->id);
        try {
            static::smsFactory($p->remittance, 'receipt', $p);
        } catch (Throwable $e) {
            report($e);
        }
        if ($o) {
            ChatFinance::note($o, '🔁 فیش '.$p->kindLabel().' '.money($p->amount).' تومان با تصویر تازه '.($replace ? 'جایگزین' : 'تکمیل').' شد.');
        }
    }

    public static function hasExtra(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('remit_payments', 'extra');
    }

    /** چه کسی اضافه‌واریز ثبت می‌کند: حسابدار کل، یا کمک‌حسابدارِ مسئول همین سفارش */
    public static function canExtra(?User $u, Order $o): bool
    {
        return $u && static::hasExtra() && (static::isChief($u) || ($u->hasPerm('remit_assist') && (int) $o->assignee_id === (int) $u->id));
    }

    /**
     * ثبت اضافه‌واریز: مشتری بعد از تمام شدن مهلت (یا بی‌کارت) به حساب کارخانه‌ای واریز کرده که حواله‌اش پر/بسته شده.
     * - مبلغ برای مشتری (بیعانه یا مانده) حساب می‌شود و مثل فیش تأییدشده جریان سفارش را جلو می‌برد.
     * - حواله دست نمی‌خورد (وضعیت و مبلغش همان می‌ماند؛ کارت تازه‌ای رویش صادر نمی‌شود)
     *   و کنارش «+… اضافه‌واریز» نشان داده می‌شود = کارخانه این مبلغ را بیشتر از حواله گرفته (از حواله بعدی‌اش کم شود).
     * - کارخانه‌دار فیش را در کارتابلش می‌بیند و تأیید می‌کند.
     *
     * @param  UploadedFile[]  $files
     */
    public static function recordExtra(Order $o, Remittance $r, string $kind, int $amount, array $files, User $by, string $note, ?string $ref = null): RemitPayment
    {
        if (! static::canExtra($by, $o)) {
            throw ValidationException::withMessages(['amount' => 'ثبت اضافه‌واریز فقط با حسابدار کل یا کمک‌حسابدارِ مسئول همین سفارش است.']);
        }
        if (! in_array($kind, ['deposit', 'settle'], true)) {
            throw ValidationException::withMessages(['kind' => 'نوع واریز (بیعانه یا مانده) را انتخاب کنید.']);
        }
        if ($amount <= 0) {
            throw ValidationException::withMessages(['amount' => 'مبلغ باید بیشتر از صفر باشد.']);
        }
        if (in_array($o->status, ['cancelled', 'failed'], true)) {
            throw ValidationException::withMessages(['amount' => 'سفارش لغو شده است.']);
        }
        $note = mb_substr(trim(strip_tags($note)), 0, 200);
        if (mb_strlen($note) < 3) {
            throw ValidationException::withMessages(['note' => 'توضیح بنویسید (مثلاً «مهلت بیعانه تمام شده بود؛ فیش در روبیکا فرستاده شد»).']);
        }
        $files = array_values(array_filter($files, fn ($f) => $f instanceof UploadedFile));
        if (! $files) {
            throw ValidationException::withMessages(['files' => 'تصویر فیش را بگذارید.']);
        }
        $statusBefore = $r->status;
        $p = DB::transaction(function () use ($o, $r, $kind, $amount, $files, $by, $note, $ref) {
            $p = RemitPayment::query()->create([
                'remittance_id' => $r->id, 'order_id' => $o->id, 'user_id' => $o->user_id, 'kind' => $kind, 'amount' => $amount,
                'status' => 'submitted', 'issued_by' => $by->id, 'submitted_at' => now(), 'receipt_ref' => $ref ? mb_substr(en_digits($ref), 0, 80) : null,
            ]);
            $hashes = static::receiptDupCheck($p, $files, false, 'st'); // همین فیش قبلاً برای این مشتری ثبت نشده باشد
            $paths = [];
            foreach ($files as $k => $file) {
                $paths[] = \App\Support\DocImages::store($file, 'receipts/'.$o->id, $p->id.'-x'.now()->format('YmdHis').'-'.$k.substr(md5(uniqid('', true)), 0, 4));
            }
            $p->forceFill(['receipt_path' => $paths[0], 'receipt_files' => $paths, 'extra' => true, 'extra_note' => $note]
                + ($hashes !== null ? ['receipt_hashes' => json_encode($hashes)] : []))->save();

            return $p;
        });
        $o->log('➕ اضافه‌واریز '.(RemitPayment::KINDS[$kind] ?? $kind).' '.money($amount).' تومان روی حواله '.$r->code.' ('.$r->title.' — '.$r->statusLabel().') ثبت شد — '.$note
            .' — حواله دست نخورد؛ کارخانه این مبلغ را بیشتر از حواله گرفته — '.$by->displayName(), $by->id);
        static::confirm($p, $by); // جریان عادی: بیعانه ← ارجاع به انبار، مانده ← تسویه کامل
        if ($r->fresh()->status !== $statusBefore) { // حواله دست نخورد
            $r->forceFill(['status' => $statusBefore])->saveQuietly();
        }
        try {
            static::smsFactory($r, 'receipt', $p);
        } catch (Throwable $e) {
            report($e);
        }

        return $p;
    }

    /** جمع اضافه‌واریزهای تأییدشده یک حواله */
    public static function extraSum(Remittance $r): int
    {
        return static::hasExtra() ? (int) RemitPayment::query()->where('remittance_id', $r->id)->where('extra', true)->where('status', 'confirmed')->sum('amount') : 0;
    }

    /** علت‌های آماده رد فیش (تنظیمات کارتابل حسابداری) */
    public static function rejectReasons(): array
    {
        $list = array_values(array_filter(array_map('trim', preg_split('/\R/u', (string) setting('remit_reject_reasons', '')))));

        return array_combine($list, $list) ?: [];
    }

    /** رد فیش (مشتری باید فیش درست را دوباره بفرستد) */
    public static function reject(RemitPayment $p, string $reason, ?User $by = null): void
    {
        $p->forceFill(['status' => 'rejected', 'reject_reason' => mb_substr($reason, 0, 300), 'reviewed_by' => $by?->id ?? auth()->id(), 'reviewed_at' => now()])->save();
        $o = $p->order;
        if (! $o) { // فیش حضوری: کمک‌حسابدار خودش با مشتری هماهنگ می‌کند
            return;
        }
        $o->log('فیش '.$p->kindLabel().' '.money($p->amount).' تومان رد شد: '.$reason, $by?->id);
        ChatFinance::note($o, '❌ فیش '.$p->kindLabel().' '.money($p->amount).' تومان تأیید نشد: '.$reason.' — لطفاً فیش درست را روی همان کارت بفرستید.', true);
        app(Sms::class)->forOrder($o, 'remit_rejected', ['amount' => number_format($p->amount), 'reason' => $reason]);
    }

    /** ابطال یک پرداخت (ظرفیت حواله آزاد می‌شود) */
    public static function cancel(RemitPayment $p, ?User $by = null, string $why = ''): void
    {
        if (in_array($p->status, ['confirmed', 'cancelled'], true)) {
            return;
        }
        // کارت «واریز مجدد حواله برگشتی»: فقط حسابدار ارشد (یا لغو سفارش) باطلش می‌کند، نه اپراتور
        if (! empty($p->bounce) && ! in_array($why, ['لغو سفارش', 'بستن حواله'], true) && ! ($by && static::isChief($by))) {
            throw ValidationException::withMessages(['pay' => 'این کارت «واریز مجدد حواله برگشتی» است و اپراتور نمی‌تواند باطلش کند؛ فقط فیش را بارگذاری کنید.']);
        }
        $p->forceFill(['status' => 'cancelled'])->save();
        $p->order?->log('پرداخت '.$p->kindLabel().' '.money($p->amount).' تومان (حواله '.$p->remittance?->code.') باطل شد'.($why ? ' — '.$why : ''), $by?->id);
        if ($p->order && $why !== 'لغو سفارش') {
            ChatFinance::note($p->order, 'مبلغ '.$p->kindLabel().' '.money($p->amount).' تومان باطل شد'.($why ? ' — '.$why : '').'.');
        }
    }

    /** با لغو سفارش، پرداخت‌های واریزنشده باطل می‌شوند */
    public static function orderCancelled(Order $o): void
    {
        RemitPayment::query()->where('order_id', $o->id)->whereIn('status', ['awaiting', 'rejected'])->get()->each(fn ($p) => static::cancel($p, null, 'لغو سفارش'));
        // پولی که رسیده یا فیشش در راه است نباید فراموش شود
        $conf = (int) RemitPayment::query()->where('order_id', $o->id)->where('status', 'confirmed')->sum('amount');
        $sub = (int) RemitPayment::query()->where('order_id', $o->id)->where('status', 'submitted')->sum('amount');
        if ($conf || $sub) {
            $o->log('💰 سفارش لغو شد ولی '.implode(' و ', array_filter([
                $conf ? money($conf).' تومان واریز تأییدشده' : null,
                $sub ? money($sub).' تومان فیش منتظر بررسی حسابداری' : null,
            ])).' دارد؛ استرداد یا تکلیف این مبلغ را پیگیری کنید.');
            try {
                if ($o->assignee_id) {
                    app(WebPush::class)->toUsers([$o->assignee_id], ['title' => 'سفارش لغوشده '.fa($o->number).' واریز دارد',
                        'body' => money($conf + $sub).' تومان — استرداد را پیگیری کنید', 'url' => url('/admin/orders/'.$o->id), 'tag' => 'refund-'.$o->id]);
                }
            } catch (Throwable $e) {
                report($e);
            }
        }
    }

    public static function checkFilled(Remittance $r): void
    {
        $s = $r->stats();
        if ($r->status === 'active' && $s['confirmed'] >= $s['amount'] && $s['amount'] > 0) {
            $r->forceFill(['status' => 'filled', 'filled_at' => now()])->save();
            static::smsFactory($r, 'filled');
            $to = array_values(array_filter(array_unique(array_merge([$r->assignee_id], User::query()->where('is_active', true)->get()->filter(fn ($u) => $u->hasPerm('remit_manage'))->pluck('id')->all()))));
            app(WebPush::class)->toUsers($to, ['title' => 'حواله '.$r->code.' پر شد ✓', 'body' => $r->title.' — '.money($r->amount).' تومان؛ آماده ارسال به کارخانه', 'url' => url('/admin/remittances/'.$r->id), 'tag' => 'remit-filled-'.$r->id]);
        }
    }

    /**
     * حذف کامل حواله (مثلاً حواله آزمایشی) با همه مبالغ صادرشده، فیش‌ها (و فایل تصویرشان)، حساب‌های مقصد و حواله‌های زیرمجموعه.
     * فقط حسابدار کل. در تاریخچه سفارش‌های مربوط یک خط ثبت می‌شود.
     *
     * @return array{remits: int, payments: int}
     */
    public static function purge(Remittance $r, ?User $by = null): array
    {
        $done = ['remits' => 0, 'payments' => 0];
        DB::transaction(function () use ($r, $by, &$done) {
            $ids = [$r->id];
            for ($i = 0, $front = [$r->id]; $front && $i < 10; $i++) { // زیرمجموعه‌ها (تقسیم/انتقال) تا چند سطح
                $front = Remittance::query()->whereIn('parent_id', $front)->whereNotIn('id', $ids)->pluck('id')->all();
                $front = array_merge($front, RemitDestination::query()->whereIn('remittance_id', $ids)->whereNotNull('child_remittance_id')->whereNotIn('child_remittance_id', $ids)->pluck('child_remittance_id')->all());
                $front = array_values(array_unique(array_map('intval', $front)));
                $ids = array_values(array_unique(array_merge($ids, $front)));
            }
            $remits = Remittance::query()->whereIn('id', $ids)->get()->keyBy('id');
            $pays = RemitPayment::query()->whereIn('remittance_id', $ids)->with('order')->get();
            foreach ($pays as $p) {
                foreach ($p->files() as $f) {
                    Storage::disk('local')->delete($f);
                }
                if ($p->order && $p->status !== 'cancelled') {
                    $p->order->log('حواله '.($remits[$p->remittance_id]->code ?? '').' حذف شد؛ '.$p->kindLabel().' '.money($p->amount).' تومان ('.(RemitPayment::STATUSES[$p->status] ?? $p->status).') هم حذف شد.', $by?->id);
                }
            }
            $done['payments'] = RemitPayment::query()->whereIn('remittance_id', $ids)->delete();
            RemitDestination::query()->whereIn('remittance_id', $ids)->delete();
            RemitDestination::query()->whereIn('child_remittance_id', $ids)->update(['child_remittance_id' => null]);
            $done['remits'] = Remittance::query()->whereIn('id', $ids)->delete();
        });
        \Illuminate\Support\Facades\Log::info('remittance purged', ['code' => $r->code, 'by' => $by?->id] + $done);

        return $done;
    }

    /** انتقال مانده آزاد حواله به کمک‌حسابدار دیگر (حواله تازه با همان حساب) */
    public static function transferFree(Remittance $r, int $toUser, ?int $amount = null, ?User $by = null): Remittance
    {
        return DB::transaction(function () use ($r, $toUser, $amount, $by) {
            $r = Remittance::query()->lockForUpdate()->findOrFail($r->id);
            $free = $r->stats()['free'];
            $amount = $amount ? min($amount, $free) : $free;
            if ($amount <= 0) {
                throw ValidationException::withMessages(['amount' => 'این حواله مانده آزاد ندارد.']);
            }
            $new = Remittance::query()->create([
                'title' => $r->title, 'amount' => $amount, 'holder_name' => $r->holder_name, 'bank_name' => $r->bank_name,
                'card_number' => $r->card_number, 'sheba' => $r->sheba, 'assignee_id' => $toUser, 'created_by' => $by?->id ?? auth()->id(),
                'parent_id' => $r->id, 'status' => 'active', 'sort' => $r->sort, 'note' => 'مانده حواله '.$r->code,
            ]);
            $r->amount = (int) $r->amount - $amount;
            $r->note = trim(($r->note ? $r->note."\n" : '').'— '.money($amount).' تومان به حواله '.$new->code.' منتقل شد ('.jdate(now(), true).')');
            $r->save();
            static::checkFilled($r);

            return $new;
        });
    }

    /** فایل فیش برای نمایش/دانلود */
    public static function receiptFile(RemitPayment $p, int $i = 0): ?string
    {
        $path = $p->files()[$i] ?? null;

        return $path && Storage::disk('local')->exists($path) ? Storage::disk('local')->path($path) : null;
    }

    /** پیامک صدور مبلغ به مشتری */
    public static function notifyCustomer(Order $o, string $kind): void
    {
        $sum = (int) RemitPayment::query()->where('order_id', $o->id)->where('kind', $kind)->whereIn('status', ['awaiting', 'rejected'])->sum('amount');
        if ($sum > 0) {
            app(Sms::class)->forOrder($o, $kind === 'deposit' ? 'remit_deposit' : 'remit_settle', ['amount' => number_format($sum), 'acct' => static::acctNote($o, $kind)]);
        }
    }

    /** کلید حساب مقصد یک حواله (کارت / شبا / شماره حساب) */
    protected static function acctKey(?Remittance $r): string
    {
        return $r ? preg_replace('/\D/', '', (string) ($r->card_number ?: ($r->sheba ?: $r->account_number))) ?: 'r'.$r->id : '';
    }

    /** پیامک: «به همان حساب بیعانه» یا «به حساب جدید …» — تا مشتری گمراه نشود */
    public static function acctNote(Order $o, string $kind): string
    {
        $mine = RemitPayment::query()->with('remittance')->where('order_id', $o->id)->where('kind', $kind)->whereIn('status', ['awaiting', 'rejected'])->get();
        $keys = $mine->map(fn ($p) => static::acctKey($p->remittance))->filter()->unique();
        $many = $keys->count() > 1;
        if ($kind === 'deposit') {
            return $many ? 'به '.fa($keys->count()).' حسابی که روی کارت‌های بیعانه نوشته شده' : 'به حسابی که روی کارت بیعانه نوشته شده';
        }
        $dep = RemitPayment::query()->with('remittance')->where('order_id', $o->id)->where('kind', 'deposit')->where('status', '!=', 'cancelled')->get()
            ->map(fn ($p) => static::acctKey($p->remittance))->filter()->unique();
        if ($dep->isNotEmpty() && $keys->isNotEmpty() && $keys->diff($dep)->isEmpty()) {
            return $many ? 'به همان حساب‌های بیعانه (طبق کارت‌های مانده حساب)' : 'به همان حساب بیعانه';
        }

        $same = $keys->intersect($dep)->count();
        if ($many && $same) {
            return 'به '.fa($keys->count()).' حسابی که روی کارت‌های مانده حساب نوشته شده ('.($same === 1 ? 'یکی از آن‌ها' : fa($same).' تا از آن‌ها').' همان حساب بیعانه است)';
        }

        return $many ? 'به '.fa($keys->count()).' حساب جدیدی که روی کارت‌های مانده حساب نوشته شده' : 'به حساب جدیدی که روی کارت مانده حساب نوشته شده (با حساب بیعانه فرق دارد)';
    }

    /** نوار پیشرفت حواله: سبز تأییدشده، آبی فیش منتظر تأیید، زرد صادرشده منتظر واریز، خاکستری آزاد */
    public static function bar(array $st, bool $legend = true): string
    {
        $a = max(1, $st['amount']);
        $w = fn ($v) => round($v * 100 / $a, 2).'%';
        $h = '<div class="rmb"><i class="ok" style="width:'.$w($st['confirmed']).'"></i><i class="sub" style="width:'.$w($st['submitted']).'"></i><i class="aw" style="width:'.$w($st['awaiting']).'"></i></div>';
        if ($legend) {
            $h .= '<div class="rml"><span><b class="ok"></b>تأیید '.money($st['confirmed']).'</span>'
                .($st['submitted'] ? '<span><b class="sub"></b>فیش '.money($st['submitted']).'</span>' : '')
                .($st['awaiting'] ? '<span><b class="aw"></b>منتظر واریز '.money($st['awaiting']).'</span>' : '')
                .'<span><b></b>آزاد '.money($st['free']).'</span>'
                .(! empty($st['over']) ? '<span style="color:#b91c1c;font-weight:800" title="کارخانه این مبلغ را بیشتر از حواله گرفته؛ از حواله بعدی همین کارخانه کم شود">+'.money($st['over']).' اضافه‌واریز</span>' : '')
                .'<span class="rmp">'.fa($st['pct']).'٪</span></div>';
        }

        return $h;
    }

    /** پیامک به کارخانه‌دار: receipt = فیش تازه، status = خلاصه، filled = تکمیل */
    public static function smsFactory(Remittance $r, string $type, ?RemitPayment $p = null, bool $now = false): array
    {
        // ارسال پیامک (چند ثانیه با پنل پیامک) بعد از پاسخ به کارمند ← تأیید/ثبت فیش منتظر پنل پیامک نمی‌ماند
        if (! $now) {
            \App\Support\AfterResponse::run(function () use ($r, $type, $p) {
                static::smsFactory($r->fresh() ?? $r, $type, $p?->fresh() ?? $p, true);
            });

            return ['ok' => true, 'msg' => 'در صف ارسال', 'maybe' => true];
        }
        $phone = $r->factory?->mobile ?: $r->factory_phone;
        if (! $phone) {
            return ['ok' => false, 'msg' => 'موبایل کارخانه‌دار ثبت نشده است.'];
        }
        $st = $r->stats();
        $data = [
            // به کارخانه‌دار هیچ اطلاعاتی از مشتری فرستاده نمی‌شود؛ فقط شماره سفارش
            'code' => $r->code, 'amount' => number_format((int) ($p?->amount ?? 0)), 'customer' => $p && ! $p->order_id ? 'فیش حضوری' : 'سفارش '.($p?->order?->number ?? ''), 'order' => (string) ($p?->order?->number ?? ''),
            'ref' => '—', 'paid' => number_format($st['confirmed']), 'left' => number_format($st['left']),
            'count' => (string) $r->payments()->where('status', 'confirmed')->count(),
            'link' => \App\Services\FactoryPortal::url('r/'.$r->id),
        ];
        $res = app(Sms::class)->send('factory_'.$type, $phone, $data, $type === 'status');
        if ($p) {
            $p->order?->log('پیامک فیش به کارخانه‌دار ('.$r->code.') '.($res['ok'] ? 'ارسال شد' : 'ارسال نشد: '.$res['msg']));
        }

        return $res;
    }
}
