<?php

namespace App\Services;

use App\Models\Product;
use App\Models\User;
use App\Models\WalkinItem;
use App\Models\WalkinSale;
use App\Support\XlsWriter;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * فروش حضوری (اپ بارکدزن + کارتابل دفتر)
 * - بارکدزن: مشخصات مشتری ← اسکن کارتنی اقلام (کمتر از کارتن: دستی) ← «ارسال به دفتر» (اسکن‌شده)
 * - تحویل‌دهنده: هنگام تحویل دوباره اسکن ← تطبیق با اسکن اول ← «بارگیری شد» (بارگیری‌شده؛ شمارش تحویل ملاک است)
 * - مرجوعی: جستجوی دستی + تعداد + وضعیت (سالم / ایراد کارخانه / ضایعات) ← کارتابل دفتر، سربرگ مرجوعی
 * پرداخت در هلو؛ این سامانه فقط اکسل هلو و کنترل خطای انسانی است.
 */
class Walkin
{
    public static function on(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasTable('walkin_sales');
    }

    public static function isWalkin(?User $u): bool
    {
        return $u && $u->role === 'keeper' && in_array($u->pick_role, self::ROLES, true);
    }

    /** نوع‌های کار اپ «اسکن و تحویل» */
    public const ROLES = ['walkin', 'walkin_d', 'walkin_sup'];

    public static function appName(): string
    {
        return (string) (setting('walkin_app_name') ?: 'اسکن و تحویل');
    }

    /** سرپرست تحویل: بارها را به تحویل‌دهنده ارجاع می‌دهد (یا روی کارتابل همه) */
    public static function canAssign(?User $u): bool
    {
        return $u && $u->is_active && ($u->pick_role === 'walkin_sup' || $u->isAdmin());
    }

    /** تحویل‌دهنده‌ها (برای ارجاع) */
    public static function deliverers()
    {
        return User::query()->where('is_active', true)->where('role', 'keeper')->whereIn('pick_role', ['walkin_d', 'walkin_sup'])->orderBy('name')->get();
    }

    /** ارجاع بار اسکن‌شده: null = روی کارتابل همه تحویل‌دهنده‌ها */
    public static function assign(WalkinSale $s, ?int $to, User $by): void
    {
        abort_unless($s->kind === 'sale' && $s->status === 'scanned', 422, 'این بار دیگر در انتظار تحویل نیست.');
        if ($to) {
            abort_unless(static::deliverers()->contains('id', $to), 422, 'تحویل‌دهنده معتبر نیست.');
        }
        $s->forceFill(['assigned_to' => $to ?: null, 'assigned_by' => $by->id])->save();
    }

    /** «پایان» فاکتور از دفتر (در هر مرحله) — از فهرست‌های اپ خارج می‌شود */
    public static function finish(WalkinSale $s, User $by): void
    {
        abort_if($s->status === 'done', 422, 'این فاکتور قبلاً پایان یافته است.');
        $s->forceFill(['done_from' => $s->status, 'status' => 'done', 'done_at' => now(), 'done_by' => $by->id])->save();
    }

    /** بازگرداندن فاکتور پایان‌یافته به مرحله قبل */
    public static function reopen(WalkinSale $s): void
    {
        abort_unless($s->status === 'done', 422);
        $s->forceFill(['status' => $s->done_from ?: ($s->kind === 'return' ? 'returned' : ($s->delivered_at ? 'loaded' : ($s->sent_at ? 'scanned' : 'draft'))), 'done_at' => null, 'done_by' => null])->save();
    }

    /**
     * فهرست سبک همه کالاها برای جستجو و شناسایی آنی بارکد در گوشی (بدون انتظار سرور):
     * [id, نام, تعداد در کارتن, فی, کدها…]
     */
    public static function productIndex(): array
    {
        $rows = [];
        Product::query()->select(['id', 'name', 'per_carton', 'price', 'sync_code', 'sku', 'barcode', 'is_active'])->orderByDesc('is_active')->orderBy('id')
            ->chunk(4000, function ($ps) use (&$rows) {
                foreach ($ps as $p) {
                    $codes = array_values(array_unique(array_filter([(string) $p->sync_code, (string) $p->sku, (string) $p->barcode], fn ($c) => $c !== '')));
                    $rows[] = [(int) $p->id, (string) $p->name, max(1, (int) $p->per_carton), (int) $p->price, $codes];
                }
            });

        return $rows;
    }

    /** نشان نسخه فهرست کالاها (تغییر کالا/قیمت ← فهرست گوشی تازه می‌شود) */
    public static function indexVersion(): string
    {
        $r = Product::query()->selectRaw('count(*) n, max(updated_at) m, max(id) i')->first();

        return substr(md5(($r->n ?? 0).'|'.($r->m ?? '').'|'.($r->i ?? 0)), 0, 12);
    }

    public static function canScan(?User $u): bool
    {
        return $u && $u->is_active && (static::isWalkin($u) || $u->isAdmin());
    }

    public static function canDeliver(?User $u): bool
    {
        return $u && $u->is_active && (in_array($u->pick_role, ['walkin_d', 'walkin_sup'], true) || $u->isAdmin());
    }

    /** پیدا کردن کالا با بارکد / کد کالا (اسکنر) */
    public static function findByCode(string $code): ?Product
    {
        $raw = trim($code);
        $c = Picking::normCode($raw);
        if ($c === '') {
            return null;
        }

        return Product::query()->where(fn ($q) => $q->where('barcode', $raw)->orWhere('sku', $raw)->orWhere('sync_code', $raw)
            ->orWhere('barcode', $c)->orWhere('sku', $c)->orWhere('sync_code', $c))->orderByDesc('is_active')->first();
    }

    public static function start(User $u, array $d, string $kind = 'sale'): WalkinSale
    {
        $name = trim((string) ($d['name'] ?? ''));
        $city = trim((string) ($d['city'] ?? ''));
        $bay = trim((string) ($d['bay'] ?? ''));
        $phone = preg_replace('/\D+/', '', en_digits((string) ($d['phone'] ?? '')));
        if (strlen($phone) >= 10 && strlen($phone) <= 12) {
            $phone = '0'.substr($phone, -10); // یکسان: ۰۹۱۲…
        }
        $err = [];
        if (mb_strlen($name) < 3) {
            $err['name'] = 'نام کامل مشتری را بنویسید.';
        }
        if ($city === '') {
            $err['city'] = 'شهر مشتری را بنویسید.';
        }
        if ($kind === 'sale' && $bay === '') {
            $err['bay'] = 'جایگاه را بنویسید.';
        }
        if ($phone !== '' && strlen($phone) < 10) {
            $err['phone'] = 'شماره تماس درست نیست.';
        }
        if ($err) {
            throw ValidationException::withMessages($err);
        }

        return WalkinSale::query()->create(['kind' => $kind, 'status' => 'draft', 'customer_name' => mb_substr($name, 0, 120), 'city' => mb_substr($city, 0, 80),
            'phone' => $phone ?: null, 'bay' => $bay !== '' ? mb_substr($bay, 0, 60) : null, 'scanned_by' => $u->id]);
    }

    protected static function lineFor(WalkinSale $s, Product $p, ?string $cond = null): WalkinItem
    {
        return $s->items()->where('product_id', $p->id)->when($cond, fn ($q) => $q->where('cond', $cond))->first()
            ?? $s->items()->create(['product_id' => $p->id, 'name' => $p->name, 'code' => (string) ($p->sku ?: ($p->sync_code ?: $p->barcode)),
                'per' => max(1, (int) $p->per_carton), 'units' => 0, 'cond' => $cond, 'unit_price' => (int) $p->unitPrice(Product::CARTON)]);
    }

    /** اسکن بارکدزن: هر اسکن یک کارتن (کالای تکی: یک عدد) */
    public static function scan(WalkinSale $s, string $code): array
    {
        static::editable($s);
        $p = static::findByCode($code);
        if (! $p) {
            // کالای ثبت‌نشده در سایت: بار اول تعداد و «هر کارتن چند تایی» پرسیده می‌شود؛ اسکن‌های بعدی همان کد = یک کارتن دیگر
            $line = static::unknownLine($s, $code);
            if (! $line) {
                return ['ok' => false, 'type' => 'ask', 'code' => static::cleanCode($code), 'msg' => 'این کد در سایت ثبت نشده — تعداد را بزنید'];
            }
            $step = max(1, (int) $line->per);
            $line->forceFill(['units' => (int) $line->units + $step])->save();

            return ['ok' => true, 'type' => 'ok', 'id' => $line->id, 'msg' => '«'.$line->name.'» +'.($step > 1 ? '۱ کارتن ('.fa($step).' عدد)' : '۱ عدد')];
        }
        $line = static::lineFor($s, $p);
        $step = max(1, (int) $line->per);
        $line->forceFill(['units' => (int) $line->units + $step])->save();
        static::retotal($s);

        return ['ok' => true, 'type' => 'ok', 'id' => $line->id, 'msg' => '«'.$p->name.'» +'.($step > 1 ? '۱ کارتن ('.fa($step).' عدد)' : '۱ عدد')];
    }

    /** دستی: تعداد کل (عدد) یک ردیف؛ ۰ = حذف */
    public static function setUnits(WalkinSale $s, int $itemId, int $units, ?string $cond = null): void
    {
        static::editable($s);
        $line = $s->items()->findOrFail($itemId);
        if ($units <= 0) {
            $line->delete();
        } else {
            $line->forceFill(['units' => min(1000000, $units)] + ($cond && isset(WalkinSale::CONDS[$cond]) ? ['cond' => $cond] : []))->save();
        }
        static::retotal($s);
    }

    /** مرجوعی: افزودن دستی کالا با تعداد و وضعیت */
    public static function addReturn(WalkinSale $s, int $productId, int $units, string $cond): void
    {
        static::editable($s);
        abort_unless($s->kind === 'return', 422);
        if (! isset(WalkinSale::CONDS[$cond])) {
            throw ValidationException::withMessages(['cond' => 'وضعیت کالا را انتخاب کنید (سالم / ایراد کارخانه / ضایعات).']);
        }
        if ($units <= 0) {
            throw ValidationException::withMessages(['units' => 'تعداد را بنویسید.']);
        }
        $p = Product::query()->findOrFail($productId);
        $line = static::lineFor($s, $p, $cond);
        $line->forceFill(['units' => (int) $line->units + $units, 'cond' => $cond])->save();
        static::retotal($s);
    }

    /** افزودن دستی کالا (بارکد خراب / بی‌برچسب): در اسکن اول به تعداد، در تحویل به شمارش تحویل */
    public static function addManual(WalkinSale $s, int $productId, int $units, string $where = 'scan'): WalkinItem
    {
        if ($units <= 0) {
            throw ValidationException::withMessages(['units' => 'تعداد را بنویسید.']);
        }
        $p = Product::query()->findOrFail($productId);
        if ($where === 'deliver') {
            abort_unless($s->kind === 'sale' && $s->status === 'scanned', 422, 'این بار آماده تحویل نیست.');
            $line = $s->items()->where('product_id', $p->id)->first() ?? static::lineFor($s, $p);
            $line->forceFill(['d_units' => (int) $line->d_units + $units])->save();
        } else {
            static::editable($s);
            $line = static::lineFor($s, $p);
            $line->forceFill(['units' => (int) $line->units + $units])->save();
        }
        static::retotal($s);

        return $line;
    }

    /**
     * اصلاح / افزودن دستی از کارتابل دفتر (در هر مرحله پیش از پایان):
     * $rows: [id => ['units' => عدد کل, 'per' => ?, 'cond' => ?]] — ردیفی که نباشد حذف می‌شود
     * $adds: [['pid' => ?, 'code' => ?, 'per' => ?, 'units' => عدد کل, 'cond' => ?]]
     * پس از بارگیری، شمارش تحویل اصلاح می‌شود (ملاک اکسل)؛ پیش از آن تعداد اسکن اول.
     */
    public static function officeEdit(WalkinSale $s, array $rows, array $adds): void
    {
        abort_if($s->status === 'done', 422, 'فاکتور پایان‌یافته قابل اصلاح نیست؛ اول «بازگرداندن» را بزنید.');
        $f = $s->delivered() ? 'd_units' : 'units';
        DB::transaction(function () use ($s, $rows, $adds, $f) {
            foreach ($s->items()->get() as $i) {
                $r = $rows[$i->id] ?? null;
                if (! $r) {
                    $i->delete();

                    continue;
                }
                $upd = [$f => max(0, (int) $r['units'])];
                if (! $i->product_id && (int) ($r['per'] ?? 0) > 0) {
                    $upd['per'] = (int) $r['per'];
                }
                if ($s->kind === 'return' && isset(WalkinSale::CONDS[(string) ($r['cond'] ?? '')])) {
                    $upd['cond'] = $r['cond'];
                }
                $i->forceFill($upd)->save();
            }
            foreach ($adds as $a) {
                $u = (int) ($a['units'] ?? 0);
                if ($u <= 0) {
                    continue;
                }
                $cond = $s->kind === 'return' ? (isset(WalkinSale::CONDS[(string) ($a['cond'] ?? '')]) ? $a['cond'] : 'ok') : null;
                if (! empty($a['pid']) && ($p = Product::query()->find((int) $a['pid']))) {
                    $line = static::lineFor($s, $p, $cond);
                } elseif (($c = static::cleanCode((string) ($a['code'] ?? ''))) !== '') {
                    $line = static::unknownLine($s, $c, $cond) ?? $s->items()->create(['product_id' => null, 'name' => 'کالای ناشناس — کد '.fa($c), 'code' => $c,
                        'per' => max(1, (int) ($a['per'] ?? 1)), 'units' => 0, 'cond' => $cond, 'unit_price' => 0]);
                } else {
                    continue;
                }
                $line->forceFill([$f => (int) $line->{$f} + $u] + ($cond ? ['cond' => $cond] : []))->save();
            }
            if ($s->status === 'scanned' || $s->status === 'loaded') {
                $s->forceFill(['diffs' => $s->status === 'loaded' ? count(static::diffs($s)) : $s->diffs])->saveQuietly();
            }
            static::retotal($s);
        });
    }

    /** ارسال به دفتر (فروش: اسکن‌شده / مرجوعی: مرجوعی) */
    public static function send(WalkinSale $s, User $u): void
    {
        static::editable($s);
        if (! $s->items()->where('units', '>', 0)->exists()) {
            throw ValidationException::withMessages(['items' => 'هنوز کالایی ثبت نشده.']);
        }
        $s->forceFill(['status' => $s->kind === 'return' ? 'returned' : 'scanned', 'sent_at' => now(), 'scanned_by' => $s->scanned_by ?: $u->id])->save();
        static::retotal($s);
    }

    /** اسکن تحویل‌دهنده */
    public static function deliverScan(WalkinSale $s, string $code): array
    {
        if ($s->kind !== 'sale' || $s->status !== 'scanned') {
            throw ValidationException::withMessages(['sale' => 'این بار آماده تحویل نیست.']);
        }
        $p = static::findByCode($code);
        if (! $p) {
            $line = static::unknownLine($s, $code);
            if (! $line) {
                return ['ok' => false, 'type' => 'ask', 'code' => static::cleanCode($code), 'msg' => '⚠ این کد در اسکن اول نبود و در سایت هم ثبت نشده — اگر واقعاً بار مشتری است، تعدادش را بزنید'];
            }
            $step = max(1, (int) $line->per);
            $line->forceFill(['d_units' => (int) $line->d_units + $step])->save();
            $extra = (int) $line->units === 0;
            $over = (int) $line->d_units > (int) $line->units;

            return ['ok' => true, 'type' => $extra ? 'extra' : ($over ? 'over' : 'ok'), 'id' => $line->id,
                'msg' => $extra ? '⚠ «'.$line->name.'» در اسکن اول نبود!' : ($over ? '⚠ «'.$line->name.'» بیشتر از اسکن اول' : '«'.$line->name.'» ✓')];
        }
        $line = $s->items()->where('product_id', $p->id)->first();
        $extra = ! $line || (int) $line->units === 0;
        $line ??= static::lineFor($s, $p);
        $step = max(1, (int) $line->per);
        $line->forceFill(['d_units' => (int) $line->d_units + $step])->save();
        $over = (int) $line->d_units > (int) $line->units;

        return ['ok' => true, 'type' => $extra ? 'extra' : ($over ? 'over' : 'ok'), 'id' => $line->id,
            'msg' => $extra ? '⚠ «'.$p->name.'» در اسکن اول نبود!' : ($over ? '⚠ «'.$p->name.'» بیشتر از اسکن اول' : '«'.$p->name.'» ✓')];
    }

    public static function cleanCode(string $code): string
    {
        return mb_substr(trim(preg_replace('/[\x00-\x1F\x7F]+/', '', en_digits($code))), 0, 60);
    }

    protected static function unknownLine(WalkinSale $s, string $code, ?string $cond = null): ?WalkinItem
    {
        $c = static::cleanCode($code);

        return $c === '' ? null : $s->items()->whereNull('product_id')->where('code', $c)->when($cond, fn ($q) => $q->where('cond', $cond))->first();
    }

    /**
     * کالای ناشناس (کدی که در سایت نیست): ثبت با همان کد اسکن‌شده و تعداد دستی
     * $where: scan (اسکن اول) | deliver (شمارش تحویل) | return (مرجوعی با وضعیت)
     */
    public static function addUnknown(WalkinSale $s, string $code, int $per, int $units, string $where = 'scan', ?string $cond = null): WalkinItem
    {
        $c = static::cleanCode($code);
        if ($c === '') {
            throw ValidationException::withMessages(['code' => 'کد کالا را بزنید.']);
        }
        if ($units <= 0) {
            throw ValidationException::withMessages(['units' => 'تعداد را بنویسید.']);
        }
        $per = max(1, min(100000, $per));
        if ($where === 'deliver') {
            abort_unless($s->kind === 'sale' && $s->status === 'scanned', 422);
        } else {
            static::editable($s);
            if ($where === 'return') {
                abort_unless($s->kind === 'return' && isset(WalkinSale::CONDS[(string) $cond]), 422);
            }
        }
        $line = static::unknownLine($s, $c, $where === 'return' ? $cond : null)
            ?? $s->items()->create(['product_id' => null, 'name' => 'کالای ناشناس — کد '.fa($c), 'code' => $c, 'per' => $per, 'units' => 0,
                'cond' => $where === 'return' ? $cond : null, 'unit_price' => 0]);
        if ($where === 'deliver') {
            $line->forceFill(['d_units' => (int) $line->d_units + $units])->save();
        } else {
            $line->forceFill(['units' => (int) $line->units + $units])->save();
        }
        static::retotal($s);

        return $line;
    }

    public static function deliverSet(WalkinSale $s, int $itemId, ?int $units): void
    {
        abort_unless($s->kind === 'sale' && $s->status === 'scanned', 422);
        $s->items()->findOrFail($itemId)->forceFill(['d_units' => $units === null ? null : max(0, $units)])->save();
    }

    /** اختلاف‌های تحویل با اسکن اول */
    public static function diffs(WalkinSale $s): array
    {
        return $s->items()->get()->filter(fn (WalkinItem $i) => (int) $i->d_units !== (int) $i->units)
            ->map(fn (WalkinItem $i) => ['id' => $i->id, 'name' => $i->name, 'a' => $i->qtyLabel((int) $i->units), 'b' => $i->qtyLabel((int) $i->d_units)])->values()->all();
    }

    /** تأیید بارگیری (تحویل‌دهنده): شمارش تحویل ملاک اکسل هلو */
    public static function confirmLoad(WalkinSale $s, User $u): void
    {
        abort_unless($s->kind === 'sale' && $s->status === 'scanned', 422);
        DB::transaction(function () use ($s, $u) {
            $n = count(static::diffs($s));
            foreach ($s->items()->get() as $i) {
                if ($i->d_units === null) {
                    $i->forceFill(['d_units' => 0])->save();
                }
            }
            $s->forceFill(['status' => 'loaded', 'delivered_by' => $u->id, 'delivered_at' => now(), 'diffs' => $n])->save();
            static::retotal($s);
        });
    }

    protected static function editable(WalkinSale $s): void
    {
        if ($s->status !== 'draft') {
            throw ValidationException::withMessages(['sale' => 'این فاکتور به دفتر فرستاده شده و دیگر قابل تغییر نیست.']);
        }
    }

    public static function retotal(WalkinSale $s): void
    {
        $sum = (int) $s->items()->get()->sum(fn (WalkinItem $i) => $s->qtyOf($i) * (int) $i->unit_price);
        $s->forceFill(['total' => $sum])->saveQuietly();
    }

    /** داده برای اپ */
    public static function data(WalkinSale $s): array
    {
        $s->loadMissing('items', 'scanner', 'deliverer', 'assignee');

        return [
            'id' => $s->id, 'code' => $s->code(), 'kind' => $s->kind, 'status' => $s->status, 'st' => $s->statusLabel(),
            'name' => $s->customer_name, 'city' => $s->city, 'phone' => $s->phone, 'bay' => $s->bay,
            'by' => $s->scanner?->displayName(), 'at' => $s->sent_at ? jdate($s->sent_at, true) : jdate($s->created_at, true),
            'total' => money($s->total), 'to' => $s->assigned_to ? $s->assignee?->displayName() : null,
            'items' => $s->items->map(fn (WalkinItem $i) => ['id' => $i->id, 'pid' => $i->product_id ? (int) $i->product_id : null, 'name' => $i->name, 'code' => $i->code ? fa($i->code) : '', 'raw' => (string) $i->code, 'price' => (int) $i->unit_price, 'per' => (int) $i->per,
                'units' => (int) $i->units, 'd' => $i->d_units, 'cond' => $i->cond, 'label' => $i->qtyLabel(), 'dlabel' => $i->d_units !== null ? $i->qtyLabel((int) $i->d_units) : null,
                'sa' => (int) $i->s_at, 'da' => (int) $i->d_at])->values()->all(),
        ];
    }

    /**
     * اکسل هلو: [کد کالا، تعداد دوم (کارتن)، تعداد (کل عدد)، فی، شرح کالا (جایگاه روی ردیف اول)]
     * مرجوعی: اول سالم‌ها، بعد ایراد کارخانه، بعد ضایعات؛ جلوی آخرین ردیف هر گروه «تا اینجا …»
     */
    public static function excel(WalkinSale $s): string
    {
        // ترتیب ردیف‌ها = ترتیب اسکن (اولین بار که هر کالا اسکن شد)
        $items = $s->items()->with('product:id,sync_code,sku,barcode')->get()->filter(fn (WalkinItem $i) => $s->qtyOf($i) > 0)
            ->sortBy(fn (WalkinItem $i) => [$i->s_at ?: PHP_INT_MAX, $i->d_at ?: PHP_INT_MAX, $i->id]);
        $x = (new XlsWriter('Sheet1'))->money([3]);
        $x->row(['کد کالا ', 'تعداد دوم', 'تعداد', 'فی', 'شرح کالا']);
        $bay = trim((string) $s->bay);
        $first = true;
        $groups = $s->kind === 'return'
            ? collect(array_keys(WalkinSale::CONDS))->map(fn ($c) => [$c, $items->filter(fn ($i) => ($i->cond ?: 'ok') === $c)->values()])
            : collect([[null, $items->values()]]);
        foreach ($groups as [$cond, $list]) {
            $n = $list->count();
            foreach ($list as $k => $i) {
                $u = $s->qtyOf($i);
                $per = max(1, (int) $i->per);
                $code = (string) ($i->product?->sku ?: ($i->product?->sync_code ?: ($i->code ?: $i->product?->barcode)));
                $code = ctype_digit(en_digits($code)) ? (int) en_digits($code) : $code;
                $note = $cond && $k === $n - 1 ? 'تا اینجا '.WalkinSale::CONDS[$cond] : '';
                if ($first && $bay !== '') {
                    // نام جایگاه روبه‌روی ردیف اول
                    $note = trim((str_contains($bay, 'جایگاه') ? $bay : 'جایگاه '.$bay).($note !== '' ? ' — '.$note : ''));
                }
                $first = false;
                // هلو متن را با کدپیج عربی ویندوز می‌خواند که ارقام فارسی (۱۹) ندارد و «??» نشان می‌دهد → ارقام انگلیسی
                $x->row([$code, $per > 1 && $u % $per === 0 ? intdiv($u, $per) : 0, $u, (int) $i->unit_price, en_digits($note)]);
            }
        }
        $s->forceFill(['excel_at' => now()])->saveQuietly();

        return $x->output();
    }
}
