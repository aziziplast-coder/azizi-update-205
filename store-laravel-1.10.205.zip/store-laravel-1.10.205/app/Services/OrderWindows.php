<?php

namespace App\Services;

use App\Models\Order;
use App\Models\User;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\ValidationException;
use Throwable;

/**
 * دو پنجره تغییر سفارش توسط مشتری
 *
 * ۱) پیش از بیعانه: «در ویرایش مشتری» — مهلت (پیش‌فرض ۶ ساعت) برای کم/زیاد/افزودن؛ در این مدت بیعانه صادر نمی‌شود.
 *    پایان مهلت بدون تغییر ← سؤال از مشتری «بیعانه صادر کنم؟» (بله / نه، تمدید) + پنجره برای همکار.
 * ۲) پس از جمع‌آوری انبار: فقط جایگزین کالاهای حذف‌شده یا افزودن کالای جدید (کم کردن نه)؛
 *    همکار در گفتگو تأیید (← انبار) یا رد می‌کند؛ تا جمع شدن آن‌ها مانده حساب صادر نمی‌شود.
 */
class OrderWindows
{
    public const EDIT_GO = '✏️ شروع ویرایش سفارش';

    public const PICKED_TEXT = "📦 بار شما جمع شد.\n{removed}تا {until} فرصت دارید به‌جای اقلام حذف‌شده کالای دیگری بگذارید یا کالای جدید به بارتان اضافه کنید: دکمه «جایگزین یا افزودن کالا» را بزنید، کالا را جستجو کنید و تعداد را بزنید. هر چقدر بخواهید اضافه کنید و در آخر «تأیید و ارسال».\nاگر تغییری ندارید، «تغییری ندارم» را بزنید تا مانده حساب برایتان صادر شود. با تمام شدن زمان هم مانده حساب خودکار صادر می‌شود.";

    public const PICKED_YES = 'جایگزین یا افزودن کالا';

    public const PICKED_NO = 'تغییری ندارم';

    public const WAIT_SETTLE = 'منتظر باشید تا حسابدار مانده حساب را جهت تکمیل وجه برای شما صادر کند.';

    public static function on(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('orders', 'staff_pop');
    }

    /* ======================= ۱) پیش از بیعانه ======================= */

    public static function editHours(): float
    {
        return max(0.5, (float) setting('dep_edit_hours', 6));
    }

    public static function hoursTxt(?float $h = null): string
    {
        return fa(rtrim(rtrim(number_format($h ?? static::editHours(), 1), '0'), '.'));
    }

    /** پایان مهلت ویرایش مشتری (فقط وقتی الان در ویرایش است) */
    public static function editUntil(Order $o): ?Carbon
    {
        if ($o->deposit_ask !== 'edit' || $o->status !== 'on_hold' || ! $o->deposit_asked_at) {
            return null;
        }

        return $o->deposit_asked_at->copy()->addMinutes((int) round(static::editHours() * 60));
    }

    /** «در ویرایش مشتری»: مهلت هنوز تمام نشده */
    public static function editing(Order $o): bool
    {
        $u = static::editUntil($o);

        return $u !== null && $u->isFuture();
    }

    /** چرا الان نمی‌شود این مبلغ را صادر کرد (null = می‌شود) */
    public static function issueBlock(Order $o, string $kind): ?string
    {
        if ($kind === 'deposit' && static::editing($o)) {
            return 'مشتری در حال ویرایش سفارش است (تا '.jdate(static::editUntil($o), true).'). بعد از ثبت تغییرات مشتری یا پایان این زمان بیعانه صادر می‌شود.';
        }
        if ($kind === 'settle') {
            if ($o->fulfil_status === 'replace_review') {
                return 'مشتری کالای جایگزین/جدید فرستاده؛ اول در گفتگو تأیید (ارسال به انبار) یا رد کنید.';
            }
            if ($o->fulfil_status === 'picking') {
                return 'اقلام سفارش در انبار در حال جمع‌آوری است؛ بعد از جمع شدن، مانده حساب صادر می‌شود.';
            }
            // فرصت افزودن/جایگزینی مشتری هنوز باز است ← بعد از پایان زمان (یا «تغییری ندارم») مانده حساب صادر می‌شود
            if ($o->canReplace() && ! $o->replace_submitted_at && ! $o->final_amount) {
                return 'مشتری تا '.jdate($o->replace_until, true).' فرصت افزودن/جایگزینی کالا دارد؛ بعد از پایان این زمان (یا «تغییری ندارم» مشتری) مانده حساب صادر می‌شود. برای صدور زودتر، «زمان افزودن» را ۰ کنید.';
            }
        }

        return null;
    }

    /** مشتری «بله، ویرایش می‌کنم» زد (دور ۱) یا همکار «فرصت آخر» داد (دور ۲): شروع مهلت */
    public static function startEdit(Order $o, int $round = 1, ?User $by = null): void
    {
        $o->forceFill(['deposit_ask' => 'edit', 'deposit_asked_at' => now()] + (static::hasRound() ? ['edit_round' => $round] : []))->saveQuietly();
        static::dropPop($o, 'late');
        $until = jdate(static::editUntil($o), true);
        $o->log(($round > 1 ? 'فرصت آخر ویرایش به مشتری داده شد' : 'مشتری سفارش را در حالت «در ویرایش مشتری» گذاشت').'؛ تا '.$until.' بیعانه صادر نمی‌شود'.($by ? ' — '.$by->displayName() : ''), $by?->id ?? $o->user_id);
        if (! ($t = Chat::thread($o, $round > 1))) {
            return;
        }
        if ($round > 1) {
            Chat::post($t, 's', $by ?? $o->assignee, 'confirm', '⏰ آخرین فرصت '.static::hoursTxt().' ساعته برای تغییر فاکتور به شما داده شد (تا '.$until.').'."\n".'دکمه زیر را بزنید، اقلام را کم و زیاد یا اضافه کنید و «ثبت تغییرات سفارش» را بزنید. با تمام شدن این زمان، هرچه در سبد باشد خودکار در سفارش ثبت می‌شود و فرصت دیگری نیست.', ['opts' => [self::EDIT_GO], 'k' => 'dep2']);
            Chat::notifyCustomer($t->refresh(), $o, '⏰ آخرین فرصت تغییر فاکتور — تا '.$until, $by ?? $o->assignee);
        } else {
            Chat::post($t, 'x', null, 'event', '✏️ سفارش در حالت «در ویرایش مشتری» است. تا '.$until.' ('.static::hoursTxt().' ساعت) فرصت دارید: در سایت بچرخید، کالا اضافه یا کم کنید و در سبد خرید «ثبت تغییرات سفارش» را بزنید. با تمام شدن زمان، هرچه در سبد باشد خودکار ثبت می‌شود.', ['r' => 1]);
        }
        Chat::staffSignal($o->assignee_id);
    }

    public static function hasRound(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('orders', 'edit_round');
    }

    /** مشتری دکمه «شروع ویرایش» فرصت آخر را زد ← اقلام به سبد */
    public static function goEdit(Order $o, Cart $cart): ?string
    {
        if (! $o->customerCanEdit()) {
            return null;
        }
        $cart->loadOrder($o->load('items'));

        return route('cart');
    }

    /** تغییرات مشتری ثبت شد یا انصراف داد ← پنجره برای همکار */
    public static function editDone(Order $o, bool $changed, bool $auto = false): void
    {
        $o->refresh();
        if ($o->status !== 'on_hold' || Remit::payments($o, 'deposit')->isNotEmpty()) {
            return; // بیعانه خودکار صادر شد
        }
        static::dropPop($o, 'late');
        static::addPop($o, 'dep',
            $auto ? 'زمان ویرایش تمام شد — تغییرات مشتری خودکار ثبت شد' : ($changed ? 'مشتری تغییرات فاکتورش را انجام داد' : 'مشتری گفت تغییری ندارد'),
            ($changed ? ($auto ? 'مشتری «ثبت تغییرات» را نزده بود؛ با تمام شدن زمان، اقلام سبدش خودکار در سفارش ثبت شد.' : 'مشتری سفارشش را تغییر داد و منتظر بیعانه است.').' مبلغ تازه سفارش: '.money($o->total).' تومان. فاکتور را بررسی و' : 'مشتری از ویرایش انصراف داد و سفارش بدون تغییر ماند.').' برایش بیعانه صادر کنید.');
    }

    /** سبدِ ویرایش این سفارش (اگر هست) */
    protected static function editCart(Order $o): ?\App\Models\CartRecord
    {
        return \App\Models\CartRecord::query()->where('edit_order_id', $o->id)->whereNull('order_id')->latest('id')->first();
    }

    /** آیا سبد ویرایش با اقلام فعلی سفارش فرق دارد؟ */
    protected static function cartDiffers(Order $o, \App\Models\CartRecord $rec): bool
    {
        $now = [];
        foreach ($o->items()->get(['product_id', 'mode', 'units', 'per_carton']) as $it) {
            if ($it->product_id && (int) $it->units > 0) {
                $k = $it->product_id.':'.$it->cartMode();
                $now[$k] = ($now[$k] ?? 0) + (int) $it->units;
            }
        }
        $cart = array_filter(array_map('intval', (array) $rec->items));
        ksort($now);
        ksort($cart);

        return $cart && $cart !== $now;
    }

    /**
     * پایان مهلت: زمان تغییرات بسته می‌شود؛ هرچه مشتری در سبد تغییر داده (حتی بدون «ثبت تغییرات») خودکار ثبت می‌شود.
     * تغییری نبود ← از همکار پرسیده می‌شود: فرصت آخر (پس از تماس) یا صدور بیعانه.
     */
    public static function editExpired(Order $o): void
    {
        $round = static::hasRound() ? max(1, (int) $o->edit_round) : 1;
        $changed = false;
        $rec = static::editCart($o);
        try {
            if ($rec && static::cartDiffers($o, $rec)) {
                $changed = static::autoSave($o, $rec);
            }
        } catch (Throwable $e) {
            report($e);
            $o->log('ثبت خودکار سبد مشتری در پایان زمان ویرایش انجام نشد: '.mb_substr($e->getMessage(), 0, 200));
        }
        $o->refresh();
        if ($rec && ! $changed) {
            $rec->refresh();
            if ((int) $rec->edit_order_id === (int) $o->id) {
                $rec->update(['items' => [], 'items_count' => 0, 'edit_order_id' => null, 'total' => 0]);
            }
        }
        if (! $changed) {
            $o->forceFill(['deposit_ask' => 'late'])->saveQuietly();
        }
        try {
            if ($t = Chat::thread($o)) {
                Chat::post($t, 'x', null, 'event', $changed
                    ? '⏰ زمان تغییر فاکتور تمام شد. تغییراتی که در سبد داده بودید خودکار در سفارش ثبت شد (مبلغ تازه: '.money($o->total).' تومان). فاکتور شما بررسی و بیعانه برایتان صادر می‌شود.'
                    : '⏰ زمان تغییر فاکتور تمام شد و سفارش بدون تغییر ماند. فاکتور شما بررسی و بیعانه برایتان صادر می‌شود.', ['r' => 1]);
            }
            if ($changed) {
                return; // پنجره «تغییرات خودکار ثبت شد؛ بیعانه صادر کنید» در editDone
            }
            $o->log('زمان '.static::hoursTxt().' ساعته ویرایش مشتری'.($round > 1 ? ' (فرصت آخر)' : '').' بدون تغییر تمام شد');
            static::addPop($o, 'late', $round > 1 ? 'فرصت آخر مشتری هم تمام شد' : 'زمان تغییرات مشتری تمام شد',
                $round > 1
                    ? 'مشتری در فرصت آخر هم تغییری در فاکتورش نداد. سفارش همان است که بود؛ برایش بیعانه صادر کنید.'
                    : 'زمان '.static::hoursTxt().' ساعته تغییرات اولیه برای مشتری تمام شد، ولی تغییری نداد. می‌خواهید با مشتری تماس بگیرید و یک فرصت آخر '.static::hoursTxt().' ساعته بدهید، یا بیعانه صادر می‌کنید؟');
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** ثبت خودکار سبد ویرایش در سفارش (بدون نیاز به ورود مشتری) */
    protected static function autoSave(Order $o, \App\Models\CartRecord $rec): bool
    {
        $guard = auth()->guard();
        $prev = $guard->user();
        $guard->setUser($o->user);
        try {
            $cart = (new Cart)->useRecord($rec);
            app(Checkout::class)->amend($o, $cart, true);
            $o->log('زمان ویرایش تمام شد؛ اقلام سبد مشتری (بدون زدن «ثبت تغییرات») خودکار در سفارش ثبت شد');

            return true;
        } finally {
            if ($prev) {
                $guard->setUser($prev);
            } elseif (method_exists($guard, 'forgetUser')) {
                $guard->forgetUser();
            }
        }
    }

    /** همکار: «فرصت آخر» (پس از تماس با مشتری) */
    public static function extend(Order $o, User $by): string
    {
        if ($o->deposit_ask !== 'late' || $o->status !== 'on_hold' || Remit::payments($o, 'deposit')->isNotEmpty()) {
            throw ValidationException::withMessages(['ext' => 'این سفارش الان منتظر تصمیم زمان ویرایش نیست.']);
        }
        if (static::hasRound() && (int) $o->edit_round >= 2) {
            throw ValidationException::withMessages(['ext' => 'فرصت آخر قبلاً داده شده؛ برایش بیعانه صادر کنید.']);
        }
        static::startEdit($o, 2, $by);

        return 'فرصت آخر '.static::hoursTxt().' ساعته به مشتری داده شد';
    }

    /** زمان‌بند: پایان مهلت‌های ویرایش */
    public static function tick(): int
    {
        if (! static::on()) {
            return 0;
        }
        $n = 0;
        $mins = (int) round(static::editHours() * 60);
        foreach (Order::query()->where('deposit_ask', 'edit')->where('status', 'on_hold')->where('deposit_asked_at', '<', now()->subMinutes($mins))->limit(30)->get() as $o) {
            static::editExpired($o);
            $n++;
        }
        // پایان فرصت افزودن/جایگزینی پس از جمع‌آوری (بدون ارسال مشتری) ← صدور مانده حساب
        foreach (Order::query()->where('fulfil_status', 'picked')->whereNotNull('replace_until')->where('replace_until', '<=', now())
            ->where('replace_until', '>=', max(now()->subDays(3), Carbon::createFromTimestamp((int) setting('addwin_since', 0))))->whereNull('replace_submitted_at')->limit(30)->get() as $o) {
            $o->replacements()->where('status', 'draft')->delete();
            $o->forceFill(['replace_until' => null])->saveQuietly();
            $o->log('زمان افزودن/جایگزینی کالای مشتری تمام شد (بدون تغییر)');
            if ($t = Chat::thread($o, false)) {
                Chat::post($t, 'x', null, 'event', '⏰ زمان افزودن کالا به بار تمام شد. '.self::WAIT_SETTLE, ['r' => 1]);
            }
            static::windowEnded($o->refresh());
            $n++;
        }

        return $n;
    }

    /* ======================= ۲) پس از جمع‌آوری ======================= */

    /** پیام «بار شما جمع شد» + دکمه (یک بار برای هر سفارش) */
    public static function afterPicked(Order $o): void
    {
        if (static::on() && ! $o->canReplace()) {
            static::windowEnded($o); // فرصت افزودن ندارد ← صدور مانده حساب
        }
        if (! static::on() || ! $o->canReplace() || ! ($t = Chat::thread($o))) {
            return;
        }
        try {
            if (\App\Models\ChatMessage::query()->where('thread_id', $t->id)->where('kind', 'confirm')->where('meta', 'like', '%"k":"pick"%')->exists()) {
                return;
            }
            $rm = Picking::removedItems($o->load('items'))->count();
            $text = strtr(trim((string) setting('picked_ask_text')) ?: self::PICKED_TEXT, [
                '{removed}' => $rm ? fa($rm).' قلم از فاکتور شما در انبار کسری یا ناموجود بود و از فاکتور حذف شد.'."\n" : '',
                '{until}' => jdate($o->replace_until, true), '{number}' => fa((string) $o->number),
            ]);
            Chat::post($t, 's', $o->assignee, 'confirm', $text, ['opts' => [self::PICKED_YES, self::PICKED_NO], 'k' => 'pick']);
            Chat::notifyCustomer($t->refresh(), $o, '📦 بار شما جمع شد — جایگزین یا کالای جدید می‌خواهید؟', $o->assignee);
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** پاسخ مشتری به پیام «بار شما جمع شد» */
    public static function pickedAnswer(Order $o, bool $yes): ?string
    {
        if ($yes) {
            return $o->canReplace() && ! $o->replace_submitted_at ? route('order.show', $o->number).'#replace' : null;
        }
        if ($o->fulfil_status === 'picked' && $o->replace_until && ! $o->replace_submitted_at) {
            $o->replacements()->where('status', 'draft')->delete();
            $o->forceFill(['replace_until' => null])->saveQuietly();
            $o->log('مشتری گفت جایگزین یا کالای جدید نمی‌خواهد؛ مهلت جایگزینی بسته شد', $o->user_id);
        }
        if ($t = Chat::thread($o, false)) {
            Chat::post($t, 'x', null, 'event', '🙏 '.self::WAIT_SETTLE, ['r' => 1]);
        }
        static::windowEnded($o->refresh());

        return null;
    }

    /* ---------- فرصت افزودن به بار (تایمر، دست اپراتور) ---------- */

    public const ADD_GO = '➕ افزودن کالا به سفارش';

    /** وضعیت فرصت افزودن برای گفتگو (null = بسته) */
    public static function addWin(Order $o): ?array
    {
        if (! static::on()) {
            return null;
        }
        $open = $o->canReplace() && ! $o->replace_submitted_at;
        $review = $o->fulfil_status === 'replace_review';
        if (! $open && ! $review) {
            return null;
        }
        $drafts = $o->replacements()->where('status', 'draft')->orderBy('id')->get();

        return [
            'open' => $open, 'review' => $review,
            'until' => $o->replace_until?->timestamp, 'until_fa' => $o->replace_until ? jdate($o->replace_until, true) : '',
            'left' => $o->replace_until ? max(0, (int) now()->diffInSeconds($o->replace_until, false)) : 0,
            'drafts' => $drafts->map(fn ($r) => ['id' => $r->id, 'name' => $r->name, 'qty' => $r->qtyLabel(), 'total' => money($r->total())])->values()->all(),
            'sum' => money((int) $drafts->sum(fn ($r) => $r->total())),
        ];
    }

    /** اپراتور: تغییر زمان فرصت افزودن (۰ = بستن ← صدور مانده حساب) */
    public static function setWindow(Order $o, float $hours, ?User $by, bool $announce = true): string
    {
        if (! in_array($o->status, ['on_hold', 'processing', 'settling'], true) || $o->isPaid() || ! in_array($o->fulfil_status, ['picked', 'replace_review'], true)) {
            throw ValidationException::withMessages(['win' => 'فرصت افزودن فقط پس از جمع شدن بار و پیش از تسویه کامل ممکن است.']);
        }
        if ($o->fulfil_status === 'replace_review') {
            throw ValidationException::withMessages(['win' => 'مشتری کالا فرستاده و منتظر تأیید است؛ اول آن را تأیید یا رد کنید.']);
        }
        $hours = max(0, min(240, $hours));
        if ($hours <= 0) {
            $o->replacements()->where('status', 'draft')->delete();
            $o->forceFill(['replace_until' => null, 'replace_submitted_at' => null])->saveQuietly();
            $o->log('فرصت افزودن کالای مشتری بسته شد'.($by ? ' — '.$by->displayName() : ''), $by?->id);
            if ($announce && ($t = Chat::thread($o, false))) {
                Chat::post($t, 'x', null, 'event', '⏰ فرصت افزودن کالا به بار بسته شد. '.self::WAIT_SETTLE, ['r' => 1]);
            }
            static::windowEnded($o->refresh(), false);

            return 'فرصت افزودن بسته شد؛ می‌توانید مانده حساب را صادر کنید.';
        }
        $o->forceFill(['replace_until' => now()->addMinutes((int) round($hours * 60)), 'replace_submitted_at' => null])->saveQuietly();
        static::dropPop($o, 'settle');
        $until = jdate($o->replace_until, true);
        $o->log('فرصت افزودن کالای مشتری تا '.$until.' ('.static::hoursTxt($hours).' ساعت)'.($by ? ' — '.$by->displayName() : ''), $by?->id);
        if ($announce && ($t = Chat::thread($o))) {
            Chat::post($t, 'x', null, 'event', '⏳ تا '.$until.' فرصت دارید کالا به بارتان اضافه یا جایگزین کنید (دکمه «➕ افزودن کالا» بالای گفتگو).', ['r' => 1]);
        }

        return 'فرصت افزودن تا '.$until;
    }

    /** اپراتور: «کادر افزودن به سفارش» برای مشتری (مثلاً در مرحله مانده حساب) */
    public static function sendBox(Order $o, User $by, float $hours): string
    {
        if (! ($o->canReplace() && ! $o->replace_submitted_at)) {
            static::setWindow($o, $hours, $by, false);
            $o->refresh();
        }
        if ($t = Chat::thread($o)) {
            Chat::post($t, 's', $by, 'confirm', '➕ برای افزودن کالا به بارتان دکمه زیر را بزنید: کالا را با نام یا کد جستجو کنید، تعداد (کارتن یا خرده) را بزنید و در آخر «تأیید و ارسال». '
                .(static::autoAdd() ? 'اقلام تأییدشده مستقیم به سفارش شما اضافه و برای جمع‌آوری به انبار می‌رود.' : 'پس از تأیید فروشگاه به سفارش اضافه می‌شود.').' (تا '.jdate($o->replace_until, true).')',
                ['opts' => [self::ADD_GO], 'k' => 'addbox']);
            Chat::notifyCustomer($t->refresh(), $o, '➕ افزودن کالا به سفارش — تا '.jdate($o->replace_until, true), $by);
        }

        return 'کادر افزودن برای مشتری فرستاده شد';
    }

    /** افزوده‌های مشتری بدون تأیید اپراتور مستقیم به سفارش و انبار برود؟ */
    public static function autoAdd(): bool
    {
        return (bool) setting('repl_auto', true);
    }

    /**
     * پایان فرصت افزودن (زمان تمام شد / «تغییری ندارم» / اپراتور بست) ← گزینه صدور مانده حساب برای اپراتور؛
     * اگر صدور خودکار کمک‌حسابدار روشن است و سفارش نقدی است، مانده همین حالا صادر می‌شود.
     */
    public static function windowEnded(Order $o, bool $pop = true): void
    {
        if ($o->isPaid() || $o->final_amount || $o->fulfil_status !== 'picked' || ! in_array($o->status, ['processing', 'settling'], true)) {
            return;
        }
        try {
            $u = $o->assignee;
            if ($u && Remit::enabled() && Remit::cfg($u)['mode'] === 'auto' && ! Shipping::hasCheques($o) && $o->payment_method !== 'cheque'
                && Remit::payments($o, 'settle')->isEmpty() && setting('settle_auto', true)) {
                $made = Remit::settle($o, (int) $o->total, null, $u);
                if ($made && $made->isNotEmpty()) {
                    Remit::notifyCustomer($o->refresh(), 'settle');
                }
                $o->log('مانده حساب خودکار پس از پایان فرصت افزودن صادر شد');

                return;
            }
        } catch (Throwable $e) {
            report($e);
            $o->log('مانده حساب خودکار صادر نشد: '.($e instanceof ValidationException ? collect($e->errors())->flatten()->first() : $e->getMessage()));
        }
        if ($pop) {
            static::addPop($o, 'settle', 'فرصت افزودن مشتری تمام شد', 'مشتری کالایی اضافه نکرد. مانده حساب را صادر کنید.');
        }
    }


    /** مشتری جایگزین/کالای جدید را فرستاد */
    public static function replSubmitted(Order $o, int $n, int $sum): void
    {
        if ($t = Chat::thread($o)) {
            Chat::post($t, 'x', null, 'event', '🔁 '.fa($n).' کالای جایگزین/جدید ('.money($sum).' تومان) برای تأیید فروشگاه فرستاده شد. پس از تأیید، برای جمع‌آوری به انبار می‌رود.', ['r' => 1]);
            Chat::notifyStaff($t, $o, '🔁 مشتری '.fa($n).' کالای جایگزین/جدید فرستاد ('.money($sum).' تومان) — در گفتگو تأیید یا رد کنید.');
        }
    }

    /** تأیید (← انبار) یا رد جایگزین‌ها از داخل گفتگو */
    public static function replDecide(Order $o, bool $ok, ?User $by, ?string $reason = null): string
    {
        if ($o->fulfil_status !== 'replace_review') {
            throw ValidationException::withMessages(['repl' => 'درخواست جایگزینی منتظر تأیید نیست.']);
        }
        $ids = $o->replacements()->where('status', 'submitted')->pluck('id')->map(fn ($v) => (int) $v)->all();
        $sum = (int) $o->replacements()->where('status', 'submitted')->get()->sum(fn ($r) => $r->total());
        $before = (int) $o->total;
        $added = app(Picking::class)->approveReplacements($o, $ok ? $ids : [], $ok);
        $o->refresh();
        $t = Chat::thread($o);
        if ($ok && $added) {
            $msg = '✅ '.fa($added).' کالای جایگزین/جدید شما ('.money($sum).' تومان) تأیید شد و برای جمع‌آوری به انبار رفت. مبلغ فاکتور: '.money($before).' ← '.money($o->total)." تومان.\n".self::WAIT_SETTLE;
        } else {
            $reason = trim((string) $reason);
            $msg = '❌ کالاهای جایگزین/جدید شما اضافه نشد'.($reason !== '' ? ': '.$reason : '.')."\n".self::WAIT_SETTLE;
        }
        if ($t) {
            Chat::post($t, 's', $by, 'text', $msg);
            Chat::notifyCustomer($t->refresh(), $o, $ok ? '✅ کالاهای جایگزین/جدید تأیید شد' : '❌ کالاهای جایگزین/جدید اضافه نشد', $by);
        }
        $o->log(($ok ? 'جایگزین‌های مشتری از گفتگو تأیید و به انبار ارجاع شد' : 'جایگزین‌های مشتری از گفتگو رد شد'.($reason ? ': '.$reason : '')).($by ? ' — '.$by->displayName() : ''), $by?->id);

        return $ok ? 'تأیید شد و به انبار رفت' : 'رد شد';
    }

    /* ======================= پنجره‌های همکار در گفتگو ======================= */

    public static function addPop(Order $o, string $k, string $title, string $body): void
    {
        if (! static::on()) {
            return;
        }
        $p = array_values(array_filter((array) $o->staff_pop, fn ($x) => ($x['k'] ?? '') !== $k));
        $p[] = ['k' => $k, 't' => $title, 'b' => $body, 'at' => now()->timestamp];
        $o->forceFill(['staff_pop' => $p])->saveQuietly();
        try {
            if ($t = Chat::thread($o, false)) {
                Chat::signal($t, ['d' => (int) round(microtime(true) * 10)]);
                Chat::staffSignal($o->assignee_id);
            }
            if ($o->assignee_id) {
                app(WebPush::class)->toUsers([$o->assignee_id], ['title' => $title.' — سفارش '.fa((string) $o->number), 'body' => $o->customer_name, 'url' => url('/admin/chats?o='.$o->id), 'tag' => 'pop-'.$o->id]);
            }
        } catch (Throwable $e) {
            report($e);
        }
    }

    public static function dropPop(Order $o, string $k): void
    {
        if (! static::on() || ! $o->staff_pop) {
            return;
        }
        $p = array_values(array_filter((array) $o->staff_pop, fn ($x) => ($x['k'] ?? '') !== $k));
        $o->forceFill(['staff_pop' => $p ?: null])->saveQuietly();
    }

    /** پنجره‌هایی که همکار با باز کردن گفتگوی این مشتری می‌بیند */
    public static function pops(Order $o, User $u): array
    {
        if (! static::on()) {
            return [];
        }
        $out = [];
        $canDo = $u->hasPerm('orders_edit') && ($u->isAdmin() || (int) $o->assignee_id === (int) $u->id);
        if ($o->fulfil_status === 'replace_review') {
            $reps = $o->replacements()->with('replaces')->where('status', 'submitted')->get();
            if ($reps->isNotEmpty()) {
                $out[] = ['k' => 'repl', 'at' => (int) $o->replace_submitted_at?->timestamp, 'can' => $canDo,
                    't' => 'مشتری کالای جایگزین/جدید فرستاده',
                    'b' => 'این اقلام را به فاکتورش اضافه کرده. تأیید می‌کنید که برای جمع‌آوری به انبار برود؟',
                    'items' => $reps->map(fn ($r) => ['name' => $r->name, 'qty' => $r->qtyLabel(), 'total' => money($r->total()),
                        'for' => $r->replaces ? 'جایگزین «'.$r->replaces->name.'»' : 'کالای جدید'])->values()->all(),
                    'sum' => money((int) $reps->sum(fn ($r) => $r->total())), 'now' => money($o->total), 'after' => money((int) $o->total + (int) $reps->sum(fn ($r) => $r->total()))];
            }
        }
        $depOpen = $o->status === 'on_hold' && Remit::payments($o, 'deposit')->isEmpty();
        $setOpen = ! $o->isPaid() && ! $o->final_amount && Remit::payments($o, 'settle')->isEmpty() && $o->fulfil_status === 'picked';
        foreach ((array) $o->staff_pop as $p) {
            if (in_array($p['k'] ?? '', ['dep', 'late'], true) && ! $depOpen) {
                continue;
            }
            if (($p['k'] ?? '') === 'settle' && ! $setOpen) {
                continue;
            }
            if (($p['k'] ?? '') === 'addprint') {
                $rnd = (int) $o->items()->where('units', '>', 0)->max('round');
                $p['print'] = $rnd > 1 ? route('admin.invoice', ['order' => $o->id, 'wh' => 'add-'.$rnd]) : null;
            }
            $out[] = $p + ['can' => Remit::enabled() && Remit::canWork($u),
                'hrs' => static::hoursTxt(), 'ext' => ($p['k'] ?? '') === 'late' && $o->deposit_ask === 'late' && (! static::hasRound() || (int) $o->edit_round < 2) && $canDo];
        }

        return $out;
    }
}
