<?php

namespace App\Services;

use App\Models\BotBroadcast;
use App\Models\BotPost;
use App\Models\BotProfile;
use App\Models\Product;
use App\Models\ProductCollection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;
use Throwable;

/**
 * ربات کانال روی هاست جدا («هاب ربات»)
 *
 * سایت تصمیم می‌گیرد (کدام کالا ارسال، ویرایش یا حذف شود؛ متن؛ ساعت خاموشی؛ سقف ارسال) و برنامه کوچک روی هاست ربات
 * (botagent/agent.py) هر دقیقه کارها را از /api/bot/v1/jobs می‌گیرد، در بله انجام می‌دهد و نتیجه را برمی‌گرداند.
 * توکن ربات بله هیچ‌وقت به سایت نمی‌آید؛ ربات هم فقط به کانال‌هایی که روی هاست خودش تعریف شده پست می‌دهد.
 * سبک: محاسبه تغییرات حداکثر هر ۳ دقیقه (و فقط اگر کالایی عوض شده باشد) و هر ۱۵ دقیقه یک بار کامل.
 */
class BotHub
{
    public const VERSION_MIN = 1;

    public static function ready(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasTable('bot_posts');
    }

    public static function cfg(): array
    {
        $c = (array) setting('bot_hub', []);
        $keys = array_values(array_filter((array) ($c['keys'] ?? []), fn ($k) => is_array($k) && ! empty($k['hash'])));
        if (! $keys && ! empty($c['key_hash'])) { // نسخه قبل: یک کلید
            $keys = [['id' => substr($c['key_hash'], 0, 8), 'hash' => $c['key_hash'], 'hint' => (string) ($c['key_hint'] ?? ''), 'label' => 'هاست ربات', 'ip' => (string) ($c['ip_lock'] ?? ''), 'at' => $c['key_at'] ?? null]];
        }

        return [
            'on' => ! array_key_exists('on', $c) || ! empty($c['on']),   // کلید اصلی همه ربات‌ها
            'keys' => $keys,                                             // هر هاست ربات یک کلید
        ];
    }

    public static function saveCfg(array $patch): void
    {
        \App\Support\Settings::set(['bot_hub' => array_merge((array) setting('bot_hub', []), $patch)]);
    }

    /* ======================= کلیدهای اتصال (هر هاست ربات یک کلید) ======================= */

    /** کلید تازه برای یک هاست ربات (کلیدهای دیگر دست نمی‌خورند). فقط همین یک بار به‌صورت کامل دیده می‌شود. */
    public static function newKey(string $label = 'هاست ربات', ?string $replace = null): string
    {
        $key = 'bk_'.Str::random(45);
        $hash = hash('sha256', $key);
        $keys = array_values(array_filter(static::cfg()['keys'], fn ($k) => $k['id'] !== $replace));
        $keys[] = ['id' => substr($hash, 0, 8), 'hash' => $hash, 'hint' => substr($key, 0, 7).'…'.substr($key, -4), 'label' => mb_substr(trim($label) ?: 'هاست ربات', 0, 60), 'ip' => '', 'at' => now()->toIso8601String()];
        static::saveCfg(['keys' => $keys, 'key_hash' => '', 'key_hint' => '']);

        return $key;
    }

    public static function revoke(?string $id = null): void
    {
        static::saveCfg(['keys' => $id ? array_values(array_filter(static::cfg()['keys'], fn ($k) => $k['id'] !== $id)) : [], 'key_hash' => '', 'key_hint' => '']);
    }

    public static function setIp(string $id, string $ip): void
    {
        static::saveCfg(['keys' => array_map(fn ($k) => $k['id'] === $id ? ['ip' => $ip] + $k : $k, static::cfg()['keys']), 'key_hash' => '']);
    }

    /** شناسه کلید معتبر، وگرنه null */
    public static function checkKey(?string $key, ?string $ip): ?string
    {
        if (! $key) {
            return null;
        }
        $h = hash('sha256', $key);
        foreach (static::cfg()['keys'] as $k) {
            if (hash_equals($k['hash'], $h)) {
                return empty($k['ip']) || $k['ip'] === $ip ? $k['id'] : null;
            }
        }

        return null;
    }

    /** وضعیت برنامه روی هر هاست ربات: [شناسه کلید => اطلاعات آخرین تماس] */
    public static function agents(): array
    {
        $ids = array_column(static::cfg()['keys'], 'label', 'id');
        $all = (array) Cache::get('bothub.agents', []);
        $out = [];
        foreach ($ids as $id => $label) {
            $a = (array) ($all[$id] ?? []);
            $out[$id] = $a + ['label' => $label, 'online' => ! empty($a['at']) && now()->timestamp - (int) $a['at'] < 180];
            $out[$id]['label'] = $label;
        }

        return $out;
    }

    /** آخرین هاست فعال (سازگاری) */
    public static function agent(): array
    {
        $a = collect(static::agents())->sortByDesc(fn ($x) => (int) ($x['at'] ?? 0))->first();

        return (array) $a;
    }

    public static function online(): bool
    {
        $ag = static::agents();

        return $ag && collect($ag)->every(fn ($a) => $a['online'] || empty($a['at']) && empty($a['chats']));
    }

    public static function seen(?string $id, ?string $ip, array $info = []): void
    {
        $all = (array) Cache::get('bothub.agents', []);
        $all[$id ?: '-'] = array_merge((array) ($all[$id ?: '-'] ?? []), $info, ['at' => now()->timestamp, 'ip' => $ip]);
        Cache::forever('bothub.agents', $all);
    }

    /** خطاهای اخیر (برای پنل) */
    public static function log(string $msg, ?int $profile = null): void
    {
        $l = (array) Cache::get('bothub.log', []);
        array_unshift($l, ['t' => now()->timestamp, 'p' => $profile, 'm' => mb_substr($msg, 0, 300)]);
        Cache::forever('bothub.log', array_slice($l, 0, 60));
    }

    /* ======================= متن پست ======================= */

    public const VARS = [
        '{name}' => 'نام کالا', '{barcode}' => 'بارکد', '{carton}' => 'تعداد در کارتن', '{price}' => 'قیمت واحد (تومان)',
        '{status}' => 'موجود / ناموجود', '{link}' => 'لینک کالا در سایت', '{date}' => 'تاریخ و ساعت آخرین تغییر', '{shop}' => 'نام فروشگاه',
        '{price_line}' => 'خط قیمت (اگر تخفیف دارد: قیمت قبل، قیمت حراج و درصد)', '{old_price}' => 'قیمت قبل از تخفیف', '{discount}' => 'درصد تخفیف',
        '{tags}' => 'هشتگ دسته کالا', '{category}' => 'نام دسته',
    ];

    /** فیلدهای قابل انتخاب متن پست (به همین ترتیب در پست می‌آیند) */
    public const FIELDS = [
        'name' => 'نام کالا', 'code' => 'بارکد / کد کالا', 'carton' => 'تعداد در کارتن', 'price' => 'قیمت هر عدد (و تخفیف اگر دارد)',
        'carton_price' => 'قیمت هر کارتن', 'retail' => 'قیمت خرده (تکی)', 'status' => 'وضعیت موجودی', 'category' => 'دسته کالا',
        'link' => 'لینک کالا در سایت', 'tags' => 'هشتگ دسته', 'date' => 'تاریخ آخرین تغییر',
    ];

    public const DEFAULT_FIELDS = ['name', 'code', 'carton', 'price', 'status'];

    /** ستون‌های نسخه ۲ (کد پست، ناموجودی، فیلدها، پاک‌سازی کانال) ساخته شده‌اند؟ */
    public static function hasV2(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('bot_profiles', 'purge') && \App\Support\DbSchema::hasColumn('bot_posts', 'code');
    }

    /** فیلدهای انتخاب‌شده کانال (خالی = متن از روی «قالب متن») */
    public static function fieldsOf(BotProfile $pf): array
    {
        if (! static::hasV2()) {
            return [];
        }
        $f = array_map('strval', (array) $pf->fields);

        return array_values(array_filter(array_keys(self::FIELDS), fn ($k) => in_array($k, $f, true)));
    }

    public static function defaultTemplate(string $footer = ''): string
    {
        return "نام محصول: {name}\nبارکد محصول: {barcode}\nتعداد در کارتن: {carton}\n{price_line}\nوضعیت در انبار : {status}\n"
            .($footer !== '' ? "\n".trim($footer)."\n" : '')
            ."\n{tags}\nآخرین تغییرات در تاریخ : {date}";
    }

    /** محصولات محدوده هر کانال */
    public static function scope(BotProfile $pf): \Illuminate\Database\Eloquent\Builder
    {
        if ($pf->source === 'collection') {
            $c = $pf->collection_id ? ProductCollection::query()->find($pf->collection_id) : null;

            return $c ? $c->products()->reorder() : Product::query()->whereRaw('1 = 0');
        }

        return Product::query()->active();
    }

    public static function available(Product $p, BotProfile $pf): bool
    {
        if (! $p->is_active) {
            return false;
        }

        return $pf->only_wholesale ? $p->cartonAvailable() : $p->isAvailable();
    }

    public static function hash(Product $p, bool $avail, ?BotProfile $pf = null): string
    {
        $base = [(string) $p->name, static::code($p), (int) $p->per_carton, (int) $p->unitPrice(Product::CARTON), $p->discountPercent() ? (int) $p->compare_price : 0, $avail];
        // فیلدهای انتخابی که در امضای قبلی نبودند (فقط وقتی همان فیلد در متن پست است؛ امضای پست‌های قدیمی عوض نمی‌شود)
        if ($pf && ($f = static::fieldsOf($pf))) {
            if (in_array('retail', $f, true)) {
                $base[] = $p->retailAllowed() ? (int) $p->unitPrice(Product::RETAIL).'|'.(int) $p->retailAvailable() : '-';
            }
            if (array_intersect(['category', 'tags'], $f)) {
                $base[] = (int) $p->category_id;
            }
            $base[] = implode(',', $f).'|'.md5((string) $pf->footer);
        }

        return md5(json_encode($base, JSON_UNESCAPED_UNICODE));
    }

    /** بارکد/کد کالا برای متن پست: بارکد، وگرنه کد کالا (هلو)؛ در این سایت کد هلو در «کد کالا» است و بارکد معمولاً خالی */
    public static function code(Product $p): string
    {
        return $p->displayCode();
    }

    public static function tag(?string $s): string
    {
        $s = trim(preg_replace('/[^\p{L}\p{N}]+/u', '_', (string) $s), '_');

        return $s !== '' ? '#'.$s : '';
    }

    public static function text(Product $p, BotProfile $pf, bool $avail, bool $album = false, ?int $wasPrice = null, ?int $postId = null): string
    {
        $price = (int) $p->unitPrice(Product::CARTON);
        $disc = $p->discountPercent();
        $old = $disc ? (int) $p->compare_price : 0;
        $priceLine = $disc
            ? 'قیمت قبل: '.number_format($old)."\n🔥 قیمت حراج (به تومان): ".number_format($price).' — '.$disc.'٪ تخفیف'
            : 'قیمت واحد (به تومان): '.number_format($price);
        $cat = $p->relationLoaded('category') ? $p->category : $p->category()->first();
        $tags = trim(implode(' ', array_filter([static::tag($cat?->name), $disc ? '#حراج' : ''])));
        if ($fields = static::fieldsOf($pf)) {
            $t = static::fieldsText($p, $pf, $fields, $avail, $priceLine, $tags, $cat?->name);
        } else {
        $tpl = trim((string) $pf->template) ?: static::defaultTemplate();
        $t = strtr($tpl, [
            '{price_line}' => $priceLine, '{old_price}' => $old ? number_format($old) : '', '{discount}' => $disc ? $disc.'٪' : '',
            '{tags}' => $tags, '{category}' => (string) $cat?->name,
            '{name}' => (string) $p->name, '{barcode}' => static::code($p) ?: '—',
            '{carton}' => (int) $p->per_carton > 0 ? $p->per_carton.' '.$p->unitName() : '—',
            '{price}' => number_format($price), '{status}' => $avail ? '🟢 موجود' : '🔴 ناموجود',
            '{link}' => $p->url(), '{date}' => \App\Support\Jalali::format(now(), true), '{shop}' => store_name(),
        ]);
        }
        $t = preg_replace("/\n{3,}/u", "\n\n", preg_replace("/^[ \t]+$/mu", '', $t));
        // قیمت پایین آمد
        if ($wasPrice && $price < $wasPrice && $avail) {
            $t = '📉 قیمت کاهش یافت!'."\n".$t;
        }
        // آلبوم دکمه ندارد؛ لینک به‌صورت متن
        if (($album || $pf->platform === 'rubika') && $pf->button_text) {
            $t .= "\n\n🔗 ".$pf->button_text.': '.static::buttonUrl($p, $pf, $postId);
        }

        return mb_substr($t, 0, 1020);
    }

    /** متن پست از روی فیلدهای انتخابی + متن ثابت پایین پست */
    protected static function fieldsText(Product $p, BotProfile $pf, array $fields, bool $avail, string $priceLine, string $tags, ?string $catName): string
    {
        $pc = (int) $p->per_carton;
        $price = (int) $p->unitPrice(Product::CARTON);
        $main = [];
        $end = [];
        foreach ($fields as $f) {
            $line = match ($f) {
                'name' => 'نام محصول: '.$p->name,
                'code' => 'بارکد محصول: '.(static::code($p) ?: '—'),
                'carton' => $pc > 0 ? 'تعداد در کارتن: '.$pc.' '.$p->unitName() : null,
                'price' => $priceLine,
                'carton_price' => $pc > 1 ? 'قیمت هر کارتن (به تومان): '.number_format($price * $pc) : null,
                'retail' => $p->retailAllowed() ? 'قیمت خرده هر '.$p->unitName().' (به تومان): '.number_format((int) $p->unitPrice(Product::RETAIL)).($p->retailAvailable() ? '' : ' — خرده ناموجود') : null,
                'status' => 'وضعیت در انبار : '.($avail ? '🟢 موجود' : '🔴 ناموجود'),
                'category' => $catName ? 'دسته: '.$catName : null,
                'link' => '🔗 مشاهده و ثبت سفارش: '.$p->url(),
                'tags' => $tags !== '' ? $tags : null,
                'date' => 'آخرین تغییرات در تاریخ : '.\App\Support\Jalali::format(now(), true),
                default => null,
            };
            if ($line === null) {
                continue;
            }
            in_array($f, ['tags', 'date'], true) ? $end[] = $line : $main[] = $line;
        }
        $footer = trim((string) $pf->footer);

        return implode("\n", $main).($footer !== '' ? "\n\n".$footer : '').($end ? "\n\n".implode("\n", $end) : '');
    }

    /** لینک دکمه: از مسیر شمارش کلیک (/b/…) به صفحه کالا یا لینک دلخواه */
    public static function buttonUrl(Product $p, BotProfile $pf, ?int $postId = null): string
    {
        return $postId ? url('/b/'.base_convert((string) $postId, 10, 36)) : static::target($p, $pf);
    }

    public static function target(?Product $p, BotProfile $pf): string
    {
        $u = trim((string) $pf->button_url);

        return $u === '' || $u === '{link}' ? ($p ? $p->url() : url('/')) : $u;
    }

    /** کلیک روی دکمه پست: شمارش (در حافظه موقت، بدون نوشتن در دیتابیس) و نشانه ۷ روزه برای سفارش */
    public static function click(BotPost $post): void
    {
        $d = now('Asia/Tehran')->format('Ymd');
        $k = 'bothub.k.'.$post->profile_id.'.'.$d;
        Cache::put($k, (int) Cache::get($k, 0) + 1, 86400 * 9);
        $top = (array) Cache::get('bothub.kp.'.$post->profile_id.'.'.$d, []);
        $top[$post->product_id ?? 0] = (int) ($top[$post->product_id ?? 0] ?? 0) + 1;
        if (count($top) > 300) {
            arsort($top);
            $top = array_slice($top, 0, 200, true);
        }
        Cache::put('bothub.kp.'.$post->profile_id.'.'.$d, $top, 86400 * 9);
    }

    /** نشانی موقت عکس JPEG (امضاشده، ۲ ساعت) */
    public static function images(Product $p, BotProfile $pf): array
    {
        $all = array_values(array_filter(array_merge([(string) $p->image], array_map('strval', (array) $p->gallery)), fn ($i) => $i !== '' && ! preg_match('#^(https?:)?//#', $i)));
        $all = array_slice($all, 0, max(1, min(10, (int) $pf->max_images)));

        return array_map(fn ($i, $n) => url(URL::temporarySignedRoute('bot.img', now()->addHours(2), ['product' => $p->id, 'n' => $n], false)), $all, array_keys($all));
    }

    /** امضای عکس‌هایی که این کانال از کالا می‌فرستد (عوض شدن عکس اصلی/گالری = پست دوباره) */
    public static function imgSig(Product $p, BotProfile $pf): string
    {
        $all = array_values(array_filter(array_merge([(string) $p->image], array_map('strval', (array) $p->gallery)), fn ($i) => $i !== '' && ! preg_match('#^(https?:)?//#', $i)));
        $all = array_slice($all, 0, $pf->platform === 'rubika' ? 1 : max(1, min(10, (int) $pf->max_images)));

        return substr(md5(implode('|', $all)), 0, 16);
    }

    protected static function hasImgCol(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasColumn('bot_posts', 'img');
    }

    /** فایل JPEG عکس شماره n کالا (حداکثر ۱۲۸۰ پیکسل؛ یک بار ساخته و نگه داشته می‌شود) */
    public static function jpeg(Product $p, int $n): ?string
    {
        $list = array_values(array_filter(array_merge([(string) $p->image], array_map('strval', (array) $p->gallery)), fn ($i) => $i !== '' && ! preg_match('#^(https?:)?//#', $i)));
        $rel = $list[$n] ?? null;
        $src = $rel ? public_path('uploads/'.ltrim($rel, '/')) : null;
        if (! $src || ! is_file($src)) {
            return null;
        }
        $dir = storage_path('app/bot-img');
        if (! is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return static::toJpeg($src, $dir.'/'.$p->id.'-'.$n.'-'.substr(md5($rel.filemtime($src)), 0, 8).'.jpg');
    }

    /** عکس پیام دستی */
    public static function broadcastJpeg(BotBroadcast $b): ?string
    {
        $src = $b->image ? public_path('uploads/'.ltrim($b->image, '/')) : null;
        if (! $src || ! is_file($src)) {
            return null;
        }
        $dir = storage_path('app/bot-img');
        if (! is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        return static::toJpeg($src, $dir.'/b'.$b->id.'-'.substr(md5($b->image.filemtime($src)), 0, 8).'.jpg');
    }

    protected static function toJpeg(string $src, string $dest): ?string
    {
        if (is_file($dest) && filesize($dest) > 0) {
            return $dest;
        }
        $info = @getimagesize($src);
        try {
            $px = (int) ($info[0] ?? 0) * (int) ($info[1] ?? 0);
            $im = $px > 0 && $px <= 25_000_000 ? match ($info[2] ?? 0) {
                IMAGETYPE_JPEG => @imagecreatefromjpeg($src),
                IMAGETYPE_PNG => @imagecreatefrompng($src),
                IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($src) : null,
                IMAGETYPE_GIF => @imagecreatefromgif($src),
                default => null,
            } : null;
            if ($im) {
                $w = imagesx($im);
                $h = imagesy($im);
                $s = min(1, 1280 / max($w, $h));
                $out = imagecreatetruecolor(max(1, (int) round($w * $s)), max(1, (int) round($h * $s)));
                imagefill($out, 0, 0, imagecolorallocate($out, 255, 255, 255));
                imagecopyresampled($out, $im, 0, 0, 0, 0, imagesx($out), imagesy($out), $w, $h);
                $ok = @imagejpeg($out, $dest, 86);
                imagedestroy($im);
                imagedestroy($out);
                if ($ok) {
                    return $dest;
                }
            }
        } catch (Throwable) {
        }

        return ($info[2] ?? 0) === IMAGETYPE_JPEG ? $src : null;
    }

    /* ======================= محاسبه تغییرات ======================= */

    /** کالایی ذخیره شد: در اولین تماس بعدی ربات، تغییرات حساب می‌شود */
    public static function dirty(): void
    {
        if (static::ready()) {
            Cache::put('bothub.dirty', 1, 3600);
        }
    }

    /** مقایسه کالاهای هر کانال با پست‌های کانال و ساختن کارها (new / edit / delete / repost) */
    /**
     * $since: فقط کالاهایی که از این زمان تغییر کرده‌اند (سبک، پس از ذخیره کالا)؛ null = بررسی کامل
     * (در بررسی کامل هم فقط کالاهای عکس‌دار یا دارای پست خوانده می‌شوند)
     */
    public static function reconcile(BotProfile $pf, ?int $since = null): array
    {
        $n = ['new' => 0, 'edit' => 0, 'delete' => 0];
        if (! $pf->enabled || static::purging($pf)) {
            return $n; // در حال «پاک کردن کل کانال»: تا پایان حذف‌ها کار تازه‌ای ساخته نمی‌شود
        }
        $started = now()->timestamp;
        $posts = BotPost::query()->where('profile_id', $pf->id)->whereNotNull('product_id')->get()->keyBy('product_id');
        $seen = [];
        $q = static::scope($pf)->select('products.*');
        if ($since) {
            $q->where('products.updated_at', '>=', \Illuminate\Support\Carbon::createFromTimestamp($since - 15));
        } elseif (! $pf->text_fallback) {
            $ids = $posts->keys()->all();
            $q->where(fn ($w) => $w->where(fn ($i) => $i->whereNotNull('products.image')->where('products.image', '!=', ''))->when($ids, fn ($w2) => $w2->orWhereIn('products.id', $ids)));
        }
        $q->chunkById(300, function ($rows) use ($pf, $posts, &$seen, &$n) {
            foreach ($rows as $p) {
                $seen[$p->id] = true;
                $avail = static::available($p, $pf);
                $h = static::hash($p, $avail, $pf);
                $post = $posts->get($p->id);
                if (! $post) {
                    if ($avail && ($p->image || $pf->text_fallback)) {
                        BotPost::query()->create(['profile_id' => $pf->id, 'product_id' => $p->id, 'legacy_id' => $p->legacy_id, 'state' => $pf->approve_new ? 'hold' : 'new', 'avail' => true, 'hash' => null]);
                        $n['new']++;
                    }

                    continue;
                }
                static::judge($post, $pf, $avail, $h, (bool) $p->image, $n, $p->image ? static::imgSig($p, $pf) : null, static::code($p));
            }
        }, 'products.id', 'id');
        // کالاهایی که از محدوده کانال بیرون رفتند (حذف، غیرفعال یا خارج از مجموعه) = ناموجود
        foreach ($since ? [] : $posts as $pid => $post) {
            if (! isset($seen[$pid]) && $post->message_id && in_array($post->state, ['ok', 'failed'], true)) {
                $p = Product::query()->find($pid);
                if (! $p || $pf->on_unavailable === 'delete') {
                    $post->update(['state' => 'delete', 'attempts' => 0, 'next_try_at' => null]);
                    $n['delete']++;
                } elseif ($post->avail) {
                    static::judge($post, $pf, false, static::hash($p, false, $pf), (bool) $p->image, $n);
                } elseif (static::hasV2() && ! $post->unavail_at) {
                    $post->forceFill(['unavail_at' => now()])->save();
                }
            }
        }
        // «ناموجود بماند؛ اگر X روز موجود نشد حذف شود»
        if (! $since && static::hasV2() && $pf->on_unavailable === 'later') {
            $days = max(1, (int) ($pf->gone_days ?: 30));
            $n['delete'] += BotPost::query()->where('profile_id', $pf->id)->whereNotNull('message_id')->whereIn('state', ['ok', 'edit', 'failed'])
                ->whereNotNull('unavail_at')->where('unavail_at', '<=', now()->subDays($days))
                ->update(['state' => 'delete', 'attempts' => 0, 'next_try_at' => null, 'notice' => false]);
        }
        Cache::put('bothub.inc.'.$pf->id, $started, 86400);
        if (! $since) {
            Cache::put('bothub.rec.'.$pf->id, $started, 86400);
        }

        return $n;
    }

    protected static function judge(BotPost $post, BotProfile $pf, bool $avail, string $h, bool $hasImg, array &$n, ?string $img = null, ?string $code = null): void
    {
        if (static::hasV2()) {
            // از چه زمانی در سایت ناموجود است (برای حذف پس از چند روز)
            if (! $avail && ! $post->unavail_at) {
                $post->forceFill(['unavail_at' => now()])->save();
            } elseif ($avail && $post->unavail_at) {
                $post->forceFill(['unavail_at' => null])->save();
            }
        }
        if (in_array($post->state, ['new', 'delete', 'repost', 'hold'], true)) {
            return; // کار قبلی هنوز انجام نشده (یا منتظر تأیید است)
        }
        // عکس کالا عوض شد (مثلاً عکس تازه از آپلود گروهی): پست قبلی پاک و پست تازه با عکس جدید فرستاده می‌شود.
        // تغییر بارکد/نام/قیمت فقط متن همان پست را ویرایش می‌کند. پست‌های قدیمی بار اول فقط امضا می‌گیرند (ارسال انبوه نمی‌شود).
        if ($img && static::hasImgCol() && $post->message_id && in_array($post->state, ['ok', 'edit', 'failed'], true) && $post->kind !== 'text') {
            if ($post->img === null) {
                $post->forceFill(['img' => $img])->save();
            } elseif ($post->img !== $img && $avail) {
                $post->update(['state' => 'repost', 'attempts' => 0, 'next_try_at' => null, 'last_error' => null]);
                $n['new']++;

                return;
            }
        }
        // کد کالا عوض شد: پست قبلی از کانال حذف و (اگر موجود است) پست تازه با کد جدید فرستاده می‌شود.
        // پست‌های قبل از این نسخه بار اول فقط کد فعلی را می‌گیرند (ارسال انبوه نمی‌شود).
        if ($code !== null && static::hasV2() && $post->message_id && in_array($post->state, ['ok', 'edit', 'failed'], true)) {
            if ($post->code === null) {
                $post->forceFill(['code' => $code])->save();
            } elseif ($post->code !== $code) {
                $post->update(['state' => $avail ? 'repost' : 'delete', 'attempts' => 0, 'next_try_at' => null, 'last_error' => null, 'notice' => false]);
                $n[$avail ? 'new' : 'delete']++;

                return;
            }
        }
        if (in_array($post->state, ['gone', 'skip'], true) || ! $post->message_id) {
            // پست ندارد: اگر دوباره موجود شد، پست تازه
            if ($avail && ! $post->avail && ($hasImg || $pf->text_fallback)) {
                $post->update(['state' => $pf->approve_new && $post->state === 'skip' ? 'hold' : 'new', 'avail' => true, 'attempts' => 0, 'next_try_at' => null, 'last_error' => null]);
                $n['new']++;
            } elseif ($post->avail !== $avail) {
                $post->update(['avail' => $avail]);
            }

            return;
        }
        if ($post->hash === $h && $post->state === 'ok') {
            // پست بی‌عکسِ کالایی که حالا عکس دارد: یک بار با عکس دوباره فرستاده شود
            if ($post->kind === 'text' && $hasImg && $avail && ! $pf->text_fallback) {
                $post->update(['state' => 'repost', 'attempts' => 0, 'next_try_at' => null]);
                $n['new']++;
            }

            return;
        }
        if ($post->hash === $h) {
            if ($post->state === 'edit') {
                $post->update(['state' => 'ok']);
            }

            return;
        }
        if (! $avail && $pf->on_unavailable === 'delete') {
            $post->update(['state' => 'delete', 'avail' => false, 'attempts' => 0, 'next_try_at' => null]);
            $n['delete']++;

            return;
        }
        $notice = false; // دوباره موجود شد: فقط همان پست ویرایش و «🟢 موجود» می‌شود؛ پیام جداگانه (ریپلای) فرستاده نمی‌شود
        $post->update(['state' => 'edit', 'attempts' => 0, 'next_try_at' => null] + ($notice ? ['notice' => true] : []));
        $n['edit']++;
    }

    public static function reconcileAll(bool $force = false): void
    {
        if (! static::ready() || ! static::cfg()['on']) {
            return;
        }
        $dirty = (bool) Cache::pull('bothub.dirty');
        foreach (BotProfile::query()->where('enabled', true)->get() as $pf) {
            $full = (int) Cache::get('bothub.rec.'.$pf->id, 0);
            $inc = (int) Cache::get('bothub.inc.'.$pf->id, 0);
            try {
                if ($force || now()->timestamp - $full > 3600) {
                    static::reconcile($pf);                 // ساعتی یک بار کامل
                } elseif ($dirty || now()->timestamp - $inc > 300) {
                    static::reconcile($pf, $inc ?: now()->timestamp - 3600); // فقط کالاهای تغییرکرده
                }
            } catch (Throwable $e) {
                report($e);
                static::log('محاسبه تغییرات '.$pf->name.': '.$e->getMessage(), $pf->id);
            }
        }
    }

    /* ======================= پاک کردن کل کانال ======================= */

    /** کانال در حال «پاک کردن کل کانال» است؟ ['mode' => resend|delete, 'at', 'total'] */
    public static function purging(BotProfile $pf): ?array
    {
        if (! static::hasV2()) {
            return null;
        }
        $p = is_array($pf->purge) ? $pf->purge : (json_decode((string) $pf->purge, true) ?: []);

        return ! empty($p['mode']) ? $p : null;
    }

    /**
     * همه پست‌های این کانال (که سایت شناسه پیامشان را دارد) در صف حذف؛ صف کارهای عقب‌افتاده خالی می‌شود.
     * $resend: پس از پایان حذف‌ها، کالاهای موجود با متن و شکل فعلی از نو فرستاده می‌شوند. وگرنه کانال خاموش می‌شود.
     */
    public static function startPurge(BotProfile $pf, bool $resend, ?\App\Models\User $by = null): int
    {
        if (! static::hasV2()) {
            throw new \RuntimeException('اول به‌روزرسانی پایگاه داده انجام شود.');
        }

        return DB::transaction(function () use ($pf, $resend, $by) {
            $q = BotPost::query()->where('profile_id', $pf->id);
            $n = (clone $q)->whereNotNull('message_id')->where('message_id', '!=', '')
                ->update(['state' => 'delete', 'attempts' => 0, 'next_try_at' => null, 'lease_until' => null, 'notice' => false, 'last_error' => null]);
            // ردیف‌های بی‌پیام فقط صف یا سابقه‌اند: پاک می‌شوند تا پس از حذف‌ها همه کالاهای موجود از نو ساخته شوند
            (clone $q)->where(fn ($w) => $w->whereNull('message_id')->orWhere('message_id', ''))->delete();
            $pf->forceFill(['purge' => json_encode(['mode' => $resend ? 'resend' : 'delete', 'at' => now()->toIso8601String(), 'total' => $n, 'by' => $by?->id]), 'enabled' => true])->save();
            static::log('پاک کردن کل کانال '.$pf->name.' شروع شد: '.number_format($n).' پیام در صف حذف'.($resend ? '؛ سپس ارسال دوباره کالاهای موجود' : ''), $pf->id);

            return $n;
        });
    }

    /** پایان حذف‌ها: ارسال دوباره (کانال روشن می‌ماند) یا خاموش شدن کانال */
    public static function endPurge(BotProfile $pf): void
    {
        $p = static::purging($pf);
        if (! $p) {
            return;
        }
        $failed = BotPost::query()->where('profile_id', $pf->id)->where('state', 'failed')->whereNotNull('message_id')->count();
        $pf->forceFill(['purge' => null] + ($p['mode'] === 'delete' ? ['enabled' => false] : []))->save();
        Cache::forget('bothub.rec.'.$pf->id); // بررسی کامل در اولین فرصت ← ساخت پست‌های تازه
        static::log('پاک کردن کل کانال '.$pf->name.' تمام شد'.($failed ? '؛ '.number_format($failed).' پیام حذف نشد (خطاهای اخیر کانال را ببینید)' : '')
            .($p['mode'] === 'resend' ? '؛ ارسال دوباره کالاهای موجود شروع شد.' : '؛ کانال خاموش شد.'), $pf->id);
    }

    /** لغو پاک‌سازی: پیام‌هایی که هنوز حذف نشده‌اند در کانال می‌مانند و با متن فعلی ویرایش می‌شوند */
    public static function cancelPurge(BotProfile $pf): int
    {
        $n = BotPost::query()->where('profile_id', $pf->id)->where('state', 'delete')->whereNotNull('message_id')
            ->update(['state' => 'edit', 'attempts' => 0, 'next_try_at' => null, 'lease_until' => null]);
        $pf->forceFill(['purge' => null])->save();
        Cache::forget('bothub.rec.'.$pf->id);
        static::log('پاک کردن کل کانال '.$pf->name.' لغو شد؛ '.number_format($n).' پیام در کانال ماند.', $pf->id);

        return $n;
    }

    /** پیشرفت پاک‌سازی برای پنل */
    public static function purgeProgress(BotProfile $pf): ?array
    {
        $p = static::purging($pf);
        if (! $p) {
            return null;
        }
        $left = BotPost::query()->where('profile_id', $pf->id)->where('state', 'delete')->count();
        $total = max((int) ($p['total'] ?? 0), $left);
        $rate = max((int) $pf->per_hour, (int) ($pf->del_per_hour ?: 600));

        return ['mode' => $p['mode'], 'total' => $total, 'left' => $left, 'done' => $total - $left, 'hours' => $left ? round($left / max(1, $rate), 1) : 0];
    }

    /* ======================= کارها برای ربات ======================= */

    public static function quiet(BotProfile $pf): bool
    {
        if (! $pf->quiet_from || ! $pf->quiet_to) {
            return false;
        }
        $now = now('Asia/Tehran')->format('H:i');
        $a = substr($pf->quiet_from, 0, 5);
        $b = substr($pf->quiet_to, 0, 5);

        return $a <= $b ? ($now >= $a && $now < $b) : ($now >= $a || $now < $b);
    }

    /** $chats: کانال‌هایی که روی هاست ربات تعریف شده‌اند [key => true] */
    public static function jobs(array $chats, int $limit = 15): array
    {
        if (! static::cfg()['on']) {
            return ['on' => false, 'jobs' => []];
        }
        static::reconcileAll();
        $profiles = BotProfile::query()->where('enabled', true)->get()->keyBy('id');
        static::daily($profiles);
        // پیام‌های دستی/خلاصه/آزمایشی اول (ساعت خاموشی شامل پیام دستی نمی‌شود)
        $allProfiles = BotProfile::query()->get()->keyBy('id');
        $out = static::broadcastJobs($chats, $allProfiles, $limit);
        foreach ($profiles as $pf) {
            $purge = static::purging($pf);
            if ($purge && ! BotPost::query()->where('profile_id', $pf->id)->where('state', 'delete')->exists()) {
                static::endPurge($pf);
                $purge = null;
                if (! $pf->enabled) {
                    continue;
                }
            }
            // ساعت خاموشی شامل حذف‌های «پاک کردن کل کانال» نیست
            if (! isset($chats[$pf->key]) || (! $purge && static::quiet($pf))) {
                continue;
            }
            // سقف ارسال در ساعت (در پاک‌سازی: سرعت حذف جدا)
            $cap = $purge ? max((int) $pf->per_hour, (int) ($pf->del_per_hour ?: 600)) : (int) $pf->per_hour;
            $hour = (int) Cache::get('bothub.h.'.$pf->id.'.'.now()->format('YmdH'), 0);
            $room = max(0, $cap - $hour);
            $take = min($limit - count($out), $room);
            if ($take <= 0) {
                continue;
            }
            $rows = BotPost::query()->with('product')->where('profile_id', $pf->id)->whereIn('state', $purge ? ['delete'] : ['delete', 'edit', 'new', 'repost'])
                ->where(fn ($q) => $q->whereNull('next_try_at')->orWhere('next_try_at', '<=', now()))
                ->where(fn ($q) => $q->whereNull('lease_until')->orWhere('lease_until', '<', now()))
                ->orderByRaw("CASE state WHEN 'delete' THEN 0 WHEN 'edit' THEN 1 WHEN 'repost' THEN 2 ELSE 3 END")->orderBy('id')->limit($take)->get();
            foreach ($rows as $post) {
                $job = static::job($post, $pf);
                if ($job) {
                    $out[] = $job;
                    $post->forceFill(['lease_until' => now()->addMinutes(4)])->save();
                }
            }
            if (count($out) >= $limit) {
                break;
            }
        }

        return ['on' => true, 'jobs' => $out];
    }

    protected static function job(BotPost $post, BotProfile $pf): ?array
    {
        $base = ['id' => $post->id, 'chat' => $pf->key, 'op' => $post->state, 'mid' => $post->message_id, 'extra' => (array) $post->extra_ids, 'kind' => $post->kind];
        if ($post->state === 'delete') {
            if (! $post->message_id) {
                $post->update(['state' => 'gone', 'avail' => false]);

                return null;
            }

            return $base;
        }
        $p = $post->product;
        if (! $p) {
            $post->update(['state' => $post->message_id ? 'delete' : 'gone']);

            return null;
        }
        $avail = static::available($p, $pf);
        $imgs = in_array($post->state, ['new', 'repost'], true) ? static::images($p, $pf) : [];
        if ($pf->platform === 'rubika') {
            $imgs = array_slice($imgs, 0, 1); // روبیکا: تک‌عکس، بدون دکمه
        }
        if (in_array($post->state, ['new', 'repost'], true) && ! $imgs && ! $pf->text_fallback) {
            $post->update(['state' => $post->state === 'repost' ? 'ok' : 'skip', 'last_error' => 'کالا عکس ندارد']);

            return null;
        }
        $album = count($imgs) > 1 || ($post->state === 'edit' && $post->kind === 'album');
        if ($imgs) {
            Cache::put('bothub.img.'.$post->id, static::imgSig($p, $pf), 86400);
        }
        if (static::hasV2() && in_array($post->state, ['new', 'repost'], true)) {
            Cache::put('bothub.code.'.$post->id, static::code($p), 86400);
        }

        $notice = $post->state === 'edit' && $post->notice && $avail
            ? "🔔 دوباره موجود شد!\n".$p->name."\n".($p->discountPercent() ? '🔥 ' : '').'قیمت واحد: '.number_format((int) $p->unitPrice(Product::CARTON)).' تومان'
            : null;

        return $base + [
            'text' => static::text($p, $pf, $avail, $album, $post->state === 'edit' ? $post->last_price : null, $post->id),
            'notice' => $notice, 'price' => (int) $p->unitPrice(Product::CARTON),
            'images' => $imgs,
            'fallback' => (bool) $pf->text_fallback,
            'button' => $pf->button_text && ! $album && $pf->platform !== 'rubika' ? ['text' => $pf->button_text, 'url' => static::buttonUrl($p, $pf, $post->id)] : null,
            'hash' => static::hash($p, $avail, $pf), 'avail' => $avail,
        ];
    }

    /** نتیجه کارها از ربات */
    public static function results(array $results): array
    {
        $done = 0;
        foreach ($results as $r) {
            if (is_string($r['id'] ?? null) && str_starts_with($r['id'], 'b')) {
                static::broadcastResult($r);
                $done += ! empty($r['ok']) ? 1 : 0;

                continue;
            }
            $post = BotPost::query()->find((int) ($r['id'] ?? 0));
            if (! $post) {
                continue;
            }
            $pf = BotProfile::query()->find($post->profile_id);
            $op = (string) ($r['op'] ?? $post->state);
            $post->lease_until = null;
            if (! empty($r['ok'])) {
                $done++;
                $hk = 'bothub.h.'.$post->profile_id.'.'.now()->format('YmdH');
                Cache::put($hk, (int) Cache::get($hk, 0) + 1, 7200);
                static::count($post->profile_id, $op);
                if ($op === 'delete') {
                    $post->fill(['state' => 'gone', 'message_id' => null, 'extra_ids' => null, 'avail' => false, 'hash' => null]);
                } else {
                    if (in_array($op, ['new', 'repost'], true)) {
                        $post->fill(['message_id' => (string) ($r['mid'] ?? ''), 'extra_ids' => array_values(array_map('strval', (array) ($r['extra'] ?? []))) ?: null, 'sent_at' => now()]);
                        if (static::hasImgCol()) {
                            $post->img = Cache::pull('bothub.img.'.$post->id);
                        }
                        if (static::hasV2()) {
                            $post->code = Cache::pull('bothub.code.'.$post->id) ?? ($post->product ? static::code($post->product) : null);
                        }
                    }
                    $post->fill(['state' => 'ok', 'kind' => in_array($r['kind'] ?? null, ['photo', 'text', 'album'], true) ? $r['kind'] : $post->kind,
                        'hash' => (string) ($r['hash'] ?? $post->hash), 'avail' => (bool) ($r['avail'] ?? $post->avail),
                        'last_price' => isset($r['price']) ? (int) $r['price'] : $post->last_price, 'notice' => false]);
                }
                $post->fill(['attempts' => 0, 'last_error' => null, 'next_try_at' => null]);
                static::activity($post->profile_id, $op, $post->product?->name ?? ('کالای '.$post->legacy_id), ! empty($r['noticed']));
            } else {
                $err = mb_substr((string) ($r['error'] ?? 'نامشخص'), 0, 290);
                $gone = ! empty($r['gone']); // پیام در کانال دیگر نیست (دستی پاک شده)
                if ($gone && $op === 'delete') {
                    $post->fill(['state' => 'gone', 'message_id' => null, 'extra_ids' => null, 'avail' => false, 'hash' => null, 'last_error' => null]);
                } elseif ($gone && $op === 'edit') {
                    // پیام پیدا نشد: اگر موجود است دوباره فرستاده می‌شود
                    $post->fill(['state' => ($r['avail'] ?? $post->avail) ? 'repost' : 'gone', 'message_id' => null, 'last_error' => $err]);
                } else {
                    $post->attempts = min(250, $post->attempts + 1);
                    $wait = ! empty($r['retry_after']) ? (int) $r['retry_after'] : min(360, 2 ** min(8, $post->attempts));
                    $post->fill(['last_error' => $err, 'next_try_at' => now()->addMinutes($post->attempts >= 6 ? 120 : max(1, (int) ceil($wait / 60)))]);
                    if ($post->attempts >= 12 || ($op === 'delete' && $post->attempts >= 3 && $pf && static::purging($pf))) {
                        $post->state = 'failed'; // در پاک‌سازی کانال: حذفی که سه بار نشد کنار گذاشته می‌شود تا کار گیر نکند
                    }
                    static::count($post->profile_id, 'err');
                    static::log(($pf?->name ?? '').' — '.(BotPost::STATES[$op] ?? $op).' کالای '.($post->product?->name ?? $post->legacy_id).': '.$err, $post->profile_id);
                }
            }
            $post->save();
        }

        return ['done' => $done];
    }

    protected static function count(int $profile, string $k): void
    {
        $key = 'bothub.c.'.$profile.'.'.now('Asia/Tehran')->format('Ymd');
        $c = (array) Cache::get($key, []);
        $c[$k] = (int) ($c[$k] ?? 0) + 1;
        Cache::put($key, $c, 86400 * 9);
    }

    /** آخرین کارهای انجام‌شده (برای «آخرین وضعیت» در پنل) */
    protected static function activity(int $profile, string $op, string $name, bool $notice = false): void
    {
        $l = (array) Cache::get('bothub.act', []);
        array_unshift($l, ['t' => now()->timestamp, 'p' => $profile, 'o' => $op, 'n' => mb_substr($name, 0, 80), 'r' => $notice]);
        Cache::forever('bothub.act', array_slice($l, 0, 40));
    }

    public static function lastActs(): array
    {
        return (array) Cache::get('bothub.act', []);
    }

    /** آمار ۷ روز اخیر هر کانال: ارسال، ویرایش، حذف، خطا، کلیک، سفارش و مبلغ سفارش از کلیک کانال */
    public static function week(BotProfile $pf): array
    {
        $o = ['new' => 0, 'edit' => 0, 'delete' => 0, 'err' => 0, 'clicks' => 0, 'days' => []];
        for ($i = 6; $i >= 0; $i--) {
            $d = now('Asia/Tehran')->subDays($i)->format('Ymd');
            $c = (array) Cache::get('bothub.c.'.$pf->id.'.'.$d, []);
            $k = (int) Cache::get('bothub.k.'.$pf->id.'.'.$d, 0);
            foreach (['new', 'edit', 'delete', 'err'] as $x) {
                $o[$x] += (int) ($c[$x] ?? 0) + ($x === 'new' ? (int) ($c['repost'] ?? 0) : 0);
            }
            $o['clicks'] += $k;
            $o['days'][] = $k;
        }
        $orders = \App\Support\DbSchema::hasColumn('orders', 'bot_src')
            ? \App\Models\Order::query()->where('bot_src', $pf->id)->where('created_at', '>=', now()->subDays(7))->whereNotIn('status', ['failed', 'cancelled', 'pending_payment'])->selectRaw('COUNT(*) c, COALESCE(SUM(total),0) s')->first()
            : null;
        $o['orders'] = (int) ($orders->c ?? 0);
        $o['sales'] = (int) ($orders->s ?? 0);

        return $o;
    }

    /** پرکلیک‌ترین کالاهای کانال در ۷ روز */
    public static function topClicked(BotProfile $pf, int $n = 5): array
    {
        $sum = [];
        for ($i = 0; $i < 7; $i++) {
            foreach ((array) Cache::get('bothub.kp.'.$pf->id.'.'.now('Asia/Tehran')->subDays($i)->format('Ymd'), []) as $pid => $c) {
                $sum[$pid] = ($sum[$pid] ?? 0) + $c;
            }
        }
        arsort($sum);
        $sum = array_slice($sum, 0, $n, true);
        $names = Product::query()->whereIn('id', array_keys($sum))->pluck('name', 'id');

        return collect($sum)->map(fn ($c, $pid) => ['name' => $names[$pid] ?? '—', 'clicks' => $c])->values()->all();
    }

    /* ======================= پیام دستی و خلاصه روزانه ======================= */

    protected static function broadcastJobs(array $chats, $profiles, int $room): array
    {
        $out = [];
        $due = BotBroadcast::query()->where('status', 'queued')->where(fn ($q) => $q->whereNull('send_at')->orWhere('send_at', '<=', now()))->orderBy('id')->limit(5)->get();
        foreach ($due as $b) {
            $res = (array) $b->results;
            $lease = (array) Cache::get('bothub.bl.'.$b->id, []);
            foreach ((array) $b->profile_ids as $pid) {
                $pf = $profiles->get((int) $pid);
                if (! $pf || ! isset($chats[$pf->key]) || ! empty($res[$pid]['ok']) || (($lease[$pid] ?? 0) > now()->timestamp) || count($out) >= $room) {
                    continue;
                }
                $imgs = [];
                if ($b->image) {
                    $imgs[] = url(URL::temporarySignedRoute('bot.bimg', now()->addHours(2), ['b' => $b->id], false));
                }
                foreach (array_slice((array) $b->product_ids, 0, 10 - count($imgs)) as $prod) {
                    $imgs[] = url(URL::temporarySignedRoute('bot.img', now()->addHours(2), ['product' => (int) $prod, 'n' => 0], false));
                }
                $out[] = ['id' => 'b'.$b->id.'p'.$pf->id, 'chat' => $pf->key, 'op' => 'announce', 'text' => mb_substr((string) $b->text, 0, count($imgs) ? 1020 : 4000),
                    'images' => $imgs, 'fallback' => true, 'button' => $b->button_text && $b->button_url && count($imgs) < 2 ? ['text' => $b->button_text, 'url' => $b->button_url] : null];
                $lease[$pid] = now()->addMinutes(4)->timestamp;
            }
            Cache::put('bothub.bl.'.$b->id, $lease, 3600);
        }

        return $out;
    }

    protected static function broadcastResult(array $r): void
    {
        if (! preg_match('/^b(\d+)p(\d+)$/', (string) $r['id'], $m)) {
            return;
        }
        $b = BotBroadcast::query()->find((int) $m[1]);
        if (! $b) {
            return;
        }
        $res = (array) $b->results;
        $res[$m[2]] = ['ok' => ! empty($r['ok']), 'mid' => $r['mid'] ?? null, 'error' => ! empty($r['ok']) ? null : mb_substr((string) ($r['error'] ?? ''), 0, 200), 'at' => now()->timestamp,
            'tries' => (int) ($res[$m[2]]['tries'] ?? 0) + 1];
        $b->results = $res;
        $all = collect((array) $b->profile_ids)->every(fn ($pid) => ! empty($res[$pid]['ok']) || (int) ($res[$pid]['tries'] ?? 0) >= 5);
        if ($all) {
            $b->status = 'done';
        }
        $b->save();
        Cache::forget('bothub.bl.'.$b->id);
        if (! empty($r['ok'])) {
            static::activity((int) $m[2], 'announce', (string) ($b->title ?: BotBroadcast::KINDS[$b->kind] ?? 'پیام'));
        } else {
            static::log('پیام «'.($b->title ?: BotBroadcast::KINDS[$b->kind] ?? '').'»: '.($r['error'] ?? ''), (int) $m[2]);
        }
    }

    /** خلاصه روزانه «جدیدهای امروز» (آلبوم تا ۱۰ کالا) در ساعت تعیین‌شده */
    protected static function daily($profiles): void
    {
        $today = now('Asia/Tehran')->toDateString();
        foreach ($profiles as $pf) {
            if (! $pf->daily_at || (string) $pf->daily_done === $today || now('Asia/Tehran')->format('H:i') < substr($pf->daily_at, 0, 5)) {
                continue;
            }
            $pf->forceFill(['daily_done' => $today])->save();
            $posts = BotPost::query()->with('product')->where('profile_id', $pf->id)->where('state', 'ok')
                ->where('sent_at', '>=', now('Asia/Tehran')->startOfDay()->utc())->whereNotNull('product_id')->orderByDesc('sent_at')->limit(30)->get()
                ->filter(fn ($p) => $p->product && $p->product->image)->values();
            if ($posts->isEmpty()) {
                continue;
            }
            $lines = $posts->take(15)->map(fn ($p) => '▫️ '.$p->product->name.' — '.number_format((int) $p->product->unitPrice(Product::CARTON)).' ت')->implode("\n");
            BotBroadcast::query()->create([
                'kind' => 'daily', 'title' => 'جدیدهای امروز', 'profile_ids' => [$pf->id], 'product_ids' => $posts->take(10)->pluck('product_id')->all(),
                'text' => '🆕 جدیدهای امروز '.store_name().' ('.fa($posts->count()).' کالا)'."\n\n".$lines.($posts->count() > 15 ? "\n…" : '')."\n\n🛒 ".url('/'),
                'status' => 'queued',
            ]);
        }
    }

    /* ======================= هشدار قطعی ======================= */

    /** از کارهای دوره‌ای سایت (سبک: فقط خواندن حافظه موقت) */
    public static function health(): void
    {
        if (! static::ready() || ! static::cfg()['on'] || ! BotProfile::query()->where('enabled', true)->exists()) {
            return;
        }
        foreach (static::agents() as $id => $a) {
            if (empty($a['at'])) {
                continue;
            }
            $down = now()->timestamp - (int) $a['at'] > 600;
            $was = (bool) Cache::get('bothub.down.'.$id);
            if ($down && ! $was) {
                Cache::forever('bothub.down.'.$id, 1);
                static::alert('🔴 ربات «'.$a['label'].'» قطع است', 'بیش از ۱۰ دقیقه است برنامه روی این هاست به سایت وصل نشده. هاست و کرون آن را بررسی کنید.');
            } elseif (! $down && $was) {
                Cache::forget('bothub.down.'.$id);
                static::alert('🟢 ربات «'.$a['label'].'» دوباره وصل شد', 'ارسال‌ها از سر گرفته شد.');
            }
        }
        foreach (BotProfile::query()->where('enabled', true)->get() as $pf) {
            $err = (int) (static::today($pf->id)['err'] ?? 0);
            $k = 'bothub.erralert.'.$pf->id.'.'.now('Asia/Tehran')->format('Ymd');
            if ($err >= 20 && ! Cache::has($k)) {
                Cache::put($k, 1, 86400);
                static::alert('⚠️ خطاهای پشت سر هم در '.$pf->name, fa($err).' خطا امروز؛ پنل ← ربات بله ← خطاهای اخیر.');
            }
        }
    }

    protected static function alert(string $title, string $body): void
    {
        static::log($title.' — '.$body);
        try {
            $ids = \App\Models\User::query()->where('is_active', true)->whereIn('role', ['admin', 'staff'])->get()
                ->filter(fn ($u) => $u->isAdmin() || $u->hasPerm('marketing'))->pluck('id')->all();
            app(WebPush::class)->toUsers($ids, ['title' => $title, 'body' => $body, 'url' => url('/admin/channel-bots'), 'tag' => 'bothub']);
        } catch (Throwable $e) {
            report($e);
        }
    }

    public static function today(int $profile): array
    {
        return (array) Cache::get('bothub.c.'.$profile.'.'.now('Asia/Tehran')->format('Ymd'), []);
    }

    /* ======================= ورود ربات‌های قبلی ======================= */

    /**
     * ربات قدیمی روی هاست ربات (پوشه، کانال، آدرس JSON، متن پایین پست، پیام‌های ارسال‌شده) ← کانال در پنل
     * $old: {key, name, chat_id, api_url, footer, promo, quiet_from, quiet_to, album, posts: [[legacy_id, message_id], ...]}
     */
    public static function importOld(array $old): array
    {
        $key = preg_replace('/[^a-z0-9_]/', '', strtolower((string) ($old['key'] ?? '')));
        abort_if($key === '', 422);
        $pf = BotProfile::query()->firstOrNew(['key' => $key]);
        $new = ! $pf->exists;
        if ($new) {
            $api = (string) ($old['api_url'] ?? '');
            $coll = null;
            if (preg_match('/what=([A-Za-z0-9_]+).*?id=(\d+)/', $api, $m)) {
                $coll = ProductCollection::query()->where('legacy_key', $m[1].':'.$m[2])->first();
            }
            $footer = trim((string) ($old['footer'] ?? ''));
            $promo = trim((string) ($old['promo'] ?? ''));
            $footer = preg_replace('#^.*aziziplast\.apk.*$\n?#mu', '', $footer); // لینک APK سایت قبلی دیگر نیست
            $pf->fill([
                'name' => (string) ($old['name'] ?? ('کانال '.$key)), 'platform' => in_array($old['platform'] ?? '', ['bale', 'telegram', 'rubika'], true) ? $old['platform'] : 'bale', 'chat_id' => (string) ($old['chat_id'] ?? ''),
                'source' => $coll ? 'collection' : 'all', 'collection_id' => $coll?->id, 'only_wholesale' => (bool) ($old['wholesale'] ?? true),
                'on_unavailable' => 'mark', 'max_images' => ! empty($old['album']) && ($old['platform'] ?? 'bale') !== 'rubika' ? 10 : 1, 'text_fallback' => false,
                'template' => static::defaultTemplate(trim($footer."\n\n".$promo)),
                'button_text' => ! empty($old['button']) ? 'مشاهده بیشتر' : null, 'button_url' => ! empty($old['button']) ? '{link}' : null,
                'quiet_from' => ! empty($old['quiet_from']) ? substr((string) $old['quiet_from'], 0, 5) : null,
                'quiet_to' => ! empty($old['quiet_to']) ? substr((string) $old['quiet_to'], 0, 5) : null,
                'per_hour' => 120, 'enabled' => true,
            ]);
            $pf->save();
        }
        // پیام‌های قبلی: تا قیمت/موجودی عوض نشده، دست نمی‌خورند؛ با تغییر، همان پست ویرایش می‌شود
        $rows = array_values(array_filter((array) ($old['posts'] ?? []), fn ($r) => is_array($r) && count($r) >= 2 && (int) $r[0] > 0 && (string) $r[1] !== ''));
        $byLegacy = [];
        foreach (array_chunk(array_map(fn ($r) => (int) $r[0], $rows), 500) as $ch) {
            foreach (Product::query()->whereIn('legacy_id', $ch)->get() as $p) {
                $byLegacy[(int) $p->legacy_id] = $p;
            }
        }
        @set_time_limit(300);
        $made = 0;
        $matched = 0;
        $have = BotPost::query()->where('profile_id', $pf->id)->get(['product_id', 'legacy_id']);
        $hasProduct = array_fill_keys($have->pluck('product_id')->filter()->all(), true);
        $hasLegacy = array_fill_keys($have->whereNull('product_id')->pluck('legacy_id')->filter()->all(), true);
        $batch = [];
        $now = now();
        foreach ($rows as $r) {
            $lid = (int) $r[0];
            $p = $byLegacy[$lid] ?? null;
            if ($p ? isset($hasProduct[$p->id]) : isset($hasLegacy[$lid])) {
                continue;
            }
            $p ? $hasProduct[$p->id] = true : $hasLegacy[$lid] = true;
            $avail = $p ? static::available($p, $pf) : false;
            $batch[] = ['profile_id' => $pf->id, 'product_id' => $p?->id, 'legacy_id' => $lid, 'message_id' => mb_substr((string) $r[1], 0, 40), 'kind' => '?',
                'hash' => $p ? static::hash($p, $avail) : null, 'avail' => $avail, 'state' => 'ok', 'attempts' => 0, 'created_at' => $now, 'updated_at' => $now];
            $made++;
            $matched += $p ? 1 : 0;
        }
        foreach (array_chunk($batch, 500) as $ch) {
            BotPost::query()->insert($ch);
        }
        $pf->forceFill(['imported_at' => now()])->save();
        static::log('ربات قبلی «'.$pf->name.'» وصل شد: '.fa($made).' پست قبلی ثبت شد ('.fa($matched).' با کالای سایت جور شد).', $pf->id);

        return ['profile' => $pf->id, 'new' => $new, 'posts' => $made, 'matched' => $matched];
    }

    /* ======================= بسته نصب ======================= */

    /** زیپ برنامه ربات با کلید تازه (کلید قبلی باطل می‌شود) */
    public static function bundle(string $label = 'هاست ربات', ?string $replace = null): string
    {
        $key = static::newKey($label, $replace);
        $zipPath = storage_path('app/botagent-'.Str::random(8).'.zip');
        $z = new \ZipArchive();
        $z->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
        $z->addFile(resource_path('botagent/agent.py'), 'botagent/agent.py');
        $z->addFile(resource_path('botagent/README.txt'), 'botagent/README.txt');
        $env = "# تنظیمات ربات — این فایل را به کسی ندهید\n"
            ."SITE_URL=".rtrim(config('app.url'), '/')."\n"
            ."AGENT_KEY=".$key."\n"
            ."# کانال‌ها (اگر خالی باشد، در اولین اجرا از ربات‌های قبلی همین هاست خوانده می‌شود):\n"
            ."#   BALE_<نام>=شناسه کانال|توکن ربات بله\n"
            ."#   TG_<نام>=شناسه کانال|توکن ربات تلگرام\n"
            ."#   RUBIKA_<نام>=شناسه کانال روبیکا|مسیر فایل نشست rubpy (بدون .rp)\n"
            ."MIGRATE_OLD=1\n";
        $z->addFromString('botagent/settings.env', $env);
        $z->close();

        return $zipPath;
    }
}
