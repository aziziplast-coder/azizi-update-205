<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class Checkout
{
    public const CONFIRM_TEXT = "آیا مطمئن هستید که می‌خواهید سفارش را ثبت کنید؟ تغییراتی ندارید؟\nبعد از ثبت سفارش، بیعانه در گفتگو برای شما صادر می‌شود.\nبه‌خاطر بسته‌بندی کالاها، بعد از ثبت سفارش امکان حذف اقلام وجود ندارد؛ پس هر تغییری دارید (کم و زیاد کردن یا افزودن کالای دیگر) همین حالا انجام دهید.";

    /** متن پرسش «مطمئنید؟» پیش از ثبت سفارش (null = خاموش) */
    public static function confirmText(bool $raw = false): ?string
    {
        $t = trim((string) setting('order_confirm_text')) ?: self::CONFIRM_TEXT;
        if ($raw) {
            return $t;
        }

        return setting('order_confirm', true) ? $t : null;
    }

    /** اصلاح سبد که باید بعد از برگشت تراکنش اعمال شود */
    protected ?array $cartFix = null;

    protected function transact(Cart $cart, callable $fn)
    {
        $this->cartFix = null;
        try {
            return DB::transaction($fn);
        } catch (ValidationException $e) {
            if ($this->cartFix) {
                $cart->set(...$this->cartFix);
            }
            throw $e;
        }
    }

    /* ---------------- ارسال ---------------- */

    public static function shippingMethods(): array
    {
        $out = [];
        foreach ((array) setting('shipping_methods', []) as $m) {
            if (empty($m['enabled']) || empty($m['title'])) {
                continue;
            }
            $m['id'] = $m['id'] ?? md5($m['title']);
            $m['cost'] = (int) to_int($m['cost'] ?? 0);
            $m['free_above'] = (int) to_int($m['free_above'] ?? 0);
            $m['collect'] = ! empty($m['collect']);
            $m['freight'] = ! empty($m['freight']);
            $m['inner_type'] = ($m['inner_type'] ?? 'fixed') === 'percent' ? 'percent' : 'fixed';
            $m['inner_amount'] = (float) en_digits((string) ($m['inner_amount'] ?? 0));
            $m['inner_max'] = (int) to_int($m['inner_max'] ?? 0);
            $m['inner_title'] = trim((string) ($m['inner_title'] ?? '')) ?: 'ارسال تا باربری';
            $out[$m['id']] = $m;
        }

        return $out;
    }

    public static function shippingMethod(?string $id): ?array
    {
        $all = static::shippingMethods();
        if ($id && isset($all[$id])) {
            return $all[$id];
        }

        return null;
    }

    public static function shippingCost(array $method, int $itemsTotal): int
    {
        if (($method['free_above'] ?? 0) > 0 && $itemsTotal >= $method['free_above']) {
            return 0;
        }
        if (! empty($method['collect'])) {
            return static::innerFee($method, $itemsTotal);
        }

        return (int) $method['cost'] + static::innerFee($method, $itemsTotal);
    }

    /** هزینه حمل درون‌شهری تا باربری (درصدی از ارزش بار یا مبلغ ثابت) که فروشگاه دریافت می‌کند */
    public static function innerFee(array $method, int $itemsTotal): int
    {
        if (empty($method['freight']) || ($method['inner_amount'] ?? 0) <= 0) {
            return 0;
        }
        $fee = ($method['inner_type'] ?? 'fixed') === 'percent'
            ? (int) round($itemsTotal * $method['inner_amount'] / 100)
            : (int) round($method['inner_amount']);
        if (($method['inner_max'] ?? 0) > 0) {
            $fee = min($fee, (int) $method['inner_max']);
        }

        return max(0, $fee);
    }

    /** متن هزینه ارسال برای نمایش */
    public static function shippingText(array $method, int $itemsTotal, bool $freeByCoupon = false): string
    {
        $cost = $freeByCoupon ? 0 : static::shippingCost($method, $itemsTotal);
        if (! empty($method['collect'])) {
            return $cost > 0 ? money($cost).' + کرایه باربری پس‌کرایه' : 'پس‌کرایه';
        }
        if ($freeByCoupon) {
            return 'رایگان (کد تخفیف)';
        }

        return $cost ? money($cost) : '—'; // بدون برچسب «رایگان»
    }

    /* ---------------- پرداخت ---------------- */

    public static function paymentMethods(): array
    {
        $out = [];
        $g = (array) setting('pay_gateway');
        if (! empty($g['enabled']) && ! empty($g['merchant'])) {
            $out['gateway'] = ['id' => 'gateway', 'title' => $g['title'] ?? 'پرداخت آنلاین', 'desc' => $g['desc'] ?? ''];
        }
        $c = (array) setting('pay_card');
        if (! empty($c['enabled'])) {
            $out['card'] = ['id' => 'card', 'title' => $c['title'] ?? 'کارت به کارت', 'desc' => $c['desc'] ?? '', 'card' => $c];
        }
        $o = (array) setting('pay_offline');
        if (! empty($o['enabled'])) {
            $opts = array_values(array_filter(array_map('trim', (array) ($o['options'] ?? []))));
            $out['offline'] = ['id' => 'offline', 'title' => $o['title'] ?? 'پرداخت در محل', 'desc' => $o['desc'] ?? '', 'options' => $opts];
        }
        $ch = Cheques::config();
        if ($ch['enabled'] && Cheques::plans()) {
            $out['cheque'] = ['id' => 'cheque', 'title' => ($ch['title'] ?? '') ?: 'خرید چکی', 'desc' => $ch['desc'] ?? ''];
        }

        return $out;
    }

    /* ---------------- هزینه‌های جانبی ---------------- */

    /** @return array<int, array{title: string, amount: int}> */
    public static function fees(int $itemsTotal, int $cartons): array
    {
        $out = [];
        foreach ((array) setting('fees', []) as $f) {
            $title = trim((string) ($f['title'] ?? ''));
            $amount = (float) en_digits((string) ($f['amount'] ?? 0));
            $below = (int) to_int($f['below'] ?? 0);
            if ($title === '' || $amount <= 0 || $itemsTotal <= 0) {
                continue;
            }
            if ($below > 0 && $itemsTotal >= $below) {
                continue;
            }
            $value = match ($f['type'] ?? 'fixed') {
                'percent' => (int) round($itemsTotal * $amount / 100),
                'carton' => (int) round($cartons * $amount),
                default => (int) round($amount),
            };
            if ($value > 0) {
                $out[] = ['title' => $title, 'amount' => $value];
            }
        }

        return $out;
    }

    /* ---------------- ثبت سفارش ---------------- */

    /** ثبت سفارش از فرم تسویه (سایت و اپ با همین قوانین) */
    public function placeFromRequest(\Illuminate\Http\Request $request, Cart $cart): Order
    {
        $request->merge([
            'postal_code' => en_digits($request->input('postal_code')),
            'pay_ref' => en_digits($request->input('pay_ref')),
            'messenger' => en_digits($request->input('messenger')),
        ]);
        $data = $request->validate(\App\Support\CheckoutFields::rules() + [
            'shipping' => 'required|string',
            'payment' => 'required|string',
            'offline_option' => 'nullable|string|max:100',
            'pay_ref' => 'nullable|string|max:60',
            'terms' => 'nullable|boolean',
            'freight_name' => 'nullable|string|max:150',
            'freight_any' => 'nullable|boolean',
            'messenger' => 'nullable|string|max:20',
        ], [], \App\Support\CheckoutFields::attributes());
        $data['name'] = trim((string) ($data['name'] ?? '')) ?: ($request->user()->name ?: $request->user()->mobile);
        $data['custom_fields'] = \App\Support\CheckoutFields::collect((array) $request->input('xf', []));
        unset($data['xf']);

        if ($data['payment'] === 'cheque') {
            $data['cheque'] = Cheques::fromRequest($request, $request->user(), (int) $cart->totals($data['shipping'])['total']);
        }

        return $this->place($request->user(), $data, $cart);
    }

    /** وضعیت‌هایی که سفارش «باز» حساب می‌شود */
    public static function openStatuses(): array
    {
        $s = (array) setting('open_statuses', ['on_hold', 'processing', 'settling', 'to_freight']);

        return $s ?: ['on_hold', 'processing', 'settling', 'to_freight'];
    }

    /**
     * تا مشتری سفارش باز دارد، سفارش جدید نمی‌تواند ثبت کند — مگر اپراتور برای همان سفارش باز اجازه داده باشد.
     * خروجی: سفارش بازی که جلوی ثبت را گرفته (null = آزاد)
     */
    public static function openBlock(?User $user): ?Order
    {
        if (! $user || ! setting('one_open_order', true) || ! \App\Support\DbSchema::hasColumn('orders', 'reorder_ok')) {
            return null;
        }
        $open = Order::query()->where('user_id', $user->id)->whereIn('status', static::openStatuses())->latest('id')->get(['id', 'number', 'status', 'reorder_ok']);
        if ($open->isEmpty() || $open->contains(fn ($o) => $o->reorder_ok)) {
            return null;
        }

        return $open->first();
    }

    public static function openBlockMsg(Order $o): string
    {
        return 'سفارش شماره '.fa($o->number).' شما هنوز باز است ('.$o->statusLabel().'). تا تکمیل آن، ثبت سفارش جدید ممکن نیست. '
            .'اگر کالای دیگری لازم دارید، در گفتگوی همان سفارش به کارشناس بگویید تا به سفارشتان اضافه کند یا اجازه سفارش جدید بدهد.';
    }

    public function place(User $user, array $data, Cart $cart): Order
    {
        if ($blk = static::openBlock($user)) {
            throw ValidationException::withMessages(['cart' => static::openBlockMsg($blk)]);
        }
        $ship = static::shippingMethod($data['shipping'] ?? null);
        $pays = static::paymentMethods();
        $pay = $pays[$data['payment'] ?? ''] ?? null;
        if (! $ship) {
            throw ValidationException::withMessages(['shipping' => 'شیوه ارسال را انتخاب کنید.']);
        }
        if (! $pay) {
            throw ValidationException::withMessages(['payment' => 'شیوه تسویه را انتخاب کنید.']);
        }
        $lines = $cart->lines();
        if ($lines->isEmpty()) {
            throw ValidationException::withMessages(['cart' => 'سبد خرید خالی است.']);
        }
        $min = Cart::unlimited() ? 0 : (int) setting('min_order', 0);
        if ($min > 0 && $cart->itemsTotal() < $min) {
            throw ValidationException::withMessages(['cart' => 'مجموع کل مبلغ سفارش شما باید بالای '.money($min, true).' باشد.']);
        }
        if (setting('terms_enabled', false) && empty($data['terms'])) {
            throw ValidationException::withMessages(['terms' => 'برای ثبت سفارش باید قوانین و شرایط خرید را بپذیرید.']);
        }
        $coupon = $cart->coupon();
        if ($coupon && ! $coupon['ok']) {
            Coupons::forget();
            throw ValidationException::withMessages(['cart' => $coupon['msg'].' کد تخفیف از سبد برداشته شد.']);
        }
        if ($pay['id'] === 'cheque') {
            $av = Cheques::availability($user, $cart->itemsTotal());
            if (! $av['ok']) {
                throw ValidationException::withMessages(['payment' => $av['reason'] ?: 'خرید چکی برای این سفارش ممکن نیست.']);
            }
            if (empty($data['cheque'])) {
                throw ValidationException::withMessages(['cheque_plan' => 'شرایط پرداخت چکی را انتخاب کنید.']);
            }
        }
        $freight = null;
        if (! empty($ship['freight'])) {
            $freight = ! empty($data['freight_any']) ? 'هر باربری که به مقصد بار دارد' : trim((string) ($data['freight_name'] ?? ''));
            if ($freight === '') {
                throw ValidationException::withMessages(['freight_name' => 'نام باربری را بنویسید یا گزینه «هر باربری که به مقصد بار دارد» را بزنید.']);
            }
        }
        $messenger = null;
        $msgCfg = (array) setting('messenger', []);
        if (! empty($msgCfg['enabled'])) {
            $messenger = mobile((string) ($data['messenger'] ?? '')) ?: null;
            if (! $messenger && ! empty($msgCfg['required'])) {
                throw ValidationException::withMessages(['messenger' => 'شماره موبایل '.(($msgCfg['label'] ?? '') ?: 'پیام‌رسان').' را درست وارد کنید.']);
            }
        }
        $review = $pay['id'] === 'cheque' && Cheques::needsReview($user);

        $order = $this->transact($cart, function () use ($user, $data, $cart, $lines, $ship, $pay, $coupon, $freight, $messenger, $review) {
            [$items, $itemsTotal, $discount, $cartons] = $this->buildItems($lines, $cart);

            $couponOff = $coupon ? min($itemsTotal, (int) $coupon['discount']) : 0;
            $shipCost = $coupon && $coupon['free_shipping'] ? 0 : static::shippingCost($ship, $itemsTotal);
            $fees = static::fees($itemsTotal, $cartons);
            $feesTotal = array_sum(array_column($fees, 'amount'));
            $payTitle = $pay['title'];
            if ($pay['id'] === 'offline' && ! empty($data['offline_option']) && in_array($data['offline_option'], $pay['options'] ?? [], true)) {
                $payTitle .= ' — '.$data['offline_option'];
            }
            $isGateway = $pay['id'] === 'gateway';
            $grand = $itemsTotal - $couponOff + $shipCost + $feesTotal;
            $cheque = null;
            if ($pay['id'] === 'cheque') {
                $cheque = Cheques::recalc($data['cheque'], $grand);
                $payTitle .= ' — '.$cheque['plan'];
            }

            $order = Order::create([
                'user_id' => $user->id,
                'status' => $isGateway ? 'pending_payment' : 'on_hold',
                'customer_name' => $data['name'],
                'mobile' => $user->mobile,
                'company' => $data['company'] ?? null,
                'province' => $data['province'] ?? null,
                'city' => $data['city'] ?? null,
                'address' => $data['address'] ?? null,
                'postal_code' => $data['postal_code'] ?? null,
                'note' => $data['note'] ?? null,
                'custom_fields' => ($data['custom_fields'] ?? []) ?: null,
                'shipping_method' => $ship['id'],
                'shipping_title' => $ship['title'],
                'shipping_cost' => $shipCost,
                'shipping_collect' => (bool) $ship['collect'],
                'payment_method' => $pay['id'],
                'payment_title' => $payTitle,
                'payment_ref' => $pay['id'] === 'card' ? (trim(en_digits((string) ($data['pay_ref'] ?? ''))) ?: null) : null,
                'items_total' => $itemsTotal,
                'discount_total' => $discount,
                'coupon_code' => $coupon ? $coupon['coupon']->code : null,
                'coupon_discount' => $couponOff,
                'terms_accepted_at' => ! empty($data['terms']) ? now() : null,
                'fees' => $fees,
                'fees_total' => $feesTotal,
                'total' => $grand,
                'stock_reduced' => true,
                'alerted_at' => $isGateway || $review ? null : now(),
                'ip' => request()->ip(),
                'freight_name' => $freight,
                'messenger' => $messenger,
                'review_status' => $review ? 'pending' : null,
            ]);
            static::insertItems($order, $items);
            if ($cheque) {
                $order->cheque = Cheques::storeFiles($order, $cheque);
                $order->saveQuietly();
            }
            $order->log('سفارش ثبت شد ('.$payTitle.')'.($review ? ' — در صف بررسی چک' : ''), $user->id);
            if ($coupon) {
                Coupons::record($coupon['coupon'], $order, $couponOff);
                $order->log('کد تخفیف '.$coupon['coupon']->code.': '.money($couponOff, true), $user->id);
            }

            $user->fill(array_filter([
                'name' => $user->name ?: $data['name'],
                'company' => $data['company'] ?? null,
                'province' => $data['province'] ?? null,
                'city' => $data['city'] ?? null,
                'address' => $data['address'] ?? null,
                'postal_code' => $data['postal_code'] ?? null,
                'messenger' => $messenger,
            ], fn ($v) => $v !== null && $v !== ''))->save();

            return $order;
        });

        $cart->close($order->id);
        Coupons::forget();
        // اجازه «سفارش جدید» یک‌بار مصرف است: با ثبت این سفارش بسته می‌شود
        if (\App\Support\DbSchema::hasColumn('orders', 'reorder_ok')) {
            foreach (Order::query()->where('user_id', $user->id)->where('id', '!=', $order->id)->where('reorder_ok', true)->get() as $prev) {
                $prev->forceFill(['reorder_ok' => null])->saveQuietly();
                $prev->log('اجازه سفارش جدید استفاده شد (سفارش '.fa($order->number).' ثبت شد) و دوباره بسته شد');
            }
        }
        Remit::welcome($order->refresh());
        if ($order->status !== 'pending_payment') {
            app(Sms::class)->newOrder($order);
            if (! $order->review_status) {
                app(WebPush::class)->newOrder($order);
            }
        }

        return $order->fresh(['items']);
    }

    /** ثبت تغییرات مشتری روی سفارشی که هنوز در مرحله اول است */
    public function amend(Order $order, Cart $cart, bool $auto = false): Order
    {
        if (! $auto && ! $order->customerCanEdit()) {
            throw ValidationException::withMessages(['cart' => 'این سفارش به دست کارشناس رسیده و دیگر قابل تغییر نیست؛ برای تغییر با فروشگاه تماس بگیرید.']);
        }
        $lines = $cart->lines();
        if ($lines->isEmpty()) {
            throw ValidationException::withMessages(['cart' => 'سبد خالی است. برای لغو کامل سفارش با فروشگاه تماس بگیرید.']);
        }
        $min = Cart::unlimited() ? 0 : (int) setting('min_order', 0);
        if ($min > 0 && $cart->itemsTotal() < $min) {
            throw ValidationException::withMessages(['cart' => 'مجموع کل مبلغ سفارش شما باید بالای '.money($min, true).' باشد.']);
        }
        $before = $order->items()->count();
        $beforeTotal = (int) $order->total;
        $beforeNames = $order->items()->whereNotNull('product_id')->pluck('name', 'product_id')->all();

        $this->transact($cart, function () use ($order, $cart, $lines) {
            $order->load('items');
            $order->adjustStock(false);
            $cart->ignoreReserved = true;
            [$items, $itemsTotal, $discount, $cartons] = $this->buildItems($lines, $cart);
            $order->items()->delete();
            $order->items()->createMany($items);

            $couponOff = min($itemsTotal, (int) $order->coupon_discount);
            $ship = static::shippingMethod($order->shipping_method);
            $shipCost = $ship ? (($order->coupon_code && (int) $order->shipping_cost === 0 && ! $ship['collect']) ? 0 : static::shippingCost($ship, $itemsTotal)) : (int) $order->shipping_cost;
            $fees = static::fees($itemsTotal, $cartons);
            $feesTotal = array_sum(array_column($fees, 'amount'));
            $grand = $itemsTotal - $couponOff + $shipCost + $feesTotal;

            $order->fill([
                'items_total' => $itemsTotal,
                'discount_total' => $discount,
                'coupon_discount' => $couponOff,
                'shipping_cost' => $shipCost,
                'fees' => $fees,
                'fees_total' => $feesTotal,
                'total' => $grand,
                'stock_reduced' => true,
                'customer_edited_at' => now(),
            ] + (\App\Support\DbSchema::hasColumn('orders', 'placed_total') ? ['placed_total' => $grand] : []) + [
                'alerted_at' => $order->review_status === 'pending' ? $order->alerted_at : now(),
            ]);
            if ($order->cheque) {
                $order->cheque = Cheques::recalc($order->cheque, $grand, $order->created_at);
            }
            $order->save();
        });

        $order->refresh();
        $gone = array_diff_key($beforeNames, $order->items()->whereNotNull('product_id')->pluck('name', 'product_id')->all());
        $order->log('مشتری اقلام سفارش را تغییر داد: '.fa($before).' قلم ← '.fa($order->items()->count()).' قلم، مبلغ '.money($beforeTotal).' ← '.money($order->total).' تومان'
            .($gone ? ' — حذف‌شده‌ها: '.implode('، ', array_slice($gone, 0, 12)).(count($gone) > 12 ? ' و '.fa(count($gone) - 12).' قلم دیگر' : '') : ''), $order->user_id);
        $cart->close($order->id);
        // تغییرات پیش از بیعانه ثبت شد ← بیعانه با مبلغ تازه صادر می‌شود
        if (in_array($order->deposit_ask, ['ask', 'edit', 'late'], true)) {
            Remit::depositGo($order, $auto ? 'زمان ویرایش تمام شد و سبد مشتری خودکار ثبت شد' : 'مشتری تغییرات فاکتور را ثبت کرد');
            OrderWindows::editDone($order, true, $auto);
        }

        return $order;
    }

    /**
     * تبدیل سبد رها شده به سفارش توسط مدیر — بدون محدودیت حداقل خرید و سقف تعداد
     */
    public function fromAbandoned(\App\Models\CartRecord $rec, array $data): Order
    {
        $user = $rec->user;
        if (! $user) {
            $m = mobile((string) ($data['mobile'] ?? ''));
            if (! $m) {
                throw ValidationException::withMessages(['mobile' => 'شماره موبایل مشتری را وارد کنید.']);
            }
            $user = User::query()->firstOrCreate(['mobile' => $m], ['name' => $data['name'] ?? null, 'role' => 'customer', 'is_active' => true]);
        }
        if (! $user->isVerified()) {
            $user->forceFill(['mobile_verified_at' => now(), 'name' => $user->name ?: ($data['name'] ?? null)])->save();
        }
        $ship = static::shippingMethod($data['shipping'] ?? null);
        $pays = static::paymentMethods();
        $pay = $pays[$data['payment'] ?? ''] ?? ['id' => 'offline', 'title' => 'هماهنگی با فروشگاه'];
        $info = (array) $rec->info;

        return DB::transaction(function () use ($rec, $data, $user, $ship, $pay, $info) {
            $items = [];
            $itemsTotal = 0;
            $discount = 0;
            $cartons = 0;
            foreach ((array) $rec->items as $key => $units) {
                [$id, $mode] = array_pad(explode(':', (string) $key), 2, Product::CARTON);
                $p = Product::query()->lockForUpdate()->find((int) $id);
                $units = (int) $units;
                if (! $p || $units <= 0) {
                    continue;
                }
                $unit = $p->unitPrice($mode);
                $compare = ($mode === Product::CARTON && $p->compare_price > $unit) ? $p->compare_price : null;
                $imode = $p->orderMode($mode);
                $items[] = ['product_id' => $p->id, 'name' => $p->name, 'barcode' => $p->barcode, 'image' => $p->image, 'mode' => $imode, 'units' => $units,
                    'per_carton' => $p->per_carton, 'unit_price' => $unit, 'compare_price' => $compare, 'total' => $unit * $units, 'warehouse_id' => $p->warehouseFor($imode)];
                $itemsTotal += $unit * $units;
                $discount += $compare ? ($compare - $unit) * $units : 0;
                $cartons += $mode === Product::CARTON ? intdiv($units, max(1, $p->per_carton)) : 0;
                $col = $mode === Product::RETAIL ? 'retail_stock' : 'stock';
                if ($p->{$col} !== null && Product::counts()) {
                    $p->{$col} -= $units;
                }
                $p->sales_count++;
                $p->saveQuietly();
            }
            if (! $items) {
                throw ValidationException::withMessages(['items' => 'کالای معتبری در این سبد نیست.']);
            }
            $shipCost = $ship ? static::shippingCost($ship, $itemsTotal) : 0;
            $fees = static::fees($itemsTotal, $cartons);
            $feesTotal = array_sum(array_column($fees, 'amount'));
            $order = Order::create([
                'user_id' => $user->id,
                'status' => $data['status'] ?? 'on_hold',
                'customer_name' => ($data['name'] ?? '') ?: (($info['name'] ?? '') ?: ($user->name ?: $user->mobile)),
                'mobile' => $user->mobile,
                'company' => $info['company'] ?? $user->company,
                'province' => $info['province'] ?? $user->province,
                'city' => $info['city'] ?? $user->city,
                'address' => $user->address,
                'postal_code' => $user->postal_code,
                'note' => $data['note'] ?? null,
                'shipping_method' => $ship['id'] ?? null,
                'shipping_title' => $ship['title'] ?? 'هماهنگی تلفنی',
                'shipping_cost' => $shipCost,
                'shipping_collect' => (bool) ($ship['collect'] ?? false),
                'payment_method' => $pay['id'],
                'payment_title' => $pay['title'],
                'items_total' => $itemsTotal,
                'discount_total' => $discount,
                'fees' => $fees,
                'fees_total' => $feesTotal,
                'total' => $itemsTotal + $shipCost + $feesTotal,
                'stock_reduced' => true,
                'alerted_at' => now(),
                'messenger' => $user->messenger,
            ]);
            $order->items()->createMany($items);
            $order->log('سفارش از سبد رها شده توسط '.(auth()->user()?->displayName() ?? 'مدیر').' ساخته شد');
            $rec->update(['order_id' => $order->id, 'stage' => 'converted', 'user_id' => $user->id]);

            return $order;
        });
    }

    /** ساخت ردیف‌های سفارش از سبد با قفل و کم کردن موجودی (داخل تراکنش صدا زده شود) */
    protected function buildItems($lines, Cart $cart): array
    {
        $items = [];
        $itemsTotal = 0;
        $discount = 0;
        $cartons = 0;
        // همه کالاها با یک پرس‌وجو قفل و خوانده می‌شوند (سفارش‌های پرقلم سریع ثبت می‌شوند)
        $locked = Product::query()->whereIn('id', collect($lines)->map(fn ($l) => $l->product->id)->unique()->values()->all())->lockForUpdate()->get()->keyBy('id');
        foreach ($lines as $l) {
            /** @var Product $p */
            $p = $locked[$l->product->id] ?? null;
            [$units, $msg] = $p ? $cart->clamp($p, $l->mode, $l->units) : [0, ''];
            if (! $p || $units !== $l->units) {
                $this->cartFix = [$l->product->id, $l->mode, $units];
                throw ValidationException::withMessages(['cart' => 'موجودی «'.$l->product->name.'» تغییر کرده است. '.$msg.' سبد را بررسی کنید.']);
            }
            $unit = $p->unitPrice($l->mode);
            $compare = ($l->mode === Product::CARTON && $p->compare_price > $unit) ? $p->compare_price : null;
            $items[] = [
                'product_id' => $p->id,
                'name' => $p->name,
                'barcode' => $p->barcode,
                'image' => $p->image,
                'mode' => $p->orderMode($l->mode),
                'units' => $units,
                'per_carton' => $p->per_carton,
                'unit_label' => $p->unit_label,
                'unit_price' => $unit,
                'compare_price' => $compare,
                'total' => $unit * $units,
                'warehouse_id' => $p->warehouseFor($p->orderMode($l->mode)),
            ];
            $itemsTotal += $unit * $units;
            $discount += $compare ? ($compare - $unit) * $units : 0;
            $cartons += $l->mode === Product::CARTON ? intdiv($units, $p->per_carton) : 0;

            $col = $l->mode === Product::RETAIL ? 'retail_stock' : 'stock';
            if ($p->{$col} !== null && Product::counts()) {
                $p->{$col} -= $units;
            }
            $p->sales_count++;
            $p->saveQuietly();
        }

        return [$items, $itemsTotal, $discount, $cartons];
    }

    /** درج یکجای اقلام سفارش (به‌جای یک کوئری برای هر قلم) */
    protected static function insertItems(Order $order, array $items): void
    {
        $rows = [];
        foreach ($items as $it) {
            $row = ['order_id' => $order->id] + $it;
            $rows[] = $row;
        }
        // ستون‌ها در همه ردیف‌ها یکسان باشد
        $keys = [];
        foreach ($rows as $r) {
            $keys += array_flip(array_keys($r));
        }
        $keys = array_keys($keys);
        foreach (array_chunk($rows, 200) as $chunk) {
            \App\Models\OrderItem::query()->insert(array_map(fn ($r) => array_merge(array_fill_keys($keys, null), $r), $chunk));
        }
        $order->unsetRelation('items');
    }

    /** پس از پرداخت موفق درگاه */
    public function markPaid(Order $order, string $ref, array $meta = []): void
    {
        if ($order->isPaid()) {
            return;
        }
        $order->payment_status = 'paid';
        $order->payment_ref = $ref;
        $order->payment_meta = $meta;
        $order->paid_at = now();
        $order->save();
        if (! $order->stock_reduced) {
            $order->adjustStock(true);
        }
        $order->log('پرداخت آنلاین موفق — کد پیگیری '.$ref, $order->user_id);
        $order->setStatus('processing', null, false);
        app(Sms::class)->newOrder($order);
        app(WebPush::class)->newOrder($order);
    }

    /** لغو سفارش‌های پرداخت‌نشده قدیمی و برگرداندن موجودی */
    public static function cancelStalePending(): int
    {
        $minutes = max(15, (int) setting('pending_cancel_minutes', 60));
        $n = 0;
        Order::query()->where('status', 'pending_payment')->where('created_at', '<', now()->subMinutes($minutes))
            ->each(function (Order $o) use (&$n) {
                $o->setStatus('cancelled', 'پرداخت انجام نشد', false);
                $n++;
            });

        return $n;
    }
}
