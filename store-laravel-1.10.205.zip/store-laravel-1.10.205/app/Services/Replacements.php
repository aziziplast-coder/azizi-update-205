<?php

namespace App\Services;

use App\Models\Product;
use App\Support\Search;

/**
 * پیشنهاد جایگزین برای کالای تمام‌شده:
 *  ۱. نوع کالا (نخستین واژه نام، مثل «آبکش») باید دقیقاً یکی باشد؛ وگرنه چیزی پیشنهاد نمی‌شود
 *  ۲. هرچه واژه‌های مشترک نام بیشتر (جنس، اندازه، مدل …)، بالاتر
 *  ۳. در شباهت نام برابر، نزدیک‌ترین قیمت به کالای حذف‌شده
 *  و تبدیل تعداد به نزدیک‌ترین مقدار در کالای جایگزین.
 */
class Replacements
{
    /** واژه‌های آغازین عمومی که نوع کالا نیستند (ست آبکش ← آبکش) */
    protected const GENERIC = ['ست', 'پک', 'بسته', 'کارتن', 'جفت', 'عدد', 'سری', 'مدل', 'طرح', 'جدید', 'سفارشی', 'اصل', 'اورجینال', 'عمده', 'تکی'];

    /** دسته ← دسته اصلی (ریشه) */
    public static function roots(): array
    {
        return \Illuminate\Support\Facades\Cache::remember('cat.roots', 600, function () {
            $parents = \App\Models\Category::query()->pluck('parent_id', 'id')->all();
            $out = [];
            foreach ($parents as $id => $pid) {
                $c = (int) $id;
                $seen = [];
                while (! empty($parents[$c]) && ! isset($seen[$c])) {
                    $seen[$c] = true;
                    $c = (int) $parents[$c];
                }
                $out[(int) $id] = $c;
            }

            return $out;
        });
    }

    /** کلید واژه نوع کالا از نام */
    public static function head(string $name): ?string
    {
        $generic = array_map([Search::class, 'key'], static::GENERIC);
        foreach (Search::words($name) as $w) {
            if (ctype_digit($w) || mb_strlen($w) < 2) {
                continue;
            }
            $k = Search::key($w);
            if ($k === '' || in_array($k, $generic, true)) {
                continue;
            }

            return $k;
        }

        return null;
    }

    /**
     * @param  array{id:int,name:string,price:int,category_id:?int,mode:string,units:int,per_carton:int}  $gone
     * @return array<int, array{product: Product, mode: string, units: int, label: string, score: float}>
     */
    public static function for(array $gone, int $limit = 3): array
    {
        $head = static::head($gone['name']);
        if (! $head) {
            return [];
        }
        $price = max(1, (int) $gone['price']);
        // فقط کالاهایی که این واژه را در نام دارند؛ نزدیک‌ترین قیمت‌ها اول
        $cands = Product::query()->active()->available()->where('id', '!=', $gone['id'])
            ->where('search_key', 'like', '%|'.$head.'|%')
            ->orderByRaw('ABS((price * 1.0) - ?)', [$price])
            ->limit(400)->get();
        if ($cands->isEmpty()) {
            return [];
        }
        $goneWords = array_values(array_unique(array_map([Search::class, 'key'], Search::words($gone['name']))));
        // واژه پس از نوع کالا (اگر عدد نباشد)
        $second = null;
        $hi = array_search($head, $goneWords, true);
        if ($hi !== false && isset($goneWords[$hi + 1]) && ! ctype_digit($goneWords[$hi + 1]) && mb_strlen($goneWords[$hi + 1]) > 1) {
            $second = $goneWords[$hi + 1];
        }
        // دسته: فقط از همان دسته اصلی (پیاله پلاستیکی ← پیاله پلاستیکی، نه بلوری یا استیل)
        $goneCat = (int) ($gone['category_id'] ?? 0);
        $roots = static::roots();
        $goneRoot = $goneCat ? ($roots[$goneCat] ?? $goneCat) : 0;
        $scored = [];
        foreach ($cands as $p) {
            if (static::head($p->name) !== $head) {
                continue; // «آبکش» فقط با «آبکش»
            }
            if ($goneRoot && (int) ($roots[(int) $p->category_id] ?? $p->category_id) !== $goneRoot) {
                continue;
            }
            $pw = array_map([Search::class, 'key'], Search::words($p->name));
            $common = 0;
            foreach ($goneWords as $w) {
                foreach ($pw as $x) {
                    if ($w === $x || (mb_strlen($w) > 3 && Search::similarity($w, $x) >= 0.85)) {
                        $common++;
                        break;
                    }
                }
            }
            [$mode, $units, $label] = static::qty($p, $gone);
            if ($units <= 0) {
                continue;
            }
            $nameScore = $goneWords ? $common / count($goneWords) : 0;
            $scored[] = ['product' => $p, 'mode' => $mode, 'units' => $units, 'label' => $label,
                'score' => round($nameScore, 3), 'common' => $common, 'diff' => abs((int) $p->price - $price),
                'second' => $second !== null && in_array($second, $pw, true), 'same' => $goneCat && (int) $p->category_id === $goneCat];
        }
        // اگر از دقیقاً همان دسته (زیردسته) کالایی هست، فقط همان‌ها
        if (array_filter($scored, fn ($r) => $r['same'])) {
            $scored = array_values(array_filter($scored, fn ($r) => $r['same']));
        }
        // اگر کالای هم‌نوع با ویژگی مشترک (مثلاً هم‌جنس) هست، آن‌هایی که فقط نوعشان یکی است کنار می‌روند
        // واژه دوم نام معمولاً جنس/گونه است (آبکش «پلاستیکی»)؛ اگر کالایی با همان واژه هست فقط همان‌ها
        if (array_filter($scored, fn ($r) => $r['second'])) {
            $scored = array_values(array_filter($scored, fn ($r) => $r['second']));
        } else {
            $best = $scored ? max(array_column($scored, 'common')) : 0;
            if ($best >= 2) {
                $scored = array_values(array_filter($scored, fn ($r) => $r['common'] >= 2));
            }
        }
        // اول شباهت نام (تعداد واژه مشترک)، بعد نزدیک‌ترین قیمت
        usort($scored, fn ($a, $b) => [$b['common'], $a['diff']] <=> [$a['common'], $b['diff']]);

        return array_map(fn ($r) => array_diff_key($r, ['common' => 1, 'diff' => 1, 'second' => 1, 'same' => 1]), array_slice($scored, 0, $limit));
    }

    /**
     * تعداد پیشنهادی در کالای جایگزین: نزدیک‌ترین تعداد عدد به سفارش قبلی، با رعایت کارتن و سقف تکی
     *
     * @return array{0: string, 1: int, 2: string}
     */
    public static function qty(Product $p, array $gone): array
    {
        $want = max(1, (int) $gone['units']);
        $n = max(1, (int) $p->per_carton);
        $preferCarton = $gone['mode'] !== Product::RETAIL;
        if ($preferCarton && $p->cartonAvailable() && $p->buyRule()[2]) {
            // قانون خرید خاص (بسته‌ای/فله): به عدد، با حداقل و گام همان کالا
            [$min, $step] = $p->buyRule();
            $units = $want <= $min ? $min : (int) ($min + round(($want - $min) / $step) * $step);
            $max = $p->cartonMaxUnits();
            if ($max >= 0) {
                $units = min($units, $max);
            }
            if ($units >= $min) {
                return [Product::CARTON, $units, fa($units).' '.$p->unitName()];
            }
        }
        if ($preferCarton && $p->cartonAvailable() && ! $p->buyRule()[2]) {
            $cartons = max(1, (int) round($want / $n));
            $units = $cartons * $n;
            $max = $p->cartonMaxUnits();
            if ($max >= 0) {
                $units = min($units, $max);
                $cartons = intdiv($units, $n);
            }
            if ($cartons > 0) {
                return [Product::CARTON, $units, $n > 1 ? fa($cartons).' کارتن '.fa($n).'تایی ('.fa($units).' عدد)' : fa($units).' عدد'];
            }
        }
        if ($p->retailAvailable()) {
            $units = min($want, $p->retailMaxUnits());

            return [Product::RETAIL, $units, fa($units).' عدد تکی'];
        }
        if ($p->cartonAvailable()) {
            $units = $n;

            return [Product::CARTON, $units, $n > 1 ? '۱ کارتن '.fa($n).'تایی' : '۱ عدد'];
        }

        return [Product::CARTON, 0, ''];
    }
}
