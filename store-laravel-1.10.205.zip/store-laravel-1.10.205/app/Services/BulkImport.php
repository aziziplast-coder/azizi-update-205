<?php

namespace App\Services;

use App\Models\Category;
use App\Models\Product;
use App\Models\Warehouse;
use App\Support\ImageCompressor;
use App\Support\Search;
use App\Support\SheetReader;
use App\Support\Watermark;
use App\Services\Sync\SyncEngine;
use Illuminate\Support\Facades\DB;
use RuntimeException;
use Throwable;

/**
 * آپلود گروهی محصولات: تصاویر (از RAR/ZIP که در مرورگر باز می‌شود) + یک فایل اکسل.
 *
 * نام هر تصویر: «شماره انبار عمده-کد کالا» و برای تصاویر بیشتر «…-2»، «…-3» یا «… (2)» (مثلاً 7-202545.jpg، 7-202545-2.jpg).
 * از اکسل نام، قیمت، تعداد در کارتن، بارکد و … خوانده می‌شود. کالاها «منتظر تأیید» و پنهان ساخته می‌شوند
 * تا اپراتور در «محصولات ← منتظر تأیید و انتشار» بررسی و گروهی منتشر کند.
 */
class BulkImport
{
    public const PERM = 'bulk_upload';

    /** فیلدهای قابل نگاشت ستون اکسل */
    public const FIELDS = [
        'code' => 'کد کالا',
        'name' => 'نام کالا',
        'price' => 'قیمت فروش (هر عدد)',
        'compare_price' => 'قیمت قبل از تخفیف',
        'per_carton' => 'تعداد در کارتن',
        'unit' => 'واحد (جفت، دست، پک …)',
        'warehouse' => 'شماره انبار عمده',
        'retail_warehouse' => 'شماره انبار خرده',
        'retail_price' => 'قیمت تکی (خرده)',
        'stock' => 'موجودی (عدد)',
        'barcode' => 'بارکد',
        'category' => 'دسته‌بندی',
        'short_description' => 'توضیح کوتاه',
        'description' => 'توضیحات',
        '' => '— نادیده گرفته شود —',
    ];

    /** ستون‌هایی که همیشه نادیده گرفته می‌شوند (موجودی، جمع، درصد تخفیف، شرح کالا) */
    protected const IGNORE = ['موجودی', 'موجود', 'جمع', 'جمع کل', 'درصد تخفیف', 'شرح کالا', 'شرح', 'ردیف'];

    /** کلمات کلیدی سرستون‌ها برای تشخیص خودکار (اولی که بخورد) */
    protected const GUESS = [
        'retail_warehouse' => ['انبار خرده', 'انبار تکی', 'انبارخرده'],
        'warehouse' => ['شماره انبار', 'انبار عمده', 'کد انبار', 'انبار'],
        'barcode' => ['بارکد', 'barcode'],
        'code' => ['کد کالا', 'کدکالا', 'کد هلو', 'کد محصول', 'code', 'sku', 'کد'],
        'retail_price' => ['قیمت تکی', 'قیمت خرده', 'فی خرده', 'قیمت خورده'],
        'compare_price' => ['قیمت قبل', 'قیمت مصرف', 'قیمت مصرف‌کننده', 'قیمت مصرف کننده', 'قیمت بدون تخفیف'],
        'price' => ['قیمت فروش', 'قیمت عمده', 'فی فروش', 'قیمت', 'فی', 'مبلغ', 'price'],
        'per_carton' => ['تعداد در کارتن', 'تعداددرکارتن', 'در کارتن', 'تعداد'], // «تعداد» = تعداد در کارتن؛ ستون «کارتن» تعداد کارتن موجود است، نه این
        'unit' => ['واحد'],
        'category' => ['دسته', 'گروه', 'category'],
        'short_description' => ['توضیح کوتاه', 'خلاصه'],
        'description' => ['توضیحات', 'description'],
        'name' => ['نام کالا', 'نام محصول', 'عنوان', 'نام', 'title', 'name'],
    ];

    public const ISSUES = [
        'img_no_row' => 'تصویر دارد ولی کدش در اکسل نیست',
        'row_no_img' => 'در اکسل هست ولی تصویر ندارد',
        'wh_mismatch' => 'شماره انبار تصویر با اکسل فرق دارد',
        'exists' => 'این کد قبلاً در سایت هست (ساخته نمی‌شود)',
        'dup_code' => 'کد تکراری در اکسل',
        'no_name' => 'نام کالا خالی است',
        'no_price' => 'قیمت ندارد',
        'bad_name' => 'نام تصویر قابل خواندن نیست (باید «انبار-کد» باشد)',
        'new_wh' => 'انبار عمده با این شماره در سایت نبود؛ ساخته می‌شود',
        'img_update' => 'کالای موجود: عکس اصلی عوض می‌شود (عکس قبلی به گالری می‌رود)',
    ];

    public static function canUse($u): bool
    {
        return (bool) $u && ($u->isAdmin() || $u->hasPerm(self::PERM));
    }

    public static function dir(int $id): string
    {
        return storage_path('app/bulk/'.$id);
    }

    /** فیلدهای لازم برای انتشار که خالی مانده‌اند */
    public static function missing(Product $p): array
    {
        $m = [];
        if (trim((string) $p->name) === '') {
            $m[] = 'نام';
        }
        if ((int) $p->price <= 0) {
            $m[] = 'قیمت';
        }
        if (! $p->image) {
            $m[] = 'تصویر';
        }
        if (! $p->category_id) {
            $m[] = 'دسته';
        }

        return $m;
    }

    /* ---------------- تصاویر ---------------- */

    /** «7-202545-2.jpg» → [انبار '7'، کد '202545'، ترتیب 2] — اگر فقط کد باشد انبار خالی است */
    public static function parseImageName(string $file): ?array
    {
        $n = pathinfo($file, PATHINFO_FILENAME);
        $n = en_digits(str_replace(['ي', 'ك'], ['ی', 'ک'], $n));
        $idx = 1;
        if (preg_match('/^(.*?)\s*\((\d{1,2})\)\s*$/u', $n, $m)) { // «… (2)»
            [$n, $idx] = [$m[1], (int) $m[2]];
        }
        $parts = array_values(array_filter(preg_split('/\s*[-_–—]\s*|\s+/u', trim($n)), fn ($x) => $x !== ''));
        if (! $parts) {
            return null;
        }
        if (count($parts) >= 3 && preg_match('/^\d{1,2}$/', end($parts))) {
            $idx = (int) array_pop($parts);
        }
        if (count($parts) === 1) {
            $code = Excel::barcode($parts[0]);

            return preg_match('/^[A-Za-z0-9.]+$/', $code) ? ['', $code, max(1, $idx)] : null;
        }
        if (! preg_match('/^\d{1,4}$/', $parts[0])) { // شماره انبار فقط عدد
            return null;
        }
        $wh = SyncEngine::whCode($parts[0]);
        $code = Excel::barcode(implode('-', array_slice($parts, 1)));

        return preg_match('/^[A-Za-z0-9.\-]+$/', $code) ? [$wh, $code, max(1, $idx)] : null;
    }

    public static function storeImage(int $id, string $original, string $tmpPath): string
    {
        $dir = static::dir($id).'/img';
        is_dir($dir) || @mkdir($dir, 0775, true);
        $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        $ext = in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true) ? $ext : 'jpg';
        $base = preg_replace('/[^\p{L}\p{N}\-_() ]+/u', '', pathinfo($original, PATHINFO_FILENAME)) ?: 'img';
        $base = mb_substr($base, 0, 80);
        $name = $base.'.'.$ext;
        for ($i = 2; is_file($dir.'/'.$name); $i++) {
            $name = $base.'~'.$i.'.'.$ext;
        }
        if (! @move_uploaded_file($tmpPath, $dir.'/'.$name)) {
            @copy($tmpPath, $dir.'/'.$name);
        }

        return $name;
    }

    /* ---------------- اکسل ---------------- */

    public static function excelPath(int $id): ?string
    {
        $f = glob(static::dir($id).'/excel/*') ?: [];

        return $f[0] ?? null;
    }

    /** خواندن اکسل: [سرستون‌ها، ردیف‌ها، شماره ردیف سرستون] */
    public static function readExcel(int $id): array
    {
        $path = static::excelPath($id);
        if (! $path) {
            // فقط عکس (بدون اکسل): برای عوض کردن عکس کالاهای موجود
            if (glob(static::dir($id).'/img/*')) {
                return [[], [], 0];
            }
            throw new RuntimeException('فایل اکسل پیدا نشد. یک فایل xlsx/xls/csv همراه تصاویر بفرستید.');
        }
        $rows = [];
        SheetReader::read($path, basename($path), function ($r) use (&$rows) {
            $rows[] = array_map(fn ($v) => is_string($v) ? trim($v) : $v, (array) $r);
        });
        // سطر سرستون: اولین سطری (از ۱۰ سطر اول) که بیشترین ستون شناخته‌شده را دارد
        $best = [0, -1];
        foreach (array_slice($rows, 0, 10, true) as $i => $r) {
            $hits = 0;
            foreach ($r as $c) {
                if (is_string($c) && $c !== '' && ! in_array(static::guessField($c), ['', 'skip'], true)) {
                    $hits++;
                }
            }
            if ($hits > $best[1]) {
                $best = [$i, $hits];
            }
        }
        $hi = $best[0];
        $headers = array_map(fn ($c) => Excel::text($c), $rows[$hi] ?? []);
        foreach ($headers as $k => $h) {
            if ($h === '') {
                $headers[$k] = 'ستون '.($k + 1);
            }
        }
        $data = array_values(array_filter(array_slice($rows, $hi + 1), fn ($r) => trim(implode('', array_map('strval', $r))) !== ''));

        return [$headers, $data, $hi + 1];
    }

    /**
     * شماره انبار عمده ← دسته اصلی‌ای که بیشتر کالاهای آن انبار در آن است (دست‌کم ۵۰٪ و ۱۰ کالا).
     *
     * @return array<string, int>
     */
    public static function warehouseRoots(): array
    {
        $roots = \App\Services\Replacements::roots();
        $count = [];
        $rows = DB::table('products as p')->join('warehouses as w', 'w.id', '=', 'p.warehouse_id')->whereNotNull('p.category_id')
            ->selectRaw('w.code, p.category_id, COUNT(*) n')->groupBy('w.code', 'p.category_id')->get();
        foreach ($rows as $r) {
            $wh = SyncEngine::whCode($r->code);
            $root = $roots[(int) $r->category_id] ?? (int) $r->category_id;
            if ($wh !== '' && $root) {
                $count[$wh][$root] = ($count[$wh][$root] ?? 0) + (int) $r->n;
            }
        }
        $out = [];
        foreach ($count as $wh => $c) {
            arsort($c);
            $top = (int) array_key_first($c);
            $sum = array_sum($c);
            if ($c[$top] >= 10 && $c[$top] / max(1, $sum) >= 0.5) {
                $out[(string) $wh] = $top;
            }
        }

        return $out;
    }

    public static function guessField(string $header): string
    {
        $h = Search::normalize(Excel::text($header));
        $h = str_replace('‌', ' ', $h);
        if (preg_match('/^(ردیف|شماره ردیف|#|row|ر)$/u', trim($h))) {
            return 'skip';
        }
        // «کارتن» یا «تعداد کارتن» (تعداد کارتن موجود) — نادیده؛ تعداد در کارتن از ستون «تعداد» خوانده می‌شود
        if (in_array(trim($h), [Search::normalize('کارتن'), Search::normalize('تعداد کارتن'), Search::normalize('کارتن موجود')], true)) {
            return 'skip';
        }
        foreach (self::IGNORE as $w) {
            $w = Search::normalize($w);
            if ($h === $w || (mb_strlen($w) > 2 && str_contains($h, $w) && ! str_contains($h, 'کارتن'))) {
                return 'skip';
            }
        }
        foreach (self::GUESS as $field => $words) {
            foreach ($words as $w) {
                $w = Search::normalize($w);
                if ($h === $w || ($w !== '' && mb_strlen($w) > 2 && str_contains($h, $w))) {
                    return $field;
                }
            }
        }

        return '';
    }

    public static function guessMapping(array $headers): array
    {
        $map = [];
        $used = [];
        foreach ($headers as $i => $h) {
            $f = static::guessField((string) $h);
            if ($f === 'skip') {
                $map[$i] = '';

                continue;
            }
            if ($f !== '' && isset($used[$f])) {
                $f = ''; // ستون دوم برای همان فیلد: نادیده
            }
            $map[$i] = $f; // ستون ناشناخته: نادیده (مشخصات فنی ساخته نمی‌شود)
            $used[$f] = true;
        }

        return $map;
    }

    /* ---------------- تحلیل ---------------- */

    /**
     * تطبیق تصاویر و اکسل.
     * خروجی: rows (برای ساخت)، issues (مغایرت‌ها)، stats
     */
    public static function analyze(int $id, array $mapping, array $opt = []): array
    {
        @set_time_limit(300);
        [$headers, $data] = static::readExcel($id);
        $col = [];
        $specCols = [];
        foreach ($mapping as $i => $f) {
            if ($f !== '' && isset(self::FIELDS[$f]) && ! isset($col[$f])) {
                $col[$f] = (int) $i;
            }
        }
        if (! isset($col['code']) && $data) {
            throw new RuntimeException('ستون «کد کالا» در اکسل مشخص نشده است.');
        }
        $rial = ($opt['unit'] ?? 'toman') === 'rial';
        $get = fn (array $r, string $f) => isset($col[$f]) ? ($r[$col[$f]] ?? null) : null;

        // تصاویر
        $imgs = [];
        $issues = [];
        foreach (glob(static::dir($id).'/img/*') ?: [] as $f) {
            $name = basename($f);
            $orig = preg_replace('/~\d+(\.[a-z]+)$/i', '$1', $name);
            $p = static::parseImageName($orig);
            if (! $p) {
                $issues[] = ['t' => 'bad_name', 'img' => $name];

                continue;
            }
            $imgs[Excel::key($p[1])][] = ['f' => $name, 'wh' => $p[0], 'i' => $p[2]];
        }

        // کالاهای موجود سایت با همین کد
        $exist = [];
        foreach (DB::table('products')->select('id', 'name', 'sku', 'sync_code', 'barcode')->cursor() as $p) {
            foreach (['sku', 'sync_code', 'barcode'] as $k) {
                $kk = Excel::key(Excel::barcode((string) $p->{$k}));
                if ($kk !== '') {
                    $exist[$kk] ??= [$p->id, $p->name];
                }
            }
        }
        $whRootOf = static::warehouseRoots();
        $rootDesc = [];
        $whs = [];
        foreach (Warehouse::query()->get(['id', 'code', 'kind']) as $w) {
            $whs[($w->kind ?: 'carton').':'.SyncEngine::whCode($w->code)] ??= $w->id;
        }
        $cats = [];
        foreach (Category::query()->get(['id', 'name']) as $c) {
            $cats[Search::key($c->name)] ??= $c->id;
        }

        $rows = [];
        $updates = [];
        $seen = [];
        $newWh = [];
        foreach ($data as $n => $r) {
            $code = Excel::barcode($get($r, 'code'));
            if ($code === '') {
                continue;
            }
            $key = Excel::key($code);
            $line = $n + 1;
            if (isset($seen[$key])) {
                $issues[] = ['t' => 'dup_code', 'code' => $code, 'row' => $line];

                continue;
            }
            $seen[$key] = true;
            $name = Excel::text($get($r, 'name'));
            $num = fn ($f) => ($v = Excel::number($get($r, $f), $rial && in_array($f, ['price', 'compare_price', 'retail_price'], true))) !== null && $v > 0 ? $v : null;
            $myImgs = $imgs[$key] ?? [];
            usort($myImgs, fn ($a, $b) => $a['i'] <=> $b['i']);
            $whImg = '';
            foreach ($myImgs as $im) {
                if ($im['wh'] !== '') {
                    $whImg = $im['wh'];
                    break;
                }
            }
            $whXls = SyncEngine::whCode($get($r, 'warehouse'));
            $wh = $whImg !== '' ? $whImg : $whXls; // شماره انبار نام عکس = انبار عمده (کارتنی)
            $flags = [];
            if ($whImg !== '' && $whXls !== '' && $whImg !== $whXls) {
                $flags[] = 'wh_mismatch';
                $issues[] = ['t' => 'wh_mismatch', 'code' => $code, 'name' => $name, 'row' => $line, 'msg' => 'تصویر: '.$whImg.' — اکسل: '.$whXls];
            }
            if ($wh !== '' && ! isset($whs['carton:'.$wh]) && ! isset($newWh[$wh])) {
                $newWh[$wh] = true;
                $issues[] = ['t' => 'new_wh', 'msg' => 'انبار عمده '.$wh];
            }
            if (isset($exist[$key])) {
                if ($myImgs) {
                    // کالای موجود با عکس تازه: عکس اصلی عوض می‌شود و عکس اصلی قبلی به گالری می‌رود
                    $updates[] = ['pid' => $exist[$key][0], 'code' => $code, 'name' => $exist[$key][1], 'imgs' => array_column($myImgs, 'f')];
                } else {
                    $issues[] = ['t' => 'exists', 'code' => $code, 'name' => $name, 'row' => $line, 'pid' => $exist[$key][0], 'msg' => $exist[$key][1]];
                }
                unset($imgs[$key]);

                continue;
            }
            if (! $myImgs) {
                $flags[] = 'row_no_img';
                $issues[] = ['t' => 'row_no_img', 'code' => $code, 'name' => $name, 'row' => $line];
            }
            if ($name === '') {
                $flags[] = 'no_name';
                $issues[] = ['t' => 'no_name', 'code' => $code, 'row' => $line];
            }
            $price = $num('price');
            if (! $price) {
                $flags[] = 'no_price';
            }
            $catName = Excel::text($get($r, 'category'));
            $catId = null;
            if ($catName !== '') {
                $last = trim((string) last(preg_split('#\s*[/>›،,]\s*#u', $catName)));
                $catId = $cats[Search::key($last)] ?? $cats[Search::key($catName)] ?? null;
            }
            $catGuess = false;
            // دسته اصلی انبار: هر انبار (انباردار) معمولاً یک دسته اصلی دارد (مثلاً انبار ۱ = بلور)
            $whRoot = $wh !== '' ? ($whRootOf[$wh] ?? null) : null;
            $inRoot = $whRoot ? ($rootDesc[$whRoot] ??= \App\Models\Category::query()->find($whRoot)?->descendantIds() ?? [$whRoot]) : null;
            if (! $catId && $catName !== '') { // دسته اکسل در سایت نیست: نزدیک‌ترین دسته از روی نام دسته اکسل + نام کالا
                $catId = ($inRoot ? Product::guessCategory($catName.' '.$name, null, $inRoot) : null) ?: Product::guessCategory($catName.' '.$name);
                $catGuess = (bool) $catId;
            }
            if (! $catId && $name !== '') {
                // اول فقط داخل دسته اصلی همان انبار (بلور ← بلور / پارچ بلوری)؛ نبود = خود دسته اصلی انبار
                $catId = $inRoot ? (Product::guessCategory($name, null, $inRoot) ?: $whRoot) : Product::guessCategory($name);
                $catGuess = (bool) $catId;
            }
            $pcRaw = $get($r, 'per_carton');
            $pc = (int) (preg_match('/\d+/', en_digits((string) $pcRaw), $m) ? $m[0] : 0);
            $unit = Excel::text($get($r, 'unit'));
            if ($unit === '' && is_string($pcRaw)) {
                $unit = (string) Product::unitFromText($pcRaw);
            }
            $specs = [];
            foreach ($specCols as $i => $h) {
                $v = Excel::text($r[$i] ?? '');
                if ($v !== '') {
                    $specs[$h] = mb_substr($v, 0, 250);
                }
            }
            $rows[] = [
                'row' => $line, 'code' => $code, 'name' => mb_substr($name, 0, 250), 'price' => $price, 'compare_price' => $num('compare_price'),
                'retail_price' => $num('retail_price'), 'per_carton' => max(1, $pc ?: 1), 'unit' => $unit ?: null,
                'stock' => ($s = Excel::number($get($r, 'stock'))) !== null ? $s : null,
                'barcode' => ($b = Excel::barcode($get($r, 'barcode'))) !== '' ? $b : null,
                'wh' => $wh, 'rwh' => SyncEngine::whCode($get($r, 'retail_warehouse')),
                'cat' => $catId, 'cat_guess' => $catGuess, 'cat_text' => $catName,
                'short' => Excel::text($get($r, 'short_description')) ?: null, 'desc' => trim((string) $get($r, 'description')) ?: null,
                'specs' => $specs, 'imgs' => array_column($myImgs, 'f'), 'flags' => $flags,
            ];
            unset($imgs[$key]);
        }
        foreach ($imgs as $key => $list) {
            if (isset($exist[$key])) {
                // عکس بدون ردیف اکسل ولی کالایش در سایت هست ← تعویض عکس همان کالا
                usort($list, fn ($a, $b) => $a['i'] <=> $b['i']);
                $updates[] = ['pid' => $exist[$key][0], 'code' => (string) $key, 'name' => $exist[$key][1], 'imgs' => array_column($list, 'f')];

                continue;
            }
            foreach ($list as $im) {
                $issues[] = ['t' => 'img_no_row', 'img' => $im['f'], 'code' => $key, 'msg' => $im['wh'] !== '' ? 'انبار '.$im['wh'] : null];
            }
        }
        if ($updates) {
            $old = DB::table('products')->whereIn('id', array_column($updates, 'pid'))->pluck('image', 'id');
            foreach ($updates as &$u) {
                $u['old'] = $old[$u['pid']] ?? null;
            }
            unset($u);
        }

        $byType = [];
        foreach ($issues as $is) {
            $byType[$is['t']] = ($byType[$is['t']] ?? 0) + 1;
        }
        $stats = [
            'rows' => count($rows), 'updates' => count($updates), 'excel_rows' => count($seen), 'images' => count(glob(static::dir($id).'/img/*') ?: []),
            'with_img' => count(array_filter($rows, fn ($r) => $r['imgs'])),
            'cat_auto' => count(array_filter($rows, fn ($r) => $r['cat_guess'])),
            'no_cat' => count(array_filter($rows, fn ($r) => ! $r['cat'])),
            'issues' => $byType,
        ];
        file_put_contents(static::dir($id).'/plan.json', json_encode(['rows' => $rows, 'updates' => $updates, 'issues' => $issues], JSON_UNESCAPED_UNICODE));
        DB::table('product_imports')->where('id', $id)->update([
            'status' => 'analyzed', 'mapping' => json_encode($mapping), 'options' => json_encode($opt), 'stats' => json_encode($stats, JSON_UNESCAPED_UNICODE), 'updated_at' => now(),
        ]);

        return ['headers' => $headers, 'rows' => $rows, 'updates' => $updates, 'issues' => $issues, 'stats' => $stats];
    }

    /** ذخیره یک عکس آپلودی در پوشه کالاها (فشرده و با واترمارک) */
    protected static function storeUploaded(int $id, string $code, string $f, int $i): ?string
    {
        $src = static::dir($id).'/img/'.$f;
        if (! is_file($src)) {
            return null;
        }
        $body = (string) file_get_contents($src);
        $sz = @getimagesize($src);
        // تصویری که مرورگر از قبل کوچک و فشرده کرده دوباره پردازش نمی‌شود (سریع‌تر)
        $c = $sz && max($sz[0], $sz[1]) <= 1600 && strlen($body) <= 700 * 1024 && in_array($sz[2], [IMAGETYPE_JPEG, IMAGETYPE_WEBP], true)
            ? ['body' => $body, 'ext' => $sz[2] === IMAGETYPE_WEBP ? 'webp' : 'jpg']
            : ImageCompressor::compress($body, 1600, 88);
        $rel = 'products/bulk/'.$id.'/'.preg_replace('/[^A-Za-z0-9\-]/', '', $code).'-'.($i + 1).'-'.substr(md5($f.microtime()), 0, 6).'.'.$c['ext'];

        return Watermark::store($rel, $c['body']) ? $rel : null;
    }

    /**
     * تعویض عکس کالاهای موجود (بعد از ساخت کالاهای تازه، در همان مرحله «ساخت/تأیید»):
     * عکس اول فایل = عکس اصلی؛ عکس اصلی قبلی اول گالری؛ بقیه عکس‌های تازه بعد از آن.
     */
    public static function updateChunk(int $id, int $offset, int $limit = 10): array
    {
        @set_time_limit(300);
        $plan = json_decode((string) @file_get_contents(static::dir($id).'/plan.json'), true);
        $list = array_slice((array) ($plan['updates'] ?? []), $offset, $limit);
        $done = 0;
        $errors = [];
        foreach ($list as $u) {
            try {
                $p = Product::query()->find((int) $u['pid']);
                if (! $p) {
                    continue;
                }
                // تکرار نشود (رفرش وسط کار): اگر یکی از عکس‌های همین آپلود قبلاً عکس اصلی شده
                if ($p->image && str_starts_with((string) $p->image, 'products/bulk/'.$id.'/'.preg_replace('/[^A-Za-z0-9\-]/', '', $u['code']).'-')) {
                    continue;
                }
                $new = [];
                foreach ((array) $u['imgs'] as $i => $f) {
                    if ($rel = static::storeUploaded($id, (string) $u['code'], (string) $f, $i)) {
                        $new[] = $rel;
                    }
                }
                if (! $new) {
                    continue;
                }
                $gallery = array_values(array_unique(array_filter(array_merge([$p->image], array_slice($new, 1), (array) $p->gallery))));
                $p->forceFill(['image' => $new[0], 'gallery' => array_slice($gallery, 0, 12) ?: null])->save();
                $done++;
            } catch (Throwable $e) {
                report($e);
                $errors[] = ['code' => $u['code'] ?? '', 'msg' => mb_substr($e->getMessage(), 0, 200)];
            }
        }
        $next = $offset + count($list);

        return ['updated' => $done, 'next' => $next, 'total' => count((array) ($plan['updates'] ?? [])), 'done' => $next >= count((array) ($plan['updates'] ?? [])), 'errors' => $errors];
    }

    /* ---------------- ساخت ---------------- */

    /** ساخت یک دسته از ردیف‌ها (برای جلوگیری از timeout هاست، چند بار صدا زده می‌شود) */
    public static function createChunk(int $id, int $offset, int $limit = 25, bool $cleanup = true): array
    {
        @set_time_limit(300);
        $plan = json_decode((string) @file_get_contents(static::dir($id).'/plan.json'), true);
        if (! $plan) {
            throw new RuntimeException('اول «بررسی» را بزنید.');
        }
        $opt = (array) json_decode((string) DB::table('product_imports')->where('id', $id)->value('options'), true);
        $rows = array_slice($plan['rows'], $offset, $limit);
        $made = 0;
        $errors = [];
        $whIds = [];
        $whId = function (string $code, string $kind) use (&$whIds) {
            if ($code === '') {
                return null;
            }
            $k = $kind.':'.$code;
            if (! array_key_exists($k, $whIds)) {
                $w = Warehouse::query()->where('kind', $kind)->get(['id', 'code'])->first(fn ($w) => SyncEngine::whCode($w->code) === $code);
                $whIds[$k] = $w?->id ?? Warehouse::query()->create(['name' => ($kind === 'retail' ? 'انبار خرده ' : 'انبار عمده ').fa($code), 'code' => $code, 'kind' => $kind, 'is_active' => true])->id;
            }

            return $whIds[$k];
        };
        $seo = static::seoMap($id);
        foreach ($rows as $r) {
            $r['seo'] = $seo[Excel::key($r['code'])] ?? [];
            try {
                // تکرار نشود (اگر صفحه وسط کار رفرش شد)
                if (Product::query()->where('import_id', $id)->where('sku', $r['code'])->exists()) {
                    continue;
                }
                $stored = [];
                foreach ($r['imgs'] as $i => $f) {
                    if ($rel = static::storeUploaded($id, (string) $r['code'], (string) $f, $i)) {
                        $stored[] = $rel;
                    }
                }
                if (\App\Models\Warehouse::isLoose($whId($r['wh'], 'carton'))) { // انبار عددی: بدون کارتن، طبق قانون انبار
                    $r['per_carton'] = 1;
                }
                $retail = $r['retail_price'] && $r['per_carton'] > 1;
                $p = new Product([
                    'name' => $r['name'] !== '' ? $r['name'] : 'کالای '.$r['code'],
                    'sku' => $r['code'], 'barcode' => $r['barcode'],
                    'price' => (int) ($r['price'] ?? 0), 'compare_price' => $r['compare_price'],
                    'per_carton' => $r['per_carton'], 'carton_enabled' => true,
                    'unit_label' => $r['unit'], 'unit_manual' => (bool) $r['unit'],
                    'in_stock' => $r['stock'] === null ? ! empty($opt['in_stock'] ?? true) : $r['stock'] > 0, 'stock' => $r['stock'],
                    'retail_enabled' => $retail, 'retail_price' => $retail ? $r['retail_price'] : null, 'retail_in_stock' => $retail,
                    'warehouse_id' => $whId($r['wh'], 'carton'), 'retail_warehouse_id' => $retail ? $whId($r['rwh'], 'retail') : null,
                    'category_id' => $r['cat'], 'short_description' => ($r['seo']['short'] ?? null) ?: $r['short'], 'description' => ($r['seo']['body'] ?? null) ?: $r['desc'],
                    'seo_title' => $r['seo']['title'] ?? null, 'seo_description' => $r['seo']['desc'] ?? null, 'focus_keyword' => $r['seo']['kw'] ?? null,
                    'image' => $stored[0] ?? null, 'gallery' => array_slice($stored, 1) ?: null,
                    'related_auto' => true,
                    'is_active' => false, 'review' => 'pending', 'import_id' => $id,
                ]);
                try {
                    $p->save();
                } catch (\Illuminate\Database\QueryException $e) {
                    // ساخت موازی دو کالای هم‌نام: نامک با کد کالا یکتا می‌شود
                    if (! preg_match('/Duplicate|UNIQUE|unique/i', $e->getMessage())) {
                        throw $e;
                    }
                    $p->slug = Product::makeSlug($p->name.' '.$r['code'], Product::class);
                    $p->save();
                }
                $made++;
            } catch (Throwable $e) {
                report($e);
                $errors[] = ['code' => $r['code'], 'msg' => mb_substr($e->getMessage(), 0, 200)];
            }
        }
        $next = $offset + count($rows);
        $done = $next >= count($plan['rows']);
        DB::table('product_imports')->where('id', $id)->update([
            'status' => $done && $cleanup ? 'done' : 'creating', 'created_count' => Product::query()->where('import_id', $id)->count(), 'updated_at' => now(),
        ]);
        if ($done && $cleanup) {
            static::cleanup($id, false);
        }

        return ['made' => $made, 'next' => $next, 'total' => count($plan['rows']), 'done' => $done, 'errors' => $errors];
    }

    /* ---------------- سئو با کمک Claude (اختیاری) ---------------- */

    /** ستون‌های اکسل سئو: [کلید، سرستون، توضیح برای Claude] */
    public const SEO_COLS = [
        ['title', 'عنوان سئو', 'حداکثر ۶۰ حرف؛ نام کالا + ویژگی اصلی + «خرید عمده»'],
        ['desc', 'توضیح متا', '۱۲۰ تا ۱۵۵ حرف؛ جذاب، با کلمه کلیدی و دعوت به خرید'],
        ['kw', 'کلمه کلیدی اصلی', '۲ تا ۴ کلمه؛ همان عبارتی که مشتری در گوگل جستجو می‌کند'],
        ['short', 'توضیح کوتاه', '۱ تا ۲ جمله (حداکثر ۲۰۰ حرف) برای بالای صفحه کالا'],
        ['body', 'توضیحات کامل', '۲ تا ۴ پاراگراف کوتاه؛ کاربرد، جنس، مزیت‌ها؛ بدون ادعای نادرست'],
    ];

    public static function seoMap(int $id): array
    {
        return (array) json_decode((string) @file_get_contents(static::dir($id).'/seo.json'), true);
    }

    /** ردیف‌های اکسل سئو: پیش از ساخت از برنامه آپلود، بعد از ساخت از کالاهای همین آپلود */
    protected static function seoSource(int $id): array
    {
        $cats = Category::query()->pluck('name', 'id');
        $plan = json_decode((string) @file_get_contents(static::dir($id).'/plan.json'), true);
        $out = [];
        $made = Product::query()->where('import_id', $id)->get(['sku', 'name', 'category_id', 'per_carton', 'unit_label', 'price', 'seo_title', 'seo_description', 'focus_keyword', 'short_description', 'description']);
        if ($made->isNotEmpty()) {
            foreach ($made as $p) {
                $out[] = ['code' => (string) $p->sku, 'name' => $p->name, 'cat' => $cats[$p->category_id] ?? '', 'pc' => $p->per_carton, 'unit' => $p->unit_label, 'price' => $p->price,
                    'seo' => ['title' => $p->seo_title, 'desc' => $p->seo_description, 'kw' => $p->focus_keyword, 'short' => $p->short_description, 'body' => $p->description ? trim(strip_tags($p->description)) : null]];
            }

            return $out;
        }
        $seo = static::seoMap($id);
        foreach ((array) ($plan['rows'] ?? []) as $r) {
            $out[] = ['code' => $r['code'], 'name' => $r['name'], 'cat' => $r['cat'] ? ($cats[$r['cat']] ?? '') : '', 'pc' => $r['per_carton'], 'unit' => $r['unit'], 'price' => $r['price'],
                'seo' => $seo[Excel::key($r['code'])] ?? []];
        }

        return $out;
    }

    /** فایل اکسل سئو (ستون‌های سئو خالی) برای دادن به Claude */
    public static function seoExcel(int $id): string
    {
        $rows = static::seoSource($id);
        if (! $rows) {
            throw new RuntimeException('کالایی برای این آپلود پیدا نشد.');
        }
        $tmp = tempnam(sys_get_temp_dir(), 'seo').'.xlsx';
        $w = new \OpenSpout\Writer\XLSX\Writer;
        $w->openToFile($tmp);
        $w->getCurrentSheet()->setName('کالاها');
        $bold = (new \OpenSpout\Common\Entity\Style\Style)->setFontBold();
        $w->addRow(\OpenSpout\Common\Entity\Row::fromValues(array_merge(['کد کالا', 'نام کالا', 'دسته', 'تعداد در کارتن', 'قیمت (تومان)'], array_column(self::SEO_COLS, 1)), $bold));
        foreach ($rows as $r) {
            $w->addRow(\OpenSpout\Common\Entity\Row::fromValues(array_merge(
                [(string) $r['code'], (string) $r['name'], (string) $r['cat'], trim($r['pc'].' '.($r['unit'] ?: 'عدد')), (int) ($r['price'] ?? 0)],
                array_map(fn ($c) => (string) ($r['seo'][$c[0]] ?? ''), self::SEO_COLS)
            )));
        }
        $w->addNewSheetAndMakeItCurrent()->setName('راهنما');
        $w->addRow(\OpenSpout\Common\Entity\Row::fromValues(['ستون', 'چه بنویسید'], $bold));
        foreach (self::SEO_COLS as $c) {
            $w->addRow(\OpenSpout\Common\Entity\Row::fromValues([$c[1], $c[2]]));
        }
        $w->addRow(\OpenSpout\Common\Entity\Row::fromValues(['', '']));
        $w->addRow(\OpenSpout\Common\Entity\Row::fromValues(['مهم', 'ستون‌های «کد کالا» تا «قیمت» را تغییر ندهید؛ فقط ستون‌های سئو را پر کنید. همه متن‌ها فارسی.']));
        $w->close();

        return $tmp;
    }

    /** ورود اکسل سئوی پرشده: پیش از ساخت ذخیره می‌شود، بعد از ساخت مستقیم روی کالاهای همین آپلود می‌نشیند */
    public static function seoImport(int $id, string $path, string $name): array
    {
        $rows = [];
        SheetReader::read($path, $name, function ($r) use (&$rows) {
            $rows[] = $r;
        });
        $hi = null;
        $col = [];
        foreach (array_slice($rows, 0, 15, true) as $i => $r) {
            foreach ($r as $j => $v) {
                $h = Search::normalize(Excel::text($v));
                if ($h === Search::normalize('کد کالا')) {
                    $hi = $i;
                    $col['code'] = $j;
                }
                foreach (self::SEO_COLS as $c) {
                    if ($h === Search::normalize($c[1])) {
                        $col[$c[0]] = $j;
                    }
                }
            }
            if ($hi !== null) {
                break;
            }
        }
        if ($hi === null || count($col) < 2) {
            throw new RuntimeException('ستون «کد کالا» و ستون‌های سئو در فایل پیدا نشد. همان اکسلی را که از این صفحه گرفتید، پرشده برگردانید.');
        }
        $map = static::seoMap($id);
        $limits = ['title' => 255, 'desc' => 500, 'kw' => 120, 'short' => 1000, 'body' => 20000];
        $n = 0;
        $made = Product::query()->where('import_id', $id)->exists();
        foreach (array_slice($rows, $hi + 1) as $r) {
            $code = Excel::barcode($r[$col['code']] ?? '');
            if ($code === '') {
                continue;
            }
            $seo = [];
            foreach (self::SEO_COLS as $c) {
                if (isset($col[$c[0]]) && ($v = trim(str_replace(['ي', 'ك'], ['ی', 'ک'], (string) ($r[$col[$c[0]]] ?? '')))) !== '') {
                    $seo[$c[0]] = mb_substr($v, 0, $limits[$c[0]]);
                }
            }
            if (! $seo) {
                continue;
            }
            if (isset($seo['body']) && ! str_contains($seo['body'], '<')) {
                // متن ساده → پاراگراف‌های HTML
                $seo['body'] = implode('', array_map(fn ($p) => '<p>'.e(trim($p)).'</p>', array_filter(preg_split('/\R+/u', $seo['body']), fn ($p) => trim($p) !== '')));
            }
            $map[Excel::key($code)] = $seo;
            if ($made && ($p = Product::query()->where('import_id', $id)->where('sku', $code)->first())) {
                $p->fill(array_filter([
                    'seo_title' => $seo['title'] ?? null, 'seo_description' => $seo['desc'] ?? null, 'focus_keyword' => $seo['kw'] ?? null,
                    'short_description' => $seo['short'] ?? null, 'description' => $seo['body'] ?? null,
                ], fn ($v) => $v !== null))->save();
            }
            $n++;
        }
        is_dir(static::dir($id)) || @mkdir(static::dir($id), 0775, true);
        file_put_contents(static::dir($id).'/seo.json', json_encode($map, JSON_UNESCAPED_UNICODE));

        return ['filled' => $n, 'total' => count(static::seoSource($id)), 'applied' => $made];
    }

    /** پاک کردن فایل‌های موقت (تصاویر و اکسل)؛ گزارش مغایرت‌ها می‌ماند */
    public static function cleanup(int $id, bool $all = true): void
    {
        $d = static::dir($id);
        foreach (['img', 'excel'] as $sub) {
            foreach (glob($d.'/'.$sub.'/*') ?: [] as $f) {
                @unlink($f);
            }
            @rmdir($d.'/'.$sub);
        }
        if ($all) {
            @unlink($d.'/plan.json');
            @unlink($d.'/seo.json');
            @rmdir($d);
        }
    }
}
