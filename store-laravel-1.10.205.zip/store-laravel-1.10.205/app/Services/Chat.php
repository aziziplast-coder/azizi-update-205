<?php

namespace App\Services;

use App\Models\ChatMessage;
use App\Models\ChatThread;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Support\ImageCompressor;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * گفتگوی مسئول سفارش با مشتری.
 *
 * سبک برای هاست اشتراکی:
 *  - «پیام تازه هست؟» از یک فایل کوچک ثابت (uploads/_chat/t-توکن.json) خوانده می‌شود که وب‌سرور مستقیم و با 304 می‌دهد؛
 *    نه PHP اجرا می‌شود، نه دیتابیس. فقط وقتی شماره آن عوض شد پیام‌ها از سایت گرفته می‌شود.
 *  - وقتی صفحه گفتگو بسته است هیچ درخواستی نیست؛ خبر با نوتیفیکیشن (و پیامک کم‌تکرار) می‌رسد.
 *  - «در حال نوشتن…» با یک اسکریپت چندخطی بدون لاراول (public/chat-t.php) در همان فایل ثبت می‌شود.
 */
class Chat
{
    public const SIDES = ['c' => 'مشتری', 's' => 'همکار', 'n' => 'یادداشت داخلی', 'x' => 'خودکار'];

    /** پاسخ به پیام (ریپلای): شناسه پیامی که پیام بعدی به آن جواب می‌دهد (کنترلر پیش از ارسال تنظیم می‌کند) */
    public static ?int $reply = null;

    /** شناسه یکتای پیام از گوشی (جلوگیری از پیام تکراری هنگام ارسال دوباره) */
    public static ?string $clientKey = null;

    public static function clientKey(?string $k): ?string
    {
        $k = substr(preg_replace('/[^A-Za-z0-9]/', '', (string) $k), 0, 40);
        static::$clientKey = strlen($k) >= 8 ? $k : null;

        return static::$clientKey;
    }

    /** این پیام قبلاً رسیده؟ (پاسخ قبلی در اینترنت ضعیف گم شده بود) */
    public static function alreadyGot(ChatThread $t): bool
    {
        if (! static::$clientKey || ! static::hasCk()) {
            return false;
        }

        return ChatMessage::query()->where('thread_id', $t->id)->where('client_key', static::$clientKey)->exists();
    }

    /** خلاصه پیام نقل‌شده برای نمایش بالای پاسخ */
    protected static function quote(ChatThread $t, int $id, string $side): ?array
    {
        $q = ChatMessage::query()->where('thread_id', $t->id)->whereKey($id)->first();
        if (! $q || $q->kind === 'event' || in_array($q->kind, ['pay', 'cheq'], true) || ($q->side === 'n' && $side === 'c')) {
            return null;
        }
        $u = $q->user_id ? User::query()->find($q->user_id) : null;
        $text = match ($q->kind) {
            'image' => '📷 عکس'.($q->body ? ': '.$q->body : ''), 'voice' => '🎤 پیام صوتی', 'video' => '🎬 ویدیو'.($q->body ? ': '.$q->body : ''),
            'product' => '🛒 '.(((array) $q->meta)['name'] ?? 'کالا'), 'confirm' => '❓ '.$q->body, 'invoice' => '🧾 فاکتور',
            default => (string) $q->body,
        };

        return ['id' => (int) $q->id, 's' => $q->side, 'fn' => $q->side === 'c' ? '' : static::firstName($u), 'n' => $q->side === 'c' ? (string) $t->order?->customer_name : ($u?->displayName() ?? ''),
            't' => mb_substr(trim(preg_replace('/\s+/u', ' ', $text)), 0, 120), 'img' => $q->kind === 'image' && ! empty(((array) $q->meta)['path']) && empty(((array) $q->meta)['gone']) ? url('uploads/'.((array) $q->meta)['path']) : null];
    }

    protected static function hasCk(): bool
    {
        static $h = null;

        return $h ??= \App\Support\DbSchema::hasColumn('chat_messages', 'client_key');
    }

    public static function ready(): bool
    {
        static $ok = null;

        return $ok ??= \App\Support\DbSchema::hasTable('chat_threads');
    }

    public static function enabled(): bool
    {
        return (bool) setting('chat_enabled', true) && static::ready();
    }

    public static function cfg(): array
    {
        return [
            'alert_min' => max(0, (int) setting('chat_alert_min', 30)),
            'hours_on' => (bool) setting('chat_hours_on', false),
            'from' => (string) setting('chat_hours_from', '08:30'),
            'to' => (string) setting('chat_hours_to', '18:00'),
            'off_days' => array_map('intval', (array) setting('chat_off_days', [5])),
            'off_text' => (string) (setting('chat_off_text') ?: 'الان خارج از ساعت کاری هستیم؛ پیامتان را بگذارید، از {from} پاسخ می‌دهیم.'),
            'close_days' => max(0, (int) setting('chat_close_days', 7)),
            'img_days' => max(0, (int) setting('chat_img_days', 90)),
            'sms' => (bool) setting('chat_sms', true),
            'del_min' => max(0, (int) setting('chat_del_min', 60)), // مهلت حذف پیام توسط فرستنده (دقیقه؛ صفر = همیشه)
            'quick' => array_values(array_filter((array) (setting('chat_quick') ?? \App\Filament\Pages\Settings\ChatSettings::QUICK), fn ($q) => trim((string) ($q['text'] ?? '')) !== '')),
        ];
    }

    /** سفارش بدون مسئول چاپ نشود (کلید مدیر کل) */
    /** ثبت «فاکتور کامل از گفتگو چاپ شد» (تکرار همان همکار در ۳ دقیقه یک بار حساب می‌شود) */
    public static function markPrinted(\App\Models\Order $o, \App\Models\User $u): void
    {
        $recent = \App\Models\OrderEvent::query()->where('order_id', $o->id)->where('user_id', $u->id)
            ->where('message', 'like', '🖨 فاکتور کامل از گفتگو چاپ شد%')->where('created_at', '>', now()->subMinutes(3))->exists();
        if (! $recent) {
            $o->log('🖨 فاکتور کامل از گفتگو چاپ شد — '.$u->displayName(), $u->id);
        }
    }

    public static function printLocked(Order $o): bool
    {
        return (bool) setting('print_needs_assignee', true) && ! $o->assignee_id;
    }

    /* =================== دسترسی =================== */

    public static function canView(?User $u, Order $o): bool
    {
        return $u && static::enabled() && $u->hasPerm('chats') && ($u->isAdmin() || ((int) $o->assignee_id === (int) $u->id && $o->assignee_id));
    }

    /** پیام به مشتری فقط از طرف مسئول همان سفارش */
    public static function canSend(?User $u, Order $o): bool
    {
        return $u && static::enabled() && $u->hasPerm('chats') && $o->assignee_id && (int) $o->assignee_id === (int) $u->id;
    }

    /** یادداشت داخلی و سپردن گفتگو: مسئول یا مدیر کل */
    public static function canManage(?User $u, Order $o): bool
    {
        return $u && static::enabled() && $u->hasPerm('chats') && ($u->isAdmin() || (int) $o->assignee_id === (int) $u->id);
    }

    /* =================== گفتگو =================== */

    /** فقط گفتگوهای سفارش (نه گفتگوی کارخانه‌دارها) */
    public static function orders(): \Illuminate\Database\Eloquent\Builder
    {
        static $fac = null, $team = null;
        $fac ??= \App\Support\DbSchema::hasColumn('chat_threads', 'factory_id');
        $team ??= \App\Support\DbSchema::hasColumn('chat_threads', 'team_user_id');

        return ChatThread::query()->when($fac, fn ($q) => $q->whereNull('factory_id'))->when($team, fn ($q) => $q->whereNull('team_user_id')); // گفتگوی کارخانه‌دار و گپ داخلی جدا
    }

    public static function thread(Order $o, bool $create = true): ?ChatThread
    {
        $t = ChatThread::query()->where('order_id', $o->id)->first();
        if (! $t && $create) {
            try {
                $t = ChatThread::query()->create([
                    'order_id' => $o->id, 'user_id' => $o->user_id, 'assignee_id' => $o->assignee_id, 'token' => Str::random(32),
                ]);
            } catch (Throwable) {
                $t = ChatThread::query()->where('order_id', $o->id)->first(); // ساخت هم‌زمان
            }
            if ($t) {
                static::signal($t);
            }
        }

        return $t;
    }

    public static function closed(ChatThread $t, ?Order $o = null): bool
    {
        if ($t->closed_at) {
            return true;
        }
        $o ??= $t->order;
        $days = static::cfg()['close_days'];

        return $days > 0 && $o && in_array($o->status, ['completed', 'cancelled', 'failed'], true)
            && $o->status_changed_at && $o->status_changed_at->lt(now()->subDays($days));
    }

    /** اسم کوچک همکار برای مشتری: «مریم» */
    public static function firstName(?User $u): string
    {
        if (! $u) {
            return 'پشتیبانی';
        }
        $n = trim((string) $u->name);

        return $n !== '' ? (string) preg_split('/\s+/u', $n)[0] : 'پشتیبانی';
    }

    /** خارج از ساعت کاری: متن پیام، وگرنه null */
    public static function offHours(): ?string
    {
        $c = static::cfg();
        if (! $c['hours_on']) {
            return null;
        }
        $now = now('Asia/Tehran');
        $hm = $now->format('H:i');
        $off = in_array((int) $now->dayOfWeek, $c['off_days'], true) || $hm < $c['from'] || $hm >= $c['to'];

        return $off ? str_replace(['{from}', '{to}'], [fa($c['from']), fa($c['to'])], $c['off_text']) : null;
    }

    /**
     * ثبت پیام
     *
     * @param  string  $side  c|s|n|x
     */
    public static function post(ChatThread $t, string $side, ?User $by, string $kind, ?string $body, array $meta = []): ChatMessage
    {
        $body = $body !== null ? mb_substr(trim($body), 0, 4000) : null;
        if (static::$reply && in_array($side, ['c', 's', 'n'], true) && in_array($kind, ['text', 'image', 'voice', 'video'], true)) {
            if ($rt = static::quote($t, static::$reply, $side)) {
                $meta['rt'] = $rt;
            }
            static::$reply = null;
        }
        $ck = in_array($side, ['c', 's', 'n'], true) ? static::$clientKey : null;
        static::$clientKey = null;
        $m = ChatMessage::query()->create([
            'thread_id' => $t->id, 'side' => $side, 'user_id' => $by?->id, 'kind' => $kind, 'body' => $body ?: null,
            ...($ck && static::hasCk() ? ['client_key' => $ck] : []),
            'meta' => $meta ?: null, 'created_at' => now(),
        ]);
        $preview = match ($kind) {
            'image' => '📷 عکس', 'product' => '🛒 '.($meta['name'] ?? 'کالا'), 'confirm' => '❓ '.($body ?? ''), 'invoice' => '🧾 فاکتور',
            'pay' => '💳 '.($meta['label'] ?? 'مبلغ قابل پرداخت'), 'cheq' => '🧾 مشخصات چک‌ها', 'voice' => '🎤 پیام صوتی', 'video' => '🎬 ویدیو',
            default => (string) $body,
        };
        if ($side === 'n') {
            // یادداشت داخلی: شماره «آخرین پیام» مشتری عوض نمی‌شود (مشتری چیزی نمی‌گیرد)؛ همکار از کلید n می‌فهمد
            static::signal($t, ['n' => (int) $m->id]);

            return $m;
        }
        $upd = ['last_id' => $m->id, 'last_at' => $m->created_at, 'last_side' => $side, 'last_text' => mb_substr($preview, 0, 150)];
        if ($side === 'c') {
            $upd['unread_staff'] = DB::raw('unread_staff + 1');
            if (! $t->awaiting_since) {
                $upd['awaiting_since'] = $m->created_at;
            }
        } elseif ($side === 's') {
            $upd['unread_customer'] = DB::raw('unread_customer + 1');
            if ($t->awaiting_since) {
                $sec = max(0, $m->created_at->getTimestamp() - $t->awaiting_since->getTimestamp());
                $upd['awaiting_since'] = null;
                $upd['alerted_at'] = null;
                $upd['replies'] = DB::raw('replies + 1');
                $upd['reply_sec_sum'] = DB::raw('reply_sec_sum + '.(int) $sec);
                if ($t->first_reply_sec === null) {
                    $upd['first_reply_sec'] = $sec;
                }
            }
            $upd['staff_read_id'] = $m->id; // کسی که جواب می‌دهد پیام‌ها را خوانده
            $upd['unread_staff'] = 0;
        } elseif ($side === 'x') {
            $upd['unread_customer'] = DB::raw('unread_customer + 1');
        }
        ChatThread::query()->whereKey($t->id)->update($upd);
        $t->refresh();
        static::signal($t, $side === 'c' ? ['tc' => 0] : ($side === 's' ? ['ts' => 0] : []));
        static::staffSignal($t->assignee_id);

        return $m;
    }

    /* =================== حذف پیام اشتباه =================== */

    public const DELETABLE = ['text', 'image', 'voice', 'video'];

    /**
     * آیا این بیننده می‌تواند پیام را حذف کند؟ فقط فرستنده، فقط پیام معمولی، و در مهلت تنظیم‌شده.
     * $side: c (مشتری/کارخانه‌دار) یا s (همکار)
     */
    public static function canDelete(ChatMessage $m, string $side, ?User $u): bool
    {
        if (! in_array($m->kind, static::DELETABLE, true) || ! empty(((array) $m->meta)['del'])) {
            return false;
        }
        $mine = $side === 'c' ? $m->side === 'c' : (in_array($m->side, ['s', 'n'], true) && $u && (int) $m->user_id === (int) $u->id);
        if (! $mine) {
            return false;
        }
        $min = static::cfg()['del_min'];

        return $min === 0 || Carbon::parse($m->created_at)->gt(now()->subMinutes($min));
    }

    /* =================== ویرایش و لایک پیام =================== */

    /** ویرایش: فقط پیام متنی خود و در همان مهلت حذف */
    public static function canEdit(ChatMessage $m, string $side, ?User $u): bool
    {
        return $m->kind === 'text' && static::canDelete($m, $side, $u);
    }

    public static function editMsg(ChatMessage $m, string $text): void
    {
        $text = mb_substr(trim($text), 0, 4000);
        if ($text === '' || $text === (string) $m->body) {
            return;
        }
        $meta = (array) $m->meta;
        $meta['ed'] = 1;
        $m->forceFill(['body' => $text, 'meta' => $meta])->save();
        $t = ChatThread::query()->find($m->thread_id);
        if ($t) {
            if ((int) $t->last_id === (int) $m->id) {
                ChatThread::query()->whereKey($t->id)->update(['last_text' => mb_substr($text, 0, 150)]);
            }
            static::signal($t->refresh(), ['d' => (int) round(microtime(true) * 10)]);
            static::staffSignal($t->assignee_id);
        }
    }

    /** لایک: هر پیام معمولی (نه پیام سیستمی و نه یادداشت داخلی برای مشتری) */
    public static function canLike(ChatMessage $m, string $side): bool
    {
        return in_array($m->kind, static::DELETABLE, true) && empty(((array) $m->meta)['del'])
            && in_array($m->side, ['c', 's', 'n'], true) && ! ($side === 'c' && $m->side === 'n');
    }

    /** لایک / برداشتن لایک ($side: c مشتری، s همکاران) */
    public static function like(ChatMessage $m, string $side): void
    {
        $meta = (array) $m->meta;
        $lk = (array) ($meta['lk'] ?? []);
        if (! empty($lk[$side])) {
            unset($lk[$side]);
        } else {
            $lk[$side] = 1;
        }
        if ($lk) {
            $meta['lk'] = $lk;
        } else {
            unset($meta['lk']);
        }
        $m->forceFill(['meta' => $meta ?: null])->save();
        if ($t = ChatThread::query()->find($m->thread_id)) {
            static::signal($t, ['d' => (int) round(microtime(true) * 10)]);
            static::staffSignal($t->assignee_id);
        }
    }

    /** پیام به «این پیام حذف شد» تبدیل می‌شود (فایلش هم پاک می‌شود) و طرف مقابل همان لحظه می‌بیند */
    public static function remove(ChatMessage $m): void
    {
        $meta = (array) $m->meta;
        foreach (['path', 'poster'] as $k) {
            if (! empty($meta[$k]) && ! str_starts_with((string) $meta[$k], 'http')) {
                @unlink(public_path('uploads/'.$meta[$k]));
            }
        }
        $was = $m->kind;
        $m->forceFill(['kind' => 'text', 'body' => '🚫 این پیام حذف شد', 'meta' => ['del' => 1, 'was' => $was]])->save();
        $t = ChatThread::query()->find($m->thread_id);
        if (! $t) {
            return;
        }
        if ((int) $t->last_id === (int) $m->id) {
            ChatThread::query()->whereKey($t->id)->update(['last_text' => '🚫 این پیام حذف شد']);
        }
        // پیام خوانده‌نشده‌ای که حذف شد، از شمارنده طرف مقابل کم شود
        $col = $m->side === 'c' ? 'unread_staff' : ($m->side === 's' ? 'unread_customer' : null);
        $read = $m->side === 'c' ? (int) $t->staff_read_id : (int) $t->customer_read_id;
        if ($col && $m->id > $read && $t->{$col} > 0) {
            ChatThread::query()->whereKey($t->id)->update([$col => DB::raw($col.' - 1')]);
        }
        $t->refresh();
        static::signal($t, ['d' => (int) round(microtime(true) * 10)]);
        static::staffSignal($t->assignee_id);
    }

    /* =================== سیگنال (فایل ثابت) =================== */

    public static function dir(): string
    {
        $d = public_path('uploads/_chat');
        if (! is_dir($d)) {
            @mkdir($d, 0755, true);
            @file_put_contents($d.'/index.html', '');
            // مرورگر هر بار فقط «تغییر کرده؟» می‌پرسد (پاسخ 304، بدون PHP)
            @file_put_contents($d.'/.htaccess', "<IfModule mod_headers.c>\n  Header set Cache-Control \"no-cache\"\n</IfModule>\nOptions -Indexes\n");
        }

        return $d;
    }

    public static function signalUrl(ChatThread $t): string
    {
        return url('chat-s.php').'?k='.$t->token;
    }

    /** فایل کوچک وضعیت گفتگو: شماره آخرین پیام، خوانده‌شدن‌ها و «در حال نوشتن» */
    public static function signal(ChatThread $t, array $extra = []): void
    {
        try {
            $f = static::dir().'/t-'.$t->token.'.json';
            $fh = @fopen($f, 'c+');
            if (! $fh) {
                return;
            }
            flock($fh, LOCK_EX);
            $cur = json_decode((string) stream_get_contents($fh), true) ?: [];
            $data = array_merge(['tc' => 0, 'ts' => 0], $cur, [
                'v' => (int) $t->last_id, 'r' => (int) $t->customer_read_id, 's' => (int) $t->staff_read_id, 'c' => $t->closed_at ? 1 : 0, 'now' => time(),
            ], $extra);
            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, json_encode($data));
            fflush($fh);
            flock($fh, LOCK_UN);
            fclose($fh);
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** توکن فایل صندوق هر همکار (تعداد خوانده‌نشده) */
    public static function staffToken(int $userId): string
    {
        return substr(hash_hmac('sha256', 'chat-inbox-'.$userId, (string) config('app.key')), 0, 32);
    }

    public static function staffSignalUrl(int $userId): string
    {
        return url('chat-s.php').'?u='.static::staffToken($userId);
    }

    /** به‌روز کردن شمارنده خوانده‌نشده‌های همکار (و همه مدیرها) */
    public static function staffSignal(?int $assigneeId): void
    {
        try {
            $ids = User::query()->where('role', 'admin')->where('is_active', true)->pluck('id')->all();
            if ($assigneeId) {
                $ids[] = (int) $assigneeId;
            }
            foreach (array_unique($ids) as $uid) {
                $u = User::query()->find($uid);
                if (! $u) {
                    continue;
                }
                $q = static::orders()->where('unread_staff', '>', 0)->whereNull('closed_at');
                if (! $u->isAdmin()) {
                    $q->where('assignee_id', $u->id);
                }
                $n = (int) $q->sum('unread_staff');
                @file_put_contents(static::dir().'/u-'.static::staffToken($uid).'.json', json_encode(['n' => $n, 't' => time()]), LOCK_EX);
            }
            \Illuminate\Support\Facades\Cache::forget('chat.badge');
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** نشان کنار منوی «گفتگوها» */
    public static function unreadFor(User $u): int
    {
        if (! static::enabled()) {
            return 0;
        }
        $q = static::orders()->where('unread_staff', '>', 0)->whereNull('closed_at');
        if (! $u->isAdmin()) {
            $q->where('assignee_id', $u->id);
        }

        return (int) $q->sum('unread_staff');
    }

    /* =================== خواندن =================== */

    public static function markRead(ChatThread $t, string $side): void
    {
        if ($side === 'c' && ($t->customer_read_id < $t->last_id || $t->unread_customer)) {
            ChatThread::query()->whereKey($t->id)->update(['customer_read_id' => $t->last_id, 'unread_customer' => 0]);
        } elseif ($side === 's' && ($t->staff_read_id < $t->last_id || $t->unread_staff)) {
            ChatThread::query()->whereKey($t->id)->update(['staff_read_id' => $t->last_id, 'unread_staff' => 0]);
        } else {
            return;
        }
        $t->refresh();
        static::signal($t);
        if ($side === 's') {
            static::staffSignal($t->assignee_id);
        }
    }

    /**
     * پیام‌ها برای نمایش
     *
     * @return array<int, array>
     */
    public static function messages(ChatThread $t, int $after = 0, bool $staff = false, int $limit = 60, int $before = 0): array
    {
        $q = ChatMessage::query()->where('thread_id', $t->id)->where('id', '>', $after);
        if ($before > 0) {
            $q->where('id', '<', $before);
        }
        if (! $staff) {
            $q->where('side', '!=', 'n');
        }
        $rows = $after ? $q->orderBy('id')->limit(300)->get() : $q->orderByDesc('id')->limit($limit)->get()->reverse()->values();
        $users = User::query()->whereIn('id', $rows->pluck('user_id')->filter()->unique())->get()->keyBy('id');
        // کارت‌های مالی همیشه با وضعیت لحظه‌ای
        $pays = ChatFinance::payCards($rows->where('kind', 'pay')->map(fn ($m) => (int) (((array) $m->meta)['pid'] ?? 0))->filter()->values()->all(), $staff);
        $cheq = $rows->contains('kind', 'cheq') && $t->order ? ChatFinance::chequeData($t->order, $staff) : null;

        return $rows->map(function (ChatMessage $m) use ($users, $staff, $pays, $cheq) {
            $u = $m->user_id ? $users->get($m->user_id) : null;
            $at = Carbon::parse($m->created_at)->timezone('Asia/Tehran');
            $meta = (array) $m->meta;
            if (in_array($m->kind, ['image', 'voice', 'video'], true) && ! empty($meta['path'])) {
                $meta['url'] = empty($meta['gone']) ? url('uploads/'.$meta['path']) : null;
                if (! empty($meta['poster']) && empty($meta['gone'])) {
                    $meta['poster'] = url('uploads/'.$meta['poster']);
                }
                unset($meta['path']);
            }
            if ($m->kind === 'pay') {
                $meta['card'] = $pays[(int) ($meta['pid'] ?? 0)] ?? null;
            } elseif ($m->kind === 'cheq') {
                $meta['card'] = $cheq;
            }

            return [
                'id' => (int) $m->id, 'side' => $m->side, 'kind' => $m->kind, 'body' => (string) $m->body, 'meta' => (object) $meta,
                'name' => $m->side === 's' || $m->side === 'n' ? ($staff ? ($u?->displayName() ?? '') : static::firstName($u)) : '',
                'time' => fa($at->format('H:i')), 'day' => \App\Support\Jalali::format($at, false),
                'ts' => $at->getTimestamp(), ...($staff && $m->user_id ? ['u' => (int) $m->user_id] : []),
            ];
        })->all();
    }

    /* =================== پیام‌های ویژه =================== */

    /** عکس: کوچک و فشرده روی هاست (عکس‌های قدیمی خودکار پاک می‌شوند) */
    public static function storeImage(UploadedFile $f): array
    {
        if (! $f->isValid() || $f->getSize() > 12 * 1024 * 1024) {
            throw new RuntimeException('عکس معتبر نیست یا بیشتر از ۱۲ مگابایت است.');
        }
        $body = (string) file_get_contents($f->getRealPath());
        if (! @getimagesizefromstring($body)) {
            throw new RuntimeException('فقط عکس (JPG، PNG، WebP) قابل ارسال است.');
        }
        $c = ImageCompressor::compress($body, 1400, 80);
        $rel = 'chat/'.date('Y-m').'/'.Str::random(28).'.'.($c['ext'] === 'png' ? 'png' : ($c['ext'] === 'webp' ? 'webp' : 'jpg'));
        $abs = public_path('uploads/'.$rel);
        is_dir(dirname($abs)) || @mkdir(dirname($abs), 0755, true);
        file_put_contents($abs, $c['body']);
        $info = @getimagesizefromstring($c['body']);

        return ['path' => $rel, 'w' => (int) ($info[0] ?? 0), 'h' => (int) ($info[1] ?? 0)];
    }

    /** محدودیت‌های ویس و ویدیو */
    public static function mediaCfg(): array
    {
        return [
            'voice' => (bool) setting('chat_voice', true), 'voice_sec' => max(10, min(600, (int) setting('chat_voice_sec', 120))),
            'video' => (bool) setting('chat_video', true), 'video_sec' => max(10, min(300, (int) setting('chat_video_sec', 90))),
        ];
    }

    /** پیام صوتی (فایل کوچک ضبط مرورگر) */
    public static function storeVoice(UploadedFile $f, int $sec): array
    {
        $c = static::mediaCfg();
        if (! $c['voice']) {
            throw new RuntimeException('ارسال پیام صوتی خاموش است.');
        }
        if (! $f->isValid() || $f->getSize() < 200 || $f->getSize() > 6 * 1024 * 1024) {
            throw new RuntimeException('پیام صوتی معتبر نیست یا خیلی طولانی است.');
        }
        $head = (string) file_get_contents($f->getRealPath(), false, null, 0, 12);
        $ext = match (true) {
            str_starts_with($head, "\x1A\x45\xDF\xA3") => 'webm',
            str_starts_with($head, 'OggS') => 'ogg',
            substr($head, 4, 4) === 'ftyp' => 'm4a',
            str_starts_with($head, 'ID3') || str_starts_with($head, "\xFF\xFB") => 'mp3',
            default => throw new RuntimeException('قالب پیام صوتی شناخته نشد.'),
        };
        $rel = 'chat/'.date('Y-m').'/'.Str::random(28).'.'.$ext;
        $abs = public_path('uploads/'.$rel);
        is_dir(dirname($abs)) || @mkdir(dirname($abs), 0755, true);
        $f->move(dirname($abs), basename($abs));

        return ['path' => $rel, 'sec' => max(1, min($c['voice_sec'] + 5, $sec)), 'size' => (int) @filesize($abs)];
    }

    /** پوشه موقت تکه‌های ویدیو */
    protected static function upPath(int $userId, string $uid): string
    {
        abort_unless(preg_match('/^[A-Za-z0-9]{16,40}$/', $uid), 422);
        $d = storage_path('app/chat-up');
        is_dir($d) || @mkdir($d, 0755, true);

        return $d.'/'.$userId.'-'.$uid.'.part';
    }

    /**
     * بارگذاری تکه‌تکه ویدیو (هر تکه ~۱.۵ مگابایت؛ به محدودیت آپلود هاست نمی‌خورد)
     *
     * @return int حجم دریافت‌شده تا الان
     */
    public static function chunk(int $userId, string $uid, int $i, UploadedFile $part): int
    {
        $f = static::upPath($userId, $uid);
        $have = is_file($f) ? (int) filesize($f) : 0;
        if ($i === 0 && $have) {
            @unlink($f);
            $have = 0;
        }
        if (! $part->isValid() || $part->getSize() > 4 * 1024 * 1024 || $have + $part->getSize() > 80 * 1024 * 1024) {
            throw new RuntimeException('ویدیو خیلی بزرگ است.');
        }
        file_put_contents($f, file_get_contents($part->getRealPath()), FILE_APPEND | LOCK_EX);

        return $have + (int) $part->getSize();
    }

    /** ویدیوی کامل (فشرده‌شده در گوشی) + تصویر پیش‌نمایش */
    public static function storeVideo(int $userId, string $uid, ?UploadedFile $poster, array $info): array
    {
        $c = static::mediaCfg();
        $f = static::upPath($userId, $uid);
        if (! $c['video']) {
            @unlink($f);
            throw new RuntimeException('ارسال ویدیو خاموش است.');
        }
        if (! is_file($f) || filesize($f) < 1000) {
            throw new RuntimeException('ویدیو کامل نرسید؛ دوباره بفرستید.');
        }
        $head = (string) file_get_contents($f, false, null, 0, 12);
        $ext = substr($head, 4, 4) === 'ftyp' ? 'mp4' : (str_starts_with($head, "\x1A\x45\xDF\xA3") ? 'webm' : null);
        if (! $ext) {
            @unlink($f);
            throw new RuntimeException('قالب ویدیو شناخته نشد (فقط MP4).');
        }
        $name = Str::random(28);
        $rel = 'chat/'.date('Y-m').'/'.$name.'.'.$ext;
        $abs = public_path('uploads/'.$rel);
        is_dir(dirname($abs)) || @mkdir(dirname($abs), 0755, true);
        rename($f, $abs);
        $meta = ['path' => $rel, 'sec' => max(1, min($c['video_sec'] + 5, (int) ($info['sec'] ?? 0))), 'w' => (int) ($info['w'] ?? 0), 'h' => (int) ($info['h'] ?? 0), 'size' => (int) filesize($abs)];
        if ($poster && $poster->isValid() && $poster->getSize() < 2 * 1024 * 1024 && @getimagesize($poster->getRealPath())) {
            $pc = ImageCompressor::compress((string) file_get_contents($poster->getRealPath()), 720, 72);
            $prel = 'chat/'.date('Y-m').'/'.$name.'-p.jpg';
            file_put_contents(public_path('uploads/'.$prel), $pc['body']);
            $meta['poster'] = $prel;
        }

        return $meta;
    }

    /** کارت کالا (پیشنهاد افزودن/جایگزینی) */
    public static function productMeta(Product $p, string $mode, int $qty, ?int $replaces = null): array
    {
        $mode = $mode === Product::RETAIL && $p->retailAllowed() ? Product::RETAIL : Product::CARTON;
        $pc = max(1, (int) $p->per_carton);
        $units = $mode === Product::CARTON && $pc > 1 ? max(1, $qty) * $pc : max(1, $qty);

        return [
            'pid' => $p->id, 'name' => $p->name, 'img' => $p->image ? thumb($p->image, 240) : null, 'url' => $p->url(),
            'mode' => $mode, 'qty' => max(1, $qty), 'units' => $units, 'pc' => $pc, 'price' => (int) $p->unitPrice($mode),
            'total' => (int) $p->unitPrice($mode) * $units, 'pf' => money((int) $p->unitPrice($mode)), 'tf' => money((int) $p->unitPrice($mode) * $units), 'avail' => $p->isAvailable(), 'replaces' => $replaces, 'st' => 'offer',
            'label' => $mode === Product::CARTON && $pc > 1 ? fa(max(1, $qty)).' کارتن ('.fa($units).' عدد)' : fa($units).' عدد',
        ];
    }

    /** افزودن کالای تأییدشده مشتری به سفارش (با یک لمس مسئول) */
    public static function applyOffer(ChatMessage $m, User $by): void
    {
        $meta = (array) $m->meta;
        if ($m->kind !== 'product' || ($meta['st'] ?? '') !== 'accepted') {
            throw new RuntimeException('این پیشنهاد هنوز تأیید مشتری را ندارد یا قبلاً اعمال شده است.');
        }
        $t = $m->thread;
        $o = $t->order;
        $p = Product::query()->find((int) $meta['pid']);
        if (! $p) {
            throw new RuntimeException('کالا دیگر وجود ندارد.');
        }
        DB::transaction(function () use ($o, $p, $meta) {
            $o->items()->create([
                'product_id' => $p->id, 'name' => $p->name, 'barcode' => $p->barcode, 'image' => $p->image, 'mode' => $meta['mode'],
                'units' => (int) $meta['units'], 'per_carton' => $p->per_carton, 'unit_label' => $p->unit_label, 'unit_price' => (int) $meta['price'], 'compare_price' => null,
                'total' => (int) $meta['price'] * (int) $meta['units'], 'warehouse_id' => $p->warehouseFor($meta['mode']),
                'replaces_item_id' => $meta['replaces'] ?? null, 'ordered_units' => (int) $meta['units'],
            ]);
            $col = $meta['mode'] === Product::RETAIL ? 'retail_stock' : 'stock';
            if ($o->stock_reduced && $p->{$col} !== null && Product::counts()) {
                $p->{$col} -= (int) $meta['units'];
                $p->saveQuietly();
            }
            Picking::recalc($o);
        });
        $meta['st'] = 'applied';
        $m->update(['meta' => $meta]);
        $o->refresh();
        $o->log('از گفتگو: «'.$p->name.'» ('.$meta['label'].') با تأیید مشتری به سفارش اضافه شد. مبلغ سفارش: '.money($o->total).' تومان', $by->id);
        static::post($t, 'x', null, 'event', '«'.$p->name.'» ('.$meta['label'].') به سفارش اضافه شد. مبلغ جدید سفارش: '.money($o->total).' تومان');
    }

    /** متن پیام آماده با جای‌گذاری {name} {order} {tracking} {total} {staff} {shop} */
    public static function fill(string $text, Order $o, ?User $staff): string
    {
        return strtr($text, [
            '{name}' => (string) preg_split('/\s+/u', trim((string) $o->customer_name))[0], '{order}' => fa($o->number),
            '{tracking}' => fa((string) $o->tracking_code), '{total}' => money($o->total), '{staff}' => static::firstName($staff), '{shop}' => store_name(),
            '{status}' => $o->statusLabel(),
        ]);
    }

    /* =================== خبر دادن =================== */

    /** پیام مشتری ← مسئول (اگر مسئول ندارد، مدیرها) */
    public static function notifyStaff(ChatThread $t, Order $o, string $text): void
    {
        $ids = $o->assignee_id ? [(int) $o->assignee_id] : User::query()->where('role', 'admin')->where('is_active', true)->pluck('id')->all();
        app(WebPush::class)->toUsers($ids, [
            'title' => '💬 '.$o->customer_name.' — سفارش '.fa($o->number), 'body' => mb_substr($text, 0, 120),
            'url' => url('/admin/chats?o='.$o->id), 'tag' => 'chat-'.$o->id,
        ]);
    }

    /** پیام همکار ← مشتری: نوتیفیکیشن؛ و پیامک (حداکثر هر ۳ ساعت یک بار، وقتی پیام قبلی را هم نخوانده) */
    public static function notifyCustomer(ChatThread $t, Order $o, string $text, ?User $staff): void
    {
        if ($o->user_id) {
            app(WebPush::class)->toUsers([(int) $o->user_id], [
                'title' => static::firstName($staff).' از '.store_name(), 'body' => mb_substr($text, 0, 120),
                'url' => route('order.show', $o->number).'#chat', 'tag' => 'chat-'.$o->id,
            ]);
        }
        $c = static::cfg();
        if (! $c['sms'] || ! $o->mobile || ($t->sms_at && $t->sms_at->gt(now()->subHours(3)))) {
            return;
        }
        ChatThread::query()->whereKey($t->id)->update(['sms_at' => now()]);
        $link = route('order.show', $o->number).'#chat';
        \App\Support\AfterResponse::run(function () use ($o, $staff, $link) {
            try {
                app(Sms::class)->sendText($o->mobile, static::firstName($staff).' از '.store_name().' درباره سفارش '.fa($o->number).' برایتان پیام فرستاد:'."\n".$link, 'chat');
            } catch (Throwable $e) {
                report($e);
            }
        });
    }

    /* =================== رویدادهای سفارش =================== */

    /** خط خودکار در گفتگو (فقط اگر گفتگو از قبل هست) */
    /** هشدار «به شماره حساب‌های قبلی واریز نکنید» (اول گفتگو و پس از جمع‌آوری بار) */
    public const WARN_START = "⚠️ توجه مهم درباره واریز\nبرای هر مرحله (بیعانه و تسویه) فقط به شماره حسابی واریز کنید که در همین گفتگو برای همان مرحله صادر می‌شود. به هیچ عنوان به شماره حساب‌های قبلی (حتی حساب بیعانه همین سفارش یا سفارش‌های قبلی) واریز نکنید؛ آن حساب‌ها ممکن است برای شخص دیگری بوده و حواله‌اش بسته شده باشد.\nدر صورت واریز به شماره حساب‌های قبلی، {store} هیچ مسئولیتی نسبت به عودت آن از دریافت‌کننده ندارد.";

    public const WARN_DEPOSIT = "✅ فیش بیعانه شما تأیید شد.\n⚠️ دقت کنید: برای تکمیل وجه، از قبل هیچ پولی واریز نکنید و منتظر بمانید تا بعد از جمع‌آوری بار، شماره حساب مانده در همین گفتگو برای شما صادر شود.\nدر صورت واریز پول بدون هماهنگی، پول شما قابل پیگیری نیست و {store} هیچ مسئولیتی در قبال آن ندارد.";

    public const WARN_SETTLE = "⚠️ لطفاً تا صدور مانده حساب هیچ مبلغی واریز نکنید.
مانده حساب با شماره حساب واریز همین‌جا برایتان صادر و پیامک می‌شود (ممکن است همان حساب بیعانه باشد یا حساب دیگری)؛ فقط به حسابی واریز کنید که روی کارت مانده حساب نوشته شده.
در صورت واریز بدون هماهنگی، {store} هیچ مسئولیتی در قبال آن ندارد.";

    public static function warn(Order $o, string $key): void
    {
        try {
            if (! static::enabled() || ! in_array($key, ['start', 'deposit', 'settle'], true) || ! ($t = static::thread($o, true))) {
                return;
            }
            // هر هشدار یک بار برای هر سفارش
            if (ChatMessage::query()->where('thread_id', $t->id)->where('kind', 'event')->where('meta', 'like', '%"warn":"'.$key.'"%')->exists()) {
                return;
            }
            $def = ['start' => self::WARN_START, 'deposit' => self::WARN_DEPOSIT, 'settle' => self::WARN_SETTLE][$key];
            $tpl = trim((string) setting('chat_warn_'.$key)) ?: $def;
            static::post($t, 'x', null, 'event', strtr($tpl, ['{store}' => store_name()]), ['warn' => $key]);
        } catch (Throwable $e) {
            report($e);
        }
    }

    public static function event(Order $o, string $text): void
    {
        try {
            if (! static::enabled() || ! ($t = static::thread($o, false))) {
                return;
            }
            static::post($t, 'x', null, 'event', $text);
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** تغییر مسئول سفارش: گفتگو هم به مسئول تازه می‌رسد */
    public static function reassigned(Order $o): void
    {
        try {
            if (! static::ready() || ! ($t = static::thread($o, false))) {
                return;
            }
            $old = $t->assignee_id;
            $t->update(['assignee_id' => $o->assignee_id]);
            $u = $o->assignee_id ? User::query()->find($o->assignee_id) : null;
            static::post($t, 'x', null, 'event', $u ? static::firstName($u).' مسئول پیگیری سفارش شما شد.' : 'گفتگو به‌زودی به همکار دیگری سپرده می‌شود.');
            static::staffSignal($old);
            if ($u && $t->awaiting_since) {
                static::notifyStaff($t, $o, 'گفتگوی سفارش به شما سپرده شد و پیام بی‌جواب دارد.');
            }
        } catch (Throwable $e) {
            report($e);
        }
    }

    /* =================== کارهای دوره‌ای (هر ۵ دقیقه) =================== */

    public static function tick(): array
    {
        if (! static::enabled()) {
            return [];
        }
        $done = [];
        $c = static::cfg();
        // هشدار پیام بی‌جواب
        if ($c['alert_min'] > 0 && ! static::offHours()) {
            $late = static::orders()->with('order')->whereNull('closed_at')->whereNotNull('awaiting_since')
                ->where('awaiting_since', '<', now()->subMinutes($c['alert_min']))->where(fn ($q) => $q->whereNull('alerted_at')->orWhereColumn('alerted_at', '<', 'awaiting_since'))
                ->limit(50)->get();
            foreach ($late as $t) {
                $o = $t->order;
                if (! $o) {
                    continue;
                }
                $mins = (int) $t->awaiting_since->diffInMinutes(now(), true);
                $ids = User::query()->where('role', 'admin')->where('is_active', true)->pluck('id')->all();
                if ($o->assignee_id) {
                    $ids[] = (int) $o->assignee_id;
                }
                app(WebPush::class)->toUsers(array_unique($ids), [
                    'title' => '⏰ پیام بی‌جواب — سفارش '.fa($o->number), 'body' => $o->customer_name.' '.fa($mins).' دقیقه است منتظر پاسخ است'.($o->assignee ? ' (مسئول: '.$o->assignee->displayName().')' : ' (بدون مسئول)'),
                    'url' => url('/admin/chats?o='.$o->id), 'tag' => 'chat-late-'.$o->id,
                ]);
                $t->update(['alerted_at' => now()]);
            }
            if ($late->isNotEmpty()) {
                $done[] = 'chat-late:'.$late->count();
            }
        }
        // بستن گفتگوی سفارش‌های تمام‌شده
        if ($c['close_days'] > 0) {
            $ids = ChatThread::query()->whereNull('closed_at')->whereHas('order', fn ($q) => $q->whereIn('status', ['completed', 'cancelled', 'failed'])->where('status_changed_at', '<', now()->subDays($c['close_days'])))->limit(200)->pluck('id');
            foreach ($ids as $id) {
                ChatThread::query()->whereKey($id)->update(['closed_at' => now(), 'unread_staff' => 0, 'awaiting_since' => null]);
                static::signal(ChatThread::query()->find($id));
            }
            if ($ids->isNotEmpty()) {
                $done[] = 'chat-closed:'.$ids->count();
            }
        }
        // پاک کردن عکس‌های قدیمی (متن پیام‌ها می‌ماند)
        if ($c['img_days'] > 0 && \Illuminate\Support\Facades\Cache::add('chat.imgclean', 1, 86400)) {
            $n = 0;
            ChatMessage::query()->whereIn('kind', ['image', 'voice', 'video'])->where('created_at', '<', now()->subDays($c['img_days']))->orderBy('id')
                ->chunkById(200, function ($rows) use (&$n) {
                    foreach ($rows as $m) {
                        $meta = (array) $m->meta;
                        if (! empty($meta['gone'])) {
                            continue;
                        }
                        foreach (['path', 'poster'] as $k) {
                            if (! empty($meta[$k])) {
                                @unlink(public_path('uploads/'.$meta[$k]));
                            }
                        }
                        $meta['gone'] = 1;
                        $m->update(['meta' => $meta]);
                        $n++;
                    }
                });
            if ($n) {
                $done[] = 'chat-img:'.$n;
            }
        }

        // تکه‌های ویدیوی نیمه‌کاره
        foreach (glob(storage_path('app/chat-up/*.part')) ?: [] as $f) {
            if (filemtime($f) < time() - 86400) {
                @unlink($f);
            }
        }

        return $done;
    }

    /* =================== گزارش مدیر =================== */

    public static function stats(): array
    {
        $rows = static::orders()->whereNotNull('assignee_id')->where('created_at', '>=', now()->subDays(30))
            ->selectRaw('assignee_id, count(*) n, sum(replies) r, sum(reply_sec_sum) s, avg(first_reply_sec) f, sum(case when awaiting_since is not null and closed_at is null then 1 else 0 end) w')
            ->groupBy('assignee_id')->get()->keyBy('assignee_id');
        $rate = \App\Models\SurveyResponse::query()->whereNotNull('assignee_id')->where('status', 'done')->where('created_at', '>=', now()->subDays(90))
            ->selectRaw('assignee_id, count(*) n, avg(staff_rating) sr, avg(rating) r')->groupBy('assignee_id')->get()->keyBy('assignee_id');
        $ids = $rows->keys()->merge($rate->keys())->unique();
        $users = User::query()->whereIn('id', $ids)->get()->keyBy('id');
        $out = [];
        foreach ($ids as $id) {
            $r = $rows->get($id);
            $s = $rate->get($id);
            $out[] = [
                'name' => $users->get($id)?->displayName() ?? '#'.$id,
                'threads' => (int) ($r->n ?? 0), 'waiting' => (int) ($r->w ?? 0),
                'avg_reply' => ($r && $r->r) ? (int) round($r->s / $r->r) : null, 'first_reply' => $r && $r->f !== null ? (int) round($r->f) : null,
                'rating' => $s && $s->sr ? round((float) $s->sr, 1) : ($s && $s->r ? round((float) $s->r, 1) : null), 'votes' => (int) ($s->n ?? 0),
            ];
        }
        usort($out, fn ($a, $b) => $b['threads'] <=> $a['threads']);

        return [
            'open' => static::orders()->whereNull('closed_at')->where('last_at', '>=', now()->subDays(7))->count(),
            'waiting' => static::orders()->whereNull('closed_at')->whereNotNull('awaiting_since')->count(),
            'unassigned' => static::orders()->whereNull('closed_at')->whereNull('assignee_id')->whereNotNull('awaiting_since')->count(),
            'staff' => $out,
        ];
    }

    public static function dur(?int $sec): string
    {
        if ($sec === null) {
            return '—';
        }
        if ($sec < 60) {
            return fa($sec).' ثانیه';
        }
        if ($sec < 3600) {
            return fa((int) round($sec / 60)).' دقیقه';
        }

        return fa(round($sec / 3600, 1)).' ساعت';
    }
}
