<?php

namespace App\Services;

use App\Models\Order;
use Illuminate\Support\Facades\Http;
use RuntimeException;
use Throwable;

/**
 * درگاه پرداخت آنلاین: زرین‌پال (v4) و زیبال. مبالغ سایت تومان است و به ریال ارسال می‌شود.
 */
class Payment
{
    public static function providers(): array
    {
        return ['zarinpal' => 'زرین‌پال', 'zibal' => 'زیبال'];
    }

    protected function config(): array
    {
        return (array) setting('pay_gateway', []);
    }

    /** @return string آدرس انتقال به درگاه */
    public function start(Order $order): string
    {
        $c = $this->config();
        $amount = (int) $order->total * 10;
        $callback = route('payment.callback', $order->number);
        $sandbox = ! empty($c['sandbox']);
        try {
            if (($c['provider'] ?? 'zarinpal') === 'zibal') {
                $r = Http::timeout(20)->acceptJson()->post('https://gateway.zibal.ir/v1/request', [
                    'merchant' => $sandbox ? 'zibal' : $c['merchant'],
                    'amount' => $amount,
                    'callbackUrl' => $callback,
                    'orderId' => $order->number,
                    'mobile' => $order->mobile,
                    'description' => 'سفارش '.$order->number,
                ])->json();
                if ((int) ($r['result'] ?? 0) !== 100) {
                    throw new RuntimeException($r['message'] ?? 'خطای درگاه زیبال');
                }
                $order->update(['payment_meta' => ['authority' => (string) $r['trackId'], 'provider' => 'zibal']]);

                return 'https://gateway.zibal.ir/start/'.$r['trackId'];
            }

            $host = $sandbox ? 'https://sandbox.zarinpal.com' : 'https://payment.zarinpal.com';
            $r = Http::timeout(20)->acceptJson()->post($host.'/pg/v4/payment/request.json', [
                'merchant_id' => $c['merchant'],
                'amount' => $amount,
                'callback_url' => $callback,
                'description' => 'سفارش '.$order->number,
                'metadata' => ['mobile' => $order->mobile, 'order_id' => $order->number],
            ])->json();
            if ((int) ($r['data']['code'] ?? 0) !== 100) {
                $err = $r['errors']['message'] ?? ($r['errors'][0]['message'] ?? 'خطای درگاه زرین‌پال');
                throw new RuntimeException(is_string($err) ? $err : 'خطای درگاه');
            }
            $order->update(['payment_meta' => ['authority' => $r['data']['authority'], 'provider' => 'zarinpal']]);

            return $host.'/pg/StartPay/'.$r['data']['authority'];
        } catch (RuntimeException $e) {
            throw $e;
        } catch (Throwable $e) {
            throw new RuntimeException('اتصال به درگاه برقرار نشد: '.$e->getMessage());
        }
    }

    /** @return array{ok: bool, ref: string, msg: string} */
    public function verify(Order $order, array $query): array
    {
        $c = $this->config();
        $meta = (array) $order->payment_meta;
        $amount = (int) $order->total * 10;
        $sandbox = ! empty($c['sandbox']);
        try {
            if (($meta['provider'] ?? '') === 'zibal') {
                if ((string) ($query['success'] ?? '') !== '1') {
                    return ['ok' => false, 'ref' => '', 'msg' => 'پرداخت لغو شد یا ناموفق بود.'];
                }
                $r = Http::timeout(20)->acceptJson()->post('https://gateway.zibal.ir/v1/verify', [
                    'merchant' => $sandbox ? 'zibal' : $c['merchant'],
                    'trackId' => $meta['authority'] ?? ($query['trackId'] ?? ''),
                ])->json();
                $code = (int) ($r['result'] ?? 0);
                if (in_array($code, [100, 201], true) && (int) ($r['amount'] ?? $amount) === $amount) {
                    return ['ok' => true, 'ref' => (string) ($r['refNumber'] ?? $meta['authority']), 'msg' => 'پرداخت موفق'];
                }

                return ['ok' => false, 'ref' => '', 'msg' => $r['message'] ?? 'پرداخت تأیید نشد.'];
            }

            if (($query['Status'] ?? '') !== 'OK') {
                return ['ok' => false, 'ref' => '', 'msg' => 'پرداخت لغو شد یا ناموفق بود.'];
            }
            $host = $sandbox ? 'https://sandbox.zarinpal.com' : 'https://payment.zarinpal.com';
            $r = Http::timeout(20)->acceptJson()->post($host.'/pg/v4/payment/verify.json', [
                'merchant_id' => $c['merchant'],
                'amount' => $amount,
                'authority' => $meta['authority'] ?? ($query['Authority'] ?? ''),
            ])->json();
            $code = (int) ($r['data']['code'] ?? 0);
            if (in_array($code, [100, 101], true)) {
                return ['ok' => true, 'ref' => (string) ($r['data']['ref_id'] ?? ''), 'msg' => 'پرداخت موفق'];
            }

            return ['ok' => false, 'ref' => '', 'msg' => 'پرداخت تأیید نشد (کد '.($r['errors']['code'] ?? $code).').'];
        } catch (Throwable $e) {
            return ['ok' => false, 'ref' => '', 'msg' => 'اتصال به درگاه برای تأیید پرداخت برقرار نشد.'];
        }
    }
}
