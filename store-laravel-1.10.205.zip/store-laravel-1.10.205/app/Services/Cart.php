<?php

namespace App\Services;

use App\Models\CartRecord;
use App\Models\Product;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use Throwable;

/**
 * سبد خرید ماندگار در پایگاه داده: «شناسه:حالت» => تعداد (عدد).
 * مهمان با کوکی شناخته می‌شود و مشتری با حسابش؛ با بستن مرورگر یا تمام شدن نشست، سبد پاک نمی‌شود.
 * حالت carton: مضرب «تعداد در کارتن» با قیمت عمده؛ حالت retail: کمتر از یک کارتن با قیمت خرد.
 */
class Cart
{
    protected const KEY = 'cart';

    public const COOKIE = 'cart_t';

    protected ?Collection $lines = null;

    protected ?CartRecord $rec = null;

    protected bool $loaded = false;

    /** هنگام ثبت ویرایش سفارش، موجودی رزرو شده قبلاً برگشته است */
    public bool $ignoreReserved = false;

    protected ?array $reserved = null;

    /** کار روی یک سبد مشخص (مثلاً ثبت خودکار سبد ویرایش در زمان‌بند) */
    public function useRecord(CartRecord $rec): static
    {
        $this->loaded = true;
        $this->rec = $rec;
        $this->lines = null;
        $this->reserved = null;
        $this->orderUnits = null;

        return $this;
    }

    /** سفارشی که مشتری در حال ویرایش آن است */
    public function editingOrder(): ?\App\Models\Order
    {
        $rec = $this->record();
        $id = $rec?->edit_order_id;

        // در زمان‌بند (ثبت خودکار سبد ویرایش) کاربری وارد نشده؛ صاحب سبد ملاک است
        return $id ? \App\Models\Order::query()->where('user_id', $rec->user_id ?: auth()->id())->find($id) : null;
    }

    /** تعداد رزرو شده توسط سفارش در حال ویرایش (برای محاسبه موجودی قابل خرید) */
    public function reserved(): array
    {
        if ($this->reserved !== null) {
            return $this->reserved;
        }
        $this->reserved = [];
        $o = $this->editingOrder();
        if ($o && $o->stock_reduced) {
            foreach ($o->items as $it) {
                $k = $it->product_id.':'.$it->cartMode();
                $this->reserved[$k] = ($this->reserved[$k] ?? 0) + (int) $it->units;
            }
        }

        return $this->reserved;
    }

    protected ?array $orderUnits = null;

    /** تعداد هر ردیف در سفارشی که الان در حال ویرایش است (کلید سبد ← تعداد) */
    public function orderUnits(): array
    {
        if ($this->orderUnits !== null) {
            return $this->orderUnits;
        }
        $this->orderUnits = [];
        try {
            foreach ($this->editingOrder()?->items ?? [] as $it) {
                if ($it->product_id && (int) $it->units > 0) {
                    $k = $it->product_id.':'.$it->cartMode();
                    $this->orderUnits[$k] = ($this->orderUnits[$k] ?? 0) + (int) $it->units;
                }
            }
        } catch (Throwable $e) {
            report($e);
        }

        return $this->orderUnits;
    }

    /** رکورد سبد فعلی (در صورت نیاز ساخته می‌شود) */
    public function record(bool $create = false): ?CartRecord
    {
        if (! $this->loaded) {
            $this->loaded = true;
            try {
                $this->rec = $this->find();
            } catch (Throwable $e) {
                $this->rec = null; // پیش از اجرای migration
            }
        }
        if (! $this->rec && $create) {
            try {
                $st = $this->sessionToken();
                $this->rec = CartRecord::create([
                    'token' => $st && ! CartRecord::query()->where('token', $st)->exists() ? $st : Str::random(40),
                    'user_id' => auth()->id(),
                    'items' => [],
                    'last_activity_at' => now(),
                ]);
                $this->remember($this->rec);
            } catch (Throwable $e) {
                return null;
            }
        }

        return $this->rec;
    }

    protected function find(): ?CartRecord
    {
        $user = auth()->user();
        $token = (string) request()->cookie(self::COOKIE, '');
        $rec = null;
        if ($user) {
            $rec = CartRecord::query()->where('user_id', $user->id)->whereNull('order_id')->latest('id')->first();
        }
        if (! $rec && $token !== '') {
            $rec = CartRecord::query()->where('token', $token)->whereNull('order_id')->first();
            if ($rec && $user && ! $rec->user_id) {
                $rec->user_id = $user->id;
                $rec->save();
            } elseif ($rec && $user && (int) $rec->user_id !== (int) $user->id) {
                $rec = null;
            }
        }
        // درخواست هم‌زمانی که هنوز کوکی سبد را نگرفته: سبد همین نشست
        if (! $rec && ! $user && $token === '' && ($st = $this->sessionToken())) {
            $rec = CartRecord::query()->where('token', $st)->whereNull('order_id')->first();
        }
        // سبدهای قدیمی که در نشست بودند
        if (! $rec && ($legacy = (array) session(self::KEY, []))) {
            $rec = CartRecord::create(['token' => Str::random(40), 'user_id' => $user?->id, 'items' => $legacy, 'items_count' => count($legacy), 'last_activity_at' => now()]);
            session()->forget(self::KEY);
        }
        if ($rec && $rec->token !== $token) {
            $this->remember($rec);
        }

        return $rec;
    }

    protected function remember(CartRecord $rec): void
    {
        Cookie::queue(self::COOKIE, $rec->token, 60 * 24 * max(7, (int) setting('cart_keep_days', 90)));
    }

    /** بعد از ورود: سبد مهمان با سبد قبلی حساب یکی می‌شود */
    public static function mergeOnLogin(\App\Models\User $user): void
    {
        try {
            $token = (string) request()->cookie(self::COOKIE, '');
            $guest = $token !== '' ? CartRecord::query()->where('token', $token)->whereNull('order_id')->first() : null;
            if (! $guest || (int) $guest->user_id === (int) $user->id) {
                return;
            }
            if ($guest->user_id) {
                return; // سبد کاربر دیگری روی همین دستگاه
            }
            $own = CartRecord::query()->where('user_id', $user->id)->whereNull('order_id')->latest('id')->first();
            if (! $own) {
                $guest->update(['user_id' => $user->id]);

                return;
            }
            $items = (array) $own->items;
            foreach ((array) $guest->items as $k => $u) {
                $items[$k] = max((int) ($items[$k] ?? 0), (int) $u);
            }
            $own->update(['items' => $items, 'items_count' => count($items), 'last_activity_at' => now()]);
            $guest->delete();
        } catch (Throwable $e) {
            report($e);
        }
    }

    public function raw(): array
    {
        return (array) ($this->record()?->items ?? []);
    }

    protected function save(array $raw): void
    {
        $this->lines = null;
        $rec = $this->record($raw !== []);
        if (! $rec) {
            session([self::KEY => $raw]);

            return;
        }
        $rec->items = $raw;
        $this->reserved = null;
        $rec->items_count = count($raw);
        $rec->last_activity_at = now();
        if (! $raw) {
            $rec->stage = 'cart';
            $rec->total = 0;
            $rec->edit_order_id = null;
        }
        $rec->save();
    }

    /** آیا کاربر فعلی کارمند است؟ (بدون محدودیت سبد) */
    public static function unlimited(): bool
    {
        // پیش‌فرض: حداقل سفارش برای همه (حتی کارمندانی که برای آزمایش یا مشتری سفارش می‌گذارند) اعمال می‌شود
        if (! setting('min_order_staff_exempt', false)) {
            return false;
        }
        $u = auth()->user();

        return $u && method_exists($u, 'isStaffLike') && $u->isStaffLike();
    }

    /**
     * تعیین تعداد یک کالا در سبد (۰ = حذف). تعداد به نزدیک‌ترین مقدار مجاز اصلاح می‌شود.
     *
     * @return array{ok: bool, units: int, msg: string}
     */
    /** کلید قفل سبد: حساب کاربر، وگرنه توکن سبد، وگرنه نشست مرورگر */
    protected function lockKey(): string
    {
        if ($id = auth()->id()) {
            return 'cart-lock:u'.$id;
        }
        $t = (string) request()->cookie(self::COOKIE, '');
        if ($t !== '') {
            return 'cart-lock:t'.sha1($t);
        }

        return 'cart-lock:s'.sha1(request()->hasSession() ? request()->session()->getId() : (string) request()->ip());
    }

    /** توکن ثابت سبد مهمانِ تازه از روی نشست: درخواست‌های هم‌زمانِ پیش از رسیدن کوکی، همه یک سبد را پیدا می‌کنند */
    protected function sessionToken(): ?string
    {
        if (auth()->id() || ! request()->hasSession() || (string) request()->session()->getId() === '') {
            return null;
        }

        return 's'.substr(hash_hmac('sha256', request()->session()->getId(), (string) config('app.key')), 0, 50);
    }

    /**
     * تغییر تعداد یک کالا در سبد — با قفل: چند درخواست پشت‌سرهم (مثلاً «+» سریع یا افزودن چند کالا)
     * هیچ‌وقت تغییر هم را بازنویسی نمی‌کنند و سبد همیشه از آخرین حالت پایگاه داده خوانده می‌شود.
     */
    public function set(int $productId, string $mode, int $units): array
    {
        $lock = Cache::lock($this->lockKey(), 15);
        $own = false;
        try {
            $own = (bool) $lock->block(8);
        } catch (\Illuminate\Contracts\Cache\LockTimeoutException) {
        } catch (Throwable $e) {
            report($e);
        }
        try {
            // حالت تازه از پایگاه داده (نه نسخه‌ای که پیش از قفل خوانده شده)
            $this->loaded = false;
            $this->rec = null;
            $this->lines = null;
            $this->reserved = null;

            return $this->setNow($productId, $mode, $units);
        } finally {
            if ($own) {
                $lock->release();
            }
        }
    }

    protected function setNow(int $productId, string $mode, int $units): array
    {
        $mode = $mode === Product::RETAIL ? Product::RETAIL : Product::CARTON;
        $raw = $this->raw();
        $key = $productId.':'.$mode;

        if ($units <= 0) {
            unset($raw[$key]);
            $this->save($raw);

            return ['ok' => true, 'units' => 0, 'msg' => 'از سبد حذف شد.'];
        }

        $p = Product::query()->active()->find($productId);
        if (! $p) {
            unset($raw[$key]);
            $this->save($raw);

            return ['ok' => false, 'units' => 0, 'msg' => 'این کالا دیگر موجود نیست.'];
        }

        [$units, $msg] = $this->clamp($p, $mode, $units);
        if ($units <= 0) {
            unset($raw[$key]);
            $this->save($raw);

            return ['ok' => false, 'units' => 0, 'msg' => $msg ?: 'این کالا در این حالت قابل خرید نیست.'];
        }
        // هر کالا فقط با یک حالت در سبد: کارتنی یا تکی
        $other = $productId.':'.($mode === Product::RETAIL ? Product::CARTON : Product::RETAIL);
        if (isset($raw[$other]) && setting('cart_single_mode', true)) {
            unset($raw[$other]);
            $msg = trim($msg.' خرید '.($mode === Product::RETAIL ? 'کارتنی' : 'خرده').' این کالا از سبد برداشته شد؛ هر کالا فقط به یک حالت خریده می‌شود.');
        }
        $isNew = ! isset($raw[$key]);
        $raw[$key] = $units;
        // قیمت لحظه افزودن (برای نمایش «از زمان افزودن گران/ارزان شد»)
        if ($isNew) {
            $this->notePrice($key, $p->unitPrice($mode));
        }
        $this->save($raw);

        return ['ok' => true, 'units' => $units, 'msg' => $msg];
    }

    /** @return array{0: int, 1: string} */
    public function clamp(Product $p, string $mode, int $units): array
    {
        $msg = '';
        $r = $this->ignoreReserved ? 0 : ($this->reserved()[$p->id.':'.$mode] ?? 0);
        if ($r > 0) {
            $p = clone $p;
            $col = $mode === Product::RETAIL ? 'retail_stock' : 'stock';
            if ($p->{$col} !== null && Product::counts()) {
                $p->{$col} += $r;
            }
        }
        if ($mode === Product::RETAIL) {
            if (! $p->retailAvailable()) {
                return [0, 'خرید خرده این کالا فعلاً ممکن نیست.'];
            }
            if (static::unlimited()) {
                return [$units, ''];
            }
            $max = $p->retailMaxUnits();
            if ($units > $max) {
                $units = $max;
                $msg = 'حداکثر خرید خرده این کالا '.fa($max).' '.$p->unitName().' است.';
            }

            return [$units, $msg];
        }

        if (! $p->cartonAvailable()) {
            return [0, $p->hasCartons() ? 'خرید کارتنی این کالا فعلاً ممکن نیست.' : 'این کالا ناموجود است.'];
        }
        // حداقل خرید و گام (کارتن کامل، یا قانون انبار/کالا: بسته‌ای یا فله)
        [$min, $step, $custom] = $p->buyRule();
        $n = $p->per_carton;
        // تعدادی که همین الان در سفارشِ در حال ویرایش هست، با قانون تازه خرید (حداقل/گام) دست نمی‌خورد
        $had = $this->orderUnits()[$p->id.':'.$mode] ?? 0;
        $rounded = $had > 0 && $units === $had ? $units : ($units <= $min ? $min : (int) ($min + round(($units - $min) / $step) * $step));
        if ($rounded !== $units) {
            $msg = $custom
                ? ($units < $min ? 'حداقل خرید این کالا '.fa($min).' '.$p->unitName().' است.' : 'تعداد به '.fa($rounded).' '.$p->unitName().' اصلاح شد.')
                : 'تعداد به '.fa($rounded / $n).' کارتن اصلاح شد.';
        }
        $units = $rounded;
        if (static::unlimited()) {
            return [$units, $msg];
        }
        $max = $p->cartonMaxUnits();
        if ($max >= 0 && $units > $max) {
            $units = $max;
            $msg = $custom ? 'موجودی این کالا '.fa($max).' '.$p->unitName().' است.' : 'موجودی این کالا '.fa($max / $n).' '.$p->cartonUnit().' است.';
        }

        return [$units, $msg];
    }

    /**
     * ویرایش سفارش: اقلام سفارش به سبد منتقل می‌شوند (قیمت هنگام سفارش هم ثبت می‌شود تا تغییر قیمت در سبد نشان داده شود)
     */
    public function loadOrder(\App\Models\Order $order): void
    {
        $items = [];
        $prices = [];
        foreach ($order->items as $it) {
            if ($it->product_id && (int) $it->units > 0) {
                // «تکی» نمایشیِ کالای ۱عددی در اصل کارتنی است؛ وگرنه در سبد «خرید خرده ممکن نیست» حذف می‌شد
                $k = $it->product_id.':'.$it->cartMode();
                $items[$k] = ($items[$k] ?? 0) + (int) $it->units;
                $prices[$k] = (int) $it->unit_price;
            }
        }
        $rec = $this->record(true);
        foreach ((array) $rec->items as $k => $u) { // کالاهایی که از قبل در سبد بود هم اضافه می‌شوند
            $items[$k] = max((int) ($items[$k] ?? 0), (int) $u);
        }
        $rec->update(['items' => $items, 'items_count' => count($items), 'edit_order_id' => $order->id, 'last_activity_at' => now(),
            'prices' => array_merge((array) $rec->prices, $prices)]);
        $this->loaded = false;
        $this->rec = null;
        $this->lines = null;
        $this->orderUnits = null;
        $this->reserved = null;
    }

    /**
     * ردیف‌های سبد با قیمت و موجودی فعلی (ردیف نامعتبر حذف/اصلاح می‌شود).
     *
     * @return Collection<int, object>
     */
    public function lines(): Collection
    {
        if ($this->lines !== null) {
            return $this->lines;
        }
        $raw = $this->raw();
        if (! $raw) {
            return $this->lines = collect();
        }
        $ids = array_unique(array_map(fn ($k) => (int) explode(':', $k)[0], array_keys($raw)));
        $products = Product::query()->active()->with('category')->whereIn('id', $ids)->get()->keyBy('id');
        $prices = (array) ($this->record()?->prices ?? []);
        $lines = collect();
        $changed = false;
        foreach ($raw as $key => $units) {
            [$id, $mode] = array_pad(explode(':', $key), 2, Product::CARTON);
            $p = $products->get((int) $id);
            if (! $p) {
                unset($raw[$key]);
                $changed = true;
                $this->noteRemoved((int) $id, $mode, (int) $units, null);

                continue;
            }
            [$fixed] = $this->clamp($p, $mode, (int) $units);
            if ($fixed <= 0) {
                unset($raw[$key]);
                $changed = true;
                $this->noteRemoved($p->id, $mode, (int) $units, $p);

                continue;
            }
            if ($fixed < (int) $units) {
                $this->noteRemoved($p->id, $mode, (int) $units, $p, $fixed);
            }
            if ($fixed !== (int) $units) {
                $raw[$key] = $fixed;
                $changed = true;
            }
            $unit = $p->unitPrice($mode);
            $retail = $mode === Product::RETAIL;
            [$bMin, $bStep, $bCustom] = $p->buyRule();
            $lines->push((object) [
                'key' => $key,
                'product' => $p,
                'mode' => $mode,
                'retail' => $retail,
                'units' => $fixed,
                'cartons' => $retail || $bCustom ? 0 : intdiv($fixed, $p->per_carton),
                'step' => $retail ? 1 : $bStep,
                'min' => $retail ? 1 : $bMin,
                'custom' => ! $retail && $bCustom,
                'max' => $retail ? $p->retailMaxUnits() : $p->cartonMaxUnits(),
                'unit_price' => $unit,
                'compare_price' => (! $retail && $p->compare_price > $unit) ? $p->compare_price : null,
                'total' => $unit * $fixed,
                'tag' => $retail ? 'خرده' : ($bCustom ? 'عمده' : ($p->hasCartons() ? 'کارتنی' : $p->unitName().'ی')),
                'qty' => $retail || ! $p->hasCartons() || $bCustom
                    ? fa($fixed).' '.$p->unitName()
                    : fa(intdiv($fixed, $p->per_carton)).' کارتن × '.fa($p->per_carton).' = '.fa($fixed).' '.$p->unitName(),
                'was_price' => ($w = (int) ($prices[$key] ?? 0)) && $w !== $unit ? $w : null,
            ]);
        }
        if ($changed) {
            $this->save($raw);
        }

        return $this->lines = $lines;
    }

    /** ثبت کالای حذف‌شده یا کم‌شده از سبد (برای پاپ‌آپ «تمام شد» و پیشنهاد جایگزین) */
    protected function noteRemoved(int $id, string $mode, int $units, ?Product $p, ?int $left = null): void
    {
        try {
            $p ??= Product::query()->find($id);
            if (! $p || ! app()->bound('session')) {
                return;
            }
            $list = (array) session('cart.removed', []);
            $list[$id.':'.$mode] = [
                'id' => $p->id, 'name' => $p->name, 'image' => $p->image, 'price' => (int) $p->unitPrice($mode), 'category_id' => $p->category_id,
                'mode' => $mode, 'units' => $units, 'left' => $left, 'per_carton' => (int) $p->per_carton, 'code' => $p->sku ?: $p->barcode,
            ];
            session(['cart.removed' => $list]);
        } catch (\Throwable) {
        }
    }

    /** ثبت قیمت لحظه افزودن یک ردیف */
    protected function notePrice(string $key, int $price): void
    {
        $rec = $this->record(true);
        if (! $rec) {
            return;
        }
        $prices = (array) ($rec->prices ?? []);
        $prices[$key] = $price;
        $rec->prices = $prices;
    }

    /** تغییر قیمت ردیف‌ها از زمان افزودن: [تعداد ردیف، جمع اختلاف] */
    public function priceChanges(): array
    {
        $n = 0;
        $diff = 0;
        foreach ($this->lines() as $l) {
            if ($l->was_price) {
                $n++;
                $diff += ($l->unit_price - $l->was_price) * $l->units;
            }
        }

        return ['count' => $n, 'diff' => $diff];
    }

    /** مشتری تغییر قیمت‌ها را دید: قیمت‌های فعلی مبنای مقایسه بعدی می‌شوند */
    public function ackPrices(): void
    {
        $rec = $this->record();
        if (! $rec) {
            return;
        }
        $prices = [];
        foreach ($this->lines() as $l) {
            $prices[$l->key] = (int) $l->unit_price;
        }
        $rec->prices = $prices;
        $rec->save();
        $this->lines = null;
    }

    public function count(): int
    {
        return count($this->raw());
    }

    public function isEmpty(): bool
    {
        return $this->count() === 0;
    }

    public function clear(): void
    {
        $this->save([]);
    }

    /** بعد از ثبت سفارش: این سبد بسته می‌شود و دفعه بعد سبد تازه ساخته می‌شود */
    public function close(int $orderId): void
    {
        $rec = $this->record();
        if ($rec) {
            $rec->update(['order_id' => $orderId, 'stage' => 'placed', 'last_activity_at' => now(), 'edit_order_id' => null]);
        }
        session()->forget(self::KEY);
        $this->rec = null;
        $this->reserved = null;
        $this->lines = null;
    }

    /** ثبت مرحله‌ای که مشتری به آن رسیده (برای گزارش سبدهای رها شده) */
    public function track(string $stage, array $info = []): void
    {
        if ($this->isEmpty()) {
            return;
        }
        $this->record()?->advance($stage, $info);
    }

    /** نقشه برای کارت‌ها: {id: {carton: units, retail: units}} */
    public function map(): array
    {
        $out = [];
        foreach ($this->raw() as $key => $units) {
            [$id, $mode] = array_pad(explode(':', $key), 2, Product::CARTON);
            $out[$id][$mode] = (int) $units;
        }

        return $out;
    }

    public function itemsTotal(): int
    {
        return (int) $this->lines()->sum('total');
    }

    /** مجموع صرفه‌جویی نسبت به قیمت قبل از تخفیف */
    public function discountTotal(): int
    {
        return (int) $this->lines()->sum(fn ($l) => $l->compare_price ? ($l->compare_price - $l->unit_price) * $l->units : 0);
    }

    public function cartonsTotal(): int
    {
        return (int) $this->lines()->sum('cartons');
    }

    /** نتیجه کد تخفیف فعلی سبد */
    public function coupon(): ?array
    {
        $code = Coupons::current();
        if (! $code || $this->isEmpty()) {
            return null;
        }

        return Coupons::evaluate($code, $this->lines(), auth()->user());
    }

    /** خلاصه کامل با هزینه ارسال، کد تخفیف و هزینه‌های جانبی */
    public function totals(?string $shippingId = null): array
    {
        $items = $this->itemsTotal();
        $coupon = $this->coupon();
        $couponOff = $coupon && $coupon['ok'] ? $coupon['discount'] : 0;
        $freeShip = $coupon && $coupon['ok'] && $coupon['free_shipping'];
        $ship = Checkout::shippingMethod($shippingId);
        $shipCost = $ship && ! $freeShip ? Checkout::shippingCost($ship, $items) : 0;
        $fees = Checkout::fees($items, $this->cartonsTotal());
        $feesTotal = array_sum(array_column($fees, 'amount'));

        return [
            'items' => $items,
            'discount' => $this->discountTotal(),
            'coupon' => $coupon,
            'coupon_discount' => $couponOff,
            'free_shipping' => $freeShip,
            'shipping' => $ship,
            'shipping_cost' => $shipCost,
            'shipping_label' => $ship ? Checkout::shippingText($ship, $items, (bool) $freeShip) : '',
            'fees' => $fees,
            'fees_total' => $feesTotal,
            'total' => max(0, $items - $couponOff) + $shipCost + $feesTotal,
            'count' => $this->count(),
        ];
    }

    /** پاسخ JSON برای درخواست‌های سبد */
    /** پاسخ سبک افزودن به سبد (بدون محاسبه کوپن، ارسال و کارمزد — فقط آنچه صفحه لازم دارد) */
    public function payload(): array
    {
        $items = $this->itemsTotal();
        $count = $this->count();
        $rec = $this->record();
        if ($rec && (int) $rec->total !== $items) {
            $rec->total = $items;
            $rec->saveQuietly();
        }

        return [
            'count' => $count,
            'countFa' => fa($count),
            'map' => $this->map(),
            'items' => $items,
            'itemsFa' => money($items),
            'totalFa' => money($items),
        ];
    }
}
