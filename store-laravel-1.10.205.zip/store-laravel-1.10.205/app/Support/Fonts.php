<?php

namespace App\Support;

class Fonts
{
    public static function options(): array
    {
        return [
            'vazirmatn' => 'وزیرمتن',
            'shabnam' => 'شبنم',
            'sahel' => 'ساحل',
            'samim' => 'صمیم',
            'custom' => 'فونت دلخواه (آپلود فایل، مثلاً یکان بخ)',
        ];
    }

    public static function family(): string
    {
        return match (setting('font', 'vazirmatn')) {
            'shabnam' => 'Shabnam',
            'sahel' => 'Sahel',
            'samim' => 'Samim',
            'custom' => setting('custom_font_regular') ? 'StoreFont' : 'Vazirmatn',
            default => 'Vazirmatn',
        };
    }

    public static function stack(): string
    {
        return '"'.static::family().'", Vazirmatn, Tahoma, sans-serif';
    }

    /** @font-face فونت آپلودشده */
    public static function customCss(): string
    {
        if (setting('font') !== 'custom' || ! setting('custom_font_regular')) {
            return '';
        }
        $css = '@font-face{font-family:StoreFont;src:url('.upload_url(setting('custom_font_regular')).');font-weight:300 500;font-display:swap}';
        $bold = setting('custom_font_bold') ?: setting('custom_font_regular');
        $css .= '@font-face{font-family:StoreFont;src:url('.upload_url($bold).');font-weight:600 900;font-display:swap}';

        return $css;
    }
}
