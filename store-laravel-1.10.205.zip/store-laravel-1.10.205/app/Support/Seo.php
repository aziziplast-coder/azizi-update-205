<?php

namespace App\Support;

/** بررسی سئوی محصول: چراغ سبز/قرمز برای هر مورد */
class Seo
{
    /** @return array<int, array{0: string, 1: bool, 2: string}> */
    public static function productChecks(array $d): array
    {
        $title = trim((string) (($d['seo_title'] ?? '') ?: ($d['name'] ?? '')));
        $meta = trim((string) (($d['seo_description'] ?? '') ?: ($d['short_description'] ?? '')));
        $desc = trim(preg_replace('/\s+/u', ' ', strip_tags((string) ($d['description'] ?? ''))));
        $tl = mb_strlen($title);
        $ml = mb_strlen($meta);
        $dl = mb_strlen($desc);
        $gallery = array_filter((array) ($d['gallery'] ?? []));

        return [
            ['عنوان (۲۰ تا ۶۵ حرف)', $tl >= 20 && $tl <= 65, fa($tl).' حرف'],
            ['توضیح متا (۷۰ تا ۱۶۰ حرف)', $ml >= 70 && $ml <= 160, $ml ? fa($ml).' حرف' : 'توضیح کوتاه یا توضیح سئو را بنویسید'],
            ['تصویر اصلی', ! empty($d['image']), ! empty($d['image']) ? 'دارد' : 'تصویر بگذارید'],
            ['توضیحات کامل (دست‌کم ۳۰۰ حرف)', $dl >= 300, fa($dl).' حرف'],
            ['دسته‌بندی', ! empty($d['category_id']), ! empty($d['category_id']) ? 'دارد' : 'دسته را انتخاب کنید'],
            ['کد کالا', ! empty($d['barcode']), ! empty($d['barcode']) ? 'دارد' : 'اختیاری'],
            ['دست‌کم ۲ تصویر', (! empty($d['image']) ? 1 : 0) + count($gallery) >= 2, fa((! empty($d['image']) ? 1 : 0) + count($gallery)).' تصویر'],
        ];
    }

    /** good | warn | bad */
    public static function level(array $d): string
    {
        $c = static::productChecks($d);
        $major = array_slice($c, 0, 5);
        $ok = count(array_filter($major, fn ($x) => $x[1]));

        return $ok === 5 ? 'good' : ($ok >= 3 ? 'warn' : 'bad');
    }

    public static function html(array $d): string
    {
        $out = '<ul style="display:grid;gap:4px;font-size:13px">';
        foreach (static::productChecks($d) as [$label, $ok, $note]) {
            $out .= '<li>'.($ok ? '🟢' : '🔴').' '.e($label).' <span style="opacity:.65">— '.e($note).'</span></li>';
        }

        return $out.'</ul>';
    }

    /**
     * تحلیل سئوی مقاله (شبیه افزونه‌های سئو)
     *
     * @return array<int, array{0: string, 1: bool, 2: string}>
     */
    public static function postChecks(array $d): array
    {
        $title = trim((string) (($d['seo_title'] ?? '') ?: ($d['title'] ?? '')));
        $meta = trim((string) (($d['seo_description'] ?? '') ?: ($d['excerpt'] ?? '')));
        $html = (string) ($d['body'] ?? '');
        $text = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($html))));
        $words = $text === '' ? 0 : count(preg_split('/\s+/u', $text));
        $kw = trim((string) ($d['focus_keyword'] ?? ''));
        $key = $kw !== '' ? Search::key($kw) : '';
        $has = fn ($t) => $key !== '' && str_contains(Search::key(strip_tags((string) $t)), $key);
        preg_match('#<p[^>]*>(.*?)</p>#isu', $html, $m);
        $first = $m[1] ?? mb_substr($text, 0, 300);
        $h2 = preg_match_all('#<h[23][^>]*>#i', $html);
        preg_match_all('#<h[23][^>]*>(.*?)</h[23]>#isu', $html, $hs);
        $links = preg_match_all('#href="(/|'.preg_quote(url('/'), '#').')#i', $html);
        $imgs = preg_match_all('#<img#i', $html) + (empty($d['image']) ? 0 : 1);
        $density = 0;
        if ($key !== '' && $words) {
            $density = round(substr_count(Search::key($text), $key) * 100 / $words, 1);
        }
        $tl = mb_strlen($title);
        $ml = mb_strlen($meta);

        $c = [
            ['عنوان سئو (۳۰ تا ۶۵ حرف)', $tl >= 30 && $tl <= 65, fa($tl).' حرف'],
            ['توضیح متا (۱۲۰ تا ۱۶۰ حرف)', $ml >= 120 && $ml <= 160, fa($ml).' حرف'],
            ['طول مقاله (دست‌کم ۶۰۰ کلمه)', $words >= 600, fa($words).' کلمه'],
            ['تیترهای میانی (H2/H3)', $h2 >= 2, fa($h2).' تیتر'],
            ['تصویر شاخص و تصاویر متن', $imgs >= 1, fa($imgs).' تصویر'],
            ['لینک داخلی به صفحات سایت', $links >= 1, fa($links).' لینک'],
        ];
        if ($key !== '') {
            $c[] = ['کلمه کلیدی در عنوان', $has($title), $has($title) ? 'دارد' : 'ندارد'];
            $c[] = ['کلمه کلیدی در توضیح متا', $has($meta), $has($meta) ? 'دارد' : 'ندارد'];
            $c[] = ['کلمه کلیدی در پاراگراف اول', $has($first), $has($first) ? 'دارد' : 'ندارد'];
            $inH = false;
            foreach ($hs[1] ?? [] as $h) {
                $inH = $inH || $has($h);
            }
            $c[] = ['کلمه کلیدی در یکی از تیترها', $inH, $inH ? 'دارد' : 'ندارد'];
            $c[] = ['تراکم کلمه کلیدی (۰٫۵ تا ۲٫۵٪)', $density >= 0.5 && $density <= 2.5, fa($density).'٪'];
        } else {
            $c[] = ['کلمه کلیدی اصلی', false, 'تعیین نشده'];
        }

        return $c;
    }

    public static function checksHtml(array $checks): string
    {
        $ok = count(array_filter($checks, fn ($x) => $x[1]));
        $pct = (int) round($ok * 100 / max(1, count($checks)));
        $color = $pct >= 80 ? '#16a34a' : ($pct >= 50 ? '#d97706' : '#dc2626');
        $out = '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px"><b style="font-size:22px;color:'.$color.'">'.fa($pct).'</b><span style="opacity:.7">امتیاز سئو از ۱۰۰</span></div><ul style="display:grid;gap:4px;font-size:13px">';
        foreach ($checks as [$label, $good, $note]) {
            $out .= '<li>'.($good ? '🟢' : '🔴').' '.e($label).' <span style="opacity:.65">— '.e($note).'</span></li>';
        }

        return $out.'</ul>';
    }
}
