<?php

namespace App\Support;

/**
 * نام فارسی ← حروف انگلیسی (فینگلیش) برای نام فایل‌ها (مثلاً اکسل هلو: Ali-Rezaei-1073.xls)
 * اول واژه‌نامه نام‌ها و پسوندهای رایج، بعد قاعده‌های آوانویسی (فارسی بدون اعراب است؛ نتیجه تقریبی ولی خواناست).
 */
class Finglish
{
    /** نام‌ها و ریشه‌های رایج (پسوند «ی» / «یان» / «زاده» / «پور» / «نیا» / «فر» جداگانه اضافه می‌شود) */
    protected const WORDS = [
        'محمد' => 'Mohammad', 'محمود' => 'Mahmoud', 'احمد' => 'Ahmad', 'علی' => 'Ali', 'رضا' => 'Reza', 'حسین' => 'Hossein', 'حسن' => 'Hassan',
        'مهدی' => 'Mahdi', 'امیر' => 'Amir', 'مجید' => 'Majid', 'سعید' => 'Saeed', 'حمید' => 'Hamid', 'وحید' => 'Vahid', 'مسعود' => 'Masoud',
        'جواد' => 'Javad', 'جعفر' => 'Jafar', 'کریم' => 'Karim', 'رحیم' => 'Rahim', 'ابراهیم' => 'Ebrahim', 'اسماعیل' => 'Esmaeil', 'یوسف' => 'Yousef',
        'یعقوب' => 'Yaghoub', 'موسی' => 'Mousa', 'عیسی' => 'Isa', 'عباس' => 'Abbas', 'قاسم' => 'Ghasem', 'هادی' => 'Hadi', 'مرتضی' => 'Morteza',
        'مصطفی' => 'Mostafa', 'مجتبی' => 'Mojtaba', 'صادق' => 'Sadegh', 'باقر' => 'Bagher', 'کاظم' => 'Kazem', 'جلال' => 'Jalal', 'کمال' => 'Kamal',
        'جمال' => 'Jamal', 'فرهاد' => 'Farhad', 'فرشید' => 'Farshid', 'بهروز' => 'Behrouz', 'بهزاد' => 'Behzad', 'بهمن' => 'Bahman', 'بیژن' => 'Bijan',
        'داوود' => 'Davoud', 'داود' => 'Davoud', 'سجاد' => 'Sajjad', 'میلاد' => 'Milad', 'پویا' => 'Pouya', 'آرش' => 'Arash', 'کیوان' => 'Keyvan',
        'نوید' => 'Navid', 'امید' => 'Omid', 'ایمان' => 'Iman', 'پیمان' => 'Peyman', 'سامان' => 'Saman', 'شهرام' => 'Shahram', 'شهاب' => 'Shahab',
        'منصور' => 'Mansour', 'ناصر' => 'Naser', 'نادر' => 'Nader', 'اکبر' => 'Akbar', 'اصغر' => 'Asghar', 'یزدان' => 'Yazdan', 'ایرج' => 'Iraj',
        'سیروس' => 'Sirous', 'کورش' => 'Kourosh', 'کوروش' => 'Kourosh', 'داریوش' => 'Dariush', 'هوشنگ' => 'Houshang', 'منوچهر' => 'Manouchehr',
        'غلام' => 'Gholam', 'غلامرضا' => 'Gholamreza', 'غلامحسین' => 'Gholamhossein', 'عبدالله' => 'Abdollah', 'حبیب' => 'Habib', 'لطف' => 'Lotf',
        'سید' => 'Seyed', 'سیده' => 'Seyedeh', 'حاج' => 'Haj', 'حاجی' => 'Haji', 'آقا' => 'Agha', 'خانم' => 'Khanom', 'مهندس' => 'Mohandes', 'دکتر' => 'Dr',
        'فاطمه' => 'Fatemeh', 'زهرا' => 'Zahra', 'مریم' => 'Maryam', 'زینب' => 'Zeynab', 'معصومه' => 'Masoumeh', 'سمیه' => 'Somayeh', 'لیلا' => 'Leila',
        'سارا' => 'Sara', 'نرگس' => 'Narges', 'مینا' => 'Mina', 'الهام' => 'Elham', 'اعظم' => 'Azam', 'اشرف' => 'Ashraf', 'طاهره' => 'Tahereh',
        'رحمان' => 'Rahman', 'رحمت' => 'Rahmat', 'نعمت' => 'Nemat', 'عزت' => 'Ezzat', 'حشمت' => 'Heshmat', 'شوکت' => 'Shokat', 'نصرت' => 'Nosrat',
        'نور' => 'Nour', 'نوری' => 'Nouri', 'زارع' => 'Zare', 'جعفری' => 'Jafari', 'موسوی' => 'Mousavi', 'رضوی' => 'Razavi', 'طباطبایی' => 'Tabatabaei',
        'کاظمی' => 'Kazemi', 'صالحی' => 'Salehi', 'قربانی' => 'Ghorbani', 'رستمی' => 'Rostami', 'مرادی' => 'Moradi', 'اکبری' => 'Akbari',
        'شریفی' => 'Sharifi', 'نظری' => 'Nazari', 'رحیمی' => 'Rahimi', 'یزدانی' => 'Yazdani', 'عزیزی' => 'Azizi', 'عزیز' => 'Aziz',
        'محسن' => 'Mohsen', 'محسنی' => 'Mohseni', 'هاشم' => 'Hashem', 'تقی' => 'Taghi', 'نقی' => 'Naghi', 'قنبر' => 'Ghanbar', 'صفر' => 'Safar', 'خسرو' => 'Khosro', 'خسروی' => 'Khosravi',
        'رفیع' => 'Rafie', 'فدایی' => 'Fadaei', 'دهقان' => 'Dehghan', 'ابوذر' => 'Abouzar', 'الله' => 'Allah', 'کرم' => 'Karam', 'مصیب' => 'Mosayeb',
        'نژاد' => 'Nejad', 'خان' => 'Khan', 'شکوه' => 'Shokouh', 'تقو' => 'Taghav', 'بحران' => 'Bahran', 'سادات' => 'Sadat', 'عرشیا' => 'Arshia',
        'نیک' => 'Nik', 'پاک' => 'Pak', 'دوست' => 'Doust', 'مهر' => 'Mehr', 'نیکو' => 'Nikou', 'شاه' => 'Shah', 'خواه' => 'Khah', 'آبادی' => 'Abadi',
        'پلاستیک' => 'Plastic', 'پلاسکو' => 'Plasco', 'پخش' => 'Pakhsh', 'فروشگاه' => 'Forooshgah', 'بازرگانی' => 'Bazargani', 'شرکت' => 'Sherkat',
        'تهران' => 'Tehran', 'شیراز' => 'Shiraz', 'اهواز' => 'Ahvaz', 'اصفهان' => 'Isfahan', 'مشهد' => 'Mashhad', 'تبریز' => 'Tabriz', 'کرج' => 'Karaj',
        'قم' => 'Qom', 'کرمان' => 'Kerman', 'یزد' => 'Yazd', 'رشت' => 'Rasht', 'ساری' => 'Sari', 'بوشهر' => 'Bushehr', 'بندرعباس' => 'Bandar-Abbas',
    ];

    protected const SUFFIX = ['نژاد' => 'nejad', 'وند' => 'vand', 'زاده' => 'zadeh', 'پور' => 'pour', 'نیا' => 'nia', 'فر' => 'far', 'یان' => 'ian', 'ی' => 'i', 'ئی' => 'ei', 'یی' => 'ei'];

    protected const MAP = [
        'آ' => 'a', 'ا' => 'a', 'أ' => 'a', 'إ' => 'e', 'ب' => 'b', 'پ' => 'p', 'ت' => 't', 'ث' => 's', 'ج' => 'j', 'چ' => 'ch', 'ح' => 'h', 'خ' => 'kh',
        'د' => 'd', 'ذ' => 'z', 'ر' => 'r', 'ز' => 'z', 'ژ' => 'zh', 'س' => 's', 'ش' => 'sh', 'ص' => 's', 'ض' => 'z', 'ط' => 't', 'ظ' => 'z', 'ع' => '',
        'غ' => 'gh', 'ف' => 'f', 'ق' => 'gh', 'ک' => 'k', 'ك' => 'k', 'گ' => 'g', 'ل' => 'l', 'م' => 'm', 'ن' => 'n', 'و' => 'v', 'ه' => 'h', 'ة' => 'h',
        'ی' => 'i', 'ي' => 'i', 'ئ' => 'e', 'ؤ' => 'o', 'ء' => '', 'ۀ' => 'ye',
    ];

    public static function make(?string $text, int $max = 60): string
    {
        $t = trim((string) $text);
        if ($t === '') {
            return '';
        }
        $t = str_replace(['ي', 'ك', "\u{200C}", '‌'], ['ی', 'ک', ' ', ' '], $t);
        $t = strtr($t, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9']);
        $out = [];
        foreach (preg_split('/[\s\-_،,\/\\\\.()]+/u', $t) as $w) {
            if ($w === '') {
                continue;
            }
            $out[] = static::word($w);
        }
        $s = implode('-', array_filter($out, fn ($x) => $x !== ''));
        $s = preg_replace('/[^A-Za-z0-9\-]+/', '', $s);
        $s = trim(preg_replace('/-{2,}/', '-', $s), '-');

        return substr($s, 0, $max);
    }

    protected static function word(string $w): string
    {
        if (preg_match('/^[A-Za-z0-9]+$/', $w)) {
            return $w;
        }
        if (isset(static::WORDS[$w])) {
            return static::WORDS[$w];
        }
        // ریشه شناخته‌شده + پسوند (رضایی، احمدی، حسین‌زاده، محمدپور، کریمیان)
        foreach (static::SUFFIX as $suf => $lat) {
            if (mb_strlen($w) > mb_strlen($suf) + 1 && str_ends_with($w, $suf)) {
                $root = mb_substr($w, 0, -mb_strlen($suf));
                if (isset(static::WORDS[$root])) {
                    $r = static::WORDS[$root];
                    if ($lat === 'i' && preg_match('/a$/i', $r)) {
                        $lat = 'ei'; // رضا ← Rezaei
                    }

                    return $r.$lat;
                }
            }
        }
        // ترکیب دو نام شناخته‌شده (محمدعلی، علیرضا)
        foreach (static::WORDS as $fa => $en) {
            if (mb_strlen($fa) >= 3 && str_starts_with($w, $fa) && isset(static::WORDS[mb_substr($w, mb_strlen($fa))])) {
                return $en.strtolower(static::WORDS[mb_substr($w, mb_strlen($fa))]);
            }
        }

        return ucfirst(static::translit($w));
    }

    /** آوانویسی حرف‌به‌حرف با چند قاعده ساده (و/ی بین صامت‌ها، ه پایانی) */
    protected static function translit(string $w): string
    {
        $ch = preg_split('//u', $w, -1, PREG_SPLIT_NO_EMPTY);
        $n = count($ch);
        $vow = ['ا', 'آ', 'و', 'ی'];
        $s = '';
        foreach ($ch as $i => $c) {
            $prev = $ch[$i - 1] ?? null;
            $next = $ch[$i + 1] ?? null;
            if (preg_match('/[A-Za-z0-9]/', $c)) {
                $s .= $c;

                continue;
            }
            if ($c === 'و') {
                // اول واژه یا پیش از واکه: v؛ میان صامت‌ها: o ؛ «او»: ou
                $s .= ($i === 0 || in_array($next, ['ا', 'ی'], true)) ? 'v' : ($prev === 'ا' ? 'u' : 'o');

                continue;
            }
            if ($c === 'ی') {
                $s .= ($next === 'ا' && $i === $n - 2 && $i > 0) ? 'i' : (($i === 0 || in_array($next, ['ا', 'و'], true)) ? 'y' : 'i'); // نیا ← nia

                continue;
            }
            if ($c === 'ه' && $i === $n - 1 && $i > 0 && ! in_array($prev, $vow, true)) {
                $s .= 'eh'; // زاده، خانه

                continue;
            }
            if ($c === 'ع') {
                $s .= $i === 0 ? (in_array($next, $vow, true) ? '' : 'a') : (in_array($prev, $vow, true) ? '' : 'a');

                continue;
            }
            if ($c === 'ا' && $i === 0 && $next && ! in_array($next, $vow, true)) {
                $s .= 'a';

                continue;
            }
            $s .= static::MAP[$c] ?? '';
            // میان دو صامت پیاپی در آغاز واژه یک e بگذار تا خواناتر شود (کریمی → Karimi نه Krimi)
            if ($i === 0 && $next && ! in_array($c, $vow, true) && ! in_array($next, $vow, true) && isset(static::MAP[$c]) && $c !== 'ع') {
                $s .= 'a';
            }
        }

        return $s;
    }

    /** نام فایل امن: «نام-مشتری-شماره» (اگر نام خالی بود فقط شماره) */
    public static function fileName(?string $customer, string $rest, string $ext = 'xls'): string
    {
        $n = static::make($customer);

        return ($n !== '' ? $n.'-' : '').trim($rest, '-').'.'.$ext;
    }
}
