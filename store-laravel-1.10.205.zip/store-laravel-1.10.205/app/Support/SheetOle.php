<?php

namespace App\Support;

use Exception;

/**
 * خوانندهٔ ظرف OLE2 / Compound File (فایل‌های xls قدیمی).
 */
class SheetOle {
    private $d, $ss, $mss, $fat = array(), $mfat = array(), $dir = array(), $mini = null, $cutoff = 4096;

    public function __construct($path, $data = null) {
        $this->d = $data !== null ? $data : file_get_contents($path);
        $d = $this->d;
        if (strlen($d) < 512) throw new Exception('فایل xls ناقص است.');
        $h = unpack('vminor/vmajor/vbom/vss/vmss', substr($d, 0x18, 10));
        $this->ss = 1 << $h['ss'];
        $this->mss = 1 << $h['mss'];
        if ($this->ss < 128 || $this->ss > 65536) throw new Exception('ساختار فایل xls نامعتبر است.');
        $v = unpack('VnFat/VdirStart/Vtx/Vcutoff/VmfStart/VnMf/VdfStart/VnDf', substr($d, 0x2C, 32));
        $this->cutoff = $v['cutoff'] ?: 4096;

        // DIFAT
        $difat = array_values(unpack('V109', substr($d, 0x4C, 436)));
        $s = $v['dfStart']; $guard = 0; $per = $this->ss / 4 - 1;
        while ($s < 0xFFFFFFFA && $guard++ < 100000) {
            $sec = $this->sector($s);
            if ($sec === '') break;
            $arr = array_values(unpack('V' . ($per + 1), $sec));
            $s = array_pop($arr);
            foreach ($arr as $a) $difat[] = $a;
        }
        $fat = '';
        foreach ($difat as $fs) { if ($fs >= 0xFFFFFFFA) continue; $fat .= $this->sector($fs); }
        $this->fat = $fat === '' ? array() : array_values(unpack('V*', $fat));

        // Directory
        $dirData = $this->chain($v['dirStart']);
        for ($o = 0; $o + 128 <= strlen($dirData); $o += 128) {
            $e = substr($dirData, $o, 128);
            $nl = ord($e[0x40]) | (ord($e[0x41]) << 8);
            $name = $nl > 2 ? SheetReader::conv(substr($e, 0, $nl - 2), 'UTF-16LE') : '';
            $u = unpack('Vstart/Vsize', substr($e, 0x74, 8));
            $this->dir[] = array('name' => $name, 'type' => ord($e[0x42]), 'start' => $u['start'], 'size' => $u['size']);
        }

        // Mini FAT
        if ($v['nMf'] && $v['mfStart'] < 0xFFFFFFFA) {
            $m = $this->chain($v['mfStart']);
            if ($m !== '') $this->mfat = array_values(unpack('V*', $m));
        }
    }

    private function sector($n) {
        return (string) substr($this->d, ($n + 1) * $this->ss, $this->ss);
    }

    private function chain($start, $size = null) {
        $out = ''; $s = $start; $seen = 0; $max = count($this->fat) + 1;
        while ($s < 0xFFFFFFFA && $seen++ < $max) {
            $out .= $this->sector($s);
            if ($size !== null && strlen($out) >= $size) break;
            $s = isset($this->fat[$s]) ? $this->fat[$s] : 0xFFFFFFFE;
        }
        return $size !== null ? substr($out, 0, $size) : $out;
    }

    /** پیدا کردن stream با یکی از نام‌ها (بدون حساسیت به حروف) */
    public function find($names) {
        foreach ($names as $n) {
            foreach ($this->dir as $i => $e) {
                if ($e['type'] === 2 && strcasecmp($e['name'], $n) === 0) return $i;
            }
        }
        return null;
    }

    public function stream($i) {
        $e = $this->dir[$i];
        if ($e['size'] < $this->cutoff && $this->mfat) {
            if ($this->mini === null) $this->mini = $this->chain($this->dir[0]['start']);
            $out = ''; $s = $e['start']; $seen = 0; $max = count($this->mfat) + 1;
            while ($s < 0xFFFFFFFA && $seen++ < $max && strlen($out) < $e['size']) {
                $out .= substr($this->mini, $s * $this->mss, $this->mss);
                $s = isset($this->mfat[$s]) ? $this->mfat[$s] : 0xFFFFFFFE;
            }
            return substr($out, 0, $e['size']);
        }
        return $this->chain($e['start'], $e['size']);
    }
}
