<?php

namespace App\Support;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Cache;

/**
 * جستجوی هوشمند فارسی:
 * - یکسان‌سازی حروف عربی/فارسی و ارقام، بی‌توجه به فاصله و نیم‌فاصله («جا پیازی» = «جاپیازی»)
 * - یکسان‌سازی حروف هم‌صدا («عادل» = «آدل»، «ثابت» = «سابت»)
 * - واژه‌های هم‌معنی تعریف‌شده در پنل («زیرسیگاری» ← «جاسیگاری»)
 * - اگر نتیجه‌ای نبود: نزدیک‌ترین واژه‌ها (غلط تایپی) و بخش مشترک واژه («زیرسیگاری» ← «…سیگاری»)
 */
class Search
{
    /** متن تمیز با فاصله */
    public static function normalize(?string $text): string
    {
        $t = mb_strtolower(en_digits((string) $text));
        $t = strtr($t, [
            'ي' => 'ی', 'ى' => 'ی', 'ك' => 'ک', 'ة' => 'ه', 'ۀ' => 'ه', 'ؤ' => 'و', 'أ' => 'ا', 'إ' => 'ا', 'ٱ' => 'ا',
            "\u{200C}" => ' ', "\u{200D}" => '', "\u{00A0}" => ' ', 'ـ' => '',
        ]);
        $t = preg_replace('/[\x{064B}-\x{065F}\x{0670}]/u', '', $t); // اعراب
        $t = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $t);

        return trim(preg_replace('/\s+/u', ' ', $t));
    }

    /** کلید آوایی بدون فاصله برای مقایسه */
    public static function key(?string $text): string
    {
        $t = str_replace(' ', '', static::normalize($text));
        $t = strtr($t, [
            'آ' => 'ا', 'ع' => 'ا', 'ء' => 'ا', 'ئ' => 'ی',
            'ث' => 'س', 'ص' => 'س',
            'ذ' => 'ز', 'ض' => 'ز', 'ظ' => 'ز',
            'ط' => 'ت', 'ح' => 'ه', 'غ' => 'ق',
        ]);

        // حروف تکراری پشت‌سرهم یکی می‌شوند (عادل → اادل → ادل)
        return preg_replace('/(.)\1+/u', '$1', $t);
    }

    /** کلید ذخیره‌شده روی هر محصول */
    public static function productKey(Product $p): string
    {
        $cat = $p->category_id ? Category::query()->whereKey($p->category_id)->value('name') : '';
        $parts = [static::key($p->name), static::key($p->sku), static::key($p->barcode), static::key($cat)];
        foreach (static::words($p->name) as $w) {
            $parts[] = static::key($w);
        }

        return '|'.implode('|', array_filter(array_unique($parts))).'|';
    }

    /** @return array<int, string> */
    public static function words(?string $text): array
    {
        return array_values(array_filter(explode(' ', static::normalize($text)), fn ($w) => mb_strlen($w) > 1 || ctype_digit($w)));
    }

    /** گروه‌های هم‌معنی از تنظیمات: هر خط «واژه۱، واژه۲، …» */
    public static function synonyms(): array
    {
        $groups = [];
        foreach (preg_split('/\R/u', (string) setting('search_synonyms', '')) as $line) {
            $ws = array_values(array_filter(array_map(fn ($w) => static::normalize($w), preg_split('/[,،=\-–|]+/u', $line))));
            if (count($ws) > 1) {
                $groups[] = $ws;
            }
        }

        return $groups;
    }

    /** اعمال شرط جستجو روی کوئری (همه واژه‌ها باید پیدا شوند) */
    public static function apply(Builder $q, string $term): Builder
    {
        $norm = static::normalize($term);
        $whole = static::key($term);
        $raw = trim(en_digits($term));
        $words = static::words($term) ?: [$norm];

        // جستجوی عددی (۳ رقم به بالا) = بارکد/کد کالا: فقط کالایی که دقیقاً همین کد را دارد (کدهای مشابه نه؛ نبود = پیدا نشد)
        if ($codes = static::numericCodes($term)) {
            return static::exactCode($q, $codes);
        }

        return $q->where(function ($w) use ($raw, $whole, $words) {
            $w->where('barcode', $raw)->orWhere('sku', $raw)
                ->orWhere('search_key', 'like', '%'.$whole.'%')
                ->orWhere(function ($all) use ($words) {
                    foreach ($words as $word) {
                        $all->where('search_key', 'like', '%'.static::key($word).'%');
                    }
                });
        })->orderByRaw('CASE WHEN barcode = ? THEN 0 WHEN search_key LIKE ? THEN 1 WHEN search_key LIKE ? THEN 2 ELSE 3 END', [$raw, '%|'.$whole.'|%', '%|'.$whole.'%']);
    }

    /**
     * جستجوی کامل با جایگزین‌ها. خروجی: [عبارت نهایی برای نمایش، نوع جایگزین (null|synonym|fuzzy), شناسه‌های جایگزین]
     *
     * @return array{term: string, kind: ?string, ids: ?array}
     */
    /** عبارت عددی (بارکد/کد کالا) ← کدهای قابل قبول؛ وگرنه null */
    public static function numericCodes(?string $term): ?array
    {
        $digits = preg_replace('/[\s\-]+/', '', trim(en_digits((string) $term)));
        if (! preg_match('/^\d{3,20}$/', $digits)) {
            return null;
        }

        return array_values(array_unique([$digits, ltrim($digits, '0') ?: '0']));
    }

    public static function exactCode(Builder $q, array $codes): Builder
    {
        return $q->where(fn ($w) => $w->whereIn('barcode', $codes)->orWhereIn('sku', $codes)
            ->orWhere(fn ($x) => $x->whereIn('sync_code', $codes)->where(fn ($y) => $y->whereNull('sku')->orWhere('sku', '')))); // فقط کد فعلی
    }

    public static function resolve(string $term, callable $count): array
    {
        if (static::numericCodes($term)) {
            return ['term' => $term, 'kind' => null, 'ids' => null]; // بارکد: بدون جایگزین/مشابه
        }
        if ($count(fn (Builder $q) => static::apply($q, $term)) > 0) {
            return ['term' => $term, 'kind' => null, 'ids' => null];
        }
        // ۱. هم‌معنی‌ها
        $norm = static::normalize($term);
        foreach (static::synonyms() as $group) {
            foreach ($group as $word) {
                if ($word !== '' && (str_contains($norm, $word) || static::key($norm) === static::key($word))) {
                    foreach ($group as $alt) {
                        if ($alt === $word) {
                            continue;
                        }
                        $altTerm = trim(str_replace($word, $alt, $norm));
                        if ($count(fn (Builder $q) => static::apply($q, $altTerm)) > 0) {
                            return ['term' => $altTerm, 'kind' => 'synonym', 'ids' => null];
                        }
                    }
                }
            }
        }
        // ۲. نزدیک‌ترین واژه‌ها (غلط تایپی یا بخش مشترک)
        $ids = static::fuzzyIds($term);
        if ($ids) {
            return ['term' => static::bestGuess($term) ?: $term, 'kind' => 'fuzzy', 'ids' => $ids];
        }

        return ['term' => $term, 'kind' => null, 'ids' => []];
    }

    /** واژه‌نامه نام کالاها: کلید واژه => [شناسه‌ها] */
    protected static function vocabulary(): array
    {
        return Cache::remember('search.vocab', 600, function () {
            $vocab = [];
            foreach (Product::query()->where('is_active', true)->get(['id', 'name']) as $p) {
                foreach (static::words($p->name) as $w) {
                    if (mb_strlen($w) < 3) {
                        continue;
                    }
                    $k = static::key($w);
                    $vocab[$k]['w'] = $vocab[$k]['w'] ?? $w;
                    $vocab[$k]['ids'][] = $p->id;
                }
            }

            return $vocab;
        });
    }

    /** امتیاز شباهت دو کلید (۰ تا ۱) */
    public static function similarity(string $a, string $b): float
    {
        $la = mb_strlen($a);
        $lb = mb_strlen($b);
        if (! $la || ! $lb) {
            return 0;
        }
        if ($a === $b) {
            return 1;
        }
        // فاصله ویرایشی روی حروف چندبایتی
        $ca = mb_str_split($a);
        $cb = mb_str_split($b);
        $prev = range(0, $lb);
        for ($i = 1; $i <= $la; $i++) {
            $cur = [$i];
            for ($j = 1; $j <= $lb; $j++) {
                $cur[$j] = min($prev[$j] + 1, $cur[$j - 1] + 1, $prev[$j - 1] + ($ca[$i - 1] === $cb[$j - 1] ? 0 : 1));
            }
            $prev = $cur;
        }
        $lev = 1 - $prev[$lb] / max($la, $lb);
        // طولانی‌ترین بخش مشترک (برای «زیرسیگاری» و «جاسیگاری»)
        $lcs = 0;
        $row = array_fill(0, $lb + 1, 0);
        for ($i = 1; $i <= $la; $i++) {
            $diag = 0;
            for ($j = 1; $j <= $lb; $j++) {
                $tmp = $row[$j];
                $row[$j] = $ca[$i - 1] === $cb[$j - 1] ? $diag + 1 : 0;
                $lcs = max($lcs, $row[$j]);
                $diag = $tmp;
            }
        }
        $sub = $lcs >= 4 ? $lcs / max($la, $lb) : 0;

        return max($lev, $sub);
    }

    /** @return array<int, int> */
    public static function fuzzyIds(string $term): array
    {
        $vocab = static::vocabulary();
        $score = [];
        foreach (static::words($term) as $w) {
            $k = static::key($w);
            if (mb_strlen($k) < 3) {
                continue;
            }
            $min = mb_strlen($k) <= 4 ? 0.74 : 0.6;
            foreach ($vocab as $vk => $v) {
                $s = static::similarity($k, (string) $vk);
                if ($s >= $min) {
                    foreach ($v['ids'] as $id) {
                        $score[$id] = max($score[$id] ?? 0, $s);
                    }
                }
            }
        }
        arsort($score);

        return array_slice(array_keys($score), 0, 200);
    }

    /** «منظورتان … بود؟» */
    public static function bestGuess(string $term): ?string
    {
        $vocab = static::vocabulary();
        $out = [];
        foreach (static::words($term) as $w) {
            $k = static::key($w);
            $best = null;
            $bs = 0;
            foreach ($vocab as $vk => $v) {
                $s = static::similarity($k, (string) $vk);
                if ($s > $bs) {
                    $bs = $s;
                    $best = $v['w'];
                }
            }
            $out[] = $bs >= 0.6 ? $best : $w;
        }

        return implode(' ', $out) ?: null;
    }

    public static function reindex(): int
    {
        $n = 0;
        Product::query()->with('category')->chunkById(300, function ($chunk) use (&$n) {
            foreach ($chunk as $p) {
                Product::query()->whereKey($p->id)->update(['search_key' => static::productKey($p)]);
                $n++;
            }
        });
        Cache::forget('search.vocab');

        return $n;
    }
}
