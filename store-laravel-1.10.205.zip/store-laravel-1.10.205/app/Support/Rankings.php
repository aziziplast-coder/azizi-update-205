<?php

namespace App\Support;

use App\Models\Product;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

/** رتبه‌بندی کالاها: پرفروش‌ترین (بر اساس تعداد فروخته‌شده) و پربازدیدترین بازه اخیر */
class Rankings
{
    /** @return array<int, int> شناسه کالا => تعداد عدد فروخته‌شده */
    public static function soldUnits(int $days = 0): array
    {
        return Cache::remember('rank.sold.'.$days, 1800, function () use ($days) {
            $q = DB::table('order_items')->join('orders', 'orders.id', '=', 'order_items.order_id')
                ->whereNotNull('order_items.product_id')
                ->whereNotIn('orders.status', ['cancelled', 'failed', 'pending_payment']);
            if ($days > 0) {
                $q->where('orders.created_at', '>=', now()->subDays($days));
            }

            return $q->groupBy('order_items.product_id')->selectRaw('order_items.product_id AS pid, SUM(order_items.units) AS sold')
                ->orderByDesc('sold')->limit(600)->pluck('sold', 'pid')->map(fn ($v) => (int) $v)->all();
        });
    }

    /** پرفروش‌ترین‌های موجود به ترتیب، با تعداد فروش */
    public static function bestsellers(int $limit, int $days = 0)
    {
        $sold = static::soldUnits($days);
        if (! $sold) {
            // هنوز فروشی نیست: بر اساس شمارنده فروش
            return Product::query()->active()->available()->with('category')->orderByDesc('sales_count')->orderByDesc('views')->limit($limit)->get()
                ->each(fn ($p) => $p->sold_units = 0);
        }
        $ids = array_keys($sold);
        $products = Product::query()->active()->available()->with('category')->whereIn('id', $ids)->get()->keyBy('id');
        $out = collect();
        foreach ($ids as $id) {
            if ($p = $products->get($id)) {
                $p->sold_units = $sold[$id];
                $out->push($p);
                if ($out->count() >= $limit) {
                    break;
                }
            }
        }

        return $out;
    }

    /** پربازدیدترین‌ها در چند ساعت اخیر */
    public static function trending(int $hours, int $limit)
    {
        $ids = Cache::remember('rank.views.'.$hours, 600, fn () => DB::table('product_view_stats')
            ->where('hour', '>=', now()->subHours($hours)->startOfHour())
            ->groupBy('product_id')->orderByRaw('SUM(views) DESC')->limit(200)->pluck('product_id')->all());
        if (! $ids) {
            return collect();
        }
        $products = Product::query()->active()->available()->with('category')->whereIn('id', $ids)->get()->keyBy('id');

        return collect($ids)->map(fn ($id) => $products->get($id))->filter()->take($limit)->values();
    }

    /** ثبت یک بازدید (ساعتی) */
    public static function hit(int $productId): void
    {
        try {
            $hour = now()->startOfHour()->format('Y-m-d H:i:s');
            $n = DB::table('product_view_stats')->where('product_id', $productId)->where('hour', $hour)->increment('views');
            if (! $n) {
                DB::table('product_view_stats')->insertOrIgnore(['product_id' => $productId, 'hour' => $hour, 'views' => 1]);
            }
        } catch (\Throwable) {
        }
    }
}
