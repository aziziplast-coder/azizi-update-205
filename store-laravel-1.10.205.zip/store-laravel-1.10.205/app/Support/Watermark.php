<?php

namespace App\Support;

use Throwable;

/**
 * جایگزینی واترمارک تأمین‌کننده با نشان فروشگاه:
 * ناحیه ثابت (درصدی از تصویر) پوشانده و تصویر PNG نشان شما روی آن گذاشته می‌شود.
 * نسخه اصلی هر تصویر جدا نگه داشته می‌شود تا با عوض شدن نشان، همه تصاویر دوباره ساخته شوند.
 */
class Watermark
{
    public static function enabled(): bool
    {
        return (bool) setting('wm_enabled', false) && function_exists('imagecreatetruecolor');
    }

    /** تنظیمات فعلی (یا تنظیمات پیش‌نمایش) */
    public static function config(array $over = []): array
    {
        $c = [
            'image' => setting('wm_image'),
            'x' => (float) setting('wm_x', 0),
            'y' => (float) setting('wm_y', 86),
            'w' => (float) setting('wm_w', 42),
            'h' => (float) setting('wm_h', 14),
            'cover' => (string) setting('wm_cover', '#ffffff'),
            'align' => (string) setting('wm_align', 'start'),
            'padding' => (float) setting('wm_padding', 6),
        ];

        return array_merge($c, array_filter($over, fn ($v) => $v !== null));
    }

    public static function origPath(string $rel): string
    {
        return storage_path('app/img-orig/'.$rel);
    }

    /** ذخیره نسخه اصلی و ساخت نسخه نهایی (با یا بدون نشان) */
    public static function store(string $rel, string $body): bool
    {
        $orig = static::origPath($rel);
        if (! is_dir(dirname($orig))) {
            @mkdir(dirname($orig), 0755, true);
        }
        @file_put_contents($orig, $body);

        return static::render($rel);
    }

    /** ساخت دوباره تصویر نهایی از روی نسخه اصلی */
    public static function render(string $rel, ?array $cfg = null): bool
    {
        $orig = static::origPath($rel);
        $dest = public_path('uploads/'.$rel);
        if (! is_file($orig)) {
            return false;
        }
        if (! is_dir(dirname($dest))) {
            @mkdir(dirname($dest), 0755, true);
        }
        $ok = false;
        if ($cfg !== null || static::enabled()) {
            try {
                $ok = static::apply($orig, $dest, $cfg ?? static::config());
            } catch (Throwable $e) {
                report($e);
            }
        }
        if (! $ok) {
            $ok = @copy($orig, $dest);
        }
        static::clearThumbs($rel);

        return $ok;
    }

    public static function clearThumbs(string $rel): void
    {
        foreach (\App\Http\Controllers\ThumbController::SIZES as $w) {
            @unlink(public_path('uploads/_t/'.$w.'/'.$rel.'.webp'));
        }
    }

    protected static function load(string $path)
    {
        $info = @getimagesize($path);
        if (! $info) {
            return null;
        }

        return match ($info[2]) {
            IMAGETYPE_JPEG => @imagecreatefromjpeg($path),
            IMAGETYPE_PNG => @imagecreatefrompng($path),
            IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($path) : null,
            IMAGETYPE_GIF => @imagecreatefromgif($path),
            default => null,
        } ?: null;
    }

    /** اعمال روی یک فایل؛ $dest = null یعنی برگرداندن تصویر GD (برای پیش‌نمایش) */
    public static function apply(string $src, ?string $dest, array $c, bool $outline = false)
    {
        @ini_set('memory_limit', '512M');
        $im = static::load($src);
        if (! $im) {
            return false;
        }
        imagepalettetotruecolor($im);
        $W = imagesx($im);
        $H = imagesy($im);
        $rx = (int) round($W * max(0, min(100, $c['x'])) / 100);
        $ry = (int) round($H * max(0, min(100, $c['y'])) / 100);
        $rw = (int) round($W * max(1, min(100, $c['w'])) / 100);
        $rh = (int) round($H * max(1, min(100, $c['h'])) / 100);
        $rw = min($rw, $W - $rx);
        $rh = min($rh, $H - $ry);

        // ۱) پوشاندن واترمارک قبلی
        if (($c['cover'] ?? '') !== 'none') {
            [$r, $g, $b] = static::rgb($c['cover'] ?: '#ffffff');
            imagefilledrectangle($im, $rx, $ry, $rx + $rw - 1, $ry + $rh - 1, imagecolorallocate($im, $r, $g, $b));
        }

        // ۲) گذاشتن نشان جدید (حفظ نسبت ابعاد، داخل ناحیه)
        $wmPath = $c['image'] ? (is_file($c['image']) ? $c['image'] : public_path('uploads/'.ltrim((string) $c['image'], '/'))) : null;
        if ($wmPath && is_file($wmPath) && ($wm = static::load($wmPath))) {
            imagealphablending($wm, true);
            $pad = (int) round(min($rw, $rh) * max(0, min(40, (float) $c['padding'])) / 100);
            $bw = max(1, $rw - 2 * $pad);
            $bh = max(1, $rh - 2 * $pad);
            $ww = imagesx($wm);
            $wh = imagesy($wm);
            $scale = min($bw / $ww, $bh / $wh);
            $nw = max(1, (int) round($ww * $scale));
            $nh = max(1, (int) round($wh * $scale));
            // راست‌چین: start = سمت چپ تصویر (جای نوار عزیزی)، end = سمت راست ناحیه
            $dx = match ($c['align'] ?? 'start') {
                'center' => $rx + $pad + (int) (($bw - $nw) / 2),
                'end' => $rx + $rw - $pad - $nw,
                default => $rx + $pad,
            };
            $dy = $ry + $pad + (int) (($bh - $nh) / 2);
            imagealphablending($im, true);
            imagecopyresampled($im, $wm, $dx, $dy, 0, 0, $nw, $nh, $ww, $wh);
            imagedestroy($wm);
        }

        if ($outline) {
            $red = imagecolorallocate($im, 230, 30, 60);
            imagesetthickness($im, max(2, (int) ($W / 300)));
            for ($i = $rx; $i < $rx + $rw; $i += 14) { // کادر نقطه‌چین ناحیه
                imageline($im, $i, $ry, min($i + 7, $rx + $rw), $ry, $red);
                imageline($im, $i, $ry + $rh - 1, min($i + 7, $rx + $rw), $ry + $rh - 1, $red);
            }
            for ($j = $ry; $j < $ry + $rh; $j += 14) {
                imageline($im, $rx, $j, $rx, min($j + 7, $ry + $rh), $red);
                imageline($im, $rx + $rw - 1, $j, $rx + $rw - 1, min($j + 7, $ry + $rh), $red);
            }
        }

        if ($dest === null) {
            return $im;
        }
        $ext = strtolower(pathinfo($dest, PATHINFO_EXTENSION));
        $ok = match ($ext) {
            'png' => imagepng($im, $dest, 6),
            'webp' => function_exists('imagewebp') ? imagewebp($im, $dest, 90) : imagejpeg($im, $dest, 92),
            'gif' => imagegif($im, $dest),
            default => imagejpeg($im, $dest, 92),
        };
        imagedestroy($im);

        return $ok;
    }

    /** پیش‌نمایش به‌صورت data URI (عرض ۶۰۰) */
    public static function preview(string $sample, array $c, bool $outline = true): ?string
    {
        $im = static::apply($sample, null, $c, $outline);
        if (! $im) {
            return null;
        }
        $w = 640;
        $h = (int) round(imagesy($im) * $w / imagesx($im));
        $sm = imagecreatetruecolor($w, $h);
        imagecopyresampled($sm, $im, 0, 0, 0, 0, $w, $h, imagesx($im), imagesy($im));
        ob_start();
        imagejpeg($sm, null, 82);
        $data = ob_get_clean();
        imagedestroy($im);
        imagedestroy($sm);

        return 'data:image/jpeg;base64,'.base64_encode($data);
    }

    /** یک تصویر نمونه برای پیش‌نمایش: آخرین تصویر اصلی دانلودشده */
    public static function sample(): ?string
    {
        $custom = setting('wm_sample');
        if ($custom && is_file(public_path('uploads/'.$custom))) {
            return public_path('uploads/'.$custom);
        }
        $dir = storage_path('app/img-orig/products/sync');
        if (! is_dir($dir)) {
            return null;
        }
        $latest = null;
        $t = 0;
        $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
        $n = 0;
        foreach ($it as $f) {
            if (++$n > 3000) {
                break;
            }
            if ($f->isFile() && $f->getMTime() >= $t) {
                $t = $f->getMTime();
                $latest = $f->getPathname();
            }
        }

        return $latest;
    }

    /** همه تصاویری که نسخه اصلی دارند */
    public static function allRels(): array
    {
        $base = storage_path('app/img-orig/');
        if (! is_dir($base)) {
            return [];
        }
        $out = [];
        $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($base, \FilesystemIterator::SKIP_DOTS));
        foreach ($it as $f) {
            if ($f->isFile()) {
                $out[] = str_replace('\\', '/', substr($f->getPathname(), strlen($base)));
            }
        }
        sort($out);

        return $out;
    }

    protected static function rgb(string $hex): array
    {
        $hex = ltrim(trim($hex), '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        }
        if (! preg_match('/^[0-9a-f]{6}$/i', $hex)) {
            return [255, 255, 255];
        }

        return [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))];
    }
}
