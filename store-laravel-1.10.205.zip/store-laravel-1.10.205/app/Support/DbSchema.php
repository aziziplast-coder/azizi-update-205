<?php

namespace App\Support;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * بررسی وجود جدول/ستون با کش.
 * روی هاست‌های اشتراکی (MySQL/MariaDB) هر Schema::hasColumn یک پرس‌وجوی کند از information_schema است
 * و در هر صفحه پنل ده‌ها بار تکرار می‌شد. حالا «هست» تا نسخه بعد کش می‌شود و «نیست» فقط یک دقیقه
 * (تا ستون تازه پس از اجرای migration زود دیده شود).
 */
class DbSchema
{
    protected static array $mem = [];

    public static function hasTable(string $table): bool
    {
        return static::check($table, null);
    }

    public static function hasColumn(string $table, string $column): bool
    {
        return static::check($table, $column);
    }

    protected static function check(string $table, ?string $column): bool
    {
        $k = $table.'.'.($column ?? '*');
        if (array_key_exists($k, static::$mem)) {
            return static::$mem[$k];
        }
        $ck = 'dbs:'.config('store.version').':'.$k;
        try {
            $hit = Cache::get($ck);
        } catch (Throwable) {
            $hit = null;
        }
        if ($hit !== null) {
            return static::$mem[$k] = (bool) $hit;
        }
        $ok = $column === null ? Schema::hasTable($table) : Schema::hasColumn($table, $column);
        try {
            Cache::put($ck, $ok ? 1 : 0, $ok ? 86400 * 7 : 60);
        } catch (Throwable) {
        }

        return static::$mem[$k] = $ok;
    }

    /** پس از migration: بررسی‌ها از نو */
    public static function flush(): void
    {
        static::$mem = [];
    }
}
