<?php

namespace App\Support;

use App\Models\Order;
use App\Models\RemitPayment;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;
use Throwable;

/**
 * تصویر مدارک (فیش واریز، چک، بیجک) با حجم کم و بدون افت خوانایی:
 * عکس گوشی (۳ تا ۸ مگابایت) ← JPEG حداکثر ۲۰۰۰ پیکسل با کیفیت ۸۵ (حدود ۲۰۰ تا ۴۰۰ کیلوبایت).
 * متن، اعداد و مهر فیش کاملاً خوانا می‌ماند. PDF و HEIC بدون تغییر نگه داشته می‌شوند.
 * همه در پوشه خصوصی storage (نه public) ذخیره می‌شوند.
 */
class DocImages
{
    public const MAX_SIDE = 2000;

    public const QUALITY = 85;

    /** ذخیره فایل بارگذاری‌شده؛ خروجی: مسیر روی دیسک local */
    public static function store(UploadedFile $file, string $dir, string $name): string
    {
        $ext = strtolower($file->getClientOriginalExtension() ?: $file->extension() ?: 'jpg');
        $body = (string) file_get_contents($file->getRealPath());
        if ($ext !== 'pdf') {
            [$body, $ext] = static::shrink($body, $ext);
        }
        $path = trim($dir, '/').'/'.$name.'.'.$ext;
        Storage::disk('local')->put($path, $body);

        return $path;
    }

    /** @return array{0: string, 1: string} [محتوا، پسوند] */
    public static function shrink(string $body, string $ext): array
    {
        if (! @getimagesizefromstring($body)) {
            return [$body, $ext]; // HEIC یا فرمت ناشناخته: همان فایل
        }
        $c = ImageCompressor::compress($body, self::MAX_SIDE, self::QUALITY);

        return [$c['body'], $c['after'] < $c['before'] ? $c['ext'] : $ext];
    }

    /** چرخاندن تصویر روی دیسک (deg: ۹۰ = ساعت‌گرد، ۲۷۰/-۹۰ = پادساعت‌گرد، ۱۸۰ = سروته) */
    public static function rotateFile(string $abs, int $deg): bool
    {
        $body = @file_get_contents($abs);
        $info = $body !== false ? @getimagesizefromstring($body) : false;
        if (! $info || ! function_exists('imagerotate')) {
            return false;
        }
        $im = @imagecreatefromstring($body);
        if (! $im) {
            return false;
        }
        $deg = (($deg % 360) + 360) % 360;
        $r = imagerotate($im, 360 - $deg, 0); // GD پادساعت‌گرد می‌چرخاند
        imagedestroy($im);
        if (! $r) {
            return false;
        }
        ob_start();
        $mime = $info['mime'] ?? 'image/jpeg';
        if ($mime === 'image/png') {
            imagesavealpha($r, true);
            imagepng($r, null, 6);
        } elseif ($mime === 'image/webp' && function_exists('imagewebp')) {
            imagewebp($r, null, 88);
        } else {
            imagejpeg($r, null, 90);
        }
        $out = (string) ob_get_clean();
        imagedestroy($r);
        if (strlen($out) < 100) {
            return false;
        }

        return @file_put_contents($abs, $out, LOCK_EX) !== false;
    }

    /** فشرده‌سازی یک فایل موجود؛ مسیر تازه (اگر پسوند عوض شد) یا همان مسیر */
    public static function shrinkFile(string $path): string
    {
        $disk = Storage::disk('local');
        if (! $disk->exists($path) || str_ends_with(strtolower($path), '.pdf')) {
            return $path;
        }
        $body = (string) $disk->get($path);
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION)) ?: 'jpg';
        [$new, $nExt] = static::shrink($body, $ext);
        if (strlen($new) >= strlen($body)) {
            return $path;
        }
        $to = $nExt === $ext ? $path : preg_replace('/\.[^.\/]+$/', '', $path).'.'.$nExt;
        $disk->put($to, $new);
        if ($to !== $path) {
            $disk->delete($path);
        }

        return $to;
    }

    /**
     * فشرده‌سازی تدریجی مدارک قدیمی (از زمان‌بند، هر بار چند فایل) — فقط فایل‌های بزرگ‌تر از ۶۰۰ کیلوبایت
     */
    public static function backfill(int $max = 8): int
    {
        if (Cache::get('docimg.backfill.done')) {
            return 0;
        }
        $n = 0;
        $big = fn (?string $p) => $p && ! str_ends_with(strtolower($p), '.pdf') && Storage::disk('local')->exists($p) && Storage::disk('local')->size($p) > 600 * 1024;
        try {
            $from = (int) Cache::get('docimg.backfill.pay', 0);
            $pays = RemitPayment::query()->where('id', '>', $from)->whereNotNull('receipt_path')->orderBy('id')->limit(40)->get(['id', 'receipt_path']);
            foreach ($pays as $p) {
                Cache::put('docimg.backfill.pay', $p->id, 86400 * 30);
                if ($n < $max && $big($p->receipt_path)) {
                    $to = static::shrinkFile($p->receipt_path);
                    if ($to !== $p->receipt_path) {
                        RemitPayment::query()->whereKey($p->id)->update(['receipt_path' => $to]);
                    }
                    $n++;
                }
                if ($n >= $max) {
                    return $n;
                }
            }
            $fromO = (int) Cache::get('docimg.backfill.order', 0);
            $orders = Order::query()->where('id', '>', $fromO)->orderBy('id')->limit(40)->get(['id', 'cheque', 'waybill_path']);
            foreach ($orders as $o) {
                Cache::put('docimg.backfill.order', $o->id, 86400 * 30);
                $ch = (array) $o->cheque;
                $dirty = false;
                foreach ((array) ($ch['docs'] ?? []) as $i => $d) {
                    if ($big($d['image'] ?? null)) {
                        $ch['docs'][$i]['image'] = static::shrinkFile($d['image']);
                        $dirty = true;
                        $n++;
                    }
                }
                foreach ((array) ($ch['staff_docs'] ?? []) as $i => $d) {
                    if ($big($d['image'] ?? null)) {
                        $ch['staff_docs'][$i]['image'] = static::shrinkFile($d['image']);
                        $dirty = true;
                        $n++;
                    }
                }
                if ($dirty) {
                    Order::query()->whereKey($o->id)->update(['cheque' => json_encode($ch, JSON_UNESCAPED_UNICODE)]);
                }
                if ($n >= $max) {
                    return $n;
                }
            }
            if ($pays->isEmpty() && $orders->isEmpty()) {
                Cache::put('docimg.backfill.done', 1, 86400); // روز بعد دوباره از جای قبلی ادامه می‌دهد
            }
        } catch (Throwable $e) {
            report($e);
        }

        return $n;
    }
}
