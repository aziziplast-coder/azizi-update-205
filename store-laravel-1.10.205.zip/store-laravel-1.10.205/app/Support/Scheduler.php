<?php

namespace App\Support;

use App\Models\OtpCode;
use App\Models\SmsLog;
use App\Services\Backup;
use App\Services\Checkout;
use Illuminate\Support\Facades\Cache;
use Throwable;

/** کارهای دوره‌ای؛ با کرون هاست (php artisan store:cron) یا خودکار پس از بازدیدها اجرا می‌شود. */
class Scheduler
{
    public static function tick(): array
    {
        $done = [];
        @set_time_limit(300);

        // یادآوری روزانه فیش‌های تأییدنشده به کارخانه‌دارها (ساعت ۹ تا ۲۰)
        try {
            if ((int) now()->format('G') >= 9 && (int) now()->format('G') < 20 && \App\Services\FactoryPortal::remind()) {
                $done[] = 'factory-remind';
            }
        } catch (Throwable $e) {
            report($e);
        }

        // گفتگوها: هشدار پیام بی‌جواب، بستن گفتگوی سفارش‌های تمام‌شده، پاک کردن عکس‌های قدیمی
        try {
            $done = array_merge($done, \App\Services\Chat::tick());
        } catch (Throwable $e) {
            report($e);
        }

        // آمار بازدید: جمع‌بندی خط‌های تازه (سبک)
        try {
            $done = array_merge($done, \App\Services\Stats::tick());
        } catch (Throwable $e) {
            report($e);
        }

        // باشگاه مشتریان: محاسبه روزانه دسته‌ها، فهرست تماس مشاوران، پیامک کمپین‌ها
        try {
            $done = array_merge($done, \App\Services\Crm::tick());
        } catch (Throwable $e) {
            report($e);
        }

        $n = Checkout::cancelStalePending();
        if ($n) {
            $done[] = "cancelled:$n";
        }

        // پایان تخفیف‌های زمان‌دار: قیمت به قبل از تخفیف برمی‌گردد
        $expired = \App\Models\Product::query()->whereNotNull('offer_ends_at')->where('offer_ends_at', '<=', now())->get();
        foreach ($expired as $p) {
            if ($p->compare_price && $p->compare_price > $p->price) {
                $p->price = $p->compare_price;
            }
            $p->compare_price = null;
            $p->offer_ends_at = null;
            $p->is_amazing = false;
            $p->save();
        }
        if ($expired->isNotEmpty()) {
            Cache::forget('home.blocks');
            $done[] = 'offers:'.$expired->count();
        }

        // همگام‌سازی JSON تأمین‌کننده‌ها
        try {
            if (app()->runningInConsole()) {
                Cache::put('cron.cli', now()->toIso8601String(), 86400);
            }
            if (app()->runningInConsole()) {
                \App\Services\Sync\SyncEngine::tick(50);
            } elseif (\App\Services\Sync\SyncWorker::broken() && (function_exists('fastcgi_finish_request') || function_exists('litespeed_finish_request'))) {
                \App\Services\Sync\SyncEngine::tick(15); // درخواست داخلی ممکن نیست: بعد از ارسال پاسخ بازدیدکننده
            } else {
                \App\Services\Sync\SyncEngine::dispatchDue();
            }
        } catch (Throwable $e) {
            report($e);
        }

        // آماده‌سازی تصاویر اپ خرید (کالاهای ناموجود) در پس‌زمینه
        try {
            $n = \App\Services\BuyerImages::warm(app()->runningInConsole() ? 40 : 12, app()->runningInConsole() ? 150 : 30);
            if ($n) {
                $done[] = "buyer-img:$n";
            }
        } catch (Throwable $e) {
            report($e);
        }

        // فشرده‌سازی تدریجی فیش‌ها و تصاویر چک قدیمی (حجم کمتر روی هاست، بدون افت خوانایی)
        try {
            if ($n = \App\Support\DocImages::backfill(app()->runningInConsole() ? 20 : 4)) {
                $done[] = "docs:$n";
            }
        } catch (Throwable $e) {
            report($e);
        }

        // بیعانه: سؤال بی‌پاسخ ← صدور؛ یادآوری و لغو خودکار پس از مهلت واریز
        try {
            $r = \App\Services\Remit::depositTick();
            if (array_sum($r)) {
                $done[] = 'dep:'.$r['issued'].'/'.$r['reminded'].'/'.$r['cancelled'];
            }
        } catch (Throwable $e) {
            report($e);
        }

        // بایگانی فیش‌ها: کوچک کردن فیش‌های تأییدشده قدیمی و (اگر روشن باشد) پاک کردن خیلی قدیمی‌ها
        try {
            $r = \App\Services\DocArchive::tick(app()->runningInConsole() ? 30 : 6);
            if ($r['shrunk'] || $r['deleted']) {
                $done[] = 'fish:'.$r['shrunk'].'/'.$r['deleted'];
            }
        } catch (Throwable $e) {
            report($e);
        }

        // یادآوری بیجک‌های بارگذاری‌نشده
        try {
            \App\Services\Shipping::nagWaybills();
        } catch (Throwable $e) {
            report($e);
        }

        // ربات بله روی هاست جدا: هشدار قطعی/خطا (فقط خواندن حافظه موقت)
        try {
            \App\Services\BotHub::health();
        } catch (Throwable $e) {
            report($e);
        }

        // ارسال کالاها به کانال‌ها
        try {
            $n = \App\Services\Channels::tick();
            if ($n) {
                $done[] = "channels:$n";
            }
        } catch (Throwable $e) {
            report($e);
        }

        // پیامک دعوت به نظرسنجی
        try {
            $n = static::surveySms();
            if ($n) {
                $done[] = "survey:$n";
            }
        } catch (Throwable $e) {
            report($e);
        }

        if (Cache::add('cron.daily.'.now()->format('Ymd'), 1, 86400 * 2)) {
            // سبدهای خالی یا خیلی قدیمی
            try {
                \App\Models\CartRecord::query()->where('updated_at', '<', now()->subDays(max(7, (int) setting('cart_keep_days', 90))))->delete();
                \App\Models\CartRecord::query()->whereNull('order_id')->where('items_count', 0)->where('updated_at', '<', now()->subDays(2))->delete();
                \App\Models\ChannelPost::query()->where('created_at', '<', now()->subDays(120))->delete();
                foreach (glob(storage_path('app/channel-tmp/*.jpg')) ?: [] as $f) {
                    if (filemtime($f) < time() - 86400 * 3) {
                        @unlink($f);
                    }
                }
            } catch (Throwable $e) {
                report($e);
            }
            try {
                if ($n = \App\Support\StaleProducts::run()) {
                    $done[] = "stale:$n";
                }
            } catch (Throwable $e) {
                report($e);
            }
            OtpCode::query()->where('expires_at', '<', now()->subDay())->delete();
            SmsLog::query()->where('created_at', '<', now()->subDays(90))->delete();
            $done[] = 'cleanup';
        }

        if (setting('backup_auto', true) && now()->hour >= (int) setting('backup_hour', 3)) {
            $key = 'cron.backup.'.now()->format('Ymd');
            if (! Cache::has($key)) {
                Cache::put($key, 1, 86400 * 2);
                try {
                    $b = app(Backup::class);
                    $b->create(setting('backup_type', 'db'), 'auto');
                    $b->prune((int) setting('backup_keep', 7));
                    $done[] = 'backup';
                } catch (Throwable $e) {
                    Cache::forget($key);
                    report($e);
                }
            }
        }
        Cache::put('cron.last', now()->toIso8601String(), 86400 * 30);

        return $done;
    }

    /** پیامک لینک نظرسنجی برای سفارش‌هایی که به مرحله نظرسنجی رسیده‌اند */
    public static function surveySms(): int
    {
        $n = 0;
        foreach (\App\Models\Survey::query()->where('is_active', true)->where('send_sms', true)->get() as $s) {
            $orders = \App\Models\Order::query()->whereIn('status', $s->statuses())->whereNull('survey_notified_at')
                ->where('status_changed_at', '<=', now()->subMinutes((int) round($s->delay_hours * 60)))
                ->where('status_changed_at', '>=', now()->subDays(7))
                ->whereNotExists(fn ($q) => $q->selectRaw('1')->from('survey_responses')->whereColumn('survey_responses.order_id', 'orders.id')->where('survey_responses.survey_id', $s->id))
                ->limit(20)->get();
            foreach ($orders as $o) {
                $o->survey_notified_at = now();
                $o->saveQuietly();
                $data = $o->smsData();
                $data['link'] = route('survey', [$o->number, 's' => $s->id]);
                app(\App\Services\Sms::class)->send('survey', $o->mobile, $data, true);
                $n++;
            }
        }

        return $n;
    }
}
