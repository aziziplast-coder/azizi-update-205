<?php

namespace App\Support;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Eloquent\Builder;

/**
 * خروجی JSON کالاها برای همکاران، اپلیکیشن‌ها و سایت‌های دیگر (هر دسته یا همه کالاها با فیلتر).
 */
class Feed
{
    /** فیلدهای قابل انتخاب */
    public const FIELDS = [
        'id' => 'شناسه',
        'name' => 'نام کالا',
        'slug' => 'نامک',
        'url' => 'لینک صفحه کالا',
        'code' => 'کد کالا (SKU یا کد تأمین‌کننده)',
        'barcode' => 'بارکد',
        'price' => 'قیمت هر عدد (عمده)',
        'compare_price' => 'قیمت قبل از تخفیف',
        'discount' => 'درصد تخفیف',
        'carton_price' => 'قیمت هر کارتن',
        'retail_price' => 'قیمت تکی',
        'per_carton' => 'تعداد در کارتن',
        'in_stock' => 'موجود است؟',
        'stock' => 'موجودی انبار (عدد)',
        'retail' => 'خرید تکی فعال؟',
        'category' => 'نام دسته',
        'category_id' => 'شناسه دسته',
        'category_path' => 'مسیر کامل دسته',
        'image' => 'تصویر اصلی',
        'images' => 'همه تصاویر (گالری)',
        'thumb' => 'تصویر کوچک (۴۸۰px webp)',
        'short_description' => 'توضیح کوتاه',
        'description' => 'توضیحات کامل (HTML)',
        'specs' => 'مشخصات فنی',
        'attributes' => 'ویژگی‌ها (رنگ و …)',
        'updated_at' => 'تاریخ آخرین تغییر',
    ];

    public const FORMATS = [
        'standard' => 'استاندارد (فیلدهای انتخابی)',
        'supplier' => 'سازگار با ماژول همگام‌سازی JSON (قالب پخش‌کننده‌ها)',
    ];

    public const SORTS = ['newest' => 'جدیدترین', 'updated' => 'آخرین تغییر', 'price' => 'ارزان‌ترین', 'price_desc' => 'گران‌ترین', 'name' => 'نام', 'sales' => 'پرفروش‌ترین', 'sort' => 'ترتیب نمایش'];

    public static function config(): array
    {
        $c = (array) setting('feed', []);
        $c['enabled'] = ! array_key_exists('enabled', $c) || ! empty($c['enabled']);
        $c['fields'] = array_values(array_intersect((array) ($c['fields'] ?? []), array_keys(self::FIELDS))) ?: ['id', 'name', 'url', 'price', 'in_stock', 'image'];
        $c['markup'] = (float) en_digits((string) ($c['markup'] ?? 0));
        $c['cache'] = max(0, (int) ($c['cache'] ?? 10));
        $c['key'] = trim((string) ($c['key'] ?? ''));
        $c['only_active'] = ! array_key_exists('only_active', $c) || ! empty($c['only_active']);

        return $c;
    }

    /** ساخت پرس‌وجو از پارامترها */
    public static function query(array $p): Builder
    {
        $c = static::config();
        $q = Product::query()->with('category:id,name,parent_id,slug');
        if ($c['only_active'] || empty($p['all'])) {
            $q->where('is_active', true);
        }
        if (! empty($p['category'])) {
            $ids = [];
            foreach (preg_split('/[,،\s]+/u', (string) $p['category']) as $token) {
                if ($token === '') {
                    continue;
                }
                $cat = ctype_digit($token) ? Category::query()->find((int) $token) : Category::query()->where('slug', $token)->first();
                if ($cat) {
                    $ids = array_merge($ids, $cat->descendantIds());
                }
            }
            $q->whereIn('category_id', $ids ?: [0]);
        }
        if (! empty($p['ids'])) {
            $q->whereIn('id', array_map('intval', preg_split('/[,\s]+/', (string) $p['ids'])));
        }
        if (! empty($p['q'])) {
            $q->search((string) $p['q']);
        }
        if (! empty($p['in_stock'])) {
            $q->where('in_stock', true)->where(fn ($w) => $w->whereNull('stock')->orWhereColumn('stock', '>=', 'per_carton'));
        }
        if (! empty($p['has_image'])) {
            $q->whereNotNull('image')->where('image', '!=', '');
        }
        if (! empty($p['on_sale'])) {
            $q->whereColumn('compare_price', '>', 'price');
        }
        if (($min = to_int($p['min_price'] ?? null)) !== null && $min > 0) {
            $q->where('price', '>=', $min);
        }
        if (($max = to_int($p['max_price'] ?? null)) !== null && $max > 0) {
            $q->where('price', '<=', $max);
        }
        if (! empty($p['updated_since'])) {
            try {
                $q->where('updated_at', '>=', \Illuminate\Support\Carbon::parse((string) $p['updated_since']));
            } catch (\Throwable) {
            }
        }
        match ($p['sort'] ?? 'newest') {
            'updated' => $q->orderByDesc('updated_at'),
            'price' => $q->orderBy('price'),
            'price_desc' => $q->orderByDesc('price'),
            'name' => $q->orderBy('name'),
            'sales' => $q->orderByDesc('sales_count'),
            'sort' => $q->orderBy('sort')->orderByDesc('id'),
            default => $q->orderByDesc('id'),
        };

        return $q;
    }

    public static function price(int|float|null $v, float $markup): ?int
    {
        if ($v === null) {
            return null;
        }
        if ($markup == 0.0) {
            return (int) $v;
        }

        return (int) (round($v * (1 + $markup / 100) / 10) * 10);
    }

    protected static function abs(?string $path): ?string
    {
        $u = upload_url($path);

        return $u && str_starts_with($u, '/') && ! str_starts_with($u, '//') ? url($u) : $u;
    }

    public static function categoryPath(?Category $c): string
    {
        static $all = null;
        if (! $c) {
            return '';
        }
        $all ??= Category::query()->get(['id', 'name', 'parent_id'])->keyBy('id');
        $names = [];
        $cur = $all->get($c->id);
        $guard = 0;
        while ($cur && $guard++ < 10) {
            array_unshift($names, $cur->name);
            $cur = $cur->parent_id ? $all->get($cur->parent_id) : null;
        }

        return implode(' > ', $names);
    }

    public static function row(Product $p, array $fields, float $markup): array
    {
        $out = [];
        foreach ($fields as $f) {
            $out[$f] = match ($f) {
                'id' => $p->id,
                'name' => $p->name,
                'slug' => $p->slug,
                'url' => $p->url(),
                'code' => $p->sku ?: ($p->sync_code ?: (string) $p->id),
                'barcode' => $p->barcode,
                'price' => static::price($p->price, $markup),
                'compare_price' => $p->compare_price > $p->price ? static::price($p->compare_price, $markup) : null,
                'discount' => $p->discountPercent(),
                'carton_price' => static::price($p->price * max(1, $p->per_carton), $markup),
                'retail_price' => $p->retail_enabled ? static::price($p->retail_price ?: $p->price, $markup) : null,
                'per_carton' => (int) $p->per_carton,
                'in_stock' => $p->isAvailable(),
                'stock' => $p->stock,
                'retail' => $p->retailAvailable(),
                'category' => $p->category?->name,
                'category_id' => $p->category_id,
                'category_path' => static::categoryPath($p->category),
                'image' => static::abs($p->image),
                'images' => array_values(array_filter(array_map(fn ($g) => static::abs($g), array_merge([$p->image], (array) $p->gallery)))),
                'thumb' => $p->image ? url(thumb($p->image, 480)) : null,
                'short_description' => $p->short_description,
                'description' => $p->description,
                'specs' => (object) ((array) $p->specs),
                'attributes' => collect($p->attributeGroups())->mapWithKeys(fn ($g) => [$g['attr']->name => array_map(fn ($v) => $v->value, $g['values'])])->all(),
                'updated_at' => optional($p->updated_at)->toIso8601String(),
                default => null,
            };
        }

        return $out;
    }

    /** قالب سازگار با فیدهای پخش‌کننده‌ها (همان قالبی که ماژول همگام‌سازی می‌خواند) */
    public static function supplierRow(Product $p, float $markup): array
    {
        return [
            'id' => (string) $p->id,
            'title' => $p->name,
            'url' => $p->url(),
            'img' => static::abs($p->image),
            'images' => array_values(array_filter(array_map(fn ($g) => static::abs($g), (array) $p->gallery))),
            'price' => static::price($p->price, $markup),
            'old_price' => $p->compare_price > $p->price ? static::price($p->compare_price, $markup) : 0,
            'is_available' => $p->isAvailable(),
            'tedad_dar_carton' => fa($p->per_carton).' عدد',
            'tedad_afzayesh' => (int) $p->per_carton,
            'code' => $p->sku ?: ($p->sync_code ?: (string) $p->id),
            'barcode' => $p->barcode,
            'cat' => static::categoryPath($p->category),
            'stock' => $p->stock,
        ];
    }

    /** ساخت خروجی کامل */
    public static function build(array $p): array
    {
        $c = static::config();
        $fields = array_values(array_intersect(array_map('trim', explode(',', (string) ($p['fields'] ?? ''))), array_keys(self::FIELDS))) ?: $c['fields'];
        $limit = max(1, min(2000, (int) ($p['limit'] ?? 500)));
        $page = max(1, (int) ($p['page'] ?? 1));
        $markup = array_key_exists('markup', $p) && $p['markup'] !== '' ? (float) $p['markup'] : $c['markup'];
        $format = ($p['format'] ?? 'standard') === 'supplier' ? 'supplier' : 'standard';

        $q = static::query($p);
        $total = (clone $q)->count();
        $rows = $q->forPage($page, $limit)->get();
        if (in_array('attributes', $fields, true)) {
            $rows->load('attributeValues.attribute');
        }
        $items = $rows->map(fn (Product $x) => $format === 'supplier' ? static::supplierRow($x, $markup) : static::row($x, $fields, $markup))->all();

        return [
            'success' => true,
            'store' => store_name(),
            'generated_at' => now()->toIso8601String(),
            'currency' => 'IRT',
            'total' => $total,
            'count' => count($items),
            'page' => $page,
            'pages' => (int) ceil($total / $limit),
            'products' => $items,
        ];
    }
}
