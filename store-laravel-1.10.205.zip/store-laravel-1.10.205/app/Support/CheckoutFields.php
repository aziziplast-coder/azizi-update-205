<?php

namespace App\Support;

/**
 * فیلدهای «اطلاعات گیرنده» در صفحه تسویه: هر فیلد اجباری / اختیاری / پنهان، با عنوان قابل تغییر،
 * به‌علاوه فیلدهای دلخواه مدیر (ذخیره در سفارش).
 */
class CheckoutFields
{
    public const BASE = [
        'name' => 'نام و نام خانوادگی',
        'company' => 'نام فروشگاه / شرکت',
        'province' => 'استان',
        'city' => 'شهر',
        'address' => 'آدرس کامل',
        'postal_code' => 'کد پستی',
        'note' => 'توضیحات سفارش',
    ];

    public const DEFAULT_MODES = [
        'name' => 'required', 'company' => 'optional', 'province' => 'required', 'city' => 'required',
        'address' => 'required', 'postal_code' => 'optional', 'note' => 'optional',
    ];

    /** @return array<string, array{mode: string, label: string}> */
    public static function base(): array
    {
        $cfg = (array) setting('checkout_fields', []);
        $out = [];
        foreach (static::BASE as $k => $label) {
            $c = (array) ($cfg[$k] ?? []);
            $mode = in_array($c['mode'] ?? '', ['required', 'optional', 'hidden'], true) ? $c['mode'] : static::DEFAULT_MODES[$k];
            $out[$k] = ['mode' => $mode, 'label' => trim((string) ($c['label'] ?? '')) ?: $label];
        }

        return $out;
    }

    /** @return array<int, array{key: string, label: string, type: string, required: bool, options: array, help: string}> */
    public static function extra(): array
    {
        $out = [];
        foreach ((array) setting('checkout_extra', []) as $i => $f) {
            $label = trim((string) ($f['label'] ?? ''));
            if ($label === '' || empty($f['enabled'] ?? true)) {
                continue;
            }
            $out[] = [
                'key' => 'x'.substr(md5($label.$i), 0, 8),
                'label' => $label,
                'type' => in_array($f['type'] ?? '', ['text', 'textarea', 'number', 'select', 'date'], true) ? $f['type'] : 'text',
                'required' => ! empty($f['required']),
                'options' => array_values(array_filter(array_map('trim', preg_split('/[\n،,]+/u', (string) ($f['options'] ?? ''))))),
                'help' => trim((string) ($f['help'] ?? '')),
            ];
        }

        return $out;
    }

    /** قوانین اعتبارسنجی */
    public static function rules(): array
    {
        $max = ['name' => 120, 'company' => 150, 'province' => 60, 'city' => 80, 'address' => 500, 'postal_code' => 20, 'note' => 1000];
        $rules = [];
        foreach (static::base() as $k => $f) {
            $rules[$k] = $f['mode'] === 'required' ? 'required|string|max:'.$max[$k] : 'nullable|string|max:'.$max[$k];
        }
        foreach (static::extra() as $f) {
            $r = [$f['required'] ? 'required' : 'nullable', 'string', 'max:1000'];
            if ($f['type'] === 'select' && $f['options']) {
                $r[] = 'in:'.implode(',', array_map(fn ($o) => str_replace(',', ' ', $o), $f['options']));
            }
            $rules['xf.'.$f['key']] = $r;
        }

        return $rules;
    }

    public static function attributes(): array
    {
        $a = [];
        foreach (static::base() as $k => $f) {
            $a[$k] = $f['label'];
        }
        foreach (static::extra() as $f) {
            $a['xf.'.$f['key']] = $f['label'];
        }

        return $a;
    }

    /** مقادیر فیلدهای دلخواه برای ذخیره در سفارش: [عنوان => مقدار] */
    public static function collect(array $input): array
    {
        $out = [];
        foreach (static::extra() as $f) {
            $v = trim(strip_tags((string) ($input[$f['key']] ?? '')));
            if ($v !== '') {
                $out[$f['label']] = mb_substr($v, 0, 1000);
            }
        }

        return $out;
    }
}
