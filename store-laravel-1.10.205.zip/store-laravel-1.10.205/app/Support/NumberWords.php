<?php

namespace App\Support;

class NumberWords
{
    public static function convert(int|float $number): string
    {
        $number = (int) floor(abs((float) $number));
        if ($number === 0) {
            return 'صفر';
        }
        $scales = ['', 'هزار', 'میلیون', 'میلیارد', 'هزار میلیارد'];
        $groups = [];
        while ($number > 0) {
            $groups[] = $number % 1000;
            $number = intdiv($number, 1000);
        }
        $parts = [];
        for ($i = count($groups) - 1; $i >= 0; $i--) {
            if ($groups[$i] === 0) {
                continue;
            }
            $parts[] = trim(static::three($groups[$i]).' '.($scales[$i] ?? ''));
        }

        return implode(' و ', $parts);
    }

    protected static function three(int $n): string
    {
        $ones = ['', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه'];
        $teens = ['ده', 'یازده', 'دوازده', 'سیزده', 'چهارده', 'پانزده', 'شانزده', 'هفده', 'هجده', 'نوزده'];
        $tens = ['', '', 'بیست', 'سی', 'چهل', 'پنجاه', 'شصت', 'هفتاد', 'هشتاد', 'نود'];
        $hundreds = ['', 'یکصد', 'دویست', 'سیصد', 'چهارصد', 'پانصد', 'ششصد', 'هفتصد', 'هشتصد', 'نهصد'];
        $parts = [];
        $h = intdiv($n, 100);
        $r = $n % 100;
        if ($h) {
            $parts[] = $hundreds[$h];
        }
        if ($r >= 10 && $r < 20) {
            $parts[] = $teens[$r - 10];
        } else {
            if ($t = intdiv($r, 10)) {
                $parts[] = $tens[$t];
            }
            if ($o = $r % 10) {
                $parts[] = $ones[$o];
            }
        }

        return implode(' و ', $parts);
    }
}
