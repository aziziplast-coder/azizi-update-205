<?php

namespace App\Support;

use App\Models\Order;
use App\Services\Cheques;
use App\Services\Shipping;

/**
 * مراحل سفارش به زبان ساده برای مشتری + «الان نوبت چه کاری است»
 * (صفحه سفارش، فهرست «سفارش‌های من» و اپ)
 */
class OrderJourney
{
    /**
     * @return array{steps: array<int, array{key: string, label: string, icon: string, state: string, note: string}>, action: array{tone: string, icon: string, title: string, text: string, href: string, btn: string}, pct: int, cancelled: bool}
     */
    public static function for(Order $o): array
    {
        $rank = Order::STATUS_RANK[$o->status] ?? 0;
        $cancelled = in_array($o->status, ['cancelled', 'failed'], true);
        $pays = $o->relationLoaded('remitPayments') ? $o->remitPayments : $o->remitPayments()->get();
        $pays = $pays->where('status', '!=', 'cancelled');
        $deps = $pays->where('kind', 'deposit');
        $ch = (array) $o->cheque;
        $hasCheques = ! empty($ch['settle']);
        $freight = Shipping::isFreight($o);

        $st = fn (bool $done, bool $cur) => $done ? 'done' : ($cur ? 'cur' : 'todo');
        $steps = [];
        $steps[] = ['key' => 'placed', 'label' => 'ثبت سفارش', 'icon' => '📝', 'state' => 'done', 'note' => jdate($o->created_at)];
        $depDone = $rank >= 1 || ($deps->isNotEmpty() && $deps->every(fn ($p) => $p->status === 'confirmed'));
        $steps[] = ['key' => 'deposit', 'label' => $deps->isNotEmpty() ? 'پرداخت بیعانه' : 'تأیید سفارش', 'icon' => '💳', 'state' => $st($depDone, $rank === 0), 'note' => ''];
        $pickDone = $rank >= 2 || $o->fulfil_status === 'picked';
        $steps[] = ['key' => 'pick', 'label' => 'آماده‌سازی در انبار', 'icon' => '📦', 'state' => $st($pickDone, $depDone && ! $pickDone), 'note' => ''];
        $paid = $o->isPaid() || $rank >= 3;
        $steps[] = ['key' => 'settle', 'label' => 'تسویه حساب', 'icon' => '🧾', 'state' => $st($paid, $pickDone && ! $paid), 'note' => ''];
        if ($hasCheques) {
            $chDone = (bool) $o->cheques_received_at || (($ch['post']['st'] ?? '') === 'approved');
            $steps[] = ['key' => 'cheques', 'label' => 'تحویل چک‌ها', 'icon' => '✍️', 'state' => $st($chDone, ! $chDone), 'note' => ''];
        }
        // تأیید نهایی سفارش (تأیید فیش‌ها) ← «در حال ارسال به باربری»
        $steps[] = ['key' => 'ship', 'label' => $freight ? 'در حال ارسال به باربری' : 'ارسال / تحویل', 'icon' => '🚚', 'state' => $st($rank >= 5 || ($rank === 4 && $o->loaded_at), $rank >= 3 && $rank < 5), 'note' => $o->loaded_at ? jdate($o->loaded_at) : ''];
        $steps[] = ['key' => 'done', 'label' => 'تکمیل سفارش', 'icon' => '✅', 'state' => $st($rank >= 5, $rank === 4), 'note' => ''];
        // فقط یک «مرحله فعلی» (برای سادگی)
        $seen = false;
        foreach ($steps as &$s) {
            if ($s['state'] === 'cur') {
                $s['state'] = $seen ? 'todo' : 'cur';
                $seen = true;
            }
        }
        unset($s);
        if ($cancelled) {
            foreach ($steps as &$s) {
                if ($s['state'] !== 'done') {
                    $s['state'] = 'off';
                }
            }
            unset($s);
        }
        $done = collect($steps)->where('state', 'done')->count();

        return [
            'steps' => $steps,
            'action' => static::action($o, $pays, $rank, $cancelled, $freight),
            'pct' => (int) round($done * 100 / max(1, count($steps))),
            'cancelled' => $cancelled,
        ];
    }

    protected static function action(Order $o, $pays, int $rank, bool $cancelled, bool $freight): array
    {
        $url = route('order.show', $o->number);
        $a = fn (string $tone, string $icon, string $title, string $text = '', string $href = '', string $btn = '') => compact('tone', 'icon', 'title', 'text', 'href', 'btn');

        if ($cancelled) {
            return $a('bad', '✖️', 'این سفارش لغو شد', (string) ($o->cancel_reason ?: ''));
        }
        if ($o->review_status === 'pending') {
            return $a('wait', '🔎', 'سفارش در حال بررسی است', 'کارشناس سفارش چکی شما را بررسی می‌کند؛ نتیجه پیامک می‌شود.');
        }
        if ($rank >= 3) {
            $pays = $pays->where('status', 'confirmed'); // پرداخت کامل است؛ فیش‌های قدیمی دیگر اقدامی لازم ندارند
        }
        $rej = $pays->firstWhere('status', 'rejected');
        if ($rej) {
            return $a('todo', '⚠️', 'فیش واریزی تأیید نشد', 'علت: '.($rej->reject_reason ?: '—').'. لطفاً فیش درست را دوباره بفرستید.', $url.'#pay', 'ارسال دوباره فیش');
        }
        $due = $pays->where('status', 'awaiting');
        if ($due->isNotEmpty()) {
            return $a('todo', '💳', 'نوبت شماست: واریز '.money($due->sum('amount')).' تومان', ($due->count() > 1 ? 'این مبلغ باید به '.fa($due->count()).' حساب جدا واریز شود. ' : '').'پس از واریز، عکس فیش را بفرستید.', $url.'#pay', 'واریز و ارسال فیش');
        }
        if ($o->canReplace() && ! $o->replace_submitted_at) {
            return $a('todo', '🔁', 'چند کالا در انبار نبود', 'اگر می‌خواهید، کالای جایگزین انتخاب کنید'.($o->replace_until ? ' (تا '.jdate($o->replace_until, true).')' : '').'.', $url.'#replace', 'انتخاب جایگزین');
        }
        if (! $o->cheques_received_at && Cheques::docsMissing($o)) {
            return $a('todo', '✍️', 'نوبت شماست: ارسال تصویر چک‌ها', 'برای هر چک، عکس خود چک و عکس ثبت آن در سامانه صیاد را بفرستید.', $url.'#cheques', 'ارسال تصویر چک‌ها');
        }
        if ($pays->where('status', 'submitted')->isNotEmpty()) {
            return $a('wait', '⏳', 'فیش شما رسید', 'کارشناس در حال بررسی واریز شماست. نیازی به کاری نیست.');
        }
        if (Cheques::docsPending($o) > 0) {
            return $a('wait', '⏳', 'تصاویر چک‌ها رسید', 'کارشناس در حال بررسی است. نیازی به کاری نیست.');
        }

        return match ($o->status) {
            'on_hold', 'pending_payment' => $a('wait', '🕐', 'سفارش ثبت شد', 'کارشناس به‌زودی سفارش را بررسی و مبلغ بیعانه را اعلام می‌کند (پیامک می‌شود).'),
            'processing' => $a('wait', '📦', 'در حال آماده‌سازی در انبار', 'کالاها در انبار جمع‌آوری می‌شوند؛ پس از آن مبلغ نهایی اعلام می‌شود.'),
            'settling' => $o->isPaid()
                ? $a('wait', '🕐', 'پرداخت کامل شد', \App\Services\Shipping::hasCheques($o) ? 'به‌محض رسیدن چک‌ها، بار برای ارسال آماده می‌شود.' : 'پس از تأیید نهایی واریزها، بار برای ارسال آماده می‌شود.')
                : $a('wait', '🧾', 'محاسبه مبلغ نهایی', 'کارشناس مبلغ نهایی (تسویه حساب) را به‌زودی اعلام می‌کند.'),
            'to_freight' => $a('wait', '⏳', $freight ? 'بار در صف ارسال به باربری است' : 'بار آماده ارسال است', 'پرداخت کامل است؛ بار به‌زودی بارگیری می‌شود.'),
            'shipped' => $o->loaded_at ? $a('ok', '🚚', $freight ? 'بار تحویل باربری شد' : 'بار ارسال شد', 'عکس بیجک به‌زودی همین‌جا قرار می‌گیرد.')
                : $a('wait', '🚚', $freight ? 'بار در حال ارسال به باربری است' : 'بار در حال ارسال است', 'سفارش تأیید نهایی شد؛ بار به‌زودی بارگیری می‌شود.'),
            'completed' => $a('ok', '✅', 'سفارش تکمیل شد', $o->waybill_path ? 'عکس بیجک باربری را ببینید. سؤالی دارید؟ با پشتیبانی در تماس باشید.' : 'از خرید شما سپاسگزاریم.', $o->waybill_path ? route('order.waybill', $o->number) : '', $o->waybill_path ? 'مشاهده بیجک' : ''),
            default => $a('wait', 'ℹ️', $o->statusLabel()),
        };
    }

    /** لینک پشتیبانی روبیکا (تنظیمات ← سفارش؛ پیش‌فرض @Plascoz) */
    public static function supportUrl(): string
    {
        $id = ltrim(trim((string) setting('support_rubika', 'Plascoz')), '@');

        return $id === '' ? '' : 'https://rubika.ir/'.rawurlencode($id);
    }

    public static function supportId(): string
    {
        return ltrim(trim((string) setting('support_rubika', 'Plascoz')), '@');
    }
}
