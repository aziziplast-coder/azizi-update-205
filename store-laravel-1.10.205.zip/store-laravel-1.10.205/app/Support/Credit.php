<?php

namespace App\Support;

/**
 * امضای طراح («طراحی و توسعه: …» با پیوند به سایت طراح) — از تنظیمات «اپ موبایل ← طراحی و توسعه».
 * فقط جاهایی که مشتری یا کارخانه‌دار می‌بیند: پایین سایت، اپ مشتری، اپ کارخانه‌داران، PDF واریزی‌های حواله، برگه خرید کارخانه.
 */
class Credit
{
    public static function get(): ?array
    {
        try {
            $c = AppUx::cfg()['credit'] ?? [];
        } catch (\Throwable) {
            return null;
        }

        return ($c['text'] ?? '') !== '' ? ['text' => $c['text'], 'url' => $c['url'] ?? ''] : null;
    }

    public static function html(string $style = ''): string
    {
        $c = static::get();
        if (! $c) {
            return '';
        }
        $t = e($c['text']);
        $in = $c['url'] !== '' ? '<a href="'.e($c['url']).'" target="_blank" rel="noopener" style="color:inherit;text-decoration:none;border-bottom:1px dotted currentColor">'.$t.'</a>' : $t;

        return '<div class="dev-credit" style="text-align:center;font-size:11.5px;opacity:.7;padding:8px 0;'.$style.'">'.$in.'</div>';
    }

    public static function text(): string
    {
        $c = static::get();

        return $c ? $c['text'].($c['url'] !== '' ? ' — '.$c['url'] : '') : '';
    }
}
