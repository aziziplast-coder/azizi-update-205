<?php

namespace App\Support;

/**
 * سازنده فایل اکسل ۹۷-۲۰۰۳ (.xls / BIFF8) بدون نیاز به کتابخانه.
 * برای ورود به نرم‌افزار حسابداری هلو که فقط این قالب را می‌پذیرد.
 * یک برگه، رشته‌های یونیکد (فارسی)، عدد با قالب «#,##0» و برگه راست‌به‌چپ.
 */
class XlsWriter
{
    /** @var array<int, array<int, mixed>> */
    protected array $rows = [];

    /** ستون‌هایی که با جداکننده هزارگان نمایش داده شوند (اندیس از صفر) */
    protected array $moneyCols = [];

    public function __construct(protected string $sheet = 'Sheet1', protected bool $rtl = true)
    {
    }

    public function row(array $cells): static
    {
        $this->rows[] = array_values($cells);

        return $this;
    }

    public function money(array $cols): static
    {
        $this->moneyCols = $cols;

        return $this;
    }

    public function output(): string
    {
        return static::ole2($this->workbook());
    }

    /* ---------------- BIFF8 ---------------- */

    protected static function rec(int $type, string $data): string
    {
        return pack('vv', $type, strlen($data)).$data;
    }

    protected static function u16(string $s): string
    {
        return mb_convert_encoding($s, 'UTF-16LE', 'UTF-8');
    }

    protected function workbook(): string
    {
        // رشته‌های یکتا (SST)
        $sst = [];
        $total = 0;
        foreach ($this->rows as $r) {
            foreach ($r as $v) {
                if (is_string($v) && ! is_numeric($v)) {
                    $total++;
                    $sst[$v] ??= count($sst);
                }
            }
        }

        $g = static::rec(0x0809, pack('vvvv', 0x0600, 0x0005, 0x0DBB, 0x07CC).pack('VV', 0x000000C1, 0x00000006)); // BOF
        $g .= static::rec(0x00E1, pack('v', 0x04B0)); // INTERFACEHDR
        $g .= static::rec(0x00C1, pack('v', 0)); // MMS
        $g .= static::rec(0x00E2, ''); // INTERFACEEND
        $g .= static::rec(0x0042, pack('v', 0x04B0)); // CODEPAGE = UTF-16
        $g .= static::rec(0x003D, pack('vvvvvvvvv', 0, 0, 0x25BC, 0x1572, 0x0038, 0, 0, 1, 0x0258)); // WINDOW1
        $g .= static::rec(0x0022, pack('v', 0)); // DATEMODE 1900
        $font = static::u16('Tahoma');
        for ($i = 0; $i < 5; $i++) { // فونت ۰ تا ۳ و ۵ (اندیس ۴ رزرو است)
            $g .= static::rec(0x0031, pack('vvvvvCCCC', 200, 0, 0x7FFF, $i === 1 ? 700 : 400, 0, 0, 0, 0, 0).pack('CC', mb_strlen('Tahoma'), 1).$font);
        }
        // ۱۵ XF سبک + XF سلول عادی (۱۵) + XF سلول عدد هزارگان (۱۶) + XF سلول سرستون پررنگ (۱۷)
        $xf = fn (int $font, int $fmt, int $type, int $used) => static::rec(0x00E0, pack('vvvCCCCVVv', $font, $fmt, $type, 0x20, 0, 0, $used, 0, 0, 0x20C0));
        $g .= $xf(0, 0, 0xFFF5, 0);
        for ($i = 1; $i < 15; $i++) {
            $g .= $xf(0, 0, 0xFFF5, 0xF4);
        }
        $g .= $xf(0, 0, 0x0001, 0);
        $g .= $xf(0, 3, 0x0001, 0x04); // قالب داخلی ۳ = #,##0
        $g .= $xf(1, 0, 0x0001, 0x08);
        $g .= static::rec(0x0293, pack('vCC', 0x8000, 0, 0xFF)); // STYLE Normal
        $name = $this->sheet;
        $bsPos = strlen($g);
        $g .= static::rec(0x0085, pack('VvCC', 0, 0, mb_strlen($name), 1).static::u16($name)); // BOUNDSHEET (جای آدرس بعداً)
        // SST
        $body = pack('VV', $total, count($sst));
        foreach (array_keys($sst) as $s) {
            $s = (string) $s;
            $body .= pack('vC', mb_strlen($s), 1).static::u16($s);
        }
        $g .= static::rec(0x00FC, $body);
        $g .= static::rec(0x000A, ''); // EOF

        // برگه
        $nRows = count($this->rows);
        $nCols = max(1, ...array_map('count', $this->rows ?: [[]]));
        $w = static::rec(0x0809, pack('vvvv', 0x0600, 0x0010, 0x0DBB, 0x07CC).pack('VV', 0x000000C1, 0x00000006));
        $w .= static::rec(0x0200, pack('VVvvv', 0, $nRows, 0, $nCols, 0)); // DIMENSIONS
        foreach ($this->rows as $ri => $r) {
            foreach ($r as $ci => $v) {
                if ($v === null || $v === '') {
                    continue;
                }
                if (is_int($v) || is_float($v) || (is_string($v) && is_numeric($v))) {
                    $ixfe = in_array($ci, $this->moneyCols, true) && $ri > 0 ? 16 : 15;
                    $w .= static::rec(0x0203, pack('vvv', $ri, $ci, $ixfe).pack('e', (float) $v)); // NUMBER
                } else {
                    $w .= static::rec(0x00FD, pack('vvvV', $ri, $ci, $ri === 0 ? 17 : 15, $sst[(string) $v])); // LABELSST
                }
            }
        }
        $w .= static::rec(0x023E, pack('vvvVvvV', 0x06B6 | ($this->rtl ? 0x0040 : 0), 0, 0, 0x40, 0, 0, 0)); // WINDOW2
        $w .= static::rec(0x000A, '');

        // آدرس برگه در BOUNDSHEET
        $g = substr_replace($g, pack('V', strlen($g)), $bsPos + 4, 4);

        return $g.$w;
    }

    /* ---------------- ظرف OLE2 (Compound File) ---------------- */

    protected static function ole2(string $stream): string
    {
        if (strlen($stream) < 4096) {
            $stream .= str_repeat("\0", 4096 - strlen($stream)); // بدون نیاز به MiniStream
        }
        $size = strlen($stream);
        $stream .= str_repeat("\0", (512 - $size % 512) % 512);
        $nData = intdiv(strlen($stream), 512);
        $nFat = 1;
        while ($nData + $nFat + 1 > $nFat * 128) {
            $nFat++;
        }
        if ($nFat > 109) {
            throw new \RuntimeException('فایل اکسل بیش از حد بزرگ است.');
        }
        $fatStart = $nData;
        $dirStart = $nData + $nFat;
        $fat = [];
        for ($i = 0; $i < $nData; $i++) {
            $fat[] = $i === $nData - 1 ? 0xFFFFFFFE : $i + 1;
        }
        for ($i = 0; $i < $nFat; $i++) {
            $fat[] = 0xFFFFFFFD;
        }
        $fat[] = 0xFFFFFFFE; // دایرکتوری
        while (count($fat) < $nFat * 128) {
            $fat[] = 0xFFFFFFFF;
        }
        $fatBin = '';
        foreach ($fat as $f) {
            $fatBin .= pack('V', $f);
        }

        $entry = function (string $name, int $type, int $child, int $start, int $size) {
            $n = $name === '' ? '' : mb_convert_encoding($name, 'UTF-16LE', 'UTF-8')."\0\0";
            $e = str_pad($n, 64, "\0");
            $e .= pack('vCC', strlen($n), $type, 1);
            $e .= pack('VVV', 0xFFFFFFFF, 0xFFFFFFFF, $child);
            $e .= str_repeat("\0", 16).pack('V', 0).str_repeat("\0", 16);
            $e .= pack('VVV', $start, $size, 0);

            return $e;
        };
        $dir = $entry('Root Entry', 5, 1, 0xFFFFFFFE, 0).$entry('Workbook', 2, 0xFFFFFFFF, 0, $size);
        $empty = str_repeat("\0", 64).pack('vCC', 0, 0, 0).pack('VVV', 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF).str_repeat("\0", 36).pack('VVV', 0, 0, 0);
        $dir .= $empty.$empty;

        $difat = '';
        for ($i = 0; $i < 109; $i++) {
            $difat .= pack('V', $i < $nFat ? $fatStart + $i : 0xFFFFFFFF);
        }
        $hdr = "\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1".str_repeat("\0", 16)
            .pack('vvvvv', 0x003E, 0x0003, 0xFFFE, 9, 6).str_repeat("\0", 6)
            .pack('VVVVVVVVV', 0, $nFat, $dirStart, 0, 4096, 0xFFFFFFFE, 0, 0xFFFFFFFE, 0)
            .$difat;

        return $hdr.$stream.$fatBin.$dir;
    }
}
