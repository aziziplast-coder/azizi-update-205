<?php

namespace App\Support;

use Throwable;

/**
 * کارهای کند بیرونی (پیامک، اعلان) پس از ارسال پاسخ به کاربر انجام می‌شوند
 * تا کلیک کارمند منتظر پنل پیامک یا سرویس اعلان نماند.
 * در خط فرمان یا وقتی پاسخ قبلاً فرستاده شده (کرون صفحه‌ای)، همان لحظه اجرا می‌شود.
 */
class AfterResponse
{
    protected static array $queue = [];

    protected static bool $hooked = false;

    protected static bool $flushing = false;

    public static function run(callable $fn): void
    {
        if (static::$flushing || app()->runningInConsole() || ! setting('defer_notify', true)) {
            static::call($fn);

            return;
        }
        static::$queue[] = $fn;
        if (! static::$hooked) {
            static::$hooked = true;
            app()->terminating(fn () => static::flush());
        }
    }

    public static function flush(): void
    {
        static::$flushing = true;
        @set_time_limit(120);
        @ignore_user_abort(true);
        while ($fn = array_shift(static::$queue)) {
            static::call($fn);
        }
        static::$flushing = false;
        static::$hooked = false;
    }

    protected static function call(callable $fn): void
    {
        try {
            $fn();
        } catch (Throwable $e) {
            report($e);
        }
    }
}
