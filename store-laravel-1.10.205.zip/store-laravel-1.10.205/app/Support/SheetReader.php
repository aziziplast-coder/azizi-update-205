<?php

namespace App\Support;

use DOMDocument;
use DOMElement;
use Exception;
use XMLReader;
use ZipArchive;

/**
 * خوانندهٔ همه‌کارهٔ فایل‌های جدولی — بدون نیاز به هیچ کتابخانهٔ خارجی.
 * نوع فایل از روی «محتوا» تشخیص داده می‌شود، نه پسوند؛ پس اگر پسوند فایل اشتباه باشد هم خوانده می‌شود.
 *
 * پشتیبانی:
 *  - xls  (اکسل ۹۷ تا ۲۰۰۳ / BIFF8 و اکسل ۹۵ / BIFF5 و BIFF3-4)
 *  - xlsx / xlsm / xltx / xltm (اکسل ۲۰۰۷ به بعد)
 *  - xlsb (اکسل باینری)
 *  - ods  (LibreOffice / OpenOffice)
 *  - XML Spreadsheet 2003
 *  - HTML با پسوند xls (خروجی بسیاری از نرم‌افزارهای حسابداری و سایت‌ها)
 *  - csv / tsv / txt (UTF-8، UTF-16 و ANSI فارسی Windows-1256)
 *
 * هر ردیف به صورت آرایهٔ [شمارهٔ ستون از صفر => مقدار متنی] به callback داده می‌شود.
 * ردیف‌های کاملاً خالی ارسال نمی‌شوند.
 */
class SheetReader {

    public static $exts = array('xls', 'xlsx', 'xlsm', 'xltx', 'xltm', 'xlt', 'xlsb', 'ods', 'csv', 'tsv', 'txt', 'xml', 'htm', 'html');

    /** خواندن فایل؛ $only = فهرست ستون‌های لازم (برای سرعت) یا null برای همه */
    public static function read($path, $name, $cb, $only = null) {
        if (!is_readable($path) || !filesize($path)) throw new Exception('فایل خالی است یا خوانده نمی‌شود: ' . $name);
        $type = self::detect($path, $name);
        switch ($type) {
            case 'xls':  return self::read_xls($path, $cb, $name);
            case 'xlsx': return self::read_xlsx($path, $cb, $only, $name);
            case 'xlsb': return self::read_xlsb($path, $cb, $name);
            case 'ods':  return self::read_ods($path, $cb, $name);
            case 'xml':  return self::read_xml2003($path, $cb);
            case 'html': return self::read_html($path, $cb, $name);
            case 'enc':  throw new Exception('فایل «' . $name . '» رمز عبور دارد. ابتدا در اکسل رمز را بردارید و دوباره ذخیره کنید.');
            default:     return self::read_csv($path, $cb);
        }
    }

    /* ======================================================================
     *  تشخیص نوع فایل
     * ==================================================================== */
    public static function detect($path, $name = '') {
        $fh = fopen($path, 'rb');
        $head = fread($fh, 4096);
        fclose($fh);

        if (strncmp($head, "\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1", 8) === 0) {
            // فایل OLE: یا xls قدیمی است یا xlsx رمزدار
            $ole = new SheetOle($path);
            if ($ole->find(array('EncryptedPackage')) !== null) return 'enc';
            return 'xls';
        }
        // BIFF2-4 بدون ظرف OLE
        if (strlen($head) > 4 && $head[0] === "\x09" && in_array($head[1], array("\x00", "\x02", "\x04", "\x08"), true)) return 'xls';

        if (strncmp($head, "PK", 2) === 0 && class_exists('ZipArchive')) {
            $z = new ZipArchive();
            if ($z->open($path) === true) {
                $t = null;
                if ($z->locateName('xl/workbook.bin') !== false) $t = 'xlsb';
                elseif ($z->locateName('content.xml') !== false) $t = 'ods';
                else {
                    for ($i = 0; $i < $z->numFiles; $i++) {
                        $n = $z->getNameIndex($i);
                        if (preg_match('#(^|/)worksheets/[^/]+\.xml$#i', $n) || preg_match('#workbook\.xml$#i', $n)) { $t = 'xlsx'; break; }
                    }
                }
                $z->close();
                if ($t) return $t;
            }
            throw new Exception('فایل فشرده است ولی ساختار اکسل معتبری ندارد.');
        }

        // فایل‌های متنی
        $txt = self::to_utf8_head($head);
        $low = strtolower($txt);
        if (strpos($low, 'urn:schemas-microsoft-com:office:spreadsheet') !== false && strpos($low, '<workbook') !== false) return 'xml';
        if (preg_match('/<(table|html|tr)[\s>]/i', $txt)) return 'html';
        if (strpos($low, '<?xml') !== false && strpos($low, '<table:') !== false) return 'xml';
        return 'csv';
    }

    private static function to_utf8_head($s) {
        if (strncmp($s, "\xFF\xFE", 2) === 0) return self::conv(substr($s, 2), 'UTF-16LE');
        if (strncmp($s, "\xFE\xFF", 2) === 0) return self::conv(substr($s, 2), 'UTF-16BE');
        return $s;
    }

    /* ======================================================================
     *  ابزارهای کمکی
     * ==================================================================== */

    /** تبدیل کدگذاری به UTF-8 با پشتیبانی کامل از Windows-1256 حتی بدون iconv */
    public static function conv($s, $from) {
        if ($s === '') return '';
        $from = strtoupper($from);
        if ($from === 'UTF-8') return $s;
        if ($from === 'CP1256' || $from === 'WINDOWS-1256') return self::cp1256($s);
        if (function_exists('mb_convert_encoding')) {
            $r = @mb_convert_encoding($s, 'UTF-8', $from === 'ISO-8859-1' ? 'ISO-8859-1' : $from);
            if ($r !== false && $r !== null) return $r;
        }
        if (function_exists('iconv')) {
            $r = @iconv($from, 'UTF-8//IGNORE', $s);
            if ($r !== false) return $r;
        }
        return $s;
    }

    private static $cp1256 = null;
    public static function cp1256($s) {
        if (self::$cp1256 === null) {
            $hi = '€پ‚ƒ„…†‡ˆ‰ٹ‹Œچژڈگ‘’“”•–—ک™ڑ›œ‌‍ں ،¢£¤¥¦§¨©ھ«¬­®¯°±²³´µ¶·¸¹؛»¼½¾؟ہءآأؤإئابةتثجحخدذرزسشصض×طظعغـفقكàلâمنهوçèéêëىيîïًٌٍَôُِ÷ّùْûü‎‏ے';
            $chars = preg_split('//u', $hi, -1, PREG_SPLIT_NO_EMPTY);
            self::$cp1256 = array();
            foreach ($chars as $i => $c) self::$cp1256[chr(128 + $i)] = $c;
        }
        return strtr($s, self::$cp1256);
    }

    /** کدپیج اکسل → نام کدگذاری */
    private static function codepage($cp) {
        $m = array(1200 => 'UTF-16LE', 1252 => 'Windows-1252', 1256 => 'CP1256', 1251 => 'Windows-1251', 1250 => 'Windows-1250', 1254 => 'Windows-1254', 65001 => 'UTF-8', 367 => 'ISO-8859-1', 32769 => 'Windows-1252', 10000 => 'Windows-1252', 720 => 'CP1256', 864 => 'CP1256');
        return isset($m[$cp]) ? $m[$cp] : 'CP1256';
    }

    /** عدد اعشاری → متن بدون نماد علمی (برای بارکدهای طولانی و قیمت‌ها) */
    public static function num($n) {
        if (is_nan($n) || is_infinite($n)) return '';
        if ($n == floor($n) && abs($n) < 1e17) return sprintf('%.0f', $n);
        $s = rtrim(rtrim(sprintf('%.10F', $n), '0'), '.');
        return $s === '-0' ? '0' : $s;
    }

    private static function dbl($b) {
        if (strlen($b) < 8) return 0.0;
        if (version_compare(PHP_VERSION, '7.0.15', '>=')) { $r = unpack('e', $b); return $r[1]; }
        $r = unpack('d', pack('S', 1) === "\x01\x00" ? $b : strrev($b));
        return $r[1];
    }

    private static function u16($s, $o) { return ord($s[$o]) | (ord($s[$o + 1]) << 8); }
    private static function u32($s, $o) { $r = unpack('V', substr($s, $o, 4)); return $r[1]; }

    /** ارسال ردیف‌ها به ترتیب شمارهٔ سطر */
    private static function flush_rows($rows, $cb) {
        ksort($rows);
        $n = 0;
        foreach ($rows as $r) {
            $has = false;
            foreach ($r as $v) if (trim((string) $v) !== '') { $has = true; break; }
            if (!$has) continue;
            ksort($r);
            call_user_func($cb, $r);
            $n++;
        }
        return $n;
    }

    /* ======================================================================
     *  XLS (BIFF2-8)
     * ==================================================================== */
    private static function read_xls($path, $cb, $name) {
        $raw = file_get_contents($path);
        if (strncmp($raw, "\xD0\xCF\x11\xE0", 4) === 0) {
            $ole = new SheetOle($path, $raw);
            $wb = $ole->find(array('Workbook', 'Book'));
            if ($wb === null) throw new Exception('بخش اطلاعات اکسل در فایل «' . $name . '» پیدا نشد (شاید فایل Word یا خراب است).');
            $data = $ole->stream($wb);
        } else {
            $data = $raw;
        }
        unset($raw);
        $len = strlen($data);
        if ($len < 8) throw new Exception('فایل xls خالی یا خراب است.');

        // ---- مرحلهٔ ۱: بخش عمومی (Workbook globals) ----
        $pos = 0; $ver = 0x0600; $sheets = array(); $sst = array(); $enc = 'CP1256';
        $first = true;
        while ($pos + 4 <= $len) {
            $id = self::u16($data, $pos); $sz = self::u16($data, $pos + 2);
            $rec = substr($data, $pos + 4, $sz);
            $start = $pos;
            $pos += 4 + $sz;
            if ($first) {
                $first = false;
                if (($id & 0xFF) !== 0x09) throw new Exception('ساختار فایل xls شناخته نشد.');
                $ver = $id === 0x0809 ? (self::u16($rec, 0) === 0x0600 ? 0x0600 : 0x0500) : 0x0400;
                $dt = $sz >= 4 ? self::u16($rec, 2) : 0x10;
                if ($dt === 0x0010 || $id !== 0x0809) {
                    // BIFF2-4 یا فقط یک شیت: کل جریان یک شیت است
                    $rows = self::xls_sheet($data, 0, $ver, $sst, $enc);
                    return self::flush_rows($rows, $cb);
                }
                continue;
            }
            switch ($id) {
                case 0x002F: throw new Exception('فایل «' . $name . '» رمزگذاری شده است. در اکسل رمز را بردارید و دوباره ذخیره کنید.');
                case 0x0042: $enc = self::codepage(self::u16($rec, 0)); break;
                case 0x0085: // BOUNDSHEET
                    $off = self::u32($rec, 0); $vis = ord($rec[4]); $typ = ord($rec[5]);
                    $sheets[] = array('off' => $off, 'vis' => $vis, 'type' => $typ);
                    break;
                case 0x00FC: // SST + CONTINUE
                    $segs = array($rec);
                    while ($pos + 4 <= $len && self::u16($data, $pos) === 0x003C) {
                        $s2 = self::u16($data, $pos + 2);
                        $segs[] = substr($data, $pos + 4, $s2);
                        $pos += 4 + $s2;
                    }
                    $sst = self::xls_sst($segs);
                    break;
            }
            if ($id === 0x000A) break; // EOF بخش عمومی
        }
        if (!$sheets) throw new Exception('هیچ شیتی در فایل «' . $name . '» پیدا نشد.');

        // اولین شیت قابل‌مشاهده‌ای که داده دارد؛ اگر نبود، هر شیتی که داده دارد
        usort($sheets, function ($a, $b) { return $a['vis'] === $b['vis'] ? 0 : ($a['vis'] === 0 ? -1 : 1); });
        foreach ($sheets as $sh) {
            if ($sh['type'] !== 0 || $sh['off'] >= $len) continue;
            $rows = self::xls_sheet($data, $sh['off'], $ver, $sst, $enc);
            if ($rows) return self::flush_rows($rows, $cb);
        }
        return 0;
    }

    private static function xls_rk($v) {
        if ($v & 2) {
            $n = $v >> 2;
            if ($n & 0x20000000) $n -= 0x40000000;
        } else {
            $n = self::dbl(pack('VV', 0, $v & 0xFFFFFFFC));
        }
        if ($v & 1) $n = $n / 100;
        return self::num((float) $n);
    }

    /** خواندن رشته در BIFF8 (XLUnicodeString) یا BIFF5 (بایت با کدپیج) */
    private static function xls_str($rec, $o, $ver, $enc, $lenBytes = 2) {
        if ($ver >= 0x0600) {
            $cch = $lenBytes === 2 ? self::u16($rec, $o) : ord($rec[$o]);
            $o += $lenBytes;
            $fl = ord($rec[$o]); $o++;
            if ($fl & 8) $o += 2;   // rich
            if ($fl & 4) $o += 4;   // ext
            if ($fl & 1) return self::conv(substr($rec, $o, $cch * 2), 'UTF-16LE');
            return self::conv(substr($rec, $o, $cch), 'ISO-8859-1');
        }
        $cch = $lenBytes === 2 ? self::u16($rec, $o) : ord($rec[$o]);
        return self::conv(substr($rec, $o + $lenBytes, $cch), $enc);
    }

    /** جدول رشته‌های مشترک با پشتیبانی از رکوردهای CONTINUE */
    private static function xls_sst($segs) {
        $out = array();
        $si = 0; $p = 8; // ۸ بایت اول: تعداد کل و یکتا
        $total = self::u32($segs[0], 4);
        $nseg = count($segs);
        $take = function ($n) use (&$segs, &$si, &$p, $nseg) {
            $r = '';
            while ($n > 0 && $si < $nseg) {
                $av = strlen($segs[$si]) - $p;
                if ($av <= 0) { $si++; $p = 0; continue; }
                $k = min($n, $av);
                $r .= substr($segs[$si], $p, $k);
                $p += $k; $n -= $k;
            }
            return $r;
        };
        for ($i = 0; $i < $total && $si < $nseg; $i++) {
            if ($p >= strlen($segs[$si])) { $si++; $p = 0; if ($si >= $nseg) break; }
            $h = $take(3);
            if (strlen($h) < 3) break;
            $cch = ord($h[0]) | (ord($h[1]) << 8);
            $fl = ord($h[2]);
            $runs = 0; $ext = 0;
            if ($fl & 8) { $x = $take(2); $runs = ord($x[0]) | (ord($x[1]) << 8); }
            if ($fl & 4) { $x = $take(4); $u = unpack('V', $x); $ext = $u[1]; }
            $hi = $fl & 1;
            $str = '';
            $left = $cch;
            while ($left > 0 && $si < $nseg) {
                $av = strlen($segs[$si]) - $p;
                if ($av <= 0) {
                    $si++; $p = 0;
                    if ($si >= $nseg) break;
                    $hi = ord($segs[$si][0]) & 1; $p = 1; // بایت پرچم در ابتدای CONTINUE
                    continue;
                }
                $chars = min($left, $hi ? intdiv($av, 2) : $av);
                if ($chars <= 0) { $si++; $p = 0; continue; }
                $bytes = substr($segs[$si], $p, $hi ? $chars * 2 : $chars);
                $p += strlen($bytes);
                $str .= $hi ? self::conv($bytes, 'UTF-16LE') : self::conv($bytes, 'ISO-8859-1');
                $left -= $chars;
            }
            if ($runs) $take($runs * 4);
            if ($ext) $take($ext);
            $out[] = $str;
        }
        return $out;
    }

    /** خواندن سلول‌های یک شیت از offset داده‌شده تا EOF */
    private static function xls_sheet($data, $pos, $ver, $sst, $enc) {
        $len = strlen($data);
        $rows = array();
        $pend = null; // سلول فرمولی که نتیجهٔ متنی‌اش در رکورد STRING بعدی است
        $depth = 0;
        while ($pos + 4 <= $len) {
            $id = self::u16($data, $pos); $sz = self::u16($data, $pos + 2);
            $r = substr($data, $pos + 4, $sz);
            $pos += 4 + $sz;
            if (($id & 0xFF) === 0x09 && in_array($id, array(0x0009, 0x0209, 0x0409, 0x0809), true)) { $depth++; continue; }
            if ($id === 0x000A) { $depth--; if ($depth <= 0) break; continue; }
            if ($depth > 1) continue; // زیربخش نمودارهای داخل شیت
            if ($sz < 4 && $id !== 0x0207) continue;
            switch ($id) {
                case 0x00FD: // LABELSST
                    $i = self::u32($r, 6);
                    $rows[self::u16($r, 0)][self::u16($r, 2)] = isset($sst[$i]) ? $sst[$i] : '';
                    break;
                case 0x0204: case 0x00D6: // LABEL / RSTRING
                    $rows[self::u16($r, 0)][self::u16($r, 2)] = self::xls_str($r, 6, $ver, $enc);
                    break;
                case 0x0004: // LABEL در BIFF2
                    $rows[self::u16($r, 0)][self::u16($r, 2)] = self::conv(substr($r, 8, ord($r[7])), $enc);
                    break;
                case 0x027E: case 0x007E: // RK
                    $rows[self::u16($r, 0)][self::u16($r, 2)] = self::xls_rk(self::u32($r, 6));
                    break;
                case 0x00BD: // MULRK
                    $row = self::u16($r, 0); $c = self::u16($r, 2);
                    $n = intdiv($sz - 6, 6);
                    for ($k = 0; $k < $n; $k++) $rows[$row][$c + $k] = self::xls_rk(self::u32($r, 4 + $k * 6 + 2));
                    break;
                case 0x0203: // NUMBER
                    $rows[self::u16($r, 0)][self::u16($r, 2)] = self::num(self::dbl(substr($r, 6, 8)));
                    break;
                case 0x0003: // NUMBER در BIFF2
                    $rows[self::u16($r, 0)][self::u16($r, 2)] = self::num(self::dbl(substr($r, 7, 8)));
                    break;
                case 0x0002: // INTEGER در BIFF2
                    $rows[self::u16($r, 0)][self::u16($r, 2)] = (string) self::u16($r, 7);
                    break;
                case 0x0006: case 0x0206: case 0x0406: // FORMULA
                    $row = self::u16($r, 0); $c = self::u16($r, 2);
                    $res = substr($r, 6, 8);
                    if (strlen($res) === 8 && $res[6] === "\xFF" && $res[7] === "\xFF") {
                        $t = ord($res[0]);
                        if ($t === 0) $pend = array($row, $c);
                        elseif ($t === 1) $rows[$row][$c] = ord($res[2]) ? '1' : '0';
                        else $rows[$row][$c] = '';
                    } else {
                        $rows[$row][$c] = self::num(self::dbl($res));
                    }
                    break;
                case 0x0207: // STRING (نتیجهٔ فرمول متنی)
                    if ($pend) { $rows[$pend[0]][$pend[1]] = self::xls_str($r, 0, $ver, $enc); $pend = null; }
                    break;
                case 0x0205: // BOOLERR
                    $rows[self::u16($r, 0)][self::u16($r, 2)] = ord($r[7]) ? '' : (ord($r[6]) ? '1' : '0');
                    break;
            }
        }
        return $rows;
    }

    /* ======================================================================
     *  XLSX / XLSM / XLTX
     * ==================================================================== */
    private static function zip_list($path) {
        $z = new ZipArchive();
        if ($z->open($path) !== true) throw new Exception('فایل اکسل معتبر نیست.');
        $names = array();
        for ($i = 0; $i < $z->numFiles; $i++) $names[] = $z->getNameIndex($i);
        $get = function ($n) use ($z) { $s = $z->getFromName($n); return $s === false ? null : $s; };
        return array($z, $names, $get);
    }

    /** ترتیب شیت‌ها از روی workbook.xml(.bin) + rels؛ خروجی: فهرست مسیرها */
    private static function ooxml_sheets($z, $names, $ext) {
        $wbPath = null;
        foreach ($names as $n) if (preg_match('#(^|/)workbook\.' . $ext . '$#i', $n)) { $wbPath = $n; break; }
        $order = array();
        if ($wbPath && $ext === 'xml') {
            $dir = dirname($wbPath); $dir = $dir === '.' ? '' : $dir . '/';
            $rels = $z->getFromName($dir . '_rels/' . basename($wbPath) . '.rels');
            $wb = $z->getFromName($wbPath);
            $map = array();
            if ($rels && preg_match_all('#<(?:\w+:)?Relationship\b[^>]*>#i', $rels, $mm)) {
                foreach ($mm[0] as $tag) {
                    if (preg_match('#\bId="([^"]+)"#', $tag, $a) && preg_match('#\bTarget="([^"]+)"#', $tag, $b)) {
                        $t = $b[1];
                        $t = $t[0] === '/' ? ltrim($t, '/') : $dir . $t;
                        $map[$a[1]] = $t;
                    }
                }
            }
            if ($wb && preg_match_all('#<(?:\w+:)?sheet\b[^>]*>#i', $wb, $mm)) {
                $hidden = array();
                foreach ($mm[0] as $tag) {
                    if (preg_match('#\br:id="([^"]+)"#i', $tag, $a) || preg_match('#:id="([^"]+)"#i', $tag, $a)) {
                        if (!isset($map[$a[1]])) continue;
                        $p = self::norm_path($map[$a[1]]);
                        if (preg_match('#state="(hidden|veryHidden)"#', $tag)) $hidden[] = $p; else $order[] = $p;
                    }
                }
                $order = array_merge($order, $hidden);
            }
        }
        // پشتیبان: هر فایل worksheets/*
        $fallback = array();
        foreach ($names as $n) if (preg_match('#(^|/)worksheets/[^/]+\.' . $ext . '$#i', $n)) $fallback[] = $n;
        natsort($fallback);
        $exist = array_flip($names);
        $order = array_values(array_filter($order, function ($p) use ($exist) { return isset($exist[$p]); }));
        foreach ($fallback as $f) if (!in_array($f, $order, true)) $order[] = $f;
        return $order;
    }

    private static function norm_path($p) {
        $out = array();
        foreach (explode('/', $p) as $seg) {
            if ($seg === '..') array_pop($out); elseif ($seg !== '.' && $seg !== '') $out[] = $seg;
        }
        return implode('/', $out);
    }

    private static function read_xlsx($path, $cb, $only, $name) {
        list($z, $names, $get) = self::zip_list($path);
        $sheets = self::ooxml_sheets($z, $names, 'xml');
        $ssPath = null;
        foreach ($names as $n) if (preg_match('#(^|/)sharedStrings\.xml$#i', $n)) { $ssPath = $n; break; }
        $z->close();
        if (!$sheets) throw new Exception('شیتی در فایل اکسل «' . $name . '» پیدا نشد.');

        $ss = array();
        if ($ssPath) {
            $x = new XMLReader();
            $x->open('zip://' . $path . '#' . $ssPath, null, LIBXML_NONET | LIBXML_COMPACT | LIBXML_PARSEHUGE);
            $cur = null; $skip = 0;
            while ($x->read()) {
                $ln = $x->localName;
                if ($x->nodeType === XMLReader::ELEMENT) {
                    if ($ln === 'si') {
                        if ($x->isEmptyElement) { $ss[] = ''; $cur = null; } else $cur = '';
                    } elseif ($ln === 'rPh' && !$x->isEmptyElement) {
                        $skip++;
                    } elseif ($ln === 't' && $cur !== null && !$skip) {
                        $cur .= $x->readString();
                    }
                } elseif ($x->nodeType === XMLReader::END_ELEMENT) {
                    if ($ln === 'rPh') $skip = max(0, $skip - 1);
                    elseif ($ln === 'si') { $ss[] = (string) $cur; $cur = null; }
                }
            }
            $x->close();
        }

        foreach ($sheets as $sheet) {
            $n = self::xlsx_sheet($path, $sheet, $ss, $only, $cb);
            if ($n) return $n;
        }
        return 0;
    }

    private static function xlsx_sheet($path, $sheet, $ss, $only, $cb) {
        $x = new XMLReader();
        if (!@$x->open('zip://' . $path . '#' . $sheet, null, LIBXML_NONET | LIBXML_COMPACT | LIBXML_PARSEHUGE)) return 0;
        $row = array(); $sent = 0;
        $col = -1;
        $pc = null; $pt = ''; $pv = ''; $inIs = false; $skip = 0;
        while ($x->read()) {
            $t = $x->nodeType;
            $ln = $x->localName;
            if ($t === XMLReader::ELEMENT) {
                if ($ln === 'row') {
                    $row = array(); $col = -1;
                    if ($x->isEmptyElement) continue;
                } elseif ($ln === 'c') {
                    $ref = (string) $x->getAttribute('r');
                    $letters = preg_replace('/[^A-Za-z]/', '', $ref);
                    $col = $letters !== '' ? self::col_index($letters) : $col + 1;
                    if ($x->isEmptyElement) { $pc = null; continue; }
                    if ($only === null || isset($only[$col])) { $pc = $col; $pt = (string) $x->getAttribute('t'); $pv = ''; } else $pc = null;
                } elseif ($pc !== null && $ln === 'v') {
                    $pv = $x->readString();
                } elseif ($pc !== null && $ln === 'rPh' && !$x->isEmptyElement) {
                    $skip++;
                } elseif ($pc !== null && $ln === 't' && !$skip) {
                    $pv .= $x->readString();
                }
            } elseif ($t === XMLReader::END_ELEMENT) {
                if ($ln === 'rPh') { $skip = max(0, $skip - 1); }
                elseif ($ln === 'c' && $pc !== null) {
                    if ($pt === 's') $v = isset($ss[(int) $pv]) ? $ss[(int) $pv] : '';
                    elseif ($pt === 'b') $v = $pv;
                    elseif ($pt === 'e') $v = '';
                    elseif ($pt === '' || $pt === 'n') $v = is_numeric($pv) ? self::num_str($pv) : $pv;
                    else $v = $pv;
                    $row[$pc] = $v;
                    $pc = null;
                } elseif ($ln === 'row') {
                    if ($row) {
                        $has = false;
                        foreach ($row as $v) if (trim((string) $v) !== '') { $has = true; break; }
                        if ($has) { call_user_func($cb, $row); $sent++; }
                    }
                    $row = array();
                }
            }
        }
        $x->close();
        return $sent;
    }

    /** «6.26E+12» یا «12.0» داخل xlsx → عدد کامل */
    private static function num_str($v) {
        if (preg_match('/^-?\d+$/', $v)) return $v;
        return self::num((float) $v);
    }

    public static function col_index($letters) {
        $letters = strtoupper($letters);
        $n = 0;
        for ($i = 0, $l = strlen($letters); $i < $l; $i++) $n = $n * 26 + (ord($letters[$i]) - 64);
        return $n - 1;
    }

    /* ======================================================================
     *  XLSB (اکسل باینری)
     * ==================================================================== */
    private static function xlsb_records($s, $cb) {
        $len = strlen($s); $p = 0;
        while ($p < $len) {
            $id = ord($s[$p++]);
            if ($id & 0x80) { $id = ($id & 0x7F) | ((ord($s[$p++]) & 0x7F) << 7); }
            $sz = 0; $sh = 0;
            for ($k = 0; $k < 4 && $p < $len; $k++) {
                $b = ord($s[$p++]);
                $sz |= ($b & 0x7F) << $sh; $sh += 7;
                if (!($b & 0x80)) break;
            }
            if (call_user_func($cb, $id, substr($s, $p, $sz)) === false) return;
            $p += $sz;
        }
    }

    private static function xlsb_wstr($d, $o) {
        $n = self::u32($d, $o);
        if ($n === 0xFFFFFFFF || $n > 1000000) return '';
        return self::conv(substr($d, $o + 4, $n * 2), 'UTF-16LE');
    }

    private static function read_xlsb($path, $cb, $name) {
        list($z, $names, $get) = self::zip_list($path);
        $sheets = array();
        foreach ($names as $n) if (preg_match('#(^|/)worksheets/[^/]+\.bin$#i', $n)) $sheets[] = $n;
        natsort($sheets);
        $ssBin = null;
        foreach ($names as $n) if (preg_match('#(^|/)sharedStrings\.bin$#i', $n)) { $ssBin = $get($n); break; }
        $ss = array();
        if ($ssBin) {
            self::xlsb_records($ssBin, function ($id, $d) use (&$ss) {
                if ($id === 19) $ss[] = self::xlsb_wstr($d, 1);
            });
        }
        foreach ($sheets as $sh) {
            $bin = $get($sh);
            if (!$bin) continue;
            $rows = array(); $r = 0;
            self::xlsb_records($bin, function ($id, $d) use (&$rows, &$r, $ss) {
                if ($id === 0) { $r = self::u32($d, 0); return; }
                if ($id < 1 || $id > 11 || strlen($d) < 8) return;
                $c = self::u32($d, 0);
                switch ($id) {
                    case 2: case 9: // RK
                        $rows[$r][$c] = $id === 2 ? self::xls_rk(self::u32($d, 8)) : self::num(self::dbl(substr($d, 8, 8)));
                        break;
                    case 5: $rows[$r][$c] = self::num(self::dbl(substr($d, 8, 8))); break;
                    case 6: case 8: $rows[$r][$c] = self::xlsb_wstr($d, 8); break;
                    case 7: $i = self::u32($d, 8); $rows[$r][$c] = isset($ss[$i]) ? $ss[$i] : ''; break;
                    case 4: case 10: $rows[$r][$c] = ord($d[8]) ? '1' : '0'; break;
                }
            });
            if ($rows) { $z->close(); return self::flush_rows($rows, $cb); }
        }
        $z->close();
        return 0;
    }

    /* ======================================================================
     *  ODS
     * ==================================================================== */
    private static function read_ods($path, $cb, $name) {
        $x = new XMLReader();
        if (!$x->open('zip://' . $path . '#content.xml', null, LIBXML_NONET | LIBXML_COMPACT | LIBXML_PARSEHUGE)) throw new Exception('فایل ods معتبر نیست.');
        $sent = 0; $tables = 0;
        $row = array(); $col = 0; $rep = 1; $cell = null; $val = null; $txt = ''; $inP = 0; $rowRep = 1;
        while ($x->read()) {
            $nm = $x->name; $t = $x->nodeType;
            if ($t === XMLReader::ELEMENT) {
                if ($nm === 'table:table') { $tables++; }
                elseif ($nm === 'table:table-row') {
                    $row = array(); $col = 0;
                    $rowRep = max(1, min(1000, (int) $x->getAttribute('table:number-rows-repeated')));
                    if ($x->isEmptyElement) continue;
                } elseif ($nm === 'table:table-cell' || $nm === 'table:covered-table-cell') {
                    $rep = max(1, min(1024, (int) $x->getAttribute('table:number-columns-repeated')));
                    $type = (string) $x->getAttribute('office:value-type');
                    $val = null;
                    if ($type === 'float' || $type === 'currency' || $type === 'percentage') $val = self::num_str((string) $x->getAttribute('office:value'));
                    elseif ($type === 'boolean') $val = $x->getAttribute('office:boolean-value') === 'true' ? '1' : '0';
                    $txt = '';
                    if ($x->isEmptyElement) { $col += $rep; continue; }
                    $cell = true;
                } elseif ($cell && $nm === 'text:p') {
                    if ($txt !== '') $txt .= "\n";
                    if (!$x->isEmptyElement) $txt .= $x->readString();
                } elseif ($cell && $nm === 'text:s') {
                    // فاصله‌ها داخل readString لحاظ نمی‌شود؛ مهم نیست
                }
            } elseif ($t === XMLReader::END_ELEMENT) {
                if ($nm === 'table:table-cell' || $nm === 'table:covered-table-cell') {
                    $v = $val !== null ? $val : $txt;
                    if ($v !== '') for ($k = 0; $k < $rep; $k++) $row[$col + $k] = $v;
                    $col += $rep; $cell = null;
                } elseif ($nm === 'table:table-row') {
                    if ($row) for ($k = 0; $k < $rowRep; $k++) { call_user_func($cb, $row); $sent++; }
                } elseif ($nm === 'table:table') {
                    if ($sent) break; // فقط اولین جدولِ دارای داده
                }
            }
        }
        $x->close();
        return $sent;
    }

    /* ======================================================================
     *  XML Spreadsheet 2003
     * ==================================================================== */
    private static function read_xml2003($path, $cb) {
        $x = new XMLReader();
        if (!$x->open($path, null, LIBXML_NONET | LIBXML_COMPACT | LIBXML_PARSEHUGE)) throw new Exception('فایل XML معتبر نیست.');
        $sent = 0; $row = array(); $col = 0; $inCell = false; $v = '';
        while ($x->read()) {
            $ln = $x->localName; $t = $x->nodeType;
            if ($t === XMLReader::ELEMENT) {
                if ($ln === 'Row') { $row = array(); $col = 0; if ($x->isEmptyElement) continue; }
                elseif ($ln === 'Cell') {
                    $idx = $x->getAttribute('ss:Index');
                    if ($idx === null) $idx = $x->getAttributeNs('Index', 'urn:schemas-microsoft-com:office:spreadsheet');
                    if ($idx) $col = (int) $idx - 1;
                    $v = '';
                    if ($x->isEmptyElement) { $col++; continue; }
                    $inCell = true;
                } elseif ($inCell && $ln === 'Data') {
                    $type = $x->getAttribute('ss:Type');
                    $v = $x->readString();
                    if ($type === 'Number' && is_numeric($v)) $v = self::num_str($v);
                }
            } elseif ($t === XMLReader::END_ELEMENT) {
                if ($ln === 'Cell') { if ($v !== '') $row[$col] = $v; $col++; $inCell = false; }
                elseif ($ln === 'Row') { if ($row) { call_user_func($cb, $row); $sent++; } }
                elseif ($ln === 'Worksheet' && $sent) break;
            }
        }
        $x->close();
        return $sent;
    }

    /* ======================================================================
     *  HTML با پسوند xls
     * ==================================================================== */
    private static function read_html($path, $cb, $name) {
        $h = file_get_contents($path);
        if (strncmp($h, "\xFF\xFE", 2) === 0 || strncmp($h, "\xFE\xFF", 2) === 0) $h = self::to_utf8_head($h);
        $h = preg_replace('/^\xEF\xBB\xBF/', '', $h);
        if (!self::is_utf8($h)) {
            $cs = preg_match('/charset\s*=\s*["\']?([\w\-]+)/i', $h, $m) ? $m[1] : 'windows-1256';
            $h = self::conv($h, stripos($cs, '1256') !== false ? 'CP1256' : $cs);
        }
        if (!class_exists('DOMDocument')) throw new Exception('افزونهٔ DOM روی سرور فعال نیست و فایل HTML خوانده نمی‌شود.');
        $prev = libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        $dom->loadHTML('<?xml encoding="UTF-8"?>' . $h, LIBXML_NONET | LIBXML_COMPACT | (defined('LIBXML_PARSEHUGE') ? LIBXML_PARSEHUGE : 0));
        libxml_clear_errors(); libxml_use_internal_errors($prev);
        unset($h);
        // جدولی که بیشترین ردیف را دارد
        $best = null; $max = 0;
        foreach ($dom->getElementsByTagName('table') as $tb) {
            $n = $tb->getElementsByTagName('tr')->length;
            if ($n > $max) { $max = $n; $best = $tb; }
        }
        if (!$best) throw new Exception('جدولی در فایل «' . $name . '» پیدا نشد.');
        $sent = 0; $span = array(); // rowspan
        $ri = 0;
        foreach ($best->getElementsByTagName('tr') as $tr) {
            $row = array(); $c = 0;
            foreach ($tr->childNodes as $td) {
                if (!($td instanceof DOMElement) || !in_array(strtolower($td->nodeName), array('td', 'th'), true)) continue;
                while (isset($span[$ri][$c])) { $row[$c] = $span[$ri][$c]; $c++; }
                $v = trim(preg_replace('/[ \t\r\n]+/u', ' ', $td->textContent));
                $cs = max(1, (int) $td->getAttribute('colspan'));
                $rs = max(1, min(500, (int) $td->getAttribute('rowspan')));
                for ($k = 0; $k < $cs; $k++) {
                    if ($k === 0 && $v !== '') $row[$c] = $v;
                    for ($q = 1; $q < $rs; $q++) $span[$ri + $q][$c] = $k === 0 ? $v : '';
                    $c++;
                }
            }
            while (isset($span[$ri][$c])) { $row[$c] = $span[$ri][$c]; $c++; }
            unset($span[$ri]);
            $ri++;
            $row = array_filter($row, function ($v) { return $v !== ''; });
            if ($row) { call_user_func($cb, $row); $sent++; }
        }
        return $sent;
    }

    private static function is_utf8($s) {
        return function_exists('mb_check_encoding') ? mb_check_encoding($s, 'UTF-8') : (bool) preg_match('//u', $s);
    }

    /* ======================================================================
     *  CSV / TSV / TXT
     * ==================================================================== */
    private static function read_csv($path, $cb) {
        $fh = fopen($path, 'rb');
        if (!$fh) throw new Exception('خواندن فایل ممکن نیست.');
        $bom = fread($fh, 4);
        $tmp = null;
        // UTF-16 (خروجی «Unicode Text» اکسل) → UTF-8 موقت
        if (strncmp($bom, "\xFF\xFE", 2) === 0 || strncmp($bom, "\xFE\xFF", 2) === 0) {
            fclose($fh);
            $all = file_get_contents($path);
            $all = self::conv(substr($all, 2), $bom[0] === "\xFF" ? 'UTF-16LE' : 'UTF-16BE');
            $tmp = tempnam(sys_get_temp_dir(), 'sheet');
            file_put_contents($tmp, $all);
            unset($all);
            $fh = fopen($tmp, 'rb');
        } else {
            rewind($fh);
        }
        // تشخیص جداکننده از روی چند خط اول
        $sample = '';
        for ($i = 0; $i < 5 && !feof($fh); $i++) $sample .= fgets($fh);
        rewind($fh);
        $cands = array(',' => 0, ';' => 0, "\t" => 0, '|' => 0);
        foreach ($cands as $d => $z) $cands[$d] = substr_count($sample, $d);
        arsort($cands);
        $d = key($cands);
        if (!$cands[$d]) $d = ',';
        if (strpos($sample, "\0") !== false) { fclose($fh); if ($tmp) @unlink($tmp); throw new Exception('فرمت فایل شناخته نشد (فایل اکسل یا متنی معتبر نیست).'); }
        $ansi = !self::is_utf8($sample);
        $sent = 0; $first = true;
        while (($r = fgetcsv($fh, 0, $d, '"', '\\')) !== false) {
            if ($r === array(null)) continue;
            if ($first) { $first = false; if (isset($r[0])) $r[0] = preg_replace('/^\xEF\xBB\xBF/', '', $r[0]); }
            $row = array();
            foreach ($r as $i => $v) {
                $v = (string) $v;
                if ($v === '') continue;
                if ($ansi || !self::is_utf8($v)) $v = self::cp1256($v);
                $v = preg_replace('/^="(.*)"$/s', '$1', $v); // ="0123" اکسل
                $row[$i] = $v;
            }
            if ($row) { call_user_func($cb, $row); $sent++; }
        }
        fclose($fh);
        if ($tmp) @unlink($tmp);
        return $sent;
    }
}
