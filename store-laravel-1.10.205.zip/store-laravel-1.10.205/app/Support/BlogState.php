<?php

namespace App\Support;

use Illuminate\Support\Facades\Cache;
use Throwable;

class BlogState
{
    /** آیا مقاله منتشرشده‌ای هست (برای نمایش لینک مجله) */
    public static function has(): bool
    {
        try {
            return Cache::remember('blog.has', 600, fn () => \App\Models\Post::query()->published()->exists());
        } catch (Throwable) {
            return false;
        }
    }
}
