<?php

namespace App\Support;

use RuntimeException;

/**
 * خواندن جریانی (Streaming) آرایه بزرگ داخل فایل JSON بدون بارگذاری کل فایل در حافظه.
 * فایل‌های چند ده مگابایتی با ده‌ها هزار کالا با چند مگابایت حافظه پردازش می‌شوند
 * و پردازش از هر نقطه (بایت) قابل ادامه است.
 */
class JsonStream
{
    protected $fh;

    protected string $buf = '';

    protected int $bufStart = 0; // آفست بایتِ ابتدای بافر در فایل

    protected int $pos = 0;      // موقعیت داخل بافر

    protected bool $eof = false;

    public function __construct(protected string $file, protected int $chunk = 1048576)
    {
        $this->fh = @fopen($file, 'rb');
        if (! $this->fh) {
            throw new RuntimeException('فایل JSON باز نشد.');
        }
    }

    public function __destruct()
    {
        if (is_resource($this->fh)) {
            fclose($this->fh);
        }
    }

    public function offset(): int
    {
        return $this->bufStart + $this->pos;
    }

    public function seek(int $offset): void
    {
        fseek($this->fh, $offset);
        $this->buf = '';
        $this->bufStart = $offset;
        $this->pos = 0;
        $this->eof = false;
    }

    /** اطمینان از وجود حداقل یک بایت در بافر از موقعیت فعلی */
    protected function fill(): bool
    {
        if ($this->pos < strlen($this->buf)) {
            return true;
        }
        if ($this->eof) {
            return false;
        }
        // بافر قبلی تمام شده: بافر تازه از ادامه فایل
        $this->bufStart += strlen($this->buf);
        $this->buf = (string) fread($this->fh, $this->chunk);
        $this->pos = 0;
        if ($this->buf === '') {
            $this->eof = true;

            return false;
        }

        return true;
    }

    protected function peek(): ?string
    {
        while ($this->fill()) {
            $c = $this->buf[$this->pos];
            if ($c === ' ' || $c === "\n" || $c === "\r" || $c === "\t" || ($this->offset() === 0 && $c === "\xEF")) {
                $this->pos += $c === "\xEF" ? 3 : 1; // BOM
                continue;
            }

            return $c;
        }

        return null;
    }

    /** خواندن یک مقدار کامل JSON (شیء، آرایه، رشته، عدد…) به‌صورت متن خام */
    protected function rawValue(): string
    {
        $c = $this->peek();
        if ($c === null) {
            throw new RuntimeException('پایان ناگهانی فایل JSON.');
        }
        $out = '';
        if ($c === '{' || $c === '[') {
            $depth = 0;
            $inStr = false;
            while ($this->fill()) {
                $len = strlen($this->buf);
                if ($inStr) {
                    // پرش تا گیومه یا بک‌اسلش بعدی
                    $n = strcspn($this->buf, '"\\', $this->pos);
                    $out .= substr($this->buf, $this->pos, $n);
                    $this->pos += $n;
                    if ($this->pos >= $len) {
                        continue;
                    }
                    $ch = $this->buf[$this->pos];
                    if ($ch === '\\') {
                        $out .= '\\';
                        $this->pos++;
                        if (! $this->fill()) {
                            break;
                        }
                        $out .= $this->buf[$this->pos++];

                        continue;
                    }
                    $out .= '"';
                    $this->pos++;
                    $inStr = false;

                    continue;
                }
                $n = strcspn($this->buf, '{}[]"', $this->pos);
                $out .= substr($this->buf, $this->pos, $n);
                $this->pos += $n;
                if ($this->pos >= $len) {
                    continue;
                }
                $ch = $this->buf[$this->pos++];
                $out .= $ch;
                if ($ch === '"') {
                    $inStr = true;
                } elseif ($ch === '{' || $ch === '[') {
                    $depth++;
                } else {
                    $depth--;
                    if ($depth === 0) {
                        return $out;
                    }
                }
            }
            throw new RuntimeException('ساختار JSON ناقص است (فایل کامل دانلود نشده).');
        }
        if ($c === '"') {
            $out = '"';
            $this->pos++;
            while ($this->fill()) {
                $n = strcspn($this->buf, '"\\', $this->pos);
                $out .= substr($this->buf, $this->pos, $n);
                $this->pos += $n;
                if ($this->pos >= strlen($this->buf)) {
                    continue;
                }
                $ch = $this->buf[$this->pos++];
                $out .= $ch;
                if ($ch === '\\') {
                    if ($this->fill()) {
                        $out .= $this->buf[$this->pos++];
                    }

                    continue;
                }

                return $out;
            }
            throw new RuntimeException('رشته JSON ناقص است.');
        }
        // عدد، true، false، null
        while ($this->fill()) {
            $n = strcspn($this->buf, ",}] \n\r\t", $this->pos);
            $out .= substr($this->buf, $this->pos, $n);
            $this->pos += $n;
            if ($this->pos < strlen($this->buf)) {
                break;
            }
        }

        return $out;
    }

    protected function expect(string $ch): void
    {
        if ($this->peek() !== $ch) {
            throw new RuntimeException('JSON معتبر نیست (انتظار «'.$ch.'» در بایت '.$this->offset().').');
        }
        $this->pos++;
    }

    /**
     * پیدا کردن آرایه کالاها و برگرداندن آفست بعد از «[»
     *
     * @param  string  $path  مسیر با نقطه (مثلاً data.products)؛ خالی = تشخیص خودکار
     */
    public function locate(string $path = ''): int
    {
        $this->seek(0);
        $c = $this->peek();
        if ($c === '[') {
            $this->pos++;

            return $this->offset();
        }
        if ($c !== '{') {
            throw new RuntimeException('پاسخ JSON معتبر نیست؛ ابتدای فایل: '.mb_substr(strip_tags((string) file_get_contents($this->file, false, null, 0, 150)), 0, 120));
        }
        $segments = $path !== '' ? explode('.', $path) : [];

        return $this->findInObject($segments, 0);
    }

    protected function findInObject(array $segments, int $level): int
    {
        $this->expect('{');
        $wanted = $segments[$level] ?? null;
        $auto = ['products', 'data', 'items', 'result', 'records', 'list'];
        $fallback = null;
        while (true) {
            $c = $this->peek();
            if ($c === '}') {
                $this->pos++;
                break;
            }
            if ($c === ',') {
                $this->pos++;

                continue;
            }
            $key = json_decode($this->rawValue(), true);
            $this->expect(':');
            $v = $this->peek();
            $isMatch = $wanted !== null ? (string) $key === $wanted : in_array($key, $auto, true);
            if ($isMatch && $v === '[' && ($wanted === null || $level === count($segments) - 1)) {
                $this->pos++;

                return $this->offset();
            }
            if ($isMatch && $v === '{' && $wanted !== null && $level < count($segments) - 1) {
                return $this->findInObject($segments, $level + 1);
            }
            if ($wanted === null && $v === '[' && $fallback === null) {
                // اولین آرایه‌ای که شیء دارد (برای ساختارهای ناشناخته)
                $start = $this->offset() + 1;
                $raw = $this->rawValue();
                if (preg_match('/^\[\s*\{/', $raw)) {
                    $fallback = $start;
                }

                continue;
            }
            $this->rawValue(); // رد کردن مقدار
        }
        if ($fallback !== null) {
            return $fallback;
        }
        throw new RuntimeException('فهرست کالاها در JSON پیدا نشد. «مسیر فهرست کالاها» را در تنظیمات اتصال بررسی کنید.');
    }

    /**
     * خواندن اعضای آرایه از آفست داده‌شده تا پایان یا تمام شدن زمان
     *
     * @param  callable(array): void  $each
     * @return int|null آفست ادامه، یا null اگر آرایه تمام شد
     */
    public function each(int $from, callable $each, float $deadline = INF, int $max = PHP_INT_MAX): ?int
    {
        $this->seek($from);
        $n = 0;
        while (true) {
            $c = $this->peek();
            if ($c === null || $c === ']') {
                return null;
            }
            if ($c === ',') {
                $this->pos++;

                continue;
            }
            $raw = $this->rawValue();
            if ($raw !== '' && $raw[0] === '{') {
                $row = json_decode($raw, true);
                if (is_array($row)) {
                    $each($row);
                }
            }
            if (++$n >= $max || microtime(true) >= $deadline) {
                return $this->offset();
            }
        }
    }
}
