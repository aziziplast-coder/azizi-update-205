<?php

namespace App\Support;

use Illuminate\Support\Carbon;

/** پاپ‌آپ اطلاع‌رسانی */
class Popup
{
    public static function current(): ?array
    {
        $p = (array) setting('popup', []);
        if (empty($p['enabled']) || (empty($p['title']) && empty($p['text']) && empty($p['image']))) {
            return null;
        }
        $now = now();
        if (! empty($p['starts_at']) && Carbon::parse($p['starts_at'])->isAfter($now)) {
            return null;
        }
        if (! empty($p['ends_at']) && Carbon::parse($p['ends_at'])->isBefore($now)) {
            return null;
        }
        $route = request()->route()?->getName();
        if (($p['pages'] ?? 'all') === 'home' && $route !== 'home') {
            return null;
        }
        if (in_array($route, ['checkout', 'login', 'payment.start'], true)) {
            return null;
        }
        $aud = $p['audience'] ?? 'all';
        if (($aud === 'guests' && auth()->check()) || ($aud === 'users' && ! auth()->check())) {
            return null;
        }

        return $p;
    }
}
