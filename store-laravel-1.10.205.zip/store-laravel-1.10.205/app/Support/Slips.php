<?php

namespace App\Support;

use App\Models\Order;
use App\Models\User;
use App\Models\Warehouse;
use Illuminate\Support\Collection;

/**
 * تقسیم اقلام یک سفارش به «حواله انباردار»:
 *  - هر انباردار یک حواله دارد که اقلام همه انبارهای او (عمده و خرده) را با هم دارد
 *  - انباری که انباردار ندارد، حواله جدای خودش را دارد
 *  - انباری که چند انباردار دارد فقط در حواله نخستین انباردار می‌آید تا دوبار جمع نشود
 *  - ترتیب اقلام: شماره انبار از ۱ به بالا (در شماره یکسان: عمده پیش از خرده)
 */
class Slips
{
    /** کلید ترتیب یک انبار: [شماره عددی، عمده=۰/خرده=۱، شناسه] */
    public static function whKey(?Warehouse $w, int $id = 0): array
    {
        $code = $w && is_numeric($w->code) ? (int) $w->code : PHP_INT_MAX;

        return [$code, ($w->kind ?? null) === 'retail' ? 1 : 0, $id];
    }

    /** مرتب‌سازی اقلام بر اساس شماره انبار */
    public static function sortItems(Collection $items, Collection $whMeta): Collection
    {
        return $items->sort(function ($a, $b) use ($whMeta) {
            $ka = array_merge(static::whKey($whMeta[$a->warehouse_id] ?? null, (int) $a->warehouse_id), [$a->id]);
            $kb = array_merge(static::whKey($whMeta[$b->warehouse_id] ?? null, (int) $b->warehouse_id), [$b->id]);

            return $ka <=> $kb;
        })->values();
    }

    /**
     * گروه‌های حواله این سفارش.
     *
     * @return array<string, array{key:string,label:string,wids:int[],keepers:string}>  کلید: k{userId} یا w{warehouseId}
     */
    public static function groups(Order $order, ?array $onlyWids = null): array
    {
        $ids = $order->items->pluck('warehouse_id')->map(fn ($v) => (int) $v)->unique()->values()->all();
        if ($onlyWids !== null) {
            $ids = array_values(array_intersect($ids, $onlyWids));
        }
        $whs = Warehouse::query()->with(['keepers' => fn ($q) => $q->where('is_active', true)->orderBy('users.id')])
            ->whereIn('id', array_filter($ids))->get()->keyBy('id');
        $sortIds = function (array $list) use ($whs) {
            usort($list, fn ($a, $b) => static::whKey($whs[$a] ?? null, $a) <=> static::whKey($whs[$b] ?? null, $b));

            return $list;
        };
        $ids = $sortIds($ids);

        $groups = [];
        $keeperOf = [];
        foreach ($ids as $wid) {
            $w = $whs[$wid] ?? null;
            $k = $w?->keepers->first();
            if ($k) {
                $keeperOf[$k->id] ??= $k;
                $groups['k'.$k->id]['wids'][] = $wid;
            } else {
                $groups['w'.$wid]['wids'][] = $wid;
            }
        }
        foreach ($groups as $key => &$g) {
            $g['key'] = $key;
            $g['wids'] = $sortIds($g['wids']);
            $labels = array_map(fn ($wid) => ($whs[$wid] ?? null)?->label() ?? 'بدون انبار', $g['wids']);
            if ($key[0] === 'k') {
                /** @var User $u */
                $u = $keeperOf[(int) substr($key, 1)];
                $g['keepers'] = $u->displayName();
                $g['label'] = $u->displayName();
                $g['whLabel'] = implode('، ', $labels);
            } else {
                $g['keepers'] = '';
                $g['label'] = $labels[0];
                $g['whLabel'] = $labels[0];
            }
        }
        unset($g);

        // ترتیب حواله‌ها بر اساس کوچک‌ترین شماره انبار هر حواله
        uasort($groups, fn ($a, $b) => static::whKey($whs[$a['wids'][0]] ?? null, $a['wids'][0]) <=> static::whKey($whs[$b['wids'][0]] ?? null, $b['wids'][0]));

        return $groups;
    }
}
