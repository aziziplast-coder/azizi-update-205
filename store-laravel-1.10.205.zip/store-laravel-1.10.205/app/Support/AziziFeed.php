<?php

namespace App\Support;

use App\Models\Product;
use App\Models\SyncItem;
use App\Models\Warehouse;
use Illuminate\Support\Facades\Cache;
use Throwable;

/**
 * خروجی هم‌شکل JSON سایت قبلی عزیزی‌پلاست: /jsonProducts.php
 * ربات‌های کانال (بله، روبیکا، تلگرام) بدون هیچ تغییری همین آدرس را می‌خوانند.
 * فیلدها و ترتیب و نوع داده‌ها دقیقاً مثل قبل است؛ قیمت و موجودی از خود همین سایت.
 *
 * تصویرها: فیلد img همان نام فایل سایت قبلی است (sm123….jpg?…). هر آدرس تصویری که ربات با آن بسازد
 * (مثلاً /Opitures/sm123….jpg) در همین سایت به تصویر همان کالا می‌رسد (image()).
 */
class AziziFeed
{
    public static function config(): array
    {
        $c = (array) (((array) setting('feed', []))['azizi'] ?? []);

        return [
            'enabled' => ! array_key_exists('enabled', $c) || ! empty($c['enabled']),
            'only_active' => ! array_key_exists('only_active', $c) || ! empty($c['only_active']),
            'markup' => (float) en_digits((string) ($c['markup'] ?? 0)),
            'cache' => max(1, (int) ($c['cache'] ?? 10)),
        ];
    }

    public static function file(): string
    {
        return storage_path('app/feed/jsonProducts.json');
    }

    /** مسیر فایل آماده؛ اگر کهنه بود دوباره ساخته می‌شود */
    public static function ready(): string
    {
        $f = static::file();
        $c = static::config();
        if (! is_file($f) || filemtime($f) < time() - $c['cache'] * 60 || ! is_dir(static::pagesDir())) {
            $lock = Cache::lock('azizi-feed-build', 300);
            if ($lock->get()) {
                try {
                    static::build();
                } finally {
                    $lock->release();
                }
            } elseif (! is_file($f)) {
                // ساخت هم‌زمان توسط درخواست دیگر؛ کمی صبر
                $lock->block(120);
                $lock->release();
            }
        }

        return $f;
    }

    public static function build(): int
    {
        @set_time_limit(600);
        @ini_set('memory_limit', '512M');
        $c = static::config();
        $dir = dirname(static::file());
        is_dir($dir) || @mkdir($dir, 0775, true);
        $tmp = static::file().'.'.getmypid().'.tmp';
        $fh = fopen($tmp, 'w');
        fwrite($fh, '{"success":true,"products":[');
        $wh = Warehouse::query()->pluck('code', 'id')->all();
        $n = 0;
        $q = Product::query()->with('category:id,name,parent_id');
        if ($c['only_active']) {
            $q->where('is_active', true);
        }
        $enc = [];
        $q->chunkById(500, function ($rows) use ($fh, $wh, $c, &$n, &$enc) {
            $extra = SyncItem::query()->whereIn('product_id', $rows->pluck('id'))->orderBy('id')->get(['product_id', 'extra'])
                ->mapWithKeys(fn ($s) => [$s->product_id => (array) (($s->extra ?? [])['r'] ?? [])])->all();
            foreach ($rows as $p) {
                $row = static::row($p, $extra[$p->id] ?? [], $wh, $c['markup']);
                $j = json_encode($row, JSON_PARTIAL_OUTPUT_ON_ERROR);
                $enc[] = $j;
                fwrite($fh, ($n++ ? ',' : '').$j);
            }
        });
        fwrite($fh, '],"total":'.$n.'}');
        fclose($fh);
        static::writeGz($tmp);
        rename($tmp.'.gz', static::file().'.gz');
        rename($tmp, static::file());
        static::writePages($enc, $n);
        Cache::forget('azizi-img-map');

        return $n;
    }

    /** هر صفحه چند کالا (?p=1، ?p=2، …) */
    public const PER_PAGE = 100;

    public static function pagesDir(): string
    {
        return dirname(static::file()).'/pages';
    }

    /** فایل یک صفحه (null = صفحه وجود ندارد) */
    public static function page(int $p): ?string
    {
        $f = static::pagesDir().'/p'.$p.'.json';

        return is_file($f) ? $f : null;
    }

    /**
     * صفحه‌ها مثل خروجی کامل: {"success":true,"products":[…۱۰۰ کالا…],"total":همه کالاها,…}
     * با یک‌جا جابه‌جا کردن پوشه، ربات هیچ‌وقت نیمه‌ساخته نمی‌بیند.
     */
    protected static function writePages(array $enc, int $total): void
    {
        $base = dirname(static::file());
        $tmp = $base.'/pages.'.getmypid().'.tmp';
        @mkdir($tmp, 0775, true);
        $pages = max(1, (int) ceil($total / static::PER_PAGE));
        for ($i = 1; $i <= $pages; $i++) {
            $slice = array_slice($enc, ($i - 1) * static::PER_PAGE, static::PER_PAGE);
            $f = $tmp.'/p'.$i.'.json';
            file_put_contents($f, '{"success":true,"products":['.implode(',', $slice).'],"total":'.$total.',"page":'.$i.',"pages":'.$pages.',"per_page":'.static::PER_PAGE.'}');
            static::writeGz($f);
        }
        $old = $base.'/pages.old.'.getmypid();
        if (is_dir(static::pagesDir())) {
            @rename(static::pagesDir(), $old);
        }
        @rename($tmp, static::pagesDir());
        if (is_dir($old)) {
            array_map('unlink', glob($old.'/*') ?: []);
            @rmdir($old);
        }
    }

    /** نسخه فشرده کنار فایل (برای ربات‌هایی که gzip می‌پذیرند ده برابر سریع‌تر) */
    protected static function writeGz(string $f): void
    {
        if (function_exists('gzencode')) {
            @file_put_contents($f.'.gz', gzencode((string) file_get_contents($f), 6));
        }
    }

    protected static function price(?int $v, float $markup): int
    {
        $v = (int) $v;

        return $markup == 0.0 ? $v : (int) (round($v * (1 + $markup / 100) / 1000) * 1000);
    }

    public static function row(Product $p, array $r, array $wh, float $markup): array
    {
        $a = $p->getAttributes();
        $legacy = (string) (($a['legacy_id'] ?? '') ?: $p->id);
        // آدرس صفحه: همان رشته سایت قبلی
        $url = (string) ($r['u'] ?? '');
        if ($url === '' || ! str_contains($url, '/product-')) {
            $url = ! empty($a['legacy_id'])
                ? '/product-'.$a['legacy_id'].'/'.str_replace(' ', '-', (string) (($a['legacy_slug'] ?? null) ?: $p->name))
                : (string) (parse_url($p->url(), PHP_URL_PATH) ?: '/');
            $url = rawurldecode($url);
        }
        // تصویر: نام فایل سایت قبلی؛ برای کالای جدید، مسیر تصویر همین سایت
        $img = is_string($r['i'] ?? null) && trim($r['i']) !== '' && ! preg_match('~^(https?:)?//~i', $r['i'])
            ? trim($r['i'])
            : ($p->image ? (preg_match('~^(https?:)?//~i', (string) $p->image) ? (string) $p->image : 'uploads/'.ltrim((string) $p->image, '/')) : '');
        // گالری: آدرس کامل (مثل قبل فقط برای کالاهای دارای گالری)
        $images = [];
        if (! empty($r['g']) || ! $r) {
            foreach ((array) $p->gallery as $g) {
                if ($g && ($u = upload_url($g))) {
                    $images[] = str_starts_with($u, '/') && ! str_starts_with($u, '//') ? url($u) : $u;
                }
            }
        }
        $per = max(1, (int) $p->per_carton);
        $ct = (string) ($r['ct'] ?? '');
        if ($ct === '' || (int) (preg_match('/\d+/', en_digits($ct), $m) ? $m[0] : 0) !== $per) {
            $ct = $per.' '.($p->unit_label ? $p->unitName() : 'عدد');
        }
        $omde = (string) ($wh[$p->warehouse_id] ?? '') ?: '0';
        $retailOk = $p->retailAllowed();
        $khord = $retailOk ? ((string) ($wh[$p->retail_warehouse_id ?: $p->warehouse_id] ?? '') ?: '0') : '0';
        $catAvail = $p->cartonAvailable();
        $retAvail = $p->retailAvailable();
        $cat = (string) ($r['k'] ?? '');
        if ($cat === '' || $p->category?->name === null || ! str_ends_with($cat, (string) $p->category?->name)) {
            $cat = str_replace(' > ', '/', Feed::categoryPath($p->category));
        }

        return [
            'id' => $legacy,
            'title' => (string) $p->name,
            'url' => $url,
            'img' => $img,
            'images' => $images,
            'price' => static::price($p->price, $markup),
            'old_price' => $p->compare_price > $p->price ? static::price($p->compare_price, $markup) : 0,
            'is_available' => $catAvail || $retAvail,
            'tedad_dar_carton' => $ct,
            'tedad_afzayesh' => $per,
            'code' => (string) ($p->sku ?: ($p->sync_code ?: $p->id)),
            'sort_number' => $omde,
            'zarib_khord' => $retailOk ? '1' : '0',
            'mojud_anbar_omde' => $catAvail ? '1' : '0',
            'mojud_anbar_khord' => $retAvail ? '1' : '0',
            'anbar_omde' => $omde,
            'anbar_khord' => $khord,
            'cat' => $cat,
        ];
    }

    /** نام فایل تصویر سایت قبلی ← شناسه کالا */
    protected static function imgMap(): array
    {
        return Cache::remember('azizi-img-map', 86400, function () {
            $map = [];
            SyncItem::query()->whereNotNull('product_id')->select(['id', 'product_id', 'extra'])->chunkById(1000, function ($rows) use (&$map) {
                foreach ($rows as $s) {
                    $r = (array) (($s->extra ?? [])['r'] ?? []);
                    $list = array_merge([is_string($r['i'] ?? null) ? $r['i'] : ''], array_map(fn ($g) => is_string($g) ? $g : '', (array) ($r['g'] ?? [])));
                    foreach ($list as $k => $x) {
                        $b = strtolower(basename(preg_replace('/\?.*$/', '', $x)));
                        if ($b !== '' && ! isset($map[$b])) {
                            $map[$b] = [(int) $s->product_id, $k];
                        }
                    }
                }
            });

            return $map;
        });
    }

    /** هر آدرس تصویری از سایت قبلی → فایل تصویر در همین سایت (یا null) */
    public static function image(string $path): ?string
    {
        $path = ltrim(rawurldecode($path), '/');
        if (str_contains($path, '..')) {
            return null;
        }
        // ۱) مسیری که انتهایش فایل واقعی همین سایت است (برای کالاهای جدید: …/uploads/products/x.jpg)
        $parts = explode('/', $path);
        for ($i = 0; $i < count($parts) - 1; $i++) {
            $tail = implode('/', array_slice($parts, $i));
            if (str_starts_with($tail, 'uploads/') && is_file($f = public_path($tail))) {
                return $f;
            }
        }
        // ۲) نام فایل سایت قبلی
        $b = strtolower(basename($path));
        $hit = static::imgMap()[$b] ?? null;
        if (! $hit && preg_match('/^(sm|small|thumb|th|lg|large)[_\-]?(.+)$/i', $b, $m)) {
            $hit = static::imgMap()['sm'.$m[2]] ?? static::imgMap()[$m[2]] ?? null;
        }
        if (! $hit) {
            return null;
        }
        try {
            $p = Product::query()->find($hit[0]);
            if (! $p) {
                return null;
            }
            $rel = $hit[1] > 0 ? (((array) $p->gallery)[$hit[1] - 1] ?? $p->image) : $p->image;
            $f = $rel ? public_path('uploads/'.ltrim((string) $rel, '/')) : null;

            return $f && is_file($f) ? $f : null;
        } catch (Throwable) {
            return null;
        }
    }
}
