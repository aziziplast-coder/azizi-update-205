<?php

namespace App\Support;

use App\Models\Category;
use App\Models\Post;
use App\Models\Product;
use App\Models\ProductCollection;
use Illuminate\Support\Facades\Cache;

/**
 * بخش‌های صفحه اول که از پنل با کشیدن و رها کردن مرتب می‌شوند.
 * هر بخش: ['type' => نوع, 'data' => تنظیمات]
 */
class HomeBlocks
{
    public const TYPES = [
        'slider' => 'اسلایدر',
        'hero' => 'بنر اصلی (تکی)',
        'benefits' => 'مزیت‌ها',
        'categories' => 'نوار دسته‌بندی‌ها',
        'amazing' => 'شگفت‌انگیز',
        'banners' => 'بنرهای چندتایی',
        'products' => 'نوار کالاها',
        'collection' => 'یک مجموعه (مثل حراجی)',
        'collections' => 'همه مجموعه‌های صفحه اول',
        'bestsellers' => 'پرفروش‌ترین‌ها (رتبه‌دار)',
        'trending' => 'پربازدیدترین‌های اخیر',
        'catstrips' => 'نوار کالاهای چند دسته',
        'recent' => 'بازدیدهای اخیر مشتری',
        'posts' => 'آخرین مقالات',
        'text' => 'متن / HTML دلخواه',
    ];

    public static function defaults(): array
    {
        $promos = array_values((array) setting('promos', []));

        return [
            ['type' => 'hero', 'data' => ['enabled' => true]],
            ['type' => 'benefits', 'data' => ['enabled' => true]],
            ['type' => 'categories', 'data' => ['enabled' => true, 'title' => 'دسته‌بندی‌ها', 'style' => 'circle']],
            ['type' => 'amazing', 'data' => ['enabled' => true]],
            ['type' => 'collections', 'data' => ['enabled' => true]],
            ['type' => 'products', 'data' => ['enabled' => true, 'title' => 'پیشنهاد ویژه', 'source' => 'featured', 'limit' => 12, 'display' => 'strip']],
            ['type' => 'banners', 'data' => ['enabled' => (bool) $promos, 'columns' => 4, 'items' => $promos]],
            ['type' => 'products', 'data' => ['enabled' => true, 'title' => 'تازه‌ها', 'source' => 'newest', 'limit' => 12, 'display' => 'strip']],
            ['type' => 'recent', 'data' => ['enabled' => true]],
            ['type' => 'posts', 'data' => ['enabled' => true, 'title' => 'از مجله', 'limit' => 4]],
        ];
    }

    public static function blocks(): array
    {
        $saved = setting('home_blocks');

        return is_array($saved) && $saved ? array_values($saved) : static::defaults();
    }

    /** داده هر بخش (با کش کوتاه) */
    /** بخش‌های یک کانال: site یا app (بر اساس «کجا نمایش داده شود؟») */
    public static function for(string $channel): array
    {
        return array_values(array_filter(static::resolve(), fn ($b) => in_array($b['data']['show_on'] ?? 'both', ['both', $channel], true)));
    }

    public static function resolve(): array
    {
        return Cache::remember('home.blocks', 300, function () {
            $out = [];
            foreach (static::blocks() as $i => $b) {
                $d = (array) ($b['data'] ?? []);
                if (array_key_exists('enabled', $d) && ! $d['enabled']) {
                    continue;
                }
                $type = $b['type'] ?? '';
                $items = match ($type) {
                    'categories' => static::categories($d),
                    'amazing' => static::amazing(),
                    'products' => static::products($d),
                    'collection' => static::collection((int) ($d['collection_id'] ?? 0)),
                    'collections' => static::collections(),
                    'posts' => Post::query()->published()->latest('published_at')->limit(max(2, min(12, (int) ($d['limit'] ?? 4))))->get(),
                    'bestsellers' => Rankings::bestsellers(max(4, min(60, (int) ($d['limit'] ?? 36))), (int) ($d['days'] ?? 0)),
                    'trending' => Rankings::trending(max(1, (int) ($d['hours'] ?? 24)), max(4, min(30, (int) ($d['limit'] ?? 12)))),
                    'catstrips' => static::catstrips($d),
                    default => null,
                };
                if (in_array($type, ['categories', 'products', 'posts', 'bestsellers', 'trending', 'catstrips'], true) && (! $items || $items->isEmpty())) {
                    continue;
                }
                if (in_array($type, ['amazing', 'collection'], true) && (! $items || $items['products']->isEmpty())) {
                    continue;
                }
                if ($type === 'collections' && ! $items) {
                    continue;
                }
                $out[] = ['type' => $type, 'data' => $d, 'items' => $items, 'i' => $i];
            }

            return $out;
        });
    }

    protected static function categories(array $d)
    {
        $q = Category::query()->active()->where('on_home', true)->orderBy('sort')->orderBy('name');
        if (($d['level'] ?? 'top') === 'top') {
            $q->whereNull('parent_id');
        }

        return $q->limit(40)->get();
    }

    public static function amazing(?int $limit = null): array
    {
        $a = (array) setting('amazing', []);
        if (empty($a['enabled'])) {
            return ['settings' => $a, 'products' => collect()];
        }
        $q = Product::query()->active()->available()->onSale()->with('category')
            ->where(fn ($w) => $w->whereNull('offer_ends_at')->orWhere('offer_ends_at', '>', now()));
        if (($a['mode'] ?? 'auto') === 'manual') {
            $q->where('is_amazing', true);
        }
        if (! empty($a['min_discount'])) {
            $q->whereRaw('compare_price * 100 >= ? * compare_price + price * 100', [(int) $a['min_discount']]);
        }
        $sort = $a['sort'] ?? 'discount';
        if ($sort === 'manual') {
            $q->orderBy('amazing_sort')->latest('id');
        } elseif ($sort === 'ending') {
            $q->orderByRaw('CASE WHEN offer_ends_at IS NULL THEN 1 ELSE 0 END')->orderBy('offer_ends_at');
        } else {
            ProductCollection::applySort($q, $sort);
        }
        $products = $q->limit($limit ?: max(4, min(30, (int) ($a['limit'] ?? 12))))->get();
        $ends = $a['ends_at'] ?? null;
        if (! $ends) {
            $ends = $products->pluck('offer_ends_at')->filter(fn ($d) => $d && $d->isFuture())->sort()->first();
        }

        return ['settings' => $a, 'products' => $products, 'ends_at' => $ends ? \Illuminate\Support\Carbon::parse($ends) : null];
    }

    protected static function products(array $d)
    {
        $limit = max(4, min(24, (int) ($d['limit'] ?? 12)));
        $q = Product::query()->active()->available()->with('category');
        switch ($d['source'] ?? 'newest') {
            case 'featured':
                $q->where('is_featured', true)->orderBy('sort')->latest('id');
                break;
            case 'sale':
                $q->onSale()->latest('updated_at');
                break;
            case 'popular':
                $q->orderByDesc('sales_count');
                break;
            case 'views':
                $q->orderByDesc('views');
                break;
            case 'category':
                $c = Category::query()->find((int) ($d['category_id'] ?? 0));
                $q->whereIn('category_id', $c ? $c->descendantIds() : [0])->orderBy('sort')->latest('id');
                break;
            default:
                $q->latest('id');
        }

        return $q->limit($limit)->get();
    }

    /** هر دسته انتخابی یک نوار کالا */
    protected static function catstrips(array $d)
    {
        $limit = max(4, min(24, (int) ($d['limit'] ?? 12)));
        $out = collect();
        $ids = array_filter(array_map('intval', (array) ($d['category_ids'] ?? [])));
        $cats = Category::query()->active()->whereIn('id', $ids ?: [0])->get()->keyBy('id');
        foreach ($ids as $id) {
            $c = $cats->get($id);
            if (! $c) {
                continue;
            }
            $q = Product::query()->active()->available()->with('category')->whereIn('category_id', $c->descendantIds());
            ProductCollection::applySort($q, $d['sort'] ?? 'newest');
            $p = $q->limit($limit)->get();
            if ($p->isNotEmpty()) {
                $out->push(['category' => $c, 'products' => $p]);
            }
        }

        return $out;
    }

    protected static function collection(int $id): ?array
    {
        $c = ProductCollection::query()->where('is_active', true)->find($id);
        if (! $c) {
            return null;
        }

        return ['collection' => $c, 'products' => $c->products()->limit(max(4, min(30, $c->home_limit ?: 12)))->get()];
    }

    protected static function collections(): array
    {
        $out = [];
        foreach (ProductCollection::query()->where('is_active', true)->where('on_home', true)->orderBy('sort')->get() as $c) {
            $p = $c->products()->limit(max(4, min(30, $c->home_limit ?: 12)))->get();
            if ($p->isNotEmpty()) {
                $out[] = ['collection' => $c, 'products' => $p];
            }
        }

        return $out;
    }

    /** نام بخش برای پنل */
    public static function label(array $state): string
    {
        $d = (array) ($state['data'] ?? []);

        return trim((static::TYPES[$state['type'] ?? ''] ?? 'بخش').(! empty($d['title']) ? ' — '.$d['title'] : ''));
    }
}
