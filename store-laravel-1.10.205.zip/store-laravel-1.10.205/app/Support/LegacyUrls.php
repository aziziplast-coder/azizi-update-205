<?php

namespace App\Support;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Support\Facades\DB;

/**
 * لینک‌های هم‌شکل سایت قبلی (برای حفظ سئو هنگام انتقال دامنه):
 *   کالا:  /product-39073/سطل+رولی3+تکنو   (شناسه و نام از آدرس صفحه کالا در JSON)
 *   دسته: /category/1/پلاستیک             (شناسه دسته در سایت قبلی، در ویرایش دسته)
 * با تنظیم «شکل لینک‌ها» = سایت قبلی، همه لینک‌ها، canonical و نقشه سایت به این شکل می‌شوند
 * و لینک‌های شکل قدیم همین سایت (/product/… و /category/…) با 301 به شکل جدید می‌روند.
 */
class LegacyUrls
{
    /** شماره کالاهای ساخت این سایت از اینجا شروع می‌شود تا با کالاهای تازه سایت قبلی (۳۹ هزار و بالاتر) برخورد نکند */
    public const OWN_FROM = 100001;

    public static function enabled(): bool
    {
        return setting('url_style', 'default') === 'legacy';
    }

    /** «/product-39073/سطل+رولی3» ← [39073، «سطل رولی3»] */
    public static function parse(?string $u): ?array
    {
        if (! $u || ! preg_match('#/product-(\d+)(?:/([^/?\#]*))?#u', $u, $m)) {
            return null;
        }
        $slug = trim(urldecode((string) ($m[2] ?? '')));

        return [(int) $m[1], $slug !== '' ? mb_substr($slug, 0, 250) : null];
    }

    /** بخش نام در لینک به همان شکل سایت قبلی: فاصله = +، حروف فارسی درصدی */
    public static function seg(string $s): string
    {
        return urlencode(trim($s));
    }

    public static function product(Product $p): ?string
    {
        $a = $p->getAttributes();
        if (empty($a['legacy_id'])) {
            return null;
        }

        return url('/product-'.$a['legacy_id'].'/'.static::seg((string) (($a['legacy_slug'] ?? null) ?: ($a['name'] ?? ''))));
    }

    public static function category(Category $c): ?string
    {
        $a = $c->getAttributes();
        if (empty($a['legacy_id'])) {
            return null;
        }

        return url('/category/'.$a['legacy_id'].'/'.static::seg((string) ($a['name'] ?? '')));
    }

    /** شناسه/نام سایت قبلی را از آدرس صفحه کالا در JSON (ردیف همگام‌سازی) روی کالاهای بدون شناسه می‌نشاند */
    public static function backfill(): int
    {
        $n = 0;
        DB::table('sync_items as s')->join('products as p', 'p.id', '=', 's.product_id')
            ->whereNull('p.legacy_id')->select('s.id', 's.product_id', 's.extra')->orderBy('s.id')
            ->chunk(500, function ($rows) use (&$n) {
                foreach ($rows as $r) {
                    $x = json_decode((string) $r->extra, true);
                    if (($l = static::parse($x['r']['u'] ?? null)) && static::claim($l[0], (int) $r->product_id)) {
                        $n += DB::table('products')->where('id', $r->product_id)->whereNull('legacy_id')
                            ->update(['legacy_id' => $l[0], 'legacy_slug' => $l[1]]);
                    }
                }
            });

        return $n;
    }

    /**
     * شناسه تازه برای کالای جدید (به شکل سایت قبلی: /product-شماره/نام) — هرگز تکراری نیست:
     * بزرگ‌تر از بزرگ‌ترین شناسه موجود، بزرگ‌ترین شناسه فید سایت قبلی و هر شناسه‌ای که قبلاً داده شده؛
     * با قفل، تا دو کالایی که هم‌زمان ساخته می‌شوند هم شماره یکسان نگیرند.
     */
    public static function nextId(): int
    {
        $lock = \Illuminate\Support\Facades\Cache::lock('legacy-id-lock', 10);
        $own = false;
        try {
            $own = (bool) $lock->block(5);
        } catch (\Throwable) {
        }
        try {
            $next = max(
                (int) DB::table('products')->max('legacy_id'),
                (int) setting('legacy_id_floor', 0),
                (int) \Illuminate\Support\Facades\Cache::get('legacy-id-last', 0),
                static::OWN_FROM - 1,
            ) + 1;
            \Illuminate\Support\Facades\Cache::forever('legacy-id-last', $next);

            return $next;
        } finally {
            if ($own) {
                $lock->release();
            }
        }
    }

    /** بزرگ‌ترین شناسه کالا در فید سایت قبلی (حتی کالاهایی که ساخته نشده‌اند) تا شناسه تازه با آن‌ها هم برخورد نکند */
    public static function feedMaxId(): int
    {
        $max = 0;
        try {
            DB::table('sync_items')->select('id', 'extra')->orderBy('id')->chunk(1000, function ($rows) use (&$max) {
                foreach ($rows as $r) {
                    if (preg_match('#/product-(\d+)#', (string) $r->extra, $m)) {
                        $max = max($max, (int) $m[1]);
                    }
                }
            });
        } catch (\Throwable) {
        }

        return $max;
    }

    /** نشاندن روی یک کالا (هنگام ساخت/به‌روزرسانی از JSON) */
    public static function apply(Product $p, ?string $pageUrl): void
    {
        if ($p->legacy_id || ! ($l = static::parse($pageUrl))) {
            return;
        }
        if (! static::claim($l[0], $p->id)) {
            return; // شناسه دست کالای دیگری از JSON است؛ کالا شناسه تازه می‌گیرد
        }
        $p->legacy_id = $l[0];
        $p->legacy_slug = $l[1];
    }

    /**
     * سایت قبلی هنوز کالای تازه می‌سازد و شماره‌اش ممکن است همان شماره‌ای باشد که این سایت به کالای دستی/آپلود گروهی داده.
     * شماره سایت قبلی اولویت دارد (لینکش در گوگل است): کالای این سایت شماره تازه (از ۱۰۰۰۰۰ به بالا) می‌گیرد
     * اگر شماره دست کالای دیگری از JSON باشد، false.
     */
    public static function claim(int $id, ?int $forProductId = null): bool
    {
        $other = DB::table('products')->where('legacy_id', $id)->when($forProductId, fn ($q) => $q->where('id', '!=', $forProductId))->first(['id', 'sync_code']);
        if (! $other) {
            return true;
        }
        $fromFeed = $other->sync_code !== null || DB::table('sync_items')->where('product_id', $other->id)->exists();
        if ($fromFeed) {
            return false;
        }
        DB::table('products')->where('id', $other->id)->update(['legacy_id' => static::nextId()]);

        return true;
    }
}
