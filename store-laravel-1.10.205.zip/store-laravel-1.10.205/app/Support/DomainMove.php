<?php

namespace App\Support;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Throwable;

/**
 * انتقال دامنه (مثلاً از zarfbanoo.com به aziziplast.com):
 * پیش‌بررسی سئو و همگام‌سازی، آزمایش اتصال دامنه تازه، تغییر APP_URL و ریدایرکت ۳۰۱ دامنه قدیم.
 */
class DomainMove
{
    public static function host(?string $url = null): string
    {
        return strtolower((string) parse_url($url ?? config('app.url'), PHP_URL_HOST));
    }

    public static function clean(string $d): string
    {
        $d = strtolower(trim(en_digits($d)));
        $d = preg_replace('#^https?://#', '', $d);

        return trim(explode('/', $d)[0]);
    }

    public static function validDomain(string $d): bool
    {
        return (bool) preg_match('/^(?=.{4,253}$)([a-z0-9-]{1,63}\.)+[a-z]{2,24}$/', $d);
    }

    /** وضعیت پیش از انتقال */
    public static function checks(): array
    {
        $p = Product::query()->count();
        $pl = Product::query()->whereNotNull('legacy_id')->count();
        $c = Category::query()->count();
        $cl = Category::query()->whereNotNull('legacy_id')->count();
        $sync = \App\Models\SyncSource::query()->where('enabled', true)->get(['id', 'name', 'url']);
        $noArch = \App\Models\SyncSource::query()->get()->filter(fn ($x) => ! $x->archiveInfo())->count();
        $remote = Product::query()->where(fn ($q) => $q->where('image', 'like', 'http%')->orWhere('image', 'like', '//%'))->count();

        $feed = \Illuminate\Support\Facades\DB::table('sync_items')->where('in_feed', true)->count();
        $made = \Illuminate\Support\Facades\DB::table('sync_items')->where('in_feed', true)->whereNotNull('product_id')->count();

        return [
            ['کالاهای سایت قبلی (JSON) ساخته‌شده در سایت', $feed && $made >= $feed * 0.98 ? 'good' : 'warn', fa($made).' از '.fa($feed).' کالای JSON در سایت ساخته شده'.($made < $feed ? ' — «ساخت همه کالاهای سایت قبلی» را بزنید (موجود و ناموجود).' : '.')],
            static::imagesCheck(),
            ['مقاله‌های سایت قبلی', ($np = \App\Models\Post::query()->whereNotNull('legacy_id')->count()) ? 'good' : 'warn',
                $np ? fa($np).' مقاله با شماره سایت قبلی (/blog-شماره/…) در وبلاگ است.' : 'هنوز مقاله‌ای از سایت قبلی وارد نشده؛ «ابزار سایت ← ورود مقاله‌های قبلی».'],
            ['شکل لینک‌ها هم‌شکل سایت قبلی', LegacyUrls::enabled() ? 'good' : 'bad', LegacyUrls::enabled() ? 'روشن است (/product-۲۱۰۹۳/… و /category/۱/…).' : 'خاموش است؛ «روشن کردن شکل لینک سایت قبلی» را بزنید.'],
            ['کالاهای دارای شناسه سایت قبلی', $p && $pl >= $p * 0.95 ? 'good' : ($pl ? 'warn' : 'bad'), fa($pl).' از '.fa($p).' کالا'.($pl < $p ? ' — بقیه با «پر کردن شناسه‌ها از JSON» یا در ویرایش کالا. کالای بدون شناسه: لینک قدیمی‌اش به جستجوی همان نام می‌رود.' : '')],
            ['دسته‌های دارای شناسه سایت قبلی', $c && $cl >= $c ? 'good' : ($cl ? 'warn' : 'bad'), fa($cl).' از '.fa($c).' دسته'],
            ['همگام‌سازی JSON', $sync->isEmpty() ? 'good' : 'warn', $sync->isEmpty() ? 'همه منابع خاموش است.' : fa($sync->count()).' منبع روشن است ('.$sync->pluck('name')->implode('، ').'). پس از انتقال، JSON سایت قبلی از دسترس خارج می‌شود؛ پیش از انتقال خاموش کنید.'],
            ['نسخه ذخیره‌شده JSON', $noArch ? 'warn' : 'good', $noArch ? fa($noArch).' منبع هنوز نسخه ذخیره‌شده ندارد؛ یک بار همگام‌سازی یا «ذخیره نسخه دائمی JSON» (همگام‌سازی JSON ← آیکن بایگانی) را بزنید.' : 'از همه منابع نسخه دائمی کنار سایت ذخیره شده است و پس از انتقال هم می‌ماند.'],
            ['تصاویر کالا از سایت دیگر', $remote ? 'warn' : 'good', $remote ? fa($remote).' کالا تصویرش را از آدرس بیرونی می‌خواند؛ پس از انتقال ممکن است نمایش داده نشود. در همگام‌سازی «دانلود تصاویر» را بزنید.' : 'همه تصاویر روی همین سایت ذخیره است.'],
            ['دامنه فعلی سایت', 'info', config('app.url')],
        ];
    }

    /** تصاویر کالاهای JSON که هنوز کامل روی همین هاست نیست (سبک/در صف/ناموفق) + برآورد فضا */
    public static function imagesCheck(): array
    {
        $q = \Illuminate\Support\Facades\DB::table('sync_items')->whereNotNull('product_id')->where('in_feed', true);
        $left = (clone $q)->whereIn('image_status', ['later', 'pending', 'failed', 'gallery'])->count();
        $failed = (clone $q)->where('image_status', 'failed')->count();
        // برآورد فضا از میانگین حجم تصاویر فعلی
        $sample = [];
        try {
            $dir = public_path('uploads/products');
            if (is_dir($dir)) {
                foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)) as $f) {
                    if (preg_match('/\.(jpe?g|webp|png)$/i', $f->getFilename())) {
                        $sample[] = $f->getPathname();
                        if (count($sample) >= 300) {
                            break;
                        }
                    }
                }
            }
        } catch (\Throwable) {
        }
        $avg = $sample ? array_sum(array_map('filesize', $sample)) / count($sample) : 250 * 1024;
        $need = $left * $avg * 3; // تصویر اصلی + گالری
        $free = function_exists('disk_free_space') ? @disk_free_space(base_path()) : false;
        $space = ' — فضای لازم حدوداً '.\App\Services\HostHealth::size($need).($free ? '، فضای آزاد هاست '.\App\Services\HostHealth::size($free) : '');

        return ['تصاویر کامل کالاها روی همین هاست', $left ? ($free !== false && $free < $need * 1.3 ? 'bad' : 'warn') : 'good',
            $left ? fa($left).' کالا هنوز تصویر کامل ندارد'.($failed ? ' ('.fa($failed).' ناموفق)' : '').'؛ پیش از انتقال «دانلود تصاویر کامل همه کالاها» را بزنید. پس از انتقال، تصاویر سایت قبلی در دسترس نیست.'.$space
                : 'همه تصاویر کامل روی همین هاست ذخیره شده است.'];
    }

    /** آزمایش: دامنه تازه به همین سایت (همین هاست) وصل است و SSL دارد؟ */
    public static function probe(string $domain): array
    {
        $token = Str::random(24);
        Cache::put('domain.probe', $token, 300);
        foreach (['https', 'http'] as $scheme) {
            try {
                $r = Http::timeout(15)->connectTimeout(8)->withoutRedirecting()->get($scheme.'://'.$domain.'/_domain-check');
                if (trim((string) $r->body()) === $token) {
                    return ['ok' => $scheme === 'https', 'msg' => $scheme === 'https' ? 'دامنه به همین سایت وصل است و SSL دارد ✓' : 'دامنه وصل است ولی SSL (https) ندارد؛ در سی‌پنل SSL رایگان (AutoSSL / Let\'s Encrypt) را برای این دامنه فعال کنید.'];
                }
                if ($r->status() >= 300 && $r->status() < 400) {
                    continue;
                }
            } catch (Throwable $e) {
                $err = $e->getMessage();
            }
        }

        return ['ok' => false, 'msg' => 'دامنه هنوز به این سایت نرسیده است (DNS هنوز تغییر نکرده، یا دامنه در سی‌پنل به پوشه همین سایت وصل نشده).'.(isset($err) ? ' — '.mb_substr($err, 0, 120) : '')];
    }

    /**
     * پیش از «اجبار https»: آیا https این دامنه به همین سایت می‌رسد و سایت آن را امن می‌بیند؟
     * (اگر پشت CDN/پروکسی سایت https را تشخیص ندهد، اجبار باعث چرخه ریدایرکت می‌شد)
     */
    public static function httpsWorks(string $host): bool
    {
        $token = Str::random(24);
        Cache::put('https.probe', $token, 300);
        try {
            $r = Http::timeout(15)->connectTimeout(8)->withoutRedirecting()->get('https://'.$host.'/_https-check');

            return trim((string) $r->body()) === $token.'|1';
        } catch (Throwable) {
            return false;
        }
    }

    /** ثبت دامنه تازه: APP_URL + فهرست دامنه‌های قدیم برای ۳۰۱ */
    public static function apply(string $domain, bool $www, array $old): void
    {
        $host = ($www ? 'www.' : '').$domain;
        $old = array_values(array_unique(array_filter(array_map(fn ($d) => static::clean((string) $d), $old), fn ($d) => static::validDomain($d) && $d !== $domain && $d !== 'www.'.$domain)));
        $cur = static::host();
        if ($cur && ! in_array($cur, [$domain, 'www.'.$domain], true)) {
            $old[] = preg_replace('/^www\./', '', $cur);
        }
        $old = array_values(array_unique($old));
        $file = base_path('.env');
        @copy($file, base_path('.env.before-domain-'.date('Ymd-His')));
        $env = (string) file_get_contents($file);
        $line = 'APP_URL=https://'.$host;
        $env = preg_match('/^APP_URL=.*$/m', $env) ? preg_replace('/^APP_URL=.*$/m', $line, $env) : $env."\n".$line;
        file_put_contents($file, $env);
        Settings::set(['domain_old' => $old, 'domain_host' => $host]);
        try {
            Artisan::call('config:clear');
            Artisan::call('cache:clear');
            Artisan::call('view:clear');
            Optimizer::clear();
            Settings::flush();
        } catch (Throwable $e) {
            report($e);
        }
    }

    /** آدرس ریدایرکت برای درخواست روی دامنه قدیم / شکل دیگر www (یا null) */
    public static function redirectFor(\Illuminate\Http\Request $request): ?string
    {
        $main = (string) setting('domain_host', '');
        if ($main === '') {
            return null;
        }
        $h = strtolower($request->getHost());
        if ($h === $main) {
            return null;
        }
        $bare = preg_replace('/^www\./', '', $h);
        $isOld = in_array($bare, (array) setting('domain_old', []), true);
        $isAlt = $bare === preg_replace('/^www\./', '', $main); // www ↔ بدون www
        if (! $isOld && ! $isAlt) {
            return null;
        }

        return 'https://'.$main.$request->getRequestUri();
    }
}
