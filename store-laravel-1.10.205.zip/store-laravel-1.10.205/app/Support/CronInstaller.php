<?php

namespace App\Support;

use Throwable;

/** تنظیم خودکار کرون هاست (cPanel/DirectAdmin) از داخل سایت، اگر هاست اجازه دهد */
class CronInstaller
{
    public static function php(): string
    {
        foreach (['/usr/local/bin/php', '/usr/bin/php', '/opt/cpanel/ea-php83/root/usr/bin/php', '/opt/cpanel/ea-php82/root/usr/bin/php'] as $p) {
            if (@is_file($p) && @is_executable($p)) {
                return $p;
            }
        }

        return 'php';
    }

    public static function command(): string
    {
        return static::php().' '.base_path('artisan').' store:cron > /dev/null 2>&1';
    }

    public static function line(): string
    {
        return '* * * * * '.static::command();
    }

    protected static function can(): bool
    {
        $disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));

        return function_exists('proc_open') && ! in_array('proc_open', $disabled, true);
    }

    /** @return array{0: int, 1: string, 2: string} */
    protected static function exec(string $cmd, ?string $stdin = null): array
    {
        $p = @proc_open($cmd, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
        if (! is_resource($p)) {
            return [127, '', 'proc_open'];
        }
        if ($stdin !== null) {
            fwrite($pipes[0], $stdin);
        }
        fclose($pipes[0]);
        $out = (string) stream_get_contents($pipes[1]);
        $err = (string) stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);

        return [proc_close($p), $out, $err];
    }

    /** آیا خط کرون فروشگاه از قبل وجود دارد؟ null = قابل بررسی نیست */
    public static function exists(): ?bool
    {
        if (! static::can()) {
            return null;
        }
        try {
            [$code, $out] = static::exec('crontab -l');

            return $code === 0 ? str_contains($out, 'store:cron') : false;
        } catch (Throwable) {
            return null;
        }
    }

    /** @return array{ok: bool, msg: string} */
    public static function install(): array
    {
        if (! static::can()) {
            return ['ok' => false, 'msg' => 'هاست اجازه تنظیم خودکار نمی‌دهد (proc_open غیرفعال است). دستور را دستی در cPanel ← Cron Jobs اضافه کنید.'];
        }
        try {
            [$code, $out, $err] = static::exec('crontab -l');
            if ($code !== 0 && ! preg_match('/no crontab/i', $err)) {
                return ['ok' => false, 'msg' => 'دسترسی به کرون از داخل سایت ممکن نشد ('.trim(mb_substr($err ?: 'crontab', 0, 120)).'). دستور را دستی در cPanel ← Cron Jobs اضافه کنید.'];
            }
            $cur = $code === 0 ? $out : '';
            if (str_contains($cur, 'store:cron')) {
                return ['ok' => true, 'msg' => 'کرون از قبل تنظیم شده است.'];
            }
            $new = rtrim($cur)."\n".static::line()."\n";
            [$c2, , $e2] = static::exec('crontab -', ltrim($new, "\n"));
            if ($c2 !== 0) {
                return ['ok' => false, 'msg' => 'ثبت کرون انجام نشد ('.trim(mb_substr($e2, 0, 120)).'). دستور را دستی اضافه کنید.'];
            }
            [, $check] = static::exec('crontab -l');

            return str_contains($check, 'store:cron')
                ? ['ok' => true, 'msg' => 'کرون تنظیم شد؛ از دقیقه بعد هر دقیقه اجرا می‌شود.']
                : ['ok' => false, 'msg' => 'کرون ثبت نشد. دستور را دستی در cPanel ← Cron Jobs اضافه کنید.'];
        } catch (Throwable $e) {
            return ['ok' => false, 'msg' => 'خطا: '.$e->getMessage()];
        }
    }
}
