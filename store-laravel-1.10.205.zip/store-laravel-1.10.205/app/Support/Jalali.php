<?php

namespace App\Support;

use Carbon\Carbon;
use DateTimeInterface;

class Jalali
{
    public static function fromGregorian(int $gy, int $gm, int $gd): array
    {
        $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy) + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100) + intdiv($gy2 + 399, 400) + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * intdiv($days, 12053));
        $days %= 12053;
        $jy += 4 * intdiv($days, 1461);
        $days %= 1461;
        if ($days > 365) {
            $jy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }
        if ($days < 186) {
            $jm = 1 + intdiv($days, 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + intdiv($days - 186, 30);
            $jd = 1 + (($days - 186) % 30);
        }

        return [$jy, $jm, $jd];
    }

    public static function toGregorian(int $jy, int $jm, int $jd): array
    {
        $jy += 1595;
        $days = -355668 + (365 * $jy) + (intdiv($jy, 33) * 8) + intdiv(($jy % 33) + 3, 4) + $jd + (($jm < 7) ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186);
        $gy = 400 * intdiv($days, 146097);
        $days %= 146097;
        if ($days > 36524) {
            $gy += 100 * intdiv(--$days, 36524);
            $days %= 36524;
            if ($days >= 365) {
                $days++;
            }
        }
        $gy += 4 * intdiv($days, 1461);
        $days %= 1461;
        if ($days > 365) {
            $gy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }
        $gd = $days + 1;
        $sal = [0, 31, (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        for ($gm = 0; $gm < 13 && $gd > $sal[$gm]; $gm++) {
            $gd -= $sal[$gm];
        }

        return [$gy, $gm, $gd];
    }

    public static function months(): array
    {
        return ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    }

    public static function format(mixed $date, bool $withTime = false, bool $long = false): string
    {
        $c = $date instanceof DateTimeInterface ? Carbon::instance($date) : Carbon::parse($date);
        $c = $c->setTimezone(config('app.timezone'));
        [$y, $m, $d] = static::fromGregorian((int) $c->format('Y'), (int) $c->format('n'), (int) $c->format('j'));
        $out = $long ? $d.' '.static::months()[$m - 1].' '.$y : sprintf('%04d/%02d/%02d', $y, $m, $d);
        if ($withTime) {
            $out .= ' - '.$c->format('H:i');
        }

        return fa($out);
    }

    /** «1405/07/16» یا «۱۴۰۵/۰۷/۱۶» → Carbon */
    public static function parse(?string $value): ?Carbon
    {
        if (! $value) {
            return null;
        }
        if (! preg_match('#^(\d{4})[/\-](\d{1,2})[/\-](\d{1,2})(?:\s+(\d{1,2}):(\d{2}))?#', en_digits(trim($value)), $mm)) {
            return null;
        }
        [$gy, $gm, $gd] = static::toGregorian((int) $mm[1], (int) $mm[2], (int) $mm[3]);

        return Carbon::create($gy, $gm, $gd, (int) ($mm[4] ?? 0), (int) ($mm[5] ?? 0), 0, config('app.timezone'));
    }
}
