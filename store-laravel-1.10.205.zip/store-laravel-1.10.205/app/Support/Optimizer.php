<?php

namespace App\Support;

use Illuminate\Support\Facades\Artisan;
use Throwable;

/** کش‌های تولیدی برای سرعت بیشتر سایت و پنل (مسیرها، اجزای پنل، آیکون‌ها) */
class Optimizer
{
    public static function warm(): array
    {
        $done = [];
        // کش مسیرها در فایل موقت ساخته و یک‌جا جایگزین می‌شود؛ وگرنه بازدیدی که هم‌زمان برسد
        // ممکن است فایل پاک‌شده را بخواند (خطای «routes-v7.php: Failed to open stream»)
        try {
            $real = app()->getCachedRoutesPath();
            $tmp = dirname($real).'/routes-v7.tmp.php';
            $prev = getenv('APP_ROUTES_CACHE');
            putenv('APP_ROUTES_CACHE='.$tmp);
            $_ENV['APP_ROUTES_CACHE'] = $_SERVER['APP_ROUTES_CACHE'] = $tmp;
            try {
                Artisan::call('route:cache');
            } finally {
                $prev === false ? putenv('APP_ROUTES_CACHE') : putenv('APP_ROUTES_CACHE='.$prev);
                unset($_ENV['APP_ROUTES_CACHE'], $_SERVER['APP_ROUTES_CACHE']);
            }
            if (is_file($tmp) && filesize($tmp) > 0) {
                @rename($tmp, $real);
                $done[] = 'route:cache';
            } elseif (! is_file($real)) {
                Artisan::call('route:cache');
                $done[] = 'route:cache';
            }
        } catch (Throwable $e) {
            report($e);
        }
        try {
            Artisan::call('filament:cache-components');
            $done[] = 'filament:cache-components';
        } catch (Throwable $e) {
            report($e);
        }
        // دستور icons:cache فقط در خط فرمان ثبت می‌شود؛ همان کار مستقیم انجام می‌شود
        try {
            app(\BladeUI\Icons\IconsManifest::class)->write(app(\BladeUI\Icons\Factory::class)->all());
            $done[] = 'icons:cache';
        } catch (Throwable $e) {
            report($e);
        }

        @file_put_contents(base_path('bootstrap/cache/.stamp'), @filemtime(config_path('store.php')).'-'.@filemtime(base_path('routes/web.php')));

        return $done;
    }

    public static function clear(): void
    {
        foreach (['bootstrap/cache/routes-v7.php', 'bootstrap/cache/blade-icons.php', 'bootstrap/cache/config.php', 'bootstrap/cache/events.php'] as $f) {
            @unlink(base_path($f));
        }
        $dir = base_path('bootstrap/cache/filament');
        if (is_dir($dir)) {
            $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST);
            foreach ($it as $f) {
                $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname());
            }
            @rmdir($dir);
        }
    }
}
