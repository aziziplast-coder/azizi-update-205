<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

/** لینک کوتاه پیامکی: دامنه/l/کد (بدون https و پارامترهای بلند) */
class ShortLink
{
    public static function code(string $url): ?string
    {
        try {
            $hash = sha1($url);
            $row = DB::table('short_links')->where('hash', $hash)->first();
            if ($row) {
                return $row->code;
            }
            for ($i = 0; $i < 5; $i++) {
                $code = Str::lower(Str::random(6));
                if (! DB::table('short_links')->where('code', $code)->exists()) {
                    DB::table('short_links')->insert(['code' => $code, 'hash' => $hash, 'url' => $url, 'created_at' => now(), 'updated_at' => now()]);

                    return $code;
                }
            }
        } catch (Throwable $e) {
            report($e);
        }

        return null;
    }

    /**
     * لینک برای متن پیامک بر اساس تنظیم «لینک در پیامک»:
     * short = aziziplast.com/l/ab12cd (پیش‌فرض) | full = لینک کامل | none = بدون لینک
     */
    public static function forSms(string $url): string
    {
        $mode = (string) setting('sms_link', 'short');
        if ($mode === 'none') {
            return '';
        }
        if ($mode === 'full') {
            return $url;
        }
        $code = static::code($url);
        $host = preg_replace('/^www\./', '', (string) parse_url(config('app.url'), PHP_URL_HOST));

        return $code ? $host.'/l/'.$code : $url;
    }

    public static function resolve(string $code): ?string
    {
        $row = DB::table('short_links')->where('code', strtolower($code))->first();
        if (! $row) {
            return null;
        }
        DB::table('short_links')->where('id', $row->id)->increment('hits');
        // فقط داخل همین سایت (با دامنه فعلی؛ پس از انتقال دامنه هم کار می‌کند)
        $p = parse_url((string) $row->url);

        return url(($p['path'] ?? '/').(isset($p['query']) ? '?'.$p['query'] : ''));
    }
}
