<?php

namespace App\Support;

use Symfony\Component\Mime\MimeTypeGuesserInterface;

/** جایگزین ساده برای هاست‌هایی که افزونه fileinfo ندارند */
class SimpleMimeGuesser implements MimeTypeGuesserInterface
{
    protected const MAP = [
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp',
        'svg' => 'image/svg+xml', 'pdf' => 'application/pdf', 'zip' => 'application/zip', 'json' => 'application/json',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'xls' => 'application/vnd.ms-excel',
        'csv' => 'text/csv', 'txt' => 'text/plain', 'woff2' => 'font/woff2', 'woff' => 'font/woff', 'ttf' => 'font/ttf', 'mp3' => 'audio/mpeg',
        'mp4' => 'video/mp4', 'sql' => 'text/plain', 'gz' => 'application/gzip', 'heic' => 'image/heic',
    ];

    public function isGuesserSupported(): bool
    {
        return true;
    }

    public function guessMimeType(string $path): ?string
    {
        if (! is_file($path) || ! is_readable($path)) {
            return null;
        }
        $info = @getimagesize($path);
        if ($info && ! empty($info['mime'])) {
            return $info['mime'];
        }
        $head = (string) @file_get_contents($path, false, null, 0, 8);
        if (str_starts_with($head, '%PDF')) {
            return 'application/pdf';
        }
        if (str_starts_with($head, "PK\x03\x04")) {
            return 'application/zip';
        }
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));

        return self::MAP[$ext] ?? 'application/octet-stream';
    }
}
