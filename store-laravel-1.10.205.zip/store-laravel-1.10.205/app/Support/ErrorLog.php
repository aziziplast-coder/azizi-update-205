<?php

namespace App\Support;

use Illuminate\Support\Carbon;
use Throwable;

/**
 * سامانه شناسایی خطا: خواندن لاگ سایت، گروه‌بندی خطاهای یکسان، تشخیص وضعیت هر خطا
 *  - ✅ برطرف‌شده: در فهرست رفع‌شده‌ها هست و نسخه فعلی سایت همان نسخه یا جدیدتر است (و بعد از نصبش تکرار نشده)
 *  - ⏳ موقت حین به‌روزرسانی: در چند دقیقه‌ای که فایل‌ها جابه‌جا می‌شدند رخ داده (نه ایراد کد)
 *  - ⚠️ دوباره رخ داده: رفع شده بود ولی بعد از نصب نسخه رفع، باز هم دیده شد
 *  - 🆕 باز: هنوز بررسی نشده
 */
class ErrorLog
{
    /**
     * خطاهای رفع‌شده: [الگو، نسخه رفع، عنوان فارسی، توضیح]
     * هر بار خطایی رفع می‌شود، یک سطر اینجا اضافه می‌شود.
     */
    public const FIXES = [
        ['~Walkin::(account|link|byToken|issue|remits)\(\)~', '1.10.193', 'فیش حضوری (اپ مدیریت): صفحه فیش باز نمی‌شد', 'با بازنویسی «فروش حضوری» در نسخه ۱۶۹، بخش «فیش حضوری» (صدور فیش برای مشتری حضوری) جا افتاده بود. به کلاس جداگانه برگشت و دوباره کار می‌کند.'],
        ['~Route \[live\.\w+\] not defined~', '1.10.193', 'گفتگوی زنده: خطای لحظه‌ای هنگام نصب به‌روزرسانی', 'وقتی فایل‌های نسخه جدید نصب می‌شد، چند ثانیه صفحه‌ها با فایل‌های نیمه‌قدیم/نیمه‌جدید باز می‌شد. از این نسخه در آن چند ثانیه صفحه «در حال به‌روزرسانی» نشان داده می‌شود و گفتگوی زنده هم هرگز صفحه را از کار نمی‌اندازد.'],
        ['~mkdir\(\): File exists.*ThumbController~s', '1.10.193', 'ساخت تصویر کوچک: دو درخواست هم‌زمان', 'دو بازدید هم‌زمان یک پوشه را می‌ساختند. بی‌خطر بود (تصویر اصلی نمایش داده می‌شد)؛ حالا اصلاً خطا ثبت نمی‌شود.'],
        ['~routes-v7\.php\): Failed to open stream~', '1.10.193', 'کش مسیرها حین به‌روزرسانی', 'لحظه نصب نسخه جدید رخ می‌داد. از این نسخه در آن لحظه صفحه «در حال به‌روزرسانی» نشان داده می‌شود.'],
        ['~include\(.*/vendor/.*\): Failed to open stream~', '1.10.193', 'فایل‌های کتابخانه حین به‌روزرسانی', 'وقتی پوشه vendor جابه‌جا می‌شد، یک بازدید هم‌زمان رسیده بود. از این نسخه با صفحه «در حال به‌روزرسانی» جلوگیری می‌شود.'],
        ['~unexpected token "endforeach".*factory/_pay~s', '1.10.173', 'اپ کارخانه‌داران: خطا هنگام تأیید فیش', 'ساختار یک قالب صفحه اشتباه بود؛ در نسخه ۱۷۳ درست شد.'],
        ['~Updater::install\(\): Argument #1 \(\$zipPath\)~', '1.10.174', 'به‌روزرسانی: فایل انتخاب‌شده گم می‌شد', 'در نسخه ۱۷۴ درست شد.'],
        ['~TextInput::dir does not exist~', '1.10.188', 'تنظیمات گفتگوی زنده', 'پیش از انتشار درست شد.'],
        ['~\[\$(s|d|q)\] was unresolvable~', '1.10.192', 'جدول‌های پنل (فیلتر/دکمه)', 'نام‌گذاری ورودی‌ها اصلاح شد.'],
    ];

    /** خطاهایی که ذاتاً لحظه‌ای‌اند (اگر نزدیک زمان به‌روزرسانی باشند) */
    public const TRANSIENT = ['~Failed to open stream~', '~not defined~', '~Class ".*" not found~', '~Call to undefined method~', '~no such table|Base table or view not found|Unknown column|no such column~i'];

    public static function files(): array
    {
        $f = glob(storage_path('logs/*.log')) ?: [];
        usort($f, fn ($a, $b) => filemtime($b) <=> filemtime($a));

        return array_slice($f, 0, 4);
    }

    /** زمان‌های نصب نسخه‌ها از گزارش به‌روزرسانی: [[زمان شروع, نسخه مقصد], ...] */
    public static function updates(): array
    {
        $out = [];
        try {
            $f = app(\App\Services\Updater::class)->workDir().'/update.log';
            if (is_file($f)) {
                foreach (array_slice(file($f) ?: [], -400) as $l) {
                    if (preg_match('~^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\] شروع به‌روزرسانی (\S+) ← (\S+)~u', $l, $m)) {
                        $out[] = [Carbon::parse($m[1]), $m[3]];
                    }
                }
            }
        } catch (Throwable) {
        }

        return $out;
    }

    /** خواندن و گروه‌بندی (آخرین چند مگابایت لاگ) */
    public static function groups(int $maxBytes = 6_000_000): array
    {
        $base = rtrim(base_path(), '/').'/';
        $groups = [];
        foreach (static::files() as $file) {
            $size = filesize($file);
            $fh = fopen($file, 'rb');
            if (! $fh) {
                continue;
            }
            if ($size > $maxBytes) {
                fseek($fh, $size - $maxBytes);
                fgets($fh);
            }
            $cur = null;
            $flush = function () use (&$cur, &$groups, $base) {
                if (! $cur) {
                    return;
                }
                $msg = $cur['msg'];
                $ctx = '';
                if (($p = strpos($msg, ' {"')) !== false) {
                    $ctx = substr($msg, $p);
                    $msg = substr($msg, 0, $p);
                }
                $view = preg_match('~\(View: ([^)]*)\)~', $msg, $vm) ? str_replace($base, '', $vm[1]) : '';
                $msg = preg_replace('~ \(View: [^)]*\)~', '', $msg);
                $msg = str_replace($base, '', $msg);
                $loc = '';
                if (preg_match('~ at (/[^\s)]+):(\d+)\)~', $ctx, $m)) {
                    $loc = str_replace($base, '', $m[1]).':'.$m[2];
                }
                if ($view !== '' && ($loc === '' || str_contains($loc, 'storage/framework/views'))) {
                    $loc = $view; // خطای قالب: خود فایل قالب مهم است، نه نسخه کامپایل‌شده
                }
                $uid = preg_match('~"userId":(\d+)~', $ctx, $m) ? (int) $m[1] : null;
                $sigText = preg_replace(['~\d{2,}~', '~"[^"]{30,}"~'], ['#', '"…"'], $msg).'|'.preg_replace('~:\d+$~', '', $loc);
                $sig = substr(md5($sigText), 0, 12);
                $g = &$groups[$sig];
                $g ??= ['sig' => $sig, 'msg' => mb_substr($msg, 0, 600), 'loc' => $loc, 'level' => $cur['level'], 'count' => 0, 'first' => $cur['t'], 'last' => $cur['t'], 'users' => [], 'times' => [], 'trace' => ''];
                $g['count']++;
                $g['last'] = max($g['last'], $cur['t']);
                $g['first'] = min($g['first'], $cur['t']);
                if ($uid) {
                    $g['users'][$uid] = 1;
                }
                $g['times'][] = $cur['t'];
                if ($g['trace'] === '' && $cur['trace']) {
                    $g['trace'] = str_replace($base, '', implode("\n", array_slice($cur['trace'], 0, 10)));
                }
                unset($g);
                $cur = null;
            };
            while (($line = fgets($fh)) !== false) {
                if (preg_match('~^\[(\d{4}-\d\d-\d\d[ T]\d\d:\d\d:\d\d)[^\]]*\] \w+\.(ERROR|CRITICAL|ALERT|EMERGENCY|WARNING): (.*)$~', $line, $m)) {
                    $flush();
                    $cur = ['t' => str_replace('T', ' ', $m[1]), 'level' => $m[2], 'msg' => rtrim($m[3]), 'trace' => []];
                } elseif ($cur && str_starts_with($line, '#') && count($cur['trace']) < 12) {
                    $cur['trace'][] = rtrim($line);
                } elseif ($cur && ! str_starts_with($line, '[stacktrace]') && ! str_starts_with($line, '"}') && count($cur['trace']) === 0 && strlen($cur['msg']) < 4000) {
                    $cur['msg'] .= ' '.trim($line);
                }
            }
            $flush();
            fclose($fh);
        }

        return static::classify(array_values($groups));
    }

    public static function classify(array $groups): array
    {
        $ver = (string) config('store.version');
        $ups = static::updates();
        $installedAt = [];
        foreach ($ups as [$t, $v]) {
            $installedAt[$v] = $t; // آخرین نصب هر نسخه
        }
        $ack = (array) setting('errlog_ack', []);
        $nearUpdate = function (string $t) use ($ups): bool {
            $c = Carbon::parse($t);
            foreach ($ups as [$u]) {
                if ($c->between($u->copy()->subMinute(), $u->copy()->addMinutes(6))) {
                    return true;
                }
            }

            return false;
        };
        foreach ($groups as &$g) {
            $g['users'] = count($g['users']);
            $g['status'] = 'open';
            $g['title'] = null;
            $g['why'] = null;
            $g['fixed_in'] = null;
            $text = $g['msg'].' '.$g['loc'];
            foreach (static::FIXES as [$re, $fixedIn, $title, $why]) {
                if (preg_match($re, $text)) {
                    $g['title'] = $title;
                    $g['why'] = $why;
                    $g['fixed_in'] = $fixedIn;
                    if (version_compare($ver, $fixedIn, '>=')) {
                        $since = $installedAt[$fixedIn] ?? null;
                        $after = $since ? count(array_filter($g['times'], fn ($t) => Carbon::parse($t)->gt($since->copy()->addMinutes(6)))) : 0;
                        $g['status'] = $after ? 'again' : 'fixed';
                        $g['after'] = $after;
                    } else {
                        $g['status'] = 'pending'; // رفعش در نسخه جدیدتری است که هنوز نصب نشده
                    }
                    break;
                }
            }
            if ($g['status'] === 'open') {
                $isTrans = false;
                foreach (static::TRANSIENT as $re) {
                    if (preg_match($re, $text)) {
                        $isTrans = true;
                        break;
                    }
                }
                if ($isTrans && count(array_filter($g['times'], fn ($t) => ! $nearUpdate($t))) === 0) {
                    $g['status'] = 'transient';
                }
            }
            if (in_array($g['status'], ['open', 'again'], true) && isset($ack[$g['sig']]) && $g['last'] <= $ack[$g['sig']]) {
                $g['status'] = 'acked';
            }
            unset($g['times']);
        }
        unset($g);
        usort($groups, fn ($a, $b) => [static::rank($a['status']), $b['last']] <=> [static::rank($b['status']), $a['last']]);

        return $groups;
    }

    protected static function rank(string $s): int
    {
        return ['again' => 0, 'open' => 1, 'pending' => 2, 'transient' => 3, 'acked' => 4, 'fixed' => 5][$s] ?? 9;
    }

    /** تعداد خطاهای باز در ۲۴ ساعت اخیر (برای عدد کنار منو؛ کش ۵ دقیقه) */
    public static function openCount(): int
    {
        try {
            return (int) \Illuminate\Support\Facades\Cache::remember('errlog.open', 300, function () {
                $since = now()->subDay()->format('Y-m-d H:i:s');

                return count(array_filter(static::groups(1_500_000), fn ($g) => in_array($g['status'], ['open', 'again'], true) && $g['last'] >= $since));
            });
        } catch (Throwable) {
            return 0;
        }
    }

    public static function ack(string $sig): void
    {
        $a = (array) setting('errlog_ack', []);
        $a[$sig] = now()->format('Y-m-d H:i:s');
        Settings::set(['errlog_ack' => array_slice($a, -500, null, true)]);
        \Illuminate\Support\Facades\Cache::forget('errlog.open');
    }

    /** گزارش متنی برای فرستادن به پشتیبان */
    public static function report(array $groups): string
    {
        $o = 'گزارش خطاهای سایت — نسخه '.config('store.version').' — '.now()->format('Y-m-d H:i')."\n\n";
        foreach ($groups as $g) {
            if (! in_array($g['status'], ['open', 'again', 'pending'], true)) {
                continue;
            }
            $o .= '['.$g['status'].'] ×'.$g['count'].' | اول: '.$g['first'].' | آخر: '.$g['last']."\n".$g['msg']."\n".$g['loc']."\n".$g['trace']."\n\n";
        }

        return $o;
    }
}
