<?php

namespace App\Support;

use App\Models\Category;

/**
 * تنظیمات تجربه مشتری در اپ (و بخشی در سایت): ورود پیش از خرید، صداها، پاپ‌آپ اطلاعیه،
 * نمایش اقلام در صفحه ارسال و پرداخت، و پیوند «طراحی و توسعه».
 */
class AppUx
{
    /** صداهای آماده (فایل در اپ: res/raw و در سایت: public/sounds برای پیش‌نمایش) */
    public const ADD_SOUNDS = [
        'pop' => 'حباب (کوتاه و نرم)',
        'chime' => 'زنگوله دو نت',
        'drop' => 'قطره',
        'coin' => 'سکه',
        'tap' => 'ضربه نرم',
    ];

    public const ORDER_SOUNDS = [
        'success' => 'موفقیت (آرپژ)',
        'bell' => 'ناقوس شاد',
        'sparkle' => 'درخشش',
        'cash' => 'صندوق',
    ];

    public const GATES = [
        'off' => 'خاموش — مهمان هم کالا را به سبد اضافه می‌کند (ورود هنگام ثبت سفارش)',
        'cart' => 'پیش از افزودن به سبد — برای افزودن اولین کالا باید وارد شود یا ثبت‌نام کند',
        'browse' => 'پیش از ورود به اپ — اپ با صفحه ورود باز می‌شود (فقط اپ؛ سایت مثل «پیش از افزودن به سبد»)',
    ];

    public const ITEMS_VIEW = [
        'collapsed' => 'بسته — دکمه «خریدهای شما (… قلم)»؛ با لمس باز می‌شود',
        'shown' => 'باز — همه اقلام نمایش داده می‌شود',
        'hidden' => 'پنهان — فقط جمع مبلغ',
    ];

    public static function cfg(): array
    {
        $c = (array) setting('app_ux', []);
        $c['login_gate'] = array_key_exists($c['login_gate'] ?? '', self::GATES) ? $c['login_gate'] : 'off';
        $c['items_view'] = array_key_exists($c['items_view'] ?? '', self::ITEMS_VIEW) ? $c['items_view'] : 'collapsed';
        $s = (array) ($c['sounds'] ?? []);
        $c['sounds'] = [
            'enabled' => ! array_key_exists('enabled', $s) || ! empty($s['enabled']),
            'add_on' => ! array_key_exists('add_on', $s) || ! empty($s['add_on']),
            'order_on' => ! array_key_exists('order_on', $s) || ! empty($s['order_on']),
            'add' => array_key_exists($s['add'] ?? '', self::ADD_SOUNDS) ? $s['add'] : 'pop',
            'order' => array_key_exists($s['order'] ?? '', self::ORDER_SOUNDS) ? $s['order'] : 'success',
            'add_file' => $s['add_file'] ?? null,
            'order_file' => $s['order_file'] ?? null,
            'volume' => max(10, min(100, (int) ($s['volume'] ?? 70))),
        ];
        $cr = (array) ($c['credit'] ?? []);
        $c['credit'] = ['text' => trim((string) ($cr['text'] ?? '')), 'url' => trim((string) ($cr['url'] ?? ''))];

        return $c;
    }

    public static function loginGate(): string
    {
        return static::cfg()['login_gate'];
    }

    /** مهمان اجازه افزودن به سبد ندارد؟ */
    public static function guestBlocked(): bool
    {
        return static::loginGate() !== 'off' && ! auth()->check();
    }

    public static function itemsView(): string
    {
        return static::cfg()['items_view'];
    }

    /** خروجی برای API تنظیمات اپ */
    public static function forApp(): array
    {
        $c = static::cfg();
        $s = $c['sounds'];

        return [
            'login_gate' => $c['login_gate'],
            'sounds' => [
                'enabled' => $s['enabled'],
                'add' => $s['add_on'] ? $s['add'] : '',
                'order' => $s['order_on'] ? $s['order'] : '',
                'add_url' => $s['add_on'] && $s['add_file'] ? \App\Support\ApiData::file($s['add_file']) : null,
                'order_url' => $s['order_on'] && $s['order_file'] ? \App\Support\ApiData::file($s['order_file']) : null,
                'volume' => $s['volume'],
            ],
            'popups' => static::popups(),
            'credit' => $c['credit']['text'] !== '' ? $c['credit'] : null,
            'items_view' => $c['items_view'],
            // «راه‌اندازی مرحله‌ای»: ثبت سفارش داخل اپ یا صفحه سایت (داخل اپ)
            'native_checkout' => (bool) setting('app_native_checkout', true),
        ];
    }

    /**
     * پاپ‌آپ‌های اطلاعیه: عمومی (صفحه اصلی) یا مخصوص دسته (هنگام باز کردن آن دسته)، یک‌بار یا هر بار، با تأخیر چند ثانیه.
     *
     * @return array<int, array>
     */
    public static function popups(): array
    {
        $out = [];
        $now = now();
        foreach ((array) (setting('app_ux')['popups'] ?? []) as $i => $p) {
            if (empty($p['enabled'])) {
                continue;
            }
            $title = trim((string) ($p['title'] ?? ''));
            $text = trim((string) ($p['text'] ?? ''));
            if ($title === '' && $text === '' && empty($p['image'])) {
                continue;
            }
            if (! empty($p['until']) && \Illuminate\Support\Carbon::parse($p['until'])->endOfDay()->isPast()) {
                continue;
            }
            $cats = [];
            if (($p['scope'] ?? 'home') === 'category') {
                // دسته‌های انتخابی + زیردسته‌هایشان
                $ids = array_map('intval', (array) ($p['categories'] ?? []));
                $cats = $ids ? array_values(array_unique(array_merge($ids, Category::query()->whereIn('parent_id', $ids)->pluck('id')->all()))) : [];
                if (! $cats) {
                    continue;
                }
            }
            $link = trim((string) ($p['link'] ?? ''));
            $target = match ($p['link_kind'] ?? ($link !== '' ? 'url' : 'none')) {
                'product' => ! empty($p['product_id']) ? ['kind' => 'product', 'id' => (int) $p['product_id']] : null,
                'category' => ! empty($p['category_id']) ? ['kind' => 'list', 'params' => ['category' => (int) $p['category_id']], 'title' => (string) Category::query()->whereKey($p['category_id'])->value('name')] : null,
                'url' => $link !== '' ? ['kind' => 'web', 'url' => preg_match('#^https?://#', $link) ? $link : url($link)] : null,
                default => null,
            };
            $out[] = [
                // شناسه پایدار: با تغییر متن، دوباره برای همه نمایش داده می‌شود
                'id' => substr(md5(json_encode([$title, $text, $p['image'] ?? '', $i])), 0, 12),
                'title' => $title,
                'text' => $text,
                'image' => ! empty($p['image']) ? \App\Support\ApiData::img($p['image'], 960) : null,
                'button' => trim((string) ($p['button'] ?? '')),
                'target' => $target,
                'scope' => ($p['scope'] ?? 'home') === 'category' ? 'category' : 'home',
                'categories' => $cats,
                'delay' => max(0, min(60, (int) ($p['delay'] ?? 2))),
                'once' => ! array_key_exists('once', $p) || ! empty($p['once']),
            ];
        }

        return $out;
    }
}
