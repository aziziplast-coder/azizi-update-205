<?php

namespace App\Support;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Support\Str;

/**
 * پر کردن خودکار عنوان و توضیح سئوی کالاها و دسته‌هایی که خالی مانده‌اند،
 * طبق توصیه‌های فعلی گوگل: عنوان یکتا و توصیفی حداکثر ~۶۰ حرف، توضیح ۱۲۰ تا ۱۵۵ حرف با ذکر ویژگی اصلی،
 * بدون تکرار کلمات کلیدی و بدون قیمت (تا با تغییر قیمت کهنه نشود).
 */
class SeoAuto
{
    public const TITLE = '{name} | خرید عمده و کارتنی';

    public const DESC = 'خرید {name}{category_part} با قیمت عمده؛ کارتن {carton} عددی و امکان خرید تکی. ارسال به سراسر کشور از {store}.';

    public static function enabled(): bool
    {
        return (bool) setting('seo_auto', true);
    }

    protected static function fill(string $tpl, array $vars): string
    {
        $out = strtr($tpl, $vars);

        return trim(preg_replace('/\s+/u', ' ', $out));
    }

    public static function productVars(Product $p): array
    {
        static $names = [];
        $cat = '';
        if ($p->category_id) {
            $cat = $names[$p->category_id] ??= (string) (Category::query()->whereKey($p->category_id)->value('name') ?? '');
        }

        return [
            '{name}' => trim((string) $p->name), '{category}' => $cat, '{category_part}' => $cat !== '' ? ' از دسته '.$cat : '',
            '{carton}' => fa(max(1, (int) $p->per_carton)), '{store}' => store_name(), '{site}' => store_name(), '{code}' => (string) ($p->sku ?: $p->barcode),
        ];
    }

    public static function product(Product $p, bool $force = false): bool
    {
        $changed = false;
        $v = static::productVars($p);
        if ($force || blank($p->seo_title)) {
            $t = static::fill((string) (setting('seo_auto_title') ?: static::TITLE), $v);
            // عنوان بلند: نام کوتاه می‌شود نه برند
            if (mb_strlen($t) > 65) {
                $t = Str::limit($v['{name}'], 58, '');
            }
            $p->seo_title = $t;
            $changed = true;
        }
        if ($force || blank($p->seo_description)) {
            $p->seo_description = Str::limit(static::fill((string) (setting('seo_auto_desc') ?: static::DESC), $v), 158, '…');
            $changed = true;
        }

        return $changed;
    }

    public static function category(Category $c, bool $force = false): bool
    {
        $changed = false;
        if ($force || blank($c->seo_title)) {
            $c->seo_title = Str::limit('خرید عمده '.$c->name.' | قیمت و تنوع', 62, '');
            $changed = true;
        }
        if ($force || blank($c->seo_description)) {
            $c->seo_description = Str::limit('خرید عمده و کارتنی انواع '.$c->name.' با بهترین قیمت و امکان خرید تکی؛ ارسال سریع به سراسر کشور از '.store_name().'.', 158, '…');
            $changed = true;
        }

        return $changed;
    }

    /** پر کردن همه خالی‌ها (یا بازنویسی همه) — دسته‌ای و سبک */
    public static function fillAll(bool $force = false): array
    {
        @set_time_limit(600);
        $n = ['products' => 0, 'categories' => 0];
        $q = Product::query()->select(['id', 'name', 'sku', 'barcode', 'per_carton', 'category_id', 'seo_title', 'seo_description']);
        if (! $force) {
            $q->where(fn ($w) => $w->whereNull('seo_title')->orWhere('seo_title', '')->orWhereNull('seo_description')->orWhere('seo_description', ''));
        }
        $q->chunkById(300, function ($chunk) use (&$n, $force) {
            foreach ($chunk as $p) {
                if (static::product($p, $force)) {
                    Product::query()->whereKey($p->id)->update(['seo_title' => $p->seo_title, 'seo_description' => $p->seo_description]);
                    $n['products']++;
                }
            }
        });
        foreach (Category::query()->get() as $c) {
            if (static::category($c, $force)) {
                $c->saveQuietly();
                $n['categories']++;
            }
        }

        return $n;
    }
}
