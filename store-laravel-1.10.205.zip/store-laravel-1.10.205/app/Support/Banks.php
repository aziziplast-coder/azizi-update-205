<?php

namespace App\Support;

/** شناسایی بانک از شماره کارت/شبا و اعتبارسنجی آن‌ها */
class Banks
{
    /** شش رقم اول کارت → بانک */
    public const BIN = [
        '603799' => 'ملی', '170019' => 'ملی', '589210' => 'سپه', '627381' => 'سپه (انصار)', '603769' => 'صادرات', '903769' => 'صادرات',
        '610433' => 'ملت', '991975' => 'ملت', '627353' => 'تجارت', '585983' => 'تجارت', '589463' => 'رفاه', '603770' => 'کشاورزی',
        '639217' => 'کشاورزی', '628023' => 'مسکن', '627648' => 'توسعه صادرات', '207177' => 'توسعه صادرات', '627961' => 'صنعت و معدن',
        '627760' => 'پست بانک', '502908' => 'توسعه تعاون', '627412' => 'اقتصاد نوین', '622106' => 'پارسیان', '639194' => 'پارسیان',
        '627884' => 'پارسیان', '502229' => 'پاسارگاد', '639347' => 'پاسارگاد', '627488' => 'کارآفرین', '502910' => 'کارآفرین',
        '621986' => 'سامان', '639346' => 'سینا', '639607' => 'سرمایه', '636214' => 'آینده', '502806' => 'شهر', '504706' => 'شهر',
        '502938' => 'دی', '639370' => 'مهر اقتصاد', '639599' => 'قوامین', '504172' => 'رسالت', '606373' => 'قرض‌الحسنه مهر ایران',
        '505785' => 'ایران زمین', '505801' => 'کوثر', '636949' => 'حکمت ایرانیان', '585947' => 'خاورمیانه', '628157' => 'توسعه',
        '505416' => 'گردشگری', '606256' => 'ملل', '507677' => 'نور', '636795' => 'مرکزی',
    ];

    /** کد بانک در شبا (رقم ۵ تا ۷) → بانک */
    public const SHEBA = [
        '017' => 'ملی', '015' => 'سپه', '019' => 'صادرات', '012' => 'ملت', '018' => 'تجارت', '013' => 'رفاه', '016' => 'کشاورزی',
        '014' => 'مسکن', '020' => 'توسعه صادرات', '011' => 'صنعت و معدن', '021' => 'پست بانک', '022' => 'توسعه تعاون',
        '055' => 'اقتصاد نوین', '054' => 'پارسیان', '057' => 'پاسارگاد', '053' => 'کارآفرین', '056' => 'سامان', '059' => 'سینا',
        '058' => 'سرمایه', '062' => 'آینده', '061' => 'شهر', '066' => 'دی', '060' => 'قرض‌الحسنه مهر ایران', '070' => 'رسالت',
        '063' => 'انصار', '069' => 'ایران زمین', '078' => 'خاورمیانه', '065' => 'گردشگری', '064' => 'گردشگری', '051' => 'توسعه',
        '010' => 'مرکزی', '075' => 'ملل', '080' => 'نور',
    ];

    public static function digits(?string $v): string
    {
        return preg_replace('/\D/', '', en_digits((string) $v));
    }

    public static function normalizeSheba(?string $v): string
    {
        $d = static::digits($v);

        return $d === '' ? '' : 'IR'.substr($d, 0, 24);
    }

    public static function fromCard(?string $card): ?string
    {
        $d = static::digits($card);

        return strlen($d) >= 6 ? (static::BIN[substr($d, 0, 6)] ?? null) : null;
    }

    public static function fromSheba(?string $sheba): ?string
    {
        $d = static::digits($sheba);

        return strlen($d) >= 5 ? (static::SHEBA[substr($d, 2, 3)] ?? null) : null;
    }

    /** الگوریتم لون برای کارت‌های بانکی */
    public static function validCard(?string $card): bool
    {
        $d = static::digits($card);
        if (strlen($d) !== 16) {
            return false;
        }
        $sum = 0;
        for ($i = 0; $i < 16; $i++) {
            $n = (int) $d[$i];
            if ($i % 2 === 0) {
                $n *= 2;
                if ($n > 9) {
                    $n -= 9;
                }
            }
            $sum += $n;
        }

        return $sum % 10 === 0;
    }

    /** شبا: IR + ۲۴ رقم با کنترل mod 97 */
    public static function validSheba(?string $sheba): bool
    {
        $d = static::digits($sheba);
        if (strlen($d) !== 24) {
            return false;
        }
        $rearranged = substr($d, 2).'1827'.substr($d, 0, 2); // I=18 R=27
        $mod = 0;
        foreach (str_split($rearranged, 7) as $chunk) {
            $mod = (int) (($mod.$chunk) % 97);
        }

        return $mod === 1;
    }

    public static function formatSheba(?string $sheba): string
    {
        $d = static::digits($sheba);

        return $d ? 'IR'.substr($d, 0, 2).' '.trim(chunk_split(substr($d, 2), 4, ' ')) : '';
    }

    public static function formatCard(?string $card): string
    {
        $d = static::digits($card);

        return $d ? trim(chunk_split($d, 4, '-'), '-') : '';
    }
}
