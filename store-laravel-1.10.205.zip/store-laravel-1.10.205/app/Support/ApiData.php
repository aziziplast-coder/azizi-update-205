<?php

namespace App\Support;

use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductCollection;
use App\Models\User;

/** شکل داده‌های API اپ موبایل (ثابت و سبک) */
class ApiData
{
    public static function img(?string $path, int $w = 480): ?string
    {
        $u = thumb($path, $w);

        return $u ? (preg_match('#^https?://#', $u) ? $u : url($u)) : null;
    }

    public static function file(?string $path): ?string
    {
        $u = upload_url($path);

        return $u ? (preg_match('#^https?://#', $u) ? $u : url($u)) : null;
    }

    /** کارت کالا در فهرست‌ها */
    public static function card(Product $p): array
    {
        $carton = $p->cartonAvailable();
        $retail = $p->retailAvailable();
        $badge = ProductCollection::badgeFor($p);

        return [
            'id' => $p->id,
            'name' => $p->name,
            'image' => static::img($p->image, 480),
            'price' => (int) $p->unitPrice(Product::CARTON),
            'compare' => $p->compare_price > $p->price ? (int) $p->compare_price : null,
            'discount' => $p->discountPercent(),
            'retail_price' => $p->retailAllowed() ? (int) $p->unitPrice(Product::RETAIL) : null,
            'per_carton' => (int) $p->per_carton,
            // قانون خرید عمده (اپ نسخه جدید): حداقل خرید و گام به عدد؛ کارتن کامل = هر دو برابر تعداد در کارتن
            'buy_min' => $p->buyRule()[0],
            'buy_step' => $p->buyRule()[1],
            'buy_note' => $p->buyRuleText(),
            'carton' => $carton,
            'retail' => $retail,
            'carton_max' => $carton ? $p->cartonMaxUnits() : 0,
            'retail_max' => $retail ? $p->retailMaxUnits() : 0,
            'available' => $carton || $retail,
            'badge' => $badge ? ['text' => (string) $badge['text'], 'color' => $badge['color'] ?? null] : null,
            'category' => $p->relationLoaded('category') ? $p->category?->name : null,
            // واحد فروش: «جفت»، «دست ۶ عددی» (جلوی قیمت: «هر جفت»)
            'unit' => $p->unitFull(),
            'unit_name' => $p->unitName(),
        ];
    }

    public static function cards($products): array
    {
        return collect($products)->map(fn (Product $p) => static::card($p))->values()->all();
    }

    /** صفحه کامل کالا */
    public static function product(Product $p): array
    {
        $specs = [];
        foreach ((array) $p->specs as $k => $v) {
            if (trim((string) $k) !== '' && trim((string) $v) !== '') {
                $specs[] = ['k' => (string) $k, 'v' => (string) $v];
            }
        }
        foreach ($p->attributeValues()->with('attribute')->get()->groupBy(fn ($v) => $v->attribute?->name) as $name => $vals) {
            if ($name) {
                $specs[] = ['k' => (string) $name, 'v' => $vals->pluck('value')->implode('، ')];
            }
        }
        $rating = $p->rating();

        return static::card($p) + [
            'images' => array_values(array_filter(array_map(fn ($i) => static::img($i, 960), $p->images()))),
            'zoom' => array_values(array_filter(array_map(fn ($i) => static::img($i, 1600), $p->images()))),
            'thumbs' => array_values(array_filter(array_map(fn ($i) => static::img($i, 160), $p->images()))),
            'short' => trim(strip_tags((string) $p->short_description)),
            'description' => static::text((string) $p->description),
            'specs' => $specs,
            'code' => $p->displayCode(),
            'rating' => $rating['avg'],
            'reviews' => $rating['count'],
            'url' => $p->url(),
            'category_id' => $p->category_id,
            'offer_ends_at' => $p->offerActive() && $p->offer_ends_at ? $p->offer_ends_at->toIso8601String() : null,
        ];
    }

    /** متن ساده از HTML (پاراگراف‌ها و فهرست‌ها حفظ می‌شود) */
    public static function text(string $html): string
    {
        $t = preg_replace(['#<br\s*/?>#i', '#</(p|div|h[1-6]|li|tr)>#i', '#<li[^>]*>#i'], ["\n", "\n", '• '], $html);
        $t = html_entity_decode(strip_tags((string) $t), ENT_QUOTES, 'UTF-8');

        return trim(preg_replace("/\n{3,}/", "\n\n", preg_replace('/[ \t]+/', ' ', $t)));
    }

    public static function category(Category $c, ?int $count = null): array
    {
        return [
            'id' => $c->id,
            'name' => $c->name,
            'icon' => static::img($c->iconPath(), 160),
            'image' => static::img($c->image ?: $c->iconPath(), 480),
            'count' => $count,
            'parent_id' => $c->parent_id,
        ];
    }

    public static function user(User $u): array
    {
        return [
            'id' => $u->id,
            'name' => (string) $u->name,
            'mobile' => (string) $u->mobile,
            'company' => (string) $u->company,
            'province' => (string) $u->province,
            'city' => (string) $u->city,
            'address' => (string) $u->address,
            'postal_code' => (string) $u->postal_code,
        ];
    }

    public static function orderSummary(Order $o): array
    {
        return [
            'number' => (string) $o->number,
            'date' => jdate($o->created_at, true),
            'status' => $o->status,
            'status_label' => $o->statusLabel(),
            'status_color' => Order::COLORS[$o->status] ?? 'gray',
            'fulfil_label' => $o->fulfilLabel(),
            'total' => (int) $o->total,
            'items' => (int) ($o->items_count ?? $o->items()->count()),
            'paid' => $o->isPaid(),
            'waybill' => (bool) $o->waybill_path,
        ] + static::journey($o);
    }

    /** مراحل سفارش و «الان نوبت چیست» (همان کارت سایت) */
    public static function journey(Order $o): array
    {
        $j = \App\Support\OrderJourney::for($o);
        $act = $j['action'];

        return [
            'action' => ['tone' => $act['tone'], 'icon' => $act['icon'], 'title' => $act['title'], 'text' => $act['text'], 'btn' => $act['btn'],
                'web' => $act['href'] && ! str_contains($act['href'], 'waybill')],
            'progress' => $j['pct'],
            'steps' => array_map(fn ($s) => ['label' => $s['label'], 'icon' => $s['icon'], 'state' => $s['state'], 'note' => (string) $s['note']], $j['steps']),
            'support_url' => $o->status === 'completed' ? \App\Support\OrderJourney::supportUrl() : '',
        ];
    }

    public static function order(Order $o): array
    {
        return static::orderSummary($o) + [
            'items_list' => $o->items->map(fn (OrderItem $i) => [
                'id' => $i->id,
                'product_id' => $i->product_id,
                'name' => $i->name,
                'image' => static::img($i->image, 160),
                'mode' => $i->mode,
                'units' => (int) $i->units,
                'qty' => $i->unitsLabel((int) $i->units),
                'ordered' => $i->ordered_units && (int) $i->ordered_units !== (int) $i->units ? $i->unitsLabel((int) $i->ordered_units) : null,
                'unit_price' => (int) $i->unit_price,
                'total' => (int) $i->total,
                'pick' => $i->pick_status,
                'pick_label' => $i->pick_status ? (OrderItem::PICK[$i->pick_status] ?? null) : null,
            ])->values()->all(),
            'items_total' => (int) $o->items_total,
            'discount' => (int) $o->coupon_discount,
            'shipping' => $o->shippingLabel(),
            'shipping_cost' => (int) $o->shipping_cost,
            'fees' => array_values((array) $o->fees),
            'payment' => (string) $o->payment_title,
            'payment_status' => (string) $o->payment_status,
            'address' => $o->fullAddress(),
            'receiver' => (string) $o->customer_name,
            'mobile' => (string) $o->mobile,
            'tracking' => (string) $o->tracking_code,
            'note' => (string) $o->note,
            'cancel_reason' => (string) ($o->cancel_reason ?? ''),
            // پرداخت به حساب حواله‌ها (بیعانه و تسویه)
            'payments' => \App\Models\RemitPayment::query()->with('remittance')->where('order_id', $o->id)->where('status', '!=', 'cancelled')->orderBy('id')->get()
                ->map(fn ($p) => [
                    'id' => $p->id, 'kind' => $p->kind, 'kind_label' => $p->kindLabel(), 'amount' => (int) $p->amount,
                    'status' => $p->status, 'status_label' => $p->statusLabel(), 'reject_reason' => (string) $p->reject_reason,
                    'holder' => $p->account()['holder'], 'bank' => $p->account()['bank'],
                    'card' => $p->account()['card'], 'sheba' => $p->account()['sheba'], 'bounce' => ! empty($p->bounce),
                    // ارسال فیش داخل اپ
                    'can_upload' => $p->payable(), 'files' => count($p->files()),
                ])->values()->all(),
            'can_replace' => $o->canReplace(),
            'replace_until' => $o->replace_until?->toIso8601String(),
            'can_edit' => $o->customerCanEdit(),
            'web' => route('order.show', $o->number),
            'freight_fee' => (int) $o->freight_fee,
            'extra_discount' => (int) $o->extra_discount,
            'waybill' => (bool) $o->waybill_path,
            'waybill_at' => $o->waybill_at ? jdate($o->waybill_at, true) : '',
            'cheques' => collect((array) (((array) $o->cheque)['settle'] ?? []))->map(fn ($c) => ['amount' => (int) $c['amount'], 'due' => (string) ($c['due_fa'] ?? ''), 'nid' => (string) ($c['nid'] ?? ''), 'name' => (string) ($c['name'] ?? ''),
                'cheque_st' => (string) ($c['docs']['cheque']['st'] ?? ''), 'sayad_st' => (string) ($c['docs']['sayad']['st'] ?? ''),
                'reason' => (string) collect((array) ($c['docs'] ?? []))->where('st', 'rejected')->pluck('reason')->filter()->implode('، '),
                'cheque_reason' => (string) ($c['docs']['cheque']['reason'] ?? ''), 'sayad_reason' => (string) ($c['docs']['sayad']['reason'] ?? '')])->values()->all(),
            'cash_amount' => (int) $o->cash_amount,
            'cheque_docs' => ! $o->cheques_received_at && \App\Services\Cheques::docsMissing($o),
            'cheque_docs_pending' => \App\Services\Cheques::docsPending($o),
            'payee' => (array) (((array) $o->cheque)['payee'] ?? []) ?: null,
            // فرم ارسال تصویر چک‌ها داخل اپ
            'cheque_form' => static::chequeForm($o),
        ];
    }

    protected static function chequeForm(Order $o): ?array
    {
        $ch = (array) $o->cheque;
        if (empty($ch['settle']) || ! \App\Services\Cheques::settleDocsNeeded($o)) {
            return null;
        }
        $cfg = \App\Services\Cheques::config();
        $post = (array) ($ch['post'] ?? []);

        return [
            'can_send' => ! $o->cheques_received_at && ! in_array($o->status, ['cancelled', 'failed', 'pending_payment'], true),
            'national_id' => (bool) $cfg['national_id'],
            'owner_nid' => (string) ($ch['owner_nid'] ?? ''),
            'post_st' => (string) ($post['st'] ?? ''),
            'post_reason' => (string) ($post['reason'] ?? ''),
            'note' => (string) ($cfg['sayad_note'] ?? ''),
            'received' => (bool) $o->cheques_received_at,
        ];
    }
}
