<?php

namespace App\Support;

use App\Models\Product;
use Illuminate\Database\Eloquent\Builder;

/**
 * تعیین تکلیف کالاهای ناموجودی که مدت زیادی (پیش‌فرض یک سال) نه قیمتشان عوض شده نه موجودی‌شان.
 *  - report: فقط فهرست و شمارش در «محصولات» (پیش‌فرض)
 *  - hide:   خودکار از سایت پنهان می‌شوند؛ صفحه‌شان با 301 به دسته می‌رود (سئو حفظ می‌شود). اطلاعات پاک نمی‌شود
 *            و اگر بعداً (اکسل/همگام‌سازی) دوباره موجود شوند، خودکار به سایت برمی‌گردند (review = stale).
 */
class StaleProducts
{
    public const ACTIONS = [
        'report' => 'فقط فهرست شوند (تصمیم با اپراتور)',
        'hide' => 'خودکار از سایت پنهان شوند (صفحه کالا به دسته‌اش منتقل می‌شود)',
    ];

    public static function cfg(): array
    {
        $c = (array) setting('stale_products', []);

        return [
            'months' => max(1, min(60, (int) ($c['months'] ?? 12))),
            'action' => isset(self::ACTIONS[$c['action'] ?? '']) ? $c['action'] : 'report',
        ];
    }

    public static function query(?int $months = null): Builder
    {
        $months ??= static::cfg()['months'];

        return Product::query()->whereRaw('NOT '.Product::AVAILABLE_SQL)->where(fn ($r) => $r->whereNull('review')->orWhere('review', 'stale'))
            ->where(fn ($q) => $q->where('changed_at', '<', now()->subMonths($months))->orWhere(fn ($w) => $w->whereNull('changed_at')->where('updated_at', '<', now()->subMonths($months))));
    }

    public static function count(): int
    {
        return (int) \Illuminate\Support\Facades\Cache::remember('stale.count', 600, fn () => static::query()->where('is_active', true)->count());
    }

    /** اجرای روزانه */
    public static function run(): int
    {
        $c = static::cfg();
        if ($c['action'] !== 'hide') {
            return 0;
        }
        $n = static::query()->where('is_active', true)->update(['is_active' => false, 'review' => 'stale', 'updated_at' => now()]);
        \Illuminate\Support\Facades\Cache::forget('stale.count');

        return $n;
    }
}
