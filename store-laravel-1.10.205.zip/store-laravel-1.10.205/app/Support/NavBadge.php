<?php

namespace App\Support;

use Illuminate\Support\Facades\Cache;
use Throwable;

/**
 * عدد کنار منوهای پنل: هر صفحه پنل همه این شمارش‌ها را لازم دارد؛ با کش کوتاه (برای هر کاربر)
 * به‌جای ده‌ها پرس‌وجو در هر کلیک، فقط هر چند ثانیه یک بار شمرده می‌شوند.
 */
class NavBadge
{
    public static function count(string $key, callable $fn, int $ttl = 20): ?string
    {
        try {
            $n = (int) Cache::remember('nav:'.$key.':'.(auth()->id() ?? 0), $ttl, fn () => (int) $fn());
        } catch (Throwable) {
            return null;
        }

        return $n ? fa($n) : null;
    }
}
