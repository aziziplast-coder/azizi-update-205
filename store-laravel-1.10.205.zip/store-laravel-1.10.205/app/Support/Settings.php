<?php

namespace App\Support;

use App\Models\Setting;
use Illuminate\Support\Facades\Cache;
use Throwable;

/**
 * تنظیمات فروشگاه (کلید/مقدار JSON در جدول settings) با کش فایل.
 */
class Settings
{
    protected static ?array $cache = null;

    public static function defaults(): array
    {
        return [
            // فروشگاه
            'store_name' => 'فروشگاه من',
            'store_tagline' => 'فروش عمده و خرده',
            'logo' => null,
            'favicon' => null,
            'phone' => '',
            'mobile' => '',
            'email' => '',
            'address' => '',
            'work_hours' => 'شنبه تا پنجشنبه ۹ تا ۱۸',
            'about' => 'فروش کارتنی برای همکاران و خرید تکی برای مصرف‌کننده، با ارسال به سراسر کشور.',
            'topbar_text' => 'ارسال به سراسر کشور · فروش عمده و کارتنی با بهترین قیمت',
            'instagram' => '',
            'telegram' => '',
            'whatsapp' => '',
            'eitaa' => '',

            // ظاهر
            'brand_color' => '#4f4a63',
            'font' => 'vazirmatn',
            'custom_font_regular' => null,
            'custom_font_bold' => null,
            'theme_mode' => 'toggle', // light | dark | toggle (پیش‌فرض روشن با دکمه) | auto
            'radius' => 16,

            // صفحه اصلی
            'hero_badge' => 'قیمت پخش برای همکاران',
            'hero_title' => 'خرید عمده، ساده و به‌صرفه',
            'hero_text' => 'کالا را کارتنی با قیمت پخش یا تکی به اندازه نیازتان بخرید.',
            'hero_button' => 'مشاهده محصولات',
            'hero_link' => '/shop',
            'hero_image' => null,
            'benefits' => ['ارسال به سراسر کشور', 'قیمت عمده کارتنی', 'امکان خرید تکی', 'تضمین اصالت کالا'],
            'promos' => [],
            'home_sections' => ['categories', 'sale', 'featured', 'newest', 'promos'],
            'home_products_count' => 8,

            // خرید و تسویه
            'min_order' => 0,
            'remit_reject_reasons' => "تصویر فیش ناخوانا است\nاطلاعات فیش ارسالی (مبلغ، تاریخ یا حساب مقصد) مغایرت دارد\nمبلغ واریزی کمتر از مبلغ اعلام‌شده است\nاین فیش قبلاً ثبت شده (تکراری)\nواریز به حساب دیگری انجام شده است",
            'checkout_note' => '',
            'shipping_methods' => [
                ['id' => 'freight', 'title' => 'باربری (پس‌کرایه)', 'desc' => 'کرایه باربری تا شهر شما هنگام تحویل پرداخت می‌شود.', 'cost' => 0, 'free_above' => 0, 'collect' => true, 'enabled' => true, 'freight' => true, 'inner_type' => 'fixed', 'inner_amount' => 0, 'inner_title' => 'ارسال تا باربری (درون‌شهری)', 'inner_max' => 0],
                ['id' => 'courier', 'title' => 'پیک', 'desc' => 'تحویل همان روز یا روز بعد (فقط داخل شهر)', 'cost' => 250000, 'free_above' => 0, 'collect' => false, 'enabled' => true],
                ['id' => 'post', 'title' => 'پست پیشتاز', 'desc' => '۳ تا ۵ روز کاری', 'cost' => 180000, 'free_above' => 0, 'collect' => false, 'enabled' => true],
                ['id' => 'pickup', 'title' => 'تحویل حضوری از انبار', 'desc' => 'هماهنگی تلفنی پیش از مراجعه', 'cost' => 0, 'free_above' => 0, 'collect' => false, 'enabled' => true],
            ],
            'pay_gateway' => ['enabled' => false, 'title' => 'پرداخت آنلاین (درگاه بانکی)', 'desc' => 'پرداخت با همه کارت‌های عضو شتاب', 'provider' => 'zarinpal', 'merchant' => '', 'sandbox' => false],
            'pay_card' => ['enabled' => true, 'title' => 'کارت به کارت', 'desc' => 'مبلغ را واریز کنید؛ سفارش پس از تأیید واریز ارسال می‌شود.', 'card_number' => '', 'holder' => '', 'bank' => '', 'sheba' => ''],
            'pay_offline' => ['enabled' => true, 'title' => 'چک / اعتباری / هنگام تحویل', 'desc' => 'برای همکاران؛ برای نحوه تسویه با شما تماس می‌گیریم.', 'options' => ['چک', 'اعتباری (همکاران)', 'پرداخت هنگام تحویل']],
            'pay_cheque' => [
                'enabled' => false,
                'title' => 'خرید چکی',
                'desc' => 'بخشی نقد و بخشی با چک صیادی ثبت‌شده در سامانه.',
                'audience' => 'approved', // approved: فقط مشتریان تأییدشده | all: همه
                'min_total' => 0,
                'first_order' => false,
                'docs' => 'image_or_sayad', // none | image_or_sayad | image | sayad | both
                'docs_for' => 'new', // new | all
                'national_id' => true,
                'review' => 'new', // off | new | all
                'reviewers' => [],
                'plans' => [
                    ['title' => 'نصف نقد، نصف یک چک ۲ ماهه', 'cash' => 50, 'count' => 1, 'first' => 60, 'interval' => 30, 'guarantee' => true],
                    ['title' => 'نصف نقد، نصف در ۳ چک ماهانه', 'cash' => 50, 'count' => 3, 'first' => 30, 'interval' => 30, 'guarantee' => true],
                ],
                'guarantee_text' => 'یک فقره چک ضمانت (بدون تاریخ یا به تاریخ آخرین چک) به مبلغ کل سفارش دریافت می‌شود و پس از وصول همه چک‌ها عودت داده می‌شود.',
                'sayad_note' => 'چک باید صیادی باشد و پیش از ثبت سفارش در سامانه صیاد (اپ بانک) به نام فروشگاه ثبت شده باشد تا قابل استعلام باشد.',
            ],
            'checkout_contacts' => [],
            'checkout_help_title' => 'سؤالی درباره پرداخت یا ارسال دارید؟',
            'fees' => [],
            'pending_cancel_minutes' => 60,

            // سبد خرید و سبدهای رها شده
            'cart_keep_days' => 90,
            'abandoned_after' => 60,
            'order_edit' => ['enabled' => true, 'statuses' => ['on_hold'], 'lock_on_view' => true],

            // شماره پیام‌رسان مشتری
            'messenger' => ['enabled' => false, 'app' => 'rubika', 'label' => 'شماره‌ای که در روبیکا دارید', 'help' => 'برای هماهنگی سفارش در روبیکا به شما پیام می‌دهیم.', 'required' => false, 'link' => ''],

            // خروجی JSON
            'feed' => ['enabled' => true, 'key' => '', 'fields' => ['id', 'name', 'url', 'code', 'barcode', 'price', 'compare_price', 'per_carton', 'in_stock', 'category', 'image'], 'markup' => 0, 'cache' => 10, 'only_active' => true],

            // ارسال خودکار به کانال‌ها
            'channels' => [],
            'channel_rules' => ['auto_new' => true, 'need_image' => true, 'need_stock' => true, 'per_hour' => 20, 'gap' => 2, 'quiet_from' => 0, 'quiet_to' => 7, 'button' => 'مشاهده و خرید', 'template' => "🛍 {name}\n\n💰 قیمت: {price} تومان{old_price_line}\n📦 {carton_line}\n🗂 {category}\n\n{short}\n\n🔗 {link}\n\n{hashtags}\n{shop}"],

            // فاکتور
            'invoice_title' => 'فاکتور فروش کالا',
            'order_prefix' => '',
            'economic_code' => '',
            'national_id' => '',
            'reg_number' => '',
            'postal_code' => '',
            'stamp' => null,
            'invoice_footer' => 'از خرید شما سپاسگزاریم.',
            'invoice_images' => true,
            'invoice_barcode' => true,
            'invoice_group_wh' => true,
            'keeper_prices' => true,

            // وضعیت فروشگاه
            'store_closed' => false,
            'closed_mode' => 'catalog', // catalog: نمایش کالا بدون خرید | full: صفحه بسته
            'closed_title' => 'فروشگاه موقتاً تعطیل است',
            'closed_message' => 'به‌زودی با کالاهای جدید برمی‌گردیم. برای سفارش تلفنی تماس بگیرید.',
            'reopen_at' => null,

            // نمادها
            'enamad_code' => '',
            'samandehi_code' => '',
            'badges' => [],

            // پیامک و ورود
            'sms_gateways' => [],
            'sms_events' => [],
            'admin_mobiles' => '',
            'login_mode' => 'otp', // otp | password | both
            'otp_length' => 5,
            'otp_ttl' => 180,
            'otp_resend' => 60,
            'webotp' => true,
            'sms_link' => 'short',

            // دکمه شناور پشتیبانی
            'support_enabled' => false,
            'support_position' => 'left',
            'support_title' => 'پشتیبانی و مشاوره خرید',
            'support_text' => '',
            'support_message' => 'سلام، درباره «{page}» سؤال دارم.',
            'support_contacts' => [],
            'support_pulse' => true,

            // هشدار سفارش
            'order_alert' => true,
            'order_sound' => 'chime',
            'order_repeat' => true,

            // سئو و PWA
            'seo_title' => '',
            'seo_description' => '',
            'head_code' => '',
            'footer_code' => '',
            'pwa_enabled' => true,
            'pwa_name' => '',
            'pwa_short_name' => '',
            'pwa_icon' => null,

            // صفحه اول (چیدمان کشیدنی؛ خالی = چیدمان پیش‌فرض)
            'home_blocks' => null,

            // فهرست کالاها و جستجو
            'shop_default_sort' => 'newest',
            'shop_per_page' => 24,
            'shop_out_mode' => 'last',      // last: ناموجودها انتهای فهرست | hide: فقط با تیک «نمایش ناموجودها»
            'url_style' => 'default',       // default | legacy (لینک‌های هم‌شکل سایت قبلی)
            'mobile_view' => 'list', // list | grid2 | grid4
            'desktop_cols' => 'auto',
            'search_synonyms' => "زیرسیگاری، جاسیگاری، زیر سیگاری\nجاپیازی، جای پیاز، سبد پیاز\nقندان، شکردان\nلیوان، ماگ\nبشقاب، دیس\nظرف، ظروف",
            'cart_single_mode' => true,
            'seo_auto' => true,              // پر کردن خودکار سئوی خالی کالاها و دسته‌ها
            'seo_auto_title' => '',
            'seo_auto_desc' => '',
            'checkout_fields' => [],         // name/company/province/city/address/postal_code/note => {mode, label}
            'checkout_extra' => [],          // [{label, type, required, options, help, enabled}]
            'shop_auto_pages' => 5,          // تا این صفحه کالاها خودکار بارگذاری می‌شوند، بعد شماره صفحه
            'retail_max_pct' => 50,          // سقف خرید تکی = این درصد از تعداد کارتن
            'single_as_retail' => true,     // کالای «تعداد در کارتن ۱» در سفارش خرده حساب شود
            'cart_notice' => 'toast',        // پیام افزودن به سبد: toast | sheet | none
            'cart_notice_seconds' => 3,

            // قوانین خرید
            'terms_enabled' => false,
            'terms_label' => 'قوانین و شرایط خرید را خواندم و می‌پذیرم.',
            'terms_text' => '<p>سفارش پس از تأیید واریز یا تماس کارشناس ارسال می‌شود.</p><p>کالای سالم و پلمپ تا ۷ روز قابل مرجوع است.</p>',

            // شگفت‌انگیز
            'amazing' => ['enabled' => true, 'title' => 'شگفت‌انگیز', 'subtitle' => 'تخفیف‌های ویژه امروز', 'mode' => 'auto', 'sort' => 'discount', 'limit' => 12, 'ends_at' => null, 'timer' => true, 'color' => '#e11d48', 'min_discount' => 0],

            // بازدیدهای اخیر
            'recent_enabled' => true,
            'recent_title' => 'بازدیدهای اخیر شما',
            'recent_limit' => 12,

            // پاپ‌آپ
            'popup' => ['enabled' => false, 'title' => '', 'text' => '', 'image' => null, 'button' => '', 'link' => '', 'delay' => 3, 'frequency' => 'session', 'days' => 1, 'pages' => 'all', 'audience' => 'all', 'starts_at' => null, 'ends_at' => null, 'version' => 1],

            // اعلان مرورگر
            'push_enabled' => false,
            'push_prompt' => true,
            'push_prompt_delay' => 20,
            'push_prompt_text' => 'از تخفیف‌ها و وضعیت سفارش‌تان باخبر شوید.',
            'push_order_status' => true,
            'push_staff_orders' => true,

            // پیگیری سفارش‌ها
            'followup_enabled' => true,
            'replace_enabled' => true,       // مشتری برای کالاهای حذف‌شده در انبار جایگزین انتخاب کند
            'replace_hours' => 6,            // مهلت انتخاب جایگزین / افزودن به بار (ساعت)
            'stock_unlimited' => true,       // کالای موجود = بی‌نهایت (بدون سقف تعداد)
            'pick_zero_stock' => true,       // کالای کسری/ناموجود در انبار، در سایت هم ناموجود شود
            'reorder_default' => true,
            'one_open_order' => true,        // تا سفارش باز دارد، سفارش جدید نزند (اپراتور برای هر سفارش می‌تواند اجازه بدهد)
            'open_statuses' => ['on_hold', 'processing', 'settling', 'to_freight'],       // دکمه «سفارش مجدد» در صفحه سفارش مشتری (برای هر سفارش قابل تغییر)
            'pick_paper' => true,            // انبارهای سرپرست‌دار: جمع‌آوری با فاکتور کاغذی (جمع‌کننده‌ها اپ ندارند)
            'keeper_app_name' => '',
            'support_rubika' => 'Plascoz',
            'followup_hours' => ['on_hold' => 2, 'processing' => 24, 'settling' => 24, 'to_freight' => 24, 'shipped' => 0],
            'followup_note' => true,

            // سئو پیشرفته
            'seo_title_product' => '{name} | {site}',
            'seo_title_category' => 'خرید {name} | {site}',
            'seo_title_post' => '{name} | {site}',
            'seo_og_image' => null,
            'seo_org_type' => 'Store',
            'seo_google_verify' => '',
            'seo_bing_verify' => '',
            'seo_noindex_search' => true,
            'seo_robots_extra' => '',
            'seo_breadcrumbs' => true,
            'blog_title' => 'مجله و مقالات',
            'blog_description' => '',
            'blog_per_page' => 12,

            // نشان روی تصاویر تأمین‌کننده
            'wm_enabled' => false,
            'wm_image' => null,
            'wm_sample' => null,
            'wm_x' => 0,
            'wm_y' => 86,
            'wm_w' => 42,
            'wm_h' => 14,
            'wm_cover' => '#ffffff',
            'wm_align' => 'start',
            'wm_padding' => 6,

            // پشتیبان‌گیری
            'backup_auto' => true,
            'backup_type' => 'db',
            'backup_keep' => 7,
            'backup_hour' => 3,
        ];
    }

    public static function all(): array
    {
        if (static::$cache !== null) {
            return static::$cache;
        }
        $saved = [];
        if (installed()) {
            try {
                $saved = Cache::rememberForever('settings.all', function () {
                    $out = [];
                    foreach (Setting::query()->get(['key', 'value']) as $row) {
                        $out[$row->key] = json_decode((string) $row->value, true);
                    }

                    return $out;
                });
            } catch (Throwable $e) {
                $saved = [];
            }
        }

        return static::$cache = array_merge(static::defaults(), $saved);
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $all = static::all();

        return array_key_exists($key, $all) && $all[$key] !== null ? $all[$key] : $default;
    }

    public static function set(array $values): void
    {
        foreach ($values as $key => $value) {
            Setting::query()->updateOrCreate(['key' => $key], ['value' => json_encode($value, JSON_UNESCAPED_UNICODE)]);
        }
        static::flush();
    }

    public static function flush(): void
    {
        static::$cache = null;
        Cache::forget('settings.all');
        Cache::forget('home.blocks');
        Cache::forget('api.home');
        \App\Http\Middleware\GuestPageCache::bump();
    }
}
