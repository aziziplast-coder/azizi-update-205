<?php

namespace App\Support;

use Throwable;

/**
 * فشرده‌سازی تصویر بدون افت کیفیت قابل‌دیدن:
 *  - ابعاد بزرگ‌تر از سقف (پیش‌فرض ۱۶۰۰ پیکسل) با نمونه‌برداری باکیفیت کوچک می‌شود (هرگز بزرگ نمی‌شود)
 *  - تصاویر بدون شفافیت: JPEG پیش‌رونده با کیفیت بالا (۸۸)
 *  - تصاویر شفاف: WebP با کیفیت بالا (یا PNG با بیشترین فشرده‌سازی)
 *  - اطلاعات اضافه (EXIF و…) حذف می‌شود
 *  - اگر نتیجه دست‌کم ۸٪ کوچک‌تر نشود، فایل اصلی بدون تغییر می‌ماند
 */
class ImageCompressor
{
    /** @return array{body: string, ext: string, before: int, after: int} */
    public static function compress(string $body, int $maxSide = 1600, int $quality = 88): array
    {
        $before = strlen($body);
        $info = @getimagesizefromstring($body);
        $origExt = match ($info[2] ?? 0) {
            IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif', default => 'jpg',
        };
        $keep = ['body' => $body, 'ext' => $origExt, 'before' => $before, 'after' => $before];
        if (! $info || ! function_exists('imagecreatefromstring')) {
            return $keep;
        }
        // GIF متحرک دست نمی‌خورد
        if ($info[2] === IMAGETYPE_GIF && substr_count($body, "\x21\xF9\x04") > 1) {
            return $keep;
        }
        [$w, $h] = $info;
        if ($w < 1 || $h < 1 || $w * $h > 40_000_000) {
            return $keep;
        }
        @ini_set('memory_limit', '512M');
        try {
            $im = @imagecreatefromstring($body);
            if (! $im) {
                return $keep;
            }
            if (! imageistruecolor($im)) {
                imagepalettetotruecolor($im);
            }
            $im = static::orient($im, $body, $info[2]);
            $w = imagesx($im);
            $h = imagesy($im);
            $alpha = $info[2] !== IMAGETYPE_JPEG && static::hasAlpha($im);

            $scale = $maxSide > 0 ? min(1, $maxSide / max($w, $h)) : 1;
            if ($scale < 1) {
                $nw = max(1, (int) round($w * $scale));
                $nh = max(1, (int) round($h * $scale));
                $dst = imagecreatetruecolor($nw, $nh);
                if ($alpha) {
                    imagealphablending($dst, false);
                    imagesavealpha($dst, true);
                    imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
                }
                imagecopyresampled($dst, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
                imagedestroy($im);
                $im = $dst;
            } elseif (! $alpha && $info[2] !== IMAGETYPE_JPEG) {
                // PNG/WebP بدون شفافیت روی زمینه سفید (برای JPEG)
                $dst = imagecreatetruecolor($w, $h);
                imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
                imagecopy($dst, $im, 0, 0, 0, 0, $w, $h);
                imagedestroy($im);
                $im = $dst;
            }

            ob_start();
            if ($alpha) {
                imagesavealpha($im, true);
                if (function_exists('imagewebp')) {
                    imagewebp($im, null, max(80, min(100, $quality + 2)));
                    $ext = 'webp';
                } else {
                    imagepng($im, null, 9);
                    $ext = 'png';
                }
            } else {
                imageinterlace($im, true); // JPEG پیش‌رونده: سریع‌تر نمایش داده می‌شود
                imagejpeg($im, null, max(75, min(95, $quality)));
                $ext = 'jpg';
            }
            $out = (string) ob_get_clean();
            imagedestroy($im);
        } catch (Throwable $e) {
            if (ob_get_level()) {
                @ob_end_clean();
            }
            report($e);

            return $keep;
        }
        // فقط اگر واقعاً سبک‌تر شد (یا ابعاد کوچک شد)
        if ($out === '' || (strlen($out) > $before * 0.92 && $scale >= 1)) {
            return $keep;
        }

        return ['body' => $out, 'ext' => $ext, 'before' => $before, 'after' => strlen($out)];
    }

    /** چرخش طبق EXIF (عکس‌های گوشی) */
    protected static function orient($im, string $body, int $type)
    {
        if ($type !== IMAGETYPE_JPEG || ! function_exists('exif_read_data')) {
            return $im;
        }
        try {
            $exif = @exif_read_data('data://image/jpeg;base64,'.base64_encode($body));
            $o = (int) ($exif['Orientation'] ?? 1);
            $deg = [3 => 180, 6 => -90, 8 => 90][$o] ?? 0;
            if ($deg) {
                $r = imagerotate($im, $deg, 0);
                if ($r) {
                    imagedestroy($im);

                    return $r;
                }
            }
        } catch (Throwable) {
        }

        return $im;
    }

    /** آیا پیکسل نیمه‌شفاف/شفاف دارد؟ (نمونه‌برداری شبکه‌ای) */
    protected static function hasAlpha($im): bool
    {
        $w = imagesx($im);
        $h = imagesy($im);
        $step = max(1, (int) floor(sqrt($w * $h / 40000)));
        for ($y = 0; $y < $h; $y += $step) {
            for ($x = 0; $x < $w; $x += $step) {
                if (((imagecolorat($im, $x, $y) >> 24) & 0x7F) > 0) {
                    return true;
                }
            }
        }

        return false;
    }
}
