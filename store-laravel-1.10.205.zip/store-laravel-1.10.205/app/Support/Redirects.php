<?php

namespace App\Support;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * ریدایرکت ۳۰۱ لینک‌های قدیمی (مقاله‌ها، صفحه‌ها و هر آدرس دیگر سایت قبلی) به صفحه تازه.
 * فقط وقتی اجرا می‌شود که آدرس در سایت پیدا نشود (۴۰۴)؛ پس هیچ صفحه موجودی را خراب نمی‌کند.
 */
class Redirects
{
    /** شکل یکسان آدرس: بدون دامنه، رمزگشایی‌شده، + و %20 = فاصله، بدون / پایانی */
    public static function norm(string $u): string
    {
        $p = parse_url(trim($u));
        $path = (string) ($p['path'] ?? $u);
        $path = urldecode(str_replace('+', ' ', $path));
        $path = '/'.trim(preg_replace('/\s+/u', ' ', $path), '/ ');
        $path = str_replace(['ي', 'ك'], ['ی', 'ک'], $path);

        return mb_strtolower($path);
    }

    public static function find(Request $request): ?string
    {
        try {
            $key = static::norm($request->getPathInfo());
            if ($key === '/') {
                return null;
            }
            if (\App\Support\DbSchema::hasTable('redirects')) {
                $row = DB::table('redirects')->where('from_hash', sha1($key))->first();
                if ($row) {
                    DB::table('redirects')->where('id', $row->id)->update(['hits' => DB::raw('hits + 1'), 'last_hit_at' => now()]);

                    return static::abs($row->to_url);
                }
            }
            // مقاله‌ای که «آدرس در سایت قبلی» دارد
            if (\App\Support\DbSchema::hasColumn('posts', 'legacy_path')) {
                $post = \App\Models\Post::query()->whereNotNull('legacy_path')->where('is_published', true)->get(['id', 'slug', 'legacy_path'])
                    ->first(fn ($p) => static::norm($p->legacy_path) === $key);
                if ($post) {
                    return route('blog.post', $post->slug);
                }
            }
        } catch (Throwable $e) {
            report($e);
        }

        return null;
    }

    public static function abs(string $to): string
    {
        return preg_match('#^https?://#i', $to) ? $to : url('/'.ltrim($to, '/'));
    }

    public static function put(string $from, string $to): bool
    {
        $key = static::norm($from);
        $to = trim($to);
        if ($key === '/' || $to === '' || static::norm($to) === $key) {
            return false;
        }
        DB::table('redirects')->updateOrInsert(['from_hash' => sha1($key)], ['from_path' => mb_substr($key, 0, 500), 'to_url' => mb_substr($to, 0, 1000), 'updated_at' => now(), 'created_at' => now()]);

        return true;
    }

    /** ورود از اکسل/CSV: ستون اول آدرس قدیم، ستون دوم آدرس جدید */
    public static function import(string $path, string $name): array
    {
        $ok = 0;
        $bad = 0;
        SheetReader::read($path, $name, function ($r) use (&$ok, &$bad) {
            $r = array_values((array) $r);
            $from = trim((string) ($r[0] ?? ''));
            $to = trim((string) ($r[1] ?? ''));
            if ($from === '' || $to === '' || ! (str_contains($from, '/') || str_contains($from, '.'))) {
                return;
            }
            static::put($from, $to) ? $ok++ : $bad++;
        });

        return ['ok' => $ok, 'bad' => $bad];
    }
}
