<?php

namespace App\Support;

/** راه‌های ارتباط با کارشناس/پشتیبانی برای دکمه شناور */
class Contact
{
    public static function types(): array
    {
        return [
            'whatsapp' => ['label' => 'واتس‌اپ', 'color' => '#25D366', 'hint' => 'شماره موبایل، مثلاً 09121234567'],
            'telegram' => ['label' => 'تلگرام', 'color' => '#229ED9', 'hint' => 'نام کاربری بدون @'],
            'eitaa' => ['label' => 'ایتا', 'color' => '#EF7F1A', 'hint' => 'نام کاربری ایتا'],
            'bale' => ['label' => 'بله', 'color' => '#2BB57F', 'hint' => 'نام کاربری بله'],
            'rubika' => ['label' => 'روبیکا', 'color' => '#7B3FE4', 'hint' => 'نام کاربری روبیکا'],
            'instagram' => ['label' => 'دایرکت اینستاگرام', 'color' => '#E1306C', 'hint' => 'نام کاربری بدون @'],
            'phone' => ['label' => 'تماس تلفنی', 'color' => '#2563EB', 'hint' => 'شماره تلفن یا موبایل'],
            'sms' => ['label' => 'پیامک', 'color' => '#0EA5E9', 'hint' => 'شماره موبایل'],
            'email' => ['label' => 'ایمیل', 'color' => '#64748B', 'hint' => 'آدرس ایمیل'],
            'link' => ['label' => 'گفتگوی آنلاین / لینک', 'color' => '#4F4A63', 'hint' => 'آدرس کامل، مثلاً لینک گفتینو یا صفحه چت'],
        ];
    }

    public static function url(string $type, string $value, string $message = ''): ?string
    {
        $v = trim(en_digits($value));
        if ($v === '') {
            return null;
        }
        $user = ltrim(preg_replace('#^https?://[^/]+/#i', '', $v), '@/');
        $intl = function (string $n) {
            $d = preg_replace('/\D/', '', $n);
            if (str_starts_with($d, '00')) {
                $d = substr($d, 2);
            } elseif (str_starts_with($d, '0')) {
                $d = '98'.substr($d, 1);
            }

            return $d;
        };

        return match ($type) {
            'whatsapp' => 'https://wa.me/'.$intl($v).($message !== '' ? '?text='.rawurlencode($message) : ''),
            'telegram' => preg_match('#^https?://#', $v) ? $v : 'https://t.me/'.$user,
            'eitaa' => preg_match('#^https?://#', $v) ? $v : 'https://eitaa.com/'.$user,
            'bale' => preg_match('#^https?://#', $v) ? $v : 'https://ble.ir/'.$user,
            'rubika' => preg_match('#^https?://#', $v) ? $v : 'https://rubika.ir/'.$user,
            'instagram' => preg_match('#^https?://#', $v) ? $v : 'https://ig.me/m/'.$user,
            'phone' => 'tel:'.preg_replace('/[^\d+]/', '', $v),
            'sms' => 'sms:'.preg_replace('/[^\d+]/', '', $v).($message !== '' ? '?body='.rawurlencode($message) : ''),
            'email' => 'mailto:'.$v,
            'link' => preg_match('#^https?://#', $v) ? $v : null,
            default => null,
        };
    }

    /** مخاطبان فعال و آماده نمایش */
    public static function items(): array
    {
        if (! setting('support_enabled')) {
            return [];
        }
        $types = static::types();
        $out = [];
        foreach ((array) setting('support_contacts', []) as $c) {
            $type = $c['type'] ?? '';
            if (empty($c['enabled']) || ! isset($types[$type])) {
                continue;
            }
            $url = static::url($type, (string) ($c['value'] ?? ''));
            if (! $url) {
                continue;
            }
            $out[] = [
                'type' => $type,
                'url' => $url,
                'label' => trim((string) ($c['label'] ?? '')) ?: $types[$type]['label'],
                'note' => trim((string) ($c['note'] ?? '')),
                'avatar' => $c['avatar'] ?? null,
                'color' => $types[$type]['color'],
                'value' => (string) ($c['value'] ?? ''),
                'external' => ! in_array($type, ['phone', 'sms', 'email'], true),
            ];
        }

        return $out;
    }
}
