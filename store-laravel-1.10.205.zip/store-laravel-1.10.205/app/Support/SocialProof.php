<?php

namespace App\Support;

use App\Models\Order;
use Illuminate\Support\Facades\Cache;

/**
 * پاپ‌آپ «خریدهای اخیر» (اثبات اجتماعی): بدون شماره، آدرس یا اطلاعات تماس مشتری؛
 * فقط نام (به شکل انتخابی)، شهر، کالاها و تعداد، جمع و شیوه پرداخت.
 */
class SocialProof
{
    public static function defaults(): array
    {
        return [
            'enabled' => false, 'first_delay' => 8, 'interval' => 25, 'duration' => 7, 'max' => 4,
            'days' => 7, 'count' => 15, 'min_total' => 0, 'name_style' => 'last', 'title' => 'auto',
            'show_items' => true, 'max_items' => 3, 'show_total' => true, 'show_payment' => true, 'show_time' => true,
            'position' => 'start', 'pages' => 'all', 'mobile' => true, 'statuses' => ['on_hold', 'processing', 'shipped', 'delivered', 'completed'],
        ];
    }

    public static function cfg(): array
    {
        return array_replace(static::defaults(), (array) setting('social_proof', []));
    }

    /** @return array<int, array> */
    public static function feed(): array
    {
        $c = static::cfg();
        if (empty($c['enabled'])) {
            return [];
        }

        return Cache::remember('social.proof', 300, function () use ($c) {
            $q = Order::query()->with('items')->where('created_at', '>=', now()->subDays(max(1, (int) $c['days'])))
                ->whereIn('status', (array) $c['statuses'] ?: ['processing'])->latest('id')->limit(max(1, min(50, (int) $c['count'])));
            if ((int) $c['min_total'] > 0) {
                $q->where('total', '>=', (int) $c['min_total']);
            }
            $out = [];
            foreach ($q->get() as $o) {
                $items = [];
                foreach ($o->items->take(max(1, (int) $c['max_items'])) as $it) {
                    $carton = ! ($it->mode === 'retail') && $it->per_carton > 1;
                    $items[] = [
                        'name' => \Illuminate\Support\Str::limit($it->name, 48),
                        'qty' => $carton ? fa(intdiv((int) $it->units, max(1, (int) $it->per_carton))).' کارتن' : fa((int) $it->units).' عدد',
                        'img' => $it->image ? thumb($it->image, 160) : null,
                    ];
                }
                $out[] = [
                    'who' => static::who((string) $o->customer_name, (string) $c['name_style'], (string) $c['title']),
                    'city' => (string) ($o->city ?: $o->province),
                    'items' => ! empty($c['show_items']) ? $items : [],
                    'more' => max(0, $o->items->count() - count($items)),
                    'total' => ! empty($c['show_total']) && $o->total > 0 ? money($o->total) : null,
                    'pay' => ! empty($c['show_payment']) ? static::payment($o) : null,
                    'ago' => ! empty($c['show_time']) ? static::ago($o->created_at) : null,
                    'img' => $items[0]['img'] ?? null,
                ];
            }

            return $out;
        });
    }

    protected static function who(string $name, string $style, string $title): string
    {
        $parts = preg_split('/\s+/u', trim($name)) ?: [];
        $last = (string) end($parts);
        $first = (string) ($parts[0] ?? '');
        $t = $title === 'none' ? '' : ($title === 'auto' ? '' : $title.' ');
        return match ($style) {
            'full' => $t.trim($name),
            'masked' => $t.mb_substr($last ?: $first, 0, 1).'***',
            'hidden' => 'یک مشتری',
            default => $t.($last ?: 'یک مشتری'),
        } ?: 'یک مشتری';
    }

    protected static function payment(Order $o): string
    {
        return match ($o->payment_method) {
            'cheque' => 'خرید چکی',
            'gateway' => 'پرداخت آنلاین',
            'card' => 'کارت به کارت',
            default => \Illuminate\Support\Str::limit((string) $o->payment_title, 30),
        };
    }

    protected static function ago($at): string
    {
        $m = (int) abs(now()->diffInMinutes($at));

        return $m < 60 ? fa(max(1, $m)).' دقیقه پیش' : ($m < 1440 ? fa(intdiv($m, 60)).' ساعت پیش' : fa(intdiv($m, 1440)).' روز پیش');
    }
}
