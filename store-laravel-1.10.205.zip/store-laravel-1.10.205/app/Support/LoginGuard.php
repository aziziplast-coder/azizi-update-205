<?php

namespace App\Support;

use Illuminate\Support\Facades\RateLimiter;

/**
 * جلوگیری از حدس زدن رمز: بعد از چند تلاش ناموفق برای یک شماره (از هر IP)
 * یا از یک IP (برای هر شماره)، ورود با رمز تا چند دقیقه بسته می‌شود.
 */
class LoginGuard
{
    public const MAX_PER_MOBILE = 8;

    public const MAX_PER_IP = 30;

    public const DECAY = 900; // ۱۵ دقیقه

    protected static function keys(string $scope, ?string $mobile): array
    {
        return ['lg:'.$scope.':m:'.sha1((string) $mobile), 'lg:'.$scope.':ip:'.sha1((string) request()->ip())];
    }

    /** پیام خطا اگر بسته است، وگرنه null */
    public static function blocked(string $scope, ?string $mobile): ?string
    {
        [$m, $ip] = static::keys($scope, $mobile);
        foreach ([[$m, self::MAX_PER_MOBILE], [$ip, self::MAX_PER_IP]] as [$k, $max]) {
            if (RateLimiter::tooManyAttempts($k, $max)) {
                $min = max(1, (int) ceil(RateLimiter::availableIn($k) / 60));

                return 'به دلیل تلاش‌های ناموفق زیاد، ورود با رمز تا '.fa($min).' دقیقه دیگر ممکن نیست. می‌توانید با کد پیامکی وارد شوید.';
            }
        }

        return null;
    }

    public static function fail(string $scope, ?string $mobile): void
    {
        foreach (static::keys($scope, $mobile) as $k) {
            RateLimiter::hit($k, self::DECAY);
        }
        usleep(400000);
    }

    public static function clear(string $scope, ?string $mobile): void
    {
        RateLimiter::clear(static::keys($scope, $mobile)[0]);
    }
}
