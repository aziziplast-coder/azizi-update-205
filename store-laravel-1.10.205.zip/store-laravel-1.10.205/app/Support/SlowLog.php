<?php

namespace App\Support;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Throwable;

/**
 * ثبت درخواست‌های کند (برای پیدا کردن علت کندی روی هاست):
 * زمان ساخت پاسخ و زمان کارهای بعد از پاسخ (پیامک، اعلان، کرون) جدا ثبت می‌شود.
 * در «سلامت هاست» نشان داده می‌شود.
 */
class SlowLog
{
    public const LIMIT_MS = 1500;

    protected static ?float $handled = null;

    protected static int $queries = 0;

    public static function boot(): void
    {
        try {
            \Illuminate\Support\Facades\DB::listen(function () {
                static::$queries++;
            });
        } catch (Throwable) {
        }
        app()->terminating(function () {
            static::finish();
        });
    }

    public static function handled(Request $r, Response $res): void
    {
        static::$handled = microtime(true);
        $ms = static::ms(static::$handled);
        $res->headers->set('Server-Timing', 'app;dur='.$ms);
    }

    /** پاسخ زودهنگام: بعد از فرستادن پاسخ، کارهای پس‌زمینه کاربر را منتظر نگه نمی‌دارد */
    public static function earlyFinish(): bool
    {
        return function_exists('fastcgi_finish_request') || function_exists('litespeed_finish_request');
    }

    protected static function ms(float $t): int
    {
        $start = defined('LARAVEL_START') ? LARAVEL_START : ($_SERVER['REQUEST_TIME_FLOAT'] ?? $t);

        return (int) round(($t - $start) * 1000);
    }

    protected static function finish(): void
    {
        try {
            $r = request();
            if (! static::$handled || ! $r) {
                return;
            }
            $resp = static::ms(static::$handled);
            $total = static::ms(microtime(true));
            $after = $total - $resp;
            // کاربر منتظر کارهای بعد از پاسخ هم می‌ماند اگر هاست «پاسخ زودهنگام» نداشته باشد
            $felt = static::earlyFinish() ? $resp : $total;
            if ($felt < static::LIMIT_MS) {
                return;
            }
            $line = json_encode([
                't' => now()->format('Y-m-d H:i:s'), 'm' => $r->method(), 'p' => mb_substr('/'.ltrim($r->path(), '/'), 0, 120),
                'ms' => $resp, 'after' => $after, 'q' => static::$queries, 'u' => auth()->id(), 'sapi' => PHP_SAPI,
            ], JSON_UNESCAPED_UNICODE);
            @file_put_contents(storage_path('logs/slow-'.now()->format('Y-m-d').'.log'), $line."\n", FILE_APPEND | LOCK_EX);
        } catch (Throwable) {
        }
    }

    /** آخرین درخواست‌های کند امروز و دیروز */
    public static function recent(int $n = 30): array
    {
        $rows = [];
        foreach ([now(), now()->subDay()] as $d) {
            $f = storage_path('logs/slow-'.$d->format('Y-m-d').'.log');
            if (is_file($f)) {
                foreach (array_reverse(file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: []) as $l) {
                    if ($x = json_decode($l, true)) {
                        $rows[] = $x;
                    }
                    if (count($rows) >= $n) {
                        return $rows;
                    }
                }
            }
        }

        return $rows;
    }
}
