<?php

namespace App\Support;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Throwable;

/**
 * خوددرمانی پایگاه داده: اگر بعد از به‌روزرسانی مایگریشنی اجرا نشده باقی مانده باشد
 * (مثلاً اجرای آن روی هاست قطع شده)، در نخستین درخواست خودکار اجرا می‌شود.
 * نتیجه برای هر نسخه/تعداد فایل یک‌بار کش می‌شود؛ هزینه عادی هر درخواست فقط خواندن یک کلید کش است.
 */
class SchemaGuard
{
    public static function key(): string
    {
        return 'schema_ok:'.config('store.version').':'.count(glob(database_path('migrations/*.php')) ?: []);
    }

    public static function check(): void
    {
        $key = static::key();
        if (Cache::get($key)) {
            return;
        }
        try {
            $pending = static::pending();
        } catch (Throwable) {
            return; // پایگاه داده در دسترس نیست
        }
        if (! $pending) {
            Cache::forever($key, 1);
            Cache::forget('schema_error');

            return;
        }
        $lock = Cache::lock('schema_migrate', 300);
        if (! $lock->get()) {
            return;
        }
        try {
            @set_time_limit(300);
            @ignore_user_abort(true);
            Artisan::call('migrate', ['--force' => true]);
            if (! static::pending()) {
                Cache::forever($key, 1);
                Cache::forget('schema_error');
                Settings::flush();
            }
        } catch (Throwable $e) {
            report($e);
            // تا ۱۰ دقیقه دوباره تلاش نشود؛ خطا در پنل نمایش داده می‌شود
            Cache::put('schema_error', mb_substr($e->getMessage(), 0, 600), 3600);
            Cache::put($key, 1, 600);
        } finally {
            $lock->release();
        }
    }

    /** نام مایگریشن‌هایی که هنوز اجرا نشده‌اند */
    public static function pending(): array
    {
        $files = array_map(fn ($f) => basename($f, '.php'), glob(database_path('migrations/*.php')) ?: []);
        $ran = DB::table('migrations')->pluck('migration')->all();

        return array_values(array_diff($files, $ran));
    }
}
