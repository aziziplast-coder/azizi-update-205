<?php

namespace App\Livewire;

use App\Models\SyncItem;
use App\Models\SyncSource;
use App\Services\Sync\SyncEngine;
use Filament\Notifications\Notification;
use Livewire\Attributes\On;
use Livewire\Component;
use Throwable;

/**
 * بخش وضعیت و پیشرفت همگام‌سازی، جدا از صفحه اصلی:
 * هر چند ثانیه فقط همین بخش کوچک تازه می‌شود (نه جدول بزرگ کالاها)، پس پنل هنگام اجرا کند نمی‌شود.
 */
class SyncStatus extends Component
{
    public int $sourceId;

    public bool $wasRunning = false;

    protected ?SyncSource $srcModel = null;

    public function mount(int $sourceId): void
    {
        $this->sourceId = $sourceId;
        $this->wasRunning = $this->src()->isRunning();
    }

    public function src(): SyncSource
    {
        return $this->srcModel ??= SyncSource::query()->findOrFail($this->sourceId);
    }

    #[On('sync-changed')]
    public function refreshStatus(): void
    {
        $this->srcModel = null;
        $this->wasRunning = $this->src()->isRunning();
    }

    public function startRun(bool $force = false): void
    {
        try {
            $r = SyncEngine::for($this->src())->queue($force);
            $this->srcModel = null;
            Notification::make()->success()->title($r === 'running' ? 'همگام‌سازی از قبل در حال اجراست' : 'اجرا آغاز شد')
                ->body('دریافت JSON و پردازش در پس‌زمینه سرور انجام می‌شود؛ می‌توانید صفحه را ببندید.')->send();
            $this->wasRunning = true;
        } catch (Throwable $e) {
            $this->srcModel = null;
            $this->src()->addLog('خطا: '.$e->getMessage(), 'error');
            $this->src()->save();
            Notification::make()->danger()->title('اجرا ممکن نشد')->body($e->getMessage())->persistent()->send();
        }
    }

    public function installCron(): void
    {
        $r = \App\Support\CronInstaller::install();
        Notification::make()->title($r['msg'])->{$r['ok'] ? 'success' : 'warning'}()->persistent()->send();
    }

    public function tick(): void
    {
        $this->srcModel = null;
        if ($this->src()->isRunning()) {
            // کار اصلی در پس‌زمینه (کارگر سرور یا کرون) انجام می‌شود؛ صفحه فقط وضعیت را نشان می‌دهد
            if (\App\Services\Sync\SyncWorker::alive()) {
                $st = (array) $this->src()->state;
            } elseif (\App\Services\Sync\SyncWorker::broken() && ! $this->hasCron()) {
                $st = SyncEngine::for($this->src())->step(6); // هاست درخواست داخلی را نمی‌پذیرد: صفحه باز کار را جلو می‌برد
            } else {
                \App\Services\Sync\SyncWorker::kick();
                $st = (array) $this->src()->state;
            }
            $this->srcModel = null;
            if (($st['status'] ?? '') !== 'running') {
                $this->wasRunning = false;
                $this->dispatch('sync-finished');
                $s = (array) $this->src()->stats;
                Notification::make()->success()->title('همگام‌سازی تمام شد')
                    ->body(fa($s['created'] ?? 0).' ساخته، '.fa($s['updated'] ?? 0).' به‌روز، '.fa($s['prices'] ?? 0).' تغییر قیمت')->send();
            }
        }
    }

    public function stopRun(): void
    {
        SyncEngine::for($this->src())->stop('اجرا توسط '.auth()->user()->displayName().' متوقف شد.');
        $this->srcModel = null;
        $this->wasRunning = false;
        $this->dispatch('sync-finished');
    }

    protected function hasCron(): bool
    {
        $cron = \Illuminate\Support\Facades\Cache::get('cron.cli');

        return $cron && \Illuminate\Support\Carbon::parse($cron)->gt(now()->subMinutes(3));
    }

    public function progress(): array
    {
        $st = (array) $this->src()->state;
        $running = ($st['status'] ?? '') === 'running';
        $pending = $running && ($st['phase'] ?? '') === 'images'
            ? SyncItem::query()->where('source_id', $this->src()->id)->whereIn('image_status', ['pending', 'gallery'])->count() : 0;
        $pct = 0;
        $label = '';
        if ($running) {
            if (($st['phase'] ?? '') === 'fetch') {
                $pct = 1;
                $label = 'در حال دریافت JSON از تأمین‌کننده…';
            } elseif ($st['phase'] === 'parse') {
                $size = max(1, (int) ($st['feed_size'] ?? 1));
                $pct = (int) round(min(1, ((int) ($st['feed_off'] ?? 0)) / $size) * 8);
                $label = 'خواندن JSON: '.fa($st['total']).' کالا خوانده شد';
            } elseif ($st['phase'] === 'products') {
                $pct = 8 + ($st['total'] ? (int) round($st['done'] * 77 / $st['total']) : 0);
                $label = 'پردازش کالاها: '.fa($st['done']).' از '.fa($st['total'])
                    .(! empty($st['cq_total']) ? ' — ساخت همراه تصویر: '.fa($st['cq_done'] ?? 0).' از '.fa($st['cq_total']) : '')
                    .' — تصاویر: '.fa($st['c']['images'] ?? 0);
            } elseif ($st['phase'] === 'images') {
                $done = (int) ($st['img_done'] ?? 0);
                $pct = 85 + (int) round(14 * $done / max(1, $done + $pending));
                $label = 'دانلود تصاویر: '.fa($done).' انجام، '.fa($pending).' مانده';
            } else {
                $pct = 99;
                $label = 'پایان کار…';
            }
        }

        // زمان سپری‌شده و تخمین زمان باقی‌مانده
        $eta = '';
        if ($running && ! empty($st['started'])) {
            $elapsed = max(1, (int) abs(now()->diffInSeconds(\Illuminate\Support\Carbon::parse($st['started']))));
            $left = null;
            if ($st['phase'] === 'products' && $st['done'] > 0) {
                // با در نظر گرفتن صف ساخت همراه تصویر
                $work = $st['done'] + (int) ($st['cq_done'] ?? 0);
                $rest = ($st['total'] - $st['done']) * (1 + (int) ($st['cq_total'] ?? 0) / max(1, $st['done'])) + max(0, (int) ($st['cq_total'] ?? 0) - (int) ($st['cq_done'] ?? 0));
                $left = $rest / max(0.01, $work / $elapsed);
            } elseif ($st['phase'] === 'images' && ($st['img_done'] ?? 0) > 0) {
                $left = $pending / max(0.01, $st['img_done'] / $elapsed);
            }
            $fmt = fn ($sec) => $sec >= 3600 ? fa(intdiv((int) $sec, 3600)).' ساعت و '.fa(intdiv((int) $sec % 3600, 60)).' دقیقه' : ($sec >= 60 ? fa((int) round($sec / 60)).' دقیقه' : fa((int) $sec).' ثانیه');
            $eta = 'سپری‌شده: '.$fmt($elapsed).($left !== null ? ' — باقی‌مانده تقریبی: '.$fmt($left) : '');
        }
        $cron = \Illuminate\Support\Facades\Cache::get('cron.cli');
        $hasCron = $cron && \Illuminate\Support\Carbon::parse($cron)->gt(now()->subMinutes(10));

        return ['running' => $running, 'pct' => $pct, 'label' => $label, 'c' => $st['c'] ?? [], 'mode' => $st['mode'] ?? 'full', 'eta' => $eta, 'cron' => $hasCron, 'total' => (int) ($st['total'] ?? 0),
            'worker' => \App\Services\Sync\SyncWorker::alive(), 'broken' => \App\Services\Sync\SyncWorker::broken()];
    }

    public function render()
    {
        return view('livewire.sync-status', ['s' => $this->src(), 'pg' => $this->progress()]);
    }
}
