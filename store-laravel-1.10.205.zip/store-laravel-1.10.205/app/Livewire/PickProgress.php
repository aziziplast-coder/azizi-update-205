<?php

namespace App\Livewire;

use App\Models\Order;
use App\Models\PickTask;
use App\Services\Picking;
use Filament\Notifications\Notification;
use Livewire\Component;

/** پیشرفت جمع‌آوری انبار در صفحه سفارش (برای واحد فروش / مسئول پیگیری) — زنده */
class PickProgress extends Component
{
    public int $orderId;

    public function mount(int $orderId): void
    {
        $this->orderId = $orderId;
    }

    protected function order(): Order
    {
        return Order::query()->findOrFail($this->orderId);
    }

    protected function canEdit(): bool
    {
        return (bool) auth()->user()?->hasPerm('orders_edit');
    }

    public function reopen(int $taskId): void
    {
        abort_unless($this->canEdit(), 403);
        $t = PickTask::query()->where('order_id', $this->orderId)->findOrFail($taskId);
        try {
            app(Picking::class)->reopen($t, auth()->user());
        } catch (\Illuminate\Validation\ValidationException $e) {
            Notification::make()->title(collect($e->errors())->flatten()->first())->danger()->send();

            return;
        }
        Notification::make()->title(Picking::deskChecked($t->fresh()) ? 'بررسی رومیزی دوباره باز شد؛ در صف «ویرایش پس از تأیید» همان سالن است.' : 'حواله بازگشایی شد؛ انباردار می‌تواند اصلاح کند.')->success()->send();
    }

    public function assign(int $taskId, $keeperId): void
    {
        abort_unless($this->canEdit(), 403);
        $t = PickTask::query()->where('order_id', $this->orderId)->findOrFail($taskId);
        $k = \App\Models\User::query()->where('role', 'keeper')->where('is_active', true)->find((int) $keeperId);
        if (! $k) {
            return;
        }
        $t->forceFill(['keeper_id' => $k->id, 'seen_at' => null])->save();
        $t->order->log('حواله به انباردار '.$k->displayName().' سپرده شد');
        app(\App\Services\WebPush::class)->toUsers([$k->id], ['title' => 'حواله جدید — سفارش '.fa($t->order->number), 'body' => $t->order->customer_name, 'url' => url('/keeper/task/'.$t->id)]);
        Notification::make()->title('حواله به '.$k->displayName().' سپرده شد.')->success()->send();
    }

    public function render()
    {
        $o = $this->order();
        $tasks = $o->pickTasks()->with(['keeper', 'items.warehouse', 'picker', 'checker'])->orderBy('round')->orderBy('id')->get();

        return view('livewire.pick-progress', [
            'order' => $o,
            'tasks' => $tasks,
            'keepers' => $tasks->contains(fn ($t) => ! $t->keeper_id || ! $t->keeper?->is_active) ? Picking::keepers() : collect(),
            'canEdit' => $this->canEdit(),
            'reps' => $o->replacements()->with('replaces')->whereIn('status', ['draft', 'submitted', 'approved', 'rejected'])->latest('id')->get(),
        ]);
    }
}
