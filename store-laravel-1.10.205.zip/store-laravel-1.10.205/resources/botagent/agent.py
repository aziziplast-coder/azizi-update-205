#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ربات کانال — برنامه کوچکِ روی هاست ربات
==========================================
همه تصمیم‌ها (کدام کالا ارسال/ویرایش/حذف شود، متن پست، ساعت خاموشی، روشن/خاموش) در پنل سایت گرفته می‌شود.
این برنامه هر دقیقه (با کرون) یک بار اجرا می‌شود:
  ۱) کارهای تازه را از سایت می‌گیرد،  ۲) در بله انجام می‌دهد،  ۳) نتیجه را به سایت می‌گوید و تمام می‌شود.

امنیت:
  • توکن ربات بله فقط در settings.env همین هاست است و هیچ‌وقت به سایت فرستاده نمی‌شود.
  • فقط به کانال‌هایی که در settings.env تعریف شده پست می‌دهد (حتی اگر سایت چیز دیگری بخواهد).
  • عکس‌ها فقط از نشانی همان سایت دانلود می‌شوند. ارتباط فقط با https و بررسی گواهی.
  • settings.env و پوشه برنامه فقط برای صاحب هاست قابل خواندن است (۶۰۰ / ۷۰۰).
  • بدون نیاز به نصب کتابخانه (فقط پایتون استاندارد). برای انتقال از ربات قبلی، اگر pymysql باشد استفاده می‌شود.
"""
import ast
import fcntl
import json
import logging
import logging.handlers
import os
import re
import signal
import socket
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

VERSION = "1.2.0"
BASE = os.path.dirname(os.path.abspath(__file__))
ENV_FILE = os.path.join(BASE, "settings.env")
STATE_FILE = os.path.join(BASE, "state.json")
LOCK_FILE = os.path.join(BASE, "agent.lock")
LOG_FILE = os.path.join(BASE, "agent.log")
RUN_SECONDS = 50          # هر اجرا حداکثر این‌قدر کار می‌کند (کرون دقیقه بعد دوباره اجرا می‌کند)
GAP = 1.2                 # فاصله بین درخواست‌ها به بله (جلوگیری از خطای «درخواست زیاد»)
BALE_API = "https://tapi.bale.ai/bot{token}/{method}"
TG_API = "https://api.telegram.org/bot{token}/{method}"
PLATFORMS = {"BALE": "bale", "TG": "telegram", "RUBIKA": "rubika"}
UA = "StoreBotAgent/" + VERSION

os.umask(0o077)
log = logging.getLogger("agent")
log.setLevel(logging.INFO)
_h = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=512 * 1024, backupCount=3, encoding="utf-8")
_h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%Y-%m-%d %H:%M:%S"))
log.addHandler(_h)
CTX = ssl.create_default_context()
REMOTE_LOG = []           # چند خطای مهم برای نمایش در پنل


def note(msg, remote=False):
    log.info(msg)
    if remote and len(REMOTE_LOG) < 10:
        REMOTE_LOG.append(str(msg)[:240])


# ─────────────────────────── تنظیمات ───────────────────────────

def read_env():
    env = {}
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    return env


def secure_files():
    for p, mode in ((BASE, 0o700), (ENV_FILE, 0o600), (STATE_FILE, 0o600), (LOG_FILE, 0o600)):
        try:
            if os.path.exists(p):
                os.chmod(p, mode)
        except OSError:
            pass


def append_env(lines):
    with open(ENV_FILE, "a", encoding="utf-8") as f:
        for l in lines:
            f.write(l + "\n")
    secure_files()


def chats_from_env(env):
    """BALE_<نام>=شناسه کانال|توکن  ·  TG_<نام>=شناسه کانال|توکن  ·  RUBIKA_<نام>=شناسه کانال|مسیر نشست rubpy"""
    out = {}
    for k, v in env.items():
        m = re.match(r"^(BALE|TG|RUBIKA)_([A-Za-z0-9_]+)$", k)
        if m and "|" in v:
            chat, token = v.split("|", 1)
            if chat.strip() and token.strip():
                out[m.group(2).lower()] = {"chat": chat.strip(), "token": token.strip(), "platform": PLATFORMS[m.group(1)]}
    return out


def load_state():
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(st):
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False)
    os.replace(tmp, STATE_FILE)
    secure_files()


# ─────────────────────────── ارتباط با سایت ───────────────────────────

class Site:
    def __init__(self, url, key):
        self.url = url.rstrip("/")
        self.key = key
        self.host = urllib.parse.urlparse(self.url).hostname

    def post(self, path, data, timeout=40):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(self.url + "/api/bot/v1/" + path, data=body, method="POST", headers={
            "Authorization": "Bearer " + self.key, "Content-Type": "application/json", "Accept": "application/json", "User-Agent": UA})
        with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
            return json.loads(r.read().decode("utf-8"))

    def image(self, url):
        u = urllib.parse.urlparse(url)
        if (u.scheme != "https" and os.environ.get("AGENT_TEST") != "1") or u.hostname != self.host:
            raise ValueError("عکس فقط از خود سایت (https)")
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=40, context=CTX) as r:
            data = r.read(15 * 1024 * 1024 + 1)
        if len(data) > 15 * 1024 * 1024 or len(data) < 200:
            raise ValueError("حجم عکس نامعتبر")
        return data


# ─────────────────────────── بله ───────────────────────────

class BaleError(Exception):
    def __init__(self, desc, code=0, retry=0):
        super().__init__(desc)
        self.desc = str(desc)
        self.code = code
        self.retry = retry

    @property
    def gone(self):
        d = self.desc.lower()
        return "not found" in d or "message_id_invalid" in d or "message to delete" in d or "message to edit" in d

    @property
    def same(self):
        return "not modified" in self.desc.lower()


def multipart(fields, files):
    b = "----agent" + uuid.uuid4().hex
    out = []
    for k, v in fields.items():
        if v is None:
            continue
        out.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n" % (b, k)).encode() + str(v).encode("utf-8") + b"\r\n")
    for k, (name, data) in files.items():
        out.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\nContent-Type: image/jpeg\r\n\r\n" % (b, k, name)).encode() + data + b"\r\n")
    out.append(("--%s--\r\n" % b).encode())
    return b"".join(out), "multipart/form-data; boundary=" + b


_last_call = [0.0]


def tg_html(t):
    """متن پست (با **پررنگ** و [لینک](نشانی)) ← HTML تلگرام"""
    t = str(t or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t, flags=re.S)
    t = re.sub(r"\[([^\]\n]+)\]\((https?://[^\s)]+)\)", lambda m: '<a href="%s">%s</a>' % (m.group(2).replace('"', "%22"), m.group(1)), t)
    return t


def api(ch, method, fields=None, files=None, _retry=True):
    """Bot API بله و تلگرام (یکسان)"""
    fields = dict(fields or {})
    if ch.get("platform") == "telegram":
        for k in ("text", "caption"):
            if k in fields and fields[k] is not None:
                fields[k] = tg_html(fields[k])
                fields["parse_mode"] = "HTML"
        if "media" in fields:
            media = json.loads(fields["media"])
            for m in media:
                if "caption" in m:
                    m["caption"] = tg_html(m["caption"])
                    m["parse_mode"] = "HTML"
            fields["media"] = json.dumps(media, ensure_ascii=False)
        base = os.environ.get("AGENT_TG_API") or TG_API
    else:
        base = os.environ.get("AGENT_BALE_API") or BALE_API
    return _call(base, ch["token"], method, fields, files, _retry)


def _call(base, token, method, fields, files, _retry=True):
    wait = GAP - (time.time() - _last_call[0])
    if wait > 0:
        time.sleep(wait)
    _last_call[0] = time.time()
    url = base.format(token=token, method=method)
    if files:
        body, ctype = multipart(fields or {}, files)
    else:
        body, ctype = json.dumps(fields or {}, ensure_ascii=False).encode("utf-8"), "application/json"
    req = urllib.request.Request(url, data=body, method="POST", headers={"Content-Type": ctype, "User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=90, context=CTX) as r:
            j = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            j = json.loads(e.read().decode("utf-8"))
        except Exception:
            raise BaleError("HTTP %s" % e.code, e.code)
    except (urllib.error.URLError, socket.timeout, ConnectionError) as e:
        raise BaleError("اتصال به پیام‌رسان برقرار نشد: %s" % getattr(e, "reason", e))
    if j.get("ok"):
        return j.get("result")
    code = int(j.get("error_code") or 0)
    retry = int((j.get("parameters") or {}).get("retry_after") or 0)
    if code == 429 and _retry and retry <= 15:
        time.sleep(max(1, retry))
        return _call(base, token, method, fields, files, False)
    raise BaleError(j.get("description") or ("خطای %s" % code), code, retry)


def markup(button):
    if not button or not button.get("url"):
        return None
    return json.dumps({"inline_keyboard": [[{"text": button.get("text") or "مشاهده", "url": button["url"]}]]}, ensure_ascii=False)


# ─────────────────────────── روبیکا (rubpy) ───────────────────────────
# با همان نشست حساب روبیکایی که ربات قبلی استفاده می‌کرد (فایل .rp روی همین هاست)

_rb_last = [0.0]


def rubika(ch, fn):
    try:
        import asyncio
        from rubpy import Client as RClient
    except ImportError:
        raise BaleError("کتابخانه rubpy روی این پایتون نیست (برنامه را با پایتونِ محیط ربات قبلی اجرا کنید)")
    wait = 3 - (time.time() - _rb_last[0])
    if wait > 0:
        time.sleep(wait)

    async def go():
        async with RClient(name=ch["token"]) as bot:
            return await fn(bot)
    try:
        return asyncio.run(go())
    except BaleError:
        raise
    except Exception as e:
        d = str(e) or e.__class__.__name__
        raise BaleError(("not found: " if "not" in d.lower() and "found" in d.lower() else "") + "روبیکا: " + d[:220])
    finally:
        _rb_last[0] = time.time()


def rb_send(site, ch, job):
    import tempfile
    text = job.get("text") or ""
    img = None
    for u in (job.get("images") or [])[:1]:
        try:
            img = site.image(u)
        except Exception as e:
            if not job.get("fallback"):
                raise BaleError("دانلود عکس نشد: %s" % e)
    if job.get("images") and not img and not job.get("fallback"):
        raise BaleError("عکس آماده نشد")
    path = None
    if img:
        fd, path = tempfile.mkstemp(suffix=".jpg", dir=BASE)
        with os.fdopen(fd, "wb") as f:
            f.write(img)
    try:
        if path:
            x = rubika(ch, lambda bot: bot.send_photo(ch["chat"], path, caption=text, parse_mode="Markdown"))
        else:
            x = rubika(ch, lambda bot: bot.send_message(ch["chat"], text, parse_mode="Markdown"))
    finally:
        if path:
            try:
                os.remove(path)
            except OSError:
                pass
    mid = getattr(x, "message_id", None) or (x.get("message_id") if isinstance(x, dict) else None)
    if not mid:
        raise BaleError("روبیکا شناسه پیام برنگرداند")
    return {"mid": str(mid), "kind": "photo" if path else "text"}


def rb_edit(ch, job):
    rubika(ch, lambda bot: bot.edit_message(ch["chat"], str(job["mid"]), job.get("text") or ""))
    return job.get("kind") if job.get("kind") in ("photo", "text") else None


def rb_delete(ch, job):
    try:
        rubika(ch, lambda bot: bot.delete_messages(ch["chat"], [str(job["mid"])]))
    except BaleError as e:
        if not e.gone:
            raise


# ─────────────────────────── انجام کارها ───────────────────────────

def do_send(site, ch, job):
    imgs = []
    err = None
    for u in job.get("images") or []:
        try:
            imgs.append(site.image(u))
        except Exception as e:
            err = "دانلود عکس نشد: %s" % e
    if job.get("images") and not imgs and not job.get("fallback"):
        raise BaleError(err or "عکس آماده نشد")   # پست بی‌عکس نمی‌رود؛ سایت بعداً دوباره می‌دهد
    text = job.get("text") or ""
    mk = markup(job.get("button"))
    if len(imgs) > 1:
        media = [{"type": "photo", "media": "attach://p%d" % i} for i in range(len(imgs))]
        media[0]["caption"] = text
        res = api(ch, "sendMediaGroup", {"chat_id": ch["chat"], "media": json.dumps(media, ensure_ascii=False)},
                   {"p%d" % i: ("photo%d.jpg" % i, d) for i, d in enumerate(imgs)})
        ids = [str(m.get("message_id")) for m in (res or [])]
        if not ids:
            raise BaleError("آلبوم ارسال نشد")
        return {"mid": ids[0], "extra": ids[1:], "kind": "album"}
    if imgs:
        res = api(ch, "sendPhoto", {"chat_id": ch["chat"], "caption": text, "reply_markup": mk}, {"photo": ("photo.jpg", imgs[0])})
        return {"mid": str(res.get("message_id")), "kind": "photo"}
    fields = {"chat_id": ch["chat"], "text": text}
    if mk:
        fields["reply_markup"] = json.loads(mk)
    res = api(ch, "sendMessage", fields)
    return {"mid": str(res.get("message_id")), "kind": "text"}


def do_delete(ch, job):
    first = None
    for mid in [job.get("mid")] + list(job.get("extra") or []):
        if not mid:
            continue
        try:
            api(ch, "deleteMessage", {"chat_id": ch["chat"], "message_id": int(mid)})
        except BaleError as e:
            if not e.gone and first is None:
                first = e
    if first:
        raise first


def do_edit(ch, job):
    text = job.get("text") or ""
    mk = markup(job.get("button"))
    mid = int(job["mid"])
    kind = job.get("kind") or "?"

    def cap():
        f = {"chat_id": ch["chat"], "message_id": mid, "caption": text}
        if kind != "album":
            f["reply_markup"] = json.loads(mk) if mk else {"inline_keyboard": []}
        api(ch, "editMessageCaption", f)

    def txt():
        f = {"chat_id": ch["chat"], "message_id": mid, "text": text}
        if mk:
            f["reply_markup"] = json.loads(mk)
        api(ch, "editMessageText", f)

    try:
        if kind == "text":
            txt()
            return "text"
        cap()
        return kind if kind in ("photo", "album") else "photo"
    except BaleError as e:
        if e.same:
            return kind if kind != "?" else None
        if e.gone and kind != "?":
            raise
        if kind in ("?", "photo") and not e.retry:
            # پست قدیمی بدون عکس بوده (کپشن ندارد) ← ویرایش متن
            try:
                txt()
                return "text"
            except BaleError as e2:
                if e2.same:
                    return "text"
                raise e2
        raise


def run_job(site, chats, job):
    r = {"id": job.get("id"), "op": job.get("op")}
    ch = chats.get(str(job.get("chat") or "").lower())
    if not ch:
        r.update(ok=False, error="این کانال روی هاست ربات تعریف نشده است")
        return r
    op = job.get("op")
    if ch.get("platform") == "rubika":
        return run_rubika(site, ch, job, r)
    try:
        if op == "delete":
            do_delete(ch, job)
            r["ok"] = True
        elif op == "announce":   # پیام دستی، خلاصه روزانه یا پیام آزمایشی از پنل
            r.update(do_send(site, ch, job))
            r["ok"] = True
        elif op in ("new", "repost"):
            if op == "repost" and job.get("mid"):
                try:
                    do_delete(ch, job)
                except BaleError:
                    pass
            r.update(do_send(site, ch, job))
            r["ok"] = True
        elif op == "edit":
            if not job.get("mid"):
                raise BaleError("شناسه پیام نیست", 400)
            k = do_edit(ch, job)
            r["ok"] = True
            if k:
                r["kind"] = k
            if job.get("notice"):   # «دوباره موجود شد» زیر همان پست
                try:
                    f = {"chat_id": ch["chat"], "text": job["notice"], "reply_to_message_id": int(job["mid"])}
                    mk = markup(job.get("button"))
                    if mk:
                        f["reply_markup"] = json.loads(mk)
                    api(ch, "sendMessage", f)
                    r["noticed"] = True
                except BaleError as e:
                    note("پیام «دوباره موجود شد» نرفت: %s" % e.desc)
        else:
            r.update(ok=False, error="کار ناشناخته")
            return r
        r["hash"] = job.get("hash")
        r["avail"] = job.get("avail")
        r["price"] = job.get("price")
    except BaleError as e:
        r.update(ok=False, error=e.desc[:280], gone=e.gone, retry_after=e.retry)
        r["avail"] = job.get("avail")
    except Exception as e:  # خطای پیش‌بینی‌نشده
        log.exception("job %s", job.get("id"))
        r.update(ok=False, error=str(e)[:280])
    return r


def run_rubika(site, ch, job, r):
    op = job.get("op")
    try:
        if op == "delete":
            rb_delete(ch, job)
        elif op in ("new", "repost", "announce"):
            if op == "repost" and job.get("mid"):
                try:
                    rb_delete(ch, job)
                except BaleError:
                    pass
            r.update(rb_send(site, ch, job))
        elif op == "edit":
            k = rb_edit(ch, job)
            if k:
                r["kind"] = k
            if job.get("notice"):
                try:
                    rubika(ch, lambda bot: bot.send_message(ch["chat"], job["notice"], reply_to_message_id=str(job["mid"])))
                    r["noticed"] = True
                except BaleError as e:
                    note("پیام «دوباره موجود شد» روبیکا نرفت: %s" % e.desc)
        else:
            r.update(ok=False, error="کار ناشناخته")
            return r
        r.update(ok=True, hash=job.get("hash"), avail=job.get("avail"), price=job.get("price"))
    except BaleError as e:
        r.update(ok=False, error=e.desc[:280], gone=e.gone, retry_after=e.retry, avail=job.get("avail"))
    except Exception as e:
        log.exception("rubika job %s", job.get("id"))
        r.update(ok=False, error=str(e)[:280])
    return r


# ─────────────────────────── انتقال از ربات قبلی ───────────────────────────

def _assigns(path):
    """مقدارهای ساده (رشته، عدد، دیکشنری) تعریف‌شده در یک فایل پایتون، بدون اجرای آن"""
    out = {}
    try:
        with open(path, encoding="utf-8") as f:
            tree = ast.parse(f.read())
    except Exception:
        return out
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                out.setdefault(node.targets[0].id, ast.literal_eval(node.value))
            except Exception:
                pass
    return out


def find_old_bots():
    home = os.path.expanduser("~")
    found = []
    for name in sorted(os.listdir(home)):
        d = os.path.join(home, name)
        if os.path.realpath(d) == os.path.realpath(BASE) or not os.path.isdir(d):
            continue
        if os.path.exists(os.path.join(d, "messengers.py")) and os.path.exists(os.path.join(d, "config.py")):
            found.append(d)
    return found


def find_tgrb_bots():
    """ربات تلگرام/روبیکای قبلی (main.py با telegram_sender یا rubika و دیتابیس SQLite محصولات)"""
    home = os.path.expanduser("~")
    found = []
    for name in sorted(os.listdir(home)):
        d = os.path.join(home, name)
        if os.path.realpath(d) == os.path.realpath(BASE) or not os.path.isdir(d):
            continue
        mp = os.path.join(d, "main.py")
        if os.path.exists(mp) and os.path.exists(os.path.join(d, "databases", "product.db")):
            try:
                src = open(mp, encoding="utf-8", errors="ignore").read()
            except OSError:
                continue
            if "telegram_sender" in src or "rubika_sender" in src:
                found.append(d)
    return found


def migrate_tgrb(site, env, d, new_env):
    import sqlite3
    a = _assigns(os.path.join(d, "main.py"))
    token, tg_chat, rb_chat = a.get("Token"), a.get("channel_id"), a.get("c")
    con = sqlite3.connect(os.path.join(d, "databases", "product.db"))
    rows = con.execute("SELECT id, telegram_id, rubika_id FROM product").fetchall()
    con.close()
    st_row = None
    if os.path.exists(os.path.join(d, "databases", "setting.db")):
        con = sqlite3.connect(os.path.join(d, "databases", "setting.db"))
        st_row = con.execute("SELECT time_send, rubika_text, telegram_text FROM setting LIMIT 1").fetchone()
        con.close()
    qf = qt = None
    if st_row and re.match(r"^\d{1,2}/\d{1,2}$", str(st_row[0] or "")):
        a0, b0 = str(st_row[0]).split("/")
        qf, qt = "%02d:00" % int(b0), "%02d:00" % int(a0)   # فقط بین این دو ساعت ارسال می‌کرد
    api_url = "jsonProducts.php"
    done = 0
    if token and tg_chat:
        foot = (st_row[2] if st_row else "") or ""
        h = re.search(r"t\.me/([A-Za-z0-9_]+)", foot)
        key = ("tg_" + (h.group(1) if h else "channel")).lower()[:30]
        posts = [[int(r[0]), str(r[1])] for r in rows if str(r[1]).isdigit()]
        res = site.post("import", {"old": {"key": key, "platform": "telegram", "name": "تلگرام " + ("@" + h.group(1) if h else str(tg_chat)), "chat_id": str(tg_chat),
                                           "api_url": api_url, "footer": foot, "promo": "", "album": False, "button": False, "wholesale": False,
                                           "quiet_from": qf, "quiet_to": qt, "posts": posts}}, timeout=180)
        note("ربات قبلی تلگرام (%s) ← کانال «%s» در پنل: %s پست قبلی ثبت شد" % (os.path.basename(d), key, res.get("posts")), True)
        if "TG_" + key not in env:
            new_env.append("TG_%s=%s|%s" % (key, tg_chat, token))
            env["TG_" + key] = "%s|%s" % (tg_chat, token)
        done += 1
    session = os.path.join(d, "rubpy")
    if rb_chat and os.path.exists(session + ".rp"):
        foot = (st_row[1] if st_row else "") or ""
        h = re.search(r"rubika\.ir/([A-Za-z0-9_]+)", foot)
        key = ("rb_" + (h.group(1) if h else "channel")).lower()[:30]
        posts = [[int(r[0]), str(r[2])] for r in rows if str(r[2]).isdigit()]
        res = site.post("import", {"old": {"key": key, "platform": "rubika", "name": "روبیکا " + ("@" + h.group(1) if h else ""), "chat_id": str(rb_chat),
                                           "api_url": api_url, "footer": foot, "promo": "", "album": False, "button": False, "wholesale": False,
                                           "quiet_from": qf, "quiet_to": qt, "posts": posts}}, timeout=180)
        note("ربات قبلی روبیکا (%s) ← کانال «%s» در پنل: %s پست قبلی ثبت شد" % (os.path.basename(d), key, res.get("posts")), True)
        if "RUBIKA_" + key not in env:
            new_env.append("RUBIKA_%s=%s|%s" % (key, rb_chat, session))
            env["RUBIKA_" + key] = "%s|%s" % (rb_chat, session)
        done += 1
    return done > 0


def stop_procs(d, script="main.py"):
    """پردازش‌های پایتونِ ربات قبلی در همان پوشه"""
    me = os.getpid()
    for pid in os.listdir("/proc"):
        if not pid.isdigit() or int(pid) == me:
            continue
        try:
            cmd = open("/proc/%s/cmdline" % pid, "rb").read().split(b"\0")
            cwd = os.readlink("/proc/%s/cwd" % pid)
        except OSError:
            continue
        if any(c.endswith(script.encode()) for c in cmd) and os.path.realpath(cwd) == os.path.realpath(d):
            try:
                os.kill(int(pid), signal.SIGTERM)
                note("ربات قبلی متوقف شد: %s (PID %s)" % (os.path.basename(d), pid))
            except OSError:
                pass


def old_db_rows(cfg):
    try:
        import pymysql
    except ImportError:
        raise RuntimeError("کتابخانه pymysql روی این پایتون نیست؛ برنامه را با پایتونِ محیط ربات قبلی اجرا کنید (راهنما)")
    c = dict(cfg)
    c.pop("autocommit", None)
    conn = pymysql.connect(host=c.get("host", "localhost"), port=int(c.get("port", 3306)), user=c["user"], password=c["password"],
                           database=c.get("db") or c.get("database"), charset="utf8mb4", connect_timeout=15)
    try:
        with conn.cursor() as cur:
            settings = None
            try:
                cur.execute("SELECT bale_text, downtime_start, downtime_end FROM settings LIMIT 1")
                settings = cur.fetchone()
            except Exception:
                pass
            cur.execute("SELECT product_id, message_id FROM messages WHERE platform = 'bale' ORDER BY id")
            rows = [[int(a), str(b)] for a, b in cur.fetchall() if a and b]
        return settings, rows
    finally:
        conn.close()


def stop_old(d):
    """ربات قبلی خاموش می‌شود تا دوباره پست تکراری نفرستد (فایل‌ها پاک نمی‌شوند، فقط نامشان .off می‌شود)"""
    for pf in ("bot.lock.d/pid", "sec_bot.lock.d/pid", "bot.pid"):
        p = os.path.join(d, pf)
        try:
            with open(p) as f:
                pid = int(f.read().strip())
            os.kill(pid, signal.SIGTERM)
            note("ربات قبلی متوقف شد: %s (PID %s)" % (os.path.basename(d), pid))
        except Exception:
            pass
    for s in ("main.py", "sec_bot.py", "watchdog.py"):
        p = os.path.join(d, s)
        if os.path.exists(p):
            try:
                os.replace(p, p + ".off")
            except OSError:
                pass


def disable_old_cron(dirs):
    try:
        cur = subprocess.run(["crontab", "-l"], capture_output=True, text=True, timeout=20)
        if cur.returncode != 0:
            return
        lines = cur.stdout.splitlines()
        with open(os.path.join(BASE, "crontab.backup"), "w", encoding="utf-8") as f:
            f.write(cur.stdout)
        names = [os.path.basename(d) for d in dirs]
        changed = False
        out = []
        for l in lines:
            if not l.lstrip().startswith("#") and any(("/" + n + " " in l or "/" + n + "/" in l or "/" + n + "&" in l) for n in names) and "botagent" not in l:
                out.append("# (خاموش شد توسط botagent) " + l)
                changed = True
            else:
                out.append(l)
        if changed:
            subprocess.run(["crontab", "-"], input="\n".join(out) + "\n", text=True, timeout=20)
            note("کرون ربات‌های قبلی خاموش شد (نسخه قبلی: crontab.backup)")
    except Exception as e:
        note("کرون تغییر نکرد: %s" % e)


def migrate(site, env, st):
    dirs = find_old_bots()
    tgrb = find_tgrb_bots()
    if not dirs and not tgrb:
        st["migrated"] = True
        return
    new_env = []
    done_dirs = []
    done_before0 = set(st.get("done") or [])
    for d in tgrb:
        if d in done_before0:
            continue
        try:
            if migrate_tgrb(site, env, d, new_env):
                done_dirs.append(d)
                st["done"] = sorted(done_before0 | set(done_dirs))
        except Exception as e:
            note("ربات قبلی %s منتقل نشد (دوباره امتحان می‌شود): %s" % (os.path.basename(d), e), True)
    dirs_all = [d for d in dirs + tgrb if d not in done_before0]
    done_before = set(st.get("done") or [])
    dirs = [d for d in dirs if d not in done_before]
    for d in dirs:
        m = _assigns(os.path.join(d, "messengers.py"))
        c = _assigns(os.path.join(d, "config.py"))
        b = _assigns(os.path.join(d, "bot.py"))
        token, chat = m.get("BALE_BOT_TOKEN"), str(m.get("BALE_CHANNEL_ID") or "")
        if not token or not chat:
            continue
        footer = b.get("fixed_footer") or ""
        settings, rows = (None, [])
        if isinstance(c.get("DB_CONFIG"), dict):
            try:
                settings, rows = old_db_rows(c["DB_CONFIG"])
            except Exception as e:
                # بدون فهرست پست‌های قبلی، همه کالاها دوباره ارسال می‌شدند؛ پس ربات قبلی فعلاً دست نمی‌خورد
                note("ربات قبلی %s منتقل نشد (دوباره امتحان می‌شود): %s" % (os.path.basename(d), e), True)
                continue
        promo = ""
        qf = qt = None
        src = open(os.path.join(d, "bot.py"), encoding="utf-8").read() if os.path.exists(os.path.join(d, "bot.py")) else ""
        if settings:
            # متن تنظیمات ربات قبلی فقط وقتی در پست می‌آمد که در کد استفاده شده بود
            if re.search(r"^\s*promo_text,", src, re.M):
                promo = settings[0] or ""
            qf, qt = (str(settings[1]) if settings[1] is not None else None), (str(settings[2]) if settings[2] is not None else None)
        handle = re.search(r"ble\.ir/([A-Za-z0-9_]+)", footer + "\n" + promo)
        key = re.sub(r"[^a-z0-9_]", "", (handle.group(1) if handle else os.path.basename(d)).lower())[:30] or "bot"
        msgr = open(os.path.join(d, "messengers.py"), encoding="utf-8").read()
        payload = {
            "key": key, "name": "کانال " + (("@" + handle.group(1)) if handle else os.path.basename(d)), "chat_id": chat,
            "api_url": str(c.get("API_BASE_URL") or ""), "footer": footer, "promo": promo,
            "album": "sendMediaGroup" in msgr, "button": "InlineKeyboardButton(" in msgr.split("def send_to_bale", 1)[-1][:1500],
            "wholesale": "available_wholesale" in src, "quiet_from": qf, "quiet_to": qt, "posts": rows,
        }
        res = site.post("import", {"old": payload}, timeout=120)
        note("ربات قبلی %s ← کانال «%s» در پنل: %s پست قبلی ثبت شد" % (os.path.basename(d), key, res.get("posts")), True)
        if "BALE_" + key not in env:
            new_env.append("BALE_%s=%s|%s" % (key, chat, token))
            env["BALE_" + key] = "%s|%s" % (chat, token)
        done_dirs.append(d)
        st["done"] = sorted(done_before | set(done_dirs))
    if len(done_dirs) < len(dirs_all):
        st["migrated"] = False
    if new_env:
        append_env(["# از ربات قبلی همین هاست (پس از عوض کردن توکن، همین‌جا جایگزین کنید)"] + new_env)
    for d in done_dirs:
        stop_old(d)
        stop_procs(d)
    if done_dirs:
        disable_old_cron(done_dirs)
    if len(done_dirs) == len(dirs_all):
        st["migrated"] = True


# ─────────────────────────── اجرای اصلی ───────────────────────────

def main():
    lock = open(LOCK_FILE, "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        return  # اجرای قبلی هنوز کار می‌کند
    secure_files()
    env = read_env()
    if not env.get("SITE_URL") or not env.get("AGENT_KEY"):
        note("settings.env ناقص است")
        return
    local = os.environ.get("AGENT_TEST") == "1" and env["SITE_URL"].startswith("http://127.0.0.1")
    if not env["SITE_URL"].startswith("https://") and not local:
        note("نشانی سایت باید https باشد")
        return
    site = Site(env["SITE_URL"], env["AGENT_KEY"])
    st = load_state()
    start = time.time()
    try:
        if env.get("MIGRATE_OLD", "1") == "1" and not st.get("migrated"):
            migrate(site, env, st)
            save_state(st)
        chats = chats_from_env(env)
        if not chats:
            note("هیچ کانالی در settings.env تعریف نشده است")
            return
        if time.time() - st.get("hello", 0) > 600:
            site.post("hello", {"version": VERSION, "chats": list(chats), "host": socket.gethostname(), "py": sys.version.split()[0]})
            st["hello"] = time.time()
            save_state(st)
        # نتیجه‌هایی که دفعه قبل به سایت نرسید (تا پست تکراری فرستاده نشود)
        results = list(st.get("pending") or [])
        while True:
            more = time.time() - start < RUN_SECONDS
            res = site.post("sync", {"version": VERSION, "chats": list(chats), "results": results, "log": REMOTE_LOG, "limit": 15 if more else 0})
            results, REMOTE_LOG[:] = [], []
            if st.get("pending"):
                st["pending"] = []
                save_state(st)
            jobs = (res.get("jobs") or []) if more else []
            if not jobs:
                break
            for job in jobs:
                results.append(run_job(site, chats, job))
                st["pending"] = results
                save_state(st)
                if time.time() - start > RUN_SECONDS + 5:
                    break
    except urllib.error.HTTPError as e:
        note("سایت پاسخ داد %s (%s)" % (e.code, "کلید اشتباه یا باطل شده" if e.code == 401 else e.reason))
    except Exception as e:
        note("اتصال به سایت نشد: %s" % e)


if __name__ == "__main__":
    main()
