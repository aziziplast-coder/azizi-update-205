@php
    $first = $pages[0];
    $docTitle = ! empty($repl) ? 'حواله کالاهای جایگزین‌شده سفارش '.$order->number : (count($pages) > 1 ? 'حواله‌های انبار سفارش '.$order->number : (($first['isSlip'] ? 'حواله انبار سفارش ' : 'فاکتور سفارش ').$order->number));
    $barcodeSvg = \App\Support\Barcode::svg((string) $order->number, 34, 1.15);
@endphp
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>{{ $docTitle }} | {{ store_name() }}</title>
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}">
<link rel="stylesheet" href="{{ asset('css/invoice.css') }}?v={{ @filemtime(public_path('css/invoice.css')) }}">
<style>:root{--ac:{{ setting('brand_color', '#4f4a63') }};--font:{!! \App\Support\Fonts::stack() !!}}</style>
</head>
<body class="iv-body">
<nav class="iv-bar" aria-label="ابزار فاکتور">
    <a class="iv-btn ghost" href="{{ $back }}">→ بازگشت</a>
    <b class="iv-bar-title">{{ $docTitle }}</b>
    <span class="iv-sp"></span>
    @if ($options)
        <div class="iv-seg" role="group" aria-label="نوع برگه">
            <a href="{{ route('admin.invoice', $order) }}" @class(['on' => $mode === ''])>{{ $role === 'keeper' ? 'اقلام انبار من' : 'فاکتور کامل' }}</a>
            @foreach ($options as $key => $label)
                <a href="{{ route('admin.invoice', [$order, 'wh' => $key]) }}" @class(['on' => $mode === (string) $key])>حواله {{ $label }}</a>
            @endforeach
            @if (count($options) > 1)
                <a href="{{ route('admin.invoice', [$order, 'wh' => 'all']) }}" @class(['on' => $mode === 'all'])>همه حواله‌ها</a>
            @endif
        </div>
    @endif
    @if (($replCount ?? 0) > 0)
        <a class="iv-btn ghost" href="{{ route('admin.invoice', [$order, 'wh' => 'repl']) }}" title="کالاهایی که مشتری به‌جای ناموجود/کسری انتخاب کرده؛ برای انبار سرپرست‌دار">🔁 چاپ جایگزین‌شده‌ها ({{ fa($replCount) }})</a>
    @endif
    <button type="button" class="iv-btn primary" onclick="window.print()" title="برای PDF در پنجره چاپ «ذخیره به‌صورت PDF» را بزنید">🖨 چاپ / PDF</button>
</nav>

<main class="iv-doc">
@foreach ($pages as $pg)
    @if ($pg['isSlip'])
        @include('invoice-slip', ['items' => $pg['items'], 'group' => $pg['group'] ?? null, 'wid' => (int) ($pg['scope'][0] ?? 0), 'barcodeSvg' => $barcodeSvg, 'pageNo' => $loop->iteration, 'pageCount' => $loop->count, 'repl' => $repl ?? false, 'replOf' => $replOf ?? []])
    @else
        @include('invoice-page', ['items' => $pg['items'], 'scope' => $pg['scope'], 'isSlip' => false, 'barcodeSvg' => $barcodeSvg])
    @endif
@endforeach
</main>
</body>
</html>
