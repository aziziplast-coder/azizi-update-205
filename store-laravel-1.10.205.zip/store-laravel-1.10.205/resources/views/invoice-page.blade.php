@php
    $sum = ['gross' => 0, 'discount' => 0, 'total' => 0, 'cartons' => 0, 'retail' => 0, 'qty' => 0];
    $whCounts = [];
    foreach ($items as $it) {
        $disc = $it->compare_price ? ($it->compare_price - $it->unit_price) * $it->units : 0;
        $sum['gross'] += $it->total + $disc;
        $sum['discount'] += $disc;
        $sum['total'] += $it->total;
        $sum['qty'] += $it->units;
        if ($it->isRetail() || $it->per_carton <= 1) { $sum['retail'] += $it->units; } else { $sum['cartons'] += $it->units / $it->per_carton; }
        $whCounts[$it->warehouse_id ?? 0] = ($whCounts[$it->warehouse_id ?? 0] ?? 0) + 1;
    }
    $multiWh = count($whCounts) > 1 && setting('invoice_group_wh', true);
    $prices = $showPrice && ! $isSlip;
    $showSub = $multiWh && $isSlip; // جمع فرعی هر انبار فقط در حواله؛ در فاکتور کامل نه
    $payable = $order->total;
    // نسخه ساده (چاپ از گفتگو): بدون عکس، بدون ستون تخفیف، بدون برچسب «کارتنی / خرید تکی»
    $plain = request()->boolean('plain') && ! $isSlip;
    $showImg = (bool) setting('invoice_images', true) && ! $plain;
    $showCode = (bool) setting('invoice_barcode', true);
    $pc = $prices ? ($plain ? 2 : 3) : 0;
    $cols = 4 + ($showCode ? 1 : 0) + $pc + ($isSlip ? 1 : 0);
    $whName = fn ($id) => optional($items->firstWhere('warehouse_id', $id)?->warehouse)->label() ?? 'بدون انبار';
    $paid = $order->isPaid();
    $sellerIds = array_filter([
        'کد اقتصادی' => setting('economic_code') ? fa(setting('economic_code')) : null,
        'شناسه ملی' => setting('national_id') ? fa(setting('national_id')) : null,
        'شماره ثبت' => setting('reg_number') ? fa(setting('reg_number')) : null,
        'کد پستی' => setting('postal_code') ? fa(setting('postal_code')) : null,
    ]);
@endphp
<article @class(['iv-page', 'is-slip' => $isSlip])>
    {{-- سربرگ --}}
    <header class="iv-head">
        <div class="iv-store">
            @if (setting('logo'))<img class="iv-logo" src="{{ upload_url(setting('logo')) }}" alt="">@else<span class="iv-mono">{{ mb_substr(store_name(), 0, 1) }}</span>@endif
            <div>
                <b class="iv-store-name">{{ store_name() }}</b>
                @if (setting('store_tagline'))<span class="iv-tag">{{ setting('store_tagline') }}</span>@endif
            </div>
        </div>
        <div class="iv-title">
            <h1>{{ $isSlip ? 'حواله خروج انبار' : setting('invoice_title', 'فاکتور فروش کالا') }}</h1>
            @if ($isSlip)
                <span class="iv-wh">{{ implode('، ', array_map(fn ($id) => $whName($id), (array) $scope)) }} — {{ fa($items->count()) }} از {{ fa($order->items->count()) }} قلم</span>
            @else
                <span class="iv-sub">{{ $paid ? 'پرداخت شده' : 'صورتحساب فروش' }}</span>
            @endif
        </div>
        <div class="iv-meta">
            <div class="iv-meta-row"><span>شماره</span><b>{{ fa($order->number) }}</b></div>
            <div class="iv-meta-row"><span>تاریخ</span><b>{{ jdate($order->created_at) }}</b></div>
            <div class="iv-meta-row"><span>ساعت</span><b>{{ fa($order->created_at->setTimezone(config('app.timezone'))->format('H:i')) }}</b></div>
            @if ($barcodeSvg)<div class="iv-barcode">{!! $barcodeSvg !!}</div>@endif
        </div>
    </header>

    {{-- طرفین --}}
    <section class="iv-parties">
        <div class="iv-party">
            <h2>فروشنده</h2>
            <dl>
                <div class="w"><dt>نام</dt><dd>{{ store_name() }}</dd></div>
                @foreach ($sellerIds as $l => $v)<div><dt>{{ $l }}</dt><dd>{{ $v }}</dd></div>@endforeach
                @if (setting('phone') || setting('mobile'))<div><dt>تلفن</dt><dd class="num">{{ fa(setting('phone') ?: setting('mobile')) }}</dd></div>@endif
                @if (setting('address'))<div class="w"><dt>نشانی</dt><dd>{{ setting('address') }}</dd></div>@endif
            </dl>
        </div>
        <div class="iv-party">
            <h2>خریدار</h2>
            <dl>
                <div class="w"><dt>نام</dt><dd><b>{{ $order->customer_name }}</b>@if ($order->company) — {{ $order->company }}@endif</dd></div>
                <div><dt>موبایل</dt><dd class="num">{{ fa($order->mobile) }}</dd></div>
                @if ($order->messenger && $order->messenger !== $order->mobile)<div><dt>پیام‌رسان</dt><dd class="num">{{ fa($order->messenger) }}</dd></div>@endif
                @if ($order->postal_code)<div><dt>کد پستی</dt><dd class="num">{{ fa($order->postal_code) }}</dd></div>@endif
                <div class="w"><dt>نشانی</dt><dd>{{ fa($order->fullAddress()) }}</dd></div>
            </dl>
        </div>
    </section>

    {{-- ارسال و تسویه --}}
    <section class="iv-strip">
        <div><span>شیوه ارسال</span><b>{{ $order->shipping_title ?: '—' }}</b></div>
        @if ($order->freight_name)<div><span>باربری</span><b>{{ $order->freight_name }}</b></div>@endif
        @foreach ((array) $order->custom_fields as $cfk => $cfv)<div><span>{{ $cfk }}</span><b>{{ $cfv }}</b></div>@endforeach
        @if ($order->tracking_code)<div><span>کد رهگیری / بارنامه</span><b class="num">{{ fa($order->tracking_code) }}</b></div>@endif
        @unless ($isSlip)
            <div><span>شیوه تسویه</span><b>{{ $order->payment_title ?: '—' }}</b></div>
            <div><span>وضعیت پرداخت</span><b @class(['ok' => $paid, 'due' => ! $paid])>{{ $paid ? 'پرداخت شده' : 'پرداخت نشده' }}</b>@if ($order->payment_ref)<span class="num">پیگیری: {{ fa($order->payment_ref) }}</span>@endif</div>
        @else
            <div><span>وضعیت سفارش</span><b>{{ $order->statusLabel() }}</b></div>
        @endunless
    </section>

    {{-- اقلام --}}
    <table class="iv-table">
        <colgroup>
            <col class="c-n">
            @if ($showCode)<col class="c-code">@endif
            <col class="c-desc">
            <col class="c-pack">
            <col class="c-qty">
            @if ($prices)<col class="c-money">@unless ($plain)<col class="c-money c-disc">@endunless<col class="c-money c-total">@endif
            @if ($isSlip)<col class="c-chk">@endif
        </colgroup>
        <thead>
            <tr>
                <th>#</th>
                @if ($showCode)<th>بارکد</th>@endif
                <th class="l">شرح کالا</th>
                <th>بسته‌بندی</th>
                <th>تعداد</th>
                @if ($prices)<th>فی (تومان)</th>@unless ($plain)<th>تخفیف</th>@endunless<th>مبلغ (تومان)</th>@endif
                @if ($isSlip)<th>✓</th>@endif
            </tr>
        </thead>
        <tbody>
        @php $n = 0; $curWh = false; $grp = null; @endphp
        @foreach ($items as $it)
            @php $wid = $it->warehouse_id ?? 0; @endphp
            @if ($multiWh && $curWh !== $wid)
                @if ($grp && $showSub)
                    <tr class="iv-subt"><td colspan="{{ $cols - $pc - ($isSlip ? 1 : 0) - 1 }}">جمع {{ $whName($curWh) }}</td><td class="num">{{ fa($grp['qty']) }}</td>@if ($prices)<td></td>@unless ($plain)<td class="num">{{ $grp['discount'] ? money($grp['discount']) : '' }}</td>@endunless<td class="num">{{ money($grp['total']) }}</td>@endif @if ($isSlip)<td></td>@endif</tr>
                @endif
                @php $curWh = $wid; $grp = ['qty' => 0, 'discount' => 0, 'total' => 0]; @endphp
                <tr class="iv-grp"><td colspan="{{ $cols }}"><span>📦 {{ $whName($wid) }}</span> <small>{{ fa($whCounts[$wid]) }} قلم</small></td></tr>
            @endif
            @php
                $disc = $it->compare_price ? ($it->compare_price - $it->unit_price) * $it->units : 0;
                if ($grp) { $grp['qty'] += $it->units; $grp['discount'] += $disc; $grp['total'] += $it->total; }
                $carton = ! $it->isRetail() && $it->per_carton > 1;
            @endphp
            <tr @class(['is-retail' => $it->isRetail()])>
                <td class="num c">{{ fa(++$n) }}</td>
                @if ($showCode)<td class="code" data-label="بارکد">{{ $it->code() ?: '—' }}</td>@endif
                <td class="l">
                    <div class="iv-item">
                        @if ($showImg && $it->image)<img src="{{ thumb($it->image, 64) }}" alt="" loading="lazy">@endif
                        <div>
                            <b>{{ $it->name }}</b>
                            @unless ($plain)<span class="iv-mode {{ $it->isRetail() ? 'r' : ($carton ? 'k' : '') }}">{{ $it->isRetail() ? 'خرید تکی' : ($carton ? 'کارتنی' : 'عددی') }}</span>@endunless@if (! empty($it->appendix) && ! $plain)<span class="iv-mode iv-app">📎 پیوست{{ $it->replaces_item_id ? ' (جایگزین)' : '' }}</span>@endif
                        </div>
                    </div>
                </td>
                <td class="c" data-label="بسته‌بندی">{{ $carton ? fa($it->cartons()).' کارتن × '.fa($it->per_carton) : ($it->isRetail() ? 'کمتر از کارتن' : '—') }}</td>
                <td class="num c strong" data-label="تعداد">{{ fa($it->units) }}</td>
                @if ($prices)
                    <td class="num" data-label="فی">{{ money($it->unit_price) }}@if ($it->compare_price && ! $plain)<s>{{ money($it->compare_price) }}</s>@endif</td>
                    @unless ($plain)<td class="num muted" data-label="تخفیف">{{ $disc ? money($disc) : '—' }}</td>@endunless
                    <td class="num strong" data-label="مبلغ">{{ money($it->total) }}</td>
                @endif
                @if ($isSlip)<td class="c" data-label="برداشت شد"><span class="iv-box"></span></td>@endif
            </tr>
        @endforeach
        @if ($showSub && $grp)
            <tr class="iv-subt"><td colspan="{{ $cols - $pc - ($isSlip ? 1 : 0) - 1 }}">جمع {{ $whName($curWh) }}</td><td class="num">{{ fa($grp['qty']) }}</td>@if ($prices)<td></td>@unless ($plain)<td class="num">{{ $grp['discount'] ? money($grp['discount']) : '' }}</td>@endunless<td class="num">{{ money($grp['total']) }}</td>@endif @if ($isSlip)<td></td>@endif</tr>
        @endif
        </tbody>
        <tfoot>
            <tr>
                <td colspan="{{ $cols - $pc - ($isSlip ? 1 : 0) - 1 }}">{{ fa($items->count()) }} قلم، {{ fa(round($sum['cartons'], 2)) }} کارتن@if ($sum['retail'])، {{ fa($sum['retail']) }} عدد تکی/عددی@endif</td>
                <td class="num c">{{ fa($sum['qty']) }}</td>
                @if ($prices)<td></td>@unless ($plain)<td class="num">{{ $sum['discount'] ? money($sum['discount']) : '' }}</td>@endunless<td class="num">{{ money($sum['total']) }}</td>@endif
                @if ($isSlip)<td></td>@endif
            </tr>
        </tfoot>
    </table>

    {{-- جمع و توضیحات --}}
    <section class="iv-bottom">
        <div class="iv-notes">
            @if ($prices)
                <div class="iv-words"><span>مبلغ قابل پرداخت به حروف</span><b>{{ num_words($payable) }} تومان</b></div>
            @endif
            @if (! $isSlip && $order->cheque)
                <div class="iv-cheque">
                    <span>شرایط پرداخت چکی: <b>{{ $order->cheque['plan'] ?? '' }}</b></span>
                    <table>
                        <tr><td>نقد</td><td class="num">{{ money($order->cheque['cash'] ?? 0) }}</td><td></td></tr>
                        @foreach ((array) ($order->cheque['cheques'] ?? []) as $i => $c)
                            <tr><td>چک {{ fa($i + 1) }}</td><td class="num">{{ money($c['amount']) }}</td><td>سررسید {{ $c['due_fa'] ?? '' }}</td></tr>
                        @endforeach
                        @if (! empty($order->cheque['guarantee']))<tr><td>چک ضمانت</td><td class="num">{{ money($order->cheque['guarantee']) }}</td><td>عودت پس از تسویه</td></tr>@endif
                    </table>
                </div>
            @endif
            @if ($order->note)
                <div class="iv-note"><span>توضیح مشتری</span>{{ $order->note }}</div>
            @endif
            @if ($isSlip)
                <div class="iv-note"><span>یادآوری</span>پس از برداشت هر قلم، خانه ✓ را علامت بزنید. تعداد را با بسته‌بندی کنترل کنید.</div>
            @endif
        </div>
        @if ($prices)
            <dl class="iv-totals">
                <div><dt>جمع کالاها</dt><dd class="num">{{ money($sum['gross']) }}</dd></div>
                @if ($sum['discount'] > 0)<div class="neg"><dt>تخفیف کالاها</dt><dd class="num">− {{ money($sum['discount']) }}</dd></div>@endif
                @if ($order->coupon_discount)<div class="neg"><dt>کد تخفیف {{ $order->coupon_code }}</dt><dd class="num">− {{ money($order->coupon_discount) }}</dd></div>@endif
                <div><dt>ارسال</dt><dd>{{ $order->shippingLabel() }}</dd></div>
                @if ($order->freight_fee)<div><dt>کرایه حمل تا باربری</dt><dd class="num">{{ money($order->freight_fee) }}</dd></div>@endif
                @if ($order->extra_discount)<div class="neg"><dt>تخفیف</dt><dd class="num">− {{ money($order->extra_discount) }}</dd></div>@endif
                @foreach ((array) $order->fees as $fee)
                    <div><dt>{{ $fee['title'] }}</dt><dd class="num">{{ money($fee['amount']) }}</dd></div>
                @endforeach
                <div class="grand"><dt>مبلغ قابل پرداخت</dt><dd class="num">{{ money($payable) }} <small>تومان</small></dd></div>
            </dl>
        @endif
    </section>

    {{-- امضا --}}
    <section class="iv-sign">
        @if ($isSlip)
            <div><span>تحویل‌دهنده (انباردار)</span></div>
            <div><span>کنترل و بسته‌بندی</span></div>
            <div><span>تحویل‌گیرنده / راننده</span></div>
        @else
            <div><span>مهر و امضای فروشنده</span>@if (setting('stamp'))<img src="{{ upload_url(setting('stamp')) }}" alt="">@endif</div>
            <div><span>امضای خریدار</span></div>
        @endif
    </section>

    <footer class="iv-foot">
        <span>{{ setting('invoice_footer') }}</span>
        <span>{{ store_name() }}@if (setting('phone')) | <span class="num">{{ fa(setting('phone')) }}</span>@endif | {{ parse_url(config('app.url'), PHP_URL_HOST) }} | چاپ {{ jdate(now(), true) }}</span>
    </footer>
</article>
