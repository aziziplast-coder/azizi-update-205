<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>نصب فروشگاه</title>
<meta name="robots" content="noindex">
<link rel="stylesheet" href="/fonts/fonts.css"><link rel="stylesheet" href="/css/app.css">
<style>
.inst{max-width:560px;margin:32px auto;padding:0 16px;display:flex;flex-direction:column;gap:16px}
.inst h1{font-size:24px;font-weight:900}
.req{list-style:none;margin:0;padding:0;display:grid;gap:4px;font-size:13px}
.req li{display:flex;gap:8px;align-items:baseline}.req .y{color:var(--ok)}.req .n{color:var(--err);font-weight:700}.req .w{color:#b45309;font-weight:700}
.dbset{border:1px solid var(--line);border-radius:16px;padding:14px;margin:0;display:flex;flex-direction:column;gap:12px}
.help{font-size:13px;border:1px dashed var(--line-2);border-radius:12px;padding:10px 12px}
.help summary{cursor:pointer;font-weight:700;color:var(--brand-ink)}
.help ol{margin:8px 0;padding-inline-start:18px;line-height:2}
.dbset legend{font-weight:800;color:var(--ink);padding:0 6px}
.steps-mini{display:flex;gap:8px;font-size:12.5px;color:var(--muted);flex-wrap:wrap}
.steps-mini b{color:var(--ok)}
</style>
</head>
<body style="padding:0">
@php $bad = collect($req)->filter(fn ($r) => ! $r[1]); $hasSqlite = extension_loaded('pdo_sqlite'); @endphp
<main class="inst">
    <div style="display:flex;align-items:center;gap:12px">
        <span class="logo-mark">ف</span>
        <div><h1>نصب فروشگاه</h1><p class="muted" style="margin:0">چند مورد را وارد کنید؛ دیتابیس و بقیه کارها خودکار انجام می‌شود.</p></div>
    </div>
    <div class="steps-mini"><span><b>✓</b> آپلود فایل‌ها</span><span>—</span><span><b>✓</b> باز کردن سایت</span><span>—</span><span>۳. این فرم</span></div>

    @if ($bad->isNotEmpty())
        <div class="card">
            <h2 style="font-size:16px">بررسی هاست</h2>
            <ul class="req">
                @foreach ($bad as [$label, $pass, $note, $must])
                    <li><span class="{{ $must ? 'n' : 'w' }}">{{ $must ? '✕' : '!' }}</span><span>{{ $label }} <small class="muted">— {{ $note }}</small></span></li>
                @endforeach
            </ul>
            @unless ($ok)
                <div class="alert alert-err" style="margin-top:12px">موارد قرمز را در سی‌پنل (بخش Select PHP Version) فعال کنید و این صفحه را دوباره باز کنید.</div>
            @endunless
        </div>
    @else
        <div class="alert alert-ok">✓ هاست شما همه پیش‌نیازها را دارد.</div>
    @endif

    @if ($errors->any())<div class="alert alert-err">{{ $errors->first() }}</div>@endif

    <form method="post" action="{{ route('install.run') }}" class="card" style="display:flex;flex-direction:column;gap:14px" onsubmit="var b=this.querySelector('button[type=submit]');b.disabled=true;b.textContent='در حال نصب… (چند ثانیه)'">
        @csrf
        <input type="hidden" name="app_url" value="{{ $url }}">
        <label class="field">نام فروشگاه<input name="store_name" value="{{ old('store_name') }}" required autofocus placeholder="مثلاً پخش عزیزی"></label>
        <label class="field">نام شما<input name="admin_name" value="{{ old('admin_name') }}" required></label>
        <label class="field"><span>موبایل <small>(نام کاربری ورود به پنل)</small></span><input name="admin_mobile" value="{{ old('admin_mobile') }}" inputmode="tel" dir="ltr" placeholder="09xxxxxxxxx" required></label>
        <div class="grid-2">
            <label class="field"><span>رمز ورود <small>(دست‌کم ۸ کاراکتر)</small></span><input name="admin_password" type="password" required minlength="8" dir="ltr"></label>
            <label class="field">تکرار رمز<input name="admin_password_confirmation" type="password" required dir="ltr"></label>
        </div>

        @php
            $hasMysql = extension_loaded('pdo_mysql');
            $def = old('driver', $hasMysql && $cpUser ? 'cpanel' : ($hasSqlite ? 'sqlite' : 'mysql'));
        @endphp
        <fieldset class="dbset">
            <legend>دیتابیس</legend>
            <div class="choices col">
                @if ($hasMysql)
                    <label class="choice"><input type="radio" name="driver" value="cpanel" @checked($def === 'cpanel')><span class="dot"></span>
                        <span><b>ساخت خودکار دیتابیس MySQL روی هاست (پیشنهادی)</b><small>فقط نام کاربری و رمز سی‌پنل را بدهید؛ دیتابیس و کاربرش خودکار ساخته می‌شود. رمز سی‌پنل ذخیره نمی‌شود.</small></span></label>
                    <label class="choice"><input type="radio" name="driver" value="mysql" @checked($def === 'mysql')><span class="dot"></span>
                        <span><b>دیتابیس را خودم در سی‌پنل ساخته‌ام</b><small>نام دیتابیس، کاربر و رمز آن را وارد می‌کنم.</small></span></label>
                @endif
                @if ($hasSqlite)
                    <label class="choice"><input type="radio" name="driver" value="sqlite" @checked($def === 'sqlite')><span class="dot"></span>
                        <span><b>دیتابیس داخلی ساده (بدون MySQL)</b><small>برای فروشگاه کوچک؛ هیچ اطلاعاتی لازم نیست.</small></span></label>
                @endif
            </div>
            <div data-db="cpanel" style="display:flex;flex-direction:column;gap:12px">
                @if ($pending = \App\Http\Controllers\InstallController::pendingDb())
                    <div class="alert alert-ok">دیتابیس {{ $pending['name'] }} قبلاً ساخته شده است؛ لازم نیست رمز سی‌پنل را دوباره وارد کنید.</div>
                @else
                <label class="field"><span>نام کاربری سی‌پنل @if ($cpUser)<small>(خودکار تشخیص داده شد)</small>@endif</span>
                    <span style="display:flex;gap:8px">
                        <input name="cp_user" value="{{ old('cp_user', $cpUser) }}" dir="ltr" autocomplete="off" autocapitalize="off" spellcheck="false" @if ($cpUser && ! old('cp_user')) readonly style="background:var(--soft)" @endif data-cpuser>
                        @if ($cpUser)<button type="button" class="btn btn-line" style="min-height:46px;flex:none" onclick="var i=this.previousElementSibling;i.readOnly=false;i.style.background='';i.focus();this.remove()">تغییر</button>@endif
                    </span>
                    @if ($cpUser)<small style="font-weight:400">همان نامی که با آن وارد سی‌پنل می‌شوید؛ بدون پسوند (مثل _admin).</small>@endif
                </label>
                <label class="field"><span>رمز ورود به سی‌پنل <small>(یا توکن API)</small></span>
                    <input name="cp_pass" type="password" dir="ltr" autocomplete="new-password" spellcheck="false"></label>
                <details class="help">
                    <summary>رمز سی‌پنل را نمی‌دانید یا با آن وارد نمی‌شوید؟ (راه ساده‌تر: توکن)</summary>
                    <ol>
                        <li>وارد سی‌پنل شوید (از پنل هاستینگ یا آدرس زیر).</li>
                        <li>در جستجوی بالای سی‌پنل بنویسید <b dir="ltr">API Tokens</b> و «Manage API Tokens» را باز کنید.</li>
                        <li>«Create» را بزنید، یک نام دلخواه (مثلاً <span dir="ltr">shop</span>) بدهید و «Create» را بزنید.</li>
                        <li>کد ۳۲ حرفی که نمایش داده می‌شود را کپی کنید و در خانه بالا (به‌جای رمز) بگذارید.</li>
                    </ol>
                    <a class="btn btn-ghost" href="https://{{ request()->getHost() }}:2083" target="_blank" rel="noopener" style="min-height:38px">باز کردن سی‌پنل</a>
                    <p class="muted" style="margin:8px 0 0">بعد از نصب می‌توانید توکن را از همان‌جا حذف کنید.</p>
                </details>
                @endif
            </div>
            <div class="grid-2" data-db="mysql">
                <p class="muted" style="grid-column:1/-1;margin:0;font-size:13px">در سی‌پنل «MySQL Database Wizard» را باز کنید: یک دیتابیس و یک کاربر بسازید و در مرحله آخر «ALL PRIVILEGES» را تیک بزنید. سپس همان نام‌ها را این‌جا بنویسید.</p>
                <label class="field">نام دیتابیس<input name="db_name" value="{{ old('db_name') }}" dir="ltr" placeholder="{{ ($cpUser ?: 'cpaneluser') }}_shop"></label>
                <label class="field">نام کاربری دیتابیس<input name="db_user" value="{{ old('db_user') }}" dir="ltr" placeholder="{{ ($cpUser ?: 'cpaneluser') }}_admin"></label>
                <label class="field">رمز دیتابیس<input name="db_pass" type="password" dir="ltr"></label>
                <label class="field">هاست دیتابیس<input name="db_host" value="{{ old('db_host', 'localhost') }}" dir="ltr"></label>
                <input type="hidden" name="db_port" value="{{ old('db_port', 3306) }}">
            </div>
        </fieldset>
        <script>
        (function () {
            var f = document.currentScript.closest('form');
            function sync() {
                var v = (f.querySelector('input[name=driver]:checked') || {}).value;
                f.querySelectorAll('[data-db]').forEach(function (d) { d.hidden = d.dataset.db !== v; });
            }
            f.addEventListener('change', function (e) { if (e.target.name === 'driver') sync(); });
            sync();
        })();
        </script>

        <button type="submit" class="btn btn-lg" @disabled(! $ok)>نصب فروشگاه</button>
        <p class="muted" style="margin:0;font-size:12.5px;text-align:center">آدرس سایت: <span dir="ltr">{{ $url }}</span> — پنل مدیریت: <span dir="ltr">{{ $url }}/admin</span></p>
    </form>
</main>
</body>
</html>
