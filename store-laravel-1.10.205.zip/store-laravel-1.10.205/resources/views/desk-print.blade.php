@php
    $sum = array_sum(array_column($rows, 'total'));
    $units = array_sum(array_column($rows, 'units'));
    $cartons = array_sum(array_column($rows, 'cartons'));
    $packCol = collect($rows)->contains(fn ($r) => ($r['packName'] ?? '') !== '');
@endphp
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>بررسی {{ $wh }} — سفارش {{ $order->number }}</title>
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}?v={{ config('store.version') }}">
<style>
:root{--font:{!! \App\Support\Fonts::stack() !!}}
*{box-sizing:border-box}
body{margin:0;background:#e5e7eb;font-family:var(--font,Vazirmatn,Tahoma,sans-serif);color:#111;font-size:12px}
.bar{position:sticky;top:0;display:flex;gap:8px;justify-content:center;padding:10px;background:#1f2937}
.bar button,.bar a{border:0;border-radius:10px;padding:10px 18px;font:inherit;font-weight:800;cursor:pointer;background:#fff;color:#111;text-decoration:none}
.bar .pri{background:#16a34a;color:#fff}
.pg{width:210mm;min-height:297mm;margin:12px auto;background:#fff;padding:12mm 11mm;box-shadow:0 4px 24px rgba(0,0,0,.15)}
h1{font-size:17px;margin:0}
.hd{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;border-bottom:2px solid #111;padding-bottom:8px;margin-bottom:8px}
.hd .r{text-align:left;font-size:11px;line-height:1.9}
.meta{display:grid;grid-template-columns:repeat(3,1fr);gap:4px 12px;margin:6px 0 10px;font-size:11.5px}
.meta b{font-weight:800}
.draft{border:2px dashed #d97706;color:#92400e;background:#fffbeb;padding:6px 10px;border-radius:8px;margin-bottom:8px;font-weight:800}
table{width:100%;border-collapse:collapse}
th,td{border:1px solid #999;padding:4px 6px;text-align:center}
th{background:#f1f5f9;font-size:11px}
td.l{text-align:right}
td.n{font-variant-numeric:tabular-nums;white-space:nowrap}
tfoot td{font-weight:900;background:#f8fafc}
.pk{margin-top:8px;font-size:13px;font-weight:800}
.miss{margin-top:8px;font-size:11px;color:#991b1b}
.sign{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:22px}
.sign div{border-top:1px solid #111;padding-top:4px;text-align:center;font-size:11px;min-height:40px}
@page{size:A4;margin:0}
@media print{body{background:#fff}.bar{display:none}.pg{margin:0;box-shadow:none;width:auto;min-height:auto}}
</style>
</head>
<body>
<div class="bar">
    <button type="button" class="pri" onclick="window.print()">⬇ دانلود PDF / چاپ</button>
    @if ($done)<a href="{{ route('admin.holoo', [$order, 'scope' => 't'.$task->id]) }}">⬇ اکسل هلو همین برگه</a>@endif
</div>
<article class="pg">
    <div class="hd">
        <div>
            <h1>برگه بررسی رومیزی — {{ $wh }}</h1>
            <div>{{ store_name() }} · برای تطبیق با فاکتور هلو</div>
        </div>
        <div class="r">
            سفارش <b style="font-size:15px">{{ fa($order->number) }}</b><br>
            چاپ: {{ jdate(now(), true) }}
        </div>
    </div>
    @unless ($done)
        <div class="draft">پیش‌نویس — بررسی این انبار هنوز «تأیید نهایی» نشده و تعدادها ممکن است تغییر کند.</div>
    @endunless
    <div class="meta">
        <span>مشتری: <b>{{ $order->customer_name }}</b>@if ($order->company) — {{ $order->company }}@endif</span>
        <span>شهر: {{ trim(($order->province ? $order->province.'، ' : '').$order->city) ?: '—' }}</span>
        <span>جمع‌کننده: <b>{{ $task->picker?->displayName() ?? '—' }}</b></span>
        <span>بررسی‌کننده: <b>{{ $task->checker?->displayName() ?? '—' }}</b></span>
        <span>تأیید: {{ $task->checked_at ? jdate($task->checked_at, true) : '—' }}</span>
        <span>بسته‌بندی: <b>{{ $pack ?: '—' }}</b></span>
    </div>
    @php($prior = $prior ?? [])
    @php($pSum = array_sum(array_column($prior, 'total')))
    @if ($prior)
        <h3 style="margin:10px 0 4px;font-size:14px">۱) سفارش اصلی — قبلاً بررسی و در هلو ثبت شده ({{ fa(count($prior)) }} ردیف)</h3>
        <table>
            <thead><tr><th>#</th><th>کد کالا</th><th>نام کالا</th><th>کارتن</th><th>تعداد (عدد)</th><th>فی (تومان)</th><th>مبلغ (تومان)</th></tr></thead>
            <tbody>
            @foreach ($prior as $k => $r)
                <tr><td>{{ fa($k + 1) }}</td><td class="n" dir="ltr">{{ $r['code'] }}</td><td class="l">{{ $r['name'] }}</td><td class="n">{{ $r['cartons'] ? fa($r['cartons']).' × '.fa($r['per']) : '۰' }}</td><td class="n"><b>{{ fa($r['units']) }}</b></td><td class="n">{{ money($r['price']) }}</td><td class="n"><b>{{ money($r['total']) }}</b></td></tr>
            @endforeach
            </tbody>
            <tfoot><tr><td colspan="6">جمع سفارش اصلی</td><td class="n">{{ money($pSum) }}</td></tr></tfoot>
        </table>
        <h3 style="margin:14px 0 4px;font-size:14px">۲) جایگزین / افزوده — همین بررسی (فقط همین‌ها در اکسل هلو)</h3>
    @endif
    <table>
        <thead><tr><th>#</th><th>کد کالا</th><th>نام کالا</th><th>کارتن</th><th>تعداد (عدد)</th><th>فی (تومان)</th><th>مبلغ (تومان)</th>@if ($packCol)<th>نام کیسه</th>@endif</tr></thead>
        <tbody>
        @foreach ($rows as $k => $r)
            <tr>
                <td>{{ fa($k + 1) }}</td>
                <td class="n" dir="ltr">{{ $r['code'] }}</td>
                <td class="l">{{ $r['name'] }}</td>
                <td class="n">{{ $r['cartons'] ? fa($r['cartons']).' × '.fa($r['per']) : '۰' }}</td>
                <td class="n"><b>{{ fa($r['units']) }}</b></td>
                <td class="n">{{ money($r['price']) }}</td>
                <td class="n"><b>{{ money($r['total']) }}</b></td>
                @if ($packCol)<td><b>{{ $r['packName'] }}</b></td>@endif
            </tr>
        @endforeach
        </tbody>
        <tfoot>
            <tr><td colspan="3">{{ $prior ? 'جمع جایگزین/افزوده' : 'جمع' }}: {{ fa(count($rows)) }} ردیف</td><td class="n">{{ fa($cartons) }} کارتن</td><td class="n">{{ fa($units) }} عدد</td><td></td><td class="n">{{ money($sum) }}</td>@if ($packCol)<td></td>@endif</tr>
        </tfoot>
    </table>
    <div class="pk">جمع تعداد دوم (کارتن): {{ fa($cartons) }} — جمع تعداد (عدد): {{ fa($units) }} — تعداد ردیف: {{ fa(count($rows)) }}</div>
    @if ($prior)
        <div class="pk">جمع سفارش اصلی: {{ money($pSum) }} تومان — جمع جایگزین/افزوده: {{ money($sum) }} تومان</div>
        <div class="pk" style="font-size:15px">جمع کل این سالن: {{ money($pSum + $sum) }} تومان <small style="font-weight:600">({{ num_words($pSum + $sum) }} تومان)</small></div>
    @else
    <div class="pk">مبلغ این سالن: {{ money($sum) }} تومان <small style="font-weight:600">({{ num_words($sum) }} تومان)</small></div>
    @endif
    @if ($missing->isNotEmpty())
        <div class="miss"><b>ناموجود در این انبار ({{ fa($missing->count()) }} قلم):</b> {{ $missing->pluck('name')->implode('، ') }}</div>
    @endif
    <div class="sign"><div>بررسی‌کننده رومیزی</div><div>ثبت در هلو</div></div>
</article>
</body>
</html>
