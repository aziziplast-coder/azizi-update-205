@extends('layouts.store', ['title' => 'اتصال برقرار نیست', 'noindex' => true])

@section('content')
<main class="wrap page tight">
    <div class="empty" style="margin-top:24px">
        <svg class="ic"><use href="#i-wifi-off"/></svg>
        <b style="color:var(--ink);font-size:18px">اینترنت شما قطع است</b>
        <span>پس از برقراری اتصال، صفحه را دوباره باز کنید. صفحه‌هایی که قبلاً دیده‌اید بدون اینترنت هم باز می‌شوند.</span>
        <button class="btn" onclick="location.reload()">تلاش دوباره</button>
    </div>
</main>
@endsection
