@extends('layouts.store', ['title' => 'سفارش '.$order->number, 'noindex' => true])

@section('content')
<main class="wrap page tight">
    @if (session('in_app'))
        @php $appLink = (data_get(setting('mobile_app'), 'scheme') ?: 'storeapp').'://order/'.$order->number; @endphp
        <a class="btn btn-block" href="{{ $appLink }}" style="margin-bottom:12px" data-app-return>بازگشت به اپلیکیشن ←</a>
        @if (session('placed') || request('paid'))<script>setTimeout(function(){location.href=@json($appLink)},1200)</script>@endif
    @endif
    @if (session('placed'))
        <ol class="steps"><li class="done">۱. سبد خرید ✓</li><li>—</li><li class="done">۲. ارسال و پرداخت ✓</li><li>—</li><li class="cur">۳. پایان</li></ol>
        <div class="card thanks">
            <svg class="ic"><use href="#i-check"/></svg>
            <h1>سفارش شما ثبت شد</h1>
            <p class="muted" style="margin:0">شماره سفارش: <b style="color:var(--ink)">{{ fa($order->number) }}</b> — وضعیت سفارش از همین صفحه و بخش «حساب من» قابل پیگیری است.</p>
        </div>
    @endif
    @if ($errors->has('pay'))<div class="alert alert-err">{{ $errors->first('pay') }}</div>@endif
    @if ($errors->has('cart'))<div class="alert alert-err">{{ $errors->first('cart') }}</div>@endif
    @if (session('ok'))<div class="alert alert-ok">{{ session('ok') }}</div>@endif
    @if ($order->review_status === 'pending')
        <div class="alert alert-warn">سفارش چکی شما در حال بررسی و استعلام چک توسط کارشناس است؛ پس از تأیید، آماده‌سازی آغاز می‌شود و پیامک اطلاع‌رسانی دریافت می‌کنید.</div>
    @endif

    @php $jr = \App\Support\OrderJourney::for($order); $supUrl = \App\Support\OrderJourney::supportUrl(); @endphp
    <div class="card" style="display:flex;flex-direction:column;gap:18px;margin-bottom:16px">
        <div class="order-head" style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
            <h2 style="margin:0">سفارش {{ fa($order->number) }}</h2>
            <span class="status {{ $order->status }}" style="font-size:14px;padding:4px 14px">{{ $order->statusLabel() }}</span>
        </div>
        @include('store.partials.journey', ['j' => $jr])
        @if ($order->status === 'completed' && $supUrl)
            <a href="{{ $supUrl }}" target="_blank" rel="noopener" class="btn btn-support btn-lg" style="justify-content:center">💬 پشتیبانی در روبیکا ({{ '@'.\App\Support\OrderJourney::supportId() }})</a>
        @endif
    </div>

    @include('store.partials.order-chat')

    <div class="split">
        <section class="split-main">
            <div class="card" style="display:flex;flex-direction:column;gap:12px">
                <h3 style="margin:0;font-size:17px">جزئیات سفارش</h3>
                @if ($order->status === 'cancelled' && $order->cancel_reason)
                    <div class="alert alert-err" style="margin:0">علت لغو: {{ $order->cancel_reason }}</div>
                @endif
                <dl class="sum">
                    <div><dt>تاریخ ثبت</dt><dd>{{ jdate($order->created_at, true) }}</dd></div>
                    <div><dt>شیوه ارسال</dt><dd>{{ $order->shipping_title }}</dd></div>
                    <div><dt>شیوه تسویه</dt><dd>{{ $order->payment_title }}</dd></div>
                    <div><dt>وضعیت پرداخت</dt><dd>{{ $order->isPaid() ? 'پرداخت شده' : 'پرداخت نشده' }}</dd></div>
                    @if ($order->payment_ref)<div><dt>شماره پیگیری</dt><dd class="ltr">{{ $order->payment_ref }}</dd></div>@endif
                    @if ($order->tracking_code)<div><dt>کد رهگیری مرسوله</dt><dd class="ltr">{{ $order->tracking_code }}</dd></div>@endif
                    @if ($order->freight_name)<div><dt>باربری</dt><dd>{{ $order->freight_name }}</dd></div>@endif
                    @if ($order->loaded_at)<div><dt>تحویل به باربری</dt><dd>{{ jdate($order->loaded_at, true) }}</dd></div>@endif
                    @foreach ((array) $order->custom_fields as $cfk => $cfv)<div><dt>{{ $cfk }}</dt><dd>{{ $cfv }}</dd></div>@endforeach
                    <div><dt>گیرنده</dt><dd style="white-space:normal;text-align:left">{{ $order->customer_name }} — {{ fa($order->fullAddress()) }}</dd></div>
                </dl>
                @if ($card && ! $order->isPaid() && in_array($order->status, ['on_hold', 'pending_payment'], true))
                    <div class="paybox">
                        <b style="color:var(--ink)">مبلغ {{ money($order->total, true) }} را به این حساب واریز کنید:</b>
                        <div class="kv">
                            @if (! empty($card['card_number']))<span>شماره کارت: <b class="ltr">{{ fa(trim(chunk_split(preg_replace('/\D/', '', en_digits($card['card_number'])), 4, '-'), '-')) }}</b></span>@endif
                            @if (! empty($card['holder']))<span>به نام: <b>{{ $card['holder'] }}</b></span>@endif
                            @if (! empty($card['sheba']))<span>شبا: <b class="ltr">{{ $card['sheba'] }}</b></span>@endif
                        </div>
                        <small class="muted">پس از واریز، شماره پیگیری را تلفنی یا در پیام‌رسان به فروشگاه اعلام کنید.</small>
                    </div>
                @endif
                @if ($remit)
                    <div id="pay" style="scroll-margin-top:90px">@include('store.partials.remit-pay', ['order' => $order, 'pays' => $remitPays])</div>
                @endif
                @if ($canPay)
                    <a href="{{ route('payment.start', $order->number) }}" class="btn btn-lg">پرداخت آنلاین {{ money($order->total, true) }}</a>
                @endif
                @if ($order->cheque)
                    <div id="cheques" style="scroll-margin-top:90px;display:grid;gap:12px">@include('store.partials.cheque-plan', ['ch' => $order->cheque, 'order' => $order])</div>
                @endif
                @if ($order->waybill_path)
                    <a href="{{ route('order.waybill', $order->number) }}" target="_blank" class="paybox" style="display:flex;gap:12px;align-items:center;text-decoration:none;color:inherit">
                        @unless (str_ends_with(strtolower($order->waybill_path), '.pdf'))<img src="{{ route('order.waybill', $order->number) }}" alt="بیجک" style="width:64px;height:64px;object-fit:cover;border-radius:12px;border:1px solid var(--line)" loading="lazy">@endunless
                        <span><b>🧾 بیجک باربری</b><br><small class="muted">{{ $order->freight_name ? 'باربری '.$order->freight_name.' — ' : '' }}بارگذاری {{ jdate($order->waybill_at, true) }} — برای مشاهده بزنید</small></span>
                    </a>
                @elseif ($order->status === 'shipped')
                    <small class="muted">بار به باربری تحویل شد؛ بیجک به‌زودی همین‌جا قرار می‌گیرد.</small>
                @endif
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                    <a href="{{ route('invoice', $order->number) }}" target="_blank" class="btn btn-line">مشاهده و چاپ فاکتور</a>
                    @if ($canEdit)
                        <form method="post" action="{{ route('order.edit', $order->number) }}">@csrf<button class="btn btn-line" type="submit">✏️ افزودن یا تغییر کالاها</button></form>
                    @endif
                    @if ($order->canReorder())
                        <form method="post" action="{{ route('order.reorder', $order->number) }}">@csrf<button class="btn btn-line" type="submit" title="اقلام همین سفارش با قیمت و موجودی امروز به سبد خرید می‌رود">🔁 سفارش مجدد</button></form>
                    @endif
                    @if ($survey)
                        <a href="{{ route('survey', [$order->number, 's' => $survey->id]) }}" class="btn btn-line">⭐ ثبت نظر درباره این سفارش</a>
                    @endif
                </div>
                @if ($canEdit)
                    <small class="muted">تا وقتی کارشناس رسیدگی به سفارش را شروع نکرده، می‌توانید کالا اضافه یا کم کنید.</small>
                @endif
            </div>

            @if ($order->fulfil_status)
                @php
                    $pt = $order->items->whereNotNull('pick_task_id');
                    $pc = $pt->whereNotNull('pick_status')->count();
                    $pn = $pt->count();
                @endphp
                <div class="card pk-status">
                    <div class="pk-head">
                        <b>وضعیت در انبار</b>
                        <span class="pk-badge {{ $order->fulfil_status }}">{{ $order->fulfil_status === 'picking' ? 'در حال جمع‌آوری' : ($order->fulfil_status === 'replace_review' ? 'جایگزین‌ها در انتظار تأیید' : 'جمع‌آوری شد') }}</span>
                    </div>
                    @if ($order->fulfil_status === 'picking')
                        <div class="pk-bar"><i style="width:{{ $pn ? round($pc / $pn * 100) : 0 }}%"></i></div>
                        <small class="muted">{{ fa($pc) }} از {{ fa($pn) }} قلم در انبار بررسی شده است. پس از پایان جمع‌آوری، نتیجه همین‌جا نمایش داده می‌شود.</small>
                    @else
                        <small class="muted">
                            {{ fa($order->items->where('pick_status', 'ok')->count()) }} قلم کامل جمع شد
                            @if ($removed->isNotEmpty())، {{ fa($removed->count()) }} قلم کسری یا ناموجود بود و مبلغ سفارش به‌روز شد.@else. همه اقلام آماده است.@endif
                        </small>
                    @endif
                </div>
            @endif

            @if ($canReplace || $reps->isNotEmpty())
                <div class="card pk-repl" id="replace" style="scroll-margin-top:90px">
                    <div class="pk-head">
                        <h2 style="margin:0;font-size:18px">{{ $removed->isNotEmpty() ? 'جایگزینی کالاهای حذف‌شده / افزودن کالا' : 'افزودن کالای جدید به بار' }}</h2>
                        @if ($canReplace && $order->replace_until)
                            <span class="pk-dead">مهلت انتخاب: تا {{ jdate($order->replace_until, true) }}</span>
                        @endif
                    </div>
                    @if ($errors->has('replace'))<div class="alert alert-err">{{ $errors->first('replace') }}</div>@endif
                    @if ($canReplace)
                        <p class="muted" style="margin:0">{{ $removed->isNotEmpty() ? 'این کالاها در انبار کم بود یا موجود نبود. اگر بخواهید، کالای مشابه را جایگزین کنید یا کالای جدید اضافه کنید.' : 'بار شما جمع شده است. اگر کالای دیگری هم می‌خواهید، از کادر زیر جستجو و اضافه کنید.' }} چیزی از فاکتور کم نمی‌شود؛ پس از «ارسال برای تأیید»، کارشناس بررسی می‌کند و برای جمع‌آوری به انبار می‌رود.</p>
                    @endif
                    @foreach ($removed as $it)
                        <div class="pk-gone">
                            <div class="pk-gone-h">
                                @if ($it->image)<img src="{{ thumb($it->image, 160) }}" alt="" loading="lazy">@endif
                                <div>
                                    <b>{{ $it->name }}</b>
                                    <span class="pk-chip {{ $it->pick_status }}">{{ $it->pick_status === 'missing' ? 'ناموجود — حذف شد' : 'کسری: '.$it->unitsLabel((int) $it->units).' از '.$it->unitsLabel($it->orderedUnits()) }}</span>
                                </div>
                            </div>
                            @if ($canReplace)
                                @php $alts = $suggest[$it->id] ?? []; @endphp
                                @if ($alts)
                                    <details class="pk-more" @if ($loop->first) open @endif>
                                    <summary>پیشنهاد جایگزین ({{ fa(count($alts)) }})</summary>
                                    <div class="pk-alts">
                                        @foreach ($alts as $a)
                                            @php $ap = $a['product']; $isC = $a['mode'] === 'carton' && $ap->per_carton > 1 && ! $ap->buyRule()[2]; @endphp
                                            <form method="post" action="{{ route('order.replace', $order->number) }}" class="pk-alt">
                                                @csrf
                                                <input type="hidden" name="product" value="{{ $ap->id }}"><input type="hidden" name="mode" value="{{ $a['mode'] }}"><input type="hidden" name="replaces" value="{{ $it->id }}">
                                                <a href="{{ $ap->url() }}" target="_blank" class="pk-alt-img">@if ($ap->image)<img src="{{ thumb($ap->image, 160) }}" alt="" loading="lazy">@endif</a>
                                                <div class="pk-alt-t">
                                                    <a href="{{ $ap->url() }}" target="_blank"><b>{{ $ap->name }}</b></a>
                                                    <span>{{ money($ap->unitPrice($a['mode'])) }} تومان {{ $isC ? 'هر '.$ap->unitName().' — '.$ap->cartonText() : ($a['mode'] === 'retail' ? 'هر '.$ap->unitName().' (خرده)' : 'هر '.$ap->unitName()) }}</span>
                                                </div>
                                                <label class="pk-alt-q"><input type="number" name="qty" min="1" value="{{ $isC ? max(1, intdiv($a['units'], $ap->per_carton)) : $a['units'] }}" inputmode="numeric"> {{ $isC ? 'کارتن' : $ap->unitName() }}</label>
                                                <button class="btn btn-sm" type="submit">افزودن</button>
                                            </form>
                                        @endforeach
                                    </div>
                                    </details>
                                @else
                                    <small class="muted">کالای مشابهی (هم‌نوع) موجود نیست.</small>
                                @endif
                            @endif
                        </div>
                    @endforeach

                    @if ($canReplace)
                        <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            var box = document.querySelector('[data-extra]'); if (!box) return;
                            var q = box.querySelector('[data-extra-q]'), l = box.querySelector('[data-extra-l]'), T;
                            var csrf = @json(csrf_token());
                            var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
                            q.addEventListener('input', function () {
                                clearTimeout(T); T = setTimeout(function () {
                                    var v = q.value.trim(); if (v.length < 2) { l.innerHTML = ''; return; }
                                    fetch(box.dataset.url + '?q=' + encodeURIComponent(v), { headers: { Accept: 'application/json' }, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
                                        l.innerHTML = j.items.length ? j.items.map(function (p) {
                                            return '<form method="post" action="' + esc(box.dataset.post) + '" class="pk-alt' + (p.avail ? '' : ' is-out') + '"><input type="hidden" name="_token" value="' + esc(csrf) + '"><input type="hidden" name="product" value="' + p.id + '"><input type="hidden" name="mode" value="' + esc(p.mode) + '">'
                                                + '<span class="pk-alt-img">' + (p.img ? '<img src="' + esc(p.img) + '" alt="" loading="lazy">' : '') + '</span>'
                                                + '<div class="pk-alt-t"><b>' + esc(p.name) + '</b><span>' + esc(p.price) + (p.note ? ' — ' + esc(p.note) : '') + '</span></div>'
                                                + (p.avail ? '<label class="pk-alt-q"><input type="number" name="qty" min="1" value="' + p.qty + '" inputmode="numeric"> ' + esc(p.unit) + '</label><button class="btn btn-sm" type="submit">افزودن</button>' : '<span class="muted" style="font-size:12px">ناموجود</span>')
                                                + '</form>';
                                        }).join('') : '<small class="muted">کالایی پیدا نشد.</small>';
                                    }).catch(function () {});
                                }, 300);
                            });
                        });
                        </script>
                        <div class="pk-extra" data-extra data-url="{{ route('order.replace.search', $order->number) }}" data-post="{{ route('order.replace', $order->number) }}">
                            <b>➕ خرید کالای دیگر</b>
                            <small class="muted">هر کالای دیگری هم بخواهید اضافه کنید؛ همراه جایگزین‌ها برای تأیید فروشگاه ارسال و به‌صورت «پیوست فاکتور» به سفارش افزوده می‌شود.</small>
                            <input type="search" class="input" data-extra-q placeholder="نام یا کد کالا…" autocomplete="off">
                            <div class="pk-alts" data-extra-l></div>
                        </div>
                    @endif

                    @if ($reps->isNotEmpty())
                        <div class="pk-chosen">
                            <b>جایگزین‌های انتخابی شما</b>
                            @foreach ($reps as $r)
                                <div class="pk-ch-row">
                                    <span class="pk-chip {{ $r->status }}">{{ ['draft' => 'انتخاب‌شده', 'submitted' => 'در انتظار تأیید', 'approved' => 'تأیید و اضافه شد', 'rejected' => 'تأیید نشد'][$r->status] }}</span>
                                    <span class="pk-ch-name">{{ $r->name }} — {{ $r->qtyLabel() }} @if (! $r->replaces_item_id)<small class="muted">(کالای اضافه)</small>@endif</span>
                                    <b>{{ money($r->total()) }}</b>
                                    @if ($r->status === 'draft' && $canReplace)
                                        <form method="post" action="{{ route('order.replace.remove', [$order->number, $r->id]) }}">@csrf<button class="linkish" type="submit">حذف</button></form>
                                    @endif
                                </div>
                            @endforeach
                            @php $drafts = $reps->where('status', 'draft'); @endphp
                            @if ($drafts->isNotEmpty() && $canReplace)
                                <div class="pk-ch-sum">جمع جایگزین‌ها: <b>{{ money($drafts->sum(fn ($r) => $r->total())) }} تومان</b></div>
                                <form method="post" action="{{ route('order.replace.submit', $order->number) }}">@csrf<button class="btn btn-lg btn-block" type="submit">ارسال جایگزین‌ها برای تأیید فروشگاه</button></form>
                            @endif
                        </div>
                    @endif
                    @if ($order->replace_submitted_at && $order->fulfil_status === 'replace_review')
                        <div class="alert alert-ok" style="margin:0">جایگزین‌ها {{ jdate($order->replace_submitted_at, true) }} برای تأیید ارسال شد؛ پس از تأیید کارشناس به سفارش اضافه می‌شود.</div>
                    @endif
                </div>
            @endif
        </section>
        <aside class="split-side card">
            <h2 style="margin:0;font-size:18px">اقلام سفارش</h2>
            @foreach ($order->items as $it)
                <div class="mini{{ $it->pick_status === 'missing' ? ' pk-off' : '' }}">
                    @if ($it->image)<img src="{{ thumb($it->image, 160) }}" alt="" loading="lazy">@else<span class="noimg"></span>@endif
                    <div><b>{{ $it->name }}</b><span><span class="tag{{ $it->isRetail() ? ' retail' : '' }}">{{ $it->modeLabel() }}</span>{{ $it->units > 0 ? $it->qtyLabel() : $it->unitsLabel($it->orderedUnits()) }}</span>
                        @if ($it->pick_status)<span class="pk-chip {{ $it->pick_status }}">{{ $it->pick_status === 'ok' ? '✓ در انبار جمع شد' : ($it->pick_status === 'missing' ? '✗ ناموجود — حذف شد' : '◐ کسری: '.$it->unitsLabel((int) $it->units).' از '.$it->unitsLabel($it->orderedUnits())) }}</span>@endif
                        @if ($it->replaces_item_id)<span class="pk-chip draft">جایگزین</span>@elseif (! empty($it->appendix))<span class="pk-chip draft">📎 پیوست فاکتور</span>@endif
                    </div>
                    <b>{{ money($it->total) }}</b>
                </div>
            @endforeach
            <dl class="sum" style="padding-top:12px;border-top:1px dashed var(--line-2)">
                <div><dt>جمع کالاها</dt><dd>{{ money($order->items_total) }}</dd></div>
                @if ($order->discount_total)<div class="neg"><dt>سود شما از تخفیف</dt><dd>{{ money($order->discount_total) }}</dd></div>@endif
                @if ($order->coupon_discount)<div class="neg"><dt>کد تخفیف {{ $order->coupon_code }}</dt><dd>− {{ money($order->coupon_discount) }}</dd></div>@endif
                <div><dt>ارسال: {{ $order->shipping_title }}</dt><dd>{{ $order->shippingLabel() }}</dd></div>
                @if ($order->freight_fee)<div><dt>کرایه حمل تا باربری</dt><dd>{{ money($order->freight_fee) }}</dd></div>@endif
                @if ($order->extra_discount)<div class="neg"><dt>تخفیف</dt><dd>− {{ money($order->extra_discount) }}</dd></div>@endif
                @foreach ((array) $order->fees as $fee)<div><dt>{{ $fee['title'] }}</dt><dd>{{ money($fee['amount']) }}</dd></div>@endforeach
                <div class="grand"><dt>مبلغ کل</dt><dd>{{ money($order->total) }} تومان</dd></div>
            </dl>
        </aside>
    </div>
</main>
@endsection
