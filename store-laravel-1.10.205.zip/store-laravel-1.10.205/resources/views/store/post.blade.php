@php
    $tpl = setting('seo_title_post', '{name}');
    $img = $post->image ? url(upload_url($post->image)) : null;
    $schema = [
        '@context' => 'https://schema.org', '@type' => 'BlogPosting',
        'headline' => \Illuminate\Support\Str::limit($post->title, 110, ''),
        'description' => $post->seo_description ?: $post->summary(),
        'datePublished' => optional($post->published_at ?? $post->created_at)->toIso8601String(),
        'dateModified' => $post->updated_at->toIso8601String(),
        'mainEntityOfPage' => $post->url(),
        'author' => ['@type' => 'Person', 'name' => $post->author?->name ?: store_name()],
        'publisher' => ['@type' => 'Organization', 'name' => store_name(), 'logo' => ['@type' => 'ImageObject', 'url' => setting('logo') ? url(upload_url(setting('logo'))) : route('pwa.icon', 512)]],
    ];
    if ($img) { $schema['image'] = [$img]; }
    if ($post->tags) { $schema['keywords'] = implode(', ', (array) $post->tags); }
    $faq = array_values(array_filter((array) $post->faq, fn ($f) => ! empty($f['q']) && ! empty($f['a'])));
@endphp
@extends('layouts.store', [
    'title' => $post->seo_title ?: str_replace(['{name}', ' | {site}', '{site}'], [$post->title, '', store_name()], $tpl),
    'description' => $post->seo_description ?: $post->summary(),
    'canonical' => $post->canonical ?: $post->url(),
    'noindex' => $post->noindex,
    'ogImage' => $post->image ? upload_url($post->image) : null,
])

@push('head')
<meta property="og:type" content="article">
<meta property="article:published_time" content="{{ optional($post->published_at)->toIso8601String() }}">
<script type="application/ld+json">{!! json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!}</script>
@if ($faq)<script type="application/ld+json">{!! json_encode(['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(fn ($f) => ['@type' => 'Question', 'name' => $f['q'], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f['a']]], $faq)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!}</script>@endif
@if (setting('seo_breadcrumbs', true))
<script type="application/ld+json">{!! json_encode(['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => array_values(array_filter([
    ['@type' => 'ListItem', 'position' => 1, 'name' => 'خانه', 'item' => route('home')],
    ['@type' => 'ListItem', 'position' => 2, 'name' => setting('blog_title', 'مجله'), 'item' => route('blog')],
    $post->category ? ['@type' => 'ListItem', 'position' => 3, 'name' => $post->category->name, 'item' => $post->category->url()] : null,
    ['@type' => 'ListItem', 'position' => $post->category ? 4 : 3, 'name' => $post->title, 'item' => $post->url()],
]))], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!}</script>
@endif
@endpush

@section('content')
<main class="wrap page tight">
    <nav class="crumbs" aria-label="مسیر"><a href="{{ route('home') }}">خانه</a><span>/</span><a href="{{ route('blog') }}">{{ setting('blog_title', 'مجله') }}</a>
        @if ($post->category)<span>/</span><a href="{{ $post->category->url() }}">{{ $post->category->name }}</a>@endif</nav>
    <article class="article">
        <header class="article-head">
            <h1>{{ $post->title }}</h1>
            <div class="article-meta muted">
                @if ($post->author)<span>{{ $post->author->name }}</span>@endif
                <time datetime="{{ optional($post->published_at)->toIso8601String() }}">{{ jdate($post->published_at ?? $post->created_at) }}</time>
                <span>{{ fa($post->readingMinutes()) }} دقیقه مطالعه</span>
            </div>
            @if ($post->image)<img class="article-img" src="{{ thumb($post->image, 1600) }}" srcset="{{ srcset($post->image, [480, 960, 1600]) }}" sizes="(max-width: 860px) 100vw, 860px" alt="{{ $post->image_alt ?: $post->title }}" fetchpriority="high">@endif
        </header>
        @if (count($toc) >= 3)
            <details class="toc" open><summary>فهرست مطالب</summary><ol>@foreach ($toc as $t)<li class="lv{{ $t['level'] }}"><a href="#{{ $t['id'] }}">{{ $t['text'] }}</a></li>@endforeach</ol></details>
        @endif
        <div class="prose article-body">{!! $body !!}</div>
        @if ($faq)
            <section class="faq"><h2>پرسش‌های متداول</h2>
                @foreach ($faq as $f)<details><summary>{{ $f['q'] }}</summary><div class="prose">{!! nl2br(e($f['a'])) !!}</div></details>@endforeach
            </section>
        @endif
        @if ($post->tags)
            <div class="tags">@foreach ((array) $post->tags as $t)<a href="{{ route('blog.tag', $t) }}" class="pill">#{{ $t }}</a>@endforeach</div>
        @endif
    </article>
    @if ($products->isNotEmpty())
        @include('store.blocks.strip', ['products' => $products, 'title' => 'کالاهای مرتبط با این مقاله'])
    @endif
    @if ($related->isNotEmpty())
        <section class="sec"><div class="sec-head"><h2>مقالات مرتبط</h2><a href="{{ route('blog') }}">همه مقالات</a></div>
            <div class="posts">@foreach ($related as $rp)@include('store.partials.post-card', ['post' => $rp])@endforeach</div></section>
    @endif
</main>
@endsection
