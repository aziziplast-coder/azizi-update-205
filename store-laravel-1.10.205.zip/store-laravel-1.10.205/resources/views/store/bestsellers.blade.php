@extends('layouts.store', ['title' => $title, 'canonical' => route('bestsellers')])

@section('content')
<main class="wrap page tight">
    <nav class="crumbs" aria-label="مسیر"><a href="{{ route('home') }}">خانه</a><span>/</span><span>{{ $title }}</span></nav>
    <div class="shop-head"><div><h1>{{ $title }}</h1><p>رتبه‌بندی بر اساس تعداد فروش</p></div></div>
    @if ($products->isEmpty())
        <div class="empty"><svg class="ic"><use href="#i-search"/></svg><span>هنوز فروشی ثبت نشده است.</span></div>
    @else
        <div class="grid plist">
            @foreach ($products as $i => $p)
                <div class="ranked"><span class="rank-n">{{ fa($offset + $i + 1) }}</span>@include('store.partials.product-card', ['p' => $p])
                    @if ($showSold && ($p->sold_units ?? 0) > 0)<small class="ranked-sold">{{ fa($p->sold_units) }} عدد فروخته شده</small>@endif</div>
            @endforeach
        </div>
        @include('store.partials.pager', ['paginator' => $products])
    @endif
</main>
@endsection
