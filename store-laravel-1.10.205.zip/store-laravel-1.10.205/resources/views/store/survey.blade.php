@extends('layouts.store', ['title' => $survey->title, 'noindex' => true])

@section('content')
<main class="wrap page tight" style="max-width:640px">
    <div class="card" style="display:flex;flex-direction:column;gap:14px">
        <h1 style="margin:0;font-size:22px">{{ $survey->title }}</h1>
        <p class="muted" style="margin:0">سفارش {{ fa($order->number) }} — {{ jdate($order->created_at) }}</p>
        @if ($survey->intro)<p style="margin:0">{{ $survey->intro }}</p>@endif
        @if ($errors->has('survey'))<div class="alert alert-err">{{ $errors->first('survey') }}</div>@endif
        @if ($done)
            <div class="alert alert-ok">نظر شما برای این سفارش ثبت شده است؛ سپاسگزاریم 🌷</div>
        @else
            @include('store.partials.survey-form')
        @endif
    </div>
</main>
@endsection
