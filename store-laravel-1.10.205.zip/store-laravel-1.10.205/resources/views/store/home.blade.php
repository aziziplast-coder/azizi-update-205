@extends('layouts.store')

@push('head')
<script type="application/ld+json">{!! json_encode(['@context' => 'https://schema.org', '@type' => 'WebSite', 'name' => store_name(), 'url' => url('/'), 'potentialAction' => ['@type' => 'SearchAction', 'target' => url('/shop').'?q={q}', 'query-input' => 'required name=q']], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!}</script>
@endpush

@section('content')
<main class="wrap page home">
    <h1 class="sr">{{ setting('seo_title') ?: store_name() }}</h1>
    @foreach ($blocks as $b)
        @includeIf('store.blocks.'.$b['type'], ['d' => $b['data'], 'items' => $b['items'], 'first' => $loop->first])
    @endforeach
    @if (! $blocks || \App\Models\Product::query()->doesntExist())
        <div class="empty"><svg class="ic"><use href="#i-box"/></svg>هنوز محصولی ثبت نشده است. از پنل مدیریت محصول اضافه کنید.</div>
    @endif
</main>
@endsection
