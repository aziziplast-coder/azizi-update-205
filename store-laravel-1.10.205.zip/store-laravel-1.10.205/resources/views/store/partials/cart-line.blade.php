@php
    $code = $l->product->sku ?: $l->product->barcode;
    $boxed = ! $l->retail && $l->product->hasCartons() && empty($l->custom);
    $un = $l->product->unitName();
@endphp
                <div class="cline" data-line data-key="{{ $l->key }}" data-p='@json($l->product->buyData())' data-mode="{{ $l->mode }}" data-units="{{ $l->units }}">
                    <a href="{{ $l->product->url() }}" class="cline-img">@if ($l->product->image)<img src="{{ thumb($l->product->image, 160) }}" alt="" loading="lazy">@else<span class="noimg"></span>@endif</a>
                    <div class="cline-info">
                        <a href="{{ $l->product->url() }}" class="cline-name">{{ $l->product->name }}</a>
                        <div class="cline-meta">
                            @if ($code)<span class="cline-code" title="کد کالا">کد <b dir="ltr">{{ $code }}</b></span>@endif
                            <span class="chip{{ $l->retail ? ' chip-retail' : '' }}">{{ $l->tag }}</span>
                        </div>
                        <div class="cline-calc">
                            @if ($boxed)
                                {{ fa($l->cartons) }} کارتن × {{ fa($l->product->per_carton) }} = <b>{{ fa($l->units) }} {{ $un }}</b>
                            @else
                                <b>{{ fa($l->units) }} {{ $un }}</b>
                            @endif
                            <span class="muted">× {{ money($l->unit_price) }}</span>
                            @if (! empty($l->was_price))
                                <span class="price-moved {{ $l->unit_price > $l->was_price ? 'up' : 'down' }}">{{ $l->unit_price > $l->was_price ? '▲ گران‌تر شد' : '▼ ارزان‌تر شد' }} (قبلاً {{ money($l->was_price) }})</span>
                            @endif
                        </div>
                    </div>
                    <div class="cline-end">
                        <b class="cline-total">{{ money($l->total) }} <small>تومان</small></b>
                        <div class="buy-in">
                            <button type="button" data-act="line-plus" aria-label="یکی بیشتر" @disabled($l->max >= 0 && $l->units + $l->step > $l->max)>+</button>
                            <span><b>{{ fa($boxed ? $l->cartons : $l->units) }}</b> <i>{{ $boxed ? 'کارتن' : $un }}</i></span>
                            <button type="button" data-act="line-minus" aria-label="یکی کمتر">−</button>
                        </div>
                        <button type="button" class="rm" data-act="remove" aria-label="حذف از سبد"><svg class="ic"><use href="#i-trash"/></svg>حذف</button>
                    </div>
                </div>
