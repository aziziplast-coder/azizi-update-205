<div class="popup" data-popup data-delay="{{ max(0, (int) ($popup['delay'] ?? 3)) }}" data-freq="{{ $popup['frequency'] ?? 'session' }}" data-days="{{ max(1, (int) ($popup['days'] ?? 1)) }}" data-ver="{{ md5(json_encode([$popup['title'] ?? '', $popup['text'] ?? '', $popup['image'] ?? '', $popup['version'] ?? 1])) }}" hidden role="dialog" aria-modal="true" aria-label="{{ $popup['title'] ?: 'اطلاعیه' }}">
    <div class="popup-bg" data-popup-close></div>
    <div class="popup-box">
        <button type="button" class="icon-btn popup-x" data-popup-close aria-label="بستن"><svg class="ic"><use href="#i-close"/></svg></button>
        @if (! empty($popup['image']))
            @if (! empty($popup['link']))<a href="{{ $popup['link'] }}" data-popup-go>@endif
            <img src="{{ thumb($popup['image'], 960) }}" alt="{{ $popup['title'] ?? '' }}" loading="lazy">
            @if (! empty($popup['link']))</a>@endif
        @endif
        @if (! empty($popup['title']) || ! empty($popup['text']) || ! empty($popup['button']))
            <div class="popup-in">
                @if (! empty($popup['title']))<b class="popup-title">{{ $popup['title'] }}</b>@endif
                @if (! empty($popup['text']))<div class="prose">{!! clean_html($popup['text']) !!}</div>@endif
                @if (! empty($popup['button']) && ! empty($popup['link']))<a href="{{ $popup['link'] }}" class="btn" data-popup-go>{{ $popup['button'] }}</a>@endif
            </div>
        @endif
    </div>
</div>
