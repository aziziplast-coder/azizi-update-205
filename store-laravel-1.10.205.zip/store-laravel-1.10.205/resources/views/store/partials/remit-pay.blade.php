{{-- پرداخت بیعانه / تسویه به حساب حواله‌ها با بارگذاری فیش --}}
@php
    $due = $pays->whereIn('status', ['awaiting', 'rejected', 'submitted']);
    $confirmed = $pays->where('status', 'confirmed');
    $final = $order->final_amount ?: $order->total;
@endphp
<div class="rp">
    @if ($pays->isEmpty())
        @if (in_array($order->status, ['on_hold'], true) && $order->review_status !== 'pending')
            <div class="alert alert-info" style="margin:0">مبلغ بیعانه و شماره حساب واریز به‌زودی توسط کارشناس اعلام و برایتان پیامک می‌شود.</div>
        @endif
    @else
        <div class="rp-sum">
            <div><span>مبلغ {{ $order->final_amount ? 'نهایی' : '' }} سفارش</span><b>{{ money($final, true) }}</b></div>
            <div><span>پرداخت تأییدشده</span><b class="ok">{{ money($confirmed->sum('amount'), true) }}</b></div>
            @if ($due->sum('amount'))<div><span>قابل پرداخت اکنون</span><b class="due">{{ money($due->sum('amount'), true) }}</b></div>@endif
        </div>
        @if ($due->count() > 1)
            <div class="rp-multi">
                <b>⚠️ این مبلغ باید به {{ fa($due->count()) }} حساب جداگانه واریز شود</b>
                <span>هر کادر زیر یک حساب جداست؛ به هر حساب فقط همان مبلغی را که کنارش نوشته شده واریز کنید و فیش هر حساب را در کادر خودش بفرستید.</span>
                <ol>@foreach ($due as $q)<li>{{ $q->account()['holder'] }}{{ $q->account()['bank'] ? ' — '.$q->account()['bank'] : '' }}: <b>{{ money($q->amount) }} تومان</b></li>@endforeach</ol>
            </div>
        @endif
        @foreach ($due as $p)
            @php $acc = $p->account(); $r = (object) ['holder_name' => $acc['holder'], 'bank_name' => $acc['bank'], 'card_number' => $acc['card'], 'sheba' => $acc['sheba'], 'code' => $p->remittance?->code]; @endphp
            <div class="rp-card {{ $p->status }}">
                <div class="rp-h">
                    <b>@if ($due->count() > 1)<span class="rp-no">حساب {{ fa($loop->iteration) }} از {{ fa($due->count()) }}</span> @endif{{ $p->kindLabel() }}: {{ money($p->amount, true) }}</b>
                    <span class="rp-st">{{ ['awaiting' => 'منتظر واریز شما', 'submitted' => 'فیش رسید — در حال بررسی', 'rejected' => 'فیش تأیید نشد'][$p->status] ?? '' }}</span>
                </div>

                <div class="rp-acc">
                    <div><span>به نام</span><b>{{ $r->holder_name }}</b><i></i>@if ($r->bank_name)<small>بانک {{ $r->bank_name }}</small>@endif</div>
                    @if ($r->card_number)
                        <div><span>شماره کارت</span><b class="ltr">{{ fa(\App\Support\Banks::formatCard($r->card_number)) }}</b>
                            <button type="button" class="rp-copy" data-copy="{{ $r->card_number }}">کپی</button></div>
                    @endif
                    @if ($r->sheba)
                        <div><span>شبا</span><b class="ltr" style="font-size:12px">{{ \App\Support\Banks::formatSheba($r->sheba) }}</b>
                            <button type="button" class="rp-copy" data-copy="{{ $r->sheba }}">کپی</button></div>
                    @endif
                    <div><span>مبلغ</span><b>{{ money($p->amount) }} تومان</b><button type="button" class="rp-copy" data-copy="{{ $p->amount * 10 }}">کپی (ریال)</button></div>
                </div>
                @if ($p->status === 'rejected' && $p->reject_reason)
                    <div class="alert alert-err" style="margin:0">فیش قبلی تأیید نشد. علت: <b>{{ $p->reject_reason }}</b> — لطفاً فیش جایگزین را بفرستید.</div>
                @endif
                @if ($p->status === 'submitted')
                    <div class="rp-sent">
                        @foreach ($p->files() as $fi => $fp)
                            @if (\App\Models\RemitPayment::isPdfPath($fp))<a href="{{ route('order.receipt.show', [$order->number, $p->id, 'i' => $fi]) }}" target="_blank" class="rp-pdf">📄 PDF</a>
                            @else<img src="{{ route('order.receipt.show', [$order->number, $p->id, 'i' => $fi]) }}" alt="فیش" loading="lazy">@endif
                        @endforeach
                        <span>{{ fa(count($p->files())) }} فیش {{ jdate($p->submitted_at, true) }} رسید و در حال بررسی است.</span>
                    </div>
                @endif
                <details class="rp-up" @if ($p->status !== 'submitted') open @endif>
                    <summary>{{ ['submitted' => 'افزودن فیش دیگر (تا پیش از تأیید کارشناس)', 'rejected' => 'ارسال فیش جایگزین'][$p->status] ?? 'بارگذاری فیش واریزی' }}</summary>
                    <form method="post" action="{{ route('order.receipt', [$order->number, $p->id]) }}" enctype="multipart/form-data" class="rp-form">
                        @csrf
                        <label class="rp-file"><input type="file" name="receipt[]" accept="image/*,application/pdf" multiple required onchange="this.closest('label').querySelector('span').textContent=this.files.length?(this.files.length>1?this.files.length+' فیش انتخاب شد':this.files[0].name):'📷 انتخاب عکس فیش'"><span>📷 انتخاب عکس فیش (چند فیش هم می‌شود)</span></label>
                        <small class="muted">اگر مبلغ را در چند نوبت واریز کرده‌اید، عکس همه فیش‌ها را با هم انتخاب کنید.</small>
                        <button class="btn btn-block" type="submit">ارسال فیش {{ $due->count() > 1 ? 'حساب '.fa($loop->iteration).' — ' : '' }}{{ money($p->amount) }} تومانی</button>
                    </form>
                </details>
            </div>
        @endforeach
        @if ($confirmed->isNotEmpty())
            <div class="rp-done">
                @foreach ($confirmed as $p)
                    <div>✓ {{ $p->kindLabel() }} {{ money($p->amount, true) }} — تأیید {{ jdate($p->reviewed_at) }}</div>
                @endforeach
            </div>
        @endif
        @if ($errors->has('receipt'))<div class="alert alert-err" style="margin:0">{{ $errors->first('receipt') }}</div>@endif
    @endif
</div>
<style>
.rp{display:grid;gap:10px}
.rp-sum{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px}
.rp-sum div{background:var(--soft,#f4f5f8);border-radius:12px;padding:8px 12px;display:grid}.rp-sum span{font-size:12px;color:var(--muted)}
.rp-sum .ok{color:var(--ok,#16a34a)}.rp-sum .due{color:#c2410c}
.rp-card{border:1.5px solid var(--line);border-radius:16px;padding:14px;display:grid;gap:10px;background:var(--card)}
.rp-card.awaiting{border-color:#f59e0b}.rp-card.rejected{border-color:#ef4444}.rp-card.submitted{border-color:#3b82f6}
.rp-h{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center}.rp-h b{font-size:16px}
.rp-st{font-size:12px;font-weight:700;padding:2px 10px;border-radius:99px;background:#fef3c7;color:#92400e}
.rp-card.submitted .rp-st{background:#dbeafe;color:#1e40af}.rp-card.rejected .rp-st{background:#fee2e2;color:#991b1b}
.rp-acc{display:grid;gap:6px;background:var(--soft,#f4f5f8);border-radius:12px;padding:10px 12px}
.rp-acc>div{display:grid;grid-template-columns:62px 1fr auto;align-items:center;gap:8px}.rp-acc span{color:var(--muted);font-size:12px}
.rp-acc b{overflow-wrap:anywhere}.rp-acc small{grid-column:2/4;margin-top:-4px;color:var(--muted)}
.rp-acc b{font-size:15px;letter-spacing:.3px}
.rp-copy{border:1px solid var(--line);background:var(--card);border-radius:8px;padding:2px 10px;font:inherit;font-size:12px;cursor:pointer}
.rp-copy.done{background:#dcfce7;border-color:#22c55e}
.rp-sent{display:flex;gap:8px;align-items:center;flex-wrap:wrap;font-size:13px}.rp-sent img{width:56px;height:56px;object-fit:cover;border-radius:10px;border:1px solid var(--line)}
.rp-pdf{display:inline-grid;place-items:center;width:56px;height:56px;border-radius:10px;border:1px solid var(--line);font-size:12px}
.rp-multi{display:grid;gap:4px;padding:12px 14px;border-radius:14px;background:#fff7ed;border:1.5px solid #fb923c;color:#7c2d12;font-size:13.5px;line-height:1.9}
.rp-multi b{font-size:15px}.rp-multi ol{margin:2px 0 0;padding-inline-start:20px}
.rp-no{display:inline-block;background:#f97316;color:#fff;border-radius:99px;padding:1px 10px;font-size:12px;margin-inline-end:6px}
.rp-up summary{cursor:pointer;font-weight:700;color:var(--brand-ink,var(--brand))}
.rp-form{display:grid;gap:8px;margin-top:8px}.rp-row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.rp-form input[type=text]{width:100%;padding:10px 12px;border:1px solid var(--line);border-radius:12px;font:inherit;background:var(--card);color:inherit}
.rp-file{display:block;border:2px dashed var(--line);border-radius:14px;padding:16px;text-align:center;cursor:pointer;font-weight:700}
.rp-file input{display:none}.rp-file:hover{border-color:var(--brand)}
.rp-done{display:grid;gap:4px;font-size:13px;color:var(--ok,#16a34a);font-weight:600}
@media(max-width:560px){.rp-row{grid-template-columns:1fr}}
</style>
<script>
document.querySelectorAll('.rp-copy').forEach(function (b) {
    b.addEventListener('click', function () {
        var t = b.dataset.copy;
        (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).catch(function () {
            var i = document.createElement('textarea'); i.value = t; document.body.appendChild(i); i.select(); document.execCommand('copy'); i.remove();
        });
        var o = b.textContent; b.textContent = 'کپی شد ✓'; b.classList.add('done'); setTimeout(function () { b.textContent = o; b.classList.remove('done'); }, 1500);
    });
});
</script>
