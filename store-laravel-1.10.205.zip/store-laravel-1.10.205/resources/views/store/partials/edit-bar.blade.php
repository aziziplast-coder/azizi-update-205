@php
    // نوار «در ویرایش مشتری»: هنگام گشتن در سایت، زمان باقی‌مانده و دکمه ثبت تغییرات همیشه دیده شود
    $eb = null;
    if (auth()->check() && ! request()->routeIs('cart')) {
        try {
            $eb = app(\App\Services\Cart::class)->editingOrder();
            $eb = $eb && $eb->customerCanEdit() ? $eb : null;
        } catch (\Throwable $e) {
            $eb = null;
        }
    }
    $ebUntil = $eb ? \App\Services\OrderWindows::editUntil($eb) : null;
@endphp
@if ($eb)
    <div class="edit-bar" role="status">
        <div class="wrap">
            <span>✏️ {{ (int) ($eb->edit_round ?? 0) >= 2 ? 'آخرین فرصت ویرایش' : 'در حال ویرایش' }} سفارش <b>{{ fa($eb->number) }}</b>@if ($ebUntil) — <span data-eb-left data-until="{{ $ebUntil->timestamp }}">تا {{ jdate($ebUntil, true) }}</span>@endif. کالا اضافه کنید، بعد:</span>
            <a class="btn btn-sm" href="{{ route('cart') }}">سبد و ثبت تغییرات ←</a>
        </div>
    </div>
    @if ($ebUntil)
        <script>
        (function () {
            var e = document.querySelector('[data-eb-left]'); if (!e) return;
            var u = +e.getAttribute('data-until') * 1000, f = function (n) { return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; }); };
            var t = function () { var s = Math.max(0, Math.round((u - Date.now()) / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60);
                e.textContent = s > 0 ? f(h ? h + ' ساعت و ' + m + ' دقیقه' : m + ' دقیقه') + ' فرصت دارید (پایان زمان = ثبت خودکار سبد)' : 'زمان ویرایش تمام شد'; };
            t(); setInterval(t, 30000);
        })();
        </script>
    @endif
@endif
