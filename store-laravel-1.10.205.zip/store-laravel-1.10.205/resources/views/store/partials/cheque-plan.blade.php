@php
    $cfgC = \App\Services\Cheques::config();
@endphp
@if (! empty($ch['settle']))
    {{-- مشخصات نهایی که کارشناس در صدور مانده حساب اعلام کرده --}}
    @php
        $docsOn = isset($order) && \App\Services\Cheques::settleDocsNeeded($order);
        $payee = (array) ($ch['payee'] ?? []);
        $stCls = ['submitted' => 'color:#b45309', 'approved' => 'color:var(--ok,#16a34a)', 'rejected' => 'color:#b91c1c'];
        $canSend = $docsOn && ! $order->cheques_received_at && ! in_array($order->status, ['cancelled', 'failed', 'pending_payment'], true);
        $post = $ch['post'] ?? null;
    @endphp
    <div class="cheque-plan">
        <div class="cp-head">مشخصات نهایی پرداخت (نقد و چک)</div>
        @isset($order)
            <div class="cp-row"><span>پرداخت نقدی (با حواله، شامل بیعانه)</span><b>{{ money($order->cash_amount ?? 0) }} تومان</b></div>
        @endisset
        @if (! empty($payee['nid']) || ! empty($payee['name']))
            <div class="cp-row"><span>چک‌ها را در سامانه صیاد به نام <b>{{ $payee['name'] ?? '' }}</b> ثبت کنید</span><b class="ltr">{{ fa($payee['nid'] ?? '') }}</b></div>
        @endif
        @foreach ((array) $ch['settle'] as $i => $c)
            <div class="cp-row"><span>چک {{ fa($i + 1) }} — سررسید <b>{{ $c['due_fa'] ?? '' }}</b>
                @if ($docsOn)
                    @foreach (\App\Services\Cheques::DOC_TYPES as $t => $tl)
                        @php $d = $c['docs'][$t] ?? null; @endphp
                        <br><small>{{ $tl }}: <b style="{{ $stCls[$d['st'] ?? ''] ?? 'color:#b45309' }}">{{ $d ? \App\Services\Cheques::DOC_STATUS[$d['st']] : 'فرستاده نشده' }}</b>@if (($d['st'] ?? '') === 'rejected' && ! empty($d['reason'])) — {{ $d['reason'] }}@endif</small>
                    @endforeach
                @endif
                </span><b>{{ money($c['amount']) }} تومان</b></div>
        @endforeach
        @if ($docsOn && $post)
            <div class="cp-row"><span>بیجک پستی چک‌ها: <b style="{{ $stCls[$post['st']] ?? '' }}">{{ \App\Services\Cheques::DOC_STATUS[$post['st']] ?? '' }}</b>@if ($post['st'] === 'rejected' && ! empty($post['reason'])) — {{ $post['reason'] }}@endif</span><b></b></div>
        @endif
        @if (isset($order) && $order->cheques_received_at)
            <div class="cp-row" style="color:var(--ok,#16a34a)"><span>✓ چک‌ها رسید و تأیید شد</span><b>{{ jdate($order->cheques_received_at) }}</b></div>
        @else
            <small class="muted">چک‌ها را با همین مبلغ و تاریخ صادر و در سامانه صیاد ثبت کنید، سپس تصویر چک و تصویر ثبت صیاد هر چک را بفرستید.</small>
        @endif
    </div>
    @if ($canSend)
        @php
            $open = collect((array) $ch['settle'])->contains(fn ($c) => collect(array_keys(\App\Services\Cheques::DOC_TYPES))->contains(fn ($t) => ($c['docs'][$t]['st'] ?? '') !== 'approved'))
                || ($post['st'] ?? '') !== 'approved';
        @endphp
        @if ($open)
        <form method="post" action="{{ route('order.cheques', $order->number) }}" enctype="multipart/form-data" class="cheque-plan" style="display:grid;gap:10px">
            @csrf
            <div class="cp-head">ارسال تصاویر چک‌ها</div>
            @if ($cfgC['national_id'])
                <label class="field"><span>کد ملی صاحب چک (صادرکننده)</span>
                    <input name="cheque_nid" inputmode="numeric" dir="ltr" maxlength="10" value="{{ old('cheque_nid', $ch['owner_nid'] ?? '') }}" placeholder="۱۰ رقم">
                </label>
            @endif
            @foreach ((array) $ch['settle'] as $i => $c)
                <div style="display:grid;gap:6px;padding:10px;border:1px dashed var(--line);border-radius:12px">
                    <b>چک {{ fa($i + 1) }} — {{ money($c['amount']) }} تومان — {{ $c['due_fa'] ?? '' }}</b>
                    @foreach (\App\Services\Cheques::DOC_TYPES as $t => $tl)
                        @php $d = $c['docs'][$t] ?? null; @endphp
                        @if (($d['st'] ?? '') === 'approved')
                            <small style="color:var(--ok,#16a34a)">✓ {{ $tl }} تأیید شد</small>
                        @else
                            @if ($d && ! empty($d['path']) && ! str_ends_with(strtolower($d['path']), '.pdf'))
                                <img src="{{ route('order.cheque.img', [$order->number, $i, 't' => 'doc', 'k' => $t, 'v' => substr(md5($d['path']), 0, 8)]) }}" alt="" loading="lazy" style="max-width:140px;border-radius:10px;border:1px solid var(--line)">
                            @endif
                            <label class="file-pick"><input type="file" name="{{ $t }}_img[{{ $i }}]" accept="image/*,application/pdf" onchange="this.closest('label').querySelector('span').textContent=this.files[0]?this.files[0].name:'{{ $tl }}'"><span>📷 {{ $d ? 'تعویض '.$tl : $tl }}</span></label>
                            @if (($d['st'] ?? '') === 'rejected')<small style="color:#b91c1c">رد شد: {{ $d['reason'] }} — لطفاً دوباره بفرستید.</small>@endif
                        @endif
                    @endforeach
                </div>
            @endforeach
            <div style="display:grid;gap:6px;padding:10px;border:1px dashed var(--line);border-radius:12px">
                <b>تصویر بیجک پستی <small class="muted">(اگر چک‌ها را پست می‌کنید؛ می‌توانید بعداً هم بفرستید)</small></b>
                @if (($post['st'] ?? '') === 'approved')
                    <small style="color:var(--ok,#16a34a)">✓ بیجک پستی تأیید شد</small>
                @else
                    @if ($post && ! str_ends_with(strtolower($post['path'] ?? ''), '.pdf'))
                        <img src="{{ route('order.cheque.img', [$order->number, 0, 't' => 'post', 'v' => substr(md5($post['path'] ?? ''), 0, 8)]) }}" alt="" loading="lazy" style="max-width:140px;border-radius:10px;border:1px solid var(--line)">
                    @endif
                    <label class="file-pick"><input type="file" name="post_img" accept="image/*,application/pdf" onchange="this.closest('label').querySelector('span').textContent=this.files[0]?this.files[0].name:'بیجک پستی'"><span>📮 {{ $post ? 'تعویض تصویر بیجک پستی' : 'تصویر بیجک پستی' }}</span></label>
                    @if (($post['st'] ?? '') === 'rejected')<small style="color:#b91c1c">رد شد: {{ $post['reason'] }}</small>@endif
                @endif
            </div>
            @if ($errors->has('cheque_docs') || $errors->has('cheque_nid'))
                <div class="alert alert-err" style="margin:0">{{ $errors->first('cheque_docs') ?: $errors->first('cheque_nid') }}</div>
            @endif
            @if (! empty($cfgC['sayad_note']))<small class="muted">{{ $cfgC['sayad_note'] }}</small>@endif
            <button class="btn btn-block" type="submit">ارسال تصاویر</button>
        </form>
        @endif
    @endif
@else
<div class="cheque-plan">
    <div class="cp-head">شرایط پرداخت: <b>{{ $ch['plan'] ?? '' }}</b></div>
    @if (($ch['cash'] ?? null) === null && empty($ch['cheques']))
        <small class="muted">مبلغ نقد، مبلغ چک‌ها و تاریخ سررسید پس از جمع‌آوری سفارش در انبار توسط کارشناس اعلام می‌شود.</small>
    @else
        <div class="cp-row"><span>پرداخت نقدی</span><b>{{ money($ch['cash'] ?? 0) }} تومان</b></div>
        @foreach ((array) ($ch['cheques'] ?? []) as $i => $c)
            <div class="cp-row"><span>چک {{ fa($i + 1) }}@if (! empty($c['due_fa'])) — سررسید {{ $c['due_fa'] }}@endif @if (! empty($ch['docs'][$i]['sayad'])) <small class="ltr">({{ fa($ch['docs'][$i]['sayad']) }})</small>@endif</span><b>{{ money($c['amount']) }} تومان</b></div>
        @endforeach
        @if (! empty($ch['guarantee']))
            <div class="cp-row muted"><span>چک ضمانت (عودت پس از تسویه)</span><b>{{ money($ch['guarantee']) }} تومان</b></div>
        @endif
        <small class="muted">مبالغ نهایی پس از جمع‌آوری انبار توسط کارشناس اعلام می‌شود.</small>
    @endif
</div>
@endif
