@php
    $gone = array_values((array) session()->pull('cart.removed', []));
    $items = [];
    foreach (array_slice($gone, 0, 6) as $g) {
        $items[] = ['g' => $g, 'alts' => $g['left'] ? [] : \App\Services\Replacements::for($g, 3)];
    }
@endphp
@if ($items)
<div class="popup rmpop" data-rmpop role="dialog" aria-modal="true" aria-label="تغییر در سبد خرید">
    <div class="popup-bg" data-rm-close></div>
    <div class="popup-box rmpop-box">
        <button type="button" class="popup-x icon-btn" data-rm-close aria-label="بستن"><svg class="ic"><use href="#i-close"/></svg></button>
        <h3>تغییر در سبد خرید شما</h3>
        <p class="muted">موجودی این کالاها در همین فاصله تمام شد یا کم شد. برای کالاهای تمام‌شده، نزدیک‌ترین کالاها از نظر نوع و قیمت پیشنهاد شده است.</p>
        <div class="rm-list">
            @foreach ($items as $it)
                @php $g = $it['g']; @endphp
                <div class="rm-item">
                    <div class="rm-gone">
                        @if ($g['image'])<img src="{{ thumb($g['image'], 160) }}" alt="" loading="lazy">@endif
                        <div>
                            <b>{{ $g['name'] }}</b>
                            <small>@if ($g['code'])کد {{ $g['code'] }} · @endif
                                @if ($g['left'])فقط {{ fa($g['mode'] === 'retail' || $g['per_carton'] < 2 ? $g['left'] : intdiv($g['left'], max(1, $g['per_carton']))) }} {{ $g['mode'] === 'retail' || $g['per_carton'] < 2 ? 'عدد' : 'کارتن' }} موجود بود و تعداد اصلاح شد
                                @else<span class="rm-out">به پایان رسید و از سبد حذف شد</span>@endif
                            </small>
                        </div>
                    </div>
                    @if ($it['alts'])
                        <div class="rm-alts">
                            <span class="rm-alts-t"><svg class="ic"><use href="#i-swap"/></svg>پیشنهاد جایگزین:</span>
                            @foreach ($it['alts'] as $a)
                                @php $p = $a['product']; @endphp
                                <div class="rm-alt">
                                    <a href="{{ $p->url() }}" target="_blank" rel="noopener">@if ($p->image)<img src="{{ thumb($p->image, 160) }}" alt="" loading="lazy">@endif</a>
                                    <div class="rm-alt-info">
                                        <a href="{{ $p->url() }}" target="_blank" rel="noopener">{{ $p->name }}</a>
                                        <small>{{ money($p->unitPrice($a['mode'])) }} تومان هر عدد · {{ $a['label'] }}</small>
                                    </div>
                                    <button type="button" class="btn btn-sm" data-replace data-id="{{ $p->id }}" data-mode="{{ $a['mode'] }}" data-units="{{ $a['units'] }}">جایگزین کن</button>
                                </div>
                            @endforeach
                        </div>
                    @elseif (! $g['left'])
                        <p class="muted rm-none">کالای مشابهی موجود نیست.</p>
                    @endif
                </div>
            @endforeach
        </div>
        <button type="button" class="btn btn-line btn-block" data-rm-close>متوجه شدم</button>
    </div>
</div>
@endif
