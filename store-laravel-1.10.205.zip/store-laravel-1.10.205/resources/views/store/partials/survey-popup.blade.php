@php
    $__sv = null;
    try {
        $__u = auth()->user();
        if ($__u && ! request()->routeIs('checkout', 'survey', 'cart')) {
            $__ids = \Illuminate\Support\Facades\Cache::remember('survey.p.'.$__u->id, 600, function () use ($__u) {
                $p = \App\Models\Survey::pendingFor($__u);

                return $p ? [$p['survey']->id, $p['order']->id] : [0, 0];
            });
            if ($__ids[0]) {
                $__s = \App\Models\Survey::query()->find($__ids[0]);
                $__o = \App\Models\Order::query()->with('assignee')->find($__ids[1]);
                $__sv = $__s && $__o ? ['survey' => $__s, 'order' => $__o] : null;
            }
        }
    } catch (\Throwable $e) {
        $__sv = null;
    }
@endphp
@if ($__sv)
    <div class="popup survey-pop" data-survey-pop data-skip="{{ route('survey.skip', $__sv['order']->number) }}" data-sid="{{ $__sv['survey']->id }}-{{ $__sv['order']->id }}" hidden role="dialog" aria-modal="true" aria-label="{{ $__sv['survey']->title }}">
        <div class="popup-bg" data-survey-later></div>
        <div class="popup-box">
            <button type="button" class="icon-btn popup-x" data-survey-later aria-label="بعداً"><svg class="ic"><use href="#i-close"/></svg></button>
            <div class="popup-in" style="text-align:right">
                <b class="popup-title">{{ $__sv['survey']->title }}</b>
                <p class="muted" style="margin:0;font-size:13px">درباره سفارش {{ fa($__sv['order']->number) }}@if ($__sv['survey']->intro) — {{ $__sv['survey']->intro }}@endif</p>
                <div data-survey-body>@include('store.partials.survey-form', ['survey' => $__sv['survey'], 'order' => $__sv['order']])</div>
                <button type="button" class="linkish" data-survey-skip style="align-self:center;font-size:13px">نمی‌خواهم نظر بدهم</button>
            </div>
        </div>
    </div>
@endif
