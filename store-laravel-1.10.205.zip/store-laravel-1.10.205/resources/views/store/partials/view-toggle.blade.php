<div class="vtoggle" role="group" aria-label="نحوه نمایش">
    <button type="button" data-pv="list" aria-label="نمایش ردیفی" title="ردیفی"><svg class="ic"><use href="#i-list"/></svg></button>
    <button type="button" data-pv="grid2" aria-label="نمایش دوتایی" title="۲تایی"><svg class="ic"><use href="#i-grid"/></svg></button>
    <button type="button" data-pv="grid4" aria-label="نمایش چهارتایی" title="۴تایی"><svg class="ic"><use href="#i-grid4"/></svg></button>
</div>
