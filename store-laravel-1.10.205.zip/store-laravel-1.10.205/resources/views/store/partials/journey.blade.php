{{-- مراحل سفارش + «الان نوبت چیست» ($j از OrderJourney::for) --}}
@php $act = $j['action']; @endphp
<div class="jr-act jr-{{ $act['tone'] }}">
    <span class="jr-act-ic" aria-hidden="true">{{ $act['icon'] }}</span>
    <div class="jr-act-t">
        <b>{{ $act['title'] }}</b>
        @if ($act['text'])<span>{{ $act['text'] }}</span>@endif
    </div>
    @if ($act['href'] && $act['btn'])
        <a href="{{ $act['href'] }}" class="btn jr-act-btn" @if (str_contains($act['href'], 'waybill')) target="_blank" @endif>{{ $act['btn'] }}</a>
    @endif
</div>
<ol class="jr-steps" aria-label="مراحل سفارش">
    @foreach ($j['steps'] as $s)
        <li class="jr-s st-{{ $s['state'] }}" @if ($s['state'] === 'cur') aria-current="step" @endif>
            <span class="jr-dot" aria-hidden="true">@if ($s['state'] === 'done')✓@else{{ $s['icon'] }}@endif</span>
            <span class="jr-lbl">{{ $s['label'] }}@if ($s['note'])<small>{{ $s['note'] }}</small>@endif
                @if ($s['state'] === 'cur')<em>مرحله فعلی</em>@endif</span>
        </li>
    @endforeach
</ol>
