@php
    $cfg = $cheque['cfg'];
    $plans = $cheque['plans'];
    $selPlan = (int) old('cheque_plan', 0);
    $needDocs = $cheque['docs'];
@endphp
<div class="paybox cheque-box" data-pay-box="cheque" @if ($pay !== 'cheque') hidden @endif data-cheque data-docs="{{ $needDocs }}">
    <div class="field">
        <span>شرایط پرداخت</span>
        <div class="choices col plan-list" role="radiogroup" aria-label="شرایط پرداخت چکی">
            @foreach ($plans as $i => $pl)
                <label class="choice">
                    <input type="radio" name="cheque_plan" value="{{ $i }}" @checked($selPlan === $i) data-plan data-count="{{ $pl['count'] }}" data-guarantee="{{ $pl['guarantee'] ? 1 : 0 }}">
                    <span class="dot"></span>
                    <span><b>{{ $pl['title'] }}</b>
                        @if ($cfg['show_calc'])
                            @php $bits = array_filter([
                                $pl['cash'] !== null ? fa($pl['cash']).'٪ نقد' : null,
                                $pl['count'] ? fa($pl['count']).' فقره چک' : null,
                                $pl['count'] && $pl['first'] !== null ? 'اولین چک '.fa($pl['first']).' روزه' : null,
                                $pl['count'] > 1 && $pl['interval'] !== null ? 'فاصله چک‌ها '.fa($pl['interval']).' روز' : null,
                                $pl['guarantee'] ? '+ چک ضمانت' : null,
                            ]); @endphp
                            @if ($bits)<small>{{ implode(' — ', $bits) }}</small>@endif
                        @endif
                        @if ($pl['desc'])<small>{{ $pl['desc'] }}</small>@endif
                    </span>
                </label>
            @endforeach
        </div>
        @error('cheque_plan')<span class="err-text">{{ $message }}</span>@enderror
    </div>

    @if ($cfg['show_calc'] && \App\Services\Cheques::calcOn())
        <div class="cheque-plan" data-plan-preview aria-live="polite"></div>
    @else
        <small class="muted">مبلغ نقد، مبلغ چک‌ها و تاریخ سررسید پس از جمع‌آوری سفارش در انبار توسط کارشناس اعلام می‌شود.</small>
    @endif

    @if ($cfg['guarantee_on'] && ! empty($cfg['guarantee_text']))
        <details class="cheque-note"><summary>چک ضمانت چیست؟</summary><p>{{ $cfg['guarantee_text'] }}</p></details>
    @endif
    @if (! empty($cfg['sayad_note']))
        <div class="alert alert-info" style="margin:0">{{ $cfg['sayad_note'] }}</div>
    @endif

    @if ($cheque['review'])
        <div class="alert alert-warn" style="margin:0">سفارش چکی شما پس از بررسی و استعلام چک توسط کارشناس تأیید و ارسال می‌شود؛ نتیجه با پیامک اطلاع داده می‌شود.</div>
    @endif
</div>
