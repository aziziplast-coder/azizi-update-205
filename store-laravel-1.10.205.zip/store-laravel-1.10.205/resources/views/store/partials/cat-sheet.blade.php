@php $tree = \App\Models\Category::tree(); @endphp
@if ($tree)
<div class="csheet" data-cats aria-hidden="true" hidden>
    <div class="csheet-bg" data-cats-close></div>
    <section class="csheet-panel" role="dialog" aria-modal="true" aria-label="دسته‌بندی کالاها">
        <header class="csheet-head">
            <b>دسته‌بندی کالاها</b>
            <a href="{{ route('shop') }}" class="csheet-all">همه محصولات</a>
            <button type="button" class="icon-btn" data-cats-close aria-label="بستن"><svg class="ic"><use href="#i-close"/></svg></button>
        </header>
        <div class="csheet-body">
            <nav class="csheet-roots" aria-label="دسته‌های اصلی">
                @foreach ($tree as $i => $root)
                    <button type="button" data-cat-root="{{ $i }}" @class(['on' => $i === 0])>
                        @if ($root['icon'])<img src="{{ $root['icon'] }}" alt="" loading="lazy" width="34" height="34">@else<span class="ph">{{ mb_substr($root['name'], 0, 1) }}</span>@endif
                        <span>{{ $root['name'] }}</span>
                    </button>
                @endforeach
            </nav>
            <div class="csheet-subs">
                @foreach ($tree as $i => $root)
                    <div data-cat-sub="{{ $i }}" @if ($i) hidden @endif>
                        <a class="csheet-root-link" href="{{ $root['url'] }}">همه کالاهای {{ $root['name'] }} <small>{{ fa($root['n']) }}</small><svg class="ic"><use href="#i-chev"/></svg></a>
                        @if ($root['children'])
                            <div class="csheet-grid">
                                @foreach ($root['children'] as $ch)
                                    <div class="csheet-group">
                                        <a class="csheet-card" href="{{ $ch['url'] }}">
                                            @if ($ch['icon'])<img src="{{ $ch['icon'] }}" alt="" loading="lazy" width="52" height="52">@else<span class="ph">{{ mb_substr($ch['name'], 0, 1) }}</span>@endif
                                            <span>{{ $ch['name'] }}</span>
                                        </a>
                                        @if ($ch['children'])
                                            <div class="csheet-leaves">@foreach ($ch['children'] as $g)<a href="{{ $g['url'] }}">{{ $g['name'] }}</a>@endforeach</div>
                                        @endif
                                    </div>
                                @endforeach
                            </div>
                        @endif
                    </div>
                @endforeach
            </div>
        </div>
    </section>
</div>
@endif
