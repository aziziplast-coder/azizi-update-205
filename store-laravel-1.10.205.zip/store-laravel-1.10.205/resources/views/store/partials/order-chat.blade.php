@php
    $chatOn = \App\Services\Chat::enabled() && $order->user_id && auth()->id() === (int) $order->user_id;
    if ($chatOn) {
        $ct = \App\Services\Chat::thread($order, false);
        $staffU = $order->assignee_id ? \App\Models\User::query()->find($order->assignee_id) : null;
        $sName = $staffU ? \App\Services\Chat::firstName($staffU) : null;
        $closed = $ct ? \App\Services\Chat::closed($ct, $order) : \App\Services\Chat::closed(new \App\Models\ChatThread(), $order);
        // سفارش قدیمیِ تمام‌شده که هیچ‌وقت گفتگو نداشته: کارت نشان داده نشود
        $chatOn = $ct && $ct->last_id ? true : ! $closed;
    }
@endphp
@if ($chatOn)
    @push('head')<link rel="stylesheet" href="{{ asset('css/chat.css') }}?v={{ config('store.version') }}">@endpush
    @php
        $chatCfg = [
            'csrf' => csrf_token(), 'state' => route('order.chat', $order->number), 'act' => route('order.chat.act', $order->number), 'typing' => url('chat-t.php'),
            'pay' => route('order.chat.pay', $order->number), 'cheque' => route('order.chat.cheque', $order->number), 'up' => route('order.chat.up', $order->number), 'mb' => asset('js/vendor/mediabunny.min.js'),
            'sig' => $ct ? \App\Services\Chat::signalUrl($ct) : null, 'last' => (int) ($ct->customer_read_id ?? 0), 'unread' => (int) ($ct->unread_customer ?? 0),
            'initial' => $sName ? mb_substr($sName, 0, 1) : '💬', 'phone' => setting('phone') ? en_digits((string) setting('phone')) : null,
        ];
    @endphp
    <div id="chat" data-chat="{{ json_encode($chatCfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) }}" style="scroll-margin-top:90px">
        <button type="button" class="chc-card">
            <span class="ch-av">{{ $sName ? mb_substr($sName, 0, 1) : '💬' }}</span>
            <div>
                <b>{{ $sName ? 'گفتگو با '.$sName.' از '.store_name() : 'گفتگو درباره این سفارش' }}</b>
                <small>
                    @if ($ct && $ct->last_text){{ $ct->last_side === 'c' ? 'شما: ' : '' }}{{ $ct->last_text }}
                    @elseif ($sName){{ $sName }}، مسئول پیگیری سفارش شما، همین‌جا پاسخ می‌دهد
                    @else سؤالی دارید؟ بپرسید؛ به‌زودی یکی از همکاران پاسخ می‌دهد
                    @endif
                </small>
            </div>
            <span class="go">💬 {{ $ct && $ct->last_id ? 'باز کردن' : 'شروع گفتگو' }}@if ($ct && $ct->unread_customer)<em>{{ fa(min(9, $ct->unread_customer)) }}</em>@endif</span>
        </button>
    </div>
    @push('scripts')
    <script src="{{ asset('js/chat.js') }}?v={{ config('store.version') }}"></script>
    <script>StoreChat.customer(document.getElementById('chat'));</script>
    @endpush
@endif
