<div class="badges">
    @if (setting('enamad_code'))<div>{!! setting('enamad_code') !!}</div>@endif
    @if (setting('samandehi_code'))<div>{!! setting('samandehi_code') !!}</div>@endif
    @foreach ((array) setting('badges', []) as $b)
        @if (! empty($b['image']))
            @if (! empty($b['url']))
                <a href="{{ $b['url'] }}" target="_blank" rel="noopener" title="{{ $b['title'] ?? '' }}"><img src="{{ upload_url($b['image']) }}" alt="{{ $b['title'] ?? '' }}" loading="lazy"></a>
            @else
                <span title="{{ $b['title'] ?? '' }}"><img src="{{ upload_url($b['image']) }}" alt="{{ $b['title'] ?? '' }}" loading="lazy"></span>
            @endif
        @endif
    @endforeach
    @if (! setting('enamad_code') && ! setting('samandehi_code') && ! setting('badges'))
        <span class="ph">نماد اینماد</span><span class="ph">ساماندهی</span>
    @endif
</div>
