@php
    $hc = array_values(array_filter((array) setting('checkout_contacts', []), fn ($c) => trim((string) ($c['phone'] ?? '')) !== ''));
@endphp
@if ($hc)
    <div class="help-box">
        <b>{{ setting('checkout_help_title', 'سؤالی دارید؟') }}</b>
        @foreach ($hc as $c)
            @php $num = preg_replace('/[^\d+]/', '', en_digits($c['phone'])); $mob = mobile($c['phone']); @endphp
            <div class="help-row">
                <span>{{ ($c['title'] ?? '') ?: 'پشتیبانی' }}@if (! empty($c['hours']))<small>{{ $c['hours'] }}</small>@endif</span>
                <span class="help-acts">
                    <a href="tel:{{ $num }}" class="btn btn-line btn-sm" dir="ltr">📞 {{ fa($c['phone']) }}</a>
                    @if (! empty($c['whatsapp']) && $mob)<a href="https://wa.me/98{{ substr($mob, 1) }}" target="_blank" rel="noopener" class="btn btn-line btn-sm" aria-label="واتس‌اپ">💬</a>@endif
                </span>
            </div>
        @endforeach
    </div>
@endif
