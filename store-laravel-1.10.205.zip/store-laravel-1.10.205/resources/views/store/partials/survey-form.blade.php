{{-- فرم نظرسنجی: $survey و $order --}}
<form method="post" action="{{ route('survey.submit', $order->number) }}" class="survey-form" data-survey-form>
    @csrf
    <input type="hidden" name="survey" value="{{ $survey->id }}">
    @foreach ($survey->items() as $q)
        <fieldset class="sq">
            <legend>{{ $q['label'] }}@if ($q['staff'] && $order->assignee) <small>({{ $order->assignee->displayName() }})</small>@endif @if (! $q['required'])<small>(اختیاری)</small>@endif</legend>
            @switch($q['type'])
                @case('rating')
                    <div class="sv-stars" role="radiogroup">
                        @for ($i = 5; $i >= 1; $i--)
                            <input type="radio" id="s-{{ $q['key'] }}-{{ $i }}" name="a[{{ $q['key'] }}]" value="{{ $i }}" @checked(old('a.'.$q['key']) == $i)>
                            <label for="s-{{ $q['key'] }}-{{ $i }}" title="{{ fa($i) }} از ۵">★</label>
                        @endfor
                    </div>
                    @break
                @case('yesno')
                    <div class="pills">
                        <label><input type="radio" name="a[{{ $q['key'] }}]" value="بله"><span>بله</span></label>
                        <label><input type="radio" name="a[{{ $q['key'] }}]" value="خیر"><span>خیر</span></label>
                    </div>
                    @break
                @case('choice')
                    <div class="pills">
                        @foreach ($q['options'] as $op)
                            <label><input type="radio" name="a[{{ $q['key'] }}]" value="{{ $op }}"><span>{{ $op }}</span></label>
                        @endforeach
                    </div>
                    @break
                @default
                    <textarea name="a[{{ $q['key'] }}]" rows="2">{{ old('a.'.$q['key']) }}</textarea>
            @endswitch
        </fieldset>
    @endforeach
    <label class="field"><span>پیشنهاد یا توضیح شما <small>(اختیاری)</small></span><textarea name="comment" rows="2">{{ old('comment') }}</textarea></label>
    <span class="err-text" data-survey-err hidden></span>
    <button type="submit" class="btn btn-block">ثبت نظر</button>
</form>
