@php
    /** @var \App\Models\Product $p */
    $carton = $p->cartonAvailable();
    $retail = $p->retailAvailable();
    $out = ! $carton && ! $retail;
    $off = $p->discountPercent();
@endphp
<article class="pcard{{ $out ? ' is-out' : '' }}" data-p='@json($p->buyData())'>
    <a href="{{ $p->url() }}" class="pimg" tabindex="-1" aria-hidden="true">
        @if ($p->image)
            <img src="{{ thumb($p->image, 480) }}" alt="" loading="lazy" decoding="async" width="480" height="480">
        @else
            <span class="noimg"><svg class="ic" style="width:40px;height:40px"><use href="#i-image"/></svg></span>
        @endif
        @if ($out)<span class="badge badge-dark">ناموجود</span>@elseif ($off)<span class="badge">{{ fa($off) }}٪</span>@endif
        @if (! $out && ($cb = \App\Models\ProductCollection::badgeFor($p)))<span class="cbadge" style="--bc:{{ $cb['color'] }}">{{ $cb['text'] }}</span>@endif
    </a>
    <div class="pbody">
        @if ($p->category)<small class="pcat">{{ $p->category->name }}</small>@endif
        <a href="{{ $p->url() }}" class="pname">{{ $p->name }}</a>
        <div class="pprice">
            @if ($off && ! $out)<del>{{ money($p->compare_price) }}</del>@endif
            <b><span data-price>{{ money($carton || ! $retail ? $p->price : $p->unitPrice('retail')) }}</span> تومان</b>
            <small>/ هر {{ $p->unitName() }}</small>
        </div>
        @if ($ruleText = $p->buyRuleText())
            <span class="chip"><svg class="ic"><use href="#i-box"/></svg>{{ $ruleText }}</span>
        @elseif ($p->hasCartons())
            <span class="chip"><svg class="ic"><use href="#i-box"/></svg>{{ $p->cartonText() }}</span>
        @endif
        @if ($carton && $retail)
            <div class="seg" role="radiogroup" aria-label="نوع خرید">
                <button type="button" role="radio" data-mode="carton" aria-checked="true">کارتنی</button>
                <button type="button" role="radio" data-mode="retail" aria-checked="false">خرده</button>
            </div>
        @endif
        <div class="pbuy">
            @if ($out)
                <a href="{{ $p->url() }}#notify" class="btn btn-line">خبرم کن وقتی موجود شد</a>
            @else
                <div class="buy-add">
                    <button type="button" class="btn" data-act="add"><svg class="ic"><use href="#i-bag"/></svg>افزودن به سبد</button>
                </div>
                <div class="buy-in" hidden>
                    <button type="button" data-act="in-plus" aria-label="یکی بیشتر">+</button>
                    <span><b data-in>۰</b> <i data-unit>{{ $p->buyRule()[2] ? $p->unitName() : $p->cartonUnit() }}</i> <i>در سبد</i></span>
                    <button type="button" data-act="in-minus" aria-label="یکی کمتر">−</button>
                </div>
            @endif
        </div>
    </div>
</article>
