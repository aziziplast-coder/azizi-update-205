        <h2 style="margin:0;font-size:18px">خلاصه سبد</h2>
        <dl class="sum">
            @if ($totals['discount'])
                <div><dt>قیمت کالاها</dt><dd>{{ money($totals['items'] + $totals['discount']) }}</dd></div>
                <div class="neg"><dt>سود شما از خرید</dt><dd>− {{ money($totals['discount']) }}</dd></div>
            @endif
            <div><dt>جمع کالاها</dt><dd>{{ money($totals['items']) }}</dd></div>
            @if (! empty($totals['coupon_discount']))
                <div class="neg"><dt>کد تخفیف {{ $totals['coupon']['coupon']->code }}</dt><dd>− {{ money($totals['coupon_discount']) }}</dd></div>
            @endif
            @foreach ($totals['fees'] as $fee)
                <div><dt>{{ $fee['title'] }}</dt><dd>{{ money($fee['amount']) }}</dd></div>
            @endforeach
            <div><dt>هزینه ارسال</dt><dd class="muted">{{ ! empty($totals['free_shipping']) ? 'رایگان (کد تخفیف)' : 'در مرحله بعد' }}</dd></div>
            <div class="grand"><dt>جمع کل</dt><dd>{{ money($totals['total']) }} تومان</dd></div>
        </dl>
        @php $cp = $totals['coupon'] ?? null; @endphp
        <form class="coupon" method="post" action="{{ route('cart.coupon') }}" data-coupon>
            @csrf
            @if ($cp && $cp['ok'])
                <div class="coupon-on"><svg class="ic"><use href="#i-tag"/></svg><span><b>{{ $cp['coupon']->code }}</b> — {{ $cp['coupon']->describe() }}</span>
                    <button type="submit" name="remove" value="1" class="linkish">حذف</button></div>
            @else
                @if ($cp && ! $cp['ok'])<span class="err-text">{{ $cp['msg'] }}</span>@endif
                <label class="coupon-row"><span class="sr">کد تخفیف</span><input name="code" placeholder="کد تخفیف دارید؟" autocomplete="off" dir="ltr" value="{{ $cp && ! $cp['ok'] ? \App\Services\Coupons::current() : '' }}"><button class="btn btn-line" type="submit">اعمال</button></label>
            @endif
        </form>
        @php $editing = $editing ?? null; @endphp
        @if ($editing)
            <div class="alert alert-info" style="margin:0"><span>در حال ویرایش سفارش <b>{{ fa($editing->number) }}</b> — نشانی، شیوه ارسال و تسویه همان قبلی می‌ماند.@if ($eu = \App\Services\OrderWindows::editUntil($editing))<br>⏰ تا <b>{{ jdate($eu, true) }}</b> فرصت دارید؛ برای افزودن کالا در سایت بچرخید و در پایان «ثبت تغییرات سفارش» را بزنید. با تمام شدن زمان، هرچه در سبد باشد خودکار در سفارش ثبت می‌شود.@endif</span></div>
            @if ($min > 0 && $totals['items'] < $min)
                <div class="alert alert-warn min-alert" role="alert"><span>مجموع کل مبلغ سفارش شما باید بالای <b>{{ money($min, true) }}</b> باشد؛ <b>{{ money($min - $totals['items'], true) }}</b> دیگر اضافه کنید.</span></div>
            @else
                <form method="post" action="{{ route('order.amend', $editing->number) }}">@csrf<button class="btn btn-lg btn-block" type="submit">ثبت تغییرات سفارش</button></form>
            @endif
            <form method="post" action="{{ route('order.edit.cancel') }}">@csrf<button class="btn btn-line btn-block" type="submit">انصراف از ویرایش</button></form>
        @elseif ($min > 0 && $totals['items'] < $min)
            <div class="alert alert-warn min-alert" role="alert"><svg class="ic"><use href="#i-bell"/></svg><span>حداقل مبلغ سفارش <b>{{ money($min, true) }}</b> است؛ <b>{{ money($min - $totals['items'], true) }}</b> دیگر به سبد اضافه کنید.</span></div>
            <div class="minbar" aria-hidden="true"><i style="width:{{ min(100, (int) round($totals['items'] * 100 / $min)) }}%"></i></div>
            @if ($canOrder)
                <button type="button" class="btn btn-lg btn-block" data-min-block>ادامه و ثبت سفارش</button>
                <dialog class="min-dlg" data-min-dlg>
                    <div class="min-dlg-ic"><svg class="ic"><use href="#i-bell"/></svg></div>
                    <p>مجموع کل مبلغ سفارش شما باید بالای <b>{{ money($min, true) }}</b> باشد.</p>
                    <p class="muted">برای ادامه، <b>{{ money($min - $totals['items'], true) }}</b> دیگر کالا به سبد اضافه کنید.</p>
                    <form method="dialog" class="min-dlg-btns">
                        <a href="{{ route('shop') }}" class="btn">ادامه خرید</a>
                        <button class="btn btn-line" value="close">متوجه شدم</button>
                    </form>
                </dialog>
            @endif
            <a href="{{ route('shop') }}" class="btn btn-lg btn-block btn-line">ادامه خرید</a>
        @elseif ($canOrder)
            <a href="{{ route('checkout') }}" class="btn btn-lg btn-block">ادامه و ثبت سفارش</a>
        @endif
        @guest<p class="muted" style="margin:0;font-size:13px;text-align:center">برای ثبت سفارش با شماره موبایل وارد می‌شوید.</p>@endguest
        @include('store.partials.help-contacts')
