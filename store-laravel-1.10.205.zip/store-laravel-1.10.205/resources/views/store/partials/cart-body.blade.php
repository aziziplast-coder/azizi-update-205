@if ($lines->isEmpty())
    <div class="empty">
        <svg class="ic"><use href="#i-bag"/></svg>
        <span>سبد خرید شما خالی است.</span>
        <a href="{{ route('shop') }}" class="btn">مشاهده محصولات</a>
    </div>
@else
<div class="split">
    <section class="split-main">
        @php
            $cartonsN = $lines->filter(fn ($l) => ! $l->retail && $l->product->hasCartons())->sum('cartons');
            $unitsN = $lines->sum('units');
        @endphp
        <div class="cart-head">
            <div class="cart-head-t"><b>سبد خرید شما</b><span class="muted"><b data-cart-n>{{ fa($lines->count()) }}</b> قلم · {{ $cartonsN ? fa($cartonsN).' کارتن · ' : '' }}{{ fa($unitsN) }} عدد</span></div>
            @if ($lines->count() > 6)<input type="search" placeholder="جستجو با نام یا کد…" data-cart-filter aria-label="جستجو در سبد">@endif
        </div>
        <div class="card cart-lines" data-cart-lines>
            @foreach ($lines as $l)
                @include('store.partials.cart-line')
            @endforeach
        </div>
        <a href="{{ route('shop') }}" class="btn btn-line" style="align-self:flex-start">→ ادامه خرید</a>
    </section>
    <aside class="split-side card" aria-label="خلاصه سبد" data-cart-summary>
@include('store.partials.cart-summary')
    </aside>
</div>
@endif
