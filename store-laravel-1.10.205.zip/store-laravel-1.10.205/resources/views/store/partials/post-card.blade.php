<article class="post-card">
    <a href="{{ $post->url() }}" class="post-img" tabindex="-1" aria-hidden="true">@if ($post->image)<img src="{{ thumb($post->image, 480) }}" alt="" loading="lazy" width="480" height="270">@else<span class="noimg"><svg class="ic"><use href="#i-image"/></svg></span>@endif</a>
    <div class="post-body">
        @if ($post->category)<a class="post-cat" href="{{ $post->category->url() }}">{{ $post->category->name }}</a>@endif
        <a href="{{ $post->url() }}" class="post-title">{{ $post->title }}</a>
        <p>{{ $post->summary(120) }}</p>
        <small class="muted">{{ jdate($post->published_at ?? $post->created_at) }} · {{ fa($post->readingMinutes()) }} دقیقه مطالعه</small>
    </div>
</article>
