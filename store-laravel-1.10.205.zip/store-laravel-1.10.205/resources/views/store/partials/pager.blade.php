@if ($paginator->hasPages())
<nav class="pager" aria-label="صفحه‌ها">
    @if ($paginator->onFirstPage())<span class="dis">›</span>@else<a href="{{ $paginator->previousPageUrl() }}" aria-label="قبلی">›</a>@endif
    @php $cur = $paginator->currentPage(); $last = $paginator->lastPage(); @endphp
    @foreach (range(1, $last) as $i)
        @if ($i === 1 || $i === $last || abs($i - $cur) <= 2)
            @if ($i === $cur)<span class="on" aria-current="page">{{ fa($i) }}</span>@else<a href="{{ $paginator->url($i) }}">{{ fa($i) }}</a>@endif
        @elseif ($i === 2 || $i === $last - 1)<span class="dis">…</span>@endif
    @endforeach
    @if ($paginator->hasMorePages())<a href="{{ $paginator->nextPageUrl() }}" aria-label="بعدی">‹</a>@else<span class="dis">‹</span>@endif
</nav>
@endif
