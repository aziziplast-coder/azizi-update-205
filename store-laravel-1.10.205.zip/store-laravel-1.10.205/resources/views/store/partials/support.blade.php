@php
    $contacts = \App\Support\Contact::items();
    $iconOf = ['whatsapp' => 'whatsapp', 'telegram' => 'telegram', 'instagram' => 'instagram', 'phone' => 'phone', 'sms' => 'sms', 'email' => 'mail', 'link' => 'chat', 'eitaa' => 'chat', 'bale' => 'chat', 'rubika' => 'chat'];
    $side = setting('support_position', 'left') === 'right' ? 'right' : 'left';
@endphp
@if ($contacts)
<div class="sup sup-{{ $side }}{{ setting('support_pulse', true) ? ' sup-pulse' : '' }}" data-support data-msg="{{ setting('support_message') }}">
    @if (count($contacts) === 1)
        @php $c = $contacts[0]; @endphp
        <a class="sup-fab" href="{{ $c['url'] }}" data-sup-link data-type="{{ $c['type'] }}" @if ($c['external']) target="_blank" rel="noopener" @endif aria-label="{{ $c['label'] }}" style="--c:{{ $c['color'] }}">
            <svg class="ic"><use href="#i-{{ $iconOf[$c['type']] }}"/></svg>
            <span class="sup-tip">{{ $c['label'] }}</span>
        </a>
    @else
        <div class="sup-panel" role="dialog" aria-label="{{ setting('support_title') }}" hidden>
            <div class="sup-head">
                <span class="sup-head-ic"><svg class="ic"><use href="#i-headset"/></svg></span>
                <div><b>{{ setting('support_title') ?: 'پشتیبانی' }}</b>@if (setting('support_text'))<small>{{ setting('support_text') }}</small>@endif</div>
                <button type="button" class="sup-x" data-sup-close aria-label="بستن"><svg class="ic"><use href="#i-close"/></svg></button>
            </div>
            <div class="sup-list">
                @foreach ($contacts as $c)
                    <a href="{{ $c['url'] }}" class="sup-item" data-sup-link data-type="{{ $c['type'] }}" @if ($c['external']) target="_blank" rel="noopener" @endif style="--c:{{ $c['color'] }}">
                        @if ($c['avatar'])
                            <span class="sup-av"><img src="{{ thumb($c['avatar'], 160) }}" alt="" loading="lazy"><i><svg class="ic"><use href="#i-{{ $iconOf[$c['type']] }}"/></svg></i></span>
                        @else
                            <span class="sup-ic"><svg class="ic"><use href="#i-{{ $iconOf[$c['type']] }}"/></svg></span>
                        @endif
                        <span class="sup-txt"><b>{{ $c['label'] }}</b><small>{{ $c['note'] ?: \App\Support\Contact::types()[$c['type']]['label'] }}</small></span>
                        <svg class="ic sup-go"><use href="#i-chev"/></svg>
                    </a>
                @endforeach
            </div>
        </div>
        <button type="button" class="sup-fab" data-sup-toggle aria-expanded="false" aria-label="{{ setting('support_title') ?: 'پشتیبانی' }}">
            <svg class="ic sup-open"><use href="#i-chat"/></svg>
            <svg class="ic sup-close"><use href="#i-close"/></svg>
        </button>
    @endif
</div>
@endif
