@extends('layouts.store', ['title' => 'ارسال و پرداخت', 'noindex' => true])

@section('content')
<main class="wrap page tight">
    <ol class="steps" aria-label="مراحل خرید"><li class="done"><a href="{{ route('cart') }}" style="color:inherit">۱. سبد خرید ✓</a></li><li>—</li><li class="cur">۲. ارسال و پرداخت</li><li>—</li><li>۳. پایان</li></ol>
    @if ($errors->any())
        <div class="alert alert-err">{{ $errors->first('cart') ?: ($errors->first('terms') ?: ($errors->first('payment') ?: ($errors->first('cheque_docs') ?: ($errors->first('cheque_plan') ?: ($errors->first('cheque_nid') ?: ($errors->first('freight_name') ?: 'لطفاً خطاهای فرم را بررسی کنید.')))))) }}</div>
    @endif
    <form method="post" action="{{ route('checkout.place') }}" class="split" enctype="multipart/form-data" data-checkout data-summary="{{ route('checkout.summary') }}" data-track="{{ route('checkout.track') }}" data-cheque-url="{{ route('checkout.cheque') }}" @if ($cfText = \App\Services\Checkout::confirmText()) data-confirm-place="{{ $cfText }}" data-cart-url="{{ route('cart') }}" @endif>
        @csrf
        <section class="split-main">
            <div class="card" style="display:flex;flex-direction:column;gap:14px">
                <h2 style="margin:0">اطلاعات گیرنده</h2>
                <div class="verified"><svg class="ic"><use href="#i-check"/></svg>موبایل {{ fa($user->mobile) }} تأیید شده است</div>
                @php
                    $cf = \App\Support\CheckoutFields::base();
                    $opt = fn ($k) => $cf[$k]['mode'] === 'optional' ? ' <small>(اختیاری)</small>' : '';
                    $req = fn ($k) => $cf[$k]['mode'] === 'required';
                    $show = fn ($k) => $cf[$k]['mode'] !== 'hidden';
                @endphp
                <div class="grid-2">
                    @if ($show('name'))<label class="field"><span>{{ $cf['name']['label'] }}{!! $opt('name') !!}</span><input name="name" value="{{ old('name', $user->name) }}" @required($req('name')) autocomplete="name">@error('name')<span class="err">{{ $message }}</span>@enderror</label>@endif
                    @if ($show('company'))<label class="field"><span>{{ $cf['company']['label'] }}{!! $opt('company') !!}</span><input name="company" value="{{ old('company', $user->company) }}" @required($req('company')) autocomplete="organization">@error('company')<span class="err">{{ $message }}</span>@enderror</label>@endif
                    @if ($show('province'))
                    <label class="field"><span>{{ $cf['province']['label'] }}{!! $opt('province') !!}</span>
                        <select name="province" @required($req('province'))>
                            <option value="">انتخاب کنید</option>
                            @foreach ($provinces as $pv)<option @selected(old('province', $user->province) === $pv)>{{ $pv }}</option>@endforeach
                        </select>@error('province')<span class="err">{{ $message }}</span>@enderror
                    </label>
                    @endif
                    @if ($show('city'))<label class="field"><span>{{ $cf['city']['label'] }}{!! $opt('city') !!}</span><input name="city" value="{{ old('city', $user->city) }}" @required($req('city'))>@error('city')<span class="err">{{ $message }}</span>@enderror</label>@endif
                </div>
                @if ($show('address'))<label class="field"><span>{{ $cf['address']['label'] }}{!! $opt('address') !!}</span><textarea name="address" rows="2" @required($req('address')) autocomplete="street-address">{{ old('address', $user->address) }}</textarea>@error('address')<span class="err">{{ $message }}</span>@enderror</label>@endif
                <div class="grid-2">
                    @if ($show('postal_code'))<label class="field"><span>{{ $cf['postal_code']['label'] }}{!! $opt('postal_code') !!}</span><input name="postal_code" inputmode="numeric" dir="ltr" value="{{ old('postal_code', $user->postal_code) }}" @required($req('postal_code'))>@error('postal_code')<span class="err">{{ $message }}</span>@enderror</label>@endif
                    @if ($show('note'))<label class="field"><span>{{ $cf['note']['label'] }}{!! $opt('note') !!}</span><input name="note" value="{{ old('note') }}" placeholder="مثلاً زمان تحویل" @required($req('note'))>@error('note')<span class="err">{{ $message }}</span>@enderror</label>@endif
                    @foreach (\App\Support\CheckoutFields::extra() as $xf)
                        <label class="field @if ($xf['type'] === 'textarea') span-2 @endif"><span>{{ $xf['label'] }}@unless ($xf['required'])<small>(اختیاری)</small>@endunless</span>
                            @if ($xf['type'] === 'textarea')
                                <textarea name="xf[{{ $xf['key'] }}]" rows="2" @required($xf['required'])>{{ old('xf.'.$xf['key']) }}</textarea>
                            @elseif ($xf['type'] === 'select')
                                <select name="xf[{{ $xf['key'] }}]" @required($xf['required'])><option value="">انتخاب کنید</option>@foreach ($xf['options'] as $o)<option @selected(old('xf.'.$xf['key']) === $o)>{{ $o }}</option>@endforeach</select>
                            @else
                                <input name="xf[{{ $xf['key'] }}]" value="{{ old('xf.'.$xf['key']) }}" @required($xf['required']) @if ($xf['type'] === 'number') inputmode="numeric" dir="ltr" @endif @if ($xf['type'] === 'date') placeholder="۱۴۰۵/۰۷/۲۰" dir="ltr" @endif>
                            @endif
                            @if ($xf['help'])<small class="muted">{{ $xf['help'] }}</small>@endif
                            @error('xf.'.$xf['key'])<span class="err">{{ $message }}</span>@enderror
                        </label>
                    @endforeach
                </div>
                @if (! empty($messenger['enabled']))
                    <label class="field messenger-field">
                        <span>{{ ($messenger['label'] ?? '') ?: 'شماره پیام‌رسان' }} @unless (! empty($messenger['required']))<small>(اختیاری)</small>@endunless</span>
                        <input name="messenger" inputmode="numeric" dir="ltr" value="{{ old('messenger', $user->messenger ?: $user->mobile) }}" placeholder="09xxxxxxxxx" @required(! empty($messenger['required']))>
                        @if (! empty($messenger['help']))<small class="muted">{{ $messenger['help'] }}</small>@endif
                        @error('messenger')<span class="err">{{ $message }}</span>@enderror
                    </label>
                @endif
            </div>

            <div class="card" style="display:flex;flex-direction:column;gap:12px">
                <h2 style="margin:0">شیوه ارسال بار</h2>
                @error('shipping')<span class="err-text">{{ $message }}</span>@enderror
                <div class="choices" role="radiogroup" aria-label="شیوه ارسال">
                    @foreach ($ships as $s)
                        @php $cost = \App\Services\Checkout::shippingCost($s, $itemsTotal); @endphp
                        <label class="choice">
                            <input type="radio" name="shipping" value="{{ $s['id'] }}" @checked($ship === $s['id']) required data-freight="{{ ! empty($s['freight']) ? 1 : 0 }}">
                            <span class="dot"></span>
                            <span><b>{{ $s['title'] }}</b>@if (! empty($s['desc']))<small>{{ $s['desc'] }}</small>@endif
                                @if ($s['free_above'] > 0 && $cost > 0)<small>رایگان برای سفارش بالای {{ money($s['free_above']) }}</small>@endif</span>
                            @if ($s['collect'] || $cost)<em>{{ \App\Services\Checkout::shippingText($s, $itemsTotal) }}{{ ! $s['collect'] && $cost ? ' تومان' : '' }}</em>@endif
                        </label>
                    @endforeach
                </div>
                @php $hasFreight = collect($ships)->contains(fn ($s) => ! empty($s['freight'])); @endphp
                @if ($hasFreight)
                    <div class="paybox freight-box" data-freight-box @if (empty($ships[$ship]['freight'])) hidden @endif>
                        @php $fm = $ships[$ship] ?? collect($ships)->first(fn ($s) => ! empty($s['freight'])); @endphp
                        <label class="field"><span>نام باربری مورد نظر شما</span>
                            <input name="freight_name" value="{{ old('freight_name') }}" placeholder="مثلاً باربری ایران‌پیما" data-freight-name>
                        </label>
                        <label class="check"><input type="checkbox" name="freight_any" value="1" @checked(old('freight_any')) data-freight-any> <span>باربری خاصی نمی‌شناسم؛ با هر باربری که به مقصد من بار می‌برد ارسال شود.</span></label>
                        @error('freight_name')<span class="err-text">{{ $message }}</span>@enderror
                        <small class="muted" style="line-height:1.9">
                            @if ($fm && \App\Services\Checkout::innerFee($fm, $itemsTotal) > 0)
                                {{ $fm['inner_title'] }} ({{ $fm['inner_type'] === 'percent' ? fa($fm['inner_amount']).'٪ ارزش بار' : 'مبلغ ثابت' }}) را فروشگاه دریافت می‌کند؛
                            @endif
                            کرایه باربری از تهران تا شهر شما هنگام تحویل بار، به خود باربری پرداخت می‌شود (پس‌کرایه).
                        </small>
                    </div>
                @endif
                @if (! $ships)<div class="alert alert-err">هیچ شیوه ارسالی فعال نیست؛ با فروشگاه تماس بگیرید.</div>@endif
            </div>

            <div class="card" style="display:flex;flex-direction:column;gap:12px">
                <h2 style="margin:0">شیوه تسویه</h2>
                @error('payment')<span class="err-text">{{ $message }}</span>@enderror
                <div class="choices col" role="radiogroup" aria-label="شیوه تسویه">
                    @foreach ($pays as $p)
                        @php $off = $p['id'] === 'cheque' && ! ($cheque['av']['ok'] ?? false); @endphp
                        <label class="choice{{ $off ? ' is-off' : '' }}">
                            <input type="radio" name="payment" value="{{ $p['id'] }}" @checked($pay === $p['id'] && ! $off) @disabled($off) required data-pay>
                            <span class="dot"></span>
                            <span><b>{{ $p['title'] }}</b>@if ($p['desc'])<small>{{ $p['desc'] }}</small>@endif
                                @if ($off)<small class="warn-text">{{ $cheque['av']['reason'] }}</small>@endif</span>
                        </label>
                    @endforeach
                </div>
                @isset($pays['card'])
                    @php $c = $pays['card']['card']; @endphp
                    <div class="paybox" data-pay-box="card" @if ($pay !== 'card') hidden @endif>
                        <div class="kv">
                            @if (! empty($c['card_number']))<span>شماره کارت: <b class="ltr">{{ fa(trim(chunk_split(preg_replace('/\D/', '', en_digits($c['card_number'])), 4, '-'), '-')) }}</b></span>@endif
                            @if (! empty($c['holder']))<span>به نام: <b>{{ $c['holder'] }}</b></span>@endif
                            @if (! empty($c['bank']))<span>بانک: <b>{{ $c['bank'] }}</b></span>@endif
                            @if (! empty($c['sheba']))<span>شبا: <b class="ltr">{{ $c['sheba'] }}</b></span>@endif
                        </div>
                        {{-- با پرداخت از طریق حواله‌ها، شماره حساب و مبلغ بعد از ثبت سفارش اعلام می‌شود؛ فیش و پیگیری همان‌جا ثبت می‌شود --}}
                        @if (\App\Services\Remit::enabled())
                            <small class="muted" style="line-height:1.9">شماره حساب و مبلغ واریز پس از ثبت سفارش توسط کارشناس اعلام و برایتان پیامک می‌شود؛ فیش را همان‌جا در صفحه سفارش بارگذاری کنید.</small>
                        @else
                            <label class="field"><span>شماره پیگیری واریز <small>(اختیاری — بعداً هم می‌توانید اعلام کنید)</small></span><input name="pay_ref" inputmode="numeric" dir="ltr" value="{{ old('pay_ref') }}" placeholder="مثلاً ۱۲۳۴۵۶"></label>
                        @endif
                    </div>
                @endisset
                @if (isset($pays['offline']) && $pays['offline']['options'])
                    <div class="paybox" data-pay-box="offline" @if ($pay !== 'offline') hidden @endif>
                        <label class="field">نحوه تسویه
                            <select name="offline_option">@foreach ($pays['offline']['options'] as $o)<option @selected(old('offline_option') === $o)>{{ $o }}</option>@endforeach</select>
                        </label>
                    </div>
                @endif
                @if ($cheque && $cheque['av']['ok'])
                    @include('store.partials.cheque-box')
                @endif
                @if (! $pays)<div class="alert alert-err">هیچ شیوه پرداختی فعال نیست؛ با فروشگاه تماس بگیرید.</div>@endif
                @if (setting('checkout_note'))<div class="alert alert-info">{{ setting('checkout_note') }}</div>@endif
            </div>
        </section>

        <aside class="split-side card" aria-label="خلاصه سفارش">
            <h2 style="margin:0;font-size:18px">سفارش شما</h2>
            @php $iv = \App\Support\AppUx::itemsView(); @endphp
            @if ($iv === 'hidden')
                <p class="muted" style="margin:0">{{ fa($lines->count()) }} قلم کالا — <a href="{{ route('cart') }}">مشاهده در سبد خرید</a></p>
            @else
                <details class="mini-list" @if ($iv === 'shown') open @endif>
                    <summary><span>خریدهای شما ({{ fa($lines->count()) }} قلم)</span><i>نمایش / بستن</i></summary>
                    @foreach ($lines as $l)
                        <div class="mini">
                            @if ($l->product->image)<img src="{{ thumb($l->product->image, 160) }}" alt="" loading="lazy">@else<span class="noimg"></span>@endif
                            <div><b>{{ $l->product->name }}</b><span><span class="tag{{ $l->retail ? ' retail' : '' }}">{{ $l->tag }}</span>{{ $l->qty }}</span></div>
                            <b>{{ money($l->total) }}</b>
                        </div>
                    @endforeach
                </details>
            @endif
            <dl class="sum" style="padding-top:12px;border-top:1px dashed var(--line-2)">
                @if ($totals['discount'])
                    <div><dt>قیمت کالاها</dt><dd>{{ money($totals['items'] + $totals['discount']) }}</dd></div>
                    <div class="neg"><dt>تخفیف</dt><dd>− {{ money($totals['discount']) }}</dd></div>
                @endif
                <div><dt>جمع کالاها</dt><dd>{{ money($totals['items']) }}</dd></div>
                @if (! empty($totals['coupon_discount']))<div class="neg"><dt>کد تخفیف {{ $totals['coupon']['coupon']->code }}</dt><dd>− {{ money($totals['coupon_discount']) }}</dd></div>@endif
                <div><dt>ارسال: <span data-ship-name>{{ $totals['shipping']['title'] ?? '—' }}</span></dt><dd data-ship-cost>{{ $totals['shipping_label'] }}</dd></div>
                @foreach ($totals['fees'] as $fee)
                    <div><dt>{{ $fee['title'] }}</dt><dd>{{ money($fee['amount']) }}</dd></div>
                @endforeach
                <div class="grand"><dt>قابل پرداخت</dt><dd><span data-grand>{{ money($totals['total']) }}</span> تومان</dd></div>
            </dl>
            @if (setting('terms_enabled'))
                <div class="terms">
                    <label class="check"><input type="checkbox" name="terms" value="1" required @checked(old('terms'))> <span>{{ setting('terms_label', 'قوانین و شرایط خرید را می‌پذیرم.') }}</span></label>
                    <details><summary>مطالعه قوانین و شرایط</summary><div class="prose terms-text">{!! clean_html(setting('terms_text')) !!}</div></details>
                    @error('terms')<span class="err-text">{{ $message }}</span>@enderror
                </div>
            @endif
            <button type="submit" class="btn btn-lg btn-block" data-submit data-gateway-label="پرداخت و ثبت سفارش" data-label="ثبت سفارش">{{ $pay === 'gateway' ? 'پرداخت و ثبت سفارش' : 'ثبت سفارش' }}</button>
            <div class="trust-row">@include('store.partials.badges')</div>
            @include('store.partials.help-contacts')
        </aside>
    </form>
</main>
@endsection
