@extends('layouts.store', ['title' => $page->title, 'description' => $page->seo_description])

@section('content')
<main class="wrap page tight">
    <nav class="crumbs"><a href="{{ route('home') }}">خانه</a><span>/</span><span>{{ $page->title }}</span></nav>
    <article class="card prose" style="max-width:900px">
        <h1 style="font-size:26px;margin-bottom:12px">{{ $page->title }}</h1>
        {!! clean_html($page->body) !!}
    </article>
</main>
@endsection
