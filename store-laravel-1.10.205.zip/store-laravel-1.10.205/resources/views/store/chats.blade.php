@extends('layouts.store', ['title' => 'گفتگوها', 'noindex' => true])

@section('content')
<main class="wrap page tight">
    <div class="cl-head">
        <h1>گفتگوها</h1>
        <p class="muted">گفتگوی هر سفارش با مسئول پیگیری؛ فیش، چک و سؤال‌هایتان را همین‌جا بفرستید.</p>
    </div>
    @if ($rows->isEmpty())
        <div class="card empty" style="border:0"><svg class="ic"><use href="#i-chat"/></svg>هنوز گفتگویی ندارید. پس از ثبت سفارش، از همین‌جا با مسئول سفارش در ارتباط هستید.<a href="{{ route('shop') }}" class="btn">شروع خرید</a></div>
    @else
        <div class="cl-list">
            @foreach ($rows as $x)
                <a class="cl-it{{ $x->unread ? ' unread' : '' }}" href="{{ route('order.show', $x->o->number) }}#chat">
                    <span class="cl-av">{{ $x->staff ? mb_substr($x->staff, 0, 1) : '💬' }}</span>
                    <span class="cl-m">
                        <span class="cl-l1"><b>سفارش {{ fa($x->o->number) }}</b><time>{{ $x->at ? ($x->at->isToday() ? fa($x->at->timezone('Asia/Tehran')->format('H:i')) : jdate($x->at, false)) : '' }}</time></span>
                        <span class="cl-l2"><span>{{ $x->has ? $x->last : ($x->staff ? 'گفتگو با '.$x->staff.' را شروع کنید' : 'برای سؤال درباره این سفارش پیام بدهید') }}</span>@if ($x->unread)<em>{{ fa($x->unread) }}</em>@endif</span>
                        <span class="cl-l3"><span class="status {{ $x->o->status }}">{{ $x->o->statusLabel() }}</span>@if ($x->staff)<small>مسئول: {{ $x->staff }}</small>@endif</span>
                    </span>
                </a>
            @endforeach
        </div>
    @endif
</main>
@endsection
