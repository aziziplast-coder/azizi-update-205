@php
    $title = $cat ? ($cat->seo_title ?: $cat->name) : ($tag ? 'برچسب: '.$tag : setting('blog_title', 'مجله'));
@endphp
@extends('layouts.store', [
    'title' => $title,
    'description' => $cat ? ($cat->seo_description ?: $cat->description) : setting('blog_description'),
    'canonical' => $cat ? $cat->url() : route('blog'),
    'noindex' => $tag || request('q') || request('page') > 1,
])

@section('content')
<main class="wrap page tight">
    <nav class="crumbs" aria-label="مسیر"><a href="{{ route('home') }}">خانه</a><span>/</span>
        @if ($cat || $tag)<a href="{{ route('blog') }}">{{ setting('blog_title', 'مجله') }}</a><span>/</span><span>{{ $cat->name ?? $tag }}</span>@else<span>{{ setting('blog_title', 'مجله') }}</span>@endif
    </nav>
    <div class="shop-head">
        <div><h1>{{ $cat->name ?? ($tag ? '#'.$tag : setting('blog_title', 'مجله')) }}</h1>
            @if ($cat && $cat->description)<p>{{ $cat->description }}</p>@elseif (! $cat && ! $tag && setting('blog_description'))<p>{{ setting('blog_description') }}</p>@endif</div>
        <form method="get" action="{{ route('blog') }}" class="blog-search"><input type="search" name="q" value="{{ $term }}" placeholder="جستجو در مقالات…" aria-label="جستجو در مقالات"></form>
    </div>
    @if ($cats->isNotEmpty())
        <div class="pills" role="list">
            <a role="listitem" href="{{ route('blog') }}" @class(['pill', 'on' => ! $cat])>همه</a>
            @foreach ($cats as $c)<a role="listitem" href="{{ $c->url() }}" @class(['pill', 'on' => $cat && $cat->id === $c->id])>{{ $c->name }} <small>{{ fa($c->posts_count) }}</small></a>@endforeach
        </div>
    @endif
    @if ($posts->isEmpty())
        <div class="empty"><svg class="ic"><use href="#i-doc"/></svg><span>مقاله‌ای پیدا نشد.</span></div>
    @else
        <div class="posts">@foreach ($posts as $post)@include('store.partials.post-card', ['post' => $post])@endforeach</div>
        @include('store.partials.pager', ['paginator' => $posts])
    @endif
</main>
@endsection
