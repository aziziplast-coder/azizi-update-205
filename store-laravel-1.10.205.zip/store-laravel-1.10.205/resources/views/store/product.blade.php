@php
    $carton = $product->cartonAvailable();
    $retail = $product->retailAvailable();
    $out = ! $carton && ! $retail;
    $off = $product->discountPercent();
    $imgs = $product->images();
    $rating = $product->rating();
    $specs = array_filter((array) $product->specs, fn ($v, $k) => trim((string) $k) !== '' && trim((string) $v) !== '', ARRAY_FILTER_USE_BOTH);
    $schema = [
        '@context' => 'https://schema.org', '@type' => 'Product', 'name' => $product->name,
        'image' => array_map(fn ($i) => url(upload_url($i)), $imgs),
        'description' => \Illuminate\Support\Str::limit(strip_tags($product->short_description ?: $product->description), 300),
        'sku' => $product->sku ?: (string) $product->id,
        'offers' => ['@type' => 'Offer', 'priceCurrency' => 'IRR', 'price' => $product->price * 10, 'availability' => $out ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock', 'url' => $product->url()],
    ];
    if ($product->barcode && preg_match('/^\d{8,14}$/', $product->barcode)) { $schema['gtin'] = $product->barcode; }
    if ($product->category) { $schema['category'] = $product->category->name; }
    if ($rating['count']) { $schema['aggregateRating'] = ['@type' => 'AggregateRating', 'ratingValue' => $rating['avg'], 'reviewCount' => $rating['count']]; }
    if ($product->offer_ends_at && $product->offerActive()) { $schema['offers']['priceValidUntil'] = $product->offer_ends_at->toDateString(); }
    $attrGroups = $product->attributeGroups();
    $crumbs = [['خانه', route('home')]];
    if ($product->category?->parent) { $crumbs[] = [$product->category->parent->name, $product->category->parent->url()]; }
    if ($product->category) { $crumbs[] = [$product->category->name, $product->category->url()]; }
    $crumbs[] = [$product->name, $product->url()];
    $tpl = setting('seo_title_product', '{name}');
@endphp
@extends('layouts.store', [
    'title' => $product->seo_title ?: str_replace(['{name}', ' | {site}', '{site}'], [$product->name, '', store_name()], $tpl),
    'noindex' => $product->noindex,
    'description' => $product->seo_description ?: ($product->short_description ?: \Illuminate\Support\Str::limit(strip_tags((string) $product->description), 160)),
    'ogImage' => $product->image ? upload_url($product->image) : null,
    'canonical' => $product->url(),
])

@push('head')
<script type="application/ld+json">{!! json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!}</script>
@if (setting('seo_breadcrumbs', true))<script type="application/ld+json">{!! json_encode(['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => array_map(fn ($c, $i) => ['@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => $c[1]], $crumbs, array_keys($crumbs))], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!}</script>@endif
@endpush

@section('content')
<main class="wrap page tight" style="gap:28px" data-viewed="{{ $product->id }}">
    <nav class="crumbs" aria-label="مسیر">
        <a href="{{ route('home') }}">خانه</a><span>/</span>
        @if ($product->category)
            @if ($product->category->parent)<a href="{{ $product->category->parent->url() }}">{{ $product->category->parent->name }}</a><span>/</span>@endif
            <a href="{{ $product->category->url() }}">{{ $product->category->name }}</a><span>/</span>
        @endif
        <span>{{ $product->name }}</span>
    </nav>

    @if (session('ok'))<div class="alert alert-ok">{{ session('ok') }}</div>@endif
    @if ($errors->any())<div class="alert alert-err">{{ $errors->first() }}</div>@endif

    <div class="prod">
        <section class="gallery" aria-label="تصاویر" data-gallery>
            <div class="gallery-main">
                @if ($imgs)
                    <img src="{{ thumb($imgs[0], 960) }}" alt="{{ $product->name }}" data-gallery-main width="960" height="960" fetchpriority="high">
                @else
                    <span class="noimg" style="display:grid;place-items:center;height:100%;color:var(--faint)"><svg class="ic" style="width:64px;height:64px"><use href="#i-image"/></svg></span>
                @endif
                @if ($out)<span class="badge badge-dark">ناموجود</span>@elseif ($off)<span class="badge">{{ fa($off) }}٪</span>@endif
            </div>
            @if (count($imgs) > 1)
                <div class="thumbs">
                    @foreach ($imgs as $i => $img)
                        <button type="button" @class(['on' => $i === 0]) data-src="{{ thumb($img, 960) }}" aria-label="تصویر {{ fa($i + 1) }}"><img src="{{ thumb($img, 160) }}" alt="" loading="lazy"></button>
                    @endforeach
                </div>
            @endif
        </section>

        <section class="pinfo">
            <h1>{{ $product->h1 ?: $product->name }}</h1>
            @if ($pcode = $product->displayCode())<div class="pcode">بارکد: <b dir="ltr">{{ $pcode }}</b></div>@endif
            <div class="pmeta">
                @if ($product->category)<span>دسته: <a href="{{ $product->category->url() }}">{{ $product->category->name }}</a></span>@endif
                @if ($rating['count'])<span class="stars">{{ str_repeat('★', (int) round($rating['avg'])) }}{{ str_repeat('☆', 5 - (int) round($rating['avg'])) }} <span class="muted">({{ fa($rating['count']) }} نظر)</span></span>@endif
            </div>
            <div class="big-price">
                @if ($off && ! $out)<del>{{ money($product->compare_price) }}</del>@endif
                <b><span data-big-price>{{ money($carton || ! $retail ? $product->price : $product->unitPrice('retail')) }}</span> تومان</b>
                <small class="muted">/ هر {{ $product->unitName() }}</small>
            </div>
            @if ($product->offer_ends_at && $product->offerActive() && ! $out)
                <div class="offer-timer"><svg class="ic"><use href="#i-fire"/></svg>پایان تخفیف: <span class="am-timer sm" data-countdown="{{ $product->offer_ends_at->toIso8601String() }}"><i data-h>۰۰</i>:<i data-m>۰۰</i>:<i data-s>۰۰</i></span></div>
            @endif
            @if ($product->short_description)<p style="margin:0">{{ $product->short_description }}</p>@endif
            @if ($attrGroups)
                <dl class="pattrs">
                    @foreach ($attrGroups as $g)
                        <div><dt>{{ $g['attr']->name }}</dt><dd>
                            @foreach ($g['values'] as $v)
                                @if ($g['attr']->type === 'color')<span class="swatch" title="{{ $v->value }}"><span class="sw" style="--c:{{ $v->color ?: '#ccc' }}"></span>{{ $v->value }}</span>@else<span class="vchip">{{ $v->value }}</span>@endif
                            @endforeach
                        </dd></div>
                    @endforeach
                </dl>
            @endif

            @php $buyRule = $product->buyRule(); @endphp
            <div class="buybox" data-buybox data-p='@json($product->buyData())'>
                @if ($out)
                    @if ($product->restock_at)
                        <div class="alert alert-ok" style="margin-bottom:8px">🏭 سفارش دادیم از کارخانه؛ به‌زودی شارژ می‌شود. شماره‌تان را بگذارید تا وقتی موجود شد پیامک بدهیم.</div>
                    @endif
                    <div class="alert alert-info" id="notify"><svg class="ic"><use href="#i-bell"/></svg>این کالا فعلاً موجود نیست. شماره‌تان را بگذارید تا وقتی موجود شد پیامک بدهیم.</div>
                    <form method="post" action="{{ route('product.notify', $product) }}" style="display:flex;gap:8px;flex-wrap:wrap">
                        @csrf
                        <input class="input" name="mobile" inputmode="tel" dir="ltr" placeholder="09xxxxxxxxx" value="{{ old('mobile', auth()->user()?->mobile) }}" style="flex:1 1 200px" required>
                        <button class="btn">خبرم کن</button>
                    </form>
                @else
                    @if ($product->hasCartons() && ($carton || $retail) && $product->retailAllowed())
                        <div class="modes" role="radiogroup" aria-label="نوع خرید">
                            <button type="button" class="mode" role="radio" data-mode="carton" aria-checked="{{ $carton ? 'true' : 'false' }}" @disabled(! $carton)>
                                <b>خرید کارتنی (عمده)</b>
                                <small>{{ $carton ? $product->cartonText().' · '.money($product->price).' هر '.$product->unitName() : 'فعلاً موجود نیست' }}</small>
                            </button>
                            <button type="button" class="mode" role="radio" data-mode="retail" aria-checked="{{ ! $carton ? 'true' : 'false' }}" @disabled(! $retail)>
                                <b>خرید خرده (کمتر از کارتن)</b>
                                <small>{{ $retail ? 'کمتر از کارتن · '.money($product->unitPrice('retail')).' هر '.$product->unitName() : 'فعلاً موجود نیست' }}</small>
                            </button>
                        </div>
                    @elseif ($product->hasCartons() && ! $buyRule[2])
                        <span class="chip"><svg class="ic"><use href="#i-box"/></svg>فروش کارتنی — هر کارتن {{ fa($product->per_carton) }} {{ $product->unitFull() }}</span>
                    @endif
                    @if ($carton && $buyRule[2])
                        <span class="chip"><svg class="ic"><use href="#i-box"/></svg>{{ $product->buyRuleText() }}</span>
                    @endif
                    <div class="buyrow">
                        <div class="stepper">
                            <button type="button" data-act="plus" aria-label="افزایش">+</button>
                            <span><b data-count>{{ $carton && $buyRule[2] ? fa($buyRule[0]) : '۱' }}</b> <i data-unit style="font-style:normal">{{ $carton && ! $buyRule[2] ? $product->cartonUnit() : $product->unitName() }}</i></span>
                            <button type="button" data-act="minus" aria-label="کاهش">−</button>
                        </div>
                        <div class="buytotal"><b><span data-total>{{ money($carton ? $product->price * $buyRule[0] : $product->unitPrice('retail')) }}</span> تومان</b><small data-summary></small></div>
                    </div>
                    <button type="button" class="btn btn-lg" data-act="add">افزودن به سبد خرید</button>
                    <span class="incart-note" data-incart hidden></span>
                @endif
                <ul class="perks">
                    <li><svg class="ic"><use href="#i-truck"/></svg>ارسال به سراسر کشور</li>
                    <li><svg class="ic"><use href="#i-box"/></svg>قیمت عمده کارتنی</li>
                    <li><svg class="ic"><use href="#i-check"/></svg>امکان خرید خرده برای مغازه‌داران</li>
                    <li><svg class="ic"><use href="#i-shield"/></svg>تضمین اصالت کالا</li>
                </ul>
            </div>
        </section>
    </div>

    <section class="tabs" data-tabs>
        <div class="tablist" role="tablist">
            <button type="button" role="tab" aria-selected="true" data-tab="desc">توضیحات</button>
            @if ($specs || $attrGroups)<button type="button" role="tab" aria-selected="false" data-tab="specs">مشخصات</button>@endif
            <button type="button" role="tab" aria-selected="false" data-tab="reviews">نظرات ({{ fa($rating['count']) }})</button>
        </div>
        <div class="tabpanel prose" data-panel="desc">
            @if ($product->description)
                {!! clean_html($product->description) !!}
            @else
                <p class="muted">{{ $product->short_description ?: 'توضیحی برای این کالا ثبت نشده است.' }}</p>
            @endif
            @if ($product->hasCartons())<p class="muted">تعداد در کارتن: {{ fa($product->per_carton) }} {{ $product->unitFull() }}</p>@endif
        </div>
        @if ($specs || $attrGroups)
            <div class="tabpanel" data-panel="specs" hidden>
                <table class="specs">
                    @foreach ($attrGroups as $g)<tr><th>{{ $g['attr']->name }}</th><td>{{ implode('، ', array_map(fn ($v) => $v->value, $g['values'])) }}</td></tr>@endforeach
                    @foreach ($specs as $k => $v)<tr><th>{{ $k }}</th><td>{{ $v }}</td></tr>@endforeach
                </table>
            </div>
        @endif
        <div class="tabpanel" data-panel="reviews" hidden>
            @forelse ($reviews as $r)
                <div class="review">
                    <div class="review-head"><b>{{ $r->name }}</b><span class="stars">{{ str_repeat('★', $r->rating) }}</span><span>{{ jdate($r->created_at) }}</span></div>
                    <p style="margin:6px 0 0">{{ $r->body }}</p>
                </div>
            @empty
                <p class="muted">هنوز نظری ثبت نشده است.</p>
            @endforelse
            @auth
                <form method="post" action="{{ route('product.review', $product) }}" style="display:flex;flex-direction:column;gap:10px;margin-top:16px;max-width:560px">
                    @csrf
                    <b style="color:var(--ink)">نظر شما</b>
                    <div class="rate-pick">
                        @for ($i = 5; $i >= 1; $i--)<input type="radio" name="rating" id="rate{{ $i }}" value="{{ $i }}" @checked($i === 5)><label for="rate{{ $i }}" title="{{ fa($i) }} ستاره">★</label>@endfor
                    </div>
                    <label class="field"><span class="sr">متن نظر</span><textarea name="body" rows="3" required minlength="3" maxlength="2000" placeholder="نظرتان درباره این کالا…"></textarea></label>
                    <button class="btn" style="align-self:flex-start">ثبت نظر</button>
                </form>
            @else
                <p><a href="{{ route('login', ['next' => request()->getRequestUri()]) }}" style="color:var(--brand-ink);font-weight:700">وارد شوید</a> تا نظر بدهید.</p>
            @endauth
        </div>
    </section>

    @if ($related->isNotEmpty())
        @include('store.blocks.strip', ['products' => $related, 'title' => 'کالاهای مشابه', 'link' => $product->category?->url()])
    @endif
    @include('store.blocks.recent', ['d' => []])
</main>
@endsection
