@extends('layouts.store', ['title' => 'ورود و ثبت‌نام', 'noindex' => true])

@section('content')
<main class="wrap page tight">
    <div class="auth">
        <div class="card">
            <h1>ورود | ثبت‌نام</h1>
            @if ($errors->any())<div class="alert alert-err">{{ $errors->first() }}</div>@endif

            @if ($otp)
                <form data-otp data-send="{{ route('login.otp') }}" data-verify="{{ route('login.verify') }}" style="display:flex;flex-direction:column;gap:14px" @if ($errors->any() && $password) hidden @endif>
                    <div data-step="mobile" style="display:flex;flex-direction:column;gap:14px">
                        <p class="lead">شماره موبایل خود را وارد کنید؛ کد تأیید پیامک می‌شود.</p>
                        <label class="field">شماره موبایل<input name="mobile" inputmode="tel" autocomplete="tel" dir="ltr" placeholder="09xxxxxxxxx" required autofocus></label>
                        <button class="btn btn-lg btn-block" data-send-btn>دریافت کد تأیید</button>
                    </div>
                    <div data-step="code" hidden style="display:flex;flex-direction:column;gap:14px">
                        <p class="lead" data-sent-msg></p>
                        <label class="field">کد تأیید<input name="code" class="otp-input" inputmode="numeric" autocomplete="one-time-code" maxlength="8" data-len="{{ (int) setting('otp_length', 5) }}"></label>
                        <label class="field" data-name-field hidden>نام و نام خانوادگی <small>(برای فاکتور)</small><input name="name" autocomplete="name"></label>
                        <button class="btn btn-lg btn-block" data-verify-btn>ورود</button>
                        <div style="display:flex;justify-content:space-between;font-size:13.5px">
                            <button type="button" class="linkish" data-edit>ویرایش شماره</button>
                            <button type="button" class="linkish" data-resend disabled>ارسال دوباره</button>
                        </div>
                    </div>
                    <div class="alert alert-err" data-otp-err hidden></div>
                    @if ($password)<button type="button" class="linkish" data-switch="password">ورود با رمز عبور</button>@endif
                </form>
            @endif

            @if ($password)
                <form method="post" action="{{ route('login.password') }}" data-pass-form style="display:flex;flex-direction:column;gap:14px" @if ($otp && ! $errors->any()) hidden @endif>
                    @csrf
                    <label class="field">شماره موبایل<input name="mobile" inputmode="tel" dir="ltr" value="{{ old('mobile') }}" required></label>
                    <label class="field">رمز عبور<input type="password" name="password" required autocomplete="current-password"></label>
                    <button class="btn btn-lg btn-block">ورود</button>
                    <div style="display:flex;justify-content:space-between;font-size:13.5px">
                        @if ($otp)<button type="button" class="linkish" data-switch="otp">ورود با کد پیامکی</button>@endif
                        @unless ($otp)<button type="button" class="linkish" data-switch="register">ثبت‌نام نکرده‌اید؟ ثبت‌نام</button>@endunless
                    </div>
                </form>
                @unless ($otp)
                    <form method="post" action="{{ route('register') }}" data-reg-form hidden style="display:flex;flex-direction:column;gap:14px">
                        @csrf
                        <label class="field">نام و نام خانوادگی<input name="name" value="{{ old('name') }}" required></label>
                        <label class="field">شماره موبایل<input name="mobile" inputmode="tel" dir="ltr" value="{{ old('mobile') }}" required></label>
                        <label class="field">رمز عبور<input type="password" name="password" required minlength="6" autocomplete="new-password"></label>
                        <label class="field">تکرار رمز عبور<input type="password" name="password_confirmation" required></label>
                        <button class="btn btn-lg btn-block">ثبت‌نام</button>
                        <button type="button" class="linkish" data-switch="password">حساب دارید؟ ورود</button>
                    </form>
                @endunless
            @endif
        </div>
    </div>
</main>
@endsection
