@php $benefits = array_values(array_filter((array) setting('benefits', []))); $bicons = ['truck', 'box', 'check', 'shield']; @endphp
@if ($benefits)
    <section class="benefits" aria-label="مزیت‌ها">
        @foreach ($benefits as $i => $b)
            <div class="benefit"><span><svg class="ic"><use href="#i-{{ $bicons[$i % 4] }}"/></svg></span><b>{{ is_array($b) ? ($b['text'] ?? '') : $b }}</b></div>
        @endforeach
    </section>
@endif
