@php $c = $items['collection']; @endphp
@include('store.blocks.strip', [
    'products' => $items['products'],
    'title' => $c->title,
    'link' => $c->url(),
    'display' => $c->display,
    'class' => $c->color ? 'tinted' : '',
    'style' => $c->color ? '--tint:'.$c->color : '',
])
