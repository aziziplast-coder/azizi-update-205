{{-- پرفروش‌ترین‌ها: فهرست رتبه‌دار در ۳ ردیف، با کشیدن افقی صفحه به صفحه --}}
@php $showSold = ! empty($d['show_sold']); @endphp
<section class="sec rank-sec">
    <div class="sec-head"><h2>{{ $d['title'] ?? 'پرفروش‌ترین‌ها' }}</h2>
        @if (! empty($d['more']))<a href="{{ route('bestsellers') }}">مشاهده همه</a>@endif</div>
    <div class="strip" data-strip>
        <div class="strip-track rank-track">
            @foreach ($items as $i => $p)
                <a href="{{ $p->url() }}" class="rank-item">
                    <span class="rank-img">@if ($p->image)<img src="{{ thumb($p->image, 160) }}" alt="" loading="lazy" width="72" height="72">@endif</span>
                    <span class="rank-n">{{ fa($i + 1) }}</span>
                    <span class="rank-t">
                        <b>{{ $p->name }}</b>
                        @if ($showSold && ($p->sold_units ?? 0) > 0)<small>{{ fa($p->sold_units) }} عدد فروخته شده</small>@else<small>{{ money($p->price) }} تومان</small>@endif
                    </span>
                </a>
            @endforeach
        </div>
        <button type="button" class="strip-nav prev" data-strip-nav="-1" aria-label="قبلی" hidden><svg class="ic"><use href="#i-chev"/></svg></button>
        <button type="button" class="strip-nav next" data-strip-nav="1" aria-label="بعدی" hidden><svg class="ic"><use href="#i-chev"/></svg></button>
    </div>
</section>
