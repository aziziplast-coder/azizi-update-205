@foreach ($items as $row)
    @include('store.blocks.strip', ['products' => $row['products'], 'title' => $row['category']->name, 'link' => $row['category']->url(), 'display' => $d['display'] ?? 'strip'])
@endforeach
