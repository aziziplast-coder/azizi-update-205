@if (setting('recent_enabled', true))
<section class="sec pstrip recent" data-recent="{{ route('recent') }}" data-limit="{{ (int) setting('recent_limit', 12) }}" hidden>
    <div class="sec-head"><h2>{{ setting('recent_title', 'بازدیدهای اخیر شما') }}</h2><button type="button" class="linkish" data-recent-clear>پاک کردن</button></div>
    <div class="strip" data-strip><div class="strip-track" data-recent-body></div>
        <button type="button" class="strip-nav prev" data-strip-nav="-1" aria-label="قبلی" hidden><svg class="ic"><use href="#i-chev"/></svg></button>
        <button type="button" class="strip-nav next" data-strip-nav="1" aria-label="بعدی" hidden><svg class="ic"><use href="#i-chev"/></svg></button>
    </div>
</section>
@endif
