@php
    $slides = array_values(array_filter((array) ($d['slides'] ?? []), fn ($s) => ! empty($s['image'])));
    $ratio = $d['ratio'] ?? '3/1';
    // اگر تصویر مخصوص موبایل نیست، در گوشی هم با نسبت همان بنر نمایش داده می‌شود تا تصویر بریده نشود
    $hasMobile = collect($slides)->contains(fn ($s) => ! empty($s['image_mobile']));
    $mratio = $hasMobile ? ($d['mobile_ratio'] ?? '4/3') : $ratio;
@endphp
@if ($slides)
<section class="slider fx-{{ $d['effect'] ?? 'slide' }}{{ ! empty($d['full']) ? ' slider-full' : '' }}" data-slider data-auto="{{ (int) ($d['autoplay'] ?? 5) }}" style="--ar:{{ $ratio }};--mar:{{ $mratio }}" aria-roledescription="carousel" aria-label="اسلایدر">
    <div class="slides">
        @foreach ($slides as $i => $s)
            @php $tag = ! empty($s['link']) ? 'a' : 'div'; @endphp
            <{{ $tag }} class="slide{{ $i === 0 ? ' on' : '' }}" @if ($tag === 'a') href="{{ $s['link'] }}" @endif aria-roledescription="slide" aria-label="{{ fa($i + 1) }} از {{ fa(count($slides)) }}">
                <picture>
                    @if (! empty($s['image_mobile']))<source media="(max-width: 640px)" srcset="{{ srcset($s['image_mobile'], [480, 960, 1600]) }}" sizes="100vw">@endif
                    <img src="{{ thumb($s['image'], 1600) }}" srcset="{{ srcset($s['image'], [960, 1600, 2400]) }}" sizes="(max-width: 1240px) 100vw, 1240px" alt="{{ $s['title'] ?? '' }}" @if ($i === 0 && $first) fetchpriority="high" @else loading="lazy" @endif decoding="async">
                </picture>
                @if (! empty($s['title']) || ! empty($s['text']) || ! empty($s['button']))
                    <span class="slide-cap cap-{{ $s['position'] ?? 'start' }}">
                        @if (! empty($s['title']))<b>{{ $s['title'] }}</b>@endif
                        @if (! empty($s['text']))<span>{{ $s['text'] }}</span>@endif
                        @if (! empty($s['button']))<em class="btn">{{ $s['button'] }}</em>@endif
                    </span>
                @endif
            </{{ $tag }}>
        @endforeach
    </div>
    @if (count($slides) > 1)
        <button type="button" class="sl-nav sl-prev" data-sl="prev" aria-label="قبلی"><svg class="ic"><use href="#i-chev"/></svg></button>
        <button type="button" class="sl-nav sl-next" data-sl="next" aria-label="بعدی"><svg class="ic"><use href="#i-chev"/></svg></button>
        <div class="sl-dots">@foreach ($slides as $i => $s)<button type="button" data-sl="{{ $i }}" @class(['on' => $i === 0]) aria-label="اسلاید {{ fa($i + 1) }}"></button>@endforeach</div>
    @endif
</section>
@endif
