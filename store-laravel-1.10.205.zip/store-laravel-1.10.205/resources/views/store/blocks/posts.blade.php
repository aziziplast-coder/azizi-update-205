<section class="sec">
    <div class="sec-head"><h2>{{ $d['title'] ?? 'از مجله' }}</h2><a href="{{ route('blog') }}">همه مقالات</a></div>
    <div class="posts">@foreach ($items as $post)@include('store.partials.post-card', ['post' => $post])@endforeach</div>
</section>
