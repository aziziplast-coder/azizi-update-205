@php $a = $items['settings']; $ends = $items['ends_at'] ?? null; @endphp
<section class="amazing" style="--am:{{ $a['color'] ?? '#e11d48' }}">
    <div class="am-side">
        <b class="am-title">{{ $a['title'] ?? 'شگفت‌انگیز' }}</b>
        @if (! empty($a['subtitle']))<span>{{ $a['subtitle'] }}</span>@endif
        @if ($ends && ! empty($a['timer']))
            <div class="am-timer" data-countdown="{{ $ends->toIso8601String() }}" aria-label="زمان باقی‌مانده"><i data-h>۰۰</i>:<i data-m>۰۰</i>:<i data-s>۰۰</i></div>
        @endif
        <a href="{{ route('amazing') }}" class="am-all">مشاهده همه <svg class="ic"><use href="#i-chev"/></svg></a>
    </div>
    <div class="strip" data-strip>
        <div class="strip-track">@foreach ($items['products'] as $p)@include('store.partials.product-card', ['p' => $p])@endforeach</div>
        <button type="button" class="strip-nav prev" data-strip-nav="-1" aria-label="قبلی" hidden><svg class="ic"><use href="#i-chev"/></svg></button>
        <button type="button" class="strip-nav next" data-strip-nav="1" aria-label="بعدی" hidden><svg class="ic"><use href="#i-chev"/></svg></button>
    </div>
</section>
