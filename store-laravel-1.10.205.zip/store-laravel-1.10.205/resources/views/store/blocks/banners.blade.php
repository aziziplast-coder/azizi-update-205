@php $list = array_values(array_filter((array) ($d['items'] ?? []), fn ($b) => ! empty($b['image']) || ! empty($b['title']))); $cols = max(1, min(4, (int) ($d['columns'] ?? 4))); @endphp
@if ($list)
<section class="banners cols-{{ $cols }}" style="--bar:{{ $d['ratio'] ?? 'auto' }}">
    @foreach ($list as $b)
        <a href="{{ $b['link'] ?? route('shop') }}" class="banner{{ empty($b['title']) ? ' plain' : '' }}">
            @if (! empty($b['image']))<img src="{{ thumb($b['image'], $cols >= 3 ? 960 : 1600) }}" srcset="{{ srcset($b['image'], [480, 960, 1600]) }}" sizes="(max-width: 640px) 50vw, {{ (int) (100 / $cols) }}vw" alt="{{ $b['title'] ?? '' }}" loading="lazy" decoding="async">@endif
            @if (! empty($b['title']))<span><b>{{ $b['title'] }}</b>@if (! empty($b['text']))<span>{{ $b['text'] }}</span>@endif</span>@endif
        </a>
    @endforeach
</section>
@endif
