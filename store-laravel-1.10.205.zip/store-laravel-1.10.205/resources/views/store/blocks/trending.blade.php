@php
    $h = (int) ($d['hours'] ?? 24);
    $label = $h <= 24 ? fa($h).' ساعت اخیر' : ($h % 24 === 0 ? fa($h / 24).' روز اخیر' : fa($h).' ساعت اخیر');
@endphp
@include('store.blocks.strip', ['products' => $items, 'title' => $d['title'] ?? 'پربازدیدترین‌ها', 'link' => route('shop', ['sort' => 'views']), 'display' => $d['display'] ?? 'strip',
    'head' => '<h2>'.e($d['title'] ?? 'پربازدیدترین‌ها').' <small class="sec-sub"><svg class="ic"><use href="#i-eye"/></svg>'.e($label).'</small></h2>'])
