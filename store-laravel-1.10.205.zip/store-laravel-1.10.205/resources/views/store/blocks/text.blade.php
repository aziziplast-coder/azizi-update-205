@if (! empty($d['html']))
<section class="sec card prose home-text">@if (! empty($d['title']))<h2>{{ $d['title'] }}</h2>@endif{!! clean_html($d['html']) !!}</section>
@endif
