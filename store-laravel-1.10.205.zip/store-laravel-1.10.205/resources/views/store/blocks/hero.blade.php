<section class="hero">
    @if (setting('hero_image'))<img src="{{ thumb(setting('hero_image'), 1600) }}" srcset="{{ srcset(setting('hero_image'), [960, 1600, 2400]) }}" sizes="(max-width: 1240px) 100vw, 1240px" alt="" @if ($first) fetchpriority="high" @else loading="lazy" @endif>@endif
    <div class="hero-in">
        @if (setting('hero_badge'))<span class="tag">{{ setting('hero_badge') }}</span>@endif
        <h2 class="hero-title">{{ setting('hero_title') }}</h2>
        @if (setting('hero_text'))<p>{{ setting('hero_text') }}</p>@endif
        @if (setting('hero_button'))<a href="{{ setting('hero_link', '/shop') }}" class="btn">{{ setting('hero_button') }}</a>@endif
    </div>
</section>
