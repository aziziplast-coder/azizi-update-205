@foreach ($items as $it)
    @include('store.blocks.collection', ['items' => $it])
@endforeach
