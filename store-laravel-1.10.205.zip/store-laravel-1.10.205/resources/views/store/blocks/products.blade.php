@php
    $src = $d['source'] ?? 'newest';
    $link = match ($src) {
        'sale' => route('shop', ['sale' => 1]),
        'popular' => route('shop', ['sort' => 'popular']),
        'category' => optional(\App\Models\Category::find((int) ($d['category_id'] ?? 0)))->url() ?? route('shop'),
        default => route('shop'),
    };
@endphp
@include('store.blocks.strip', ['products' => $items, 'title' => $d['title'] ?? 'کالاها', 'link' => $link, 'display' => $d['display'] ?? 'strip'])
