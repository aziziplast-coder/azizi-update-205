<section class="sec">
    <div class="sec-head"><h2>{{ $d['title'] ?? 'دسته‌بندی‌ها' }}</h2><a href="{{ route('shop') }}">همه محصولات</a></div>
    <div class="catstrip cs-{{ $d['style'] ?? 'circle' }}" data-strip>
        <div class="strip-track">
            @foreach ($items as $c)
                <a href="{{ $c->url() }}" class="cs-item">
                    <span class="cs-img">@if ($c->iconPath())<img src="{{ thumb($c->iconPath(), 160) }}" alt="" loading="lazy" width="80" height="80">@else<i>{{ mb_substr($c->name, 0, 1) }}</i>@endif</span>
                    <b>{{ $c->name }}</b>
                </a>
            @endforeach
        </div>
        <button type="button" class="strip-nav prev" data-strip-nav="-1" aria-label="قبلی" hidden><svg class="ic"><use href="#i-chev"/></svg></button>
        <button type="button" class="strip-nav next" data-strip-nav="1" aria-label="بعدی" hidden><svg class="ic"><use href="#i-chev"/></svg></button>
    </div>
</section>
