{{-- نوار افقی کالا: $products, $title, $link, $class, $style, $head --}}
<section class="sec pstrip {{ $class ?? '' }}" @if (! empty($style)) style="{{ $style }}" @endif>
    <div class="sec-head">{!! $head ?? '<h2>'.e($title).'</h2>' !!}@if (! empty($link))<a href="{{ $link }}">مشاهده همه</a>@endif</div>
    @if (($display ?? 'strip') === 'grid')
        <div class="grid">@foreach ($products as $p)@include('store.partials.product-card', ['p' => $p])@endforeach</div>
    @else
        <div class="strip" data-strip>
            <div class="strip-track">@foreach ($products as $p)@include('store.partials.product-card', ['p' => $p])@endforeach</div>
            <button type="button" class="strip-nav prev" data-strip-nav="-1" aria-label="قبلی" hidden><svg class="ic"><use href="#i-chev"/></svg></button>
            <button type="button" class="strip-nav next" data-strip-nav="1" aria-label="بعدی" hidden><svg class="ic"><use href="#i-chev"/></svg></button>
        </div>
    @endif
</section>
