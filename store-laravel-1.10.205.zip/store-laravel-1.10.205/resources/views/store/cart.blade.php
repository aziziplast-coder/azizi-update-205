@extends('layouts.store', ['title' => 'سبد خرید', 'noindex' => true])

@section('content')
<main class="wrap page tight">
    <ol class="steps" aria-label="مراحل خرید"><li class="cur">۱. سبد خرید</li><li>—</li><li>۲. ارسال و پرداخت</li><li>—</li><li>۳. پایان</li></ol>
    @if (! $canOrder)
        <div class="alert alert-err">{{ setting('closed_title') }} — {{ setting('closed_message') }}</div>
    @endif
    @if ($errors->any())<div class="alert alert-err">{{ $errors->first() }}</div>@endif
    @if (session('ok'))<div class="alert alert-ok">{{ session('ok') }}</div>@endif
    @if (session('err'))<div class="alert alert-err">{{ session('err') }}</div>@endif
    @php $openBlk = auth()->check() && ! session('err') ? \App\Services\Checkout::openBlock(auth()->user()) : null; @endphp
    @if ($openBlk && empty($editing))
        <div class="alert alert-err">{{ \App\Services\Checkout::openBlockMsg($openBlk) }} <a href="{{ route('order.show', $openBlk->number) }}#chat" style="font-weight:800;text-decoration:underline">گفتگوی سفارش {{ fa($openBlk->number) }}</a></div>
    @endif
    <div data-cart-body>
        @include('store.partials.cart-body')
    </div>
</main>
@endsection
