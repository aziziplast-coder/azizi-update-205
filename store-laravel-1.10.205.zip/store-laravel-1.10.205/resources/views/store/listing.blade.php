@extends('layouts.store', ['title' => $seoTitle ?? $title, 'description' => $description ?? null, 'canonical' => $canonical ?? null, 'noindex' => request()->except('page')])

@section('content')
<main class="wrap page tight">
    <nav class="crumbs" aria-label="مسیر"><a href="{{ route('home') }}">خانه</a><span>/</span><span>{{ $title }}</span></nav>
    @if (! empty($image))<div class="cat-banner"><img src="{{ thumb($image, 1600) }}" srcset="{{ srcset($image, [960, 1600, 2400]) }}" sizes="(max-width: 1240px) 100vw, 1240px" alt="{{ $title }}"></div>@endif
    <div class="shop-head listing-head" @if (! empty($tint)) style="--tint:{{ $tint }}" @endif>
        <div>
            <h1>{{ $title }}</h1>
            @if (! empty($intro))<p>{{ $intro }}</p>@endif
        </div>
        @if (! empty($endsAt))<div class="am-timer" data-countdown="{{ $endsAt->toIso8601String() }}"><i data-h>۰۰</i>:<i data-m>۰۰</i>:<i data-s>۰۰</i></div>@endif
    </div>
    <div class="toolbar">
        <span class="muted">{{ fa(method_exists($products, 'total') ? $products->total() : $products->count()) }} کالا</span>
        <div class="toolbar-end">@include('store.partials.view-toggle')</div>
    </div>
    @if ($products->isEmpty())
        <div class="empty"><svg class="ic"><use href="#i-box"/></svg><span>فعلاً کالایی در این بخش نیست.</span><a href="{{ route('shop') }}" class="btn btn-ghost">همه محصولات</a></div>
    @else
        <div class="grid plist">@foreach ($products as $p)@include('store.partials.product-card', ['p' => $p])@endforeach</div>
        @if (method_exists($products, 'links'))@include('store.partials.pager', ['paginator' => $products])@endif
    @endif
</main>
@endsection
