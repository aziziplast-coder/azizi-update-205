@php
    $tpl = setting('seo_title_category', '{name}');
    $pageTitle = $term !== '' ? 'جستجو: '.$term : ($category ? ($category->seo_title ?: str_replace(['{name}', ' | {site}', '{site}'], [$category->name, '', store_name()], $tpl)) : 'همه محصولات');
@endphp
@extends('layouts.store', [
    'title' => $pageTitle,
    'description' => $category ? ($category->seo_description ?: $category->description) : null,
    'noindex' => ($term !== '' && setting('seo_noindex_search', true)) || request()->except('page') || ($category && $category->noindex),
    'canonical' => $category ? $category->url().(request('page') > 1 ? '?page='.(int) request('page') : '') : route('shop'),
    'ogImage' => $category && ($category->banner ?: $category->image) ? upload_url($category->banner ?: $category->image) : null,
])

@if ($category && setting('seo_breadcrumbs', true))
@push('head')
@php
    $crumbs = [['خانه', route('home')], ['محصولات', route('shop')]];
    if ($category->parent) { $crumbs[] = [$category->parent->name, $category->parent->url()]; }
    $crumbs[] = [$category->name, $category->url()];
@endphp
<script type="application/ld+json">{!! json_encode(['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => array_map(fn ($c, $i) => ['@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => $c[1]], $crumbs, array_keys($crumbs))], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!}</script>
@endpush
@endif

@section('content')
<main class="wrap page tight">
    <nav class="crumbs" aria-label="مسیر">
        <a href="{{ route('home') }}">خانه</a><span>/</span>
        @if ($category)
            <a href="{{ route('shop') }}">محصولات</a><span>/</span>
            @if ($category->parent)<a href="{{ $category->parent->url() }}">{{ $category->parent->name }}</a><span>/</span>@endif
            <span>{{ $category->name }}</span>
        @else
            <span>{{ $term !== '' ? 'جستجو' : 'همه محصولات' }}</span>
        @endif
    </nav>
    @if ($category && $category->banner)
        <div class="cat-banner"><img src="{{ thumb($category->banner, 1600) }}" srcset="{{ srcset($category->banner, [960, 1600, 2400]) }}" sizes="(max-width: 1240px) 100vw, 1240px" alt="{{ $category->name }}" fetchpriority="high"></div>
    @endif
    <div class="shop-head">
        <div>
            <h1>{{ $term !== '' ? 'نتیجه جستجوی «'.$term.'»' : ($category ? ($category->h1 ?: $category->name) : 'همه محصولات') }}</h1>
            @if ($category && $category->description)<p>{{ \Illuminate\Support\Str::limit(strip_tags($category->description), 220) }}</p>@endif
        </div>
        <button type="button" class="btn btn-line filter-toggle" data-filters-toggle><svg class="ic"><use href="#i-filter"/></svg>فیلترها</button>
    </div>
    @if ($searchNote)<div class="alert alert-info">{{ $searchNote }}</div>@endif
    @php $subcats = $subcats->filter(fn ($sc) => $sc->products_count > 0)->values(); @endphp
    @if ($subcats->isNotEmpty() && $term === '')
        <section class="catchips" data-catchips aria-label="دسته‌بندی‌ها">
            <div class="catchips-head">
                <b>{{ $category ? 'زیردسته‌های '.$category->name : 'دسته‌بندی‌ها' }}</b>
                <button type="button" class="linkish" data-catchips-more hidden>مشاهده همه <svg class="ic"><use href="#i-chev"/></svg></button>
            </div>
            <div class="catchips-list" role="list">
                @foreach ($subcats as $sc)
                    <a role="listitem" href="{{ $sc->url() }}" class="catchip">
                        @if ($sc->iconPath())<img src="{{ thumb($sc->iconPath(), 64) }}" alt="" loading="lazy" width="28" height="28">@endif
                        <span>{{ $sc->name }}</span><small>{{ fa($sc->products_count) }}</small>
                    </a>
                @endforeach
            </div>
        </section>
    @endif

    <div class="shop">
        <form class="filters" method="get" data-filters aria-label="فیلترها">
            @if ($term !== '')<input type="hidden" name="q" value="{{ $term }}">@endif
            @if (request('sort'))<input type="hidden" name="sort" value="{{ $sort }}">@endif
            <div class="fbox">
                <b>نوع خرید</b>
                <label><input type="checkbox" name="carton" value="1" @checked(request('carton')) data-autosubmit> کارتنی (عمده)</label>
                <label><input type="checkbox" name="retail" value="1" @checked(request('retail')) data-autosubmit> قابل خرید خرده</label>
            </div>
            <div class="fbox">
                <b>قیمت هر عدد (تومان)</b>
                <div class="row">
                    <input type="text" name="min" inputmode="numeric" value="{{ request('min') }}" placeholder="از" aria-label="از">
                    <input type="text" name="max" inputmode="numeric" value="{{ request('max') }}" placeholder="تا" aria-label="تا">
                </div>
                <button class="btn btn-ghost" style="min-height:38px">اعمال</button>
            </div>
            @foreach ($attrs as $at)
                <div class="fbox">
                    <b>{{ $at->name }}</b>
                    <div class="fvals{{ $at->type === 'color' ? ' swatches' : '' }}">
                        @foreach ($at->values as $v)
                            <label @if ($at->type === 'color') title="{{ $v->value }}" @endif>
                                <input type="checkbox" name="f[{{ $at->id }}][]" value="{{ $v->id }}" @checked(in_array($v->id, array_map('intval', (array) request('f.'.$at->id, [])), true)) data-autosubmit>
                                @if ($at->type === 'color')<span class="sw" style="--c:{{ $v->color ?: '#ccc' }}"></span><span class="sr">{{ $v->value }}</span>@else {{ $v->value }}@endif
                            </label>
                        @endforeach
                    </div>
                </div>
            @endforeach
            <div class="fbox">
                <b>موجودی</b>
                @if (setting('shop_out_mode', 'last') === 'last')
                    <label><input type="checkbox" name="only" value="1" @checked(request('only')) data-autosubmit> فقط کالاهای موجود</label>
                @else
                    <label><input type="checkbox" name="all" value="1" @checked(request('all')) data-autosubmit> نمایش ناموجودها هم</label>
                @endif
                <label><input type="checkbox" name="sale" value="1" @checked(request('sale')) data-autosubmit> فقط تخفیف‌دار</label>
            </div>
            @if (request()->except(['page', 'q', 'sort']))<a href="{{ $category ? $category->url() : route('shop', array_filter(['q' => $term ?: null])) }}" class="btn btn-line" style="min-height:38px">حذف فیلترها</a>@endif
        </form>

        <section class="shop-main">
            <nav class="sortbar" aria-label="مرتب‌سازی">
                <span class="sortbar-l"><svg class="ic"><use href="#i-sort"/></svg>مرتب‌سازی:</span>
                @foreach ($sorts as $k => $v)
                    <a href="{{ request()->fullUrlWithQuery(['sort' => $k, 'page' => null]) }}" @class(['on' => $sort === $k]) rel="nofollow">{{ $v }}</a>
                @endforeach
            </nav>
            <div class="toolbar">
                <span class="muted">
                    @if ($products->total()){{ fa($products->total()) }} کالا @if ($products->currentPage() > 1)<small>(از {{ fa($products->firstItem()) }})</small>@endif @else کالایی پیدا نشد @endif
                </span>
                <div class="toolbar-end">
                    @include('store.partials.view-toggle')
                    <label class="sortsel"><span class="d-only">مرتب‌سازی</span>
                        <select onchange="var u=new URL(location.href);u.searchParams.set('sort',this.value);u.searchParams.delete('page');location.href=u" aria-label="مرتب‌سازی">
                            @foreach ($sorts as $k => $v)<option value="{{ $k }}" @selected($sort === $k)>{{ $v }}</option>@endforeach
                        </select>
                    </label>
                </div>
            </div>
            @if ($products->isEmpty())
                <div class="empty"><svg class="ic"><use href="#i-search"/></svg>
                    <span>{{ $term !== '' ? 'کالایی با این نام یا بارکد پیدا نشد.' : 'در این بخش کالای موجودی نیست.' }}</span>
                    <a href="{{ route('shop', ['all' => 1]) }}" class="btn btn-ghost">مشاهده همه کالاها</a>
                </div>
            @else
                <div class="grid plist" data-plist data-auto-pages="{{ (int) setting('shop_auto_pages', 5) }}" data-page="{{ $products->currentPage() }}">
                    @foreach ($products as $p)
                        @include('store.partials.product-card', ['p' => $p])
                    @endforeach
                </div>
                <div class="plist-more" data-plist-loader hidden><span class="spin"></span> در حال بارگذاری کالاهای بیشتر…</div>
                <div data-pager-wrap>@include('store.partials.pager', ['paginator' => $products])</div>
            @endif
            @if ($category && $category->seo_text && ! request('page'))
                <div class="card prose seo-text" data-more><div class="seo-text-in">{!! clean_html($category->seo_text) !!}</div><button type="button" class="linkish" data-more-btn>ادامه مطلب</button></div>
            @endif
        </section>
    </div>
</main>
@endsection
