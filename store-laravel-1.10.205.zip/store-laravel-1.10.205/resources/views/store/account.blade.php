@extends('layouts.store', ['title' => 'حساب کاربری', 'noindex' => true])

@section('content')
<main class="wrap page tight">
    @if (session('ok'))<div class="alert alert-ok">{{ session('ok') }}</div>@endif
    <div class="acct">
        <nav class="acct-nav" aria-label="حساب">
            <div style="padding:6px 12px 10px"><b style="color:var(--ink)">{{ $user->displayName() }}</b><br><small class="muted ltr">{{ fa($user->mobile) }}</small></div>
            <a href="{{ route('account') }}" @class(['on' => $tab !== 'profile'])><svg class="ic"><use href="#i-list"/></svg>سفارش‌های من</a>
            <a href="{{ route('account', ['tab' => 'profile']) }}" @class(['on' => $tab === 'profile'])><svg class="ic"><use href="#i-user"/></svg>اطلاعات حساب</a>
            @if ($user->isStaffLike())<a href="{{ url('/admin') }}"><svg class="ic"><use href="#i-grid"/></svg>پنل مدیریت</a>@endif
            <form method="post" action="{{ route('logout') }}">@csrf<button><svg class="ic"><use href="#i-logout"/></svg>خروج</button></form>
        </nav>
        <section class="acct-main">
            @if ($tab === 'profile')
                <form method="post" action="{{ route('account.update') }}" class="card" style="display:flex;flex-direction:column;gap:14px">
                    @csrf
                    <h2 style="margin:0">اطلاعات حساب</h2>
                    @if ($errors->any())<div class="alert alert-err">{{ $errors->first() }}</div>@endif
                    <div class="grid-2">
                        <label class="field">نام و نام خانوادگی<input name="name" value="{{ old('name', $user->name) }}" required></label>
                        <label class="field">نام فروشگاه / شرکت<input name="company" value="{{ old('company', $user->company) }}"></label>
                        <label class="field">استان<select name="province"><option value="">—</option>@foreach ($provinces as $pv)<option @selected(old('province', $user->province) === $pv)>{{ $pv }}</option>@endforeach</select></label>
                        <label class="field">شهر<input name="city" value="{{ old('city', $user->city) }}"></label>
                    </div>
                    <label class="field">آدرس<textarea name="address" rows="2">{{ old('address', $user->address) }}</textarea></label>
                    <div class="grid-2">
                        <label class="field">کد پستی<input name="postal_code" dir="ltr" inputmode="numeric" value="{{ old('postal_code', $user->postal_code) }}"></label>
                        <span></span>
                        <label class="field"><span>رمز عبور جدید <small>(اختیاری)</small></span><input type="password" name="password" autocomplete="new-password" minlength="6"></label>
                        <label class="field">تکرار رمز عبور<input type="password" name="password_confirmation" autocomplete="new-password"></label>
                    </div>
                    <button class="btn" style="align-self:flex-start">ذخیره</button>
                </form>
            @else
                <div class="card">
                    <h2>سفارش‌های من</h2>
                    @if ($orders->isEmpty())
                        <div class="empty" style="border:0"><svg class="ic"><use href="#i-bag"/></svg>هنوز سفارشی ثبت نکرده‌اید.<a href="{{ route('shop') }}" class="btn">شروع خرید</a></div>
                    @else
                        @php $supUrl = \App\Support\OrderJourney::supportUrl(); @endphp
                        <div class="ol-list">
                            @foreach ($orders as $o)
                                @php $j = \App\Support\OrderJourney::for($o); $act = $j['action']; @endphp
                                <article class="ol-card">
                                    <div class="ol-top">
                                        <span class="ol-num">سفارش {{ fa($o->number) }}</span>
                                        <span class="status {{ $o->status }}">{{ $o->statusLabel() }}</span>
                                    </div>
                                    <div class="ol-meta"><span>تاریخ: <b>{{ jdate($o->created_at) }}</b></span><span>مبلغ: <b>{{ money($o->total) }} تومان</b></span></div>
                                    @unless ($j['cancelled'])
                                        <div class="ol-bar" role="progressbar" aria-valuenow="{{ $j['pct'] }}" aria-valuemin="0" aria-valuemax="100" title="پیشرفت سفارش"><i style="width:{{ $j['pct'] }}%"></i></div>
                                    @endunless
                                    @php $its = $o->items; $paidSum = (int) $o->remitPayments->where('status', 'confirmed')->sum('amount'); @endphp
                                    @if ($its->isNotEmpty())
                                        <details class="ol-items">
                                            <summary>جزئیات فاکتور — {{ fa($its->count()) }} قلم</summary>
                                            <div class="ol-tbl" role="region" aria-label="اقلام سفارش {{ fa($o->number) }}" tabindex="0">
                                                <table>
                                                    <thead><tr><th>کالا</th><th>کد</th><th>تعداد</th><th>فی (تومان)</th><th>جمع (تومان)</th></tr></thead>
                                                    <tbody>
                                                        @foreach ($its as $it)
                                                            <tr @class(['gone' => (int) $it->units === 0])>
                                                                <td>{{ $it->name }}<small>{{ $it->modeLabel() }}</small></td>
                                                                <td class="ltr">{{ fa($it->code()) ?: '—' }}</td>
                                                                <td>{{ $it->qtyLabel() }}</td>
                                                                <td>{{ money($it->unit_price) }}</td>
                                                                <td><b>{{ money($it->total) }}</b></td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                            <dl class="ol-sum">
                                                <div><dt>جمع اقلام</dt><dd>{{ money($its->sum('total')) }} تومان</dd></div>
                                                @if ((int) $o->extra_discount)<div><dt>تخفیف</dt><dd>− {{ money($o->extra_discount) }} تومان</dd></div>@endif
                                                @if ((int) $o->freight_fee)<div><dt>کرایه حمل</dt><dd>{{ money($o->freight_fee) }} تومان</dd></div>@endif
                                                <div class="t"><dt>مبلغ سفارش</dt><dd>{{ money($o->total) }} تومان</dd></div>
                                                @if ($paidSum)<div><dt>پرداخت تأییدشده</dt><dd>{{ money($paidSum) }} تومان</dd></div>@endif
                                            </dl>
                                            <a href="{{ route('invoice', $o->number) }}" target="_blank" rel="noopener" class="ol-inv">🧾 فاکتور قابل چاپ</a>
                                        </details>
                                    @endif
                                    <div class="ol-act jr-{{ $act['tone'] }}"><span aria-hidden="true">{{ $act['icon'] }}</span><span><b>{{ $act['title'] }}</b>@if ($act['text'])<br>{{ $act['text'] }}@endif</span></div>
                                    <div class="ol-btns">
                                        <a href="{{ $act['href'] && ! str_contains($act['href'], 'waybill') ? $act['href'] : route('order.show', $o->number) }}" class="btn">{{ $act['tone'] === 'todo' && $act['btn'] ? $act['btn'] : 'مشاهده و پیگیری سفارش' }}</a>
                                        @if ($o->status === 'completed' && $supUrl)
                                            <a href="{{ $supUrl }}" target="_blank" rel="noopener" class="btn btn-support">💬 پشتیبانی</a>
                                        @endif
                                    </div>
                                </article>
                            @endforeach
                        </div>
                        @include('store.partials.pager', ['paginator' => $orders])
                    @endif
                </div>
            @endif
        </section>
    </div>
</main>
@endsection
