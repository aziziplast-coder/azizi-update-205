<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ setting('closed_title') }} | {{ store_name() }}</title>
<meta name="robots" content="noindex">
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}"><link rel="stylesheet" href="{{ asset('css/app.css') }}">
<style>:root{--brand:{{ setting('brand_color', '#4f4a63') }};--font:{!! \App\Support\Fonts::stack() !!}}</style>
</head>
<body style="padding:0">
<div class="closed">
    <div class="card">
        @if (setting('logo'))<img src="{{ upload_url(setting('logo')) }}" alt="" style="max-height:64px">@else<span class="logo-mark" style="width:64px;height:64px;font-size:28px">{{ mb_substr(store_name(), 0, 1) }}</span>@endif
        <h1>{{ setting('closed_title') }}</h1>
        <p class="muted" style="margin:0">{{ setting('closed_message') }}</p>
        @if (setting('reopen_at'))<p style="margin:0">بازگشایی: <b>{{ fa(setting('reopen_at')) }}</b></p>@endif
        @if (setting('phone'))<a class="btn" href="tel:{{ en_digits(setting('phone')) }}">تماس: <span class="ltr">{{ fa(setting('phone')) }}</span></a>@endif
        <a href="{{ route('login') }}" class="muted" style="font-size:12px">ورود مدیر</a>
    </div>
</div>
</body>
</html>
