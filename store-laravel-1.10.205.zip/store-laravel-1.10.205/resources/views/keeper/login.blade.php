@extends('keeper.layout', ['title' => 'ورود', 'bodyClass' => 'kp-login'])

@section('body')
<main class="kl">
    <div class="kl-card">
        <img src="{{ route('pwa.icon', 192) }}" alt="" class="kl-logo">
        <h1>{{ setting('keeper_app_name') ?: 'کارتابل انبار' }}</h1>
        <p>{{ store_name() }}</p>
        @if ($errors->any())<div class="k-alert">{{ $errors->first() }}</div>@endif
        <form method="post" action="{{ url('/keeper/login') }}" class="kl-form">
            @csrf
            <label>شماره موبایل<input name="mobile" inputmode="tel" autocomplete="username" dir="ltr" value="{{ old('mobile') }}" required></label>
            <label>رمز عبور<input type="password" name="password" autocomplete="current-password" dir="ltr" required></label>
            <button class="k-btn k-btn-pri k-btn-lg" type="submit">ورود به کارتابل</button>
        </form>
        <small>رمز عبور را مدیر فروشگاه در بخش «کارمندان» تعیین می‌کند.</small>
    </div>
</main>
@endsection
