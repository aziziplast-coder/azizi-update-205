<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="{{ setting('brand_color', '#4f4a63') }}">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="{{ setting('keeper_app_name') ?: 'کارتابل انبار' }}">
<meta name="format-detection" content="telephone=no">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>{{ $title ?? 'کارتابل انبار' }} | {{ store_name() }}</title>
<link rel="manifest" href="{{ route('keeper.manifest') }}">
<link rel="apple-touch-icon" href="{{ route('pwa.icon', 192) }}">
<link rel="icon" href="{{ route('pwa.icon', 64) }}">
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}?v={{ config('store.version') }}">
<link rel="stylesheet" href="{{ asset('css/keeper.css') }}?v={{ @filemtime(public_path('css/keeper.css')) }}">
<style>:root{--ac:{{ setting('brand_color', '#4f4a63') }};--font:{!! \App\Support\Fonts::stack() !!}}</style>
</head>
<body class="kp {{ $bodyClass ?? '' }}">
@if (session('kp_msg'))<div class="k-notice" onclick="this.remove()">{{ session('kp_msg') }}</div>@endif
@yield('body')
@php
    $kpData = ($kp ?? []) + ['csrf' => csrf_token(), 'sw' => route('pwa.worker'), 'push' => null, 'icon' => route('pwa.icon', 192)];
    if (\App\Services\WebPush::enabled()) {
        $kpData['push'] = ['key' => \App\Services\WebPush::keys()['public'], 'url' => route('push.subscribe')];
    }
@endphp
<script>window.KP = {!! json_encode($kpData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) !!};</script>
<script src="{{ asset('js/keeper.js') }}?v={{ @filemtime(public_path('js/keeper.js')) }}"></script>
</body>
</html>
