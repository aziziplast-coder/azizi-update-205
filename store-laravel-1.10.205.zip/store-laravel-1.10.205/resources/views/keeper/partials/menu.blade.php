<div class="k-sheet" data-sheet="menu" hidden>
    <div class="k-sheet-box">
        <h3>منو</h3>
        <button type="button" class="k-row" data-install hidden>📲 نصب اپ روی این دستگاه</button>
        <button type="button" class="k-row" data-push>🔔 اعلان حواله جدید <small data-notif-state></small></button>
        <button type="button" class="k-row" data-sound>🔊 آزمایش صدای هشدار</button>
        @if (! $user->isKeeper())<a class="k-row" href="{{ url('/admin') }}">⚙️ پنل مدیریت</a>@endif
        <form method="post" action="{{ route('keeper.logout') }}">@csrf<button class="k-row k-danger" type="submit">⎋ خروج از حساب</button></form>
        <button type="button" class="k-btn k-btn-ghost" data-close>بستن</button>
    </div>
</div>
<div class="k-sheet" data-sheet="notif" hidden>
    <div class="k-sheet-box">
        <h3>اعلان حواله جدید</h3>
        <div class="k-help" data-notif-body></div>
        <button type="button" class="k-btn" data-notif-retry>دوباره امتحان کن</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>بستن</button>
    </div>
</div>
