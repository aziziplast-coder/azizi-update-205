@extends('keeper.layout', ['title' => 'بررسی بار '.$order->number, 'bodyClass' => 'kp-task kp-check', 'kp' => [
    'page' => 'check', 'state' => $state, 'base' => url('/keeper/check/'.$task->id), 'home' => url('/keeper'),
]])

@section('body')
<header class="k-top k-top-task">
    <div class="k-top-row">
        <a href="{{ url('/keeper') }}" class="k-icon" aria-label="بازگشت"><svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg></a>
        <div class="k-brand">
            <b>بررسی بار — سفارش {{ fa($order->number) }}</b>
            <small>{{ $order->customer_name }} · جمع‌کننده: {{ $task->picker?->displayName() ?? '—' }}@if ($order->assignee) · 🎧 کارشناس: {{ $order->assignee->displayName() }}@endif</small>
        </div>
        <a class="k-icon k-call" href="tel:{{ $order->mobile }}" aria-label="تماس با مشتری"><svg viewBox="0 0 24 24"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2"/></svg></a>
    </div>
    <div class="k-bay-big">📍 جایگاه بار: <b>{{ $task->bay ?: 'نامشخص' }}</b></div>
    <div class="k-prog"><i data-prog></i><span data-prog-text></span></div>
    <div class="k-scan">
        <input type="text" data-scan inputmode="none" enterkeyhint="go" placeholder="آماده اسکن… (بارکدخوان را بزنید)" autocomplete="off" autocorrect="off" spellcheck="false">
        <button type="button" class="k-icon" data-kbd aria-label="تایپ دستی بارکد" title="تایپ دستی"><svg viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10h.01M11 10h.01M15 10h.01M7 14h10"/></svg></button>
    </div>
</header>

<main class="k-items" data-items></main>

<footer class="k-foot">
    <span class="k-saved" data-saved>کارتن‌های برچسب‌دار را اسکن کنید؛ عددهای بدون برچسب را «تأیید دستی» بزنید</span>
    <div class="k-foot-btns">
        <button type="button" class="k-btn k-btn-ghost" data-back-picker>برگشت به جمع‌کننده</button>
        <button type="button" class="k-btn k-btn-ok" data-approve>تأیید نهایی بار ✓</button>
    </div>
</footer>

<div class="k-sheet" data-sheet="approve" hidden>
    <div class="k-sheet-box">
        <h3>همه اقلام بررسی نشده</h3>
        <div class="k-diff" data-diff></div>
        <button type="button" class="k-btn k-btn-ok k-btn-lg" data-approve-mode="scanned">تأیید طبق اسکن و تأیید دستی (بقیه کسری ثبت شود)</button>
        <button type="button" class="k-btn" data-approve-mode="picker">تأیید طبق شمارش جمع‌کننده</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>ادامه اسکن</button>
    </div>
</div>
<div class="k-sheet" data-sheet="fee" hidden>
    <div class="k-sheet-box">
        <h3>🚚 کرایه حمل تا باربری</h3>
        <p class="k-muted" data-fee-title></p>
        <p class="k-muted">کرایه حمل بار از شرکت تا باربری تهران؛ به فاکتور و حساب مشتری اضافه می‌شود.</p>
        <input class="k-bay-input" data-fee-input type="text" inputmode="numeric" dir="ltr" placeholder="مبلغ به تومان" style="font-size:22px;text-align:center" autocomplete="off">
        <button type="button" class="k-btn k-btn-ok k-btn-lg" data-fee-ok>ثبت کرایه و تأیید نهایی بار</button>
        <button type="button" class="k-btn" data-fee-later>تأیید نهایی — کرایه را بعداً ثبت می‌کنم</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>انصراف</button>
    </div>
</div>
<div class="k-sheet" data-sheet="manual" hidden>
    <div class="k-sheet-box">
        <h3>✋ تأیید دستی (عددهای بدون برچسب بارکد)</h3>
        <b data-man-name></b>
        <p class="k-muted" data-man-info></p>
        <label class="k-muted" style="display:grid;gap:6px">تعداد عددی که شمردید و تأیید می‌کنید
            <input class="k-bay-input" data-man-input type="text" inputmode="numeric" dir="ltr" style="font-size:22px;text-align:center" autocomplete="off">
        </label>
        <button type="button" class="k-btn k-btn-ok k-btn-lg" data-man-ok>ثبت تأیید دستی</button>
        <button type="button" class="k-btn k-btn-ghost" data-man-clear>برداشتن تأیید دستی</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>انصراف</button>
    </div>
</div>
<div class="k-sheet" data-sheet="back" hidden>
    <div class="k-sheet-box">
        <h3>برگشت به جمع‌کننده</h3>
        <p class="k-muted">فاکتور با توضیح شما دوباره در کارتابل جمع‌کننده می‌نشیند.</p>
        <input class="k-bay-input" data-back-note maxlength="190" placeholder="توضیح (مثلاً: ۲ کارتن جاصابونی کم است)">
        <button type="button" class="k-btn k-btn-bad k-btn-lg" data-back-ok>برگرداندن</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>انصراف</button>
    </div>
</div>
<div class="k-alarm" data-alarm hidden><b data-alarm-title></b><span data-alarm-text></span><small>برای ادامه لمس کنید</small></div>
<div class="k-toast" data-toast hidden></div>
@endsection
