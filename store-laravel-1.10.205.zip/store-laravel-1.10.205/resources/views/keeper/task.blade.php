@extends('keeper.layout', ['title' => 'سفارش '.$order->number, 'bodyClass' => 'kp-task', 'kp' => [
    'page' => 'task', 'state' => $state, 'keepers' => $keepers,
    'base' => url('/keeper/task/'.$task->id), 'home' => url('/keeper'),
]])

@section('body')
<header class="k-top k-top-task">
    <div class="k-top-row">
        <a href="{{ url('/keeper') }}" class="k-icon" aria-label="بازگشت"><svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg></a>
        <div class="k-brand">
            <b>سفارش {{ fa($order->number) }}@if ($task->round > 1) <span class="k-chip k-chip-add">جایگزین</span>@endif</b>
            <small>{{ $order->customer_name }}@if ($order->assignee) · 🎧 کارشناس: {{ $order->assignee->displayName() }}@endif</small>
        </div>
        <button type="button" class="k-icon" data-info-btn aria-label="مشخصات سفارش"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/></svg></button>
        <a class="k-icon k-call" href="tel:{{ $order->mobile }}" aria-label="تماس با مشتری"><svg viewBox="0 0 24 24"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2"/></svg></a>
    </div>
    <div class="k-info" data-info @if ($task->keeper) hidden @endif>
        <span>{{ trim(($order->province ? $order->province.'، ' : '').$order->city) ?: '—' }}</span>
        <a href="tel:{{ $order->mobile }}" dir="ltr">{{ fa($order->mobile) }}</a>
        @if ($order->company)<span>{{ $order->company }}</span>@endif
        @if ($task->keeper)<span>انباردار: {{ $task->keeper->displayName() }}</span>@else<span class="k-warn">بدون انباردار</span>
            @if (\App\Services\Picking::seesAll(auth()->user()) && $task->status !== 'done')
                <form method="post" action="{{ route('keeper.resplit', $task) }}" style="display:inline">@csrf<button class="k-chip-btn" type="submit" onclick="return confirm('اقلام این سفارش بر اساس انبار فعلی کالاها بین انباردارها تقسیم شود؟ (تیک‌ها و تعدادهای ثبت‌شده حفظ می‌شوند)')">⇄ تقسیم بین انباردارها</button></form>
            @endif
        @endif
    </div>
    @if ($order->note)<div class="k-note">📝 {{ $order->note }}</div>@endif
    <div class="k-prog"><i data-prog></i><span data-prog-text></span></div>
    <div class="k-scan">
        <input type="search" data-scan inputmode="search" enterkeyhint="search" placeholder="اسکن بارکد یا جستجو" autocomplete="off">
        <button type="button" class="k-icon" data-scan-btn aria-label="اسکنر"><svg viewBox="0 0 24 24"><path d="M4 7V5a1 1 0 011-1h2M17 4h2a1 1 0 011 1v2M20 17v2a1 1 0 01-1 1h-2M7 20H5a1 1 0 01-1-1v-2M7 8v8M10 8v8M13 8v8M16 8v8"/></svg></button>
    </div>
    <nav class="k-chips">
        <button type="button" class="on" data-filter="left">مانده</button>
        <button type="button" data-filter="ok">انجام‌شده</button>
        <button type="button" data-filter="all">همه</button>
    </nav>
</header>

<main class="k-items" data-items></main>

<footer class="k-foot" data-foot>
    <span class="k-saved" data-saved>هر تیک خودکار ذخیره می‌شود</span>
    <div class="k-foot-btns">
        <button type="button" class="k-btn k-btn-ghost" data-tempsave>ذخیره موقت</button>
        <button type="button" class="k-btn k-btn-ok" data-done>پایان حواله ✓</button>
    </div>
</footer>

<div class="k-sheet" data-sheet="move" hidden>
    <div class="k-sheet-box">
        <h3>انتقال به انباردار دیگر</h3>
        <p class="k-muted" data-move-name></p>
        <div class="k-move-list" data-move-list></div>
        <button type="button" class="k-btn k-btn-ghost" data-close>انصراف</button>
    </div>
</div>
<div class="k-sheet" data-sheet="done" hidden>
    <div class="k-sheet-box">
        <h3>پایان جمع‌آوری</h3>
        <p data-done-msg></p>
        <button type="button" class="k-btn k-btn-bad k-btn-lg" data-done-missing>بله، بررسی‌نشده‌ها ناموجود حساب شوند</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>بازگشت و بررسی</button>
    </div>
</div>
<div class="k-sheet" data-sheet="bay" hidden>
    <div class="k-sheet-box">
        <h3>بار را کجا گذاشتید؟</h3>
        <p class="k-muted">جایگاه بار را بنویسید تا {{ $task->stage !== null ? 'سرپرست' : 'مسئول سفارش' }} بار را پیدا کند؛ مثلاً «سکوی ۳» یا «کنار درب ۲».</p>
        <input class="k-bay-input" data-bay-input maxlength="80" placeholder="جایگاه بار" autocomplete="off" enterkeyhint="done">
        <div class="k-bay-recent" data-bay-recent></div>
        <button type="button" class="k-btn k-btn-ok k-btn-lg" data-bay-ok>ثبت و پایان</button>
        <button type="button" class="k-btn k-btn-ghost" data-bay-skip>بدون جایگاه، پایان</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>بازگشت</button>
    </div>
</div>
<div class="k-flash" data-flash hidden><b data-flash-title></b><span data-flash-text></span></div>
<div class="k-toast" data-toast hidden></div>
@endsection
