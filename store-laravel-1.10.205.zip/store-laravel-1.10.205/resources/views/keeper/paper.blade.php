@extends('keeper.layout', ['title' => 'بررسی فاکتور '.$order->number, 'bodyClass' => 'kp-task kp-paper', 'kp' => [
    'page' => 'paper', 'state' => $state, 'base' => url('/keeper/paper/'.$task->id), 'approve' => url('/keeper/check/'.$task->id.'/approve'), 'home' => url('/keeper'),
]])

@section('body')
<header class="k-top k-top-task">
    <div class="k-top-row">
        <a href="{{ url('/keeper') }}" class="k-icon" aria-label="بازگشت"><svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg></a>
        <div class="k-brand">
            <b>بررسی فاکتور کاغذی — {{ fa($order->number) }}@if ($task->round > 1) <span class="k-chip k-chip-add">جایگزین</span>@endif</b>
            <small>{{ $order->customer_name }} · جمع‌کننده: {{ $task->picker?->displayName() ?? '—' }}@if ($order->assignee) · 🎧 کارشناس: {{ $order->assignee->displayName() }}@endif</small>
        </div>
        <a class="k-icon k-call" href="tel:{{ $order->mobile }}" aria-label="تماس با مشتری"><svg viewBox="0 0 24 24"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2"/></svg></a>
    </div>
    <div class="k-paper-hint">📝 فقط اقلامی را بزنید که جمع‌کننده روی فاکتور <b>تغییر</b> نوشته (کم یا ناموجود). بقیه «موجود طبق فاکتور» ثبت می‌شوند.</div>
    <div class="k-scan">
        <input type="search" data-q inputmode="search" enterkeyhint="search" placeholder="جستجوی نام یا کد کالا" autocomplete="off">
    </div>
    <div class="k-paper-sum" data-sum></div>
</header>

<main class="k-items" data-items></main>

<footer class="k-foot">
    <span class="k-saved" data-saved>هر تغییر خودکار ذخیره می‌شود</span>
    <div class="k-foot-btns">
        <button type="button" class="k-btn k-btn-ok k-btn-lg ready" data-approve>✓ باقی موارد موجود بودند — تأیید نهایی</button>
    </div>
</footer>

<div class="k-sheet" data-sheet="edit" hidden>
    <div class="k-sheet-box">
        <h3 data-ed-name></h3>
        <p class="k-muted" data-ed-want></p>
        <div class="k-ed-acts">
            <button type="button" class="k-btn k-btn-bad" data-ed-missing>✗ ناموجود</button>
            <button type="button" class="k-btn" data-ed-full>✓ موجود کامل</button>
        </div>
        <div class="k-edit" data-ed-steps></div>
        <div class="k-edit-sum"><span>جمع‌شده: <b data-ed-sum></b></span></div>
        <input class="k-edit-note" data-ed-note maxlength="190" placeholder="یادداشت (اختیاری) — مثلاً «کارتن آسیب‌دیده»">
        <button type="button" class="k-btn k-btn-ok k-btn-lg" data-ed-ok>ثبت تعداد کمتر</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>انصراف</button>
    </div>
</div>
<div class="k-sheet" data-sheet="bay" hidden>
    <div class="k-sheet-box">
        <h3>📍 جایگاه بار</h3>
        <p class="k-muted">بار بررسی شد. جایگاه بار را بنویسید تا مسئول سفارش و بارگیری آن را پیدا کنند؛ مثلاً «سکوی ۳» یا «کنار درب ۲».</p>
        <input class="k-bay-input" data-bay-input maxlength="80" placeholder="جایگاه بار" autocomplete="off" enterkeyhint="done">
        <div class="k-bay-recent" data-bay-recent></div>
        <button type="button" class="k-btn k-btn-ok k-btn-lg" data-bay-ok>ثبت جایگاه</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>بازگشت</button>
    </div>
</div>
<div class="k-sheet" data-sheet="fee" hidden>
    <div class="k-sheet-box">
        <h3>🚚 کرایه حمل تا باربری</h3>
        <p class="k-muted" data-fee-title></p>
        <p class="k-muted">کرایه حمل بار از شرکت تا باربری؛ به فاکتور و حساب مشتری اضافه می‌شود.</p>
        <input class="k-bay-input" data-fee-input type="text" inputmode="numeric" dir="ltr" placeholder="مبلغ به تومان" style="font-size:22px;text-align:center" autocomplete="off">
        <button type="button" class="k-btn k-btn-ok k-btn-lg" data-fee-ok>ثبت کرایه و تأیید نهایی</button>
        <button type="button" class="k-btn" data-fee-later>تأیید نهایی — کرایه را بعداً ثبت می‌کنم</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>انصراف</button>
    </div>
</div>
<div class="k-sheet" data-sheet="confirm" hidden>
    <div class="k-sheet-box">
        <h3>تأیید نهایی فاکتور</h3>
        <div class="k-diff" data-confirm-body></div>
        <button type="button" class="k-btn k-btn-ok k-btn-lg" data-confirm-ok>بله، تأیید نهایی</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>بازگشت</button>
    </div>
</div>
<div class="k-toast" data-toast hidden></div>
@endsection
