@extends('keeper.layout', ['title' => 'سرپرست انبار', 'bodyClass' => 'kp-list kp-sup', 'kp' => ['page' => 'sup', 'data' => $data, 'api' => route('keeper.tasks'), 'me' => $user->id]])

@section('body')
<header class="k-top">
    <div class="k-top-row">
        <div class="k-brand">
            <b>{{ setting('keeper_app_name') ?: 'کارتابل انبار' }}</b>
            <small>{{ $user->displayName() }} — سرپرست</small>
        </div>
        <span class="k-live" data-live title="به‌روزرسانی خودکار"><i></i></span>
        <button type="button" class="k-icon" data-menu aria-label="منو"><svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
    </div>
    <nav class="k-tabs" role="tablist">
@php($paper = \App\Services\Picking::paper())
        <button type="button" class="on" data-tab="new">{{ $paper ? 'فاکتور جدید' : 'جدید' }} <em data-count="new">۰</em></button>
        <button type="button" data-tab="picking">{{ $paper ? 'دست جمع‌کننده' : 'در جریان' }} <em data-count="picking">۰</em></button>
        <button type="button" data-tab="review">بررسی <em data-count="review">۰</em></button>
        <button type="button" data-tab="ship">آماده ارسال <em data-count="ship">۰</em></button>
        <button type="button" data-tab="team">جمع‌کننده‌ها</button>
    </nav>
    @if ($paper)
    <div class="k-recv">
        <input type="text" data-recv-num inputmode="numeric" enterkeyhint="go" placeholder="📥 شماره فاکتور برگشتی (تایپ یا اسکن)" autocomplete="off">
        <button type="button" class="k-btn k-btn-ok" data-recv-go>تحویل گرفتم</button>
    </div>
    @endif
    <div class="k-search"><input type="search" data-q placeholder="جستجوی نام مشتری، شماره سفارش یا موبایل" autocomplete="off" enterkeyhint="search"></div>
</header>

<main class="k-list" data-list aria-live="polite"></main>

<div class="k-sheet" data-sheet="assign" hidden>
    <div class="k-sheet-box">
        <h3>{{ \App\Services\Picking::paper() ? '📄 تحویل فاکتور کاغذی به جمع‌کننده' : 'سپردن فاکتور' }}</h3>
        <p class="k-muted" data-assign-title></p>
        <div class="k-move-list" data-assign-list></div>
        <button type="button" class="k-btn k-btn-ghost" data-close>انصراف</button>
    </div>
</div>
<div class="k-sheet" data-sheet="load" hidden>
    <div class="k-sheet-box">
        <h3>🚚 بارگیری و تحویل به باربری</h3>
        <p class="k-muted" data-load-title></p>
        <label class="k-muted" data-load-fee-wrap style="display:grid;gap:6px">کرایه حمل از شرکت تا باربری (تومان) — اختیاری
            <input class="k-bay-input" data-load-fee type="text" inputmode="numeric" dir="ltr" placeholder="مثلاً ۸۵۰۰۰۰" autocomplete="off">
        </label>
        <button type="button" class="k-btn k-btn-ok k-btn-lg" data-load-ok>بارگیری شد ✓</button>
        <button type="button" class="k-btn k-btn-ghost" data-close>انصراف</button>
    </div>
</div>
<input type="file" accept="image/*,application/pdf" capture="environment" data-waybill-file hidden>
@include('keeper.partials.menu')
<div class="k-toast" data-toast hidden></div>
@endsection
