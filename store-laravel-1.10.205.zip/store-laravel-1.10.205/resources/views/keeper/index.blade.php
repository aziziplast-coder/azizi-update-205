@extends('keeper.layout', ['title' => 'کارتابل', 'bodyClass' => 'kp-list', 'kp' => ['page' => 'list', 'data' => $data, 'api' => route('keeper.tasks'), 'seesAll' => $seesAll, 'me' => $user->id]])

@section('body')
<header class="k-top">
    <div class="k-top-row">
        <div class="k-brand">
            <b>{{ setting('keeper_app_name') ?: 'کارتابل انبار' }}</b>
            <small>{{ $user->displayName() }}{{ $seesAll ? ' — همه انباردارها' : '' }}</small>
        </div>
        <span class="k-live" data-live title="به‌روزرسانی خودکار"><i></i></span>
        <button type="button" class="k-icon" data-menu aria-label="منو">
            <svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
        </button>
    </div>
    <nav class="k-tabs" role="tablist">
        <button type="button" class="on" data-tab="open">جاری <em data-count="open">۰</em></button>
        <button type="button" data-tab="added">افزوده‌ها <em data-count="added">۰</em></button>
        <button type="button" data-tab="done">جمع‌شده <em data-count="done">۰</em></button>
    </nav>
    @if ($seesAll)
        <div class="k-filter">
            <select data-keeper-filter>
                <option value="">همه انباردارها</option>
                <option value="none">بدون انباردار</option>
                @foreach ($keepers as $k)<option value="{{ $k['id'] }}">{{ $k['name'] }}</option>@endforeach
            </select>
        </div>
    @endif
</header>

<main class="k-list" data-list aria-live="polite"></main>

@include('keeper.partials.menu')
<div class="k-toast" data-toast hidden></div>
@endsection
