@php($appName = \App\Services\Walkin::appName())
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#0b1220">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="{{ $appName }}">
<meta name="format-detection" content="telephone=no">
<title>{{ $appName }} | {{ store_name() }}</title>
<link rel="manifest" href="{{ route('walkin.manifest') }}">
<link rel="apple-touch-icon" href="{{ asset('img/walkin-192.png') }}">
<link rel="icon" href="{{ asset('img/walkin-192.png') }}">
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}?v={{ config('store.version') }}">
<link rel="stylesheet" href="{{ asset('css/walkin.css') }}?v={{ @filemtime(public_path('css/walkin.css')) }}">
<style>:root{--font:{!! \App\Support\Fonts::stack() !!}}</style>
<script>addEventListener('beforeinstallprompt',function(e){e.preventDefault();window.__bip=e;});</script>
</head>
<body class="wk {{ $bodyClass ?? '' }}">
{{-- صفحه آغاز: نماد، نام اپ، معرفی و امضای طراح (هر بار باز شدن اپ، یک بار در هر نوبت) --}}
<div class="wk-splash" data-splash>
    <div class="sp-in">
        <img src="{{ asset('img/walkin-512.png') }}" alt="" width="112" height="112">
        <h1>{{ $appName }}</h1>
        <p>اسکن سریع بار مشتری حضوری<br>تطبیق دوباره هنگام تحویل · خروجی مستقیم هلو</p>
        <div class="sp-bar"><i></i></div>
        <small>{{ store_name() }}</small>
    </div>
    @if ($c = \App\Support\Credit::get())
        <div class="sp-cr">طراحی و توسعه نرم‌افزار<br>@if ($c['url'] !== '')<a href="{{ $c['url'] }}" target="_blank" rel="noopener">{{ $c['text'] }}</a>@else<b>{{ $c['text'] }}</b>@endif</div>
    @endif
</div>
<script>(function(){var s=document.querySelector('[data-splash]');try{if(sessionStorage.getItem('wk.sp')){s.remove();return;}sessionStorage.setItem('wk.sp','1');}catch(e){}setTimeout(function(){s.classList.add('out');setTimeout(function(){s.remove();},450);},1700);})();</script>
@yield('body')
<script src="{{ asset('js/wk-install.js') }}?v={{ @filemtime(public_path('js/wk-install.js')) }}" defer></script>
<script>if('serviceWorker' in navigator){addEventListener('load',function(){navigator.serviceWorker.register('{{ route('pwa.worker') }}').catch(function(){});});}</script>
</body>
</html>
