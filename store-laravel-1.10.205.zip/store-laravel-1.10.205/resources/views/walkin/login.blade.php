@extends('walkin.layout', ['bodyClass' => 'wk-login'])

@section('body')
<main class="lg">
    <div class="lg-brand">
        <img src="{{ asset('img/walkin-192.png') }}" alt="" width="84" height="84">
        <h1>{{ \App\Services\Walkin::appName() }}</h1>
        <p>{{ store_name() }}</p>
    </div>
    <form method="post" action="{{ url('/walkin/login') }}" class="lg-card">
        @csrf
        @if ($errors->any())<div class="lg-err">{{ $errors->first() }}</div>@endif
        <label>شماره موبایل<input name="mobile" type="tel" inputmode="tel" autocomplete="username" value="{{ old('mobile') }}" required dir="ltr"></label>
        <label>رمز عبور<input name="password" type="password" autocomplete="current-password" required dir="ltr"></label>
        <button type="submit" class="wk-btn pri big">ورود</button>
    </form>
    <button type="button" class="wk-inst" data-install hidden>📲 نصب برنامه روی گوشی</button>
    <ul class="lg-feat">
        <li><b>⚡</b>اسکن آنی با بارکدخوان بلوتوثی — هر اسکن یک کارتن</li>
        <li><b>🔁</b>تطبیق دوباره هنگام تحویل و هشدار خطای شمارش</li>
        <li><b>📊</b>جمع تقریبی فاکتور و خروجی مستقیم اکسل هلو</li>
    </ul>
    {!! \App\Support\Credit::html('color:#94a3b8;padding-top:18px') !!}
</main>
@endsection
