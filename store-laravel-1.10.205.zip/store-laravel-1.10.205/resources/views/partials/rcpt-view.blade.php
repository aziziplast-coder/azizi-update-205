{{-- نمایشگر فیش همکاران: بزرگ‌نمایی، جابه‌جایی و چرخاندن (فایل روی سرور) --}}
<script>window.RCPT = {!! json_encode(['rot' => str_replace('999999999', '{id}', route('admin.remit.rotate', 999999999, false)), 'csrf' => csrf_token()], JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!};</script>
<script src="{{ asset('js/rcpt-view.js') }}?v={{ @filemtime(public_path('js/rcpt-view.js')) }}"></script>
