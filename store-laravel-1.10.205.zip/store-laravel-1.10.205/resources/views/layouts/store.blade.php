@php
    $brand = setting('brand_color', '#4f4a63');
    $mode = setting('theme_mode', 'toggle');
    $title = trim(($title ?? '') !== '' ? $title.' | '.store_name() : (setting('seo_title') ?: store_name().' — '.setting('store_tagline')));
    $desc = $description ?? setting('seo_description') ?: setting('about');
    $cart = app(\App\Services\Cart::class);
    $menuCats = \Illuminate\Support\Facades\Cache::remember('menu.cats', 600, fn () => \App\Models\Category::query()->active()->where('in_menu', true)->whereNull('parent_id')->orderBy('sort')->orderBy('name')->with(['children' => fn ($q) => $q->where('is_active', true)->with(['children' => fn ($x) => $x->where('is_active', true)])])->limit(30)->get());
    $pv = in_array(setting('mobile_view'), ['list', 'grid2', 'grid4'], true) ? setting('mobile_view') : 'list';
    $ogImage = $ogImage ?? (setting('seo_og_image') ? upload_url(setting('seo_og_image')) : null);
    $popup = \App\Support\Popup::current();
    $pushOn = \App\Services\WebPush::enabled();
@endphp
<!doctype html>
<html lang="fa" dir="rtl" data-theme="{{ $mode === 'dark' ? 'dark' : 'light' }}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content">
@if (session('in_app'))<script>try{sessionStorage.setItem('app','1')}catch(e){}</script>@endif
<script>/* حالت اپ نصب‌شده (PWA): بدون زوم، صفحه ثابت */(function(){var d=document.documentElement,a=false;try{a=matchMedia('(display-mode: standalone)').matches||matchMedia('(display-mode: fullscreen)').matches||navigator.standalone===true||/StoreWebApp/.test(navigator.userAgent)||/[?&](source=pwa|app=1)/.test(location.search)||sessionStorage.getItem('app')==='1';if(a)sessionStorage.setItem('app','1')}catch(e){}if(a){d.classList.add('is-app');var m=document.querySelector('meta[name=viewport]');if(m)m.setAttribute('content','width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover')}})()</script>
<title>{{ $title }}</title>
<meta name="description" content="{{ \Illuminate\Support\Str::limit(strip_tags((string) $desc), 160) }}">
<link rel="canonical" href="{{ $canonical ?? url()->current() }}">
@if (! empty($noindex))<meta name="robots" content="noindex, follow">@endif
<meta property="og:site_name" content="{{ store_name() }}">
<meta property="og:title" content="{{ $title }}">
<meta property="og:description" content="{{ \Illuminate\Support\Str::limit(strip_tags((string) $desc), 160) }}">
<meta property="og:locale" content="fa_IR">
@isset($ogImage)<meta property="og:image" content="{{ url($ogImage) }}">@endisset
<meta name="theme-color" content="{{ $brand }}">
@if (setting('pwa_enabled', true))
<link rel="manifest" href="{{ route('pwa.manifest') }}">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="{{ setting('pwa_short_name') ?: mb_substr(store_name(), 0, 12) }}">
{{-- آیفون: آیکون ۱۸۰ تمام‌قد؛ «v» با عوض شدن آیکون عوض می‌شود تا گوشی نسخه قدیمی را از حافظه نخواند --}}
<link rel="apple-touch-icon" sizes="180x180" href="{{ route('pwa.icon', 180) }}?v={{ substr(md5((string) (setting('pwa_icon') ?: setting('logo')).setting('brand_color')), 0, 8) }}">
@endif
<link rel="icon" href="{{ setting('favicon') ? upload_url(setting('favicon')) : route('pwa.icon', 64) }}">
<link rel="preload" href="{{ asset('fonts/vazirmatn-Regular.woff2') }}" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}?v={{ config('store.version') }}">
<link rel="stylesheet" href="{{ asset('css/app.css') }}?v={{ config('store.version') }}">
@if (setting('seo_google_verify'))<meta name="google-site-verification" content="{{ setting('seo_google_verify') }}">@endif
@if (setting('seo_bing_verify'))<meta name="msvalidate.01" content="{{ setting('seo_bing_verify') }}">@endif
<meta name="twitter:card" content="summary_large_image">
<script>(function(){var d=document.documentElement;try{d.dataset.pv=localStorage.getItem('pv14')||'{{ $pv }}'}catch(e){d.dataset.pv='{{ $pv }}'}})()</script>
<script type="speculationrules">{"prefetch":[{"where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/admin*","/logout","/cart*","/checkout*","/payment/*","/*\\?*add=*"]}},{"not":{"selector_matches":"[data-no-prefetch], [download]"}}]},"eagerness":"conservative"}]}</script>
<style>:root{--brand:{{ $brand }};--font:{!! \App\Support\Fonts::stack() !!};--r:{{ (int) setting('radius', 16) }}px}{!! \App\Support\Fonts::customCss() !!}</style>
@if ($mode === 'toggle' || $mode === 'auto')
<script>(function(){try{var t=localStorage.getItem('theme');if(!t&&{{ $mode === 'auto' ? 'true' : 'false' }}&&matchMedia('(prefers-color-scheme: dark)').matches)t='dark';if(t)document.documentElement.dataset.theme=t}catch(e){}})()</script>
@endif
@stack('head')
{!! setting('head_code') !!}
</head>
<body>
@include('store.partials.icons')
@if (\App\Http\Middleware\StoreOpen::closed())
    <div class="alert alert-err" style="border-radius:0;justify-content:center">{{ setting('closed_title') }} — {{ setting('closed_message') }}</div>
@endif
@if (setting('topbar_text') || setting('phone'))
<div class="topbar"><div class="wrap"><span>{{ setting('topbar_text') }}</span>@if (setting('phone'))<a class="ltr" href="tel:{{ en_digits(setting('phone')) }}">{{ fa(setting('phone')) }}</a>@endif</div></div>
@endif
<header class="hdr">
    <div class="wrap hdr-row">
        <button type="button" class="icon-btn app-back" data-app-back aria-label="بازگشت" hidden><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg></button>
        <button type="button" class="icon-btn menu-btn m-only" aria-label="منو" data-drawer-open><svg class="ic"><use href="#i-menu"/></svg></button>
        <b class="app-title" data-app-title hidden></b>
        <button type="button" class="icon-btn app-search-btn" data-app-search aria-label="جستجو" hidden><svg class="ic"><use href="#i-search"/></svg></button>
        <a href="{{ route('home') }}" class="logo" aria-label="{{ store_name() }}">
            @if (setting('logo'))
                <img class="logo-img" src="{{ upload_url(setting('logo')) }}" alt="{{ store_name() }}">
            @else
                <span class="logo-mark">{{ mb_substr(store_name(), 0, 1) }}</span>
                <span class="logo-text"><b>{{ store_name() }}</b>@if (setting('store_tagline'))<small>{{ setting('store_tagline') }}</small>@endif</span>
            @endif
        </a>
        <form class="search" action="{{ route('shop') }}" method="get" role="search" data-suggest="{{ route('search.suggest') }}">
            <label><svg class="ic"><use href="#i-search"/></svg><span class="sr">جستجو</span>
                <input type="search" name="q" value="{{ request('q') }}" placeholder="جستجوی نام کالا یا بارکد…" autocomplete="off" enterkeyhint="search"></label>
            <div class="suggest" hidden></div>
        </form>
        <div class="hdr-actions">
            @if ($mode === 'toggle' || $mode === 'auto')
                <button type="button" class="icon-btn d-only" data-theme-toggle aria-label="حالت شب و روز"><svg class="ic"><use href="#i-moon"/></svg></button>
            @endif
            @auth
                <a href="{{ route('account') }}" class="acct-btn d-only"><svg class="ic"><use href="#i-user"/></svg>{{ \Illuminate\Support\Str::limit(auth()->user()->displayName(), 18) }}</a>
            @else
                <a href="{{ route('login') }}" class="acct-btn d-only"><svg class="ic"><use href="#i-user"/></svg>ورود | ثبت‌نام</a>
            @endauth
            <a href="{{ route('cart') }}" class="icon-btn filled d-only" aria-label="سبد خرید"><svg class="ic"><use href="#i-bag"/></svg><span class="cart-count{{ $cart->count() ? '' : ' is-empty' }}" data-cart-count>{{ fa($cart->count()) }}</span></a>
            <a href="{{ auth()->check() ? route('account') : route('login') }}" class="icon-btn m-only" aria-label="حساب کاربری"><svg class="ic"><use href="#i-user"/></svg></a>
        </div>
    </div>
    <nav class="hdr-nav" aria-label="منوی اصلی">
        <div class="wrap">
            @if ($menuCats->isNotEmpty())
            <div class="mega" data-mega>
                <button type="button" class="mega-btn" aria-expanded="false" aria-haspopup="true"><svg class="ic"><use href="#i-menu"/></svg>دسته‌بندی کالاها</button>
                <div class="mega-panel" role="menu">
                    <ul class="mega-roots">
                        @foreach ($menuCats as $i => $mc)
                            <li @class(['on' => $i === 0]) data-mega-root="{{ $i }}"><a href="{{ $mc->url() }}" role="menuitem">@if ($mc->iconPath())<img src="{{ thumb($mc->iconPath(), 64) }}" alt="" loading="lazy" width="24" height="24">@endif{{ $mc->name }}</a></li>
                        @endforeach
                    </ul>
                    @foreach ($menuCats as $i => $mc)
                        <div class="mega-sub" data-mega-sub="{{ $i }}" @if ($i) hidden @endif>
                            <a class="mega-all" href="{{ $mc->url() }}">همه کالاهای {{ $mc->name }} <svg class="ic"><use href="#i-chev"/></svg></a>
                            @if ($mc->children->isNotEmpty())
                                <div class="mega-cols">
                                    @foreach ($mc->children as $ch)
                                        <div class="mega-col">
                                            <a class="mega-h" href="{{ $ch->url() }}">@if ($ch->iconPath())<img src="{{ thumb($ch->iconPath(), 64) }}" alt="" loading="lazy" width="28" height="28">@endif{{ $ch->name }}</a>
                                            @foreach ($ch->children as $g)<a href="{{ $g->url() }}">{{ $g->name }}</a>@endforeach
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <p class="muted">زیردسته‌ای ندارد.</p>
                            @endif
                        </div>
                    @endforeach
                </div>
            </div>
            @endif
            <div class="nav-links">
            <a href="{{ route('home') }}" @class(['on' => request()->routeIs('home')])>خانه</a>
            <a href="{{ route('shop') }}" @class(['on' => request()->routeIs('shop') && ! request('q')])>همه محصولات</a>
            @if (data_get(setting('amazing'), 'enabled'))<a href="{{ route('amazing') }}" @class(['nav-hot', 'on' => request()->routeIs('amazing')])><svg class="ic"><use href="#i-fire"/></svg>{{ data_get(setting('amazing'), 'title', 'شگفت‌انگیز') }}</a>@endif
            @foreach ($menuCats->take(6) as $mc)
                <a href="{{ $mc->url() }}" @class(['nav-cat', 'on' => request()->is('category/'.$mc->slug)])>{{ $mc->name }}</a>
            @endforeach
            @if (\App\Support\BlogState::has())<a href="{{ route('blog') }}" @class(['on' => request()->routeIs('blog*')])>{{ setting('blog_title', 'مجله') }}</a>@endif
            </div>
        </div>
    </nav>
</header>
@include('store.partials.edit-bar')

<div class="drawer" data-drawer aria-hidden="true">
    <div class="drawer-bg" data-drawer-close></div>
    <nav class="drawer-panel" aria-label="منو">
        <div class="drawer-head"><b>{{ store_name() }}</b><button type="button" class="icon-btn" data-drawer-close aria-label="بستن"><svg class="ic"><use href="#i-close"/></svg></button></div>
        <a href="{{ route('home') }}">خانه</a>
        <a href="{{ route('shop') }}">همه محصولات</a>
        @if (data_get(setting('amazing'), 'enabled'))<a href="{{ route('amazing') }}">{{ data_get(setting('amazing'), 'title', 'شگفت‌انگیز') }}</a>@endif
        @foreach ($menuCats as $mc)
            @if ($mc->children->isNotEmpty())
                <details class="drawer-acc">
                    <summary>{{ $mc->name }}</summary>
                    <a class="drawer-sub" href="{{ $mc->url() }}">همه {{ $mc->name }}</a>
                    @foreach ($mc->children as $sub)<a class="drawer-sub" href="{{ $sub->url() }}">{{ $sub->name }}</a>@endforeach
                </details>
            @else
                <a href="{{ $mc->url() }}">{{ $mc->name }}</a>
            @endif
        @endforeach
        @if (\App\Support\BlogState::has())<a href="{{ route('blog') }}">{{ setting('blog_title', 'مجله') }}</a>@endif
        <a href="{{ route('cart') }}">سبد خرید</a>
        <a href="{{ auth()->check() ? route('account') : route('login') }}">{{ auth()->check() ? 'حساب من' : 'ورود | ثبت‌نام' }}</a>
        @if ($mode === 'toggle' || $mode === 'auto')<a href="#" data-theme-toggle>حالت شب / روز</a>@endif
        @if (setting('phone'))<a href="tel:{{ en_digits(setting('phone')) }}" class="app-only">تماس با فروشگاه: <span class="ltr">{{ fa(setting('phone')) }}</span></a>@endif
        @foreach (\Illuminate\Support\Facades\Cache::remember('footer.pages', 600, fn () => \App\Models\Page::query()->where('is_active', true)->where('in_footer', true)->orderBy('sort')->get(['title', 'slug'])) as $fp)
            <a href="{{ $fp->url() }}" class="app-only">{{ $fp->title }}</a>
        @endforeach
        <a href="#" data-install hidden>نصب اپلیکیشن روی گوشی</a>
    </nav>
</div>

@yield('content')

<footer class="foot">
    <div class="wrap foot-grid">
        <div>
            <b>{{ store_name() }}</b>
            <p>{{ setting('about') }}</p>
            @php $soc = array_filter(['instagram' => setting('instagram'), 'telegram' => setting('telegram'), 'whatsapp' => setting('whatsapp')]); @endphp
            @if ($soc)
                <div class="socials">
                    @foreach ($soc as $k => $v)
                        <a href="{{ str_starts_with($v, 'http') ? $v : ($k === 'instagram' ? 'https://instagram.com/'.ltrim($v, '@') : ($k === 'telegram' ? 'https://t.me/'.ltrim($v, '@') : 'https://wa.me/'.preg_replace('/\D/', '', en_digits($v)))) }}" target="_blank" rel="noopener" aria-label="{{ $k }}"><svg class="ic"><use href="#i-{{ $k }}"/></svg></a>
                    @endforeach
                </div>
            @endif
            @php $apkUrl = (string) (setting('mobile_app')['download_url'] ?? ''); @endphp
            @if ($apkUrl)<a class="btn btn-ghost android-btn" href="{{ $apkUrl }}" rel="nofollow"><svg class="ic"><use href="#i-download"/></svg>دانلود اپلیکیشن اندروید</a>@endif
            @if (setting('pwa_enabled', true))<button type="button" class="btn btn-ghost install-btn" data-install hidden><svg class="ic"><use href="#i-download"/></svg>نصب اپلیکیشن</button>@endif
        </div>
        <div>
            <b>دسترسی سریع</b>
            <a href="{{ route('shop') }}">همه محصولات</a>
            <a href="{{ route('account') }}">حساب کاربری و پیگیری سفارش</a>
            <a href="{{ route('cart') }}">سبد خرید</a>
            @if (\App\Support\BlogState::has())<a href="{{ route('blog') }}">{{ setting('blog_title', 'مجله') }}</a>@endif
            @foreach (\Illuminate\Support\Facades\Cache::remember('footer.pages', 600, fn () => \App\Models\Page::query()->where('is_active', true)->where('in_footer', true)->orderBy('sort')->get(['title', 'slug'])) as $fp)
                <a href="{{ $fp->url() }}">{{ $fp->title }}</a>
            @endforeach
        </div>
        <div class="foot-contact">
            <b>تماس با ما</b>
            @if (setting('phone'))<span><svg class="ic"><use href="#i-phone"/></svg><a class="ltr" href="tel:{{ en_digits(setting('phone')) }}">{{ fa(setting('phone')) }}</a></span>@endif
            @if (setting('mobile'))<span><svg class="ic"><use href="#i-phone"/></svg><a class="ltr" href="tel:{{ en_digits(setting('mobile')) }}">{{ fa(setting('mobile')) }}</a></span>@endif
            @if (setting('address'))<span><svg class="ic"><use href="#i-pin"/></svg>{{ setting('address') }}</span>@endif
            @if (setting('work_hours'))<span><svg class="ic"><use href="#i-clock"/></svg>{{ setting('work_hours') }}</span>@endif
        </div>
        <div>
            <b>نمادها و مجوزها</b>
            @include('store.partials.badges')
        </div>
    </div>
    <div class="foot-bottom">تمامی حقوق برای {{ store_name() }} محفوظ است.</div>
    {!! \App\Support\Credit::html('padding:4px 0 10px') !!}
</footer>

@php $chatNav = auth()->check() && \App\Services\Chat::enabled(); $chatUnread = $chatNav ? (int) \App\Models\ChatThread::query()->where('user_id', auth()->id())->sum('unread_customer') : 0; @endphp
<nav @class(['mnav', 'mnav-5' => $chatNav]) aria-label="دسترسی سریع">
    <a href="{{ route('home') }}" @class(['on' => request()->routeIs('home')])><svg class="ic"><use href="#i-home"/></svg>خانه</a>
    <button type="button" data-cats-open @class(['on' => request()->routeIs('shop', 'category', 'product')])><svg class="ic"><use href="#i-cats"/></svg>دسته‌بندی‌ها</button>
    <a href="{{ route('cart') }}" @class(['on' => request()->routeIs('cart', 'checkout')])><svg class="ic"><use href="#i-bag"/></svg>سبد خرید<span class="cart-count{{ $cart->count() ? '' : ' is-empty' }}" data-cart-count>{{ fa($cart->count()) }}</span></a>
    @if ($chatNav)<a href="{{ route('chats') }}" @class(['on' => request()->routeIs('chats')])><svg class="ic"><use href="#i-chat"/></svg>گفتگو<span class="cart-count{{ $chatUnread ? '' : ' is-empty' }}" data-chat-count>{{ fa($chatUnread) }}</span></a>@endif
    <a href="{{ auth()->check() ? route('account') : route('login') }}" @class(['on' => request()->routeIs('account', 'login', 'order.*')])><svg class="ic"><use href="#i-user"/></svg>حساب من</a>
</nav>

@include('store.partials.cat-sheet')
@if (session()->has('cart.removed'))@include('store.partials.removed-popup')@endif
@unless (request()->routeIs('chats'))@include('store.partials.support')@endunless
@if ($popup)@include('store.partials.popup', ['popup' => $popup])@endif
@auth @include('store.partials.survey-popup') @endauth
<div class="toast" role="status" aria-live="polite" data-toast></div>
<script>window.STORE={!! json_encode([
    'csrf' => csrf_token(), 'cartSet' => route('cart.set'), 'cartUrl' => route('cart'), 'map' => (object) $cart->map(),
    'sw' => setting('pwa_enabled', true) || $pushOn ? route('pwa.worker') : null, 'name' => store_name(), 'icon' => route('pwa.icon', 192),
    'push' => $pushOn ? ['key' => \App\Services\WebPush::keys()['public'], 'url' => route('push.subscribe'), 'prompt' => (bool) setting('push_prompt', true), 'delay' => (int) setting('push_prompt_delay', 20), 'text' => setting('push_prompt_text')] : null,
    'pv' => $pv,
    'notice' => ['type' => setting('cart_notice', 'toast'), 'sec' => max(1, (int) setting('cart_notice_seconds', 3))],
    'proof' => (function () {
        $c = \App\Support\SocialProof::cfg();
        if (empty($c['enabled'])) return null;
        $page = request()->routeIs('home') ? 'home' : (request()->routeIs('shop', 'category', 'product') ? 'shop' : 'other');
        if ($c['pages'] === 'home' && $page !== 'home') return null;
        if ($c['pages'] === 'shop' && $page === 'other') return null;
        return ['url' => route('social.proof'), 'first' => (int) $c['first_delay'], 'gap' => (int) $c['interval'], 'dur' => (int) $c['duration'], 'max' => (int) $c['max'], 'pos' => $c['position'], 'mobile' => (bool) $c['mobile']];
    })(),
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!};</script>
<script src="{{ asset('js/app.js') }}?v={{ config('store.version') }}" defer></script>
@stack('scripts')
@php $pageInfo = \App\Services\Live::pageFrom(get_defined_vars()); $liveCfg = \App\Services\Live::front($pageInfo); $stCfg = \App\Services\Stats::front($pageInfo); @endphp
@if ($stCfg)
<script>window.STP={!! json_encode($stCfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!};</script>
<script src="{{ asset('js/st.js') }}?v={{ config('store.version') }}" defer></script>
@endif
@if ($liveCfg)
<link rel="stylesheet" href="{{ asset('css/live.css') }}?v={{ config('store.version') }}">
<script>window.LIVE={!! json_encode($liveCfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) !!};</script>
<script src="{{ asset('js/live.js') }}?v={{ config('store.version') }}" defer></script>
@endif
{!! setting('footer_code') !!}
</body>
</html>
