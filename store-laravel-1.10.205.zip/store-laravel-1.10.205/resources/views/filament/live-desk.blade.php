@php
    $lc = \App\Services\Live::cfg();
    $cfg = [
        'state' => route('admin.live.state'), 'send' => route('admin.live.send'), 'close' => route('admin.live.close'), 'csrf' => csrf_token(),
        'quick' => array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string) $lc['quick'])))),
        'rules' => \App\Services\Live::RULES, 'sound' => (bool) $lc['sound'], 'site' => url('/'), 'settings' => url('/admin/settings/live'),
        'admin' => auth()->user()->isAdmin(), 'assign' => route('admin.live.assign'), 'voice' => $lc['voice'] ? (int) $lc['voice_sec'] : 0,
        'me' => \Illuminate\Support\Str::before(trim((string) auth()->user()->name), ' '), 'meId' => auth()->id(), 'title' => 'گفتگوی زنده',
    ];
@endphp
<x-filament-panels::page>
    <link rel="stylesheet" href="{{ asset('css/live-desk.css') }}?v={{ config('store.version') }}">
    <div class="ld" id="ld" wire:ignore data-cfg='@json($cfg, JSON_UNESCAPED_UNICODE | JSON_HEX_APOS)'>
        <div class="ld-boot">در حال بارگذاری…</div>
    </div>
    <script src="{{ asset('js/live-desk.js') }}?v={{ config('store.version') }}"></script>
</x-filament-panels::page>
