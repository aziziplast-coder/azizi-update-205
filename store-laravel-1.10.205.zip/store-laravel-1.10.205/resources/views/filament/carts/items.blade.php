@php
    $raw = (array) $rec->items;
    $ids = array_unique(array_map(fn ($k) => (int) explode(':', $k)[0], array_keys($raw)));
    $products = \App\Models\Product::query()->whereIn('id', $ids)->get()->keyBy('id');
    $sum = 0;
    $info = (array) $rec->info;
@endphp
<div style="display:grid;gap:10px;font-size:13px">
    @if ($info)
        <div style="display:flex;flex-wrap:wrap;gap:4px 18px;opacity:.85">
            @foreach (['name' => 'نام', 'mobile' => 'موبایل', 'company' => 'فروشگاه', 'province' => 'استان', 'city' => 'شهر', 'shipping' => 'ارسال', 'payment' => 'تسویه'] as $k => $l)
                @if (! empty($info[$k]))<span>{{ $l }}: <b>{{ $info[$k] }}</b></span>@endif
            @endforeach
        </div>
    @endif
    <table style="width:100%;border-collapse:collapse">
        <thead><tr style="text-align:right;opacity:.65;font-size:12px"><th style="padding:5px">کالا</th><th style="padding:5px">تعداد</th><th style="padding:5px">مبلغ (تومان)</th></tr></thead>
        <tbody>
        @foreach ($raw as $key => $units)
            @php [$id, $mode] = array_pad(explode(':', $key), 2, 'carton'); $p = $products->get((int) $id); $t = $p ? $p->unitPrice($mode) * (int) $units : 0; $sum += $t; @endphp
            <tr style="border-top:1px solid rgba(127,127,127,.2)">
                <td style="padding:5px">{{ $p?->name ?? 'کالای حذف‌شده #'.$id }} @if ($mode === 'retail')<small style="color:#d97706">(تکی)</small>@endif</td>
                <td style="padding:5px">{{ fa($units) }} عدد @if ($p && $mode !== 'retail' && $p->per_carton > 1)<small style="opacity:.6">({{ fa(intdiv((int) $units, $p->per_carton)) }} کارتن)</small>@endif</td>
                <td style="padding:5px">{{ money($t) }}</td>
            </tr>
        @endforeach
        </tbody>
        <tfoot><tr style="border-top:2px solid rgba(127,127,127,.3);font-weight:700"><td style="padding:5px" colspan="2">جمع</td><td style="padding:5px">{{ money($sum) }}</td></tr></tfoot>
    </table>
</div>
