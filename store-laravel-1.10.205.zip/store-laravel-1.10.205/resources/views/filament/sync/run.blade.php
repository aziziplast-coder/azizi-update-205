@php
    $s = $this->src();
    $o = $s->allOptions();
@endphp
<x-filament-panels::page>
    <style>
        .sy-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
        .sy-card{padding:12px 14px;border-radius:14px;border:1px solid rgb(127 127 127/.18)}
        .sy-card small{display:block;opacity:.65;font-size:12px}
        .sy-card b{font-size:20px}
        .sy-bar{height:12px;border-radius:99px;background:rgb(127 127 127/.15);overflow:hidden}
        .sy-bar i{display:block;height:100%;border-radius:99px;background:rgb(var(--primary-500));transition:width .5s}
        .sy-log{max-height:280px;overflow:auto;font-size:12.5px;display:grid;gap:4px}
        .sy-log div{display:flex;gap:8px;padding:4px 0;border-bottom:1px dashed rgb(127 127 127/.15)}
        .sy-log .error{color:#dc2626}.sy-log .warn{color:#d97706}.sy-log .ok{color:#16a34a}
        .sy-tabs{display:flex;gap:6px;flex-wrap:wrap}
        .sy-tabs button{padding:6px 14px;border-radius:99px;border:1px solid rgb(127 127 127/.25);font-size:13px;font-weight:600}
        .sy-tabs button.on{background:rgb(var(--primary-600));color:#fff;border-color:transparent}
        .sy-pc{width:100%;border-collapse:collapse;font-size:13px}.sy-pc td,.sy-pc th{padding:7px 8px;border-bottom:1px solid rgb(127 127 127/.12);text-align:right}
        .up{color:#dc2626}.down{color:#16a34a}
    </style>

    @livewire(\App\Livewire\SyncStatus::class, ['sourceId' => $s->id], key('sync-status-'.$s->id))

    <div class="sy-tabs">
        @foreach (['items' => 'کالاهای JSON', 'prices' => 'تغییر قیمت‌ها', 'excel' => 'ورود از اکسل', 'log' => 'گزارش اجرا'] as $k => $v)
            <button type="button" wire:click="$set('view_tab', '{{ $k }}')" @class(['on' => $view_tab === $k])>{{ $v }}</button>
        @endforeach
    </div>

    @if ($view_tab === 'items')
        {{ $this->table }}
    @elseif ($view_tab === 'prices')
        <x-filament::section heading="آخرین تغییرات قیمت">
            <x-slot name="headerEnd"><x-filament::button size="sm" color="gray" icon="heroicon-o-arrow-down-tray" wire:click="downloadPrices">اکسل همه تغییرات</x-filament::button></x-slot>
            @php $pcs = $this->priceChanges(); @endphp
            @if ($pcs->isEmpty())<p style="opacity:.6">هنوز تغییر قیمتی ثبت نشده است.</p>@else
            <div style="overflow-x:auto"><table class="sy-pc"><thead><tr><th>کالا</th><th>خرید قبلی ← جدید</th><th>فروش قبلی</th><th>فروش جدید</th><th>تغییر</th><th>زمان</th></tr></thead><tbody>
                @foreach ($pcs as $pc)
                    @php $diff = $pc->old_price ? round(($pc->new_price - $pc->old_price) * 100 / $pc->old_price, 1) : 0; @endphp
                    <tr><td><b>{{ $pc->title }}</b><br><small style="opacity:.6">{{ $pc->code }}</small></td><td>{{ money($pc->raw_old) }} ← {{ money($pc->raw_new) }}</td><td>{{ money($pc->old_price) }}</td><td><b>{{ money($pc->new_price) }}</b></td>
                        <td class="{{ $diff > 0 ? 'up' : 'down' }}">{{ $diff > 0 ? '▲' : '▼' }} {{ fa(abs($diff)) }}٪</td><td>{{ jdate($pc->created_at, true) }}</td></tr>
                @endforeach
            </tbody></table></div>@endif
        </x-filament::section>
    @elseif ($view_tab === 'excel')
        <x-filament::section heading="ساخت و قیمت‌گذاری از روی اکسل" description="کد یا بارکد کالاها را در اکسل بدهید؛ همان‌ها در JSON پیدا و ساخته یا به‌روز می‌شوند. هر ردیف می‌تواند درصد سود خودش را داشته باشد.">
            <form wire:submit="runExcel" style="display:grid;gap:14px">
                {{ $this->excelForm }}
                <div><x-filament::button type="submit" icon="heroicon-o-play" wire:loading.attr="disabled">خواندن اکسل و ساخت کالاها</x-filament::button>
                    <span wire:loading wire:target="runExcel" style="opacity:.7;margin-inline-start:8px">در حال خواندن فایل و دریافت JSON…</span></div>
            </form>
            @if (! empty($s->state['not_found']))
                <div style="margin-top:14px;padding:10px 14px;border-radius:12px;background:rgb(254 243 199);color:rgb(146 64 14);font-size:13px">
                    {{ fa(count($s->state['not_found'])) }} کد از آخرین اکسل در JSON پیدا نشد.
                    <x-filament::link tag="button" wire:click="downloadNotFound">دانلود فهرست</x-filament::link>
                </div>
            @endif
            @if ($o['only_listed'])
                <p style="font-size:13px;opacity:.75;margin-top:10px">حالت «فقط فهرست اکسل» روشن است. برای خاموش کردن، از تنظیمات › ساخت و به‌روزرسانی اقدام کنید.</p>
            @endif
        </x-filament::section>
    @else
        <x-filament::section heading="گزارش اجرا">
            <div class="sy-log">
                @forelse (array_reverse((array) $s->log) as $l)
                    <div class="{{ $l['l'] ?? '' }}"><span style="opacity:.6;white-space:nowrap">{{ jdate($l['t'], true) }}</span><span>{{ $l['m'] }}</span></div>
                @empty
                    <p style="opacity:.6">هنوز گزارشی نیست.</p>
                @endforelse
            </div>
        </x-filament::section>
    @endif
</x-filament-panels::page>
