<style>
/* دکمه ⚡ ویرایش سریع کنار نام کالا (همه اندازه‌ها) */
.pq-btn{display:inline-flex;vertical-align:middle;align-items:center;justify-content:center;width:28px;height:28px;margin-inline-start:4px;border-radius:8px;color:#d97706;background:rgba(245,158,11,.12);border:0;cursor:pointer}
.pq-btn:hover{background:rgba(245,158,11,.25)}
.pq-ic{width:17px;height:17px}
/* ===== پنل روی گوشی ===== */
.adm-nag .sm{display:none}
@media (max-width:640px){
  .adm-nag{display:inline-flex!important;margin:0 0 8px 6px!important;padding:6px 11px!important;font-size:12.5px!important;border-radius:999px!important;width:auto}
  .adm-nag .lg{display:none}.adm-nag .sm{display:inline}.adm-nag i{font-style:normal;opacity:.7}
  .fi-main{padding-inline:10px!important}
  .fi-header{gap:10px!important}
  .fi-header-heading{font-size:1.3rem!important;line-height:1.6!important}
  .fi-header .fi-ac{gap:6px!important}
  .fi-header .fi-btn{padding:6px 10px!important;font-size:12.5px!important}
  .fi-section-header{padding:12px 14px!important}
  .fi-section-content{padding:12px 14px!important}
  .fi-tabs{overflow-x:auto;flex-wrap:nowrap!important;scrollbar-width:none;max-width:100%}
  .fi-tabs::-webkit-scrollbar{display:none}
  .fi-tabs-item{flex:none;white-space:nowrap}
  .fi-ta-header-cell,.fi-ta-cell>div,.fi-ta-cell{padding-inline:6px!important}
  .fi-ta-cell:first-child,.fi-ta-header-cell:first-child{padding-inline-start:10px!important}
  .fi-ta-text-item-label{white-space:normal}
  .fi-ta-header-toolbar{padding:8px 10px!important;gap:8px!important}
  .fi-ta-search-field{min-width:0;flex:1}
  .fi-pagination{padding:8px 10px!important}
  .fi-modal-window{border-radius:18px!important}
  .fi-fo-field-wrp-label span{font-size:13px}
  /* کارت سفارش در فهرست سفارش‌ها: چندخطی، بدون بیرون‌زدگی */
  .order-mcard,.order-mcard *{white-space:normal!important}
  .fi-ta-cell:has(.order-mcard){width:100%}
  .order-mcard span[style*="border-radius:999px"]{white-space:nowrap!important;display:inline-block}
  .fi-wi-stats-overview-stats-ctn{gap:8px!important}
  .fi-wi-stats-overview-stat{padding:12px!important}
}
</style>
<style>
/* پنل مدیریت: جزئیات فارسی و پنجره هشدار سفارش */
.fi-body{font-feature-settings:"ss01"}
/* منوی کناری روی گوشی: کل ارتفاع واقعی صفحه (بدون رفتن زیر نوار مرورگر)، پهن‌تر و قابل اسکرول تا آخر */
@media (max-width:1023px){
.fi-sidebar{height:100vh;height:100dvh!important;max-height:100dvh;width:min(86vw,340px)!important;max-width:86vw}
.fi-sidebar-nav{overflow-y:auto!important;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;padding-bottom:calc(32px + env(safe-area-inset-bottom))!important}
.fi-sidebar-item-label{white-space:normal}
}
/* دکمه‌های بالای صفحه (مثلاً جزئیات سفارش) در چند ردیف بشکنند و از صفحه بیرون نزنند */
.fi-header{flex-wrap:wrap}
.fi-header>div:last-child{flex-shrink:1;min-width:0;max-width:100%}
.fi-header>div:last-child>.fi-ac{flex-wrap:wrap;row-gap:.5rem}
.fi-ta-text-input input,.ltr-input input,[dir=ltr]{direction:ltr}
.fi-ta-text-input input{text-align:center}
.fi-ta-text-input.min-w-48{min-width:6.5rem!important}
.order-st .fi-select-input{min-width:0;width:12rem;padding-top:.3rem;padding-bottom:.3rem;padding-inline-start:.5rem;font-size:.75rem;font-weight:700}
.order-st .fi-input-wrp{border-radius:10px}.order-st .fi-select-input{background-color:transparent!important}
.order-st-on_hold .fi-input-wrp{background:#fef3c7!important;--tw-ring-color:#f59e0b!important;box-shadow:0 0 0 1.5px #f59e0b!important}.order-st-on_hold .fi-select-input{color:#92400e!important}
.order-st-processing .fi-input-wrp{background:#dbeafe!important;--tw-ring-color:#3b82f6!important;box-shadow:0 0 0 1.5px #3b82f6!important}.order-st-processing .fi-select-input{color:#1e40af!important}
.order-st-settling .fi-input-wrp{background:#ede9fe!important;--tw-ring-color:#8b5cf6!important;box-shadow:0 0 0 1.5px #8b5cf6!important}.order-st-settling .fi-select-input{color:#5b21b6!important}
.order-st-shipped .fi-input-wrp{background:#ccfbf1!important;--tw-ring-color:#14b8a6!important;box-shadow:0 0 0 1.5px #14b8a6!important}.order-st-shipped .fi-select-input{color:#115e59!important}
.order-st-completed .fi-input-wrp{background:#dcfce7!important;--tw-ring-color:#22c55e!important;box-shadow:0 0 0 1.5px #22c55e!important}.order-st-completed .fi-select-input{color:#166534!important}
.order-st-cancelled .fi-input-wrp{background:#fee2e2!important;--tw-ring-color:#ef4444!important;box-shadow:0 0 0 1.5px #ef4444!important}.order-st-cancelled .fi-select-input{color:#991b1b!important}
.order-st-failed .fi-input-wrp{background:#fee2e2!important;--tw-ring-color:#ef4444!important;box-shadow:0 0 0 1.5px #ef4444!important}.order-st-failed .fi-select-input{color:#991b1b!important}
.order-st-pending_payment .fi-input-wrp{background:#f1f5f9!important;--tw-ring-color:#94a3b8!important;box-shadow:0 0 0 1.5px #94a3b8!important}.order-st-pending_payment .fi-select-input{color:#334155!important}
.dark .order-st .fi-input-wrp{filter:brightness(.92)}
.order-st.is-overdue .fi-input-wrp{box-shadow:0 0 0 2.5px #dc2626!important}
.fi-ta-table:has(.order-st,.order-mcard) .fi-ta-cell>div,.fi-ta-table:has(.order-st,.order-mcard) .fi-ta-header-cell{padding-inline:.4rem!important}
.fi-ta-table:has(.order-st) .fi-ta-actions{gap:.3rem}
.order-st.min-w-48{min-width:0!important;padding-inline:.5rem!important}
.seo-ok{color:#16a34a}.seo-warn{color:#d97706}.seo-bad{color:#dc2626}
.oa-stack{position:fixed;left:20px;bottom:20px;z-index:100000;display:grid;gap:10px;width:min(380px,calc(100vw - 24px))}
.oa{padding:14px 16px;border-radius:18px;background:#fff;border:1px solid rgb(0 0 0 / .08);border-top:4px solid rgb(var(--primary-600));box-shadow:0 24px 60px -20px rgba(0,0,0,.45);color:#334155;opacity:0;transform:translateY(16px) scale(.98);transition:opacity .22s,transform .22s}
.dark .oa{background:rgb(var(--gray-900));border-color:rgb(255 255 255 / .1);color:rgb(var(--gray-200))}
.oa.oa-stage{border-top-color:#16a34a}
.oa.is-in{opacity:1;transform:none;animation:oa-shake .5s .25s}
.oa.is-out{opacity:0;transform:translateY(10px)}
@keyframes oa-shake{20%,60%{transform:rotate(-1.2deg)}40%,80%{transform:rotate(1.2deg)}}
.oa-head{display:flex;align-items:center;gap:10px}
.oa-ico{display:grid;place-items:center;width:40px;height:40px;border-radius:12px;background:rgb(var(--primary-50));font-size:20px;animation:oa-ring 1s ease-in-out 2}
.dark .oa-ico{background:rgb(var(--primary-950))}
@keyframes oa-ring{25%{transform:rotate(-14deg)}75%{transform:rotate(14deg)}}
.oa-title{display:grid;flex:1}.oa-title b{font-size:15px}.oa-title small{opacity:.7;font-size:12px}
.oa-x{all:unset;cursor:pointer;width:30px;height:30px;border-radius:9px;text-align:center;line-height:30px;font-size:20px;opacity:.6}
.oa-x:hover{background:rgb(0 0 0 / .05)}
.oa-main{margin:10px 0 8px;font-size:14px;line-height:1.9}
.oa-total{color:rgb(var(--primary-600));font-size:15.5px}
.dark .oa-total{color:rgb(var(--primary-400))}
.oa-meta{display:grid;gap:4px;margin:0 0 12px;padding:10px 12px;border-radius:12px;background:rgb(0 0 0 / .04)}
.dark .oa-meta{background:rgb(255 255 255 / .05)}
.oa-meta div{display:flex;justify-content:space-between;gap:10px;font-size:12.5px}
.oa-meta dt{opacity:.7;white-space:nowrap}.oa-meta dd{margin:0;font-weight:700;text-align:left}
.oa-actions{display:flex;flex-wrap:wrap;align-items:center;gap:8px}
.oa-btn{display:inline-flex;align-items:center;justify-content:center;height:38px;padding:0 16px;border-radius:10px;font-weight:700;font-size:13.5px;border:1px solid rgb(0 0 0 / .12);background:transparent;cursor:pointer;color:inherit}
.oa-btn.primary{flex:1;background:rgb(var(--primary-600));border-color:transparent;color:#fff}
.oa-btn.oa-pref{font-size:12px;padding:0 10px;font-weight:600;opacity:.85}
.oa-unlock{all:unset;cursor:pointer;font-weight:700;font-size:12.5px;color:rgb(var(--primary-600))}
@media (max-width:782px){.oa-stack{left:12px;right:12px;bottom:12px;width:auto}}
.meter{height:10px;border-radius:99px;background:rgb(0 0 0 / .07);overflow:hidden}.dark .meter{background:rgb(255 255 255 / .08)}
.meter>i{display:block;height:100%;border-radius:inherit;background:rgb(var(--primary-600));transition:width .6s}
.meter.warn>i{background:#d97706}.meter.bad>i{background:#dc2626}
.rmb{display:flex;height:10px;border-radius:99px;background:rgb(0 0 0/.07);overflow:hidden;min-width:120px}.dark .rmb{background:rgb(255 255 255/.09)}
.rmb i{display:block;height:100%;transition:width .6s}.rmb .ok{background:#16a34a}.rmb .sub{background:#3b82f6}.rmb .aw{background:#f59e0b}
.rml{display:flex;flex-wrap:wrap;gap:4px 12px;margin-top:6px;font-size:11.5px;opacity:.85}.rml b{display:inline-block;width:8px;height:8px;border-radius:2px;background:rgb(0 0 0/.15);margin-inline-end:4px}
.rml b.ok{background:#16a34a}.rml b.sub{background:#3b82f6}.rml b.aw{background:#f59e0b}.rml .rmp{margin-inline-start:auto;font-weight:800}
.rm-copy{cursor:pointer;border-bottom:1px dashed currentColor}.rm-copy:active{opacity:.6}
</style>
<script src="{{ asset('js/jdp.js') }}?v={{ config('store.version') }}" defer></script>
@if (auth()->check() && \App\Services\Chat::enabled() && auth()->user()->hasPerm('chats'))
<link rel="stylesheet" href="/css/chat.css?v={{ config('store.version') }}">
<script src="/js/chat.js?v={{ config('store.version') }}" defer data-navigate-once></script>
@endif
{{-- گوشی: با باز شدن کیبورد خود صفحه کوچک شود (نه این‌که روی صفحه بیفتد) --}}
<meta name="viewport" content="width=device-width, initial-scale=1, interactive-widget=resizes-content">
<script>
/*
 * کلیک گم‌شده روی دسکتاپ (دکمه بستن، ذخیره و …):
 * Filament هر بار که پنل با سرور تبادل دارد (ذخیره خودکار یک خانه، نمایش یا بسته شدن پیام «ذخیره شد»)
 * دکمه‌ها را لحظه‌ای غیرفعال می‌کند؛ کلیکی که در همان لحظه برسد گم می‌شود و باید چند بار زد.
 * اینجا اگر دکمه زیر موشواره زده شد ولی کلیک نرسید، همین که دکمه دوباره فعال شد، همان کلیک یک بار انجام می‌شود.
 * فقط موشواره (دسکتاپ)؛ لمس گوشی دست نمی‌خورد.
 */
(function () {
    var pend = null;
    function btnOf(t) { return t && t.closest ? t.closest('button, a.fi-btn, a.fi-icon-btn') : null; }
    window.addEventListener('pointerdown', function (e) {
        pend = null;
        if (e.pointerType !== 'mouse' || e.button !== 0) return;
        var b = btnOf(e.target);
        if (!b || !b.hasAttribute('wire:loading.attr')) return; // فقط دکمه‌هایی که هنگام تبادل غیرفعال می‌شوند
        pend = { b: b, at: Date.now() };
    }, true);
    window.addEventListener('click', function (e) { if (pend && pend.b.contains(e.target)) pend = null; }, true);
    // mouseup به دکمه غیرفعال نمی‌رسد؛ pointerup می‌رسد
    window.addEventListener('pointerup', function (e) {
        var p = pend;
        if (!p || e.pointerType !== 'mouse') return;
        var under = document.elementFromPoint(e.clientX, e.clientY);
        if (!under || !p.b.contains(under)) { pend = null; return; } // موشواره از روی دکمه کشیده شد
        setTimeout(function wait() {
            if (pend !== p) return;              // کلیک خودش رسید
            if (!p.b.isConnected) { pend = null; return; }
            if (p.b.disabled || p.b.hasAttribute('disabled')) {
                if (Date.now() - p.at < 6000) setTimeout(wait, 40); else pend = null;
                return;
            }
            pend = null;
            p.b.click();
        }, 40);
    }, true);
})();
</script>
<script>
/* رقم فارسی/عربی در خانه‌های عددی پنل همان لحظه به رقم انگلیسی تبدیل شود (ذخیره بی‌خطا با صفحه‌کلید فارسی) */
document.addEventListener('input', function (e) {
    var el = e.target;
    if (!el || el.tagName !== 'INPUT' || el.inputMode !== 'numeric' && el.inputMode !== 'decimal') return;
    var v = el.value, n = v.replace(/[۰-۹]/g, function (d) { return d.charCodeAt(0) - 1776; }).replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; });
    if (n !== v) { var p = el.selectionStart; el.value = n; try { el.setSelectionRange(p, p); } catch (x) {} el.dispatchEvent(new Event('input', { bubbles: true })); }
}, true);
</script>
