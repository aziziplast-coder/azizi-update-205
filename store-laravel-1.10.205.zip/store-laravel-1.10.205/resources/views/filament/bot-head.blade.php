<div class="fi-header flex flex-col gap-4">
    @include('filament.bot-tabs', ['active' => $active])
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
        <h1 class="fi-header-heading text-2xl font-bold tracking-tight">{{ $title }}</h1>
        <div style="display:flex;gap:8px;flex-wrap:wrap">@foreach ($actions as $act){{ $act }}@endforeach</div>
    </div>
    @isset($note)<p style="margin:0;font-size:13px;opacity:.75">{{ $note }}</p>@endisset
</div>
