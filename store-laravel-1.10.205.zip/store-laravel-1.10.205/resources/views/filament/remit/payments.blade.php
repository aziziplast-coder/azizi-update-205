@php $r = $getRecord(); @endphp
<div wire:poll.30s.visible>
    @include('filament.remit.rows', ['payments' => $r->payments()->with(['order', 'reviewer'])->orderByRaw("CASE status WHEN 'submitted' THEN 0 WHEN 'awaiting' THEN 1 WHEN 'rejected' THEN 2 WHEN 'confirmed' THEN 3 ELSE 4 END")->orderByDesc('id')->get(), 'showOrder' => true, 'showRemit' => false])
</div>
