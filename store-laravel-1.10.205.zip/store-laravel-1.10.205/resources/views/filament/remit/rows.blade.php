{{-- جدول پرداخت‌های حواله / سفارش. متغیرها: $payments, $showOrder, $showRemit --}}
@php
    $colors = ['awaiting' => ['#fef3c7', '#92400e'], 'submitted' => ['#dbeafe', '#1e40af'], 'confirmed' => ['#dcfce7', '#166534'], 'rejected' => ['#fee2e2', '#991b1b'], 'cancelled' => ['#f1f5f9', '#64748b']];
@endphp
@if ($payments->isEmpty())
    <div style="opacity:.6;font-size:13px;padding:8px 0">هنوز مبلغی از این حواله برای مشتری صادر نشده است.</div>
@else
<div style="overflow-x:auto">
<table style="width:100%;border-collapse:collapse;font-size:12.5px">
    <thead><tr style="text-align:right;opacity:.65">
        <th style="padding:6px 4px">فیش</th>
        @if ($showOrder)<th style="padding:6px 4px">سفارش / مشتری</th>@endif
        @if ($showRemit)<th style="padding:6px 4px">حواله</th>@endif
        <th style="padding:6px 4px">بابت</th><th style="padding:6px 4px">مبلغ</th><th style="padding:6px 4px">وضعیت</th><th style="padding:6px 4px"></th>
    </tr></thead>
    <tbody>
    @foreach ($payments as $p)
        @php $c = $colors[$p->status] ?? ['#f1f5f9', '#334155']; $can = \App\Filament\Resources\RemitPaymentResource::canReview($p); @endphp
        <tr style="border-top:1px solid rgb(0 0 0/.07);{{ $p->status === 'cancelled' ? 'opacity:.5' : '' }}">
            <td style="padding:6px 4px;width:58px">
                @if ($p->files())
                    <div style="display:flex;gap:4px;flex-wrap:wrap;max-width:156px">
                    @foreach ($p->files() as $fi => $fp)
                        <a href="{{ route('admin.remit.receipt', [$p, 'i' => $fi, 'v' => substr(md5((string) $p->updated_at), 0, 8)]) }}" target="_blank" title="فیش {{ fa($fi + 1) }}">
                            @if (\App\Models\RemitPayment::isPdfPath($fp))<span style="display:grid;place-items:center;width:48px;height:48px;border-radius:10px;background:#fee2e2;color:#b91c1c;font-weight:800">PDF</span>
                            @else<img src="{{ route('admin.remit.receipt', [$p, 'i' => $fi, 'v' => substr(md5((string) $p->updated_at), 0, 8)]) }}" style="width:48px;height:48px;object-fit:cover;border-radius:10px;border:1px solid rgb(0 0 0/.1)" loading="lazy">@endif
                        </a>
                    @endforeach
                    </div>
                @else<span style="display:grid;place-items:center;width:48px;height:48px;border-radius:10px;background:rgb(0 0 0/.05);font-size:10px;opacity:.6">بی‌فیش</span>@endif
            </td>
            @if ($showOrder)
                <td style="padding:6px 4px">
                    @if ($p->order_id)<a href="{{ \App\Filament\Resources\OrderResource::getUrl('view', ['record' => $p->order_id]) }}" style="font-weight:700;color:rgb(var(--primary-600))">{{ fa($p->order?->number) }}</a>
                    @else<b>🏪 حضوری</b>@endif
                    <div style="opacity:.7">{{ $p->partyName() }} — {{ fa((string) $p->partyMobile()) }}</div>
                </td>
            @endif
            @if ($showRemit)
                <td style="padding:6px 4px"><a href="{{ \App\Filament\Resources\RemittanceResource::getUrl('view', ['record' => $p->remittance_id]) }}" style="font-weight:700">{{ fa($p->remittance?->code) }}</a>
                    <div style="opacity:.7">{{ \Illuminate\Support\Str::limit($p->remittance?->title, 24) }}</div></td>
            @endif
            <td style="padding:6px 4px">{{ $p->kindLabel() }}</td>
            <td style="padding:6px 4px;font-weight:800;white-space:nowrap">{{ money($p->amount) }}</td>
            <td style="padding:6px 4px">
                <span style="display:inline-block;padding:2px 9px;border-radius:99px;font-weight:700;background:{{ $c[0] }};color:{{ $c[1] }}">{{ $p->statusLabel() }}</span>
                @if ($p->factory_confirmed_at)<br><small style="color:#15803d;font-weight:700" title="کارخانه‌دار در اپ تأیید کرد">🏭 ✓ نشستن در حساب — {{ jdate($p->factory_confirmed_at, true) }}</small>
                @elseif ($p->remittance?->factory_id && in_array($p->status, ['submitted', 'confirmed'], true))<br><small style="color:#b45309">🏭 منتظر تأیید کارخانه‌دار</small>@endif
                <div style="opacity:.65;font-size:11px;margin-top:2px">
                    @if ($p->receipt_ref)پیگیری: <b dir="ltr">{{ fa($p->receipt_ref) }}</b> @endif
                    @if ($p->paid_on)— {{ fa($p->paid_on) }} @endif
                    @if ($p->submitted_at)<br>ارسال فیش: {{ jdate($p->submitted_at, true) }}@endif
                    @if ($p->reviewed_at && in_array($p->status, ['confirmed', 'rejected']))<br>{{ $p->status === 'confirmed' ? 'تأیید' : 'رد' }}: {{ jdate($p->reviewed_at, true) }} — {{ $p->reviewer?->displayName() }}@endif
                    @if ($p->reject_reason)<br><span style="color:#b91c1c">علت رد: {{ $p->reject_reason }}</span>@endif
                    @if ($p->customer_note)<br>یادداشت مشتری: {{ $p->customer_note }}@endif
                </div>
            </td>
            <td style="padding:6px 4px;white-space:nowrap">
                @if ($can && $p->status === 'submitted')
                    <button type="button" wire:click="confirmPayment({{ $p->id }})" wire:confirm="فیش {{ money($p->amount) }} تومانی تأیید شود؟ (مبلغ در حساب حواله دیده شده باشد)"
                        style="padding:4px 10px;border-radius:8px;background:#16a34a;color:#fff;font-weight:700">✓ تأیید</button>
                @endif
                @if ($can && in_array($p->status, ['submitted', 'awaiting']))
                    <span x-data="{ open: false, r: '', t: '' }" style="display:inline-block;vertical-align:top">
                        <button type="button" x-on:click="open = ! open"
                            style="padding:4px 10px;border-radius:8px;background:#fee2e2;color:#991b1b;font-weight:700">✕ رد</button>
                        <div x-show="open" x-cloak x-on:click.outside="open = false"
                            style="margin-top:6px;width:250px;background:#fff;color:#111;border:1px solid #e5e7eb;border-radius:12px;padding:10px;box-shadow:0 10px 30px rgb(0 0 0/.15);white-space:normal;display:grid;gap:6px;text-align:start">
                            <b style="font-size:12px">علت رد (برای مشتری پیامک می‌شود)</b>
                            @foreach (\App\Services\Remit::rejectReasons() as $why)
                                <label style="display:flex;gap:6px;align-items:flex-start;font-size:12px;cursor:pointer"><input type="radio" value="{{ $why }}" x-model="r"> <span>{{ $why }}</span></label>
                            @endforeach
                            <label style="display:flex;gap:6px;align-items:center;font-size:12px;cursor:pointer"><input type="radio" value="_other" x-model="r"> <span>علت دیگر…</span></label>
                            <input x-show="r === '_other'" x-model="t" type="text" placeholder="علت را بنویسید" style="border:1px solid #d1d5db;border-radius:8px;padding:4px 8px;font-size:12px">
                            <button type="button" x-bind:disabled="! r || (r === '_other' && ! t.trim())"
                                x-on:click="$wire.rejectPayment({{ $p->id }}, r === '_other' ? t : r); open = false"
                                style="padding:5px 10px;border-radius:8px;background:#dc2626;color:#fff;font-weight:700;font-size:12px">رد فیش و پیامک به مشتری</button>
                        </div>
                    </span>
                @endif
            </td>
        </tr>
    @endforeach
    </tbody>
</table>
</div>
@endif
