<x-filament-panels::page>
    @php $d = $this->data(); $k = $d['kpi']; @endphp
    <style>
        .dk-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}
        .dk-k{background:#fff;border:1px solid rgb(0 0 0/.07);border-radius:18px;padding:14px 16px}.dark .dk-k{background:rgb(255 255 255/.04);border-color:rgb(255 255 255/.08)}
        .dk-k small{display:block;opacity:.6;font-size:12px}.dk-k b{display:block;font-size:20px;font-weight:800;margin-top:4px}.dk-k i{font-style:normal;font-size:11px;opacity:.6}
        .dk-card{background:#fff;border:1px solid rgb(0 0 0/.07);border-radius:20px;padding:16px}.dark .dk-card{background:rgb(255 255 255/.04);border-color:rgb(255 255 255/.08)}
        .dk-card h3{font-weight:800;font-size:15px;margin-bottom:10px;display:flex;gap:8px;align-items:center}
        .dk-row{display:grid;grid-template-columns:minmax(150px,1.2fr) 2.5fr auto;gap:14px;align-items:center;padding:10px 0;border-top:1px solid rgb(0 0 0/.06)}
        .dk-row:first-of-type{border-top:0}.dk-row a{font-weight:700}.dk-row .sub{font-size:11.5px;opacity:.65}
        @media(max-width:800px){.dk-row{grid-template-columns:1fr}}
        .dk-pill{display:inline-block;padding:2px 9px;border-radius:99px;font-size:11px;font-weight:700;background:#dbeafe;color:#1e40af}
    </style>

    <div wire:poll.30s.visible class="space-y-5">
        @if (! $d['enabled'])
            <div style="padding:12px 16px;border-radius:14px;background:#fef3c7;color:#92400e;font-weight:600">
                پرداخت از طریق حواله‌ها هنوز خاموش است؛ {{ $d['chief'] ? 'در «تنظیمات کلی» پایین همین صفحه روشنش کنید.' : 'حسابدار کل باید آن را روشن کند.' }}
            </div>
        @endif

        <div class="dk-kpis">
            <div class="dk-k"><small>حواله‌های جاری</small><b>{{ fa($k['count']) }}</b><i>جمع {{ money($k['amount']) }} تومان</i></div>
            <div class="dk-k"><small>واریز تأییدشده</small><b style="color:#16a34a">{{ money($k['confirmed']) }}</b><i>{{ fa($k['pct']) }}٪ از کل حواله‌ها</i></div>
            <div class="dk-k"><small>مانده برای تکمیل</small><b style="color:#d97706">{{ money($k['left']) }}</b><i>آزاد (صادرنشده): {{ money($k['free']) }}</i></div>
            <a class="dk-k" href="{{ \App\Filament\Resources\RemitPaymentResource::getUrl() }}" style="{{ $k['pending'] ? 'border-color:#3b82f6' : '' }}"><small>فیش منتظر تأیید</small><b style="color:#2563eb">{{ fa($k['pending']) }}</b><i>{{ money($k['pending_sum']) }} تومان — بررسی ←</i></a>
            <div class="dk-k"><small>تأیید امروز</small><b>{{ money($d['today']) }}</b><i>تومان</i></div>
        </div>

        @if ($d['chief'] && $d['fw_all']->isNotEmpty())
            {{-- حسابدار کل: تأیید «نشستن در حساب» به‌جای کارخانه‌دار --}}
            <div class="dk-card" x-data="{ sel: [], all: false }" x-on:fw-reset.window="sel = []" id="fwait">
                <h3>🏭 فیش‌های منتظر تأیید کارخانه‌دار <span class="dk-pill">{{ $d['fw_on'] ? fa($d['fwait']->count()).' از '.fa($d['fw_all']->count()) : fa($d['fwait']->count()) }} فیش — {{ money($d['fwait']->sum('amount')) }} تومان</span>
                    <span style="margin-inline-start:auto;display:flex;gap:8px;align-items:center">
                        <label style="font-size:12.5px;font-weight:600;display:flex;gap:6px;align-items:center;cursor:pointer"><input type="checkbox" wire:key="fw-all-{{ md5(implode(',', $d['fwait']->pluck('id')->all())) }}" x-on:change="sel = $event.target.checked ? @js($d['fwait']->pluck('id')->all()) : []"> {{ $d['fw_on'] ? 'انتخاب همه فیلترشده‌ها' : 'انتخاب همه' }}</label>
                        <x-filament::button size="sm" color="success" icon="heroicon-o-check-badge" x-bind:disabled="!sel.length"
                            x-on:click="if (confirm('نشستن ' + String(sel.length).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]) + ' فیش انتخاب‌شده در حساب کارخانه به‌جای کارخانه‌دار تأیید شود؟')) { $wire.factoryOk(sel); sel = []; }">تأیید انتخاب‌شده‌ها <span x-show="sel.length" x-text="'(' + String(sel.length).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]) + ')'"></span></x-filament::button>
                    </span></h3>
                {{-- فیلتر: کارخانه، حواله، نوع، دیرکرد، جستجو --}}
                <div class="fw-f">
                    <select wire:model.live="fwFac" x-on:change="sel = []"><option value="">🏭 همه کارخانه‌ها ({{ fa(count($d['fw_facs'])) }})</option>
                        @foreach ($d['fw_facs'] as $k => $f)<option value="{{ $k }}">{{ $f['name'] }} — {{ fa($f['n']) }} فیش · {{ money($f['sum']) }}</option>@endforeach</select>
                    <select wire:model.live="fwRemit" x-on:change="sel = []"><option value="">📄 همه حواله‌ها</option>
                        @foreach ($d['fw_remits'] as $rid => $r)<option value="{{ $rid }}">حواله {{ fa($r['code']) }}{{ $this->fwFac === '' ? ' — '.$r['fac'] : '' }} ({{ fa($r['n']) }})</option>@endforeach</select>
                    <select wire:model.live="fwKind" x-on:change="sel = []"><option value="">بیعانه و تسویه</option><option value="deposit">فقط بیعانه</option><option value="settle">فقط تسویه</option></select>
                    <label class="fw-late"><input type="checkbox" wire:model.live="fwLate" x-on:change="sel = []"> فقط دیرکرد (بیش از {{ fa($d['late_h']) }} ساعت)</label>
                    <input type="search" wire:model.live.debounce.400ms="fwQ" x-on:input="sel = []" placeholder="جستجو: شماره سفارش، مبلغ، شماره پیگیری، مشتری…">
                    @if ($d['fw_on'])<button type="button" wire:click="fwClear" x-on:click="sel = []" class="fw-x">✕ حذف فیلترها</button>@endif
                </div>
                <style>
                    .fw-f{display:flex;flex-wrap:wrap;gap:8px;margin:2px 0 10px;align-items:center}
                    .fw-f select,.fw-f input[type=search]{height:38px;border-radius:10px;border:1px solid rgb(127 127 127/.3);padding:0 10px;font-size:13px;background:transparent;max-width:100%}
                    .fw-f select{min-width:170px}.fw-f input[type=search]{flex:1;min-width:220px}
                    .fw-late{display:flex;gap:6px;align-items:center;font-size:12.5px;font-weight:600;padding:0 10px;height:38px;border-radius:10px;border:1px solid rgb(127 127 127/.3);cursor:pointer}
                    .fw-x{height:38px;padding:0 12px;border-radius:10px;font-size:12.5px;font-weight:700;color:#b91c1c;background:rgb(254 226 226)}
                </style>
                <p style="font-size:12.5px;opacity:.7;margin:-4px 0 8px">کارخانه‌دار هنوز «به حسابم نشست» را نزده است. اگر از نشستن پول مطمئن هستید، به‌جای او تأیید کنید (در تاریخچه سفارش ثبت می‌شود). روی عکس فیش بزنید تا بزرگ شود؛ از همان‌جا هم می‌شود تأیید کرد و فیش بعدی را دید.</p>
                @foreach ($d['fwait'] as $ix => $p)
                    @php
                        $late = $p->submitted_at && $p->submitted_at->lt(now()->subHours($d['late_h']));
                        $hrs = $p->submitted_at ? (int) $p->submitted_at->diffInHours(now()) : 0;
                        $files = $p->files();
                        $fac = $p->remittance?->factory?->name ?: ($p->remittance?->title ?? '—');
                    @endphp
                    <div class="dk-row" wire:key="fw-{{ $p->id }}" @if ($ix >= 20) x-show="all" x-cloak @endif data-pay="{{ $p->id }}" data-amt="{{ money($p->amount) }}" data-code="{{ $fac }} · حواله {{ $p->remittance?->code }}" data-ref="{{ $p->order ? 'سفارش '.fa($p->order->number) : 'فیش حضوری' }} · {{ $p->kindLabel() }}" data-oklabel="به حساب کارخانه نشست (به‌جای کارخانه‌دار)"
                        style="grid-template-columns:auto auto minmax(150px,1.3fr) 1fr auto;{{ $late ? 'background:rgb(254 242 242);border-radius:12px;padding-inline:8px' : '' }}">
                        <input type="checkbox" value="{{ $p->id }}" x-model.number="sel">
                        <div style="display:flex;gap:4px">
                            @foreach (array_slice($files, 0, 3) as $i => $path)
                                @php $u = route('admin.remit.receipt', [$p, 'i' => $i, 'v' => substr(md5((string) $p->updated_at), 0, 8)]); @endphp
                                @if (\App\Models\RemitPayment::isPdfPath($path))
                                    <a href="{{ $u }}" target="_blank" style="width:46px;height:46px;border-radius:10px;display:grid;place-items:center;background:#fee2e2;color:#b91c1c;font-weight:800;font-size:11px">PDF</a>
                                @else
                                    <a href="{{ $u }}" target="_blank" data-lb><img src="{{ $u }}" alt="فیش" loading="lazy" style="width:46px;height:46px;object-fit:cover;border-radius:10px;border:1px solid rgb(0 0 0/.1)"></a>
                                @endif
                            @endforeach
                        </div>
                        <div><b style="font-size:15px">{{ money($p->amount) }}</b> <span class="sub">تومان — {{ $p->kindLabel() }}</span>
                            <div class="sub">🏭 {{ $fac }} · حواله {{ fa((string) $p->remittance?->code) }}
                                @if ($p->order) · <a href="{{ \App\Filament\Resources\OrderResource::getUrl('view', ['record' => $p->order]) }}" target="_blank">سفارش {{ fa($p->order->number) }}</a>@endif</div></div>
                        <div class="sub" style="{{ $late ? 'color:#b91c1c;font-weight:800;opacity:1' : '' }}">{{ $late ? '⚠️ ' : '⏳ ' }}{{ $hrs >= 24 ? fa(intdiv($hrs, 24)).' روز و '.fa($hrs % 24).' ساعت' : fa(max(1, $hrs)).' ساعت' }} از ثبت فیش
                            <br>{{ $p->status === 'submitted' ? 'فیش هنوز بررسی نشده' : 'فیش تأیید حسابداری شده' }}</div>
                        <div>
                            <x-filament::button size="sm" color="success" outlined wire:click="factoryOk([{{ $p->id }}])" wire:confirm="نشستن {{ money($p->amount) }} تومان در حساب «{{ $fac }}» به‌جای کارخانه‌دار تأیید شود؟">✓ تأیید</x-filament::button>
                            <button type="button" hidden data-okbtn wire:click="factoryOk([{{ $p->id }}])"></button>
                        </div>
                    </div>
                @endforeach
                @if ($d['fwait']->isEmpty())<div style="padding:16px;text-align:center;opacity:.6;font-size:13px">با این فیلتر فیشی نیست.</div>@endif
                @if ($d['fwait']->count() > 20)
                    <button type="button" x-show="!all" x-on:click="all = true" style="margin-top:10px;width:100%;padding:10px;border-radius:12px;border:1px dashed rgb(127 127 127/.4);font-weight:700;font-size:13px">نمایش همه ({{ fa($d['fwait']->count() - 20) }} فیش دیگر) ▾</button>
                @endif
            </div>
            <link rel="stylesheet" href="{{ asset('css/receipt-lb.css') }}?v={{ @filemtime(public_path('css/receipt-lb.css')) }}">
            <script src="{{ asset('js/factory-lb.js') }}?v={{ @filemtime(public_path('js/factory-lb.js')) }}"></script>
        @endif

        @if ($d['chief'] && $d['people'])
            <div class="dk-card">
                <h3>👥 پیشرفت کمک‌حسابدارها</h3>
                @foreach ($d['people'] as $p)
                    <div class="dk-row">
                        <div><a href="{{ \App\Filament\Resources\RemittanceResource::getUrl('index', ['tableFilters[assignee_id][value]' => $p['user']?->id]) }}">{{ $p['user']?->displayName() ?? 'بدون کمک‌حسابدار' }}</a>
                            <div class="sub">{{ fa($p['count']) }} حواله — {{ money($p['amount']) }} تومان @if ($p['pending_receipts'])<span class="dk-pill">{{ fa($p['pending_receipts']) }} فیش منتظر</span>@endif</div></div>
                        <div>{!! \App\Services\Remit::bar($p) !!}</div>
                        <div style="text-align:left;font-weight:800">مانده {{ money($p['left']) }}</div>
                    </div>
                @endforeach
            </div>
        @endif

        <div class="dk-card">
            <h3>📄 {{ $d['chief'] ? 'همه حواله‌های جاری' : 'حواله‌های جاری من' }}
                @if ($d['chief'])<a href="{{ \App\Filament\Resources\RemittanceResource::getUrl('create') }}" style="margin-inline-start:auto;font-size:13px;color:rgb(var(--primary-600))">+ ایجاد حواله</a>@endif</h3>
            @forelse ($d['active'] as $r)
                @php $st = $d['stats'][$r->id]; @endphp
                <div class="dk-row">
                    <div><a href="{{ \App\Filament\Resources\RemittanceResource::getUrl('view', ['record' => $r]) }}">{{ fa($r->code) }} — {{ \Illuminate\Support\Str::limit($r->title, 30) }}</a>
                        <div class="sub">{{ money($r->amount) }} تومان @if ($d['chief'])— {{ $r->assignee?->displayName() }}@endif @if ($r->bank_name)— {{ $r->bank_name }}@endif</div></div>
                    <div>{!! \App\Services\Remit::bar($st) !!}</div>
                    <div style="text-align:left"><b>{{ money($st['left']) }}</b><div class="sub">مانده</div></div>
                </div>
            @empty
                <div style="opacity:.6;font-size:13px">حواله جاری وجود ندارد.</div>
            @endforelse
        </div>

        @if ($d['filled']->isNotEmpty())
            <div class="dk-card">
                <h3>✅ حواله‌های پر شده اخیر (آماده ارسال به کارخانه)</h3>
                @foreach ($d['filled'] as $r)
                    <div class="dk-row">
                        <div><a href="{{ \App\Filament\Resources\RemittanceResource::getUrl('view', ['record' => $r]) }}">{{ fa($r->code) }} — {{ \Illuminate\Support\Str::limit($r->title, 30) }}</a>
                            <div class="sub">{{ money($r->amount) }} تومان — پر شد {{ jdate($r->filled_at, true) }} @if ($d['chief'])— {{ $r->assignee?->displayName() }}@endif</div></div>
                        <div class="sub">{{ fa($r->payments()->where('status', 'confirmed')->count()) }} فیش از مشتریان</div>
                        <div style="display:flex;gap:8px">
                            <a href="{{ route('admin.remit.print', $r) }}" target="_blank" style="padding:6px 12px;border-radius:10px;background:#16a34a;color:#fff;font-weight:700;font-size:12px">⬇ گزارش PDF</a>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>

    <div class="dk-card">
        <h3>⚙️ تنظیمات بیعانه من</h3>
        <form wire:submit="saveMine" class="space-y-3">
            {{ $this->mineForm }}
            <x-filament::button type="submit">ذخیره تنظیمات من</x-filament::button>
        </form>
    </div>

    @if ($d['chief'])
        <div class="dk-card">
            <h3>🏦 تنظیمات کلی حسابداری (حسابدار کل)</h3>
            <form wire:submit="saveGen" class="space-y-3">
                {{ $this->genForm }}
                <x-filament::button type="submit" color="gray">ذخیره تنظیمات کلی</x-filament::button>
            </form>
        </div>
    @endif
</x-filament-panels::page>
