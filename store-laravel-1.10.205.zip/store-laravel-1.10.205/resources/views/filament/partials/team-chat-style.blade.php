<style>
    .fc-q { border: 1px solid rgba(127,127,127,.25); border-radius: 12px; padding: 8px 12px; min-width: 240px; background: transparent; }
    .fc-list { display: flex; flex-direction: column; gap: 8px; max-width: 760px; --brand: rgb(var(--primary-600)); --card: #fff; --muted: #6b7280; }
    .dark .fc-list { --card: rgb(var(--gray-900)); --muted: #9ca3af; }
    .fc-card { width: 100%; text-align: right; padding: 10px 14px; border-radius: 16px; }
    .fc-card .ch-av { width: 44px; height: 44px; font-size: 18px; }
    .fc-card b { font-size: 14.5px; }
    .fc-card .go { background: transparent; color: inherit; padding: 0; flex-direction: column; align-items: flex-end; gap: 4px; font-weight: 600; }
    .fc-card .go em { position: static; background: #25d366; }
    .fc-at { font-style: normal; font-size: 11px; opacity: .65; }
</style>
