@php
    $order = $getRecord();
    $ml = messenger_link($order->messenger);
@endphp
@if ($ml)
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        <b dir="ltr" style="user-select:all">{{ $order->messenger }}</b>
        <a href="{{ $ml['url'] }}" target="_blank" rel="noopener" onclick="try{navigator.clipboard.writeText('{{ $order->messenger }}')}catch(e){}"
           style="display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:8px;background:rgb(22 163 74);color:#fff;font-size:12.5px;font-weight:700">💬 پیام در {{ $ml['label'] }}</a>
        @unless ($ml['direct'])<span style="font-size:11.5px;opacity:.7">شماره کپی می‌شود؛ در {{ $ml['label'] }} جستجو کنید.</span>@endunless
    </div>
@endif
