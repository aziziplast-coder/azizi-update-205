@php $r = $getRecord(); @endphp
@livewire(\App\Livewire\PickProgress::class, ['orderId' => $r->id], key('pick-'.$r->id.'-'.$r->pick_round.'-'.$r->fulfil_status.'-'.$r->updated_at?->timestamp))
