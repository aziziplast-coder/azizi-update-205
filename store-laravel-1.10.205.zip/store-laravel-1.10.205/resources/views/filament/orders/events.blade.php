<ul style="display:grid;gap:6px;font-size:13px">
    @forelse ($getRecord()->events()->with('user')->get() as $e)
        <li><span style="opacity:.6">{{ jdate($e->created_at, true) }}</span> — {{ $e->message }} @if ($e->user && $e->user->isStaffLike())<small style="opacity:.6">({{ $e->user->displayName() }})</small>@endif</li>
    @empty
        <li style="opacity:.6">رویدادی ثبت نشده است.</li>
    @endforelse
</ul>
