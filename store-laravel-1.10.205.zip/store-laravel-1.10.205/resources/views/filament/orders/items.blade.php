@php
    $order = $getRecord();
    $u = auth()->user();
    $items = $order->items()->with('warehouse')->get();
    if ($u->isKeeper()) {
        $mine = $u->warehouses()->pluck('warehouses.id')->all();
        $items = $items->whereIn('warehouse_id', $mine);
    }
    $showPrice = ! $u->isKeeper() || setting('keeper_prices', true);
@endphp
<div style="overflow-x:auto;max-width:100%">
<div style="min-width:600px">
<table style="width:100%;border-collapse:collapse;font-size:13.5px">
    <thead>
        <tr style="text-align:right;opacity:.7;font-size:12.5px">
            <th style="padding:6px 8px">#</th><th style="padding:6px 8px">کالا</th><th style="padding:6px 8px">نوع</th><th style="padding:6px 8px">تعداد</th><th style="padding:6px 8px">انبار</th>
            @if ($showPrice)<th style="padding:6px 8px">فی</th><th style="padding:6px 8px">جمع</th>@endif
        </tr>
    </thead>
    <tbody>
    @foreach ($items->values() as $i => $it)
        <tr style="border-top:1px solid rgb(127 127 127 / .2){{ $it->pick_status === 'missing' ? ';opacity:.55' : '' }}">
            <td style="padding:8px">{{ fa($i + 1) }}</td>
            <td style="padding:8px;display:flex;gap:10px;align-items:center;min-width:220px">
                @if ($it->image)<img src="{{ thumb($it->image, 64) }}" alt="" loading="lazy" decoding="async" width="40" height="40" style="width:40px;height:40px;border-radius:8px;object-fit:cover">@endif
                <span><b>{{ $it->name }}</b>@if ($it->barcode)<br><small style="opacity:.6">{{ $it->barcode }}</small>@endif</span>
            </td>
            <td style="padding:8px;white-space:nowrap"><span style="display:inline-block;padding:2px 8px;border-radius:6px;font-size:12px;font-weight:700;white-space:nowrap;{{ $it->isRetail() ? "background:#fff7ed;color:#c2410c" : "background:#eef2ff;color:#4338ca" }}">{{ $it->modeLabel() }}</span></td>
            <td style="padding:8px;white-space:nowrap">
                {{ $it->units > 0 ? $it->qtyLabel() : '۰' }}
                @if ($it->pick_status)
                    <br><span style="display:inline-block;margin-top:3px;padding:0 8px;border-radius:999px;font-size:11.5px;font-weight:700;{{ ['ok' => 'background:#e7f6ee;color:#0f7a45', 'short' => 'background:#fff4e0;color:#b45309', 'missing' => 'background:#fdecea;color:#b91c1c'][$it->pick_status] }}">{{ \App\Models\OrderItem::PICK[$it->pick_status] }}@if ($it->pick_status !== 'ok') — سفارش {{ $it->unitsLabel($it->orderedUnits()) }}@endif</span>
                @elseif ($it->pick_task_id)
                    <br><span style="font-size:11.5px;opacity:.6">در انتظار انبار</span>
                @endif
                @if ($it->replaces_item_id)<br><span style="font-size:11.5px;color:#b45309">جایگزین</span>@endif
            </td>
            <td style="padding:8px;white-space:nowrap">{{ $it->warehouse?->name ?? '—' }}</td>
            @if ($showPrice)
                <td style="padding:8px;white-space:nowrap">{{ money($it->unit_price) }}</td>
                <td style="padding:8px;white-space:nowrap;font-weight:700">{{ money($it->total) }}</td>
            @endif
        </tr>
    @endforeach
    </tbody>
</table>
</div>
</div>
@if ($showPrice && ! $u->isKeeper())
<dl style="margin:14px 0 0;display:grid;gap:4px;font-size:13.5px;max-width:360px;margin-inline-start:auto">
    <div style="display:flex;justify-content:space-between"><dt style="opacity:.7">جمع کالاها</dt><dd>{{ money($order->items_total) }}</dd></div>
    @if ($order->discount_total)<div style="display:flex;justify-content:space-between"><dt style="opacity:.7">تخفیف لحاظ‌شده</dt><dd>{{ money($order->discount_total) }}</dd></div>@endif
    @if ($order->coupon_discount)<div style="display:flex;justify-content:space-between;color:#16a34a"><dt>کد تخفیف {{ $order->coupon_code }}</dt><dd>− {{ money($order->coupon_discount) }}</dd></div>@endif
    <div style="display:flex;justify-content:space-between"><dt style="opacity:.7">ارسال: {{ $order->shipping_title }}</dt><dd>{{ $order->shippingLabel() }}</dd></div>
    @if ($order->freight_fee)<div style="display:flex;justify-content:space-between"><dt style="opacity:.7">کرایه حمل تا باربری</dt><dd>{{ money($order->freight_fee) }}</dd></div>@endif
    @if ($order->extra_discount)<div style="display:flex;justify-content:space-between;color:#16a34a"><dt>تخفیف</dt><dd>− {{ money($order->extra_discount) }}</dd></div>@endif
    @foreach ((array) $order->fees as $fee)<div style="display:flex;justify-content:space-between"><dt style="opacity:.7">{{ $fee['title'] }}</dt><dd>{{ money($fee['amount']) }}</dd></div>@endforeach
    <div style="display:flex;justify-content:space-between;font-weight:800;font-size:15px;border-top:1px solid rgb(127 127 127 / .25);padding-top:6px"><dt>مبلغ کل</dt><dd>{{ money($order->total) }} تومان</dd></div>
</dl>
@endif
