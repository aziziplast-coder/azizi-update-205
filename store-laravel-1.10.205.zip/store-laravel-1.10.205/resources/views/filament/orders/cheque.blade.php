@php
    $order = $getRecord();
    $ch = (array) $order->cheque;
@endphp
<div style="display:grid;gap:12px;font-size:13.5px">
    <div style="display:flex;flex-wrap:wrap;gap:6px 24px">
        <span>طرح: <b>{{ $ch['plan'] ?? '—' }}</b></span>
        @if (! empty($ch['national_id']))<span>کد ملی صاحب چک: <b dir="ltr" style="user-select:all">{{ $ch['national_id'] }}</b></span>@endif
        @if (($ch['cash'] ?? null) !== null)<span>نقد (طرح): <b>{{ money($ch['cash']) }} تومان</b></span>@endif
    </div>
    @php $planRows = (array) ($ch['cheques'] ?? []); @endphp
    @if ($planRows || ! empty($ch['guarantee']))
    <table style="width:100%;border-collapse:collapse">
        <thead><tr style="text-align:right;opacity:.7;font-size:12px"><th style="padding:6px">چک</th><th style="padding:6px">مبلغ (تومان)</th><th style="padding:6px">سررسید</th><th style="padding:6px">شناسه صیادی</th><th style="padding:6px">تصویر</th></tr></thead>
        <tbody>
        @php $rows = (array) ($ch['cheques'] ?? []); if (! empty($ch['guarantee'])) { $rows[] = ['amount' => $ch['guarantee'], 'due_fa' => 'ضمانت', 'g' => true]; } @endphp
        @foreach ($rows as $i => $c)
            @php $d = $ch['docs'][$i] ?? []; @endphp
            <tr style="border-top:1px solid rgba(127,127,127,.2)">
                <td style="padding:6px"><b>{{ ! empty($c['g']) ? 'چک ضمانت' : 'چک '.fa($i + 1) }}</b></td>
                <td style="padding:6px">{{ money($c['amount']) }}</td>
                <td style="padding:6px">{{ $c['due_fa'] ?? '' }}</td>
                <td style="padding:6px" dir="ltr">@if (! empty($d['sayad']))<span style="user-select:all;font-family:monospace">{{ trim(chunk_split($d['sayad'], 4, ' ')) }}</span>@else<span style="opacity:.5">—</span>@endif</td>
                <td style="padding:6px">
                    @if (! empty($d['image']))
                        @php $u = route('admin.cheque', [$order->id, $i]); $isPdf = str_ends_with(strtolower($d['image']), '.pdf'); @endphp
                        <a href="{{ $u }}" target="_blank" style="display:inline-block">
                            @if ($isPdf)📄 PDF @else<img src="{{ $u }}" alt="" style="width:96px;height:60px;object-fit:cover;border-radius:6px;border:1px solid rgba(127,127,127,.3)">@endif
                        </a>
                    @else<span style="opacity:.5">—</span>@endif
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
    @endif
    @if (! empty($ch['settle']))
        @php
            $canRv = auth()->user()?->hasPerm('orders_edit');
            $lockAp = $order->loadingLocked() && ! auth()->user()?->isAdmin(); // پس از رفتن برای بارگیری، تأیید پس گرفته نمی‌شود
            $stC = ['submitted' => '#b45309', 'approved' => '#16a34a', 'rejected' => '#b91c1c'];
            $reasons = \App\Services\Remit::rejectReasons();
            $payee = (array) ($ch['payee'] ?? []);
            $docsOn = \App\Services\Cheques::settleDocsNeeded($order);
        @endphp
        <div style="border:1px solid rgba(14,165,233,.4);border-radius:12px;padding:10px;display:grid;gap:8px">
            <b>مشخصات نهایی (صدور مانده حساب): نقد {{ money((int) $order->cash_amount) }} تومان + {{ fa(count($ch['settle'])) }} چک</b>
            @if (! empty($payee['nid']) || ! empty($payee['name']))
                <span>گیرنده چک‌ها (ثبت صیاد): <b>{{ $payee['name'] ?? '' }}</b> — کد/شناسه ملی <b dir="ltr" style="user-select:all">{{ $payee['nid'] ?? '' }}</b></span>
            @endif
            @if (! empty($ch['owner_nid']))<span>کد ملی صاحب چک (اعلام مشتری): <b dir="ltr" style="user-select:all">{{ $ch['owner_nid'] }}</b></span>@endif
            @php
                $items = [];
                foreach ($ch['settle'] as $i => $c) {
                    foreach (\App\Services\Cheques::DOC_TYPES as $t => $tl) {
                        $items[$i][$t] = $c['docs'][$t] ?? null;
                    }
                }
            @endphp
            @foreach ($ch['settle'] as $i => $c)
                <div style="border-top:1px solid rgba(127,127,127,.2);padding-top:8px;display:grid;gap:6px">
                    <div style="display:flex;gap:16px;flex-wrap:wrap;align-items:center"><span>چک {{ fa($i + 1) }}: <b>{{ money($c['amount']) }}</b> تومان</span><span>سررسید: <b>{{ $c['due_fa'] ?? '' }}</b></span>
                        @if (! empty($c['image']))
                            @php $u = route('admin.cheque', [$order->id, $i, 't' => 'settle']); @endphp
                            <a href="{{ $u }}" target="_blank" style="font-size:12px">تصویر قبلی</a>
                        @endif
                    </div>
                    @if ($docsOn)
                    <div style="display:flex;gap:12px;flex-wrap:wrap">
                        @foreach (\App\Services\Cheques::DOC_TYPES as $t => $tl)
                            @php $d = $items[$i][$t]; @endphp
                            <div style="display:grid;gap:4px;padding:6px;border:1px dashed rgba(127,127,127,.35);border-radius:10px;min-width:170px">
                                <small style="font-weight:700">{{ $tl }}</small>
                                @if ($d && ! empty($d['path']))
                                    @php $u = route('admin.cheque', [$order->id, $i, 't' => 'doc', 'k' => $t, 'v' => substr(md5($d['path']), 0, 8)]); @endphp
                                    <a href="{{ $u }}" target="_blank">@if (str_ends_with(strtolower($d['path']), '.pdf'))📄 PDF @else<img src="{{ $u }}" alt="" loading="lazy" style="width:150px;height:90px;object-fit:cover;border-radius:6px;border:1px solid rgba(127,127,127,.3)">@endif</a>
                                    <small style="color:{{ $stC[$d['st']] ?? '#555' }};font-weight:700">{{ \App\Services\Cheques::DOC_STATUS[$d['st']] ?? '' }}@if ($d['st'] === 'rejected' && ! empty($d['reason'])) — {{ $d['reason'] }}@endif</small>
                                    @if ($canRv)
                                        <div style="display:flex;gap:6px;flex-wrap:wrap">
                                            @if ($d['st'] !== 'approved')
                                                <button type="button" wire:click="reviewChequeDoc('{{ $t }}', {{ $i }}, true)" style="padding:3px 10px;border-radius:8px;background:#16a34a;color:#fff;font-weight:700;font-size:12px">✓ تأیید</button>
                                            @endif
                                            @if (! ($d['st'] === 'approved' && $lockAp))
                                            @include('filament.orders.partials.reject-pop', ['call' => "\$wire.reviewChequeDoc('{$t}', {$i}, false, %s)", 'reasons' => $reasons, 'label' => $d['st'] === 'approved' ? 'لغو تأیید / رد' : '✕ رد'])
                                            @endif
                                        </div>
                                    @endif
                                @else
                                    <small style="color:#b45309">هنوز نفرستاده</small>
                                @endif
                            </div>
                        @endforeach
                    </div>
                    @endif
                </div>
            @endforeach
            @if ($docsOn)
                @php $pd = $ch['post'] ?? null; @endphp
                <div style="border-top:1px solid rgba(127,127,127,.2);padding-top:8px;display:grid;gap:6px">
                    <b>بیجک پستی چک‌ها</b>
                    @if ($pd && ! empty($pd['path']))
                        @php $u = route('admin.cheque', [$order->id, 0, 't' => 'post', 'v' => substr(md5($pd['path']), 0, 8)]); @endphp
                        <a href="{{ $u }}" target="_blank">@if (str_ends_with(strtolower($pd['path']), '.pdf'))📄 PDF @else<img src="{{ $u }}" alt="" loading="lazy" style="width:150px;height:90px;object-fit:cover;border-radius:6px;border:1px solid rgba(127,127,127,.3)">@endif</a>
                        <small style="color:{{ $stC[$pd['st']] ?? '#555' }};font-weight:700">{{ \App\Services\Cheques::DOC_STATUS[$pd['st']] ?? '' }}@if ($pd['st'] === 'rejected' && ! empty($pd['reason'])) — {{ $pd['reason'] }}@endif</small>
                        @if ($canRv)
                            <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:flex-start">
                                @if ($pd['st'] !== 'approved')
                                    <span x-data="{ q: false }" style="display:inline-block">
                                        <button type="button" x-on:click="q = ! q" style="padding:3px 10px;border-radius:8px;background:#16a34a;color:#fff;font-weight:700;font-size:12px">✓ تأیید بیجک</button>
                                        <div x-show="q" x-cloak x-on:click.outside="q = false" style="margin-top:6px;width:260px;background:#fff;color:#111;border:1px solid #e5e7eb;border-radius:12px;padding:10px;box-shadow:0 10px 30px rgb(0 0 0/.15);display:grid;gap:8px">
                                            <b style="font-size:13px">تأیید می‌کنید که بار برای ارسال به باربری (بارگیری) برود؟</b>
                                            <button type="button" x-on:click="$wire.reviewPost(true, null, true); q = false" style="padding:5px 10px;border-radius:8px;background:#16a34a;color:#fff;font-weight:700;font-size:12px">بله، برای بارگیری برود</button>
                                            <button type="button" x-on:click="$wire.reviewPost(true, null, false); q = false" style="padding:5px 10px;border-radius:8px;background:#f3f4f6;color:#111;font-weight:700;font-size:12px">خیر، تا رسیدن چک‌ها صبر کن</button>
                                        </div>
                                    </span>
                                @endif
                                @if (! ($pd['st'] === 'approved' && $lockAp))
                                @include('filament.orders.partials.reject-pop', ['call' => '$wire.reviewPost(false, %s)', 'reasons' => $reasons, 'label' => $pd['st'] === 'approved' ? 'لغو تأیید / رد' : '✕ رد'])
                                @else
                                <small style="opacity:.7">🔒 بار برای بارگیری رفته؛ تأیید قابل برگشت نیست.</small>
                                @endif
                            </div>
                        @endif
                    @else
                        <small style="opacity:.7">مشتری هنوز بیجک پستی نفرستاده (اگر چک‌ها را پست کند، تصویر بیجک را می‌فرستد).</small>
                    @endif
                </div>
            @endif
            <span style="font-weight:700;color:{{ $order->cheques_received_at ? '#16a34a' : '#b45309' }}">{{ $order->cheques_received_at ? '✓ چک‌ها رسید و تأیید شد — '.jdate($order->cheques_received_at, true) : 'چک‌ها هنوز نرسیده‌اند (پس از رسیدن، «ارسال و بیجک ← چک‌ها رسید» را بزنید)' }}</span>
        </div>
    @endif
    @if (! empty($ch['staff_docs']))
        <div style="display:grid;gap:6px">
            <b>تصاویر چک (بارگذاری کارمندان)</b>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
                @foreach ($ch['staff_docs'] as $i => $d)
                    @php $u = route('admin.cheque', [$order->id, $i, 's' => 1]); $isPdf = str_ends_with(strtolower($d['image'] ?? ''), '.pdf'); @endphp
                    <a href="{{ $u }}" target="_blank" title="{{ $d['note'] ?? '' }}" style="display:inline-block">@if ($isPdf)📄 PDF @else<img src="{{ $u }}" alt="" loading="lazy" style="width:110px;height:70px;object-fit:cover;border-radius:6px;border:1px solid rgba(127,127,127,.3)">@endif</a>
                @endforeach
            </div>
        </div>
    @endif
    <p style="margin:0;font-size:12px;opacity:.7">برای استعلام: اپ بانک ← استعلام چک صیادی ← شناسه ۱۶ رقمی و کد ملی صاحب چک.</p>
</div>
