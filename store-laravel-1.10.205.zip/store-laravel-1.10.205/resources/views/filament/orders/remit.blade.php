@php
    $o = $getRecord();
    $pays = \App\Models\RemitPayment::query()->with(['remittance', 'reviewer', 'order'])->where('order_id', $o->id)->orderBy('id')->get();
    $conf = \App\Services\Remit::confirmedSum($o);
    $dep = \App\Services\Remit::confirmedSum($o, 'deposit');
    $final = $o->final_amount ?: $o->total;
    $open = $pays->whereIn('status', ['awaiting', 'submitted', 'rejected'])->sum('amount');
@endphp
<div wire:poll.60s.visible style="display:grid;gap:10px">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px;font-size:12.5px">
        <div style="padding:8px 10px;border-radius:12px;background:rgb(0 0 0/.04)"><div style="opacity:.6">{{ $o->final_amount ? 'مبلغ نهایی' : 'مبلغ سفارش' }}</div><b>{{ money($final) }}</b></div>
        <div style="padding:8px 10px;border-radius:12px;background:#dcfce7;color:#166534"><div style="opacity:.75">بیعانه تأییدشده</div><b>{{ money($dep) }}</b></div>
        <div style="padding:8px 10px;border-radius:12px;background:#dcfce7;color:#166534"><div style="opacity:.75">کل واریز تأییدشده</div><b>{{ money($conf) }}</b></div>
        <div style="padding:8px 10px;border-radius:12px;background:#fef3c7;color:#92400e"><div style="opacity:.75">در انتظار (صادر / فیش)</div><b>{{ money($open) }}</b></div>
        <div style="padding:8px 10px;border-radius:12px;background:{{ $final - $conf > 0 ? '#fee2e2' : '#dcfce7' }}"><div style="opacity:.75">مانده حساب مشتری</div><b>{{ money(max(0, $final - $conf)) }}</b></div>
    </div>
    @include('filament.remit.rows', ['payments' => $pays, 'showOrder' => false, 'showRemit' => true])
</div>
