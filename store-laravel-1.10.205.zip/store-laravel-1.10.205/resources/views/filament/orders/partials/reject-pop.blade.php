{{-- انتخاب علت رد؛ $call قالب فراخوانی با %s برای علت --}}
<span x-data="{ open: false, r: '', t: '' }" style="display:inline-block;vertical-align:top">
    <button type="button" x-on:click="open = ! open" style="padding:3px 10px;border-radius:8px;background:#fee2e2;color:#991b1b;font-weight:700;font-size:12px">{{ $label ?? '✕ رد' }}</button>
    <div x-show="open" x-cloak x-on:click.outside="open = false"
        style="margin-top:6px;width:250px;background:#fff;color:#111;border:1px solid #e5e7eb;border-radius:12px;padding:10px;box-shadow:0 10px 30px rgb(0 0 0/.15);white-space:normal;display:grid;gap:6px;text-align:start;position:relative;z-index:20">
        <b style="font-size:12px">علت رد (برای مشتری پیامک می‌شود)</b>
        @foreach ($reasons as $why)
            <label style="display:flex;gap:6px;align-items:flex-start;font-size:12px;cursor:pointer"><input type="radio" value="{{ $why }}" x-model="r"> <span>{{ $why }}</span></label>
        @endforeach
        <label style="display:flex;gap:6px;align-items:center;font-size:12px;cursor:pointer"><input type="radio" value="_other" x-model="r"> <span>علت دیگر…</span></label>
        <input x-show="r === '_other'" x-model="t" type="text" placeholder="علت را بنویسید" style="border:1px solid #d1d5db;border-radius:8px;padding:4px 8px;font-size:12px">
        <button type="button" x-bind:disabled="! r || (r === '_other' && ! t.trim())"
            x-on:click="{!! sprintf($call, "(r === '_other' ? t : r)") !!}; open = false"
            style="padding:5px 10px;border-radius:8px;background:#dc2626;color:#fff;font-weight:700;font-size:12px">رد و پیامک به مشتری</button>
    </div>
</span>
