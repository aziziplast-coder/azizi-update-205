<x-filament-panels::page>
    @php $st = $this->stats(); @endphp
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px">
        @foreach ([['همه مشترکان', $st['all']], ['مشتریان واردشده', $st['customers']], ['کارکنان', $st['staff']]] as [$l, $v])
            <x-filament::section><div style="opacity:.7;font-size:13px">{{ $l }}</div><b style="font-size:24px">{{ fa($v) }}</b></x-filament::section>
        @endforeach
    </div>
    @php $svc = $this->services(); $le = \Illuminate\Support\Facades\Cache::get('push.last_errors'); @endphp
    @if ($svc || $le)
        <x-filament::section heading="عیب‌یابی" icon="heroicon-o-wrench-screwdriver" collapsible :collapsed="! $le">
            @if ($svc)<div style="font-size:13px;margin-bottom:8px">مشترکان بر اساس مرورگر: @foreach ($svc as $k => $v)<b>{{ $k }}</b>: {{ fa($v) }}@if (! $loop->last) · @endif @endforeach</div>@endif
            @if ($le)
                <div style="font-size:13px">آخرین خطاهای ارسال ({{ jdate($le['at'], true) }}):</div>
                <ul style="font-size:13px;margin:6px 0 0;padding-right:18px;display:grid;gap:4px">@foreach ($le['errors'] as $why => $n)<li>{{ fa($n) }} مورد — {{ $why }}</li>@endforeach</ul>
            @endif
            <p style="font-size:12.5px;opacity:.75;margin:10px 0 0;line-height:1.9">اعلان مرورگر از سرور سایت به سرویس اعلان گوگل (کروم)، موزیلا (فایرفاکس) یا اپل فرستاده می‌شود. اگر هاست داخل ایران است و این سرویس‌ها از هاست در دسترس نیستند، اعلان ارسال نمی‌شود؛ در این حالت هاست خارج از ایران یا پیامک راه جایگزین است.</p>
        </x-filament::section>
    @endif
    <x-filament::section heading="ارسال اعلان جدید" icon="heroicon-o-paper-airplane">
        <form wire:submit="sendNow" style="display:grid;gap:14px">
            {{ $this->sendForm }}
            <div><x-filament::button type="submit" icon="heroicon-o-paper-airplane" wire:loading.attr="disabled">ارسال</x-filament::button>
                <span wire:loading wire:target="sendNow" style="opacity:.7;margin-inline-start:8px">در حال ارسال…</span></div>
        </form>
    </x-filament::section>
    <x-filament::section heading="تنظیمات" collapsible :collapsed="(bool) setting('push_enabled')">
        <form wire:submit="saveConf" style="display:grid;gap:14px">
            {{ $this->confForm }}
            <div style="display:flex;gap:8px;flex-wrap:wrap">
                <x-filament::button type="submit">ذخیره تنظیمات</x-filament::button>
                @if (setting('push_enabled'))
                    <x-filament::button type="button" color="gray" icon="heroicon-o-bell" x-on:click="window.adminPush && window.adminPush()">دریافت اعلان سفارش جدید روی همین دستگاه</x-filament::button>
                    <x-filament::button type="button" color="gray" icon="heroicon-o-beaker" wire:click="testMine" wire:loading.attr="disabled">ارسال اعلان آزمایشی به دستگاه‌های من</x-filament::button>
                @endif
            </div>
        </form>
    </x-filament::section>
    {{ $this->table }}
</x-filament-panels::page>
