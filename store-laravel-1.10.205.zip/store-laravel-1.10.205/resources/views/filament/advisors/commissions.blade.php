<x-filament-panels::page>
    <div style="font-size:13px;opacity:.8;margin-bottom:-8px;line-height:1.9">پورسانت هر سفارش «در انتظار» است تا سفارش به وضعیت‌های قطعیِ «تنظیمات پورسانت» برسد؛ آن‌وقت به کیف پول مشاور اضافه می‌شود. لغو ← باطل؛ تغییر مبلغ ← اصلاح خودکار.</div>
    {{ $this->table }}
</x-filament-panels::page>
