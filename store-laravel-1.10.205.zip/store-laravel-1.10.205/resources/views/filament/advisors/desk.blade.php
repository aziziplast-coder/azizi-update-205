<x-filament-panels::page>
    <div style="font-size:13px;opacity:.8;margin-bottom:-8px;line-height:1.9">مشاور = کارمندی که در «کارکنان» تیک «مشاور فروش» دارد. هر مشاور در «اپ مشاور» (<a href="{{ url('/advisor') }}" target="_blank" dir="ltr" style="text-decoration:underline">{{ preg_replace('~^https?://~', '', url('/advisor')) }}</a>) لینک خودش، مشتری‌ها، پورسانت‌ها و کیف پولش را می‌بیند و شماره حسابش را ثبت می‌کند. تسویه از دکمه «تسویه» همین صفحه.</div>
    {{ $this->table }}
</x-filament-panels::page>
