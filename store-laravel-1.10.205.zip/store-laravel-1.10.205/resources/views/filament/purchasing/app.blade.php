<x-filament-panels::page>
    <style>
        .pa-wrap{margin-top:-2rem;border-radius:20px;overflow:hidden;border:1px solid rgb(0 0 0/.08);background:#f2f3f6;box-shadow:0 1px 3px rgb(0 0 0/.05)}
        .dark .pa-wrap{border-color:rgb(255 255 255/.1)}
        .pa-wrap iframe{display:block;width:100%;height:calc(100vh - 12rem);min-height:560px;border:0}
        .pa-bar{display:flex;gap:8px;justify-content:flex-end;margin:-1rem 0 .75rem;flex-wrap:wrap}
        .pa-bar a{font-size:13px;font-weight:700;padding:6px 12px;border-radius:10px;background:rgb(0 0 0/.05)}.dark .pa-bar a{background:rgb(255 255 255/.07)}
    </style>
    <div class="pa-bar">
        <a href="{{ \App\Filament\Pages\PurchasingDesk::getUrl() }}">ورود اکسل، آمار و تنظیمات</a>
        <a href="{{ url('/buyer/print?all=1') }}" target="_blank">چاپ همه پیش‌نویس‌ها</a>
        <a href="{{ url('/buyer') }}" target="_blank">باز کردن در پنجره جدا ↗</a>
    </div>
    <div class="pa-wrap">
        <iframe src="{{ url('/buyer?embed=1') }}" allow="web-share; clipboard-write" title="اپ خرید"></iframe>
    </div>
</x-filament-panels::page>
