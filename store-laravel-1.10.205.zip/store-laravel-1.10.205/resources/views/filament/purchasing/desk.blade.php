<x-filament-panels::page>
    @php $d = $this->data(); @endphp
    <style>
        .pu-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}
        .pu-k{background:#fff;border:1px solid rgb(0 0 0/.07);border-radius:18px;padding:14px 16px}.dark .pu-k{background:rgb(255 255 255/.04);border-color:rgb(255 255 255/.08)}
        .pu-k small{display:block;opacity:.6;font-size:12px}.pu-k b{display:block;font-size:22px;font-weight:800;margin-top:4px}.pu-k i{font-style:normal;font-size:11px;opacity:.6}
        .pu-card{background:#fff;border:1px solid rgb(0 0 0/.07);border-radius:20px;padding:16px}.dark .pu-card{background:rgb(255 255 255/.04);border-color:rgb(255 255 255/.08)}
        .pu-card h3{font-weight:800;font-size:15px;margin-bottom:10px}
        .pu-hero{display:flex;flex-wrap:wrap;gap:14px;align-items:center;justify-content:space-between;border-radius:22px;padding:18px 20px;color:#fff;background:linear-gradient(135deg,rgb(var(--primary-600)),#1f2330)}
        .pu-hero b{font-size:18px}.pu-hero p{opacity:.85;font-size:13px;margin-top:4px;max-width:640px}
        .pu-hero a{background:#fff;color:#111;font-weight:800;border-radius:14px;padding:10px 18px;white-space:nowrap}
        .pu-t{width:100%;font-size:13px}.pu-t td,.pu-t th{padding:7px 6px;border-top:1px solid rgb(0 0 0/.06);text-align:right}.pu-t th{opacity:.6;font-weight:600;border:0}
        .pu-bar{height:6px;border-radius:9px;background:rgb(0 0 0/.06);overflow:hidden;margin-top:4px}.pu-bar i{display:block;height:100%;background:linear-gradient(90deg,#f59e0b,#dc2626)}
        .pu-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}@media(max-width:900px){.pu-grid{grid-template-columns:1fr}}
        .pu-pill{display:inline-block;padding:1px 9px;border-radius:99px;font-size:11px;font-weight:700}
        .pu-sent{background:#fef3c7;color:#92400e}.pu-received{background:#dcfce7;color:#166534}.pu-cancelled{background:#f3f4f6;color:#6b7280}
    </style>

    <div class="space-y-5" style="display:flex;flex-direction:column;gap:20px">
        <div class="pu-hero">
            <div>
                <b>اپ مسئول خرید</b>
                <p>کالاهای ناموجود هر کارخانه به ترتیب پرفروش‌ترین، تعیین کارتن، حذف موارد ناخواسته و ارسال گزارش PDF/تصویر برای کارخانه‌ها. روی گوشی باز کنید و «افزودن به صفحه اصلی» را بزنید.</p>
                <p dir="ltr" style="text-align:right;font-weight:700">{{ url('/buyer') }}</p>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
                <a href="{{ \App\Filament\Pages\PurchasingApp::getUrl() }}">تهیه گزارش خرید در پنل ←</a>
                <a href="{{ url('/buyer') }}" target="_blank" style="background:rgb(255 255 255/.15);color:#fff">اپ در پنجره جدا ↗</a>
            </div>
        </div>

        @if (! $d['ready'])
            <div class="pu-card">جدول‌های این بخش در حال ساخت است؛ صفحه را دوباره باز کنید.</div>
        @else
            @php $s = $d['stats']; @endphp
            <div class="pu-kpis">
                <div class="pu-k"><small>کالاهای اکسل</small><b>{{ fa(number_format($s['total'])) }}</b><i>{{ $s['import'] ? 'کالاها: '.fa($s['import']['at']) : 'اکسل کالاها وارد نشده' }}<br>{{ $s['sales_import'] ? 'فروش: '.fa($s['sales_import']['at']) : 'اکسل فروش وارد نشده' }}</i></div>
                <div class="pu-k"><small>ناموجود کارتنی (انبار عمده)</small><b style="color:#dc2626">{{ fa($s['out']) }}</b><i>در {{ fa($s['suppliers']) }} کارخانه — {{ ! empty($s['scan']) ? 'ملاک: اسکن انبار عمده '.fa($s['scan']['at']) : fa($s['missing']).' مورد عکاسی نشده' }}</i></div>
                <div class="pu-k"><small>کم‌موجود</small><b style="color:#d97706">{{ fa($s['low']) }}</b><i>کمتر از حد تنظیم‌شده</i></div>
                <div class="pu-k"><small>در سبد خرید (پیش‌نویس)</small><b style="color:#16a34a">{{ fa($s['draft']) }} قلم</b><i>{{ $s['draft_amount'] ? 'جمع: '.fa(number_format($s['draft_amount'])).' '.$this->cfg['buy_price_unit'] : 'مبلغ آخرین خرید در اکسل نیست' }}</i></div>
                <div class="pu-k"><small>سفارش‌های در انتظار بار</small><b style="color:#2563eb">{{ fa($s['open']) }}</b><i>ثبت‌شده و ارسال‌شده</i></div>
            </div>
            @if (! empty($s['alerts']))
                <a href="{{ url('/buyer') }}" target="_blank" style="display:block;padding:12px 16px;border-radius:14px;background:#fff1f2;color:#9f1239;font-weight:700;border:1.5px solid #fecdd3">⚠️ {{ fa($s['alerts']) }} کالای خریده‌شده در اسکن انبار عمده نیامد — در اپ خرید بررسی کنید ›</a>
            @endif
            @php $old = max($s['import']['days'] ?? 0, $s['sales_import']['days'] ?? 0); @endphp
            @if ($old > 10)
                <div style="padding:12px 16px;border-radius:14px;background:#fef3c7;color:#92400e;font-weight:600">{{ fa($old) }} روز از آخرین ورود اکسل گذشته است؛ فایل‌های تازه کالاها و فروش را وارد کنید.</div>
            @endif

            <div class="pu-grid">
                <div class="pu-card">
                    <h3>ورود اکسل کالاها و فروش (هر چند روز)</h3>
                    <form wire:submit="import" class="space-y-3">
                        {{ $this->upForm }}
                        <x-filament::button type="submit" wire:loading.attr="disabled" wire:target="import">
                            <span wire:loading.remove wire:target="import">وارد کردن و جایگزینی فهرست</span>
                            <span wire:loading wire:target="import">در حال خواندن فایل…</span>
                        </x-filament::button>
                    </form>
                    @foreach ((array) $this->last as $l)
                        <p style="margin-top:10px;font-size:13px">
                            @if ($l['kind'] === 'sales')
                                فروش «{{ $l['file'] }}»: {{ fa($l['rows']) }} بارکد، {{ fa($l['matched']) }} مورد در فهرست کالاها.
                            @else
                                کالاها «{{ $l['file'] }}»: {{ fa($l['rows']) }} کالا، {{ fa($l['suppliers']) }} تأمین‌کننده — {{ fa($l['matched']) }} وصل به کالای سایت، مبلغ آخرین خرید برای {{ fa($l['with_price'] ?? 0) }} کالا.
                            @endif
                        </p>
                    @endforeach
                    @if (count($d['imports']))
                        <table class="pu-t" style="margin-top:12px">
                            <tr><th>تاریخ</th><th>نوع</th><th>فایل</th><th>ردیف</th><th>تطبیق</th></tr>
                            @foreach ($d['imports'] as $im)
                                <tr><td>{{ \App\Support\Jalali::format($im->created_at, true) }}</td><td>{{ ($im->kind ?? 'supply') === 'sales' ? 'فروش' : 'کالاها' }}</td><td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $im->file_name }}</td><td>{{ fa($im->rows) }}</td><td>{{ fa($im->matched + $im->feed_only) }}</td></tr>
                            @endforeach
                        </table>
                    @endif
                </div>

                <div class="pu-card">
                    <h3>کارخانه‌هایی با پرفروش‌ترین کالاهای ناموجود</h3>
                    @php $max = max(1, collect($d['top'])->max('s')); @endphp
                    @forelse ($d['top'] as $t)
                        <div style="padding:6px 0;border-top:1px solid rgb(0 0 0/.05)">
                            <div style="display:flex;justify-content:space-between;gap:8px;font-size:13px"><b>{{ $t['name'] }}</b><span style="opacity:.7">{{ fa($t['n']) }} ناموجود کارتنی</span></div>
                            <div class="pu-bar"><i style="width:{{ max(2, round($t['s'] / $max * 100)) }}%"></i></div>
                        </div>
                    @empty
                        <p style="opacity:.6;font-size:13px">کالای ناموجودی نیست یا اکسل هنوز وارد نشده است.</p>
                    @endforelse
                </div>
            </div>

            <div class="pu-card">
                <h3>آخرین سفارش‌های خرید</h3>
                @if (count($d['orders']))
                    <table class="pu-t">
                        <tr><th>شماره</th><th>کارخانه</th><th>اقلام</th><th>کارتن</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th><th>ثبت‌کننده</th><th></th></tr>
                        @foreach ($d['orders'] as $o)
                            <tr>
                                <td>{{ fa($o->number) }}</td><td>{{ $o->supplier_name }}</td><td>{{ fa($o->items_count) }}</td><td>{{ fa($o->total_cartons) }}</td><td>{{ $o->total_amount ? fa(number_format($o->total_amount)) : '—' }}</td>
                                <td><span class="pu-pill pu-{{ $o->status }}">{{ \App\Models\PurchaseOrder::STATUSES[$o->status] ?? $o->status }}</span></td>
                                <td>{{ \App\Support\Jalali::format($o->created_at, true) }}</td><td>{{ $o->creator?->displayName() }}</td>
                                <td><a href="{{ url('/buyer/print?po='.$o->id) }}" target="_blank" style="color:rgb(var(--primary-600));font-weight:700">چاپ</a></td>
                            </tr>
                        @endforeach
                    </table>
                @else
                    <p style="opacity:.6;font-size:13px">هنوز سفارش خریدی ثبت نشده است.</p>
                @endif
            </div>

            <div class="pu-card">
                <h3>تنظیمات</h3>
                <form wire:submit="saveCfg" class="space-y-3">
                    {{ $this->cfgForm }}
                    <x-filament::button type="submit" color="gray">ذخیره تنظیمات</x-filament::button>
                </form>
                <p style="margin-top:10px;font-size:12.5px;opacity:.7">دسترسی: در «کارمندان» برای مسئول خرید، دسترسی «خرید و تأمین» را بزنید. مدیر کل همیشه دسترسی دارد.</p>
            </div>
        @endif
    </div>
</x-filament-panels::page>
