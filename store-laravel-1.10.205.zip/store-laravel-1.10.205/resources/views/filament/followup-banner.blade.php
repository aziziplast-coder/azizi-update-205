@php
    $u = auth()->user();
    $n = $u && $u->hasPerm('followups') ? \App\Models\Order::overdueQuery($u->force_followup || ! $u->isAdmin() ? $u->id : null)->count() : 0;
@endphp
@if ($n && ! request()->routeIs('filament.admin.pages.followups'))
    <a href="{{ \App\Filament\Pages\Followups::getUrl() }}" class="adm-nag" style="display:flex;gap:8px;align-items:center;margin-bottom:12px;padding:10px 14px;border-radius:12px;background:rgb(254 243 199);color:rgb(146 64 14);font-weight:700;font-size:14px">
        <span class="lg">⚠️ {{ fa($n) }} سفارش عقب‌افتاده {{ $u->isAdmin() && ! $u->force_followup ? 'در فروشگاه' : 'به نام شما' }} پیگیری نشده است — مشاهده و به‌روزرسانی</span><span class="sm">⚠️ {{ fa($n) }} سفارش عقب‌افتاده</span><i class="sm">›</i>
    </a>
@endif
@php $wb = $u && $u->hasPerm('waybills') ? \App\Services\Shipping::overdueCount() : 0; @endphp
@if ($wb && ! request()->routeIs('filament.admin.pages.waybills'))
    <a href="{{ \App\Filament\Pages\Waybills::getUrl() }}" class="wb-nag adm-nag" style="display:flex;gap:8px;align-items:center;margin-bottom:12px;padding:10px 14px;border-radius:12px;background:#dc2626;color:#fff;font-weight:800;font-size:14px">
        <span class="lg">🧾 {{ fa($wb) }} بیجک باربری بیش از {{ fa(\App\Services\Shipping::waybillHours()) }} ساعت است بارگذاری نشده — همین حالا بارگذاری کنید</span><span class="sm">🧾 {{ fa($wb) }} بیجک بارگذاری نشده</span><i class="sm">›</i>
    </a>
    <style>@keyframes wbnag{0%,100%{box-shadow:0 0 0 0 rgb(220 38 38/.55)}50%{box-shadow:0 0 0 8px rgb(220 38 38/0)}}.wb-nag{animation:wbnag 1.6s infinite}</style>
@endif
