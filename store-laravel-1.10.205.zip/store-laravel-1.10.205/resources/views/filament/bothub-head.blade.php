<div class="fi-header flex flex-col gap-4">
    @include('filament.bot-tabs', ['active' => 'bots'])
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
        <h1 class="fi-header-heading text-2xl font-bold tracking-tight">🤖 ربات‌های کانال (بله، تلگرام، روبیکا)</h1>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
            @foreach ($actions as $act){{ $act }}@endforeach
        </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px">
        @forelse ($agents as $id => $a)
            @php $st = ! empty($a['online']) ? 'on' : (empty($a['at']) ? 'never' : 'off'); @endphp
            <div style="border-radius:16px;padding:14px 16px;background:{{ $st === 'on' ? 'rgba(22,163,74,.09)' : ($st === 'off' ? 'rgba(220,38,38,.08)' : 'rgba(127,127,127,.06)') }};border:1px solid {{ $st === 'on' ? 'rgba(22,163,74,.3)' : ($st === 'off' ? 'rgba(220,38,38,.3)' : 'rgba(127,127,127,.2)') }}">
                <div style="font-size:12px;opacity:.7">🖥 {{ $a['label'] }}</div>
                <div style="font-size:17px;font-weight:800;margin-top:2px">{{ $st === 'on' ? '🟢 وصل است' : ($st === 'never' ? '⚪ هنوز وصل نشده' : '🔴 قطع است') }}</div>
                <div style="font-size:12px;opacity:.75;margin-top:4px;line-height:1.9">
                    @if (! empty($a['at']))آخرین تماس: {{ jdate(\Illuminate\Support\Carbon::createFromTimestamp($a['at']), true) }}<br>@endif
                    @if (! empty($a['version']))نسخه {{ $a['version'] }} @if (! empty($a['py']))· پایتون {{ $a['py'] }}@endif<br>@endif
                    @if (! empty($a['ip']))IP: <span dir="ltr">{{ $a['ip'] }}</span>@if (collect($cfg['keys'])->firstWhere('id', $id)['ip'] ?? '') · 🔒 قفل@endif<br>@endif
                    @if (! empty($a['chats']))کانال‌ها: <span dir="ltr">{{ implode('، ', (array) $a['chats']) }}</span><br>@endif
                    کلید: <span dir="ltr">{{ collect($cfg['keys'])->firstWhere('id', $id)['hint'] ?? '' }}</span>
                </div>
            </div>
        @empty
            <div style="border-radius:16px;padding:14px 16px;border:1px dashed rgba(127,127,127,.35);font-size:13px;line-height:2">
                هنوز هاست رباتی وصل نشده. «دانلود برنامه ربات» را بزنید، زیپ را روی هاست ربات بارگذاری کنید و یک خط کرون اضافه کنید (راهنما داخل زیپ).
            </div>
        @endforelse
    </div>
    <div style="font-size:12.5px;opacity:.75">همه ربات‌ها: <b>{{ $cfg['on'] ? 'روشن' : 'خاموش' }}</b> · روی سایت فقط هش کلیدها ذخیره است.</div>
    @php $opName = ['new' => '📤 ارسال', 'repost' => '📤 ارسال دوباره', 'edit' => '✏️ ویرایش', 'delete' => '🗑 حذف', 'announce' => '📣 پیام']; @endphp
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:10px">
        <div style="border-radius:16px;padding:14px 16px;border:1px solid rgba(127,127,127,.2)">
            <div style="display:flex;justify-content:space-between;align-items:center">
                <b style="font-size:14px">آخرین کارهای ربات</b>
                <span style="font-size:12px;opacity:.75">در صف: {{ fa($queue) }} @if ($hold)· <a href="{{ \App\Filament\Resources\BotPostResource::getUrl('index', ['activeTab' => 'hold']) }}" style="color:#b45309;font-weight:700">منتظر تأیید: {{ fa($hold) }}</a>@endif</span>
            </div>
            <div style="font-size:12.5px;line-height:2.1;margin-top:6px">
                @forelse ($acts as $x)
                    <div style="display:flex;justify-content:space-between;gap:8px"><span>{{ $opName[$x['o']] ?? $x['o'] }} — {{ $x['n'] }}@if (! empty($x['r'])) <small>🔔</small>@endif <small style="opacity:.6">({{ $names[$x['p']] ?? '' }})</small></span><span style="opacity:.6;white-space:nowrap" dir="ltr">{{ jdate(\Illuminate\Support\Carbon::createFromTimestamp($x['t']), true) }}</span></div>
                @empty
                    <div style="opacity:.6">هنوز کاری انجام نشده است.</div>
                @endforelse
            </div>
        </div>
        @if ($tops)
            <div style="border-radius:16px;padding:14px 16px;border:1px solid rgba(127,127,127,.2)">
                <b style="font-size:14px">پرکلیک‌ترین کالاها در کانال (۷ روز)</b>
                <div style="font-size:12.5px;line-height:2.1;margin-top:6px">
                    @foreach ($tops as $ch => $list)
                        <div style="opacity:.65;font-size:11.5px;margin-top:4px">{{ $ch }}</div>
                        @foreach ($list as $t)<div style="display:flex;justify-content:space-between"><span>{{ $t['name'] }}</span><span>{{ fa($t['clicks']) }} کلیک</span></div>@endforeach
                    @endforeach
                </div>
            </div>
        @endif
    </div>
    @if ($log)
        <details style="border-radius:14px;border:1px solid rgba(127,127,127,.2);padding:10px 14px">
            <summary style="cursor:pointer;font-weight:700;font-size:13px">رویدادها و خطاهای اخیر ({{ fa(count($log)) }})</summary>
            <div style="font-size:12.5px;line-height:2;margin-top:6px">
                @foreach ($log as $l)
                    <div><span style="opacity:.6" dir="ltr">{{ jdate(\Illuminate\Support\Carbon::createFromTimestamp($l['t']), true) }}</span> — {{ $l['m'] }}</div>
                @endforeach
            </div>
        </details>
    @endif
</div>
