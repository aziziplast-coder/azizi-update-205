<x-filament-panels::page>
<style>
    .cc-t{width:100%;border-collapse:collapse;font-size:13px}
    .cc-t th,.cc-t td{padding:8px;border-bottom:1px solid rgb(127 127 127/.14);text-align:right;vertical-align:middle}
    .cc-t th{font-size:12px;opacity:.7;font-weight:700}
    .cc-code{font-family:ui-monospace,monospace;direction:ltr;display:inline-block;padding:1px 7px;border-radius:6px;background:rgb(127 127 127/.12);font-weight:700}
    .cc-new{background:rgb(22 163 74/.14);color:#15803d}.dark .cc-new{color:#4ade80}
    .cc-old{text-decoration:line-through;opacity:.7}
    .cc-note{padding:12px 14px;border-radius:12px;background:rgb(59 130 246/.08);font-size:13px;line-height:2}
    .cc-tg{display:flex;gap:10px;flex-wrap:wrap}
    .cc-tg label{display:flex;gap:8px;align-items:center;padding:8px 12px;border-radius:10px;border:1px solid rgb(127 127 127/.2);cursor:pointer;font-size:13px}
    .cc-in{height:38px;border-radius:10px;border:1px solid rgb(127 127 127/.3);padding:0 10px;background:transparent;font:inherit}
    .cc-pill{font-size:11px;padding:2px 8px;border-radius:99px;background:rgb(127 127 127/.12)}
    .cc-wrap{overflow-x:auto}
    .cc-res button{display:block;width:100%;text-align:right;padding:7px 10px;border-radius:8px}
    .cc-res button:hover{background:rgb(127 127 127/.1)}
</style>

@if (! $ready)
    <div class="cc-note">برای فعال شدن، یک بار «به‌روزرسانی دیتابیس» را بزنید.</div>
@else
<div class="cc-note">
    <b>چطور کار می‌کند؟</b> هر بار «ورود از اکسل ← اطلاعات کالا» اجرا شود، کدهایی که در سایت نیستند بررسی می‌شوند:
    اگر کالایی در سایت با <b>همان نام</b> هست که کد فعلی‌اش در فایل نیامده، یعنی کدش در هلو عوض شده؛ کد سایت هم خودکار عوض می‌شود
    و از آن به بعد کالا <b>فقط با کد جدید</b> شناخته می‌شود (در جستجو، اکسل، فاکتور هلو و انبار). اگر نام کمی فرق کرده باشد، اینجا برای تأیید شما می‌ماند.
</div>

<div class="cc-tg" style="margin-top:12px">
    <label><input type="checkbox" @checked($cfg['auto']) wire:click="setting('auto')"> تغییر خودکار وقتی نام کالا دقیقاً یکی است</label>
    <label><input type="checkbox" @checked($cfg['suggest']) wire:click="setting('suggest')"> پیشنهاد برای نام‌های شبیه (با تأیید من)</label>
</div>

<x-filament::section :heading="'در انتظار تأیید ('.fa($pending->count()).')'" description="کد در فایل هلو آمده ولی در سایت نیست؛ احتمالاً همین کالاست که کدش عوض شده.">
    @if ($pending->isEmpty())
        <div style="opacity:.6;font-size:13px">موردی برای تأیید نیست. ✅</div>
    @else
    <div class="cc-wrap"><table class="cc-t">
        <tr><th>کالای سایت</th><th>کد فعلی</th><th></th><th>کد در فایل هلو</th><th>نام در فایل</th><th>قیمت سایت / فایل</th><th>دلیل</th><th></th></tr>
        @foreach ($pending as $c)
            @php $p = $products[$c->product_id] ?? null; @endphp
            <tr wire:key="p{{ $c->id }}">
                <td>@if ($p)<a href="{{ \App\Filament\Resources\ProductResource::getUrl('edit', ['record' => $p->id]) }}" target="_blank" style="color:rgb(var(--primary-600))">{{ $p->name }}</a>@else — @endif</td>
                <td><span class="cc-code">{{ $c->old_code }}</span></td><td>←</td>
                <td><span class="cc-code cc-new">{{ $c->new_code }}</span></td>
                <td>{{ $c->file_name }}</td>
                <td style="white-space:nowrap">{{ $p ? money($p->price) : '—' }} / {{ $c->file_price ? money($c->file_price) : '—' }}</td>
                <td><span class="cc-pill">{{ $c->reason }}</span></td>
                <td style="white-space:nowrap">
                    <x-filament::button size="xs" color="success" wire:click="approve({{ $c->id }})">بله، همین است</x-filament::button>
                    <x-filament::button size="xs" color="gray" wire:click="reject({{ $c->id }})">نه</x-filament::button>
                </td>
            </tr>
        @endforeach
    </table></div>
    @endif
</x-filament::section>

<x-filament::section heading="ثبت دستی تغییر کد" description="مسئول خرید گفته کد کالایی عوض شده؟ کد جدید را بنویسید و کالا را انتخاب کنید.">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;align-items:start">
        <div><div style="font-size:12.5px;margin-bottom:4px">کد جدید در هلو</div><input class="cc-in" style="width:100%" dir="ltr" wire:model="newCode" placeholder="مثلاً 504343"></div>
        <div>
            <div style="font-size:12.5px;margin-bottom:4px">کالا (نام یا کد فعلی)</div>
            @if ($picked)
                <div style="display:flex;gap:8px;align-items:center;min-height:38px"><b>{{ $picked->name }}</b> <span class="cc-code">{{ $picked->sku }}</span>
                    <x-filament::link tag="button" size="sm" wire:click="$set('pick', null)">عوض کردن</x-filament::link></div>
            @else
                <input class="cc-in" style="width:100%" wire:model.live.debounce.400ms="find" placeholder="جستجوی کالا…">
                @if ($found)
                    <div class="cc-res" style="margin-top:4px;border:1px solid rgb(127 127 127/.2);border-radius:10px;padding:4px;max-height:260px;overflow:auto">
                        @foreach ($found as $f)
                            <button type="button" wire:click="choose({{ $f->id }})">{{ $f->name }} <span class="cc-code">{{ $f->sku }}</span></button>
                        @endforeach
                    </div>
                @endif
            @endif
        </div>
        <div style="padding-top:22px"><x-filament::button wire:click="assign" icon="heroicon-o-arrows-right-left">عوض کردن کد</x-filament::button></div>
    </div>
</x-filament::section>

<x-filament::section heading="تاریخچه تغییر کدها">
    <x-slot name="headerEnd"><input class="cc-in" wire:model.live.debounce.400ms="q" placeholder="جستجو: کد یا نام" style="width:200px"></x-slot>
    @if ($hist->isEmpty())
        <div style="opacity:.6;font-size:13px">هنوز تغییری ثبت نشده.</div>
    @else
    <div class="cc-wrap"><table class="cc-t">
        <tr><th>تاریخ</th><th>کالا</th><th>کد قبلی</th><th></th><th>کد جدید</th><th>روش</th><th>توسط</th><th></th></tr>
        @foreach ($hist as $c)
            @php $p = $products[$c->product_id] ?? null; @endphp
            <tr wire:key="h{{ $c->id }}" style="{{ $c->status === 'undone' ? 'opacity:.5' : '' }}">
                <td style="white-space:nowrap" class="text-xs">{{ jdate($c->created_at, true) }}</td>
                <td>@if ($p)<a href="{{ \App\Filament\Resources\ProductResource::getUrl('edit', ['record' => $p->id]) }}" target="_blank" style="color:rgb(var(--primary-600))">{{ $p->name }}</a>@else — @endif</td>
                <td><span class="cc-code cc-old">{{ $c->old_code ?: '—' }}</span></td><td>←</td>
                <td><span class="cc-code cc-new">{{ $c->new_code }}</span></td>
                <td><span class="cc-pill">{{ ['auto' => 'خودکار از اکسل', 'manual' => 'ویرایش کالا', 'assign' => 'تأیید / دستی'][$c->source] ?? $c->source }}</span>@if ($c->status === 'undone') <span class="cc-pill">برگردانده شد</span>@endif</td>
                <td class="text-xs">{{ $c->user_id ? ($users[$c->user_id] ?? '') : 'سیستم' }}</td>
                <td>@if ($c->status === 'applied' && $c->old_code && $p && (string) $p->sku === (string) $c->new_code)
                    <x-filament::link tag="button" size="sm" color="danger" wire:click="undo({{ $c->id }})" wire:confirm="کد این کالا به {{ $c->old_code }} برگردد؟">برگرداندن</x-filament::link>
                @endif</td>
            </tr>
        @endforeach
    </table></div>
    @endif
</x-filament::section>
@endif
</x-filament-panels::page>
