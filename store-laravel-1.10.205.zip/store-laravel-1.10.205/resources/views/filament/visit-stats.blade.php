@php
    $S = \App\Services\Stats::class;
    $pct = function ($cur, $prev) {
        if (! $prev) return null;
        return round(($cur - $prev) * 100 / $prev, 1);
    };
    $chg = function ($cur, $prev, bool $lowerBetter = false) use ($pct) {
        $p = $pct($cur, $prev);
        if ($p === null) return '';
        $good = $lowerBetter ? $p <= 0 : $p >= 0;
        return '<span class="vs-chg '.($good ? 'up' : 'down').'">'.($p >= 0 ? '▲' : '▼').' '.fa(abs($p)).'٪</span>';
    };
    $bar = fn ($v, $max) => $max > 0 ? max(2, round($v * 100 / $max)) : 0;
    $sum = $sum ?? [];
@endphp
<x-filament-panels::page>
<style>
    .vs-top{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
    .vs-top select,.vs-top input{height:38px;border-radius:10px;border:1px solid rgb(127 127 127/.3);padding:0 10px;background:transparent;font:inherit}
    .vs-live{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:99px;background:rgb(22 163 74/.1);color:#15803d;font-weight:700;font-size:13px;cursor:pointer}
    .dark .vs-live{color:#4ade80}
    .vs-dot{width:8px;height:8px;border-radius:50%;background:#16a34a;box-shadow:0 0 0 0 rgb(22 163 74/.6);animation:vsp 1.8s infinite}
    @keyframes vsp{70%{box-shadow:0 0 0 8px rgb(22 163 74/0)}100%{box-shadow:0 0 0 0 rgb(22 163 74/0)}}
    .vs-tabs{display:flex;flex-wrap:wrap;gap:6px}
    .vs-tabs button{padding:7px 14px;border-radius:99px;border:1px solid rgb(127 127 127/.25);font-size:13px;font-weight:600}
    .vs-tabs button.on{background:rgb(var(--primary-600));border-color:transparent;color:#fff}
    .vs-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px}
    .vs-card{padding:14px 16px;border-radius:14px;border:1px solid rgb(127 127 127/.18);background:rgb(255 255 255/.6)}
    .dark .vs-card{background:rgb(255 255 255/.03)}
    .vs-card small{display:block;opacity:.65;font-size:12.5px}
    .vs-card b{font-size:21px;font-weight:800;display:block;margin:2px 0}
    .vs-card i{font-style:normal;font-size:11.5px;opacity:.6}
    .vs-chg{font-size:12px;font-weight:700}.vs-chg.up{color:#16a34a}.vs-chg.down{color:#dc2626}
    .vs-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:16px}
    .vs-t{width:100%;border-collapse:collapse;font-size:13px}
    .vs-t th,.vs-t td{padding:7px 8px;border-bottom:1px solid rgb(127 127 127/.13);text-align:right;white-space:nowrap}
    .vs-t th{font-weight:700;opacity:.7;font-size:12px}
    .vs-t td.nm{white-space:normal;max-width:280px}
    .vs-wrap{overflow-x:auto}
    .vs-b{position:relative;height:6px;border-radius:9px;background:rgb(127 127 127/.12);margin-top:4px;min-width:60px}
    .vs-b span{position:absolute;top:0;bottom:0;right:0;border-radius:9px;background:rgb(var(--primary-500))}
    .vs-funnel{display:flex;flex-direction:column;gap:8px}
    .vs-fs{display:grid;grid-template-columns:150px 1fr 90px;align-items:center;gap:10px;font-size:13px}
    .vs-fs .tr{height:30px;border-radius:8px;background:rgb(127 127 127/.1);position:relative;overflow:hidden}
    .vs-fs .tr span{position:absolute;top:0;bottom:0;right:0;background:linear-gradient(90deg,rgb(var(--primary-400)),rgb(var(--primary-600)));border-radius:8px}
    .vs-fs .tr em{position:absolute;inset:0;display:flex;align-items:center;padding:0 10px;font-style:normal;font-weight:700;color:#fff;mix-blend-mode:normal;text-shadow:0 1px 2px rgb(0 0 0/.35)}
    .vs-heat{display:grid;grid-template-columns:70px repeat(24,1fr);gap:2px;font-size:10.5px;direction:ltr}
    .vs-heat div{height:22px;border-radius:4px;display:flex;align-items:center;justify-content:center}
    .vs-heat .lb{direction:rtl;justify-content:flex-end;padding-inline-end:6px;font-size:11.5px;opacity:.75}
    .vs-note{padding:12px 14px;border-radius:12px;background:rgb(234 179 8/.12);font-size:13px;line-height:1.9}
    .vs-chart svg{width:100%;height:240px;display:block}
    .vs-leg{display:flex;gap:14px;font-size:12px;opacity:.8;margin-top:6px;flex-wrap:wrap}
    .vs-leg span::before{content:'';display:inline-block;width:10px;height:10px;border-radius:3px;margin-inline-end:5px;vertical-align:-1px;background:var(--c)}
    .vs-pill{display:inline-block;padding:2px 8px;border-radius:99px;font-size:11.5px;background:rgb(127 127 127/.12)}
    .vs-mut{opacity:.6;font-size:12px}
</style>

<div wire:poll.60s="refreshData">
<div class="vs-top">
    <select wire:model.live="period" aria-label="بازه">
        @foreach (\App\Services\Reports::PERIODS as $k => $v)
            @continue($k === 'all')
            <option value="{{ $k }}">{{ $v }}</option>
        @endforeach
    </select>
    @if ($period === 'custom')
        <input wire:model.blur="from" placeholder="از ۱۴۰۵/۰۸/۰۱" dir="ltr" style="width:140px">
        <input wire:model.blur="to" placeholder="تا ۱۴۰۵/۰۸/۳۰" dir="ltr" style="width:140px">
    @endif
    <span class="vs-mut">{{ $label }}</span>
    <span wire:loading class="vs-mut">در حال محاسبه…</span>
    <span class="vs-live" wire:click="setTab('live')" title="بازدیدکنندگان ۵ دقیقه اخیر"><i class="vs-dot"></i> الان {{ fa($online['n']) }} نفر در سایت</span>
    <span style="margin-inline-start:auto;display:flex;gap:6px">
        @if (in_array($tab, ['overview', 'sources']))
            <x-filament::button size="sm" color="gray" icon="heroicon-o-arrow-down-tray" wire:click="export('channels')">اکسل منابع</x-filament::button>
        @elseif ($tab === 'products')
            <x-filament::button size="sm" color="gray" icon="heroicon-o-arrow-down-tray" wire:click="export('products')">اکسل کالاها</x-filament::button>
        @elseif ($tab === 'search')
            <x-filament::button size="sm" color="gray" icon="heroicon-o-arrow-down-tray" wire:click="export('search')">اکسل جستجوها</x-filament::button>
        @endif
        @if (auth()->user()->isAdmin() || auth()->user()->hasPerm('settings'))
            <x-filament::button size="sm" :color="$enabled ? 'gray' : 'success'" wire:click="toggle" wire:confirm="{{ $enabled ? 'ثبت آمار بازدید خاموش شود؟' : 'ثبت آمار بازدید روشن شود؟' }}">{{ $enabled ? 'خاموش کردن ثبت آمار' : 'روشن کردن ثبت آمار' }}</x-filament::button>
        @endif
    </span>
</div>

@if (! $enabled)
    <div class="vs-note" style="margin-top:12px">ثبت آمار بازدید خاموش است؛ بازدیدهای تازه شمرده نمی‌شوند.</div>
@elseif ($empty)
    <div class="vs-note" style="margin-top:12px">👋 ثبت آمار از همین الان شروع شد. چند دقیقه بعد از اولین بازدیدها، اعداد اینجا نمایش داده می‌شوند.<br>
        همکاران فروشگاه (مدیر و کارکنان) در آمار شمرده نمی‌شوند؛ برای امتحان، سایت را از یک گوشی بدون ورود باز کنید.</div>
@endif

<div class="vs-tabs" style="margin-top:14px">
    @foreach (\App\Filament\Pages\VisitStats::TABS as $k => $v)
        <button type="button" class="{{ $tab === $k ? 'on' : '' }}" wire:click="setTab('{{ $k }}')">{{ $v }}</button>
    @endforeach
</div>

<div style="display:flex;flex-direction:column;gap:16px;margin-top:16px">

{{-- ===================================================== نمای کلی --}}
@if ($tab === 'overview')
    <div class="vs-cards">
        @foreach ([
            ['بازدیدکننده یکتا', fa($sum['visitors']), $chg($sum['visitors'], $prev['visitors']), 'جدید: '.fa($sum['new'])],
            ['ورود (نشست)', fa($sum['sessions']), $chg($sum['sessions'], $prev['sessions']), 'از اپ: '.fa($sum['app'])],
            ['بازدید صفحه', fa($sum['pageviews']), $chg($sum['pageviews'], $prev['pageviews']), fa($sum['pps']).' صفحه در هر ورود'],
            ['میانگین ماندن', $S::dur($sum['dur']), $chg($sum['dur'], $prev['dur']), 'زمانی که صفحه جلوی چشم بوده'],
            ['نرخ پرش', fa($sum['bounce']).'٪', $chg($sum['bounce'], $prev['bounce'], true), 'فقط یک صفحه دیده و رفته'],
            ['افزودن به سبد', fa($sum['adds']), $chg($sum['adds'], $prev['adds']), fa($sum['cart_s']).' ورود با سبد'],
            ['سفارش از بازدیدها', fa($sum['orders']), $chg($sum['orders'], $prev['orders']), 'نرخ تبدیل: '.fa($sum['conv']).'٪'],
            ['فروش از بازدیدها', money($sum['revenue']), $chg($sum['revenue'], $prev['revenue']), 'تومان'],
        ] as [$l, $v, $c, $sub])
            <div class="vs-card"><small>{{ $l }}</small><b>{{ $v }}</b>{!! $c !!} <i>{{ $sub }}</i></div>
        @endforeach
    </div>

    @php
        $ser = $series;
        $nS = count($ser);
        $maxV = max(1, collect($ser)->max('pv'));
        $W = 1000; $H = 220; $pad = 10;
        $x = fn ($i) => $nS > 1 ? $pad + ($W - 2 * $pad) * $i / ($nS - 1) : $W / 2;
        $y = fn ($v) => $H - 18 - ($H - 36) * $v / $maxV;
        $line = fn ($key) => collect($ser)->map(fn ($r, $i) => round($x($i), 1).','.round($y($r[$key]), 1))->implode(' ');
        $area = 'M'.round($x(0),1).','.($H - 18).' L'.str_replace(' ', ' L', $line('v')).' L'.round($x($nS - 1),1).','.($H - 18).' Z';
        $step = max(1, (int) ceil($nS / 10));
    @endphp
    <x-filament::section heading="روند بازدید" :description="'مقایسه با '.fa($days).' روز قبل از آن در کارت‌های بالا'">
        <div class="vs-chart">
            <svg viewBox="0 0 {{ $W }} {{ $H }}" preserveAspectRatio="none" role="img" aria-label="نمودار بازدید">
                @foreach ([0.25, 0.5, 0.75, 1] as $g)
                    <line x1="0" x2="{{ $W }}" y1="{{ $y($maxV * $g) }}" y2="{{ $y($maxV * $g) }}" stroke="currentColor" stroke-opacity=".08"/>
                @endforeach
                <path d="{{ $area }}" fill="rgb(var(--primary-500))" fill-opacity=".12"/>
                <polyline points="{{ $line('pv') }}" fill="none" stroke="#f59e0b" stroke-width="2" vector-effect="non-scaling-stroke"/>
                <polyline points="{{ $line('v') }}" fill="none" stroke="rgb(var(--primary-600))" stroke-width="2.5" vector-effect="non-scaling-stroke"/>
                @foreach ($ser as $i => $r)
                    <circle cx="{{ $x($i) }}" cy="{{ $y($r['v']) }}" r="{{ $nS > 40 ? 0 : 3 }}" fill="rgb(var(--primary-600))"><title>{{ $r['label'] }}: {{ fa($r['v']) }} بازدیدکننده · {{ fa($r['pv']) }} صفحه · {{ fa($r['o']) }} سفارش</title></circle>
                    <rect x="{{ $x($i) - ($W / max(1, $nS)) / 2 }}" y="0" width="{{ $W / max(1, $nS) }}" height="{{ $H }}" fill="transparent"><title>{{ $r['label'] }}: {{ fa($r['v']) }} بازدیدکننده · {{ fa($r['pv']) }} بازدید صفحه · {{ fa($r['o']) }} سفارش</title></rect>
                @endforeach
            </svg>
            <div style="display:flex;justify-content:space-between;font-size:10.5px;opacity:.6;direction:ltr">
                @foreach ($ser as $i => $r)
                    @if ($i % $step === 0 || $i === $nS - 1)<span>{{ \Illuminate\Support\Str::after($r['label'], '/') }}</span>@endif
                @endforeach
            </div>
            <div class="vs-leg"><span style="--c:rgb(var(--primary-600))">بازدیدکننده یکتا</span><span style="--c:#f59e0b">بازدید صفحه</span><span class="vs-mut">نشانگر را روی هر روز نگه دارید تا عددها را ببینید</span></div>
        </div>
    </x-filament::section>

    <div class="vs-grid">
        <x-filament::section heading="قیف خرید" description="از ورود تا سفارش؛ کجا مشتری‌ها را از دست می‌دهید؟">
            @php
                $fs = [['ورود به سایت', $sum['sessions']], ['دیدن صفحه کالا', $sum['product_s']], ['افزودن به سبد', $sum['cart_s']], ['رسیدن به تکمیل خرید', $sum['checkout_s']], ['ثبت سفارش', $sum['order_s']]];
                $f0 = max(1, $fs[0][1]);
            @endphp
            <div class="vs-funnel">
                @foreach ($fs as $i => [$l, $n])
                    <div class="vs-fs">
                        <span>{{ $l }}</span>
                        <div class="tr"><span style="width:{{ max(3, round($n * 100 / $f0)) }}%"></span><em>{{ fa($n) }}</em></div>
                        <span class="vs-mut">{{ $i ? fa(round($n * 100 / max(1, $fs[$i - 1][1]))).'٪ از قبلی' : '' }}</span>
                    </div>
                @endforeach
            </div>
        </x-filament::section>

        <x-filament::section heading="از کجا می‌آیند؟">
            @php $mx = max(1, collect($channels)->max('s')); @endphp
            <table class="vs-t">
                <tr><th>منبع</th><th>ورود</th><th>سفارش</th><th>تبدیل</th></tr>
                @forelse ($channels as $r)
                    <tr><td class="nm">{{ $S::CHANNELS[$r['k']] ?? $r['k'] }}<div class="vs-b"><span style="width:{{ $bar($r['s'], $mx) }}%"></span></div></td><td>{{ fa($r['s']) }}</td><td>{{ fa($r['o']) }}</td><td>{{ fa($r['conv']) }}٪</td></tr>
                @empty
                    <tr><td colspan="4" class="vs-mut">هنوز داده‌ای نیست.</td></tr>
                @endforelse
            </table>
            <div style="margin-top:8px"><x-filament::link tag="button" wire:click="setTab('sources')" size="sm">جزئیات منابع ←</x-filament::link></div>
        </x-filament::section>
    </div>

    <x-filament::section heading="چه ساعت‌هایی شلوغ است؟" description="تعداد ورود به سایت در هر ساعت و روز هفته (پررنگ‌تر = شلوغ‌تر). بهترین زمان برای پیامک، تخفیف و پاسخگویی.">
        @php $hm = max(1, collect($heat)->flatten()->max()); @endphp
        <div class="vs-wrap"><div class="vs-heat" style="min-width:720px">
            <div></div>
            @for ($h = 0; $h < 24; $h++)<div class="vs-mut">{{ fa($h) }}</div>@endfor
            @foreach ($heat as $wd => $row)
                <div class="lb">{{ $S::WEEKDAYS[$wd] }}</div>
                @foreach ($row as $h => $n)
                    <div title="{{ $S::WEEKDAYS[$wd] }} ساعت {{ fa($h) }}: {{ fa($n) }} ورود" style="background:rgba(var(--primary-500), {{ $n ? round(0.12 + 0.88 * $n / $hm, 2) : 0.05 }});color:{{ $n / $hm > .55 ? '#fff' : 'inherit' }}">{{ $n ? fa($n) : '' }}</div>
                @endforeach
            @endforeach
        </div></div>
    </x-filament::section>

    <div class="vs-grid">
        <x-filament::section heading="بازدید بر اساس نوع صفحه">
            @php $mx = max(1, collect($kinds)->max('n')); @endphp
            <table class="vs-t">
                @foreach ($kinds as $r)
                    <tr><td class="nm">{{ $S::KINDS[$r['k']] ?? $r['k'] }}<div class="vs-b"><span style="width:{{ $bar($r['n'], $mx) }}%"></span></div></td><td>{{ fa($r['n']) }}</td><td class="vs-mut">{{ fa(round($r['n'] * 100 / max(1, $sum['pageviews']))) }}٪</td></tr>
                @endforeach
            </table>
        </x-filament::section>
        <x-filament::section heading="بازدید صفحه در ساعت‌های روز">
            @php $hh = collect($hours)->keyBy('k'); $mx = max(1, collect($hours)->max('n')); @endphp
            <div style="display:flex;align-items:flex-end;gap:3px;height:150px;direction:ltr">
                @for ($h = 0; $h < 24; $h++)
                    @php $n = (int) ($hh[(string) $h]['n'] ?? 0); @endphp
                    <div title="ساعت {{ fa($h) }}: {{ fa($n) }} بازدید" style="flex:1;display:flex;flex-direction:column;justify-content:flex-end;height:100%;gap:3px;align-items:center">
                        <i style="display:block;width:100%;border-radius:4px 4px 0 0;background:rgb(var(--primary-500));height:{{ $n ? max(2, round($n * 100 / $mx)) : 0 }}%"></i>
                        <span style="font-size:9.5px;opacity:.6">{{ fa($h) }}</span>
                    </div>
                @endfor
            </div>
        </x-filament::section>
    </div>
@endif

{{-- ===================================================== منابع ورود --}}
@if ($tab === 'sources')
    <x-filament::section heading="کانال‌های ورود" description="هر ورود یک بار شمرده می‌شود (۳۰ دقیقه بی‌فعالیتی = ورود تازه). سفارش و فروش، سفارش‌هایی است که در همان ورود ثبت شده.">
        <div class="vs-wrap"><table class="vs-t">
            <tr><th>کانال</th><th>ورود</th><th>بازدیدکننده</th><th>صفحه/ورود</th><th>ماندن</th><th>پرش</th><th>افزودن به سبد</th><th>سفارش</th><th>تبدیل</th><th>فروش (تومان)</th><th></th></tr>
            @forelse ($channels as $r)
                <tr>
                    <td class="nm"><b>{{ $S::CHANNELS[$r['k']] ?? $r['k'] }}</b></td><td>{{ fa($r['s']) }}</td><td>{{ fa($r['v']) }}</td><td>{{ fa(round($r['pv'] / max(1, $r['s']), 1)) }}</td>
                    <td>{{ $S::dur($r['dur']) }}</td><td>{{ fa($r['bounce']) }}٪</td><td>{{ fa($r['ad']) }}</td><td>{{ fa($r['o']) }}</td><td>{{ fa($r['conv']) }}٪</td><td>{{ money($r['rev']) }}</td>
                    <td><x-filament::link tag="button" size="sm" wire:click="$set('channel', '{{ $channel === $r['k'] ? '' : $r['k'] }}')">{{ $channel === $r['k'] ? 'همه' : 'جزئیات' }}</x-filament::link></td>
                </tr>
            @empty
                <tr><td colspan="11" class="vs-mut">هنوز داده‌ای نیست.</td></tr>
            @endforelse
        </table></div>
    </x-filament::section>

    <x-filament::section heading="🔗 لینک‌ساز کمپین" description="برای هر پست اینستاگرام، پیامک یا تبلیغ یک لینک جدا بسازید تا اینجا ببینید هر کدام چند بازدید و چند سفارش آورده.">
        <div x-data="{ u: @js(url('/')), s: 'instagram', c: '' , get link() { let b = this.u.trim() || '/'; let q = 'utm_source=' + encodeURIComponent(this.s.trim() || 'link') + (this.s === 'sms' ? '&utm_medium=sms' : '') + (this.c.trim() ? '&utm_campaign=' + encodeURIComponent(this.c.trim()) : ''); return b + (b.includes('?') ? '&' : '?') + q } }" style="display:grid;gap:8px;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));align-items:end">
            <label style="font-size:12.5px">آدرس صفحه (سایت، کالا یا دسته)<input x-model="u" dir="ltr" style="width:100%;height:38px;border-radius:10px;border:1px solid rgb(127 127 127/.3);padding:0 10px;background:transparent"></label>
            <label style="font-size:12.5px">کجا منتشر می‌کنید؟
                <select x-model="s" style="width:100%;height:38px;border-radius:10px;border:1px solid rgb(127 127 127/.3);padding:0 10px;background:transparent">
                    <option value="instagram">اینستاگرام</option><option value="telegram">تلگرام</option><option value="whatsapp">واتساپ</option><option value="eitaa">ایتا</option><option value="bale">بله</option><option value="rubika">روبیکا</option><option value="sms">پیامک</option><option value="ads">تبلیغ</option><option value="other">سایر</option>
                </select></label>
            <label style="font-size:12.5px">نام کمپین (انگلیسی، مثلاً yalda)<input x-model="c" dir="ltr" style="width:100%;height:38px;border-radius:10px;border:1px solid rgb(127 127 127/.3);padding:0 10px;background:transparent"></label>
            <div style="grid-column:1/-1;display:flex;gap:8px;align-items:center">
                <code x-text="link" dir="ltr" style="flex:1;padding:9px 12px;border-radius:10px;background:rgb(127 127 127/.1);font-size:12.5px;overflow-wrap:anywhere"></code>
                <x-filament::button size="sm" x-on:click="navigator.clipboard && navigator.clipboard.writeText(link); $el.querySelector('span') && ($el.querySelector('span').innerText = 'کپی شد ✓')">کپی لینک</x-filament::button>
            </div>
        </div>
    </x-filament::section>

    <div class="vs-grid">
        <x-filament::section :heading="'سایت‌ها و منابع'.($channel ? ' — '.($S::CHANNELS[$channel] ?? $channel) : '')" description="سایت ارجاع‌دهنده یا utm_source لینک">
            <table class="vs-t">
                <tr><th>منبع</th><th>ورود</th><th>سفارش</th><th>فروش</th></tr>
                @forelse ($sources as $r)
                    <tr><td class="nm" dir="ltr" style="text-align:right">{{ $r['k'] }}</td><td>{{ fa($r['s']) }}</td><td>{{ fa($r['o']) }}</td><td>{{ money($r['rev']) }}</td></tr>
                @empty
                    <tr><td colspan="4" class="vs-mut">موردی نیست.</td></tr>
                @endforelse
            </table>
        </x-filament::section>
        <x-filament::section heading="کمپین‌ها (utm_campaign)" description="برای لینک‌های اینستاگرام، پیامک و تبلیغ، آخر لینک بنویسید: ?utm_source=instagram&utm_campaign=yalda">
            <table class="vs-t">
                <tr><th>کمپین</th><th>ورود</th><th>سفارش</th><th>فروش</th></tr>
                @forelse ($campaigns as $r)
                    @continue(! $channel && isset($advNames[$r['k']]))
                    <tr><td class="nm">{{ $r['k'] }}</td><td>{{ fa($r['s']) }}</td><td>{{ fa($r['o']) }}</td><td>{{ money($r['rev']) }}</td></tr>
                @empty
                    <tr><td colspan="4" class="vs-mut">موردی نیست.</td></tr>
                @endforelse
            </table>
        </x-filament::section>
    </div>

    <div class="vs-grid">
        <x-filament::section heading="ورود از لینک مشاوران">
            <table class="vs-t">
                <tr><th>مشاور</th><th>ورود</th><th>بازدیدکننده</th><th>سفارش</th><th>فروش</th></tr>
                @forelse ($advisors as $r)
                    <tr><td class="nm">{{ $advNames[$r['k']] ?? $r['k'] }}</td><td>{{ fa($r['s']) }}</td><td>{{ fa($r['v']) }}</td><td>{{ fa($r['o']) }}</td><td>{{ money($r['rev']) }}</td></tr>
                @empty
                    <tr><td colspan="5" class="vs-mut">هنوز کسی از لینک مشاوران وارد نشده.</td></tr>
                @endforelse
            </table>
        </x-filament::section>
        <x-filament::section heading="صفحه‌های ورود" description="اولین صفحه‌ای که بازدیدکننده دیده">
            <table class="vs-t">
                <tr><th>صفحه</th><th>ورود</th><th>پرش</th><th>سفارش</th></tr>
                @forelse ($landing as $r)
                    <tr><td class="nm">{{ \Illuminate\Support\Str::limit($r['k'], 60) }}</td><td>{{ fa($r['s']) }}</td><td>{{ fa($r['bounce']) }}٪</td><td>{{ fa($r['o']) }}</td></tr>
                @empty
                    <tr><td colspan="4" class="vs-mut">موردی نیست.</td></tr>
                @endforelse
            </table>
        </x-filament::section>
        <x-filament::section heading="صفحه‌های خروج" description="آخرین صفحه‌ای که قبل از رفتن دیده شده">
            <table class="vs-t">
                <tr><th>صفحه</th><th>تعداد</th></tr>
                @forelse ($exits as $r)
                    <tr><td class="nm">{{ \Illuminate\Support\Str::limit($r['k'], 60) }}</td><td>{{ fa($r['s']) }}</td></tr>
                @empty
                    <tr><td colspan="2" class="vs-mut">موردی نیست.</td></tr>
                @endforelse
            </table>
        </x-filament::section>
    </div>
@endif

{{-- ===================================================== کالاها --}}
@if ($tab === 'products')
    <x-filament::section heading="پربازدیدترین کالاها" description="بازدید = هر بار باز شدن صفحه کالا؛ یکتا = تعداد ورودهایی که کالا را دیده‌اند؛ نرخ افزودن = چند درصد بیننده‌ها به سبد اضافه کرده‌اند.">
        @php $mx = max(1, collect($products)->max('n')); @endphp
        <div class="vs-wrap"><table class="vs-t">
            <tr><th>#</th><th>کالا</th><th>بازدید</th><th>یکتا</th><th>افزودن به سبد</th><th>نرخ افزودن</th></tr>
            @forelse ($products as $i => $r)
                <tr>
                    <td class="vs-mut">{{ fa($i + 1) }}</td>
                    <td class="nm"><a href="{{ \App\Filament\Resources\ProductResource::getUrl('edit', ['record' => $r['k']]) }}" style="color:rgb(var(--primary-600))">{{ $pnames[$r['k']] ?? ('کالای حذف‌شده #'.$r['k']) }}</a><div class="vs-b"><span style="width:{{ $bar($r['n'], $mx) }}%"></span></div></td>
                    <td>{{ fa($r['n']) }}</td><td>{{ fa($r['u']) }}</td><td>{{ fa($r['a']) }}</td><td>{{ fa($r['u'] ? round($r['a'] * 100 / $r['u']) : 0) }}٪</td>
                </tr>
            @empty
                <tr><td colspan="6" class="vs-mut">هنوز داده‌ای نیست.</td></tr>
            @endforelse
        </table></div>
    </x-filament::section>

    <div class="vs-grid">
        <x-filament::section heading="⚠️ پربازدید ولی کم‌خرید" description="زیاد دیده می‌شوند ولی کمتر به سبد اضافه می‌شوند؛ قیمت، عکس، توضیح یا موجودی‌شان را بررسی کنید.">
            <table class="vs-t">
                <tr><th>کالا</th><th>یکتا</th><th>افزودن</th><th>نرخ</th></tr>
                @forelse ($cold as $r)
                    <tr><td class="nm"><a href="{{ \App\Filament\Resources\ProductResource::getUrl('edit', ['record' => $r['k']]) }}" style="color:rgb(var(--primary-600))">{{ $pnames[$r['k']] ?? '#'.$r['k'] }}</a></td><td>{{ fa($r['u']) }}</td><td>{{ fa($r['a']) }}</td><td>{{ fa(round($r['a'] * 100 / max(1, $r['u']))) }}٪</td></tr>
                @empty
                    <tr><td colspan="4" class="vs-mut">کالایی با حداقل ۵ بیننده نیست.</td></tr>
                @endforelse
            </table>
        </x-filament::section>
        <x-filament::section heading="دسته‌بندی‌ها" description="باز شدن صفحه دسته + بازدید کالاهای آن دسته">
            @php $pc = collect($pcats)->keyBy('k'); $all = collect($cats)->keyBy('k')->keys()->merge($pc->keys())->unique()->take(20); @endphp
            <table class="vs-t">
                <tr><th>دسته</th><th>صفحه دسته</th><th>بازدید کالاها</th></tr>
                @forelse ($all as $k)
                    <tr><td class="nm">{{ $cnames[$k] ?? '#'.$k }}</td><td>{{ fa(collect($cats)->firstWhere('k', $k)['n'] ?? 0) }}</td><td>{{ fa($pc[$k]['n'] ?? 0) }}</td></tr>
                @empty
                    <tr><td colspan="3" class="vs-mut">هنوز داده‌ای نیست.</td></tr>
                @endforelse
            </table>
        </x-filament::section>
    </div>
@endif

{{-- ===================================================== جستجو --}}
@if ($tab === 'search')
    <div class="vs-cards">
        <div class="vs-card"><small>تعداد جستجو</small><b>{{ fa($sum['searches']) }}</b></div>
        <div class="vs-card"><small>جستجوی بی‌نتیجه</small><b>{{ fa(collect($zero)->sum('a')) }}</b><i>کالایی پیدا نشده</i></div>
    </div>
    <div class="vs-grid">
        <x-filament::section heading="بیشترین جستجوها">
            @php $mx = max(1, collect($searches)->max('n')); @endphp
            <table class="vs-t">
                <tr><th>عبارت</th><th>تعداد</th><th>بی‌نتیجه</th></tr>
                @forelse ($searches as $r)
                    <tr><td class="nm"><a href="{{ route('shop', ['q' => $r['k']]) }}" target="_blank" style="color:rgb(var(--primary-600))">{{ $r['k'] }}</a><div class="vs-b"><span style="width:{{ $bar($r['n'], $mx) }}%"></span></div></td><td>{{ fa($r['n']) }}</td><td>{{ $r['a'] ? fa($r['a']) : '' }}</td></tr>
                @empty
                    <tr><td colspan="3" class="vs-mut">هنوز جستجویی ثبت نشده.</td></tr>
                @endforelse
            </table>
        </x-filament::section>
        <x-filament::section heading="❗ جستجوهای بی‌نتیجه" description="مشتری دنبالش بوده ولی چیزی پیدا نکرده؛ یا کالا را اضافه کنید، یا این کلمه را به نام/برچسب کالای مشابه اضافه کنید.">
            <table class="vs-t">
                <tr><th>عبارت</th><th>دفعات بی‌نتیجه</th></tr>
                @forelse ($zero as $r)
                    <tr><td class="nm">{{ $r['k'] }}</td><td>{{ fa($r['a']) }}</td></tr>
                @empty
                    <tr><td colspan="2" class="vs-mut">عالی! جستجوی بی‌نتیجه‌ای نبوده.</td></tr>
                @endforelse
            </table>
        </x-filament::section>
    </div>
@endif

{{-- ===================================================== مخاطبان --}}
@if ($tab === 'audience')
    @php
        $lists = [
            ['دستگاه', $devices, fn ($k) => $S::DEVICES[$k] ?? 'نامشخص'],
            ['سیستم‌عامل', $os, fn ($k) => $S::OS[$k] ?? 'نامشخص'],
            ['مرورگر', $browsers, fn ($k) => $S::BROWSERS[$k] ?? 'نامشخص'],
            ['سایت یا اپ', $apps, fn ($k) => ['0' => 'سایت (مرورگر)', '1' => 'اپ اندروید', '2' => 'نصب‌شده روی صفحه گوشی'][$k] ?? $k],
            ['جدید یا قدیمی', $newret, fn ($k) => $k === '1' ? 'بازدیدکننده جدید' : 'بازدیدکننده قدیمی (برگشتی)'],
        ];
    @endphp
    <div class="vs-grid">
        @foreach ($lists as [$h, $rows, $nm])
            <x-filament::section :heading="$h">
                @php $tot = max(1, collect($rows)->sum('s')); @endphp
                <table class="vs-t">
                    <tr><th></th><th>ورود</th><th>سهم</th><th>تبدیل</th></tr>
                    @forelse ($rows as $r)
                        <tr><td class="nm">{{ $nm((string) $r['k']) }}<div class="vs-b"><span style="width:{{ $bar($r['s'], $tot) }}%"></span></div></td><td>{{ fa($r['s']) }}</td><td>{{ fa(round($r['s'] * 100 / $tot)) }}٪</td><td>{{ fa($r['conv']) }}٪</td></tr>
                    @empty
                        <tr><td colspan="4" class="vs-mut">هنوز داده‌ای نیست.</td></tr>
                    @endforelse
                </table>
            </x-filament::section>
        @endforeach
    </div>
    <x-filament::section heading="مشتریان واردشده با بیشترین بازدید" description="مشتریانی که با حساب کاربری وارد سایت شده‌اند؛ آن‌هایی که زیاد سر می‌زنند ولی سفارش نداده‌اند، فرصت تماس هستند.">
        <div class="vs-wrap"><table class="vs-t">
            <tr><th>مشتری</th><th>شهر</th><th>ورود</th><th>صفحه</th><th>کالا دیده</th><th>افزودن</th><th>سفارش</th><th>آخرین بازدید</th></tr>
            @forelse ($customers as $r)
                <tr>
                    <td class="nm"><a href="{{ \App\Filament\Resources\CustomerResource::getUrl('index', ['tableSearch' => $r['mobile'] ?: $r['name']]) }}" style="color:rgb(var(--primary-600))">{{ $r['name'] }}</a> <span class="vs-mut" dir="ltr">{{ $r['mobile'] }}</span></td>
                    <td>{{ $r['city'] }}</td><td>{{ fa($r['s']) }}</td><td>{{ fa($r['pv']) }}</td><td>{{ fa($r['pr']) }}</td><td>{{ fa($r['ad']) }}</td>
                    <td>@if ($r['o']){{ fa($r['o']) }}@else<span class="vs-pill" style="background:rgb(234 179 8/.18)">بدون سفارش</span>@endif</td>
                    <td class="vs-mut">{{ jdate(\Carbon\Carbon::createFromTimestamp($r['la'], config('app.timezone')), true) }}</td>
                </tr>
            @empty
                <tr><td colspan="8" class="vs-mut">هنوز مشتری واردشده‌ای سر نزده.</td></tr>
            @endforelse
        </table></div>
    </x-filament::section>
@endif

{{-- ===================================================== الان --}}
@if ($tab === 'live')
    <div class="vs-cards">
        <div class="vs-card"><small>الان در سایت (۵ دقیقه اخیر)</small><b>{{ fa($online['n']) }} نفر</b><i>هر دقیقه خودکار به‌روز می‌شود</i></div>
        <div class="vs-card"><small>بازدیدکننده یکتای {{ $days === 1 ? 'امروز' : 'این بازه' }}</small><b>{{ fa($sum['visitors']) }}</b></div>
    </div>
    <div class="vs-grid">
        <x-filament::section heading="در چه بخشی هستند؟">
            @php $mx = max(1, max($online['kinds'] ?: [0])); @endphp
            <table class="vs-t">
                @forelse ($online['kinds'] as $k => $n)
                    <tr><td class="nm">{{ $S::KINDS[$k] ?? $k }}<div class="vs-b"><span style="width:{{ $bar($n, $mx) }}%"></span></div></td><td>{{ fa($n) }} نفر</td></tr>
                @empty
                    <tr><td class="vs-mut">الان کسی در سایت نیست.</td></tr>
                @endforelse
            </table>
        </x-filament::section>
        <x-filament::section heading="صفحه‌هایی که الان دیده می‌شوند">
            <table class="vs-t">
                @forelse ($online['pages'] as $t => $n)
                    <tr><td class="nm">{{ \Illuminate\Support\Str::limit($t, 70) }}</td><td>{{ fa($n) }} نفر</td></tr>
                @empty
                    <tr><td class="vs-mut">—</td></tr>
                @endforelse
            </table>
            @if (\App\Filament\Pages\LiveDesk::canAccess())
                <div style="margin-top:8px" class="vs-mut">برای دیدن تک‌تک بازدیدکننده‌ها و پیام دادن به آن‌ها: <a href="{{ \App\Filament\Pages\LiveDesk::getUrl() }}" style="color:rgb(var(--primary-600))">گفتگوی زنده</a></div>
            @endif
        </x-filament::section>
    </div>
@endif

</div>
</div>
</x-filament-panels::page>
