<x-filament-panels::page>
<div class="dk2" wire:ignore id="dk2" data-list="{{ route('admin.desk.list', ['hall' => $this->hall]) }}" data-hall="{{ $this->hall }}" data-base="{{ url('/admin-tools/desk') }}" data-csrf="{{ csrf_token() }}" data-open="{{ (int) request('t') }}">
    <aside class="dk2-side">
        <div data-ret></div>
        <div class="dk2-sh"><b>منتظر بررسی</b><em data-wait-n>۰</em><span class="dk2-live" data-live title="به‌روزرسانی خودکار"></span></div>
        <input type="search" class="dk2-q" data-q placeholder="جستجوی مشتری یا شماره سفارش" autocomplete="off">
        <div data-wait class="dk2-tasks"></div>
        <div class="dk2-sh dk2-sh2"><b>تأییدشده — ۳ روز اخیر</b></div>
        <div data-done class="dk2-tasks"></div>
    </aside>
    <section class="dk2-main" data-main>
        <div class="dk2-empty">
            <b>📋</b>
            <p>یک سفارش از ستون «منتظر بررسی» انتخاب کنید.</p>
            <small>بار جمع‌شده را روی میز بگذارید؛ هر کالا را با <b>بارکدخوان</b> اسکن کنید یا <b>بخشی از نام</b> را تایپ کنید و تعداد را تأیید کنید. در آخر «تأیید نهایی» و خروجی اکسل هلو.</small>
        </div>
    </section>
</div>

<style>
.dk2{display:grid;grid-template-columns:320px 1fr;gap:16px;align-items:start}
@media (max-width:1100px){.dk2{grid-template-columns:1fr}}
.dk2-side{background:#fff;border:1px solid rgb(0 0 0/.07);border-radius:16px;padding:12px;position:sticky;top:76px;max-height:calc(100vh - 100px);overflow:auto}
.dark .dk2-side,.dark .dk2-card,.dark .dk2-head,.dark .dk2-row{background:rgb(var(--gray-900));border-color:rgb(255 255 255/.1)}
.dk2-sh{display:flex;align-items:center;gap:8px;font-size:14px;margin:2px 2px 8px}
.dk2-sh em{font-style:normal;background:#f59e0b;color:#fff;border-radius:999px;padding:0 9px;font-weight:800;font-size:12px}
.dk2-sh2{margin-top:16px;color:#64748b}
.dk2-live{width:8px;height:8px;border-radius:50%;background:#16a34a;margin-inline-start:auto}
.dk2-live.off{background:#dc2626}
.dk2-q{width:100%;height:38px;border:1px solid rgb(0 0 0/.12);border-radius:10px;padding:0 10px;margin-bottom:10px;background:transparent}
.dk2-tasks{display:grid;gap:8px}
.dk2-ret{background:#fef2f2;border:2px solid #dc2626;border-radius:14px;padding:10px;margin-bottom:14px;display:grid;gap:8px}
.dark .dk2-ret{background:rgb(127 29 29/.25)}
.dk2-ret>b{color:#b91c1c;font-size:14px;display:flex;align-items:center;gap:6px}
.dk2-ret>b em{font-style:normal;background:#dc2626;color:#fff;border-radius:999px;padding:0 9px;font-size:12px;margin-inline-start:auto}
.dk2-rcard{background:#fff;border:1.5px solid rgb(220 38 38/.35);border-radius:12px;padding:9px 10px;cursor:pointer;display:grid;gap:3px}
.dark .dk2-rcard{background:rgb(var(--gray-900))}
.dk2-rcard.on{outline:3px solid #dc2626}
.dk2-rcard small{color:#64748b}
.dk2-rv{background:#fff;border:3px solid #dc2626;border-radius:18px;padding:22px;display:grid;gap:14px}
.dark .dk2-rv{background:rgb(var(--gray-900))}
.dk2-rv h2{margin:0;font-size:22px;font-weight:900;color:#b91c1c}
.dk2-rv .dk2-rmeta{display:flex;flex-wrap:wrap;gap:8px}
.dk2-rv table{width:100%;border-collapse:collapse;font-size:14px}
.dk2-rv td{padding:7px 6px;border-bottom:1px dashed rgb(0 0 0/.12)}
.dk2-rv td:last-child{text-align:left;font-weight:800;white-space:nowrap}
.dk2-rv tr.maybe td{color:#94a3b8}
.dk2-rv .dk2-rbtn{height:58px;border-radius:14px;border:0;background:#dc2626;color:#fff;font-size:18px;font-weight:900;cursor:pointer}
.dk2-rv .dk2-rbtn.arm{background:#7f1d1d}
.dk2-rv .dk2-holoo{background:#fff7ed;border:1px solid #fdba74;color:#9a3412;border-radius:10px;padding:8px 12px;font-size:13px}
.dk2-card{display:block;width:100%;text-align:right;border:1.5px solid rgb(0 0 0/.08);border-radius:12px;padding:9px 11px;background:#fff;cursor:pointer;font-size:13px;line-height:1.8}
.dk2-card:hover{border-color:rgb(var(--primary-500))}
.dk2-card.on{border-color:rgb(var(--primary-600));box-shadow:0 0 0 3px rgb(var(--primary-500)/.15)}
.dk2-card b{font-size:14px}.dk2-card small{display:block;color:#64748b}
.dk2-card .dk2-x{display:flex;gap:6px;flex-wrap:wrap;margin-top:4px}
.dk2-card a{color:rgb(var(--primary-600));font-weight:800}
.dk2-chip{display:inline-block;border-radius:999px;padding:0 8px;font-size:11.5px;font-weight:800;background:#f1f5f9;color:#475569}
.dk2-chip.ok{background:#dcfce7;color:#166534}button.dk2-vf{border:1px solid transparent;cursor:pointer;font:inherit;font-size:11.5px;font-weight:800}button.dk2-vf.on{border-color:currentColor;box-shadow:0 0 0 2px rgba(15,23,42,.08)}.dk2-chip.bad{background:#fee2e2;color:#991b1b}.dk2-chip.warn{background:#fef3c7;color:#92400e}
.dk2-empty{background:#fff;border:1px dashed rgb(0 0 0/.15);border-radius:16px;padding:60px 20px;text-align:center;color:#64748b}
.dark .dk2-empty{background:transparent}
.dk2-empty b{font-size:40px;display:block}
.dk2-head{background:#fff;border:1px solid rgb(0 0 0/.07);border-radius:16px;padding:14px 16px;display:grid;gap:10px;position:sticky;top:64px;z-index:5}
.dk2-ttl{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
.dk2-ttl h2{font-size:18px;font-weight:900;margin:0}
.dk2-ttl a{color:rgb(var(--primary-600));font-weight:700;font-size:13px}
.dk2-meta{display:flex;flex-wrap:wrap;gap:6px 14px;font-size:13px;color:#64748b}
.dk2-scan{display:flex;gap:8px}
.dk2-scan input{flex:1;height:52px;border-radius:12px;border:2px solid rgb(var(--primary-500));padding:0 14px;font-size:18px;font-weight:700;background:transparent}
.dk2-prog{height:10px;border-radius:999px;background:#e2e8f0;overflow:hidden}
.dk2-prog i{display:block;height:100%;background:#16a34a;transition:width .3s}
.dk2-sum{display:flex;gap:8px;flex-wrap:wrap;font-size:13px}
.dk2-items{display:grid;gap:8px;margin-top:12px}
.dk2-grp{font-weight:900;color:#64748b;font-size:13px;margin:8px 4px 0}
.dk2-row{display:grid;grid-template-columns:52px 1fr auto auto;gap:12px;align-items:center;background:#fff;border:2px solid rgb(0 0 0/.06);border-radius:14px;padding:8px 12px}
.dk2-row img,.dk2-row .dk2-noimg{width:52px;height:52px;border-radius:10px;object-fit:cover;background:#f1f5f9}
.dk2-row.ok{border-color:#16a34a;background:#f0fdf4}.dk2-row.short{border-color:#f59e0b;background:#fffbeb}.dk2-row.miss{border-color:#dc2626;background:#fef2f2}
.dark .dk2-row.ok{background:rgb(22 163 74/.12)}.dark .dk2-row.short{background:rgb(245 158 11/.12)}.dark .dk2-row.miss{background:rgb(220 38 38/.12)}
.dk2-row.hit{box-shadow:0 0 0 4px rgb(var(--primary-500)/.35)}
.dk2-row.dim{opacity:.35}
.dk2-nm b{display:block;font-size:14.5px}.dk2-nm small{color:#64748b;font-size:12.5px}
.dk2-want{text-align:center;font-size:12.5px;color:#64748b;min-width:120px}.dk2-want b{display:block;font-size:15px;color:inherit}
.dk2-ctl{display:flex;align-items:center;gap:6px}
.dk2-ctl input{width:84px;height:40px;border-radius:10px;border:1.5px solid rgb(0 0 0/.15);text-align:center;font-weight:900;font-size:17px;background:transparent}
.dk2-ctl button{height:40px;min-width:40px;border-radius:10px;border:0;font-weight:900;padding:0 10px;background:#f1f5f9;cursor:pointer}
.dark .dk2-ctl button{background:rgb(255 255 255/.08)}
.dk2-ctl .y{background:#16a34a;color:#fff}.dk2-ctl .n{background:#dc2626;color:#fff}
.dk2-ctl .d{background:#fff1f2;color:#9f1239}
.dk2-fix{display:block;margin:4px auto 0;border:1.5px solid rgb(0 0 0/.15);background:transparent;border-radius:8px;padding:1px 10px;font-size:12px;font-weight:800;cursor:pointer;color:rgb(var(--primary-600))}
.dk2-fix:hover{background:rgb(var(--primary-500)/.1)}
.dk2-foot{position:sticky;bottom:0;margin-top:14px;background:rgb(var(--gray-50));padding:10px 0;display:flex;gap:10px;justify-content:flex-end;align-items:center}
.dark .dk2-foot{background:rgb(var(--gray-950))}
.dk2-btn{height:48px;border-radius:12px;border:0;padding:0 20px;font-weight:900;cursor:pointer;background:#e2e8f0}
.dk2-btn.pri{background:#16a34a;color:#fff;font-size:16px}
.dk2-btn.ghost{background:transparent;border:1.5px solid rgb(0 0 0/.15)}
.dk2-done{background:#fff;border:2px solid #16a34a;border-radius:16px;padding:40px 20px;text-align:center}
.dark .dk2-done{background:rgb(var(--gray-900))}
.dk2-done>b{font-size:44px;display:block}
.dk2-done .dk2-btn{margin:8px}
.dk2-alarm{position:fixed;inset:auto 50% 40px auto;transform:translateX(50%);z-index:60;padding:16px 26px;border-radius:16px;font-weight:900;font-size:17px;color:#fff;box-shadow:0 20px 50px -10px rgba(0,0,0,.5);text-align:center;max-width:90vw}
.dk2-alarm.bad{background:#dc2626}.dk2-alarm.warn{background:#d97706}.dk2-alarm.ok{background:#16a34a}
.dk2-alarm small{display:block;font-weight:600;font-size:13px;opacity:.9}
.dk2-modal{position:fixed;inset:0;background:rgba(15,23,42,.5);z-index:70;display:grid;place-items:center;padding:16px}
.dk2-modal>div{background:#fff;border-radius:18px;padding:20px;max-width:520px;width:100%;display:grid;gap:10px}
.dark .dk2-modal>div{background:rgb(var(--gray-900))}
.dk2-modal h3{font-weight:900;font-size:17px;margin:0}
.dk2-modal ul{max-height:240px;overflow:auto;font-size:13px;margin:0;padding-inline-start:18px}
.dk2-tabs{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}
.dk2-tabs button{border:1.5px solid rgb(0 0 0/.12);background:transparent;border-radius:999px;padding:5px 12px;font-weight:800;font-size:13px;cursor:pointer}
.dk2-tabs button.on{background:rgb(var(--primary-600));border-color:rgb(var(--primary-600));color:#fff}
.dk2-tabs button em{font-style:normal;margin-inline-start:6px;background:rgb(0 0 0/.1);border-radius:999px;padding:0 7px;font-size:11.5px}
.dk2-whb{display:inline-block;background:rgb(var(--primary-600));color:#fff;border-radius:999px;padding:1px 10px;font-size:12.5px;font-weight:800}
.dk2-add{display:flex;gap:8px;position:relative}
.dk2-add input{flex:1;height:40px;border-radius:10px;border:1.5px dashed rgb(0 0 0/.25);padding:0 12px;background:transparent}
.dk2-res{position:absolute;top:44px;inset-inline:0;z-index:20;background:#fff;border:1px solid rgb(0 0 0/.12);border-radius:12px;box-shadow:0 20px 40px -12px rgba(0,0,0,.35);max-height:320px;overflow:auto}
.dark .dk2-res{background:rgb(var(--gray-900))}
.dk2-res .p{display:flex;gap:10px;align-items:center;padding:8px 10px;border-bottom:1px solid rgb(0 0 0/.06)}
.dk2-res .p img,.dk2-res .p .dk2-noimg{width:40px;height:40px;border-radius:8px;object-fit:cover;background:#f1f5f9}
.dk2-res .p span{flex:1;font-size:13px}.dk2-res .p small{display:block;color:#64748b}
.dk2-res .p input{width:70px;height:34px;border-radius:8px;border:1px solid rgb(0 0 0/.2);text-align:center;background:transparent}
.dk2-res .p button{height:34px;border-radius:8px;border:0;background:#16a34a;color:#fff;font-weight:800;padding:0 10px;cursor:pointer}
.dk2-row.added{border-style:dashed}
.dk2-tbl{width:100%;border-collapse:collapse;margin-top:14px;font-size:13px;text-align:right}
.dk2-tbl th,.dk2-tbl td{border-bottom:1px solid rgb(0 0 0/.08);padding:6px 8px}
.dk2-tbl th{color:#64748b;font-size:12px}
.dk2-tbl tfoot td{font-weight:900;font-size:15px}
.dk2-pk{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.dk2-pk label{display:grid;gap:4px;font-weight:800;font-size:13px}
.dk2-pk input{height:44px;border-radius:10px;border:1.5px solid rgb(0 0 0/.18);text-align:center;font-size:18px;font-weight:900;background:transparent}
.dk2-packbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;border-top:1px dashed rgb(0 0 0/.12);padding-top:10px;font-size:13px}
.dk2-packbar .dk2-btn{height:40px;padding:0 14px}
.dk2-packbar .dk2-btn:disabled{opacity:.45;cursor:default}
.dk2-net{position:fixed;top:72px;left:50%;transform:translateX(-50%);z-index:60;max-width:min(440px,calc(100vw - 28px));padding:9px 14px;border-radius:14px;font-size:13px;font-weight:800;line-height:1.7;box-shadow:0 8px 24px rgb(0 0 0 / .18)}
.dk2-net.q{background:#fef3c7;color:#92400e}.dk2-net.off{background:#991b1b;color:#fff}.dk2-net.ok{background:#dcfce7;color:#166534}
.dk2-net small{display:block;font-weight:600;opacity:.9}
</style>

<script>
(function () {
	var root = document.getElementById('dk2'); if (!root || root.dataset.ready) return; root.dataset.ready = '1';
	var FA = '۰۱۲۳۴۵۶۷۸۹';
	function fa(v) { return String(v).replace(/[0-9]/g, function (d) { return FA[d]; }); }
	function en(v) { return String(v || '').replace(/[۰-۹]/g, function (d) { return FA.indexOf(d); }).replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }); }
	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
	function $(s, r) { return (r || root).querySelector(s); }
	var base = root.dataset.base, csrf = root.dataset.csrf, list = { wait: [], done: [], whs: [] }, st = null, q = '', lastId = null, filter = '', wsel = '', vf = '';
	wsel = root.dataset.hall || '';
	function post(url, data) {
		var fd = new FormData(); Object.keys(data || {}).forEach(function (k) { if (data[k] !== undefined && data[k] !== null) fd.append(k, data[k]); });
		return fetch(url, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-TOKEN': csrf, Accept: 'application/json' } }).then(function (r) { return r.json().catch(function () { return { ok: false, msg: 'خطای سرور (' + r.status + ')' }; }); });
	}
	function get(url) { return fetch(url + (url.indexOf('?') < 0 ? '?' : '&') + '_=' + Date.now(), { credentials: 'same-origin', headers: { Accept: 'application/json' } }).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }); }
	var actx;
	function beep(bad) {
		try {
			actx = actx || new (window.AudioContext || window.webkitAudioContext)();
			(bad ? [[220, 0, .2], [180, .22, .3]] : [[1320, 0, .09]]).forEach(function (s) {
				var o = actx.createOscillator(), g = actx.createGain(); o.type = bad ? 'square' : 'sine'; o.frequency.value = s[0];
				g.gain.setValueAtTime(.0001, actx.currentTime + s[1]); g.gain.exponentialRampToValueAtTime(.3, actx.currentTime + s[1] + .02); g.gain.exponentialRampToValueAtTime(.0001, actx.currentTime + s[1] + s[2]);
				o.connect(g); g.connect(actx.destination); o.start(actx.currentTime + s[1]); o.stop(actx.currentTime + s[1] + s[2] + .05);
			});
		} catch (e) {}
	}
	var alarmT;
	function alarm(kind, title, text) {
		var a = document.querySelector('.dk2-alarm'); if (!a) { a = document.createElement('div'); a.className = 'dk2-alarm'; document.body.appendChild(a); a.addEventListener('click', function () { a.hidden = true; }); }
		a.className = 'dk2-alarm ' + kind; a.innerHTML = esc(title) + (text ? '<small>' + esc(text) + '</small>' : ''); a.hidden = false;
		if (kind !== 'ok') beep(true);
		clearTimeout(alarmT); alarmT = setTimeout(function () { a.hidden = true; }, kind === 'ok' ? 1600 : 3500);
	}
	function lbl(i, u) {
		if (u == null) return '—';
		return i.carton && u > 0 && u % i.per === 0 ? fa(u / i.per) + ' کارتن <small>(' + fa(u) + ' عدد)</small>' : fa(u) + ' عدد';
	}

	/* ---------- ستون صف ---------- */
	function card(t, done) {
		return '<div class="dk2-card' + (st && st.id === t.id ? ' on' : '') + '" data-open="' + t.id + '"><b>' + esc(t.order) + ' — ' + esc(t.name) + '</b>'
			+ '<small>🏬 ' + esc(t.hallName || '') + ' · ' + esc(t.whs || t.keeper) + ' · ' + fa(t.items) + ' قلم' + ((t.pickers || t.picker) ? ' · جمع‌کننده: ' + esc(t.pickers || t.picker) : '') + '</small>'
			+ '<div class="dk2-x">' + (done ? '<span class="dk2-chip ok">✓ ' + esc(t.checker || '') + ' ' + esc(t.checkedAgo || '') + '</span>' + (t.pack ? '<span class="dk2-chip">📦 ' + esc(t.pack) + '</span>' : '') + '<a href="' + esc(t.holoo) + '" target="_blank" data-stop>⬇ اکسل</a><a href="' + esc(t.print) + '" target="_blank" data-stop>📄 PDF</a>'
				: (t.bay ? '<span class="dk2-chip">📍 ' + esc(t.bay) + '</span>' : '') + '<span class="dk2-chip warn">' + esc(t.ago || '') + '</span>' + (t.waitFor ? '<span class="dk2-chip bad">⏳ منتظر ' + esc(t.waitFor) + '</span>' : '') + (t.prev ? '<span class="dk2-chip warn">بررسی تکمیلی (کالای افزوده بعدی)</span>' : '') + (t.rechecks && !done ? '<span class="dk2-chip bad">✏️ ویرایش پس از تأیید</span>' : '')) + '</div></div>';
	}
	function m(t) { return (!wsel || t.hall === wsel) && (!q || (t.search || '').indexOf(q) >= 0); }
	function renderTabs() { return;
		var whs = list.whs || [];
		$('[data-whtabs]').innerHTML = whs.length ? '<button type="button" data-wsel="" class="' + (!wsel ? 'on' : '') + '">همه<em>' + fa(list.wait.length) + '</em></button>' + whs.map(function (w) {
			var n = list.wait.filter(function (t) { return t.hall === w.id; }).length;
			return '<button type="button" data-wsel="' + w.id + '" class="' + (wsel === w.id ? 'on' : '') + '">' + esc(w.name) + '<em>' + fa(n) + '</em></button>';
		}).join('') : '';
	}
	function retCard(r) {
		return '<div class="dk2-rcard' + (rv && rv.id === r.id ? ' on' : '') + '" data-ropen="' + r.id + '"><b>⛔ ' + esc(r.order) + ' — ' + esc(r.name) + '</b><small>' + esc(r.state) + (r.bay ? ' · 📍 ' + esc(r.bay) : '') + (r.pack ? ' · 📦 ' + esc(r.pack) : '') + ' · ' + fa(r.items.length) + ' قلم · لغو ' + esc(r.ago || '') + '</small></div>';
	}
	function renderRet() {
		var rs = (list.ret || []);
		$('[data-ret]').innerHTML = rs.length ? '<div class="dk2-ret"><b>⛔ لغو شد — به انبار برگردانید<em>' + fa(rs.length) + '</em></b>' + rs.map(retCard).join('') + '</div>' : '';
	}
	var rv = null, rArm = 0;
	function retView(r) {
		rv = r; st = null;
		var maybe = r.items.some(function (i) { return !i.sure; });
		main.innerHTML = '<div class="dk2-rv"><h2>⛔ سفارش ' + esc(r.order) + ' لغو شد</h2>'
			+ '<p style="margin:0;font-size:15px"><b>' + esc(r.name) + '</b>' + (r.city ? ' — ' + esc(r.city) : '') + ' · لغو ' + esc(r.ago || '') + (r.reason ? '<br><small style="color:#64748b">علت: ' + esc(r.reason) + '</small>' : '') + '</p>'
			+ '<div class="dk2-rmeta"><span class="dk2-chip bad">' + esc(r.state) + '</span>' + (r.bay ? '<span class="dk2-chip">📍 جایگاه: ' + esc(r.bay) + '</span>' : '') + (r.pack ? '<span class="dk2-chip">📦 ' + esc(r.pack) + '</span>' : '') + (r.picker ? '<span class="dk2-chip">👤 ' + esc(r.picker) + '</span>' : '') + '</div>'
			+ '<p style="margin:0;font-weight:800">این بار را ارسال نکنید. ' + (r.pack ? 'بسته‌ها را باز کنید و ' : '') + 'اقلام زیر را به قفسه برگردانید، بعد دکمه پایین را بزنید.</p>'
			+ (r.holoo ? '<div class="dk2-holoo">فاکتور هلوی این سفارش گرفته شده؛ به حسابداری بگویید در هلو برگشت بزند.</div>' : '')
			+ '<table>' + r.items.map(function (i) { return '<tr' + (i.sure ? '' : ' class="maybe"') + '><td>' + esc(i.name) + (i.code ? ' <small style="color:#94a3b8">' + esc(i.code) + '</small>' : '') + '</td><td>' + esc(i.qty) + (i.sure ? '' : ' ؟') + '</td></tr>'; }).join('') + '</table>'
			+ (maybe ? '<small style="color:#64748b">ردیف‌های کم‌رنگ «؟» هنوز تأیید نشده بودند؛ اگر روی میز هستند برگردانید.</small>' : '')
			+ '<button type="button" class="dk2-rbtn" data-rdone="' + r.id + '">↩️ همه به انبار برگشت داده شد</button></div>';
		renderRet();
	}
	function renderList() {
		renderRet();
		renderTabs();
		$('[data-wait-n]').textContent = fa(list.wait.filter(m).length);
		$('[data-wait]').innerHTML = list.wait.filter(m).map(function (t) { return card(t, false); }).join('') || '<small style="color:#64748b">باری منتظر بررسی نیست ✅</small>';
		$('[data-done]').innerHTML = list.done.filter(m).map(function (t) { return card(t, true); }).join('') || '<small style="color:#64748b">—</small>';
	}
	function loadList() {
		return get(root.dataset.list).then(function (j) {
			var before = list.wait.map(function (t) { return t.id; });
			var rBefore = (list.ret || []).map(function (r) { return r.id; }), firstLoad = !list.loaded;
			j.ret = j.ret || []; j.loaded = true;
			list = j; renderList(); $('[data-live]').classList.remove('off');
			var rNew = j.ret.filter(function (r) { return rBefore.indexOf(r.id) < 0; });
			if (!firstLoad && rNew.length) alarm('bad', '⛔ سفارش ' + rNew.map(function (r) { return r.order; }).join('، ') + ' لغو شد', 'این بار را ارسال نکنید؛ کالاها را به انبار برگردانید.');
			// همین بار روی میز باز است و سفارش لغو شد ← صفحه برگشت
			if (st) { var hit = j.ret.filter(function (r) { return r.id === st.id; })[0]; if (hit) retView(hit); else if (!st.done && !j.wait.some(function (t) { return t.id === st.id; })) open(st.id); }
			if (rv && !j.ret.some(function (r) { return r.id === rv.id; })) { rv = null; main.innerHTML = '<div class="dk2-empty"><b>↩️</b><p>برگشت این بار ثبت شده است.</p></div>'; }
			var fresh = j.wait.filter(function (t) { return before.indexOf(t.id) < 0 && (!wsel || t.hall === wsel); });
			if (before.length && fresh.length) alarm('ok', '📦 بار تازه برای بررسی: سفارش ' + fresh.map(function (t) { return t.order; }).join('، '));
		}).catch(function () { $('[data-live]').classList.add('off'); });
	}
	$('[data-q]').addEventListener('input', function (e) { q = en(e.target.value.trim()).toLowerCase(); renderList(); });
	root.addEventListener('click', function (e) {
		if (e.target.closest('[data-stop]')) return;
		var ws = e.target.closest('[data-wsel]'); if (ws) { wsel = ws.dataset.wsel; try { localStorage.setItem('dk2-hall', wsel); } catch (x) {} renderList(); return; }
		var c = e.target.closest('[data-open]'); if (c && c.classList.contains('dk2-card')) open(+c.dataset.open);
		var ro = e.target.closest('[data-ropen]'); if (ro) { var r = (list.ret || []).filter(function (x) { return x.id === +ro.dataset.ropen; })[0]; if (r) retView(r); }
	});

	/* ---------- بررسی یک سفارش ---------- */
	var main = $('[data-main]');
	function open(id) {
		get(base + '/' + id).then(function (j) {
			if (j.cancelled) { if (j.cancelled.done) { st = null; main.innerHTML = '<div class="dk2-empty"><b>⛔</b><p>سفارش ' + esc(j.cancelled.order) + ' لغو شد.</p><small>' + esc(j.cancelled.msg || '') + '</small></div>'; } else retView(j.cancelled); return; }
			rv = null;
			st = j; lastId = null; filter = ''; vf = ''; renderTask(); renderList(); try { history.replaceState(null, '', '?t=' + id); } catch (e) {}
			// سالن شمارشی: بررسی نیمه‌کاره (قطعی برق، ذخیره موقت) ← ادامه یا از اول
			var done = st.items.filter(function (i) { return i.desk != null && !i.added; }).length;
			if (!st.done && st.mode === 'count' && done) {
				var d = modal('<h3>این بررسی نیمه‌کاره است</h3><p>' + fa(done) + ' قلم از ' + fa(st.items.length) + ' قلم قبلاً تأیید شده' + (st.packs.length ? ' و ' + fa(st.packs.length) + ' کیسه/کارتن بسته شده' : '') + '.</p>'
					+ '<button type="button" class="dk2-btn pri" data-x>▶ ادامه بررسی</button><button type="button" class="dk2-btn" data-reset style="background:#fee2e2;color:#991b1b">↺ شروع از اول</button>');
				d.querySelector('[data-reset]').addEventListener('click', function () {
					if (!confirm('همه تأییدها و کیسه‌های این بررسی پاک شود و از اول شروع کنید؟')) return;
					packAct({ act: 'reset' }, 'بررسی از اول شروع شد'); d.remove();
				});
			}
		})
			.catch(function () { alarm('bad', 'باز نشد؛ دوباره امتحان کنید'); });
	}
	function cls(i) { if (i.desk == null) return ''; return i.desk >= i.target && i.desk > 0 ? 'ok' : i.desk === 0 ? 'miss' : 'short'; }
	function row(i) {
		var dim = filter && (i.name.toLowerCase().indexOf(filter) < 0 && !i.codes.some(function (c) { return c.toLowerCase().indexOf(filter) >= 0; }));
		return '<div class="dk2-row ' + cls(i) + (i.added ? ' added' : '') + (i.id === lastId ? ' hit' : '') + (dim ? ' dim' : '') + '" data-iid="' + i.id + '">'
			+ (i.img ? '<img src="' + esc(i.img) + '" alt="" loading="lazy">' : '<span class="dk2-noimg"></span>')
			+ '<div class="dk2-nm"><b>' + (i.added ? '➕ ' : '') + esc(i.name) + '</b><small>' + (i.added ? 'افزوده بررسی‌کننده · ' : '') + (i.code ? esc(i.code) + ' · ' : '') + (i.carton ? 'کارتن ' + fa(i.per) + 'تایی' : 'عددی/تکی') + (i.note ? ' · 📝 ' + esc(i.note) : '') + (i.pack ? ' · <b style="color:#7c3aed">📦 ' + esc(packName(i.pack)) + '</b>' : '') + '</small></div>'
			+ '<div class="dk2-want">جمع‌کننده<b>' + (i.target === 0 ? 'ناموجود' : lbl(i, i.target)) + '</b>' + (i.target !== i.want ? '<small>سفارش: ' + fa(i.want) + ' عدد</small>' : '') + '<button type="button" class="dk2-fix" data-fix title="اصلاح تعداد جمع‌شده توسط جمع‌کننده">✎ اصلاح</button></div>'
			+ '<div class="dk2-ctl"><button type="button" class="y" data-full title="همه موجود است">✓</button><input type="text" inputmode="numeric" data-units value="' + (i.desk == null ? '' : fa(i.desk)) + '" placeholder="عدد"><button type="button" class="n" data-zero title="ناموجود">✗</button><button type="button" data-clear title="برداشتن">↺</button><button type="button" class="d" data-del title="حذف این قلم از بررسی و فاکتور">🗑</button></div></div>';
	}
	function packName(n) { var p = (st.packs || []).filter(function (x) { return x.n === n; })[0]; return p ? p.name : 'بسته ' + fa(n); }
	function matches(i) { return !filter || i.name.toLowerCase().indexOf(filter) >= 0 || i.codes.some(function (c) { return c.toLowerCase().indexOf(filter) >= 0; }); }
	function packBar() {
		var el = $('[data-packbar]', main); if (!el) return;
		var loose = st.items.filter(function (i) { return i.desk != null && i.desk > 0 && !i.pack; }).length, next = (st.packs || []).length + 1;
		el.innerHTML = '<span>بیرون از بسته: <b>' + fa(loose) + '</b> قلم تأییدشده</span>'
			+ '<button type="button" class="dk2-btn pri" data-pack="bag"' + (loose ? '' : ' disabled') + '>👜 بستن کیسه ' + fa(next) + '</button>'
			+ '<button type="button" class="dk2-btn" data-pack="box"' + (loose ? '' : ' disabled') + '>📦 بستن کارتن ' + fa(next) + '</button>'
			+ (st.packs || []).map(function (p) { return '<span class="dk2-chip">' + (p.type === 'box' ? '📦 ' : '👜 ') + esc(p.name) + ' · ' + fa(st.items.filter(function (i) { return i.pack === p.n; }).length) + ' قلم</span>'; }).join('')
			+ ((st.packs || []).length ? '<button type="button" class="dk2-btn ghost" data-unpack title="برداشتن آخرین بسته">↶ باز کردن آخرین بسته</button>' : '');
	}
	function packAct(data, okMsg) {
		post(base + '/' + st.id + '/pack', data).then(function (j) {
			if (!j.ok) { alarm('bad', j.msg || 'انجام نشد'); return; }
			st = j.state; renderTask(); if (okMsg) alarm('ok', okMsg);
		}).catch(function () { alarm('bad', 'اتصال برقرار نشد'); });
	}
	function counts() {
		var c = { all: st.items.length, ok: 0, short: 0, miss: 0, left: 0 };
		st.items.forEach(function (i) { var k = cls(i); if (!k) c.left++; else c[k]++; });
		return c;
	}
	function renderItems() {
		applyQ();
		var h = '', lastWh = null;
		if (st.mode === 'count' && filter) {
			// سالن شمارشی: کالای پیدا شده بالا، بقیه کم‌رنگ
			var hit = st.items.filter(matches), rest = st.items.filter(function (i) { return !matches(i); });
			h = '<div class="dk2-grp">🔎 پیدا شد: ' + fa(hit.length) + '</div>' + hit.map(row).join('') + (rest.length ? '<div class="dk2-grp">بقیه اقلام</div>' + rest.map(row).join('') : '');
		} else if (vf) {
			// فیلتر: «مانده برای بررسی» یا «بررسی شده‌ها»
			var vis = st.items.filter(function (i) { return vf === 'done' ? i.desk != null : i.desk == null; });
			h = '<div class="dk2-grp">' + (vf === 'done' ? '✔ بررسی شده‌ها' : '⏳ مانده برای بررسی') + ': ' + fa(vis.length) + ' قلم' + (vf === 'done' ? ' — ' + fa(vis.reduce(function (a, i) { return a + (+i.desk || 0); }, 0)) + ' عدد اسکن‌شده' : '') + ' <button type="button" class="dk2-btn ghost" data-vf="" style="padding:2px 10px;font-size:12px;margin-inline-start:8px">نمایش همه</button></div>';
			vis.forEach(function (i) { if (i.wh !== lastWh) { h += '<div class="dk2-grp">' + esc(i.wh) + '</div>'; lastWh = i.wh; } h += row(i); });
			if (!vis.length) h += '<div style="padding:18px;text-align:center;color:#64748b">' + (vf === 'done' ? 'هنوز قلمی بررسی نشده.' : 'همه اقلام بررسی شده‌اند ✅') + '</div>';
		} else {
			st.items.forEach(function (i) { if (i.wh !== lastWh) { h += '<div class="dk2-grp">' + esc(i.wh) + '</div>'; lastWh = i.wh; } h += row(i); });
		}
		$('[data-items]', main).innerHTML = h;
		packBar();
		var c = counts();
		$('[data-prog]', main).style.width = (c.all ? Math.round((c.all - c.left) / c.all * 100) : 0) + '%';
		$('[data-sum]', main).innerHTML = '<span class="dk2-chip">' + fa(c.all) + ' قلم</span><span class="dk2-chip ok">موجود: ' + fa(c.ok) + '</span><span class="dk2-chip warn">کمتر: ' + fa(c.short) + '</span><span class="dk2-chip bad">ناموجود: ' + fa(c.miss) + '</span><button type="button" class="dk2-chip dk2-vf' + (vf === 'left' ? ' on' : '') + '" data-vf="left" title="فقط اقلامی که هنوز بررسی نشده">مانده برای بررسی: ' + fa(c.left) + '</button><button type="button" class="dk2-chip dk2-vf ok' + (vf === 'done' ? ' on' : '') + '" data-vf="done" title="فقط اقلامی که اسکن/بررسی شده‌اند">✔ بررسی شده‌ها: ' + fa(c.all - c.left) + ' قلم</button><span class="dk2-chip" style="background:#e0f2fe;color:#075985" title="جمع تعداد اسکن‌شده همه اقلام (مثلاً قلمی که ۶ عدد اسکن شده = ۶)">📦 جمع اسکن‌شده: ' + fa(st.items.reduce(function (a, i) { return a + (+i.desk || 0); }, 0)) + ' عدد</span>';
		if (st.mode === 'count' && filter) { window.scrollTo({ top: 0, behavior: 'smooth' }); }
		else if (lastId) { var el = main.querySelector('[data-iid="' + lastId + '"]'); if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
	}
	function renderTask() {
		if (st.done) { doneView(); return; }
		main.innerHTML = '<div class="dk2-head"><div class="dk2-ttl"><span class="dk2-whb">🏬 ' + esc(st.wh) + '</span><h2>سفارش ' + esc(st.order) + ' — ' + esc(st.name) + '</h2><a href="' + esc(st.orderUrl) + '" target="_blank">مشاهده سفارش ↗</a><a href="' + esc(st.print) + '" target="_blank">📄 پیش‌نمایش برگه</a></div>'
			+ '<div class="dk2-meta"><span>🏬 ' + esc(st.keeper) + '</span>' + (st.picker ? '<span>👤 جمع‌کننده: ' + esc(st.picker) + '</span>' : '') + (st.op ? '<span>🎧 کارشناس: ' + esc(st.op) + '</span>' : '') + (st.bay ? '<span>📍 ' + esc(st.bay) + '</span>' : '') + (st.city ? '<span>' + esc(st.city) + '</span>' : '') + (st.note ? '<span>📝 ' + esc(st.note) + '</span>' : '') + '</div>'
			+ (st.round > 1 ? '<div class="dk2-chip warn" style="font-size:13px;padding:6px 12px">🔁 بررسی تکمیلی مرحله ' + fa(st.round) + ': فقط اقلام افزوده/جایگزین مشتری (' + fa(st.items.length) + ' قلم). اقلام قبلی پیش‌تر بررسی و در هلو ثبت شده‌اند؛ اکسل این بررسی هم فقط همین اقلام است.</div>' : '')
			+ (st.waitFor ? '<div class="dk2-chip bad" style="font-size:13px;padding:6px 12px">⏳ ' + esc(st.waitFor) + ' هنوز جمع‌آوری همین سالن را تمام نکرده؛ اقلامش بعد از «پایان حواله» به همین بررسی اضافه می‌شود. بهتر است صبر کنید.</div>' : '')
			+ '<div class="dk2-scan"><input type="text" data-scan placeholder="' + (st.mode === 'count' ? 'بخشی از نام کالا را بنویسید (کالا خودش بالا می‌آید) یا بارکد را اسکن کنید' : 'بارکد را اسکن کنید یا بخشی از نام کالا را بنویسید و Enter بزنید') + '" autocomplete="off" spellcheck="false"></div>'
			+ '<div class="dk2-prog"><i data-prog></i></div><div class="dk2-sum" data-sum></div>'
			+ (st.mode === 'count' ? '<div class="dk2-packbar" data-packbar></div>' : '') + '</div>'
			+ '<div class="dk2-items" data-items></div>'
			+ '<div class="dk2-add" style="margin-top:12px"><input type="search" data-add-q placeholder="➕ افزودن کالای دیگر به سفارش (خارج از جمع‌شده‌های جمع‌کننده): نام یا بارکد" autocomplete="off"><div class="dk2-res" data-add-res hidden></div></div>'
			+ '<div class="dk2-foot"><span style="color:#64748b;font-size:13px">✓ = همه موجود · عدد = تعداد شمرده‌شده · ✗ = ناموجود</span>' + (st.mode === 'count' ? '<button type="button" class="dk2-btn ghost" data-tempsave>💾 ذخیره موقت</button>' : '') + '<button type="button" class="dk2-btn pri" data-approve>تأیید نهایی سفارش ✓</button></div>';
		renderItems();
		setTimeout(function () { var s = $('[data-scan]', main); if (s) s.focus(); }, 50);
	}
	function doneView(all) {
		var sum = 0, tc = 0, tu = 0, nf = function (v) { return fa(Number(v).toLocaleString('en')); }, pcol = (st.rows || []).some(function (r) { return r.packName; });
		var ccol = (st.rows || []).some(function (r) { return r.cartons; }); // سالن «۱ عدد در کارتن»: ستون کارتن (همه صفر) نشان داده نمی‌شود
		var tb = (st.rows || []).map(function (r, k) { sum += r.total; tc += r.cartons; tu += r.units; return '<tr><td>' + fa(k + 1) + '</td><td dir="ltr" style="text-align:right">' + esc(r.code) + '</td><td>' + esc(r.name) + '</td>' + (ccol ? '<td>' + (r.cartons ? fa(r.cartons) + ' × ' + fa(r.per) : '۰') + '</td>' : '') + '<td><b>' + fa(r.units) + '</b></td><td>' + nf(r.price) + '</td><td><b>' + nf(r.total) + '</b></td>' + (pcol ? '<td><b>' + esc(r.packName || '') + '</b></td>' : '') + '</tr>'; }).join('');
		main.innerHTML = '<div class="dk2-done"><b>✅</b><h2 style="font-size:20px;font-weight:900">سفارش ' + esc(st.order) + ' — ' + esc(st.wh) + ' تأیید شد</h2>'
			+ '<p style="color:#64748b">' + (all ? 'همه انبارهای این سفارش تمام شد؛ مشتری موجود/ناموجودها را می‌بیند و سفارش به کارشناس پیگیری رسید.' : (all === false ? 'کار شما با این بار تمام است ✅ اکسل هلو را بگیرید و سراغ سفارش بعدی بروید. (انبارهای دیگرِ همین سفارش جدا بررسی می‌شوند؛ لازم نیست منتظر بمانید.)' : 'بررسی این انبار ثبت شده است.')) + (st.pack ? '<br>📦 بسته‌بندی: <strong>' + esc(st.pack) + '</strong>' : '') + '</p>'
			+ '<a class="dk2-btn pri" style="display:inline-flex;align-items:center" href="' + esc(st.holoo) + '" target="_blank">⬇ اکسل هلو این انبار</a>'
			+ '<a class="dk2-btn" style="display:inline-flex;align-items:center" href="' + esc(st.print) + '" target="_blank">📄 PDF برای تطبیق با هلو</a>'
			+ '<button type="button" class="dk2-btn ghost" data-next>سفارش بعدی ←</button>'
			+ (st.reopenBlock ? '<small style="display:block;color:#64748b;margin-top:6px">✏️ ویرایش بررسی: ' + esc(st.reopenBlock) + '</small>'
				: st.reopenDirect ? '<div style="margin-top:10px;font-size:12.5px;color:#64748b">فقط اگر کالایی را اشتباه شمرده‌اید: <button type="button" data-reopen style="background:none;border:0;color:#92400e;font-weight:800;text-decoration:underline;cursor:pointer">✏️ ویرایش بررسی</button></div>'
				: st.reopenReq ? '<div class="dk2-chip warn" style="margin-top:8px;font-size:13px;padding:6px 12px">⏳ درخواست ویرایش (' + esc(st.reopenReq.why) + ') برای ' + esc(st.assignee || 'مسئول پیگیری') + ' فرستاده شد؛ پس از اجازه او، این سفارش دوباره در صف بررسی می‌آید.</div>'
				: '<div style="margin-top:10px;font-size:12.5px;color:#64748b">فقط اگر کالایی را اشتباه شمرده‌اید: <button type="button" data-reopen style="background:none;border:0;color:#92400e;font-weight:800;text-decoration:underline;cursor:pointer">✏️ درخواست ویرایش از مسئول پیگیری' + (st.assignee ? ' (' + esc(st.assignee) + ')' : '') + '</button></div>')
			+ (st.rechecks ? '<div class="dk2-chip warn" style="margin-top:8px;font-size:13px;padding:6px 12px">این بررسی ' + fa(st.rechecks) + ' بار ویرایش شده؛ اگر اکسل هلو را قبلاً گرفته‌اید، اکسل تازه را بگیرید و فاکتور هلو را اصلاح کنید.</div>' : '')
			+ '<table class="dk2-tbl"><thead><tr><th>#</th><th>کد کالا</th><th>کالا (همان ترتیب اکسل هلو)</th>' + (ccol ? '<th>کارتن</th>' : '') + '<th>تعداد</th><th>فی</th><th>مبلغ</th>' + (pcol ? '<th>نام کیسه</th>' : '') + '</tr></thead><tbody>' + tb + '</tbody>'
			+ '<tfoot><tr><td colspan="3">جمع (' + fa((st.rows || []).length) + ' ردیف) — باید با فاکتور هلو یکی باشد</td>' + (ccol ? '<td>' + fa(tc) + ' کارتن</td>' : '') + '<td>' + fa(tu) + ' عدد</td><td></td><td>' + nf(sum) + ' تومان</td>' + (pcol ? '<td></td>' : '') + '</tr></tfoot></table></div>';
	}
	/* ---------- اصلاح تعداد جمع‌شده / حذف قلم ---------- */
	function fixPicked(i) {
		var d = modal('<h3>اصلاح تعداد جمع‌شده</h3><p>' + esc(i.name) + '<br><small>سفارش مشتری: ' + lbl(i, i.want) + ' · ثبت جمع‌کننده: ' + (i.target === 0 ? 'ناموجود' : lbl(i, i.target)) + '</small></p>'
			+ '<label style="display:grid;gap:4px;font-weight:800;font-size:13px">تعداد درست (به عدد — سفارش ' + fa(i.want) + '؛ بیشتر هم مجاز)' + (i.carton ? ' — هر کارتن ' + fa(i.per) + ' عدد' : '') + '<input type="text" inputmode="numeric" data-fixv value="' + fa(i.target) + '" style="height:44px;border-radius:10px;border:1.5px solid rgba(0,0,0,.18);text-align:center;font-size:18px;font-weight:900;background:transparent"></label>'
			+ '<button type="button" class="dk2-btn pri" data-fixgo>ثبت اصلاح</button><button type="button" class="dk2-btn ghost" data-x>بازگشت</button>');
		var inp = d.querySelector('[data-fixv]');
		setTimeout(function () { inp.focus(); inp.select(); }, 50);
		function go() {
			var v = en(inp.value).replace(/\D/g, '');
			if (v === '') { alarm('bad', 'تعداد را بنویسید'); return; }
			if (i.max && +v > i.max) { alarm('bad', 'خیلی بیشتر از سفارش مشتری است', 'حداکثر ' + fa(i.max) + ' عدد'); return; }
			if (+v > i.want && !confirm('«' + i.name + '»: ' + fa(+v) + ' عدد بیشتر از سفارش مشتری (' + fa(i.want) + ' عدد) است — مثلاً کارتن کامل.\nثبت شود؟ (مبلغ فاکتور مشتری بیشتر می‌شود)')) return;
			var b = d.querySelector('[data-fixgo]'); b.disabled = true;
			post(base + '/' + st.id + '/item/' + i.id + '/picked', { units: v }).then(function (j) {
				d.remove();
				if (!j.ok) { alarm('bad', j.msg || 'اصلاح نشد'); return; }
				st = j.state; lastId = i.id; renderTask(); alarm('ok', '✓ تعداد جمع‌شده اصلاح شد');
			}).catch(function () { b.disabled = false; alarm('bad', 'اتصال برقرار نشد'); });
		}
		d.querySelector('[data-fixgo]').addEventListener('click', go);
		inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); go(); } });
	}
	function removeItem(i) {
		var msg = i.added ? 'کالای افزوده «' + i.name + '» از این بررسی و از سفارش حذف شود؟'
			: 'قلم «' + i.name + '» از بررسی رومیزی و از فاکتور مشتری حذف شود؟\n\nمشتری آن را «ناموجود» نمی‌بیند و جایگزین هم نمی‌تواند بگیرد؛ موجودی کالا به سایت برمی‌گردد و جمع فاکتور دوباره محاسبه می‌شود.\nاگر فقط کالا در انبار نبود، به‌جای حذف دکمه ✗ (ناموجود) را بزنید.';
		if (!confirm(msg)) return;
		post(base + '/' + st.id + '/item/' + i.id + '/remove', {}).then(function (j) {
			if (!j.ok) { alarm('bad', j.msg || 'حذف نشد'); return; }
			st = j.state; lastId = null; renderTask(); alarm('ok', '🗑 «' + i.name + '» حذف شد');
		}).catch(function () { alarm('bad', 'اتصال برقرار نشد'); });
	}
	function byId(id) { for (var k = 0; k < st.items.length; k++) if (st.items[k].id === id) return st.items[k]; return null; }

	/* ---------- کار بدون اینترنت: هر اسکن/تعداد اول همین‌جا (و در حافظه همین کامپیوتر) ثبت می‌شود و پشت صحنه به سرور می‌رود ---------- */
	var QK = 'dk2q', Q = {}, sending = false, netOff = false, sentAt = 0;
	try { Q = JSON.parse(localStorage.getItem(QK) || '{}') || {}; } catch (x) { Q = {}; }
	function qSave() { try { localStorage.setItem(QK, JSON.stringify(Q)); } catch (x) {} }
	function qCount(tid) { return Q[tid] ? Object.keys(Q[tid]).length : 0; }
	function qAll() { return Object.keys(Q).reduce(function (n, t) { return n + qCount(t); }, 0); }
	function qPut(tid, iid, v) { (Q[tid] = Q[tid] || {})[iid] = v === null ? '' : v; qSave(); netBadge(); flush(); }
	function applyQ() { if (!st || st.done || !Q[st.id]) return; var mq = Q[st.id]; st.items.forEach(function (i) { if (Object.prototype.hasOwnProperty.call(mq, i.id)) i.desk = mq[i.id] === '' ? null : +mq[i.id]; }); }
	function netBadge() {
		var n = qAll(), b = document.querySelector('.dk2-net');
		if (!b) { b = document.createElement('div'); b.className = 'dk2-net'; document.body.appendChild(b); }
		if (netOff) { b.className = 'dk2-net off'; b.innerHTML = '🔴 اینترنت قطع یا ضعیف است — کار را ادامه دهید' + '<small>' + (n ? fa(n) + ' ثبت در همین کامپیوتر نگه داشته شده و با وصل شدن اینترنت خودکار ارسال می‌شود. صفحه را نبندید.' : 'اسکن‌ها همین‌جا ثبت می‌شوند.') + '</small>'; b.hidden = false; return; }
		if (n) { b.className = 'dk2-net q'; b.innerHTML = '⏳ ارسال ' + fa(n) + ' ثبت به سرور…'; b.hidden = false; return; }
		if (Date.now() - sentAt < 2500) { b.className = 'dk2-net ok'; b.innerHTML = '✓ همه ثبت‌ها روی سرور ذخیره شد'; b.hidden = false; setTimeout(netBadge, 2600); return; }
		b.hidden = true;
	}
	function flush() {
		if (sending) return;
		var tid = Object.keys(Q).filter(function (t) { return qCount(t); })[0];
		if (!tid) { if (Object.keys(Q).length) { Q = {}; qSave(); } netBadge(); return; }
		var iid = Object.keys(Q[tid])[0], v = Q[tid][iid];
		sending = true;
		var fd = new FormData(); fd.append('units', v);
		var ctl = window.AbortController ? new AbortController() : null, to = setTimeout(function () { if (ctl) ctl.abort(); }, 12000);
		fetch(base + '/' + tid + '/item/' + iid, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-TOKEN': csrf, Accept: 'application/json' }, signal: ctl ? ctl.signal : undefined })
			.then(function (r) {
				clearTimeout(to);
				if (r.status >= 500 || r.status === 429 || r.status === 0) throw new Error('retry');
				if (r.status === 419 || r.status === 401) { sending = false; netOff = false; alarm('bad', 'نشست ورود تمام شده', 'یک بار دوباره وارد پنل شوید؛ ثبت‌های این صفحه در همین کامپیوتر نگه داشته شده و بعد از ورود ارسال می‌شود.'); netBadge(); return null; }
				return r.json().catch(function () { return { ok: false, msg: 'پاسخ نامعتبر سرور' }; }).then(function (j) {
					sending = false; netOff = false; sentAt = Date.now();
					if (j.cancelled) { delete Q[tid]; qSave(); alarm('bad', j.msg || 'سفارش لغو شد'); loadList(); netBadge(); flush(); return j; }
					if (Q[tid] && Q[tid][iid] === v) delete Q[tid][iid];
					if (Q[tid] && !qCount(tid)) delete Q[tid];
					qSave();
					if (!j.ok) alarm('bad', 'یک ثبت روی سرور انجام نشد', j.msg || '');
					else if (st && String(st.id) === String(tid) && !(Q[tid] && Object.prototype.hasOwnProperty.call(Q[tid], iid))) { var it = byId(+iid); if (it && it.desk !== j.desk) { it.desk = j.desk; renderItems(); } }
					netBadge(); flush();
					return j;
				});
			})
			.catch(function () { clearTimeout(to); sending = false; netOff = true; netBadge(); setTimeout(flush, 4000); });
	}
	window.addEventListener('online', function () { netOff = false; flush(); });
	window.addEventListener('offline', function () { netOff = true; netBadge(); });
	setInterval(function () { if (qAll()) flush(); }, 6000);
	function normCode(c) { c = en(c).replace(/\s+/g, '').toUpperCase(); return /^[0-9]+$/.test(c) ? (c.replace(/^0+/, '') || '0') : c; }
	/* اسکن روی همین کامپیوتر (همان قاعده سرور: هر اسکن یک کارتن برای کالای کارتنی، وگرنه یک عدد) */
	function localScan(code) {
		var c = normCode(code), hit = st.items.filter(function (i) { return i.codes.indexOf(c) >= 0; });
		if (!hit.length) return null;
		var it = hit.filter(function (i) { return (i.desk || 0) < i.target; })[0] || hit.filter(function (i) { return (i.desk || 0) < (i.cap || i.want); })[0] || hit[0];
		var now = it.desk || 0;
		if (now >= (it.cap || it.want)) return { type: 'extra', it: it };
		it.desk = Math.min(it.cap || it.want, now + (it.carton ? it.per : 1));
		qPut(st.id, it.id, it.desk);
		return { type: it.desk > it.target ? 'over' : 'ok', it: it };
	}
	/* شمارش میز بیشتر از گفته جمع‌کننده: تأیید بررسی‌کننده (اکسل هلو و PDF با همین شمارش میز ساخته می‌شود) */
	var overOk = {};
	function overAsk(it) {
		if (!st || overOk[st.id + ':' + it.id + ':' + it.desk]) return;
		var d = modal('<h3>⚠ تعداد بیشتر از گفته جمع‌کننده</h3><p style="line-height:2">«' + esc(it.name) + '»<br>جمع‌کننده گفته <b>' + (it.target === 0 ? 'ناموجود' : lbl(it, it.target)) + '</b> از <b>' + lbl(it, it.want) + '</b> داریم، ولی شما <b>' + lbl(it, it.desk) + '</b> شمردید.<br>تأیید می‌کنی که <b>' + lbl(it, it.desk) + '</b> درست است؟ (اکسل هلو و PDF با همین تعداد ساخته می‌شود)</p>'
			+ '<div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="dk2-btn pri" data-ov-yes>✓ بله، ' + lbl(it, it.desk) + ' درست است</button><button type="button" class="dk2-btn" data-ov-no>✗ نه، برگردان به ' + (it.target === 0 ? '۰' : lbl(it, it.target)) + '</button></div>');
		d.querySelector('[data-ov-yes]').addEventListener('click', function () { overOk[st.id + ':' + it.id + ':' + it.desk] = 1; d.remove(); var s = $('[data-scan]', main); if (s) s.focus(); });
		d.querySelector('[data-ov-no]').addEventListener('click', function () { d.remove(); setUnits(it, it.target); });
	}
	function setUnits(i, v) {
		i.desk = v; lastId = i.id;
		qPut(st.id, i.id, v);
		if (st.mode === 'count') { var sc = $('[data-scan]', main); if (sc) { sc.value = ''; filter = ''; sc.focus(); } }
		renderItems();
	}
	main.addEventListener('click', function (e) {
		var vb = e.target.closest('[data-vf]');
		if (vb && st && !st.done) { var nv = vb.getAttribute('data-vf'); vf = vf === nv ? '' : nv; renderItems(); return; }
		if (e.target.closest('[data-next]')) { st = null; main.innerHTML = ''; loadList().then(function () { if (list.wait.length) open(list.wait[0].id); else main.innerHTML = '<div class="dk2-empty"><b>✅</b><p>باری منتظر بررسی نیست.</p></div>'; }); return; }
		if (e.target.closest('[data-approve]')) { approve(); return; }
		if (e.target.closest('[data-reopen]')) { reopenTask(); return; }
		var pk = e.target.closest('[data-pack]'); if (pk) { packAct({ type: pk.dataset.pack }, '✓ ' + (pk.dataset.pack === 'box' ? 'کارتن' : 'کیسه') + ' بسته شد'); return; }
		if (e.target.closest('[data-unpack]')) { if (confirm('آخرین کیسه/کارتن باز شود؟ اقلامش دوباره «بیرون از بسته» می‌شوند.')) packAct({ act: 'undo' }, 'آخرین بسته باز شد'); return; }
		if (e.target.closest('[data-tempsave]')) {
			alarm('ok', '💾 ذخیره شد', 'هر وقت برگشتید همین سفارش را باز کنید و «ادامه» بزنید.');
			st = null; main.innerHTML = '<div class="dk2-empty"><b>💾</b><p>بررسی به‌صورت موقت ذخیره شد.</p><small>همه تأییدها روی سرور ثبت شده؛ با باز کردن دوباره همین سفارش، «ادامه بررسی» یا «شروع از اول» را انتخاب کنید.</small></div>';
			try { history.replaceState(null, '', location.pathname + '?hall=' + encodeURIComponent(root.dataset.hall || '')); } catch (x) {}
			renderList(); return;
		}
		var r = e.target.closest('[data-iid]'); if (!r || !st) return;
		var i = byId(+r.dataset.iid); if (!i) return;
		if (e.target.closest('[data-full]')) { beep(); setUnits(i, i.target); }
		else if (e.target.closest('[data-zero]')) { setUnits(i, 0); }
		else if (e.target.closest('[data-clear]')) { setUnits(i, null); }
		else if (e.target.closest('[data-fix]')) { fixPicked(i); }
		else if (e.target.closest('[data-del]')) { removeItem(i); }
	});
	main.addEventListener('keydown', function (e) {
		var u = e.target.closest('[data-units]');
		if (u && e.key === 'Enter') {
			e.preventDefault();
			var i = byId(+e.target.closest('[data-iid]').dataset.iid), v = en(u.value).replace(/\D/g, '');
			if (i) { setUnits(i, v === '' ? null : Math.min(i.cap || i.want, +v)); if (i.desk != null && i.desk > i.target) overAsk(i); }
			var s = $('[data-scan]', main); if (s) { s.value = ''; filter = ''; s.focus(); }
			return;
		}
		if (e.target.matches('[data-scan]') && e.key === 'Enter') {
			e.preventDefault();
			var code = en(e.target.value).trim(); if (!code) return;
			var low = code.toLowerCase();
			var exact = st.items.filter(function (i) { return i.codes.some(function (c) { return c.toLowerCase() === low || c.replace(/^0+/, '') === low.replace(/^0+/, ''); }); });
			var ls = localScan(code);
			if (ls) {
				e.target.value = ''; filter = ''; lastId = ls.it.id;
				if (ls.type === 'extra') alarm('warn', '⚠ بیشتر از سفارش مشتری', '«' + ls.it.name + '» اضافه است؛ کنار گذاشته شود.');
				else { beep(); if (ls.type === 'over') overAsk(ls.it); }
				renderItems();
				return;
			}
			if (exact.length || /^[0-9A-Za-z\-]{5,}$/.test(code)) {
				e.target.value = ''; filter = '';
				if (netOff) { alarm('bad', '✗ این کد در این حواله نیست', 'کد ' + fa(code) + ' — کنار بگذارید (اینترنت قطع است؛ نام کالا بعداً قابل بررسی است).'); return; }
				post(base + '/' + st.id + '/scan', { code: code }).then(function (j) {
					if (!j.ok) { alarm('bad', j.msg || 'ثبت نشد'); return; }
					if (j.type === 'notin') { alarm('bad', '✗ این کالا در این حواله نیست', (j.name ? '«' + j.name + '» — ' : '') + 'کنار بگذارید، یا اگر باید اضافه شود از کادر «افزودن کالای دیگر» اضافه کنید.'); var aq = $('[data-add-q]', main); if (aq) { aq.value = code; searchAdd(code); } return; }
					if (j.type === 'unknown') { alarm('bad', '✗ بارکد ناشناخته', 'کد ' + fa(code)); return; }
					var it = byId(j.itemId); if (it) it.desk = j.desk; lastId = j.itemId;
					if (j.type === 'extra') alarm('warn', '⚠ بیشتر از سفارش مشتری', '«' + j.name + '» اضافه است؛ کنار گذاشته شود.');
					else { beep(); if (j.type === 'over' && it) overAsk(it); }
					renderItems();
				}).catch(function () { netOff = true; netBadge(); alarm('bad', '✗ این کد در این حواله نیست', 'کد ' + fa(code) + ' (اینترنت ضعیف است)'); });
				return;
			}
			// جستجوی نام: اگر یک کالا پیدا شد، کادر تعدادش فوکوس می‌شود
			var hits = st.items.filter(function (i) { return i.name.toLowerCase().indexOf(low) >= 0; });
			if (hits.length === 1) { lastId = hits[0].id; filter = ''; renderItems(); var inp = main.querySelector('[data-iid="' + hits[0].id + '"] [data-units]'); if (inp) { inp.focus(); inp.select(); } e.target.value = ''; }
			else if (!hits.length) alarm('bad', 'کالایی با «' + code + '» در این حواله نیست');
			else { filter = low; renderItems(); alarm('warn', fa(hits.length) + ' کالا پیدا شد', 'کالای درست را از فهرست انتخاب کنید'); }
		}
	});
	main.addEventListener('input', function (e) {
		if (e.target.matches('[data-scan]')) {
			var v = en(e.target.value).trim().toLowerCase();
			filter = /^[0-9]+$/.test(v) ? '' : (v.length >= 2 ? v : '');
			if (st && st.mode === 'count') { renderItems(); return; }
			main.querySelectorAll('[data-iid]').forEach(function (r) {
				var i = byId(+r.dataset.iid); var dim = filter && i.name.toLowerCase().indexOf(filter) < 0;
				r.classList.toggle('dim', !!dim);
			});
		}
	});
	function reopenTask() {
		var d = modal('<h3>✏️ ' + (st.reopenDirect ? 'ویرایش بررسی' : 'درخواست ویرایش بررسی') + ' سفارش ' + esc(st.order) + '</h3><p>' + (st.reopenDirect ? 'بررسی دوباره باز می‌شود؛ شمارش‌های قبلی سر جایش است. فقط کالای اشتباه را اصلاح کنید و دوباره «تأیید نهایی» بزنید. تغییرات (قبل ← بعد) و علت در تاریخچه سفارش ثبت می‌شود و جمع فاکتور دوباره حساب می‌شود.' : 'مسئول پیگیری (' + esc(st.assignee || '—') + ') ممکن است طبق همین بررسی از مشتری حساب گرفته باشد؛ درخواست برای او فرستاده می‌شود و پس از اجازه‌اش، سفارش دوباره در صف بررسی شما می‌آید.') + '</p>'
			+ '<label style="display:grid;gap:4px;font-weight:800;font-size:13px">علت ویرایش<input type="text" data-why placeholder="مثلاً: لیوان X دو کارتن شمرده شد ولی یکی بود" style="height:44px;border-radius:10px;border:1.5px solid rgba(0,0,0,.18);padding:0 10px;background:transparent"></label>'
			+ '<button type="button" class="dk2-btn pri" data-go>' + (st.reopenDirect ? 'باز کردن برای ویرایش' : 'فرستادن درخواست') + '</button><button type="button" class="dk2-btn ghost" data-x>انصراف</button>');
		var w = d.querySelector('[data-why]'); setTimeout(function () { w.focus(); }, 50);
		d.querySelector('[data-go]').addEventListener('click', function () {
			var why = w.value.trim(); if (why.length < 3) { alarm('bad', 'علت ویرایش را بنویسید'); w.focus(); return; }
			this.disabled = true;
			post(base + '/' + st.id + '/reopen', { reason: why }).then(function (j) {
				d.remove();
				if (!j.ok) { alarm('bad', j.msg || 'باز نشد'); return; }
				st = j.state; lastId = null; renderTask(); loadList();
				if (j.sent) alarm('ok', '✓ درخواست ویرایش فرستاده شد', 'پس از اجازه مسئول پیگیری، سفارش دوباره در صف بررسی می‌آید.');
				else alarm('ok', '✏️ بررسی برای ویرایش باز شد', 'کالای اشتباه را اصلاح و دوباره تأیید نهایی کنید.');
			}).catch(function () { alarm('bad', 'اتصال برقرار نشد'); });
		});
	}
	function modal(html) { var d = document.createElement('div'); d.className = 'dk2-modal'; d.innerHTML = '<div>' + html + '</div>'; document.body.appendChild(d); d.addEventListener('click', function (e) { if (e.target === d || e.target.closest('[data-x]')) d.remove(); }); return d; }
	function approve() {
		if (qCount(st.id)) {
			flush();
			alarm('warn', '⏳ هنوز ' + fa(qCount(st.id)) + ' ثبت به سرور نرسیده', netOff ? 'اینترنت که وصل شد خودکار ارسال می‌شود؛ بعد «تأیید نهایی» را بزنید.' : 'چند لحظه صبر کنید و دوباره «تأیید نهایی» را بزنید.');
			return;
		}
		if (st.waitFor && !confirm(st.waitFor + ' هنوز جمع‌آوری این سالن را تمام نکرده. اگر الان تأیید کنید، اقلام او بررسی جداگانه می‌خواهد. ادامه می‌دهید؟')) return;
		var left = st.items.filter(function (i) { return i.desk == null; });
		var diff = st.items.filter(function (i) { return i.desk != null && i.desk !== i.target; });
		var h = '<h3>تأیید نهایی سفارش ' + esc(st.order) + '</h3>'
			+ (diff.length ? '<p>با شمارش جمع‌کننده فرق دارد:</p><ul>' + diff.map(function (i) { return '<li>' + esc(i.name) + ': جمع‌کننده ' + lbl(i, i.target) + ' ← بررسی ' + lbl(i, i.desk) + '</li>'; }).join('') + '</ul>' : '');
		if (left.length) {
			h += '<p><b>' + fa(left.length) + ' قلم هنوز بررسی نشده:</b></p><ul>' + left.slice(0, 30).map(function (i) { return '<li>' + esc(i.name) + '</li>'; }).join('') + '</ul>'
				+ '<button type="button" class="dk2-btn pri" data-rest="picker">بقیه طبق شمارش جمع‌کننده تأیید شود</button>'
				+ '<button type="button" class="dk2-btn" data-rest="missing" style="background:#fee2e2;color:#991b1b">بقیه ناموجود ثبت شود</button>';
		} else {
			h += '<p>همه اقلام بررسی شد.</p><button type="button" class="dk2-btn pri" data-rest="missing">بله، تأیید نهایی</button>';
		}
		var loose = st.items.filter(function (i) { return !i.pack && ((i.desk != null && i.desk > 0) || (i.desk == null && i.target > 0)); }).length;
		var pc = st.mode === 'count' && ((st.packs || []).length || loose);
		var nb = (st.packs || []).filter(function (p) { return p.type !== 'box'; }).length, nx = (st.packs || []).filter(function (p) { return p.type === 'box'; }).length;
		if (pc && loose) h = h.replace('<button type="button" class="dk2-btn pri"', '<div class="dk2-pk" style="grid-template-columns:1fr"><label>' + fa(loose) + ' قلم بیرون از بسته است؛ آخرین بسته (شماره ' + fa((st.packs || []).length + 1) + '):<span style="display:flex;gap:14px;font-weight:700"><label><input type="radio" name="dk2last" value="bag" checked> کیسه</label><label><input type="radio" name="dk2last" value="box"> کارتن</label></span></label></div><button type="button" class="dk2-btn pri"');
		h = h.replace('<button type="button" class="dk2-btn pri"', '<div class="dk2-pk"><label>' + (st.retail ? 'تعداد کیسه' : 'تعداد کیسه (اختیاری)') + '<input inputmode="numeric" data-bags placeholder="۰"></label><label>' + (st.retail ? 'تعداد کارتن' : 'تعداد کارتن (اختیاری)') + '<input inputmode="numeric" data-boxes placeholder="۰"></label></div><button type="button" class="dk2-btn pri"');
		h += '<button type="button" class="dk2-btn ghost" data-x>بازگشت</button>';
		var d = modal(h);
		setTimeout(function () { var bi = d.querySelector('[data-bags]'); if (bi) bi.focus(); }, 50);
		if (pc) { var bi2 = d.querySelector('[data-bags]'), bx2 = d.querySelector('[data-boxes]'); if (bi2 && nb) bi2.placeholder = fa(nb) + ' (از کیسه‌های بسته‌شده)'; if (bx2 && nx) bx2.placeholder = fa(nx) + ' (از کارتن‌های بسته‌شده)'; }
		d.addEventListener('click', function (e) {
			var b = e.target.closest('[data-rest]'); if (!b) return;
			var bags = en((d.querySelector('[data-bags]') || {}).value || '').replace(/\D/g, ''), boxes = en((d.querySelector('[data-boxes]') || {}).value || '').replace(/\D/g, '');
			if (st.retail && !pc && !bags && !boxes && !confirm('تعداد کیسه و کارتن را ننوشتید. بدون آن تأیید شود؟')) return;
			var lastEl = d.querySelector('input[name=dk2last]:checked');
			b.disabled = true;
			post(base + '/' + st.id + '/approve', { rest: b.dataset.rest, bags: bags, boxes: boxes, last: lastEl ? lastEl.value : '' }).then(function (j) {
				d.remove();
				if (!j.ok) { alarm('bad', j.msg || 'انجام نشد'); return; }
				alarm('ok', '✓ تأیید شد'); st = j.state; doneView(j.all); loadList();
			}).catch(function () { b.disabled = false; alarm('bad', 'اتصال برقرار نشد'); });
		});
	}
	// افزودن کالای دیگر به سفارش
	var addT, addRes = [];
	function searchAdd(v) {
		var box = $('[data-add-res]', main); if (!box) return;
		v = en(v || '').trim(); if (v.length < 2) { box.hidden = true; return; }
		get(base + '/' + st.id + '/products?q=' + encodeURIComponent(v)).then(function (j) {
			addRes = j.items || []; box.hidden = false;
			box.innerHTML = addRes.length ? addRes.map(function (p, k) {
				return '<div class="p">' + (p.img ? '<img src="' + esc(p.img) + '" alt="">' : '<span class="dk2-noimg"></span>') + '<span><b>' + esc(p.name) + '</b><small>' + esc(p.code) + ' · کارتن ' + fa(p.per) + 'تایی · فی ' + esc(st.retail && p.retail ? p.price : p.cprice) + '</small></span>'
					+ '<input inputmode="numeric" data-add-u="' + k + '" placeholder="عدد"><button type="button" data-add-go="' + k + '">افزودن</button></div>';
			}).join('') : '<div class="p"><span>کالایی پیدا نشد.</span></div>';
		}).catch(function () {});
	}
	main.addEventListener('input', function (e) { if (e.target.matches('[data-add-q]')) { clearTimeout(addT); var v = e.target.value; addT = setTimeout(function () { searchAdd(v); }, 300); } });
	main.addEventListener('click', function (e) {
		var g = e.target.closest('[data-add-go]'); if (!g) return;
		var p = addRes[+g.dataset.addGo], inp = main.querySelector('[data-add-u="' + g.dataset.addGo + '"]'), u = +(en(inp.value).replace(/\D/g, '') || 0);
		if (!u) { alarm('bad', 'تعداد (عدد) را بنویسید'); inp.focus(); return; }
		g.disabled = true;
		post(base + '/' + st.id + '/add', { pid: p.id, units: u }).then(function (j) {
			g.disabled = false;
			if (!j.ok) { alarm('bad', j.msg || 'اضافه نشد'); return; }
			st = j.state; lastId = st.items.length ? st.items[st.items.length - 1].id : null;
			st.items.forEach(function (i) { if (i.added && i.name === p.name) lastId = i.id; });
			alarm('ok', '➕ «' + p.name + '» ' + fa(u) + ' عدد به سفارش اضافه شد'); renderTask();
		}).catch(function () { g.disabled = false; alarm('bad', 'اتصال برقرار نشد'); });
	});
	// بارکدخوان وقتی فوکوس روی کادر نیست
	var buf = '', bufT;
	document.addEventListener('keydown', function (e) {
		if (!st || st.done || e.target.matches('input, textarea, select')) return;
		if (e.key === 'Enter') { if (buf.length >= 4) { var s = $('[data-scan]', main); if (s) { s.value = buf; s.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); } } buf = ''; return; }
		if (e.key && e.key.length === 1) { buf += e.key; clearTimeout(bufT); bufT = setTimeout(function () { buf = ''; }, 400); }
	});
	// «همه به انبار برگشت داده شد» (دو مرحله‌ای)
	main.addEventListener('click', function (e) {
		var b = e.target.closest('[data-rdone]'); if (!b) return;
		var id = +b.dataset.rdone;
		if (rArm !== id) { rArm = id; b.classList.add('arm'); b.textContent = 'مطمئنید همه اقلام به قفسه برگشت؟ دوباره بزنید ✓'; setTimeout(function () { if (rArm === id) { rArm = 0; b.classList.remove('arm'); b.textContent = '↩️ همه به انبار برگشت داده شد'; } }, 4000); return; }
		rArm = 0; b.disabled = true;
		post(base + '/' + id + '/returned', {}).then(function (j) {
			if (!j.ok) { b.disabled = false; alarm('bad', j.msg || 'ثبت نشد'); return; }
			alarm('ok', '↩️ برگشت کالاها ثبت شد'); rv = null;
			main.innerHTML = '<div class="dk2-empty"><b>↩️</b><p>برگشت کالاهای این سفارش ثبت شد.</p></div>';
			list.ret = (list.ret || []).filter(function (r) { return r.id !== id; }); renderList(); loadList();
		}).catch(function () { b.disabled = false; alarm('bad', 'اتصال برقرار نشد'); });
	});
	loadList().then(function () { var t = +root.dataset.open; if (t) open(t); });
	netBadge(); flush();
	setInterval(function () { if (!document.hidden) loadList(); }, 15000);
})();
</script>
</x-filament-panels::page>
