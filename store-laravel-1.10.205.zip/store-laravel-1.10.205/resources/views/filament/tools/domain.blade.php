<x-filament-panels::page>
<div style="display:grid;gap:20px;font-size:13.5px">
    <x-filament::section heading="۱) پیش از انتقال (روی دامنه فعلی)" icon="heroicon-o-clipboard-document-check">
        <div style="display:grid;gap:8px">
            @foreach ($checks as [$label, $st, $msg])
                @php $c = ['good' => ['#16a34a', '✓'], 'warn' => ['#d97706', '!'], 'bad' => ['#dc2626', '✗'], 'info' => ['#2563eb', 'ℹ']][$st]; @endphp
                <div style="display:flex;gap:10px;align-items:flex-start">
                    <span style="flex:none;width:24px;height:24px;border-radius:50%;display:grid;place-items:center;color:#fff;font-weight:800;background:{{ $c[0] }}">{{ $c[1] }}</span>
                    <div><b>{{ $label }}</b><br><span style="opacity:.8" @if ($st === 'info') dir="ltr" @endif>{{ $msg }}</span></div>
                </div>
            @endforeach
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
            <x-filament::button wire:click="buildAll" wire:confirm="همه کالاهای JSON سایت قبلی (موجود و ناموجود) ساخته شوند؟ ناموجودها با یک تصویر سبک ساخته می‌شوند و انتهای هر دسته می‌آیند؛ لینک‌ها هم‌شکل سایت قبلی می‌شود." size="sm">ساخت همه کالاهای سایت قبلی</x-filament::button>
            <x-filament::button wire:click="fullImages" wire:confirm="تصاویر کامل و گالری همه کالاها (از جمله ناموجودها) از سایت قبلی دانلود و روی همین هاست ذخیره شود؟" color="warning" size="sm">دانلود تصاویر کامل همه کالاها</x-filament::button>
            <x-filament::button wire:click="enableLegacy" color="gray" size="sm">روشن کردن شکل لینک سایت قبلی</x-filament::button>
            <x-filament::button wire:click="backfill" color="gray" size="sm">پر کردن شناسه کالاها از JSON</x-filament::button>
            <x-filament::button wire:click="disableSync" wire:confirm="همه منابع همگام‌سازی JSON خاموش شوند؟ JSON و ارتباط کالاها پاک نمی‌شود و نسخه ذخیره‌شده JSON می‌ماند؛ موجودی و قیمت از این پس در پنل تغییر می‌کند." color="warning" size="sm">خاموش کردن همگام‌سازی JSON</x-filament::button>
        </div>
    </x-filament::section>

    <x-filament::section heading="۲) سی‌پنل و DNS (بیرون از سایت)" icon="heroicon-o-server-stack">
        <ol style="margin:0;padding-inline-start:20px;display:grid;gap:6px;line-height:1.9">
            <li>یک روز قبل: در پنل دامنه aziziplast.com مقدار TTL رکوردها را کم کنید (مثلاً ۳۰۰ ثانیه) تا تغییر سریع پخش شود.</li>
            <li>از «ابزار سایت ← پشتیبان‌گیری» یک پشتیبان کامل بگیرید.</li>
            <li>سی‌پنل همین هاست ← <b>Domains</b> ← <b>Create A New Domain</b>: دامنه aziziplast.com، تیک «Share document root» را بردارید و Document Root را <b>همان پوشه public سایت فعلی</b> بدهید (همان پوشه‌ای که zarfbanoo.com به آن وصل است).</li>
            <li>DNS دامنه aziziplast.com (و www) را به این هاست بدهید: یا NSهای هاست، یا رکورد A به IP هاست. (اگر ایمیل دامنه روی سرور دیگری است، رکوردهای MX را دست نزنید.)</li>
            <li>سی‌پنل ← <b>SSL/TLS Status</b> ← Run AutoSSL (یا Let's Encrypt) برای aziziplast.com و www.aziziplast.com.</li>
            <li>چند دقیقه بعد پایین همین صفحه «آزمایش اتصال» را بزنید؛ وقتی سبز شد «ثبت دامنه جدید».</li>
        </ol>
    </x-filament::section>

    <x-filament::section heading="۳) ثبت دامنه جدید" icon="heroicon-o-globe-alt" :description="'دامنه فعلی: '.$cur">
        {{ $this->form }}
        @if ($probe)
            <div style="margin-top:10px;padding:10px 12px;border-radius:10px;font-weight:700;{{ $probe['ok'] ? 'background:rgba(22,163,74,.1);color:#15803d' : 'background:rgba(220,38,38,.08);color:#b91c1c' }}">{{ $probe['host'] }}: {{ $probe['msg'] }}</div>
        @endif
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
            <x-filament::button wire:click="test" color="gray">آزمایش اتصال دامنه</x-filament::button>
            <x-filament::button wire:click="apply" wire:confirm="آدرس اصلی سایت به دامنه جدید تغییر کند و دامنه‌های قدیم با ۳۰۱ به آن بروند؟" color="danger">ثبت دامنه جدید</x-filament::button>
        </div>
    </x-filament::section>

    <x-filament::section heading="۴) پس از انتقال" icon="heroicon-o-check-badge">
        <ol style="margin:0;padding-inline-start:20px;display:grid;gap:6px;line-height:1.9">
            <li>با https://aziziplast.com/admin دوباره وارد پنل شوید (ورود روی دامنه قبلی جدا بود). مشتری‌ها هم یک بار دوباره وارد می‌شوند.</li>
            <li>چند لینک قدیمی را امتحان کنید، مثلاً aziziplast.com/product-21093/… و aziziplast.com/category/1/… ؛ باید همان کالا/دسته باز شود.</li>
            <li>«تنظیمات ← اپ اندروید ← ساخت نسخه جدید اپ» (آدرس سایت داخل اپ ساخته می‌شود). اپ‌های نصب‌شده قبلی تا وقتی zarfbanoo.com روی همین هاست است کار می‌کنند.</li>
            <li>درگاه پرداخت: در پنل درگاه (زرین‌پال و …) دامنه aziziplast.com را ثبت/تأیید کنید.</li>
            <li>پنل پیامک: اگر لینک‌ها باید ثبت شوند، دامنه aziziplast.com را ثبت کنید.</li>
            <li>گوگل سرچ کنسول: برای aziziplast.com نقشه سایت https://aziziplast.com/sitemap.xml را ثبت کنید و گزارش «صفحات» (خطای ۴۰۴) را چند روز زیر نظر بگیرید.</li>
            <li>zarfbanoo.com را دست‌کم ۶ ماه تمدید و روی همین هاست نگه دارید (ریدایرکت ۳۰۱ و اپ‌های قدیمی).</li>
            <li>کرون سی‌پنل (اگر تعریف کرده‌اید) با مسیر پوشه همان می‌ماند؛ نیازی به تغییر نیست.</li>
        </ol>
    </x-filament::section>
</div>
</x-filament-panels::page>
