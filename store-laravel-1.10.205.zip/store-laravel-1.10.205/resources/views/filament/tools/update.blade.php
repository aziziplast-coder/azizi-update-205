<x-filament-panels::page>
    <x-filament::section>
        <div style="display:flex;flex-wrap:wrap;gap:8px 24px;font-size:14px;align-items:center">
            <span>نسخه فعلی: <b dir="ltr">{{ $version }}</b></span>
        </div>
        <ol style="font-size:13px;opacity:.8;margin:10px 0 0;padding-inline-start:18px;list-style:decimal;display:grid;gap:2px">
            <li>فایل zip نسخه جدید را انتخاب کنید و «بررسی فایل» را بزنید.</li>
            <li>با «نصب نسخه جدید»: کدها بررسی، از پایگاه داده پشتیبان گرفته و نسخه جدید جایگزین می‌شود.</li>
            <li>سایت با نسخه جدید آزمایش می‌شود؛ اگر خطا بدهد، خودکار به نسخه قبل برمی‌گردد و علت خطا این‌جا نمایش داده می‌شود.</li>
        </ol>
    </x-filament::section>

    <x-filament::section>
        <form wire:submit="inspect" style="display:grid;gap:12px">
            {{ $this->form }}
            <div style="display:flex;gap:8px;flex-wrap:wrap">
                <x-filament::button type="submit" color="gray" icon="heroicon-o-magnifying-glass">بررسی فایل</x-filament::button>
                @if ($inspected)
                    <x-filament::button type="button" wire:click="install" icon="heroicon-o-arrow-up-circle" wire:loading.attr="disabled"
                        wire:confirm="سایت به نسخه {{ $inspected['version'] }} به‌روزرسانی شود؟ این کار ممکن است یکی دو دقیقه طول بکشد.">نصب نسخه {{ $inspected['version'] }}</x-filament::button>
                @endif
                <span wire:loading wire:target="install" style="opacity:.75;align-self:center">در حال به‌روزرسانی… صفحه را نبندید.</span>
            </div>
        </form>
        @if ($inspected)
            <p style="margin:12px 0 0;font-size:13.5px">فایل معتبر است: نسخه <b dir="ltr">{{ $inspected['version'] }}</b> با {{ fa($inspected['files']) }} فایل.
                @if (version_compare($inspected['version'], $version, '<='))<span style="color:#d97706"> (این نسخه از نسخه فعلی جدیدتر نیست)</span>@endif</p>
        @endif
        @if ($error)
            <div style="margin-top:12px;padding:12px 14px;border-radius:12px;background:rgb(220 38 38 / .1);color:#dc2626;white-space:pre-line;font-size:13.5px"><b>مشکل:</b> {{ $error }}</div>
        @endif
        @if ($result)
            <div style="margin-top:12px;padding:12px 14px;border-radius:12px;background:rgb(22 163 74 / .1);color:#16a34a;font-size:13.5px">{{ $result }}</div>
        @endif
    </x-filament::section>

    @if ($previous)
        <x-filament::section heading="بازگشت دستی به نسخه قبل" description="فقط کد برمی‌گردد؛ اطلاعات فروشگاه تغییر نمی‌کند.">
            @foreach ($previous as $p)
                <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-top:1px solid rgb(127 127 127 / .2);font-size:13.5px">
                    <span>نسخه <b dir="ltr">{{ $p['version'] }}</b> — {{ jdate(\Illuminate\Support\Carbon::createFromTimestamp($p['time']), true) }}</span>
                    <x-filament::button size="xs" color="warning" wire:click="rollback('{{ $p['dir'] }}')" wire:confirm="کد سایت به این نسخه برگردد؟">بازگشت</x-filament::button>
                </div>
            @endforeach
        </x-filament::section>
    @endif

    @if ($log)
        <x-filament::section heading="گزارش به‌روزرسانی‌ها" collapsible collapsed>
            <pre style="font-size:12px;white-space:pre-wrap;direction:rtl;margin:0">{{ $log }}</pre>
        </x-filament::section>
    @endif
</x-filament-panels::page>
