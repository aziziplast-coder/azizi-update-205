<x-filament-panels::page>
    <x-filament::section>
        <div style="display:flex;flex-wrap:wrap;gap:8px 24px;font-size:13.5px">
            <span>پشتیبان خودکار: <b>{{ setting('backup_auto') ? 'روشن — روزانه از ساعت '.fa(setting('backup_hour', 3)) : 'خاموش' }}</b></span>
            <span>نوع: <b>{{ setting('backup_type') === 'full' ? 'کامل' : 'پایگاه داده' }}</b></span>
            <span>نگه‌داری: <b>{{ fa(setting('backup_keep', 7)) }} نسخه آخر</b></span>
            @if ($disk)<span>فضای آزاد هاست: <b>{{ \App\Services\HostHealth::size($disk['free']) }}</b></span>@endif
        </div>
        <p style="font-size:12.5px;opacity:.7;margin:8px 0 0">پشتیبان‌ها در پوشه محافظت‌شده storage/app/backups هستند و از اینترنت قابل دسترسی نیستند. یک نسخه را گاهی دانلود و جای دیگری نگه دارید.</p>
    </x-filament::section>
    <x-filament::section heading="فهرست پشتیبان‌ها">
        @if (! $list)
            <p style="opacity:.7">هنوز پشتیبانی وجود ندارد.</p>
        @else
            <div style="overflow-x:auto">
                <table style="width:100%;border-collapse:collapse;font-size:13.5px">
                    <thead><tr style="text-align:right;opacity:.7;font-size:12.5px"><th style="padding:8px">تاریخ</th><th style="padding:8px">نوع</th><th style="padding:8px">منبع</th><th style="padding:8px">حجم</th><th style="padding:8px"></th></tr></thead>
                    <tbody>
                    @foreach ($list as $b)
                        <tr style="border-top:1px solid rgb(127 127 127 / .2)">
                            <td style="padding:8px;white-space:nowrap">{{ jdate($b['time'], true) }}</td>
                            <td style="padding:8px"><x-filament::badge :color="$b['type'] === 'full' ? 'success' : 'gray'">{{ $b['type'] === 'full' ? 'کامل' : 'پایگاه داده' }}</x-filament::badge></td>
                            <td style="padding:8px">{{ \App\Services\Backup::LABELS[$b['label']] ?? $b['label'] }}</td>
                            <td style="padding:8px;white-space:nowrap">{{ \App\Services\HostHealth::size($b['size']) }}</td>
                            <td style="padding:8px;white-space:nowrap;display:flex;gap:6px;justify-content:flex-end">
                                <x-filament::button tag="a" size="xs" color="gray" icon="heroicon-o-arrow-down-tray" :href="route('admin.backup.download', $b['file'])">دانلود</x-filament::button>
                                <x-filament::button size="xs" color="warning" icon="heroicon-o-arrow-uturn-left" wire:click="restore('{{ $b['file'] }}')"
                                    wire:confirm="اطلاعات فعلی سایت با این پشتیبان جایگزین می‌شود (قبلش خودکار یک پشتیبان از وضعیت فعلی گرفته می‌شود). ادامه می‌دهید؟">بازگردانی</x-filament::button>
                                <x-filament::button size="xs" color="danger" icon="heroicon-o-trash" wire:click="delete('{{ $b['file'] }}')" wire:confirm="این پشتیبان از هاست حذف شود؟">حذف</x-filament::button>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </x-filament::section>
</x-filament-panels::page>
