<x-filament-panels::page>
<div style="display:grid;gap:16px;font-size:13.5px" @if (! empty($st['running'])) wire:poll.1500ms="tick" @endif>
    <x-filament::section>
        <p style="margin:0 0 10px;opacity:.85;line-height:1.9">مقاله‌های سایت قبلی (شکل لینک <span dir="ltr">/blog-134/عنوان</span>) پیش از انتقال دامنه خوانده و در وبلاگ همین سایت ذخیره می‌شوند:
            عنوان، متن، تصویر اصلی و تصاویر داخل متن (روی همین هاست)، توضیح و تاریخ. هر مقاله با همان شماره ذخیره می‌شود تا پس از انتقال، لینک قدیمی دقیقاً همان مقاله را باز کند.
            مقاله‌ای که قبلاً وارد شده دوباره ساخته نمی‌شود. پس از ورود، مقاله‌ها را در «مقاله‌ها» ببینید و در صورت نیاز ویرایش کنید.</p>
        <div style="display:grid;gap:10px;max-width:640px">
            <label style="display:grid;gap:4px;font-weight:700">دامنه سایت قبلی
                <input wire:model="base" dir="ltr" class="fi-input" style="border:1px solid rgba(127,127,127,.35);border-radius:8px;padding:8px 10px" @disabled(! empty($st['running']))></label>
            <label style="display:grid;gap:4px;font-weight:700">لینک‌های اضافه (اختیاری، هر خط یکی — اگر بعضی مقاله‌ها پیدا نشدند)
                <textarea wire:model="extra" rows="3" dir="ltr" style="border:1px solid rgba(127,127,127,.35);border-radius:8px;padding:8px 10px" @disabled(! empty($st['running']))></textarea></label>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
                @if (empty($st['running']))
                    <x-filament::button wire:click="start" wire:loading.attr="disabled">یافتن و ورود مقاله‌ها</x-filament::button>
                @else
                    <x-filament::button wire:click="stop" color="gray">توقف</x-filament::button>
                @endif
            </div>
        </div>
    </x-filament::section>

    @if (! empty($st['urls']))
        @php $tot = count($st['urls']); $pct = $tot ? round($st['i'] * 100 / $tot) : 0; @endphp
        <x-filament::section :heading="'پیشرفت: '.fa($st['i']).' از '.fa($tot)">
            <div style="height:10px;border-radius:99px;background:rgba(127,127,127,.15);overflow:hidden"><div style="height:100%;width:{{ $pct }}%;background:#16a34a"></div></div>
            <div style="display:flex;gap:16px;margin-top:8px;flex-wrap:wrap">
                <span style="color:#15803d;font-weight:700">✓ وارد شد: {{ fa($st['ok']) }}</span>
                <span style="opacity:.75">تکراری/رد شد: {{ fa($st['skip']) }}</span>
                <span style="color:#b91c1c;font-weight:700">ناموفق: {{ fa($st['fail']) }}</span>
                @if (empty($st['running']))<span style="font-weight:700">پایان یافت.</span>@else<span>در حال ورود… (صفحه را باز نگه دارید)</span>@endif
            </div>
            <div style="margin-top:10px;max-height:320px;overflow:auto;display:grid;gap:4px">
                @foreach (array_reverse($st['log']) as [$s, $m])
                    <div style="font-size:12.5px;color:{{ $s === 'ok' ? '#15803d' : ($s === 'fail' ? '#b91c1c' : 'inherit') }}">{{ $s === 'ok' ? '✓' : ($s === 'fail' ? '✗' : '•') }} {{ $m }}</div>
                @endforeach
            </div>
        </x-filament::section>
    @endif
</div>
</x-filament-panels::page>
