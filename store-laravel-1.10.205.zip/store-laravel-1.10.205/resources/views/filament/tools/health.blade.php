@php $lv = fn ($p) => $p === null ? '' : ($p >= 92 ? 'bad' : ($p >= 80 ? 'warn' : '')); @endphp
<x-filament-panels::page>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px" wire:poll.15s.visible>
        @foreach ([['رم ('.($live['mem']['src'] ?? '').')', $live['mem_pct'], $live['mem'] ? \App\Services\HostHealth::size($live['mem']['used']).' از '.\App\Services\HostHealth::size($live['mem']['total']) : 'نامشخص'],
                   ['دیسک', $live['disk_pct'], $live['disk'] ? \App\Services\HostHealth::size($live['disk']['free']).' آزاد از '.\App\Services\HostHealth::size($live['disk']['total']) : 'نامشخص'],
                   ['پردازنده', $live['cpu_pct'], $live['load'] ? 'بار: '.fa(implode(' / ', $live['load'])).' — '.fa($live['cpus']).' هسته' : 'نامشخص']] as [$label, $pct, $sub])
            <x-filament::section>
                <div style="display:flex;justify-content:space-between;align-items:baseline"><b>{{ $label }}</b><b style="font-size:22px">{{ $pct === null ? '—' : fa($pct).'٪' }}</b></div>
                <div class="meter {{ $lv($pct) }}" style="margin:10px 0 6px"><i style="width:{{ $pct ?? 0 }}%"></i></div>
                <small style="opacity:.7">{{ $sub }}</small>
            </x-filament::section>
        @endforeach
        <x-filament::section>
            <div style="display:grid;gap:6px;font-size:13px">
                <div style="display:flex;justify-content:space-between"><span>پاسخ پایگاه داده</span><b>{{ fa($live['db_ms']) }} ms</b></div>
                <div style="display:flex;justify-content:space-between"><span>حافظه این درخواست</span><b>{{ \App\Services\HostHealth::size($live['php_mem']) }}</b></div>
                <div style="display:flex;justify-content:space-between"><span>روشن بودن سرور</span><b>{{ fa(round($live['uptime'] / 86400, 1)) }} روز</b></div>
                <div style="display:flex;justify-content:space-between;opacity:.6"><span>به‌روزرسانی</span><span>{{ fa($live['t']) }}</span></div>
            </div>
        </x-filament::section>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:16px;align-items:start">
        <x-filament::section :heading="'امتیاز سلامت: '.fa($score).' از ۱۰۰'" icon="heroicon-o-shield-check">
            <ul style="display:grid;gap:8px;font-size:13.5px">
                @foreach ($checks as [$t, $st, $note])
                    <li style="display:flex;gap:8px"><span>{{ $st === 'good' ? '🟢' : ($st === 'warn' ? '🟡' : '🔴') }}</span><span><b>{{ $t }}</b> <span style="opacity:.7">— {{ $note }}</span></span></li>
                @endforeach
            </ul>
        </x-filament::section>
        <div style="display:grid;gap:16px">
            <x-filament::section heading="مشخصات" icon="heroicon-o-information-circle">
                <dl style="display:grid;gap:6px;font-size:13px">
                    @foreach ($info as $k => $v)<div style="display:flex;justify-content:space-between;gap:10px"><dt style="opacity:.7">{{ $k }}</dt><dd style="margin:0;text-align:left" dir="ltr">{{ $v }}</dd></div>@endforeach
                </dl>
            </x-filament::section>
            <x-filament::section heading="چه چیزی فضا گرفته؟" icon="heroicon-o-chart-pie">
                @if ($sizes)
                    @php $max = max(1, max($sizes)); @endphp
                    <div style="display:grid;gap:10px;font-size:13px">
                        @foreach ($sizes as $k => $v)
                            <div><div style="display:flex;justify-content:space-between"><span>{{ $k }}</span><b>{{ \App\Services\HostHealth::size($v) }}</b></div>
                            <div class="meter"><i style="width:{{ round($v / $max * 100) }}%"></i></div></div>
                        @endforeach
                    </div>
                @else
                    <p style="font-size:13px;opacity:.7;margin:0 0 10px">برای محاسبه دکمه را بزنید (چند ثانیه).</p>
                @endif
                <x-filament::button wire:click="calcSizes" size="sm" color="gray" style="margin-top:10px" wire:loading.attr="disabled">محاسبه حجم‌ها</x-filament::button>
            </x-filament::section>
        </div>
    </div>
    @php $errs = \App\Services\HostHealth::recentErrors(15); @endphp
    <x-filament::section heading="آخرین خطاهای سایت" icon="heroicon-o-bug-ant" collapsible :collapsed="! $errs" style="margin-top:16px">
        @if ($errs)
            <p style="font-size:13px;opacity:.75;margin:0 0 10px">اگر جایی خطای ۵۰۰ دیدید، متن خطای همان زمان را از این‌جا کپی کنید و برای پشتیبانی بفرستید.</p>
            <div style="display:grid;gap:8px">
                @foreach ($errs as $er)
                    <details style="border:1px solid rgba(127,127,127,.25);border-radius:10px;padding:8px 12px">
                        <summary style="cursor:pointer;font-size:13px"><b dir="ltr">{{ $er['time'] }}</b> — <span dir="ltr" style="color:#dc2626">{{ \Illuminate\Support\Str::limit($er['message'], 160) }}</span></summary>
                        <textarea readonly dir="ltr" onclick="this.select()" style="width:100%;min-height:160px;margin-top:8px;font:12px/1.6 monospace;padding:8px;border-radius:8px;background:rgba(127,127,127,.08);border:0">{{ $er['full'] }}</textarea>
                    </details>
                @endforeach
            </div>
        @else
            <p style="font-size:13px;opacity:.7;margin:0">خطایی ثبت نشده است. 👌</p>
        @endif
    </x-filament::section>
</x-filament-panels::page>
