<x-filament-panels::page>
<link rel="stylesheet" href="{{ asset('css/admin-tools.css') }}?v={{ @filemtime(public_path('css/admin-tools.css')) }}">
<style>
.ss-tabs{display:flex;gap:6px;padding:5px;background:var(--sf);border-radius:16px;margin-bottom:16px;overflow-x:auto;scrollbar-width:none}
.ss-tabs button{flex:1;min-width:max-content;display:inline-flex;align-items:center;justify-content:center;gap:8px;border:0;background:none;border-radius:12px;padding:10px 14px;font-weight:800;font-size:13.5px;color:var(--mu);cursor:pointer;transition:.2s}
.ss-tabs button.on{background:var(--cd);color:var(--ac);box-shadow:0 2px 10px -4px rgba(0,0,0,.25)}
.ss-files{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px;margin-top:14px}
.ss-file{display:flex;flex-direction:column;gap:8px;padding:12px;border-radius:16px;background:var(--sf);border:2px solid transparent;animation:bu-in .3s both}
.ss-file.carton{border-color:rgba(var(--primary-500),.35)}.ss-file.retail{border-color:rgba(18,161,80,.4)}.ss-file.skip{opacity:.55}.ss-file.ask{border-color:var(--bad)}
.ss-file .h{display:flex;align-items:center;gap:10px}
.ss-file .h em{flex:none;width:38px;height:44px;border-radius:9px;display:grid;place-items:end center;padding-bottom:5px;font-style:normal;font-size:9.5px;font-weight:900;color:#fff;background:linear-gradient(160deg,#22c55e,#15803d)}
.ss-file .h b{font-size:13px;word-break:break-all}.ss-file .h small{display:block;color:var(--mu);font-size:11.5px}
.ss-seg{display:flex;gap:4px;padding:3px;background:var(--cd);border-radius:11px}
.ss-seg button{flex:1;border:0;background:none;border-radius:9px;padding:6px 4px;font-weight:800;font-size:12px;color:var(--mu);cursor:pointer}
.ss-seg button.on.carton{background:var(--ac);color:#fff}.ss-seg button.on.retail{background:var(--ok);color:#fff}.ss-seg button.on.skip{background:var(--ln);color:inherit}
.ss-flag{font-size:12px;font-weight:700;line-height:1.8;padding:6px 10px;border-radius:10px}
.ss-flag.ok{background:#e0f2fe;color:#075985}.dark .ss-flag.ok{background:rgb(14 165 233 / .15);color:#7dd3fc}.ss-flag.bad{background:var(--badb);color:var(--bad)}.ss-flag.wa{background:var(--wab);color:var(--wa)}
.ss-scope{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:8px;margin-top:14px}
.ss-scope label{display:flex;gap:10px;align-items:flex-start;padding:12px;border-radius:14px;background:var(--sf);border:2px solid transparent;cursor:pointer;font-size:13px;line-height:1.8}
.ss-scope label:has(input:checked){border-color:rgba(var(--primary-500),.5);background:var(--acs)}
.ss-scope b{display:block;font-size:13.5px}
.ss-warn{display:flex;flex-direction:column;gap:8px;padding:14px;border-radius:16px;background:var(--badb);border:1.5px solid rgba(229,72,77,.35);margin-bottom:14px}
.ss-warn h4{margin:0;color:var(--bad);font-size:14.5px;font-weight:900}
.ss-warn p{margin:0;font-size:13px;line-height:1.9}
.ss-big{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}
.ss-big>div{border-radius:18px;padding:14px;background:var(--sf);display:flex;flex-direction:column;gap:6px}
.ss-big h4{margin:0;font-size:13px;font-weight:900;display:flex;align-items:center;gap:6px}
.ss-big .n{display:flex;gap:8px}
.ss-big .n span{flex:1;border-radius:12px;padding:8px 10px;background:var(--cd)}
.ss-big .n b{display:block;font-size:22px;font-weight:900;line-height:1.2}.ss-big .n small{font-size:11.5px;font-weight:700;color:var(--mu)}
.ss-big .n .on b{color:var(--ok)}.ss-big .n .off b{color:var(--wa)}
.ss-cov{display:flex;flex-wrap:wrap;gap:6px}
.ss-cov span{display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:800;padding:5px 10px;border-radius:999px;background:var(--sf)}
.ss-cov span.y{background:var(--okb);color:var(--ok)}.ss-cov span.n{color:var(--mu)}
.ss-cov span small{font-weight:600;opacity:.8}
.ss-confirm{display:flex;align-items:center;gap:8px;font-weight:800;font-size:13px;color:var(--bad)}
.ss-hist .it{display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:center;padding:10px 12px;border-radius:14px;background:var(--sf);margin-bottom:8px}
.ss-hist .it>em{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;font-style:normal;background:var(--cd);font-size:18px}
.ss-hist .it b{display:block;font-size:13.5px}.ss-hist .it small{color:var(--mu);font-size:12px;line-height:1.8}
.ss-old{display:grid;gap:16px}
@media (max-width:640px){.ss-tabs button{font-size:12.5px;padding:9px 10px}.ss-big .n b{font-size:19px}.ss-hist .it{grid-template-columns:auto 1fr}.ss-hist .it>div:last-child{grid-column:1/-1}}
</style>

<div class="bu" id="ss" x-data="{ tab: '{{ request('tab', 'scan') }}' }">
    <svg width="0" height="0" style="position:absolute"><defs><linearGradient id="buGrad" x1="0" x2="1"><stop offset="0" stop-color="rgb(var(--primary-400))"/><stop offset="1" stop-color="rgb(var(--primary-700))"/></linearGradient></defs></svg>

    <div class="bu-hero">
        <i class="deco"></i><i class="deco2"></i>
        <h2 x-show="tab === 'full'" x-cloak>اطلاعات کالا از هلو 🧾</h2>
        <p x-show="tab === 'full'" x-cloak>فایل قیمت هلو (یا هر نرم‌افزار حسابداری) را بدهید؛ کالاها با کد کالا پیدا می‌شوند و قیمت، نام و موجودی‌شان به انتخاب شما به‌روز می‌شود. ستون‌ها خودکار تشخیص داده می‌شوند.</p>
        <h2 x-show="tab === 'scan'">موجودی امروز انبارها 🏬</h2>
        <p x-show="tab === 'scan'">خروجی اسکنر انباردارها را بدهید (ZIP، RAR یا فایل‌های جدا). کالاهای داخل فایل‌های «عمده» در فروش کارتنی و کالاهای داخل فایل‌های «خرده» در فروش خرده موجود می‌شوند و بقیه ناموجود. قبل از هر تغییری پیش‌نمایش و هشدارها را می‌بینید و هر وقت لازم شد برمی‌گردانید.</p>
        <div class="pills" x-show="tab === 'scan'"><span>🔎 پیش‌نمایش قبل از اعمال</span><span>🛡 تشخیص فایل جابه‌جا</span><span>🏬 فقط انبارهای اسکن‌شده</span><span>↩ برگشت با یک کلیک</span></div>
    </div>

    <div class="ss-tabs" role="tablist">
        <button type="button" :class="tab === 'scan' && 'on'" x-on:click="tab = 'scan'">📦 موجودی روزانه (اسکنر)</button>
        <button type="button" :class="tab === 'full' && 'on'" x-on:click="tab = 'full'">🧾 اطلاعات کالا (قیمت، نام…)</button>
    </div>

    {{-- ========== موجودی روزانه ========== --}}
    <div x-show="tab === 'scan'">
        <div class="bu-steps" id="ssSteps" style="grid-template-columns:repeat(3,1fr)"><i class="track" id="ssTrack" style="right:16.6%"></i>
            <div class="on"><b>۱</b>فایل‌های اسکنر</div><div><b>۲</b>پیش‌نمایش</div><div><b>۳</b>اعمال</div>
        </div>

        <div class="bu-card bu-anim" id="ssPick">
            <label class="bu-drop" id="ssDrop">
                <input type="file" id="ssFile" multiple hidden accept=".rar,.zip,.7z,.xlsx,.xls,.csv">
                <div class="icons"><span class="x">OMDE</span><span class="z">ZIP</span><span class="j" style="background:linear-gradient(160deg,#14b8a6,#0f766e)">KHORDE</span></div>
                <b class="t" id="ssDropT">فایل‌های اسکنر امروز را اینجا رها کنید</b>
                <small id="ssDropS">ZIP یا RAR عمده و خرده، یا فایل‌های اکسل جدا — همه با هم.</small>
                <span class="btnish">انتخاب فایل‌ها</span>
            </label>
            <div class="bu-help">
                <div><em>🏷</em><span><b>نوع از روی نام فایل:</b> نام شامل <code>omde</code> = انبار عمده (کارتنی)، شامل <code>khorde</code> = انبار خرده. اگر لازم بود همین‌جا عوضش کنید.</span></div>
                <div><em>🔢</em><span><b>محتوا:</b> فقط کدهای اسکن‌شده (یک ستون). کدهای تکراری و خانه‌های خالی مهم نیستند.</span></div>
                <div><em>🛡</em><span><b>اشتباه انباردار:</b> اگر فایل عمده در خرده ریخته شده باشد (یا برعکس)، یا تعداد زیادی کالا ناگهان ناموجود شود، پیش از اعمال هشدار می‌گیرید.</span></div>
            </div>

            <div id="ssPicked" hidden style="margin-top:18px">
                <div class="bu-kpis" id="ssPickKpi"></div>
                <div class="ss-files" id="ssFiles"></div>
                <div class="ss-scope">
                    <label><input type="radio" name="ssScope" value="covered" checked><span><b>فقط انبارهایی که امروز اسکن شده‌اند (پیشنهادی)</b>اگر فایل یک انبار جا مانده باشد، کالاهای آن انبار دست نمی‌خورند.</span></label>
                    <label><input type="radio" name="ssScope" value="all"><span><b>همه انبارها</b>هر کالایی که در هیچ فایلی نیست ناموجود می‌شود (فقط وقتی همه فایل‌ها را داده‌اید).</span></label>
                </div>
                <div class="bu-row" style="margin-top:14px">
                    <button class="bu-btn pri lg" id="ssGo">بررسی و پیش‌نمایش ← <small style="opacity:.8;font-weight:600">(هنوز چیزی تغییر نمی‌کند)</small></button>
                    <button class="bu-btn" id="ssReset">انتخاب دوباره</button>
                </div>
            </div>
        </div>

        <div class="bu-card bu-anim" id="ssBusy" hidden>
            <div class="bu-live">
                <div class="bu-ring" id="ssRing"><svg viewBox="0 0 150 150"><circle class="bg" cx="75" cy="75" r="62"/><circle class="fg" cx="75" cy="75" r="62"/></svg><div><b>۰٪</b><small>…</small></div></div>
                <div><h3 id="ssBusyH">در حال خواندن فایل‌ها…</h3><div class="bu-note"><span class="bu-shine">کدها با همه کالاهای سایت و انبارها مقایسه می‌شوند.</span></div></div>
            </div>
        </div>

        <div id="ssPrev" hidden>
            <div id="ssWarn"></div>
            <div class="bu-card bu-anim"><div class="ss-big" id="ssBig"></div></div>
            <div class="bu-card bu-anim">
                <h3>فایل‌ها</h3>
                <div class="ss-files" id="ssFiles2" style="margin-top:0"></div>
                <div class="bu-row" style="margin-top:12px"><button class="bu-btn" id="ssRe">↻ بررسی دوباره با نوع‌های انتخاب‌شده</button></div>
            </div>
            <div class="bu-card bu-anim">
                <h3>کدام انبارها امروز اسکن شده‌اند؟</h3>
                <p class="bu-note" style="margin:-6px 0 10px">کالاهای انبارهای سبز که در فایل‌ها نیستند ناموجود می‌شوند؛ انبارهای خاکستری امروز دست نمی‌خورند.</p>
                <div id="ssCov"></div>
            </div>
            <div class="bu-card bu-anim">
                <div class="bu-row" style="justify-content:space-between;margin-bottom:10px"><h3 style="margin:0">فهرست تغییرات</h3><span class="bu-note">برای فهرست کامل، دانلود را بزنید</span></div>
                <div class="bu-tabs" id="ssLTabs"></div>
                <div class="bu-scroll" id="ssList"></div>
            </div>
            <div class="bu-dock">
                <label class="ss-confirm" id="ssConfirmWrap" hidden><input type="checkbox" id="ssConfirm"> هشدارها را بررسی کردم؛ اعمال شود</label>
                <span class="bu-note" id="ssDockNote"></span>
                <div class="bu-row"><button class="bu-btn" id="ssCancel">انصراف</button><button class="bu-btn ok lg" id="ssApply">✓ اعمال روی سایت</button></div>
            </div>
        </div>

        <div class="bu-card bu-done" id="ssDone" hidden>
            <div class="check">✓</div>
            <h3>موجودی انبارها به‌روز شد</h3>
            <div class="ss-big" id="ssDoneBig" style="text-align:right;margin:14px 0"></div>
            <p class="bu-note">اگر اشتباهی پیش آمده، با «برگرداندن» همه‌چیز دقیقاً به حالت قبل از این به‌روزرسانی برمی‌گردد.</p>
            <div class="bu-row" style="justify-content:center;margin-top:10px"><button class="bu-btn lg" id="ssUndoNow">↩ برگرداندن همین به‌روزرسانی</button><button class="bu-btn pri lg" onclick="location.reload()">تمام</button></div>
        </div>

        @if ($scans->isNotEmpty())
            <div class="bu-card ss-hist bu-anim">
                <h3>به‌روزرسانی‌های اخیر</h3>
                @foreach ($scans as $sc)
                    @php $st = json_decode((string) $sc->stats, true) ?: []; $c = $st['counts'] ?? []; @endphp
                    <div class="it">
                        <em>{{ $sc->status === 'reverted' ? '↩' : '✅' }}</em>
                        <div><b>{{ jdate($sc->applied_at, true) }} · {{ $sc->user }}</b>
                            <small>کارتنی: {{ fa($c['c_on'] ?? 0) }} موجود، {{ fa($c['c_off'] ?? 0) }} ناموجود · خرده: {{ fa($c['r_on'] ?? 0) }} موجود، {{ fa($c['r_off'] ?? 0) }} ناموجود · {{ fa(count($st['files'] ?? [])) }} فایل
                                @isset($c['all_total'])<br>کل موجود پس از فایل: {{ fa($c['all_total']) }} کالا (کارتنی {{ fa($c['c_total']) }} · خرده {{ fa($c['r_total']) }})@endisset{{ $sc->status === 'reverted' ? ' · برگردانده شد '.jdate($sc->reverted_at, true) : '' }}</small></div>
                        <div class="bu-row" style="gap:6px">
                            @foreach (['summary' => 'خلاصه', 'c_off' => 'ناموجودشده‌ها', 'c_on' => 'موجودشده‌ها', 'r_off' => 'خرده ناموجود', 'r_on' => 'خرده موجود', 'unknown' => 'کدهای ناشناخته'] as $k => $l)
                                <a class="bu-btn" style="min-height:32px;font-size:12px;padding:0 10px" href="{{ route('admin.stockscan.report', [$sc->id, $k]) }}">⬇ {{ $l }}</a>
                            @endforeach
                            @if ($undoId === $sc->id)<button class="bu-btn" style="min-height:32px;font-size:12px;padding:0 10px;color:var(--bad)" data-undo="{{ $sc->id }}">↩ برگرداندن</button>@endif
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>

    {{-- ========== اطلاعات کالا (فایل قیمت هلو) ========== --}}
    <div x-show="tab === 'full'" x-cloak>
        <div class="bu-steps" id="piSteps" style="grid-template-columns:repeat(3,1fr)"><i class="track" id="piTrack" style="right:16.6%"></i>
            <div class="on"><b>۱</b>فایل قیمت</div><div><b>۲</b>ستون‌ها و گزینه‌ها</div><div><b>۳</b>نتیجه</div>
        </div>

        <div class="bu-card bu-anim" id="piPick">
            <label class="bu-drop" id="piDrop">
                <input type="file" id="piFile" multiple hidden accept=".xlsx,.xls,.csv,.xlsb,.zip,.rar">
                <div class="icons"><span class="x">XLSX</span><span class="z">HOLOO</span></div>
                <b class="t" id="piDropT">فایل قیمت هلو را اینجا رها کنید</b>
                <small>اکسل اطلاعات کالا (کد، نام، قیمت…). ستون‌ها و سطر عنوان خودکار تشخیص داده می‌شوند.</small>
                <span class="btnish">انتخاب فایل</span>
            </label>
            <div class="bu-help">
                <div><em>🧠</em><span><b>تشخیص خودکار:</b> ستون کد کالا، نام، قیمت و بقیه از روی عنوان ستون‌ها پیدا می‌شود؛ ریال یا تومان بودن هم با مقایسه با قیمت‌های فعلی سایت.</span></div>
                <div><em>🔍</em><span><b>پیش از اجرا</b> نگاشت ستون‌ها و چند ردیف نمونه را می‌بینید و اگر لازم بود عوض می‌کنید.</span></div>
                <div><em>📩</em><span><b>پیامک «موجود شد»</b> فقط از همین بخش و فقط اگر تیکش را بزنید فرستاده می‌شود.</span></div>
            </div>
        </div>

        <div class="bu-card bu-anim" id="piBusy" hidden>
            <div class="bu-live">
                <div class="bu-ring" id="piRing"><svg viewBox="0 0 150 150"><circle class="bg" cx="75" cy="75" r="62"/><circle class="fg" cx="75" cy="75" r="62"/></svg><div><b>۰٪</b><small>…</small></div></div>
                <div><h3 id="piBusyH">در حال خواندن فایل…</h3><div class="bu-note"><span class="bu-shine">ستون‌ها و کالاها بررسی می‌شوند.</span></div></div>
            </div>
        </div>

        <div id="piMap" hidden>
            <div class="bu-card bu-anim">
                <div class="bu-kpis" id="piKpi"></div>
            </div>
            <div class="bu-card bu-anim">
                <div class="bu-row" style="justify-content:space-between;margin-bottom:10px"><h3 style="margin:0">ستون‌ها</h3><span class="bu-note" id="piSkipNote"></span></div>
                <div class="bu-map" id="piCols"></div>
                <h3 style="margin:16px 0 8px;font-size:13.5px">چند ردیف نمونه</h3>
                <div class="bu-scroll"><table class="bu-tbl" id="piTbl"></table></div>
            </div>
            <div class="bu-card bu-anim">
                <h3>گزینه‌ها</h3>
                <div class="ss-scope" style="margin-top:0">
                    <label><input type="checkbox" id="piPrice" checked><span><b>💰 قیمت‌ها به‌روز شود</b>قیمت فروش (و ستون‌های قیمتی دیگری که انتخاب شده) جایگزین می‌شود.</span></label>
                    <label><input type="checkbox" id="piName"><span><b>✏️ نام کالاها به‌روز شود</b>نام سایت با نام فایل یکی می‌شود (نام‌هایی که برای سئو ویرایش کرده‌اید هم عوض می‌شوند). خاموش باشد، هیچ نامی عوض نمی‌شود.</span></label>
                    <div id="piRenameNote" class="bu-note" style="grid-column:1/-1"></div>
                    <label><input type="checkbox" id="piStock"><span><b>✅ کالاهای داخل فایل موجود شوند</b>هر کالایی که در فایل هست در سایت موجود می‌شود و در اپ خرید و تأمین «رسیده» حساب می‌شود (کالاهای دیگر دست نمی‌خورند).</span></label>
                    <label id="piNotifyW" style="opacity:.5"><input type="checkbox" id="piNotify" disabled><span><b>📩 پیامک «موجود شد» برای مشتری‌ها</b>به مشتری‌هایی که منتظر موجود شدن این کالاها بوده‌اند پیامک می‌رود.</span></label>
                </div>
                <div class="bu-row" style="margin-top:12px;gap:8px">
                    <span class="bu-note" style="font-weight:800">واحد قیمت در فایل:</span>
                    <div class="ss-seg" style="min-width:220px" id="piUnit"><button type="button" data-u="toman" class="carton">تومان</button><button type="button" data-u="rial" class="carton">ریال (÷۱۰)</button></div>
                    <span class="bu-note" id="piUnitNote"></span>
                </div>
            </div>
            <div class="bu-dock">
                <span class="bu-note" id="piDockNote"></span>
                <div class="bu-row"><button class="bu-btn" onclick="location.reload()">انصراف</button><button class="bu-btn ok lg" id="piRun">✓ اجرا روی سایت</button></div>
            </div>
        </div>

        <div class="bu-card bu-done" id="piDone" hidden>
            <div class="check">✓</div>
            <h3>اطلاعات کالاها به‌روز شد</h3>
            <div class="bu-kpis" id="piDoneKpi" style="margin:14px 0"></div>
            <div class="bu-row" style="justify-content:center" id="piDl"></div>
            <div class="bu-row" style="justify-content:center;margin-top:12px"><button class="bu-btn pri lg" onclick="location.href=location.pathname+'?tab=full'">تمام</button></div>
        </div>

        @if ($report)
            @php $s = $report['stats']; @endphp
            <div class="bu-card bu-anim" id="piLast">
                <h3>آخرین اجرا <small class="bu-note">{{ jdate($report['at'], true) }} — {{ $report['files'] }}</small></h3>
                <div class="bu-kpis">
                    @foreach ([['', $s['rows'], 'ردیف خوانده‌شده'], ['ok', $s['found'], 'کالای پیدا شده'], ['bad', $s['unknown'], 'کد ناشناخته'], ['', $s['price'], 'قیمت تغییرکرده'], ['', $s['renamed'], 'نام تغییرکرده'], ['ok', $s['instock'], 'موجود شده'], ['ok', $s['codechange'] ?? 0, 'کد عوض‌شده در هلو'], ['bad', $s['codepending'] ?? 0, 'تغییر کد در انتظار تأیید']] as [$cl, $v, $l])
                        <div class="bu-kpi {{ $cl }}"><b>{{ fa($v) }}</b><small>{{ $l }}</small></div>
                    @endforeach
                </div>
                <div class="bu-row" style="margin-top:12px">
                    @if (! empty($s['codechange']) || ! empty($s['codepending']))
                        <a class="bu-btn pri" href="{{ \App\Filament\Pages\ProductCodeChanges::getUrl() }}">🔁 تغییر کد کالاها</a>
                    @endif
                    @foreach (['codechange' => 'کدهای عوض‌شده', 'unknown' => 'کدهای ناشناخته', 'price' => 'تغییر قیمت‌ها', 'renamed' => 'تغییر نام‌ها'] as $k => $l)
                        @if (! empty($report['lists'][$k]['rows']))<a class="bu-btn" href="{{ route('admin.export.report', $k) }}">⬇ {{ $l }} ({{ fa(count($report['lists'][$k]['rows'])) }})</a>@endif
                    @endforeach
                    @if (! empty($report['lists']['unknown']['rows']))
                        <a class="bu-btn pri" href="{{ route('admin.export.photo') }}" target="_blank">📷 برگه عکاسی (PDF / چاپ)</a>
                        <a class="bu-btn" href="{{ route('admin.export.report', 'photo') }}">⬇ اکسل عکاسی</a>
                    @endif
                </div>
            </div>
        @endif
    </div>
    <canvas id="buConfetti" hidden></canvas>
</div>

<script type="module">
const $ = s => document.querySelector(s);
const fa = n => String(n ?? '').replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CSRF = document.querySelector('meta[name=csrf-token]')?.content;
const XLS = /\.(xlsx|xls|csv|xlsb)$/i, ARC = /\.(rar|zip|7z)$/i;
const KIND = { carton: 'عمده (کارتنی)', retail: 'خرده', skip: 'نادیده' };
let files = [], ID = null, PV = null, lTab = 'c_off', lMax = 40;

function kindOf(n) {
    n = n.toLowerCase();
    if (/khord|kherd|khurd|خرده|خورده|tak|تکی/.test(n)) return 'retail';
    if (/omde|omdeh|omdah|عمده|carton|karton|کارتن/.test(n)) return 'carton';
    return null;
}
function step(n) { document.querySelectorAll('#ssSteps div').forEach((s, i) => { s.className = i < n - 1 ? 'done' : i === n - 1 ? 'on' : ''; }); $('#ssTrack').style.width = ((n - 1) / 2 * 66.6) + '%'; }
async function api(url, body, isForm) {
    const r = await fetch('/admin-tools/stock-scan' + url, { method: 'POST', headers: Object.assign({ 'X-CSRF-TOKEN': CSRF, 'Accept': 'application/json' }, isForm ? {} : { 'Content-Type': 'application/json' }), body: isForm ? body : JSON.stringify(body || {}), credentials: 'same-origin' });
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (!r.ok || j.ok === false) throw new Error(j.msg || j.message || ('خطای سرور ' + r.status));
    return j;
}
function ring(pct, label) { const el = $('#ssRing'), c = el.querySelector('.fg'), L = 2 * Math.PI * 62; c.style.strokeDasharray = L; c.style.strokeDashoffset = L * (1 - pct); el.querySelector('b').textContent = fa(Math.round(pct * 100)) + '٪'; if (label) el.querySelector('small').textContent = label; }
function countUp(el, to) { const t0 = performance.now(); const f = t => { const k = Math.min(1, (t - t0) / 700); el.textContent = fa(Math.round(to * (1 - Math.pow(1 - k, 3)))); if (k < 1) requestAnimationFrame(f); }; requestAnimationFrame(f); }

/* ---------- ۱. فایل‌ها ---------- */
const drop = $('#ssDrop'), DT = 'فایل‌های اسکنر امروز را اینجا رها کنید';
['dragover', 'dragenter'].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.add('over'); $('#ssDropT').textContent = 'رها کنید! 🎯'; }));
['dragleave', 'drop'].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.remove('over'); $('#ssDropT').textContent = DT; }));
drop.addEventListener('drop', ev => take([...ev.dataTransfer.files]));
$('#ssFile').addEventListener('change', ev => take([...ev.target.files]));
$('#ssReset').onclick = () => { files = []; $('#ssPicked').hidden = true; $('#ssFile').value = ''; };

let Archive = null;
function flatten(obj, out, path) {
    for (const k in obj) { const v = obj[k]; if (v instanceof Blob) out.push({ f: v instanceof File ? v : new File([v], k), path: path }); else if (v && typeof v === 'object') flatten(v, out, (path ? path + '/' : '') + k); }
    return out;
}
async function unpack(file) {
    if (!Archive) Archive = (await import('/vendor/libarchive/libarchive.js')).Archive;
    const arc = await Archive.open(file);
    const all = flatten(await arc.extractFiles(), [], '');
    try { await arc.close(); } catch (e) {}
    // اگر نام فایل داخل آرشیو نوع را نمی‌گوید، نام پوشه یا خود آرشیو کمک می‌کند (مثلاً omde.zip/basir.xlsx)
    return all.filter(x => XLS.test(x.f.name) && !x.f.name.startsWith('~$') && !x.f.name.startsWith('.')).map(x => ({ file: x.f, hint: kindOf(x.path) || kindOf(file.name) }));
}
async function take(list) {
    drop.classList.add('busy'); $('#ssDropT').textContent = 'در حال باز کردن فایل‌ها…';
    try {
        for (const f of list) {
            if (ARC.test(f.name)) (await unpack(f)).forEach(x => add(x.file, x.hint));
            else if (XLS.test(f.name) && !f.name.startsWith('~$')) add(f, null);
        }
    } catch (e) { alert('باز کردن فایل فشرده ناموفق بود: ' + e.message); }
    drop.classList.remove('busy'); $('#ssDropT').textContent = DT;
    showPicked();
}
function add(f, hint) {
    if (files.some(x => x.file.name === f.name && x.file.size === f.size)) return;
    files.push({ file: f, kind: kindOf(f.name) || hint || null });
}
function fileCard(x, i, extra) {
    const k = x.kind || 'ask';
    return `<div class="ss-file ${k}" style="animation-delay:${i * 40}ms"><div class="h"><em>XLSX</em><div><b>${esc(x.name || x.file.name)}</b><small>${extra || (x.file ? fa(Math.ceil(x.file.size / 1024)) + ' کیلوبایت' : '')}</small></div></div>`
        + `<div class="ss-seg">${['carton', 'retail', 'skip'].map(t => `<button type="button" data-i="${i}" data-k="${t}" class="${t}${x.kind === t ? ' on' : ''}">${KIND[t]}</button>`).join('')}</div>`
        + (x.kind ? '' : '<div class="ss-flag bad">نوع این فایل از نامش معلوم نیست؛ یکی را انتخاب کنید.</div>')
        + (x.flags || []).map(f => `<div class="ss-flag ${f[0]}">${esc(f[1])}</div>`).join('') + '</div>';
}
function showPicked() {
    if (!files.length) return;
    const c = files.filter(x => x.kind === 'carton').length, r = files.filter(x => x.kind === 'retail').length, a = files.filter(x => !x.kind).length;
    $('#ssPickKpi').innerHTML = [['', c, 'فایل عمده (کارتنی)', '📦'], ['ok', r, 'فایل خرده', '🧺'], ...(a ? [['bad', a, 'نوع نامعلوم', '❓']] : [])]
        .map(([cl, n, l, ic], i) => `<div class="bu-kpi ${cl}" style="animation-delay:${i * 60}ms"><em>${ic}</em><b>${fa(n)}</b><small>${l}</small></div>`).join('');
    $('#ssFiles').innerHTML = files.map((x, i) => fileCard(x, i)).join('');
    $('#ssGo').disabled = !files.some(x => x.kind === 'carton' || x.kind === 'retail') || files.some(x => !x.kind);
    $('#ssPicked').hidden = false;
}
document.addEventListener('click', e => {
    const b = e.target.closest('.ss-seg button'); if (!b) return;
    const i = +b.dataset.i;
    if (b.closest('#ssFiles')) { files[i].kind = b.dataset.k; showPicked(); }
    else if (PV) { PV.files[i].kind = b.dataset.k; drawFiles2(); }
});

/* ---------- ۲. بررسی ---------- */
$('#ssGo').onclick = async () => {
    $('#ssPick').hidden = true; $('#ssBusy').hidden = false; step(2); ring(.05, 'آپلود');
    try {
        ID = (await api('/start')).id;
        const fd = new FormData(); files.filter(x => x.kind !== 'skip').forEach(x => { fd.append('files[]', x.file); fd.append('names[]', x.file.name); });
        const up = await api('/' + ID + '/file', fd, true); ring(.5, 'بررسی');
        const kinds = {}; files.filter(x => x.kind !== 'skip').forEach((x, i) => { if (up.saved[i]) kinds[up.saved[i]] = x.kind; });
        await analyze(kinds);
    } catch (e) { alert(e.message); location.reload(); }
};
async function analyze(kinds) {
    $('#ssBusyH').textContent = 'مقایسه با کالاهای سایت…';
    PV = await api('/' + ID + '/analyze', { kinds, scope: document.querySelector('input[name=ssScope]:checked').value });
    ring(1, 'آماده'); $('#ssBusy').hidden = true; $('#ssPrev').hidden = false; step(2);
    drawPrev();
}
function drawFiles2() {
    $('#ssFiles2').innerHTML = PV.files.map((f, i) => fileCard(f, i, fa(f.unique) + ' کد · ' + fa(f.known) + ' کالای سایت · ' + fa(f.unknown) + ' ناشناخته' + (f.kind ? ' · ' + fa(f.retail_rate) + '٪ خرده‌دار' : ''))).join('');
}
function drawPrev() {
    const c = PV.counts, bad = PV.warnings.filter(w => w[0] === 'bad');
    $('#ssWarn').innerHTML = bad.length ? `<div class="ss-warn bu-anim"><h4>⚠️ پیش از اعمال، این‌ها را بررسی کنید</h4>${bad.map(w => `<p>• ${esc(w[1])}</p>`).join('')}</div>` : '';
    const box = (title, icon, on, off, skip, has) => has ? `<div><h4>${icon} ${title}</h4><div class="n"><span class="on"><b data-n="${on}">۰</b><small>موجود می‌شود</small></span><span class="off"><b data-n="${off}">۰</b><small>ناموجود می‌شود</small></span></div>${skip ? `<small class="bu-note">${fa(skip)} کالای موجود در انبارهای اسکن‌نشده دست نمی‌خورد</small>` : ''}</div>` : '';
    $('#ssBig').innerHTML = box('فروش کارتنی (عمده)', '📦', c.c_on, c.c_off, c.c_skip, PV.has.carton) + box('فروش خرده', '🧺', c.r_on, c.r_off, c.r_skip, PV.has.retail)
        + `<div><h4>🛒 برای مشتری</h4><div class="n"><span class="on"><b data-n="${c.buy_on}">۰</b><small>قابل خرید می‌شود</small></span><span class="off"><b data-n="${c.buy_off}">۰</b><small>از خرید خارج می‌شود</small></span></div>${PV.unknown ? `<small class="bu-note">${fa(PV.unknown)} کد در سایت پیدا نشد — <a href="/admin-tools/stock-scan/${ID}/report/unknown" style="color:var(--ac);font-weight:800">دانلود</a></small>` : ''}</div>`;
    $('#ssBig').querySelectorAll('b[data-n]').forEach(b => countUp(b, +b.dataset.n));
    $('#ssBig').insertAdjacentHTML('beforeend', `<div class="ss-tot" style="grid-column:1/-1;display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-top:4px">${[['🟢 کل موجود پس از این فایل‌ها', c.all_total], ['📦 کل کارتنی موجود', c.c_total], ['🧺 کل خرده موجود', c.r_total], ['🔴 کارتنی ناموجود می‌شود', c.c_off], ['🔴 خرده ناموجود می‌شود', c.r_off]].map(t => `<div style="padding:10px 12px;border-radius:14px;background:rgba(0,0,0,.035)"><small style="display:block;opacity:.7;font-size:12px">${t[0]}</small><b style="font-size:20px">${fa(t[1] || 0)}</b></div>`).join('')}<small class="bu-note" style="grid-column:1/-1">«کل موجود» یعنی کالاهای تازه موجودشده به‌علاوه کالاهایی که از قبل موجود بودند و تغییری نمی‌کنند. <a href="/admin-tools/stock-scan/${ID}/report/summary" style="color:var(--ac);font-weight:800">⬇ اکسل خلاصه</a></small></div>`);
    drawFiles2();
    const cov = (t, list) => list.length ? `<div style="margin-bottom:10px"><div class="bu-note" style="font-weight:800;margin-bottom:6px">${t}</div><div class="ss-cov">${list.map(w => `<span class="${w.covered ? 'y' : 'n'}">${w.covered ? '✓' : '—'} ${esc(w.name)} <small>${fa(w.hits)} اسکن از ${fa(w.avail)} موجود</small></span>`).join('')}</div></div>` : '';
    $('#ssCov').innerHTML = cov('انبارهای عمده', PV.carton_cover) + cov('انبارهای خرده', PV.retail_cover) + (PV.scope === 'all' ? '<p class="ss-flag wa">حالت «همه انبارها»: هر کالایی که در فایل‌ها نیست ناموجود می‌شود.</p>' : '');
    const T = [['c_off', 'کارتنی ناموجود می‌شود', c.c_off], ['c_on', 'کارتنی موجود می‌شود', c.c_on], ['r_off', 'خرده ناموجود می‌شود', c.r_off], ['r_on', 'خرده موجود می‌شود', c.r_on]].filter(t => t[2]);
    if (T.length && !T.some(t => t[0] === lTab)) lTab = T[0][0];
    $('#ssLTabs').innerHTML = T.map(([k, l, n]) => `<button data-l="${k}" class="${lTab === k ? 'on' : ''}">${l}<em>${fa(n)}</em></button>`).join('') + (T.length ? `<a class="bu-btn" style="min-height:32px;font-size:12px" href="/admin-tools/stock-scan/${ID}/report/${lTab}">⬇ دانلود همین فهرست</a>` : '');
    const LA = (PV.samples[lTab] || []), L = LA.slice(0, lMax);
    $('#ssList').innerHTML = T.length ? `<table class="bu-tbl"><tbody>${L.map(r => `<tr class="${lTab.endsWith('on') ? 'ok' : 'wa'}"><td class="bu-ltr">${esc(fa(r.c))}</td><td><b>${esc(r.n)}</b></td><td>${esc(r.w || '')}${r.rw ? ' · ' + esc(r.rw) : ''}</td></tr>`).join('')}</tbody></table>` + (LA.length > L.length ? `<button class="bu-btn" style="width:100%" data-more>نمایش بیشتر (${fa(LA.length - L.length)})</button>` : ((T.find(t => t[0] === lTab) || [0, 0, 0])[2] > LA.length ? '<p class="bu-note">… فهرست کامل را دانلود کنید.</p>' : '')) : '<p class="bu-note" style="font-size:14px">🎉 موجودی امروز با سایت یکی است؛ تغییری لازم نیست.</p>';
    $('#ssConfirmWrap').hidden = !bad.length; $('#ssConfirm').checked = false;
    const total = c.c_on + c.c_off + c.r_on + c.r_off;
    $('#ssDockNote').innerHTML = `<b>${fa(total)}</b> تغییر آماده اعمال`;
    $('#ssApply').disabled = !total || !!bad.length;
}
$('#ssConfirm').onchange = e => { $('#ssApply').disabled = !e.target.checked; };
$('#ssLTabs').addEventListener('click', e => { const b = e.target.closest('button[data-l]'); if (b) { lTab = b.dataset.l; lMax = 40; drawPrev(); } });
$('#ssList').addEventListener('click', e => { if (e.target.closest('[data-more]')) { lMax += 80; drawPrev(); } });
$('#ssRe').onclick = async () => {
    const kinds = {}; PV.files.forEach(f => { kinds[f.name] = f.kind || 'skip'; });
    $('#ssPrev').hidden = true; $('#ssBusy').hidden = false; ring(.5, 'بررسی');
    try { await analyze(kinds); } catch (e) { alert(e.message); $('#ssBusy').hidden = true; $('#ssPrev').hidden = false; }
};
document.querySelectorAll('input[name=ssScope]').forEach(r => r.addEventListener('change', () => { if (PV) $('#ssRe').click(); }));
$('#ssCancel').onclick = () => location.reload();

/* ---------- ۳. اعمال و برگشت ---------- */
$('#ssApply').onclick = async () => {
    $('#ssApply').disabled = true; $('#ssApply').textContent = 'در حال اعمال…';
    try {
        const r = await api('/' + ID + '/apply');
        const c = r.counts || {};
        $('#ssPrev').hidden = true; $('#ssDone').hidden = false; step(3);
        document.querySelectorAll('#ssSteps div').forEach(s => s.className = 'done'); $('#ssTrack').style.width = '66.6%';
        $('#ssDoneBig').innerHTML = `<div><h4>📦 کارتنی</h4><div class="n"><span class="on"><b>${fa(c.c_on || 0)}</b><small>موجود شد</small></span><span class="off"><b>${fa(c.c_off || 0)}</b><small>ناموجود شد</small></span></div></div>`
            + `<div><h4>🧺 خرده</h4><div class="n"><span class="on"><b>${fa(c.r_on || 0)}</b><small>موجود شد</small></span><span class="off"><b>${fa(c.r_off || 0)}</b><small>ناموجود شد</small></span></div></div>`
            + (c.all_total != null ? `<p class="bu-note" style="grid-column:1/-1;font-size:14px">کل موجود اکنون: <b>${fa(c.all_total)}</b> کالا — کارتنی <b>${fa(c.c_total)}</b> · خرده <b>${fa(c.r_total)}</b> · <a href="/admin-tools/stock-scan/${ID}/report/summary" style="color:var(--ac);font-weight:800">⬇ اکسل خلاصه</a></p>` : '');
        $('#ssUndoNow').onclick = () => undo(ID);
        scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) { alert(e.message); $('#ssApply').disabled = false; $('#ssApply').textContent = '✓ اعمال روی سایت'; }
};
async function undo(id) {
    if (!confirm('همه تغییرهای این به‌روزرسانی برگردانده شود؟')) return;
    try { const r = await api('/' + id + '/undo'); alert('برگردانده شد: موجودی ' + fa(r.n) + ' کالا به حالت قبل برگشت.'); location.reload(); }
    catch (e) { alert(e.message); }
}
document.querySelectorAll('[data-undo]').forEach(b => b.onclick = () => undo(b.dataset.undo));

/* ================= اطلاعات کالا (فایل قیمت) ================= */
let PI = null;
function piStep(n) { document.querySelectorAll('#piSteps div').forEach((s, i) => { s.className = i < n - 1 ? 'done' : i === n - 1 ? 'on' : ''; }); $('#piTrack').style.width = ((n - 1) / 2 * 66.6) + '%'; }
function piRing(pct, label) { const el = $('#piRing'), c = el.querySelector('.fg'), L = 2 * Math.PI * 62; c.style.strokeDasharray = L; c.style.strokeDashoffset = L * (1 - pct); el.querySelector('b').textContent = fa(Math.round(pct * 100)) + '٪'; if (label) el.querySelector('small').textContent = label; }
async function piApi(url, body) {
    const r = await fetch('/admin-tools/price-import' + url, { method: 'POST', headers: { 'X-CSRF-TOKEN': CSRF, 'Accept': 'application/json' }, body, credentials: 'same-origin' });
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (!r.ok || j.ok === false) throw new Error(j.msg || (r.status === 413 ? 'حجم فایل از سقف آپلود هاست بیشتر است؛ فایل را zip کنید.' : r.status >= 500 ? 'خطای سرور ' + r.status + ' (حافظه/زمان هاست کافی نبود؛ اگر تکرار شد فایل را به csv یا چند فایل کوچک‌تر تبدیل کنید)' : j.message || ('خطای سرور ' + r.status)));
    return j;
}
const piDrop = $('#piDrop'), PDT = 'فایل قیمت هلو را اینجا رها کنید';
['dragover', 'dragenter'].forEach(e => piDrop.addEventListener(e, ev => { ev.preventDefault(); piDrop.classList.add('over'); $('#piDropT').textContent = 'رها کنید! 🎯'; }));
['dragleave', 'drop'].forEach(e => piDrop.addEventListener(e, ev => { ev.preventDefault(); piDrop.classList.remove('over'); $('#piDropT').textContent = PDT; }));
piDrop.addEventListener('drop', ev => piTake([...ev.dataTransfer.files]));
$('#piFile').addEventListener('change', ev => piTake([...ev.target.files]));

async function piTake(list) {
    let xs = [];
    try {
        for (const f of list) {
            if (ARC.test(f.name)) xs.push(...(await unpack(f)).map(x => x.file));
            else if (XLS.test(f.name) && !f.name.startsWith('~$')) xs.push(f);
        }
    } catch (e) { alert('باز کردن فایل فشرده ناموفق بود: ' + e.message); return; }
    if (!xs.length) { alert('فایل اکسل (xlsx / xls / csv) پیدا نشد.'); return; }
    $('#piPick').hidden = true; $('#piBusy').hidden = false; piStep(2); piRing(.15, 'آپلود');
    const fd = new FormData(); xs.forEach(f => { fd.append('files[]', f); fd.append('names[]', f.name); });
    try {
        PI = await piApi('/start', fd);
        piRing(1, 'آماده'); $('#piBusy').hidden = true; $('#piMap').hidden = false;
        piDraw();
    } catch (e) { alert(e.message); location.href = location.pathname + '?tab=full'; }
}
function piDraw() {
    const opts = Object.entries(PI.fields);
    const has = k => PI.mapping.includes(k);
    $('#piKpi').innerHTML = [['', PI.rows, 'ردیف کالا در فایل', '🧾'], ['ok', PI.matched, 'کالای پیدا شده در سایت', '🔗'], [PI.rows - PI.matched > 0 ? 'wa' : '', Math.max(0, PI.rows - PI.matched), 'کد ناشناخته / تکراری', '❔'], ['', PI.files.length, 'فایل', '📄']]
        .map(([cl, n, l, ic], i) => `<div class="bu-kpi ${cl}" style="animation-delay:${i * 60}ms"><em>${ic}</em><b>${fa(n)}</b><small>${l}</small></div>`).join('');
    $('#piSkipNote').textContent = PI.skip ? 'سطر عنوان ستون‌ها پیدا شد' + (PI.skip > 1 ? '؛ ' + fa(PI.skip - 1) + ' سطر عنوان گزارش بالای آن خوانده نمی‌شود' : '') : 'فایل سطر عنوان ندارد؛ ستون‌ها از روی داده‌ها حدس زده شد';
    $('#piCols').innerHTML = PI.headers.map((h, j) => `<label class="${PI.mapping[j] ? 'on' : 'off'}"><span>${esc(h)}<i>${esc(fa(PI.sample[0]?.[j] ?? ''))}</i></span><select data-col="${j}" class="bu-in">${opts.map(([k, l]) => `<option value="${esc(k)}"${PI.mapping[j] === k ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`).join('');
    const used = PI.mapping.map((m, j) => m ? j : -1).filter(j => j >= 0);
    $('#piTbl').innerHTML = '<thead><tr>' + used.map(j => `<th>${esc(PI.fields[PI.mapping[j]])}</th>`).join('') + '</tr></thead><tbody>' + PI.sample.map(r => '<tr>' + used.map(j => `<td${PI.mapping[j] === 'name' ? ' style="font-weight:800"' : ''}>${esc(fa(r[j]))}</td>`).join('') + '</tr>').join('') + '</tbody>';
        + '<tbody>' + PI.sample.map(r => '<tr>' + r.map((v, j) => `<td class="${PI.mapping[j] ? '' : 'bu-note'}" style="${PI.mapping[j] ? 'font-weight:700' : 'opacity:.5'}">${esc(fa(v))}</td>`).join('') + '</tr>').join('') + '</tbody>';
    document.querySelectorAll('#piUnit button').forEach(b => b.classList.toggle('on', b.dataset.u === PI.unit));
    $('#piUnitNote').textContent = PI.unitAuto === false ? '' : 'خودکار تشخیص داده شد';
    const ok = has('code');
    $('#piDockNote').innerHTML = ok ? `<b>${fa(PI.matched)}</b> کالا به‌روز می‌شود` : '<span style="color:var(--bad);font-weight:800">ستون «کد کالا / بارکد» را انتخاب کنید</span>';
    $('#piRun').disabled = !ok;
    const rn = PI.renames || 0;
    $('#piRenameNote').innerHTML = rn ? `<div style="background:rgba(245,158,11,.12);border-radius:12px;padding:10px 12px;line-height:1.9"><b>⚠️ ${fa(rn)} کالا در فایل نامی متفاوت با سایت دارند.</b> فقط اگر تیک «نام کالاها به‌روز شود» روشن باشد عوض می‌شوند (گزارش کامل پس از اجرا).<br>${(PI.rename_sample || []).map(x => `<small style="display:block">«${esc(x.from)}» ← «${esc(x.to)}»</small>`).join('')}</div>` : (has('name') ? '<small>✓ نام همه کالاهای پیدا شده با سایت یکی است.</small>' : '');
}
$('#piCols').addEventListener('change', e => {
    const s = e.target.closest('select[data-col]'); if (!s) return;
    const j = +s.dataset.col, v = s.value;
    if (v) PI.mapping = PI.mapping.map((m, i) => (i !== j && m === v) ? '' : m); // هر فیلد فقط یک ستون
    PI.mapping[j] = v; piDraw();
});
$('#piUnit').addEventListener('click', e => { const b = e.target.closest('button[data-u]'); if (b) { PI.unit = b.dataset.u; PI.unitAuto = false; piDraw(); } });
$('#piStock').onchange = e => { const on = e.target.checked; $('#piNotify').disabled = !on; if (!on) $('#piNotify').checked = false; $('#piNotifyW').style.opacity = on ? 1 : .5; };
$('#piRun').onclick = async () => {
    if ($('#piName').checked && (PI.renames || 0) > 0 && !confirm('نام ' + fa(PI.renames) + ' کالا با نام فایل جایگزین می‌شود. ادامه می‌دهید؟')) return;
    if ($('#piNotify').checked && !confirm('برای مشتری‌های منتظر کالاهایی که موجود می‌شوند پیامک فرستاده شود؟')) return;
    $('#piRun').disabled = true; $('#piMap').hidden = true; $('#piBusy').hidden = false; $('#piBusyH').textContent = 'در حال به‌روزرسانی کالاها…'; piRing(.5, 'اجرا');
    const fd = new FormData();
    PI.mapping.forEach(m => fd.append('mapping[]', m));
    fd.append('skip', PI.skip); fd.append('unit', PI.unit);
    fd.append('update_price', $('#piPrice').checked ? 1 : 0); fd.append('update_name', $('#piName').checked ? 1 : 0);
    fd.append('instock', $('#piStock').checked ? 1 : 0); fd.append('notify', $('#piNotify').checked ? 1 : 0);
    try {
        const r = await piApi('/' + PI.token + '/run', fd), s = r.stats;
        $('#piBusy').hidden = true; $('#piDone').hidden = false; piStep(3);
        document.querySelectorAll('#piSteps div').forEach(x => x.className = 'done'); $('#piTrack').style.width = '66.6%';
        $('#piLast')?.remove();
        $('#piDoneKpi').innerHTML = [['', s.rows, 'ردیف خوانده‌شده'], ['ok', s.found, 'کالای پیدا شده'], ['bad', s.unknown, 'کد ناشناخته'], ['', s.price, 'قیمت تغییرکرده'], ['', s.renamed, 'نام تغییرکرده'], ['ok', s.instock, 'موجود شده'], ['ok', s.codechange, 'کد عوض‌شده در هلو'], ['bad', s.codepending, 'تغییر کد در انتظار تأیید']]
            .filter(([cl, n, l], i) => i < 6 || n).map(([cl, n, l], i) => `<div class="bu-kpi ${cl}" style="animation-delay:${i * 60}ms"><b>${fa(n || 0)}</b><small>${l}</small></div>`).join('');
        $('#piDl').innerHTML = ((s.codechange || s.codepending) ? `<a class="bu-btn pri" href="{{ \App\Filament\Pages\ProductCodeChanges::getUrl() }}">🔁 تغییر کد کالاها</a>` : '') + [['codechange', 'کدهای عوض‌شده'], ['unknown', 'کدهای ناشناخته'], ['price', 'تغییر قیمت‌ها'], ['renamed', 'تغییر نام‌ها']].filter(([k]) => r.lists[k])
            .map(([k, l]) => `<a class="bu-btn" href="/admin-tools/export/report/${k}">⬇ ${l} (${fa(r.lists[k])})</a>`).join('')
            + (r.lists.unknown ? `<a class="bu-btn pri" href="/admin-tools/export/photo" target="_blank">📷 برگه عکاسی (PDF / چاپ)</a><a class="bu-btn" href="/admin-tools/export/report/photo">⬇ اکسل عکاسی</a>` : '');
        scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) { alert(e.message); $('#piBusy').hidden = true; $('#piMap').hidden = false; $('#piRun').disabled = false; }
};
</script>
</x-filament-panels::page>
