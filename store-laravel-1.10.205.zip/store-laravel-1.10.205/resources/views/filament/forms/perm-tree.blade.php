@php
    $tree = \App\Models\User::PERM_TREE;
    $L = \App\Models\User::PERMISSIONS;
    $keysOf = fn ($n) => \App\Models\User::permKeys($n);
@endphp
<x-dynamic-component :component="$getFieldWrapperView()" :field="$field">
<div class="pt" x-data="{
        state: $wire.$entangle('{{ $getStatePath() }}'),
        has(k) { return Array.isArray(this.state) && this.state.includes(k) },
        cnt(ks) { return ks.filter(k => this.has(k)).length },
        set(ks, on) { let s = new Set(Array.isArray(this.state) ? this.state : []); ks.forEach(k => on ? s.add(k) : s.delete(k)); this.state = [...s] },
        all() { return @js(array_keys($L)) },
    }">
    <div class="pt-top">
        <button type="button" class="pt-mini" x-on:click="set(all(), true)">انتخاب همه</button>
        <button type="button" class="pt-mini" x-on:click="set(all(), false)">هیچ‌کدام</button>
        <button type="button" class="pt-mini" x-on:click="$dispatch('pt-open', true)">باز کردن همه</button>
        <button type="button" class="pt-mini" x-on:click="$dispatch('pt-open', false)">بستن همه</button>
        <span class="pt-sum" x-text="(Array.isArray(state) ? state.filter(k => all().includes(k)).length : 0).toLocaleString('fa-IR') + ' از {{ fa(count($L)) }} دسترسی'"></span>
    </div>
    @foreach ($tree as $g)
        @php $gk = $keysOf($g); @endphp
        <div class="pt-g" x-data="{ open: false }" x-on:pt-open.window="open = $event.detail" :class="{ 'on': cnt(@js($gk)) > 0 }">
            <div class="pt-gh">
                <input type="checkbox" class="pt-cb" :checked="cnt(@js($gk)) === {{ count($gk) }}" x-effect="$el.indeterminate = cnt(@js($gk)) > 0 && cnt(@js($gk)) < {{ count($gk) }}" x-on:change="set(@js($gk), $event.target.checked)">
                <button type="button" class="pt-gt" x-on:click="open = !open">
                    <span class="pt-ic">{{ $g['i'] }}</span><b>{{ $g['t'] }}</b>
                    <em class="pt-n" x-text="cnt(@js($gk)).toLocaleString('fa-IR') + ' از {{ fa(count($gk)) }}'"></em>
                    <svg class="pt-ch" :class="{ 'up': open }" viewBox="0 0 20 20" width="18" height="18"><path fill="currentColor" d="M5.3 7.3a1 1 0 0 1 1.4 0L10 10.6l3.3-3.3a1 1 0 1 1 1.4 1.4l-4 4a1 1 0 0 1-1.4 0l-4-4a1 1 0 0 1 0-1.4Z"/></svg>
                </button>
            </div>
            <div class="pt-body" x-show="open" x-collapse>
                @foreach ($g['c'] as $it)
                    @php $ik = $keysOf($it); $kids = $it['c'] ?? []; @endphp
                    <div class="pt-it">
                        <label class="pt-row">
                            <input type="checkbox" class="pt-cb" :checked="has('{{ $it['k'] }}')" x-on:change="set(@js($ik), $event.target.checked)">
                            <span>{{ $L[$it['k']] }}</span>
                            @if ($kids)<em class="pt-n sm" x-text="cnt(@js(array_slice($ik, 1))).toLocaleString('fa-IR') + ' از {{ fa(count($ik) - 1) }}'"></em>@endif
                        </label>
                        @if ($kids)
                            <div class="pt-sub">
                                @foreach ($kids as $sub)
                                    @php $sk = $keysOf($sub); @endphp
                                    <label class="pt-row">
                                        <input type="checkbox" class="pt-cb" :checked="has('{{ $sub['k'] }}')" x-on:change="set(@js($sk), $event.target.checked); if ($event.target.checked) set(['{{ $it['k'] }}'], true)">
                                        <span>{{ $L[$sub['k']] }}</span>
                                    </label>
                                @endforeach
                            </div>
                        @endif
                    </div>
                @endforeach
            </div>
        </div>
    @endforeach
</div>
<style>
.pt{display:flex;flex-direction:column;gap:8px}
.pt-top{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-bottom:2px}
.pt-mini{font-size:12px;padding:4px 10px;border-radius:8px;border:1px solid rgb(0 0 0/.1);background:transparent;cursor:pointer}
.dark .pt-mini{border-color:rgb(255 255 255/.12)}
.pt-sum{margin-inline-start:auto;font-size:12px;opacity:.7}
.pt-g{border:1px solid rgb(0 0 0/.09);border-radius:14px;overflow:hidden;transition:border-color .2s,box-shadow .2s}
.dark .pt-g{border-color:rgb(255 255 255/.1)}
.pt-g.on{border-color:rgb(var(--primary-500)/.45);box-shadow:0 0 0 3px rgb(var(--primary-500)/.08)}
.pt-gh{display:flex;align-items:center;gap:10px;padding:0 14px;background:rgb(127 127 127/.05)}
.pt-gt{flex:1;display:flex;align-items:center;gap:10px;padding:12px 0;background:none;border:0;cursor:pointer;text-align:right;color:inherit}
.pt-gt b{font-size:14px}
.pt-ic{font-size:18px}
.pt-n{font-style:normal;font-size:11.5px;padding:1px 8px;border-radius:20px;background:rgb(127 127 127/.12);margin-inline-start:auto}
.pt-g.on .pt-n:not(.sm){background:rgb(var(--primary-500)/.15);color:rgb(var(--primary-600))}
.pt-n.sm{margin-inline-start:6px;font-size:11px}
.pt-ch{transition:transform .2s;opacity:.6}.pt-ch.up{transform:rotate(180deg)}
.pt-body{padding:6px 14px 10px}
.pt-it{border-bottom:1px dashed rgb(127 127 127/.18)}.pt-it:last-child{border-bottom:0}
.pt-row{display:flex;align-items:center;gap:10px;padding:8px 0;cursor:pointer;font-size:13.5px;line-height:1.7}
.pt-sub{padding-inline-start:28px;margin:-2px 0 6px;border-inline-start:2px solid rgb(var(--primary-500)/.25)}
.pt-sub .pt-row{padding:5px 10px;font-size:13px;opacity:.9}
.pt-cb{width:18px;height:18px;border-radius:5px;flex:none;accent-color:rgb(var(--primary-600));cursor:pointer}
</style>
</x-dynamic-component>
