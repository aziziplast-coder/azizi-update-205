@php
    $open = (int) request('u');
    $threads = \App\Models\ChatThread::query()->whereNotNull('team_user_id')->get()->keyBy('team_user_id');
    $rows = \App\Services\TeamChat::operators()
        ->map(function ($op) use ($threads) {
            $t = $threads->get($op->id);

            return (object) ['u' => $op, 't' => $t, 'unread' => (int) ($t->unread_staff ?? 0), 'at' => $t?->last_at];
        })
        ->sortByDesc(fn ($x) => [$x->unread > 0 ? 1 : 0, $x->at ? $x->at->timestamp : 0])->values();
@endphp
<x-filament-panels::page>
<div wire:ignore>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:12px">
        <h1 style="margin:0;font-size:22px;font-weight:900">💬 گپ با اپراتورها</h1>
        <input type="search" id="tc-q" placeholder="جستجوی نام همکار…" class="fc-q">
    </div>
    <p style="margin:0 0 12px;font-size:12.5px;opacity:.7">اپراتورها از منوی «فروش ← گپ با حسابدار کل» پیام می‌دهند (عکس فیش، ویس، ویدیو). پیام تازه با اعلان گوشی/مرورگر خبر داده می‌شود؛ همه حسابدارهای کل همین گفتگوها را می‌بینند.</p>
    <div class="fc-list">
        @forelse ($rows as $x)
            @php
                $op = $x->u; $t = $x->t; $nm = $op->displayName();
                $cfg = [
                    'plain' => true, 'side' => 's', 'hash' => 'tc-'.$op->id, 'autoOpen' => $open === (int) $op->id,
                    'csrf' => csrf_token(), 'state' => route('admin.tchat', $op->id), 'act' => route('admin.tchat.act', $op->id), 'typing' => url('chat-t.php'),
                    'up' => route('admin.tchat.up'), 'mb' => asset('js/vendor/mediabunny.min.js'),
                    'sig' => $t ? \App\Services\Chat::signalUrl($t) : null, 'last' => (int) ($t->staff_read_id ?? 0), 'unread' => $x->unread,
                    'title' => $nm, 'sub' => trim(fa((string) $op->mobile)), 'initial' => mb_substr($nm, 0, 1),
                    'custName' => $nm, 'custInitial' => mb_substr($nm, 0, 1), 'phone' => $op->mobile,
                    'empty' => '<i>💬</i><b>هنوز پیامی رد و بدل نشده</b><br>پیام شما در پنل '.e($nm).' («گپ با حسابدار کل») نمایش داده می‌شود.',
                ];
            @endphp
            <div class="fc-row" data-q="{{ $nm }} {{ $op->mobile }} {{ fa((string) $op->mobile) }}" data-chat="{{ json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) }}">
                <button type="button" class="chc-card fc-card">
                    <span class="ch-av">{{ mb_substr($nm, 0, 1) }}</span>
                    <div>
                        <b>{{ $nm }}</b>
                        <small>{{ $t && $t->last_text ? ($t->last_side === 's' ? 'شما: ' : '').$t->last_text : fa((string) $op->mobile) }}</small>
                    </div>
                    <span class="go">@if ($t && $t->last_at)<i class="fc-at">{{ $t->last_at->isToday() ? fa($t->last_at->timezone('Asia/Tehran')->format('H:i')) : jdate($t->last_at) }}</i>@endif @if ($x->unread)<em>{{ fa(min(9, $x->unread)) }}</em>@endif</span>
                </button>
            </div>
        @empty
            <div style="padding:30px;text-align:center;opacity:.7">همکار دیگری تعریف نشده است.</div>
        @endforelse
    </div>
</div>
@include('filament.partials.team-chat-style')
<script>
(function () {
    function init() {
        if (!window.StoreChat) return setTimeout(init, 60);
        document.querySelectorAll('.fc-row[data-chat]').forEach(function (r) { if (!r.dataset.init) { r.dataset.init = 1; StoreChat.customer(r); } });
        var q = document.getElementById('tc-q');
        if (q && !q.dataset.init) {
            q.dataset.init = 1;
            q.addEventListener('input', function () {
                var v = q.value.trim().toLowerCase();
                document.querySelectorAll('.fc-row').forEach(function (r) { r.hidden = v && r.dataset.q.toLowerCase().indexOf(v) < 0; });
            });
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
</script>
</x-filament-panels::page>
