<x-filament-panels::page>
    <div style="font-size:13px;opacity:.8;margin-bottom:-8px">سفارش چکی مشتریان جدید تا اینجا تأیید نشود، در «سفارش‌ها»، پیگیری و چاپ فاکتور دیده نمی‌شود. بعد از استعلام چک در اپ بانک (شناسه صیادی + کد ملی) تأیید یا رد کنید.</div>
    {{ $this->table }}
</x-filament-panels::page>
