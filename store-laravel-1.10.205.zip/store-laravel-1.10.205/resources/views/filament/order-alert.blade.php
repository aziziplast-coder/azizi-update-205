@if (setting('order_alert', true) && auth()->user()?->hasPerm('orders'))
<script data-navigate-once>
window.storeAlert = {!! json_encode([
    'url' => route('admin.alerts'),
    'sound' => setting('order_sound', 'chime'),
    'repeat' => (bool) setting('order_repeat', true),
    'icon' => '/pwa-icon-192.png',
], JSON_UNESCAPED_SLASHES) !!};
</script>
<script data-navigate-once src="/js/order-alert.js?v={{ config('store.version') }}" defer></script>
@endif
<script data-navigate-once>
// تبدیل ارقام فارسی به انگلیسی در فیلدهای عددی پنل
document.addEventListener('input', function (e) {
    var t = e.target;
    if (!t || t.tagName !== 'INPUT') return;
    var im = t.getAttribute('inputmode');
    if (!(im === 'numeric' || im === 'decimal' || im === 'tel' || t.type === 'number' || t.type === 'tel' || t.hasAttribute('data-en'))) return;
    var v = t.value.replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }).replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
    if (v !== t.value) { t.value = v; }
}, true);
</script>
<script data-navigate-once>
// در موبایل منوی کناری هنگام باز شدن صفحه بسته باشد
(function () {
    function closeOnMobile() {
        if (window.innerWidth < 1024 && window.Alpine && Alpine.store('sidebar')) { Alpine.store('sidebar').close(); }
    }
    if (window.Alpine && Alpine.store && Alpine.store('sidebar')) { closeOnMobile(); }
    document.addEventListener('alpine:initialized', closeOnMobile);
    document.addEventListener('livewire:navigated', closeOnMobile);
})();
</script>
@if (\App\Services\WebPush::enabled())
<script data-navigate-once>
window.pushErrText = function (e) {
    var m = (e && e.message) || '';
    if (m === 'denied' || (e && e.name === 'NotAllowedError')) return 'اجازه اعلان داده نشد. از تنظیمات مرورگر (آیکون قفل کنار آدرس) اعلان‌ها را مجاز کنید.';
    if (/push service|AbortError|Registration failed/i.test(m + (e && e.name))) return 'مرورگر نتوانست به سرویس اعلان وصل شود (' + m + '). کروم در ایران برای اعلان به سرویس گوگل نیاز دارد که معمولاً بدون فیلترشکن در دسترس نیست؛ فایرفاکس یا اج را امتحان کنید.';
    return 'فعال نشد: ' + m;
};
window.adminPush = function () {
    var key = @json(\App\Services\WebPush::keys()['public']);
    function b64u(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; var r = atob(s), a = new Uint8Array(r.length); for (var i = 0; i < r.length; i++) a[i] = r.charCodeAt(i); return a; }
    if (!window.isSecureContext) { alert('اعلان فقط روی آدرس https کار می‌کند.'); return; }
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) { alert('این مرورگر از اعلان پشتیبانی نمی‌کند. (در آیفون ابتدا سایت را به صفحه اصلی اضافه کنید)'); return; }
    Notification.requestPermission().then(function (p) {
        if (p !== 'granted') throw new Error('denied');
        return navigator.serviceWorker.register('/sw.js', { scope: '/' }).then(function () { return navigator.serviceWorker.ready; });
    }).then(function (reg) {
        return reg.pushManager.getSubscription().then(function (s) { return s || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(key) }); });
    }).then(function (sub) {
        var j = sub.toJSON(); j.staff = 1;
        return fetch(@json(route('push.subscribe')), { method: 'POST', body: JSON.stringify(j), credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'X-CSRF-TOKEN': @json(csrf_token()) } });
    }).then(function (r) { alert(r && r.ok ? 'اعلان سفارش‌های جدید روی این دستگاه فعال شد ✓' : 'ثبت نشد؛ دوباره تلاش کنید.'); })
      .catch(function (e) { alert(window.pushErrText ? window.pushErrText(e) : 'فعال نشد: ' + (e && e.message)); });
};
</script>
@endif
