@php
    $tabs = [
        'bots' => ['🤖 ربات‌ها (هاست ربات)', \App\Filament\Resources\BotProfileResource::getUrl('index')],
        'posts' => ['📋 پست‌ها', \App\Filament\Resources\BotPostResource::getUrl('index')],
        'msgs' => ['📣 پیام به کانال‌ها', \App\Filament\Resources\BotBroadcastResource::getUrl('index')],
        'site' => ['⚙️ ارسال از خود سایت', \App\Filament\Pages\Settings\ChannelSettings::getUrl()],
    ];
    $hold = \App\Services\BotHub::ready() ? \App\Models\BotPost::query()->where('state', 'hold')->count() : 0;
@endphp
<nav style="display:flex;gap:6px;flex-wrap:wrap;background:rgba(127,127,127,.08);padding:5px;border-radius:14px;width:fit-content;max-width:100%">
    @foreach ($tabs as $k => [$label, $url])
        <a href="{{ $url }}" style="padding:7px 14px;border-radius:10px;font-size:13px;font-weight:700;white-space:nowrap;{{ $active === $k ? 'background:rgb(var(--primary-600));color:#fff' : 'opacity:.8' }}">
            {{ $label }}@if ($k === 'posts' && $hold) <span style="background:#f59e0b;color:#fff;border-radius:99px;padding:0 6px;font-size:11px">{{ fa($hold) }}</span>@endif
        </a>
    @endforeach
</nav>
