@php
    $st = \App\Services\DocArchive::stats();
    $cats = \App\Services\DocArchive::cats();
    $cfg = \App\Services\DocArchive::cfg();
    $h = fn ($b) => \App\Services\DocArchive::human((float) $b);
    $total = array_sum(array_column($st['cats'], 'size'));
@endphp
<x-filament-panels::page>
    <div class="da-grid">
        @foreach ($cats as $k => $c)
            @php $x = $st['cats'][$k] ?? ['n' => 0, 'size' => 0]; @endphp
            <div class="da-card">
                <div class="da-top"><span class="da-ic">{{ $c['icon'] }}</span><b>{{ $c['title'] }}</b></div>
                <div class="da-num">{{ $h($x['size']) }} <small>· {{ fa(number_format($x['n'])) }} فایل</small></div>
                <div class="da-bar"><i style="width:{{ $total > 0 ? max(2, round($x['size'] / $total * 100)) : 0 }}%"></i></div>
                <div class="da-path"><span>مسیر روی هاست:</span> <code dir="ltr">{{ $c['path'] }}</code></div>
                <div class="da-note">{{ $c['note'] }}</div>
            </div>
        @endforeach
    </div>

    <div class="da-box">
        <div class="da-row">
            <b>وضعیت نگهداری</b>
            <span class="da-chip {{ $cfg['shrink'] ? 'ok' : '' }}">{{ $cfg['shrink'] ? '✓ فیش‌های تأییدشده قدیمی‌تر از '.fa($cfg['shrink_months']).' ماه خودکار کوچک می‌شوند' : 'کوچک کردن فیش‌های قدیمی خاموش است' }}</span>
            <span class="da-chip {{ $cfg['delete_years'] ? 'warn' : 'ok' }}">{{ $cfg['delete_years'] ? '⚠ فایل فیش‌های قدیمی‌تر از '.fa($cfg['delete_years']).' سال پاک می‌شود' : '✓ هیچ فیشی خودکار پاک نمی‌شود' }}</span>
            <span class="da-chip">💬 رسانه گفتگو: {{ ($d = \App\Services\Chat::cfg()['img_days']) ? 'بعد از '.fa($d).' روز پاک می‌شود' : 'هرگز پاک نمی‌شود' }}</span>
        </div>
        <p class="da-muted">پوشه سایت روی هاست: <code dir="ltr" style="background:rgba(127,127,127,.12);padding:2px 6px;border-radius:6px">{{ base_path() }}</code> — ORDER-ID = شناسه سفارش (هر سفارش یک پوشه)، YYYY-MM = سال و ماه.<br>این پوشه‌ها خصوصی‌اند و از اینترنت مستقیم باز نمی‌شوند؛ فقط همکاران حسابداری از داخل پنل می‌بینند. در «پشتیبان‌گیری» هاست (cPanel) هم همراه سایت ذخیره می‌شوند.
            آخرین محاسبه حجم: {{ jdate(\Illuminate\Support\Carbon::createFromTimestamp($st['at']), true) }}@if ($st['partial']) (تقریبی؛ تعداد فایل زیاد بود)@endif</p>
    </div>

    <div class="da-box">
        <div class="da-row" style="justify-content:space-between"><b>🧾 فیش‌ها ماه‌به‌ماه</b><span class="da-muted">دانلود: یک فایل zip با نام هر فیش «شماره سفارش-مبلغ-وضعیت» + فهرست</span></div>
        @if ($st['months'])
            <div style="overflow-x:auto">
                <table class="da-tbl">
                    <thead><tr><th>ماه</th><th>تعداد فیش</th><th>تأییدشده</th><th>حجم</th><th></th></tr></thead>
                    <tbody>
                        @foreach ($st['months'] as $ym => $m)
                            <tr>
                                <td><b>{{ \App\Services\DocArchive::ymLabel($ym) }}</b></td>
                                <td>{{ fa(number_format($m['n'])) }}</td>
                                <td>{{ fa(number_format($m['confirmed'])) }}</td>
                                <td>{{ $h($m['size']) }}</td>
                                <td><a class="da-dl" href="{{ route('admin.docarchive.zip', ['m' => $ym]) }}">⬇ دانلود zip</a></td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <p class="da-muted">هنوز فیشی ثبت نشده است.</p>
        @endif
    </div>
    <style>
        .da-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 12px; }
        .da-card, .da-box { background: #fff; border: 1px solid rgba(127,127,127,.18); border-radius: 16px; padding: 14px 16px; }
        .dark .da-card, .dark .da-box { background: rgb(var(--gray-900)); }
        .da-top { display: flex; align-items: center; gap: 8px; font-size: 14px; }
        .da-ic { font-size: 20px; }
        .da-num { font-size: 22px; font-weight: 900; margin: 8px 0 6px; }
        .da-num small { font-size: 12.5px; font-weight: 600; opacity: .65; }
        .da-bar { height: 6px; border-radius: 9px; background: rgba(127,127,127,.15); overflow: hidden; }
        .da-bar i { display: block; height: 100%; background: rgb(var(--primary-500)); border-radius: 9px; }
        .da-path { margin-top: 10px; font-size: 12px; display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
        .da-path span { opacity: .65; }
        .da-path code { background: rgba(127,127,127,.12); padding: 2px 6px; border-radius: 6px; font-size: 11.5px; word-break: break-all; }
        .da-note, .da-muted { font-size: 12px; opacity: .7; margin-top: 6px; line-height: 1.9; }
        .da-row { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
        .da-chip { font-size: 12px; padding: 3px 10px; border-radius: 999px; background: rgba(127,127,127,.12); }
        .da-chip.ok { background: #dcfce7; color: #166534; } .da-chip.warn { background: #fef3c7; color: #92400e; }
        .dark .da-chip.ok { background: #14532d88; color: #bbf7d0; } .dark .da-chip.warn { background: #78350f88; color: #fde68a; }
        .da-tbl { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }
        .da-tbl th, .da-tbl td { padding: 8px 10px; border-bottom: 1px solid rgba(127,127,127,.12); text-align: right; white-space: nowrap; }
        .da-tbl th { font-size: 12px; opacity: .65; font-weight: 600; }
        .da-dl { color: rgb(var(--primary-600)); font-weight: 700; }
    </style>
</x-filament-panels::page>
