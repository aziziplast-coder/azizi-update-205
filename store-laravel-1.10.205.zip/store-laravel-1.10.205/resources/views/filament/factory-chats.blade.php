@php
    $u = auth()->user();
    $open = (int) request('f');
    $threads = \App\Models\ChatThread::query()->whereNotNull('factory_id')->get()->keyBy('factory_id');
    $rows = \App\Models\Factory::query()->where(fn ($q) => $q->where('active', true)->orWhereIn('id', $threads->keys()))->orderBy('name')->get()
        ->map(function ($f) use ($threads) {
            $t = $threads->get($f->id);

            return (object) ['f' => $f, 't' => $t, 'unread' => (int) ($t->unread_staff ?? 0), 'at' => $t?->last_at];
        })
        ->sortByDesc(fn ($x) => [$x->unread > 0 ? 1 : 0, $x->at ? $x->at->timestamp : 0])->values();
@endphp
<x-filament-panels::page>
<div wire:ignore>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:12px">
        <h1 style="margin:0;font-size:22px;font-weight:900">🏭 گفتگو با کارخانه‌دارها</h1>
        <input type="search" id="fc-q" placeholder="جستجوی نام یا موبایل…" class="fc-q">
    </div>
    <p style="margin:0 0 12px;font-size:12.5px;opacity:.7">کارخانه‌دار از «{{ \App\Services\FactoryPortal::cfg()['name'] }}» ← «گفتگو» پیام می‌دهد. پاسخ شما همان‌جا دیده می‌شود و اگر نخوانده باشد، حداکثر هر ۳ ساعت یک پیامک «پیام تازه» برایش می‌رود.</p>
    <div class="fc-list">
        @forelse ($rows as $x)
            @php
                $f = $x->f; $t = $x->t;
                $cfg = [
                    'plain' => true, 'side' => 's', 'hash' => 'fc-'.$f->id, 'autoOpen' => $open === (int) $f->id,
                    'csrf' => csrf_token(), 'state' => route('admin.fchat', $f->id), 'act' => route('admin.fchat.act', $f->id), 'typing' => url('chat-t.php'),
                    'up' => route('admin.fchat.up'), 'mb' => asset('js/vendor/mediabunny.min.js'),
                    'sig' => $t ? \App\Services\Chat::signalUrl($t) : null, 'last' => (int) ($t->staff_read_id ?? 0), 'unread' => $x->unread,
                    'title' => $f->name, 'sub' => trim(($f->isThird() ? 'شخص ثالث · ' : '').($f->company ? $f->company.' · ' : '').fa($f->mobile)), 'initial' => mb_substr($f->name, 0, 1),
                    'custName' => $f->name, 'custInitial' => mb_substr($f->name, 0, 1), 'phone' => $f->mobile,
                    'empty' => '<i>💬</i><b>هنوز پیامی رد و بدل نشده</b><br>پیام شما در اپ کارخانه‌داران به '.e($f->name).' نمایش داده می‌شود.',
                ];
            @endphp
            <div class="fc-row" data-q="{{ $f->name }} {{ $f->mobile }} {{ fa($f->mobile) }} {{ $f->company }}" data-chat="{{ json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) }}">
                <button type="button" class="chc-card fc-card">
                    <span class="ch-av">{{ mb_substr($f->name, 0, 1) }}</span>
                    <div>
                        <b>{{ $f->name }} @if ($f->isThird())<small class="fc-tag">شخص ثالث</small>@endif</b>
                        <small>{{ $t && $t->last_text ? ($t->last_side === 's' ? 'شما: ' : '').$t->last_text : fa($f->mobile) }}</small>
                    </div>
                    <span class="go">@if ($t && $t->last_at)<i class="fc-at">{{ $t->last_at->isToday() ? fa($t->last_at->timezone('Asia/Tehran')->format('H:i')) : jdate($t->last_at) }}</i>@endif @if ($x->unread)<em>{{ fa(min(9, $x->unread)) }}</em>@endif</span>
                </button>
            </div>
        @empty
            <div style="padding:30px;text-align:center;opacity:.7">هنوز کارخانه‌داری تعریف نشده است (حسابداری ← کارخانه‌دارها).</div>
        @endforelse
    </div>
</div>
<style>
    .fc-q { border: 1px solid rgba(127,127,127,.25); border-radius: 12px; padding: 8px 12px; min-width: 240px; background: transparent; }
    .fc-list { display: flex; flex-direction: column; gap: 8px; max-width: 760px; --brand: rgb(var(--primary-600)); --card: #fff; --muted: #6b7280; }
    .dark .fc-list { --card: rgb(var(--gray-900)); --muted: #9ca3af; }
    .fc-card { width: 100%; text-align: right; padding: 10px 14px; border-radius: 16px; }
    .fc-card .ch-av { width: 44px; height: 44px; font-size: 18px; }
    .fc-card b { font-size: 14.5px; }
    .fc-card small.fc-tag { display: inline-block; font-size: 11px; font-weight: 600; background: rgba(127,127,127,.15); color: inherit; border-radius: 6px; padding: 1px 6px; margin: 0 4px 0 0; vertical-align: middle; }
    .fc-card .go { background: transparent; color: inherit; padding: 0; flex-direction: column; align-items: flex-end; gap: 4px; font-weight: 600; }
    .fc-card .go em { position: static; background: #25d366; }
    .fc-at { font-style: normal; font-size: 11px; opacity: .65; }
</style>
<script>
(function () {
    function init() {
        if (!window.StoreChat) return setTimeout(init, 60);
        document.querySelectorAll('.fc-row[data-chat]').forEach(function (r) { if (!r.dataset.init) { r.dataset.init = 1; StoreChat.customer(r); } });
        var q = document.getElementById('fc-q');
        if (q && !q.dataset.init) {
            q.dataset.init = 1;
            q.addEventListener('input', function () {
                var v = q.value.trim().toLowerCase();
                document.querySelectorAll('.fc-row').forEach(function (r) { r.hidden = v && r.dataset.q.toLowerCase().indexOf(v) < 0; });
            });
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
</script>
</x-filament-panels::page>
