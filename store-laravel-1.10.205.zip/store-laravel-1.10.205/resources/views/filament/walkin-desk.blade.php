<x-filament-panels::page>
    @php
        $c = $this->counts();
        $k = $this->kpis();
        $tabs = $this->tabs();
        $max = max(1, collect($k['days'])->max('n'));
        $T = [
            'scanned' => ['منتظر تحویل', 'M3 7h18M5 7l1.5 12h11L19 7M9 7V5a3 3 0 0 1 6 0v2', $c['scanned'], null],
            'loaded' => ['بارگیری‌شده', 'M3 13h11V6H3zM14 9h4l3 4v4h-7zM6.5 20a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM17.5 20a2 2 0 1 0 0-4 2 2 0 0 0 0 4z', $c['loaded'], '۳۰ روز'],
            'returned' => ['مرجوعی', 'M9 14L4 9l5-5M4 9h11a5 5 0 0 1 0 10h-3', $c['returned'], '۳۰ روز'],
            'draft' => ['در حال اسکن', 'M4 7V5a1 1 0 0 1 1-1h2M17 4h2a1 1 0 0 1 1 1v2M20 17v2a1 1 0 0 1-1 1h-2M7 20H5a1 1 0 0 1-1-1v-2M8 8v8M11 8v8M14 8v8M17 8v8', $c['draft'], null],
            'done' => ['پایان‌یافته', 'M5 12l4 4L19 6', $c['done'], '۳۰ روز'],
        ];
        $NOTE = [
            'scanned' => 'بارکدزن اسکن کرده و به دفتر فرستاده؛ تحویل‌دهنده هنگام بارگیری دوباره اسکن می‌کند. اکسل هلو در این مرحله طبق اسکن اول است.',
            'loaded' => 'بار تحویل شده؛ اکسل هلو طبق شمارش تحویل‌دهنده است. ردیف‌های با اختلاف قرمز علامت خورده‌اند.',
            'returned' => 'مرجوعی‌های حضوری؛ اکسل هلو به ترتیب سالم، ایراد کارخانه، ضایعات — با «تا اینجا …» در ستون توضیحات.',
            'draft' => 'فاکتورهایی که بارکدزن شروع کرده و هنوز نفرستاده؛ اکسل هلو طبق اسکن تا همین لحظه.',
            'done' => 'فاکتورهایی که «پایان» خورده‌اند؛ با «بازگرداندن» به مرحله قبل برمی‌گردند.',
        ];
    @endphp

    <style>
        .wkd{--ink:#0b1220;--ac:#0ea5a4;--ac2:#22d3ee;--card:#fff;--line:rgb(15 23 42/.08);--mut:rgb(15 23 42/.55)}
        .dark .wkd{--card:rgb(255 255 255/.04);--line:rgb(255 255 255/.08);--mut:rgb(255 255 255/.55)}
        /* سربرگ داشبوردی */
        .wkd-hero{position:relative;overflow:hidden;border-radius:24px;padding:22px;background:radial-gradient(120% 140% at 100% 0%,#1d3a66 0%,#0b1220 55%);color:#e2e8f0;box-shadow:0 18px 40px rgb(11 18 32/.25)}
        .wkd-hero::after{content:'';position:absolute;inset:auto -60px -80px auto;width:260px;height:260px;border-radius:50%;background:radial-gradient(circle,rgb(34 211 238/.18),transparent 70%)}
        .wkd-top{display:flex;align-items:center;gap:14px;flex-wrap:wrap;position:relative;z-index:1}
        .wkd-top img{width:52px;height:52px;border-radius:16px;box-shadow:0 8px 24px rgb(34 211 238/.25)}
        .wkd-top h2{margin:0;font-size:21px;font-weight:900;color:#fff}
        .wkd-top p{margin:2px 0 0;font-size:12.5px;color:#94a3b8}
        .wkd-top .lnk{margin-inline-start:auto;display:flex;gap:8px;flex-wrap:wrap}
        .wkd-top .lnk a,.wkd-top .lnk span{font-size:12px;font-weight:700;padding:7px 12px;border-radius:999px;background:rgb(255 255 255/.08);color:#cbd5e1;text-decoration:none;border:1px solid rgb(255 255 255/.08)}
        .wkd-top .lnk a:hover{background:rgb(255 255 255/.14)}
        .wkd-hero,.wkd-tabs{min-width:0;max-width:100%}
        .wkd-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-top:18px;position:relative;z-index:1}
        .wkd-kpi{border-radius:16px;padding:12px 14px;background:rgb(255 255 255/.06);border:1px solid rgb(255 255 255/.07)}
        .wkd-kpi small{display:block;font-size:11.5px;color:#94a3b8;font-weight:700}
        .wkd-kpi b{display:block;font-size:24px;font-weight:900;color:#fff;margin-top:4px;line-height:1.2}
        .wkd-kpi b em{font-style:normal;font-size:12px;color:#94a3b8;font-weight:700;margin-inline-start:4px}
        .wkd-kpi.ac b{color:#5eead4}.wkd-kpi.warn b{color:#fbbf24}.wkd-kpi.bad b{color:#fb7185}
        .wkd-kpi.chart{grid-column:span 2;display:flex;align-items:flex-end;gap:12px}
        .wkd-bars{flex:1;display:flex;align-items:flex-end;gap:6px;height:58px}
        .wkd-bars div{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;height:100%;justify-content:flex-end}
        .wkd-bars i{display:block;width:100%;max-width:22px;border-radius:6px 6px 3px 3px;background:linear-gradient(180deg,#5eead4,#0891b2);min-height:3px}
        .wkd-bars div.today i{background:linear-gradient(180deg,#fde68a,#f59e0b)}
        .wkd-bars span{font-size:10px;color:#94a3b8;font-weight:700}
        /* سربرگ‌ها */
        .wkd-tabs{display:flex;gap:6px;padding:6px;border-radius:18px;background:var(--card);border:1px solid var(--line);overflow-x:auto;box-shadow:0 1px 2px rgb(15 23 42/.04)}
        .wkd-tab{flex:1;min-width:max-content;display:flex;align-items:center;justify-content:center;gap:9px;padding:11px 16px;border-radius:13px;font-weight:800;font-size:14px;color:var(--mut);cursor:pointer;transition:.15s;border:0;background:none}
        .wkd-tab svg{width:19px;height:19px}
        .wkd-tab .ct{font-size:12px;font-weight:900;min-width:24px;height:22px;padding:0 7px;border-radius:999px;display:inline-grid;place-items:center;background:rgb(127 127 127/.12)}
        .wkd-tab .ct small{font-weight:700;font-size:10px;opacity:.7;margin-inline-start:3px}
        .wkd-tab:hover{background:rgb(127 127 127/.07)}
        .wkd-tab.on{background:linear-gradient(135deg,#0f766e,#0891b2);color:#fff;box-shadow:0 8px 20px rgb(8 145 178/.28)}
        .wkd-tab.on .ct{background:rgb(255 255 255/.22);color:#fff}
        .wkd-note{display:flex;gap:10px;align-items:flex-start;font-size:12.5px;line-height:1.9;color:var(--mut);padding:2px 6px}
        .wkd-note i{font-style:normal;width:22px;height:22px;flex:none;border-radius:8px;display:grid;place-items:center;background:rgb(14 165 164/.12);color:#0f766e;font-size:12px;font-weight:900}
        /* خانه‌های جدول */
        .wkd-cust{display:flex;align-items:center;gap:11px;min-width:220px}
        .wkd-cust b{font-size:14.5px;font-weight:800}
        .wkd-av{width:40px;height:40px;flex:none;border-radius:13px;display:grid;place-items:center;font-weight:900;font-size:16px;color:#fff}
        .wkd-av.h0{background:linear-gradient(135deg,#0f766e,#14b8a6)}.wkd-av.h1{background:linear-gradient(135deg,#1d4ed8,#60a5fa)}.wkd-av.h2{background:linear-gradient(135deg,#7c3aed,#a78bfa)}
        .wkd-av.h3{background:linear-gradient(135deg,#be123c,#fb7185)}.wkd-av.h4{background:linear-gradient(135deg,#b45309,#fbbf24)}.wkd-av.h5{background:linear-gradient(135deg,#0e7490,#22d3ee)}
        .wkd-meta{display:flex;gap:6px;flex-wrap:wrap;margin-top:3px;font-size:11.5px;color:var(--mut);align-items:center}
        .wkd-meta{gap:8px}
        .wkd-code{font-weight:900;font-size:11px;padding:1px 7px;border-radius:6px;background:rgb(14 165 164/.12);color:#0f766e;letter-spacing:.3px}
        .wkd-code.ret{background:rgb(234 88 12/.12);color:#c2410c}
        .dark .wkd-code{color:#5eead4}.dark .wkd-code.ret{color:#fdba74}
        
        .wkd-bay{display:inline-flex;font-weight:900;font-size:13.5px;padding:5px 11px;border-radius:10px;background:rgb(127 127 127/.08);white-space:nowrap}
        .wkd-load b{font-size:16px;font-weight:900}.wkd-load small{display:block;font-size:11.5px;color:var(--mut)}
        .wkd-money{font-weight:900;font-size:15px;white-space:nowrap}.wkd-money small{font-size:11px;color:var(--mut);margin-inline-start:4px;font-weight:700}
        .wkd-flow{display:grid;gap:4px;font-size:12.5px;min-width:170px}
        .wkd-flow div{display:flex;align-items:center;gap:6px}
        .wkd-flow i{font-style:normal;width:20px;height:20px;border-radius:7px;display:grid;place-items:center;background:rgb(127 127 127/.1);font-size:11px;flex:none}
        .wkd-flow span{font-weight:700}.wkd-flow small{color:var(--mut);font-size:11px}
        .wkd-flow .wait span{color:#b45309;font-weight:800}.dark .wkd-flow .wait span{color:#fbbf24}
        .wkd-pills{display:flex;flex-wrap:wrap;gap:5px;max-width:230px}
        .wkd-pill{font-size:11.5px;font-weight:800;padding:3px 9px;border-radius:999px;white-space:nowrap;background:rgb(127 127 127/.1)}
        .wkd-pill.blue{background:rgb(37 99 235/.12);color:#1d4ed8}.wkd-pill.green{background:rgb(22 163 74/.13);color:#15803d}.wkd-pill.amber{background:rgb(217 119 6/.13);color:#b45309}
        .wkd-pill.orange{background:rgb(234 88 12/.13);color:#c2410c}.wkd-pill.red{background:rgb(225 29 72/.13);color:#be123c}.wkd-pill.green-soft{color:#15803d;background:transparent;border:1px solid rgb(22 163 74/.3)}
        .wkd-pill.soft{color:#0f766e;background:rgb(14 165 164/.1)}.wkd-pill.dash{border:1px dashed rgb(127 127 127/.4);background:transparent;color:var(--mut)}
        .dark .wkd-pill.blue{color:#93c5fd}.dark .wkd-pill.green,.dark .wkd-pill.green-soft{color:#86efac}.dark .wkd-pill.amber{color:#fcd34d}.dark .wkd-pill.orange{color:#fdba74}.dark .wkd-pill.red{color:#fda4af}.dark .wkd-pill.soft{color:#5eead4}
        .wkd-row-bad{box-shadow:inset 4px 0 0 #e11d48}
        /* پنجره اقلام */
        .wkm-info{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
        .wkm-info b{display:block;font-size:16px;font-weight:900}.wkm-info span{font-size:12.5px;color:rgb(127 127 127)}
        .wkm-info .ppl{margin-inline-start:auto;display:grid;gap:3px;text-align:left;font-size:12px}
        .wkm-sum{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:8px;margin:14px 0}
        .wkm-sum div{border-radius:14px;padding:10px 12px;background:rgb(127 127 127/.07)}
        .wkm-sum div.wide{background:linear-gradient(135deg,#0b1220,#16233f);color:#fff}
        .wkm-sum small{display:block;font-size:11px;font-weight:700;opacity:.65}
        .wkm-sum b{font-size:19px;font-weight:900}.wkm-sum b em{font-style:normal;font-size:11px;opacity:.7}
        .wkm-sum .wide b{color:#5eead4}.wkm-sum .bad{background:rgb(225 29 72/.1);color:#be123c}.wkm-sum .ok{background:rgb(22 163 74/.1);color:#15803d}.wkm-sum .unk{background:rgb(234 88 12/.1);color:#c2410c}
        .wkm-list{display:grid;gap:6px;max-height:55vh;overflow:auto;padding-inline-end:2px}
        .wkm-it{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:14px;border:1px solid rgb(127 127 127/.14);border-inline-start:4px solid transparent}
        .wkm-it .n{width:24px;font-size:11.5px;font-weight:800;color:rgb(127 127 127);text-align:center;flex:none}
        .wkm-it .t{flex:1;min-width:0}.wkm-it .t b{display:block;font-size:13.5px;font-weight:800}.wkm-it .t small{font-size:11.5px;color:rgb(127 127 127)}
        .wkm-it .t em{font-style:normal;color:#c2410c;font-weight:700}
        .wkm-it .q{flex:none;min-width:92px;text-align:center;font-weight:900;font-size:13.5px;padding:5px 8px;border-radius:10px;background:rgb(127 127 127/.07)}
        .wkm-it .q small{display:block;font-size:10px;font-weight:700;opacity:.6}
        .wkm-it .q.dim{opacity:.7}.wkm-it .q.m{min-width:110px;background:none}
        .wkm-it .q i{font-style:normal;color:#e11d48}
        .wkm-it.over,.wkm-it.less{border-inline-start-color:#e11d48;background:rgb(225 29 72/.05)}.wkm-it.unk{border-inline-start-color:#ea580c;background:rgb(234 88 12/.05)}
        .wkm-grp{font-size:12.5px;font-weight:900;margin:8px 4px 2px}.wkm-grp.factory{color:#b45309}.wkm-grp.waste{color:#be123c}.wkm-grp.ok{color:#15803d}
        @media (max-width:700px){.wkd-kpi.chart{grid-column:span 1}.wkm-it{flex-wrap:wrap}.wkm-it .t{flex-basis:calc(100% - 40px)}}
    </style>

    <div class="wkd" style="display:grid;grid-template-columns:minmax(0,1fr);gap:14px;min-width:0" wire:poll.60s>
        <section class="wkd-hero">
            <div class="wkd-top">
                <img src="{{ asset('img/walkin-192.png') }}" alt="">
                <div><h2>فروش حضوری</h2><p>اسکن بار مشتری، تطبیق هنگام تحویل و خروجی مستقیم هلو</p></div>
                <div class="lnk">
                    <a href="{{ url('/walkin') }}" target="_blank">📱 اپ «{{ \App\Services\Walkin::appName() }}»</a>
                    <span dir="ltr">{{ preg_replace('#^https?://#', '', url('/walkin')) }}</span>
                </div>
            </div>
            <div class="wkd-kpis">
                @if ($k['sales'])
                    <div class="wkd-kpi ac"><small>فاکتور امروز</small><b>{{ fa($k['today_n']) }}</b></div>
                    <div class="wkd-kpi"><small>جمع تقریبی امروز</small><b>{{ money($k['today_sum']) }}<em>تومان</em></b></div>
                    <div class="wkd-kpi {{ $k['waiting'] ? 'warn' : '' }}"><small>منتظر تحویل</small><b>{{ fa($k['waiting']) }}</b></div>
                    <div class="wkd-kpi"><small>بارگیری امروز</small><b>{{ fa($k['loaded_today']) }}@if ($k['diffs_today'])<em style="color:#fb7185">{{ fa($k['diffs_today']) }} با اختلاف</em>@endif</b></div>
                @endif
                <div class="wkd-kpi"><small>مرجوعی امروز</small><b>{{ fa($k['ret_today']) }}</b></div>
                <div class="wkd-kpi {{ $k['no_excel'] ? 'bad' : '' }}"><small>تمام‌شده بدون اکسل هلو</small><b>{{ fa($k['no_excel']) }}</b></div>
                @if ($k['sales'])
                    <div class="wkd-kpi chart"><div><small>۷ روز اخیر</small><b>{{ fa(collect($k['days'])->sum('n')) }}<em>فاکتور</em></b></div>
                        <div class="wkd-bars">@foreach ($k['days'] as $ix => $d)<div @class(['today' => $ix === 6]) title="{{ $d['date'] }} — {{ fa($d['n']) }} فاکتور · {{ money($d['sum']) }} تومان"><i style="height:{{ max(4, round($d['n'] * 100 / $max)) }}%"></i><span>{{ $d['label'] }}</span></div>@endforeach</div></div>
                @endif
            </div>
        </section>

        <nav class="wkd-tabs">
            @foreach ($T as $key => [$label, $icon, $n, $sfx])
                @if (in_array($key, $tabs, true))
                    <button type="button" wire:click="setTab('{{ $key }}')" @class(['wkd-tab', 'on' => $tab === $key])>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="{{ $icon }}"/></svg>
                        {{ $label }} <span class="ct" @if ($sfx) title="{{ $sfx }} اخیر" @endif>{{ fa($n) }}</span>
                    </button>
                @endif
            @endforeach
        </nav>
        <div class="wkd-note"><i>i</i><span>{{ $NOTE[$tab] ?? '' }}</span></div>

        {{ $this->table }}
    </div>
</x-filament-panels::page>
