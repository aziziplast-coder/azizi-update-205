@php $lv = fn ($p) => $p === null ? '' : ($p >= 92 ? 'bad' : ($p >= 80 ? 'warn' : '')); @endphp
<x-filament-widgets::widget>
    <x-filament::section heading="وضعیت هاست" icon="heroicon-o-server-stack" wire:poll.60s.visible>
        <div style="display:grid;gap:12px;font-size:13px">
            @if ($live['mem'])
                <div><div style="display:flex;justify-content:space-between"><span>رم ({{ $live['mem']['src'] }})</span><b>{{ fa($live['mem_pct']) }}٪</b></div>
                <div class="meter {{ $lv($live['mem_pct']) }}"><i style="width:{{ $live['mem_pct'] }}%"></i></div>
                <small style="opacity:.6">{{ \App\Services\HostHealth::size($live['mem']['used']) }} از {{ \App\Services\HostHealth::size($live['mem']['total']) }}</small></div>
            @endif
            @if ($live['disk'])
                <div><div style="display:flex;justify-content:space-between"><span>دیسک</span><b>{{ fa($live['disk_pct']) }}٪</b></div>
                <div class="meter {{ $lv($live['disk_pct']) }}"><i style="width:{{ $live['disk_pct'] }}%"></i></div>
                <small style="opacity:.6">{{ \App\Services\HostHealth::size($live['disk']['free']) }} آزاد</small></div>
            @endif
            @if ($live['cpu_pct'] !== null)
                <div><div style="display:flex;justify-content:space-between"><span>پردازنده ({{ fa($live['cpus']) }} هسته)</span><b>{{ fa($live['cpu_pct']) }}٪</b></div>
                <div class="meter {{ $lv($live['cpu_pct']) }}"><i style="width:{{ $live['cpu_pct'] }}%"></i></div></div>
            @endif
            <div style="display:flex;justify-content:space-between;opacity:.75"><span>پاسخ پایگاه داده</span><span>{{ fa($live['db_ms']) }} میلی‌ثانیه</span></div>
            @php($early = \App\Support\SlowLog::earlyFinish())
            <div style="display:flex;justify-content:space-between;opacity:.75"><span>اجرای PHP</span><span dir="ltr">{{ PHP_SAPI }}</span></div>
            @if (! $early)<div style="font-size:12px;color:#b45309;line-height:1.8">⚠ «پاسخ زودهنگام» روی این هاست نیست (PHP-FPM یا LiteSpeed). پیامک و اعلان‌ها ممکن است کلیک کارمندان را کند کنند؛ از پشتیبانی هاست بخواهید PHP را روی PHP-FPM یا LSAPI بگذارد.</div>@endif
            @php($slow = \App\Support\SlowLog::recent(8))
            @if ($slow)
                <details><summary style="cursor:pointer">🐢 درخواست‌های کند اخیر ({{ fa(count($slow)) }})</summary>
                    <div style="display:grid;gap:4px;margin-top:6px;font-size:11.5px">
                        @foreach ($slow as $x)
                            <div style="display:flex;justify-content:space-between;gap:8px"><span dir="ltr" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $x['m'] }} {{ $x['p'] }}</span><span style="white-space:nowrap">{{ fa(round(($x['ms'] + ($early ? 0 : $x['after'])) / 1000, 1)) }} ث{{ ! $early && $x['after'] > 500 ? ' (بعد از پاسخ '.fa(round($x['after'] / 1000, 1)).')' : '' }} · {{ fa(substr($x['t'], 11, 5)) }}</span></div>
                        @endforeach
                    </div></details>
            @endif
            <a href="{{ \App\Filament\Pages\HostHealthPage::getUrl() }}" style="color:rgb(var(--primary-600));font-weight:700">جزئیات سلامت هاست ←</a>
        </div>
    </x-filament::section>
</x-filament-widgets::widget>
