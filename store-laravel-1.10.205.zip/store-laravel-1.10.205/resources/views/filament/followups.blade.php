<x-filament-panels::page>
    @if ($this->isLocked())
        <div style="padding:14px 18px;border-radius:14px;background:rgb(254 226 226);color:rgb(153 27 27);font-weight:700;line-height:2">
            🔒 پنل شما تا پیگیری سفارش‌های زیر قفل است. برای هر سفارش «به‌روزرسانی وضعیت» را بزنید و توضیح پیگیری را بنویسید.
            اگر سفارش هنوز در همان مرحله است، همان وضعیت را با توضیح ثبت کنید تا مهلت تمدید شود.
        </div>
    @else
        @php $h = \App\Models\Order::followupHours(); @endphp
        <div style="font-size:13px;opacity:.75">
            زمان مجاز: پرداخت بیعانه {{ fa($h['on_hold']) }} ساعت · جمع‌آوری انبار {{ fa($h['processing']) }} ساعت · تسویه حساب {{ fa($h['settling'] ?? 24) }} ساعت · ارسال‌شده {{ $h['shipped'] ? fa($h['shipped']).' ساعت' : 'بدون محدودیت' }}
            — قابل تغییر در «تنظیمات › سفارش و پیگیری».
        </div>
    @endif
    {{ $this->table }}
</x-filament-panels::page>
