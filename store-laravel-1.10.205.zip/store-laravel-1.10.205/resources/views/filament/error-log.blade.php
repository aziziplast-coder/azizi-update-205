@php
    $ST = [
        'again' => ['⚠️ دوباره رخ داده', '#dc2626'], 'open' => ['🆕 باز — بررسی نشده', '#ea580c'], 'pending' => ['🔜 رفع در نسخه جدیدتر', '#2563eb'],
        'transient' => ['⏳ موقت حین به‌روزرسانی', '#64748b'], 'acked' => ['👁 بررسی شد', '#64748b'], 'fixed' => ['✅ برطرف شد', '#16a34a'],
    ];
    $tabs = ['open' => ['باز', ($counts['open'] ?? 0) + ($counts['again'] ?? 0)], 'pending' => ['رفع در نسخه بعد', $counts['pending'] ?? 0], 'fixed' => ['برطرف‌شده', $counts['fixed'] ?? 0],
        'transient' => ['موقت', $counts['transient'] ?? 0], 'acked' => ['بررسی‌شده', $counts['acked'] ?? 0], 'all' => ['همه', $total]];
@endphp
<x-filament-panels::page>
<style>
.el-top{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.el-tab{border:1px solid rgba(127,127,127,.25);background:transparent;border-radius:20px;padding:6px 14px;font-size:13px;font-weight:700;cursor:pointer}
.el-tab.on{background:rgb(var(--primary-600));border-color:rgb(var(--primary-600));color:#fff}
.el-tab b{font-size:11px;opacity:.8;margin-right:4px}
.el-sp{flex:1}
.el-c{border:1px solid rgba(127,127,127,.18);border-right:4px solid var(--c);border-radius:14px;padding:12px 14px;margin-top:10px;background:#fff}
.dark .el-c{background:rgba(255,255,255,.03)}
.el-h{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.el-st{font-size:12px;font-weight:800;color:var(--c);background:color-mix(in srgb,var(--c) 10%,transparent);border-radius:20px;padding:2px 10px}
.el-t{font-weight:800;font-size:14px}
.el-m{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;direction:ltr;text-align:left;background:rgba(127,127,127,.07);border-radius:10px;padding:8px 10px;margin-top:8px;word-break:break-word;white-space:pre-wrap}
.el-meta{font-size:12px;opacity:.75;margin-top:6px;line-height:1.9}
.el-why{font-size:13px;margin-top:6px;line-height:1.9}
.el-tr summary{cursor:pointer;font-size:12px;margin-top:6px;opacity:.8}
.el-empty{text-align:center;padding:40px;opacity:.7}
</style>
<div class="el-top">
    @foreach ($tabs as $k => [$l, $n])
        <button type="button" class="el-tab {{ $tab === $k ? 'on' : '' }}" wire:click="$set('tab', '{{ $k }}')">{{ $l }} <b>{{ fa($n) }}</b></button>
    @endforeach
    <span class="el-sp"></span>
    <x-filament::button size="sm" color="gray" icon="heroicon-o-arrow-down-tray" wire:click="download">گزارش برای پشتیبان</x-filament::button>
    <x-filament::button size="sm" color="gray" icon="heroicon-o-trash" wire:click="clearOld" wire:confirm="لاگ‌های قدیمی‌تر از ۱۴ روز پاک شود؟">پاک کردن لاگ‌های قدیمی</x-filament::button>
</div>
<p style="font-size:12.5px;opacity:.75;line-height:1.9;margin:0">نسخه فعلی سایت: <b>{{ fa($ver) }}</b>. خطاهای یکسان یک‌جا شمرده می‌شوند. «برطرف شد» یعنی در این نسخه رفع شده و بعد از نصبش دیگر رخ نداده؛ «موقت» یعنی فقط در چند دقیقه نصب به‌روزرسانی دیده شده (ایراد کد نیست). برای خطاهای «باز» دکمه «گزارش برای پشتیبان» را بزنید و فایل را بفرستید.</p>
@forelse ($rows as $g)
    @php [$label, $color] = $ST[$g['status']] ?? ['—', '#64748b']; @endphp
    <div class="el-c" style="--c:{{ $color }}" wire:key="e{{ $g['sig'] }}">
        <div class="el-h">
            <span class="el-st">{{ $label }}{{ $g['fixed_in'] && in_array($g['status'], ['fixed', 'again', 'pending'], true) ? ' — نسخه '.fa($g['fixed_in']) : '' }}</span>
            <span class="el-t">{{ $g['title'] ?: 'خطای ثبت‌شده' }}</span>
            <span class="el-sp"></span>
            <span style="font-size:12px;font-weight:700">×{{ fa($g['count']) }}</span>
            @if (in_array($g['status'], ['open', 'again'], true))
                <x-filament::button size="xs" color="gray" wire:click="ack('{{ $g['sig'] }}')">بررسی شد</x-filament::button>
            @endif
        </div>
        @if ($g['why'])<div class="el-why">{{ $g['why'] }}</div>@endif
        @if ($g['status'] === 'again')<div class="el-why" style="color:#dc2626;font-weight:700">بعد از نصب نسخه رفع، {{ fa($g['after'] ?? 0) }} بار دیگر رخ داده — لطفاً گزارش را برای پشتیبان بفرستید.</div>@endif
        <div class="el-m">{{ \Illuminate\Support\Str::limit($g['msg'], 500) }}</div>
        <div class="el-meta">
            @if ($g['loc'])📍 <span dir="ltr">{{ $g['loc'] }}</span> · @endif
            اولین بار: {{ jdate(\Illuminate\Support\Carbon::parse($g['first']), true) }} · آخرین بار: {{ jdate(\Illuminate\Support\Carbon::parse($g['last']), true) }}
            @if ($g['users']) · {{ fa($g['users']) }} کاربر @endif
        </div>
        @if ($g['trace'])<details class="el-tr"><summary>جزئیات فنی (ردیابی)</summary><div class="el-m">{{ $g['trace'] }}</div></details>@endif
    </div>
@empty
    <div class="el-empty">🎉 خطایی در این بخش نیست.</div>
@endforelse
</x-filament-panels::page>
