<x-filament-panels::page>
<div style="display:grid;gap:18px;font-size:13.5px">
    @if ($runs->isEmpty())
        <p style="margin:0;opacity:.8;line-height:1.9">«انبارگردانی تازه» را بزنید و سه فایل را بدهید: موجودی هلو، اسکن بارکد انبار (همان اکسل روزهای زوج) و — اگر هست — خرید شعبه‌های شیراز و اهواز.
            کالاهایی که در هلو موجودی زیاد دارند ولی در انبار اسکن نشده‌اند گزارش می‌شوند. فایل‌ها پس از خواندن پاک می‌شوند.</p>
    @endif
    @if ($runs->isNotEmpty())
        <x-filament::section heading="نتیجه" icon="heroicon-o-clipboard-document-list">
            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:12px">
                <select wire:model.live="sid" style="border:1px solid rgba(127,127,127,.35);border-radius:8px;padding:6px 10px;min-width:min(280px,100%);max-width:100%">
                    @foreach ($runs as $r)<option value="{{ $r->id }}">{{ $r->label() }}</option>@endforeach
                </select>
                <x-filament::button wire:click="export" color="success" size="sm" icon="heroicon-o-arrow-down-tray">خروجی اکسل</x-filament::button>
                <x-filament::button wire:click="deleteRun" wire:confirm="این نتیجه حذف شود؟" color="gray" size="sm">حذف این نتیجه</x-filament::button>
            </div>
            @if ($cur)
                @php $s = $cur->stats; @endphp
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin-bottom:14px">
                    <div style="padding:12px;border-radius:12px;background:rgba(220,38,38,.08)"><small style="opacity:.7">در هلو هست، در انبار نیست</small><div style="font-size:22px;font-weight:800;color:#b91c1c">{{ fa(number_format($s['missing'] ?? 0)) }} کالا</div><small>{{ fa(number_format($s['missing_qty'] ?? 0)) }} عدد{{ ! empty($s['missing_value']) ? ' — ارزش '.money($s['missing_value']) : '' }}</small></div>
                    <div style="padding:12px;border-radius:12px;background:rgba(217,119,6,.1)"><small style="opacity:.7">تکراری (۲ بار یا بیشتر پشت سر هم)</small><div style="font-size:22px;font-weight:800;color:#b45309">{{ fa($s['repeat'] ?? 0) }} کالا</div><small>احتمال گم شدن بیشتر</small></div>
                    <div style="padding:12px;border-radius:12px;background:rgba(127,127,127,.08)"><small style="opacity:.7">ردیف‌های هلو / بارکدهای اسکن</small><div style="font-size:18px;font-weight:800">{{ fa(number_format($s['holoo_rows'] ?? 0)) }} / {{ fa(number_format($s['scan_codes'] ?? 0)) }}</div><small>حداقل گزارش: {{ fa($cur->settings['min'] ?? 100) }}</small></div>
                    <div style="padding:12px;border-radius:12px;background:rgba(127,127,127,.08)"><small style="opacity:.7">خرید شعبه‌ها</small><div style="font-size:18px;font-weight:800">{{ fa($s['branch_reduced'] ?? 0) }} کسر / {{ fa($s['excluded'] ?? 0) }} حذف</div></div>
                </div>
                <div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap">
                    <x-filament::button wire:click="$set('kind', 'missing')" :color="$kind === 'missing' ? 'danger' : 'gray'" size="sm">در هلو هست، در انبار نیست ({{ fa($s['missing'] ?? 0) }})</x-filament::button>
                    <x-filament::button wire:click="$set('kind', 'extra')" :color="$kind === 'extra' ? 'warning' : 'gray'" size="sm">در انبار اسکن شده، در هلو نیست ({{ fa($s['extra'] ?? 0) }})</x-filament::button>
                </div>
            @endif
        </x-filament::section>
    @endif
    <div>{{ $this->table }}</div>
</div>
</x-filament-panels::page>
