@php
    $u = auth()->user();
    $t = \App\Services\TeamChat::thread($u);
    $cfg = [
        'plain' => true, 'side' => 'c', 'hash' => 'tchat', 'autoOpen' => true,
        'csrf' => csrf_token(), 'state' => route('admin.tchat.me'), 'act' => route('admin.tchat.me.act'), 'typing' => url('chat-t.php'),
        'up' => route('admin.tchat.up'), 'mb' => asset('js/vendor/mediabunny.min.js'),
        'sig' => \App\Services\Chat::signalUrl($t), 'last' => (int) $t->customer_read_id, 'unread' => (int) $t->unread_customer,
        'title' => 'حسابدار کل', 'sub' => 'درباره فیش‌ها، واریزها، حواله‌ها و فاکتورها بپرسید', 'initial' => '🧾',
        'empty' => '<i>💬</i><b>سؤالی از حسابدار کل دارید؟</b><br>همین‌جا بنویسید، عکس فیش یا ویس بفرستید؛ حسابدار کل پاسخ می‌دهد.',
    ];
@endphp
<x-filament-panels::page>
<div wire:ignore>
    <h1 style="margin:0 0 12px;font-size:22px;font-weight:900">💬 گپ با حسابدار کل</h1>
    <div class="fc-list">
        <div class="fc-row" id="tchat" data-chat="{{ json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) }}">
            <button type="button" class="chc-card fc-card">
                <span class="ch-av">🧾</span>
                <div><b>حسابدار کل</b><small>{{ $t->last_text ? ($t->last_side === 'c' ? 'شما: ' : '').$t->last_text : 'درباره فیش‌ها، واریزها و حواله‌ها همین‌جا بپرسید' }}</small></div>
                <span class="go">@if ($t->unread_customer)<em>{{ fa(min(9, (int) $t->unread_customer)) }}</em>@endif 💬 باز کردن</span>
            </button>
        </div>
    </div>
</div>
@include('filament.partials.team-chat-style')
<script>
(function () {
    function init() {
        if (!window.StoreChat) return setTimeout(init, 60);
        var r = document.getElementById('tchat'); if (r && !r.dataset.init) { r.dataset.init = 1; StoreChat.customer(r); }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
</script>
</x-filament-panels::page>
