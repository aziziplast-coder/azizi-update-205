<x-filament-panels::page>
    @if ($rebuild)
        <div wire:poll.750ms="rebuildStep" style="padding:12px 16px;border-radius:14px;border:1px solid rgb(127 127 127/.2);display:grid;gap:8px">
            <b>در حال اعمال نشان روی تصاویر… {{ fa($rebuild['i']) }} از {{ fa($rebuild['total']) }}</b>
            <div style="height:10px;border-radius:99px;background:rgb(127 127 127/.15);overflow:hidden"><i style="display:block;height:100%;width:{{ $rebuild['total'] ? round($rebuild['i'] * 100 / $rebuild['total']) : 0 }}%;background:rgb(var(--primary-500))"></i></div>
        </div>
    @endif
    <x-filament-panels::form wire:submit="save">
        {{ $this->form }}
        <x-filament-panels::form.actions :actions="$this->getFormActions()" :sticky="true" />
    </x-filament-panels::form>
</x-filament-panels::page>
