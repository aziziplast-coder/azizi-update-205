<x-filament-panels::page>
    @php $c = $this->counts(); @endphp
    <style>
        .wb-tabs{display:flex;gap:8px;flex-wrap:wrap}
        .wb-tab{display:flex;align-items:center;gap:8px;padding:10px 16px;border-radius:14px;border:1px solid rgb(127 127 127/.22);background:rgb(127 127 127/.05);font-weight:800;font-size:14px;cursor:pointer}
        .wb-tab.on{background:rgb(var(--primary-600));border-color:rgb(var(--primary-600));color:#fff}
        .wb-tab small{font-weight:700;font-size:12px;padding:1px 8px;border-radius:999px;background:rgb(127 127 127/.18)}
        .wb-tab.on small{background:rgb(255 255 255/.25)}
        .wb-tab .late{background:#dc2626;color:#fff}
        .wb-note{padding:10px 14px;border-radius:12px;font-size:13px;line-height:1.9}
    </style>
    <div class="wb-tabs">
        <button type="button" wire:click="setTab('pending')" @class(['wb-tab', 'on' => $tab === 'pending'])>📤 ارسال‌نشده <small>{{ fa($c['pending']) }}</small>@if ($c['late'])<small class="late">{{ fa($c['late']) }} دیرکرد</small>@endif</button>
        <button type="button" wire:click="setTab('archive')" @class(['wb-tab', 'on' => $tab === 'archive'])>🗂 بایگانی <small>{{ fa($c['archive']) }} در ۳۰ روز</small></button>
    </div>
    @if ($tab === 'pending')
        <div class="wb-note" style="background:rgb(254 226 226);color:rgb(153 27 27)">
            سفارش‌هایی که به باربری تحویل شده‌اند ولی بیجکشان بارگذاری نشده. مهلت: <b>{{ fa(\App\Services\Shipping::waybillHours()) }} ساعت</b> پس از تحویل؛ بعد از آن هر {{ fa((int) setting('waybill_nag_hours', 3)) }} ساعت یادآوری.
            <br>اگر بار با <b>خاور مستقیم تا درِ مغازه</b> رفته، «ارسال مستقیم» را بزنید (بارنامه و شماره راننده اختیاری است).
        </div>
    @else
        <div class="wb-note" style="background:rgb(220 252 231);color:rgb(22 101 52)">بیجک‌های بارگذاری‌شده و ارسال‌های مستقیم. روی تصویر بزنید تا بزرگ شود؛ «دانلود» فایل را ذخیره می‌کند.</div>
    @endif
    {{ $this->table }}
</x-filament-panels::page>
