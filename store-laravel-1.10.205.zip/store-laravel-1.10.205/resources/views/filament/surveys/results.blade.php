<x-filament-panels::page>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
        <select wire:model.live="period" class="fi-select-input" style="border:1px solid rgba(127,127,127,.3);border-radius:8px;padding:6px 10px;background:transparent">
            <option value="30">۳۰ روز اخیر</option><option value="90">۹۰ روز اخیر</option><option value="365">یک سال</option><option value="all">همه</option>
        </select>
        <select wire:model.live="staff" style="border:1px solid rgba(127,127,127,.3);border-radius:8px;padding:6px 10px;background:transparent">
            <option value="">همه کارشناسان</option>
            @foreach ($staffList as $id => $n)<option value="{{ $id }}">{{ $n }}</option>@endforeach
        </select>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px">
        <x-filament::section><div style="font-size:12px;opacity:.7">پاسخ‌ها</div><div style="font-size:26px;font-weight:800">{{ fa($rows->count()) }}</div></x-filament::section>
        <x-filament::section><div style="font-size:12px;opacity:.7">میانگین رضایت</div><div style="font-size:26px;font-weight:800">{{ $avg ? fa(round($avg, 1)).' / ۵' : '—' }}</div></x-filament::section>
        <x-filament::section><div style="font-size:12px;opacity:.7">نخواستند نظر بدهند</div><div style="font-size:26px;font-weight:800">{{ fa($skipped) }}</div></x-filament::section>
    </div>

    @if ($byStaff->count())
        <x-filament::section heading="رضایت مشتری از هر کارشناس" icon="heroicon-o-user-group">
            <div style="display:grid;gap:8px;font-size:13.5px">
                @foreach ($byStaff as $s)
                    <div style="display:grid;grid-template-columns:160px 1fr 120px;gap:10px;align-items:center">
                        <b>{{ $s['user']?->displayName() ?? '—' }}</b>
                        <div style="height:10px;border-radius:6px;background:rgba(127,127,127,.15);overflow:hidden"><i style="display:block;height:100%;width:{{ (($s['sr'] ?? $s['r']) ?: 0) * 20 }}%;background:rgb(var(--primary-500))"></i></div>
                        <span>{{ ($s['sr'] ?? $s['r']) ? fa($s['sr'] ?? $s['r']).' / ۵' : '—' }} <small style="opacity:.6">({{ fa($s['n']) }} نظر)</small></span>
                    </div>
                @endforeach
            </div>
        </x-filament::section>
    @endif

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px">
        @foreach ($stats as $s)
            <x-filament::section :heading="$s['q']['label']">
                @if (isset($s['avg']))
                    <div style="font-size:22px;font-weight:800;margin-bottom:6px">{{ $s['avg'] ? fa($s['avg']).' / ۵' : '—' }} <small style="font-size:12px;opacity:.6">{{ fa($s['n']) }} پاسخ</small></div>
                @endif
                @if (! empty($s['dist']))
                    @php $mx = max(1, max($s['dist'])); @endphp
                    <div style="display:grid;gap:5px;font-size:12.5px">
                        @foreach ($s['dist'] as $k => $v)
                            <div style="display:grid;grid-template-columns:70px 1fr 40px;gap:8px;align-items:center">
                                <span>{{ isset($s['avg']) ? str_repeat('★', (int) $k) : $k }}</span>
                                <div style="height:8px;border-radius:5px;background:rgba(127,127,127,.15)"><i style="display:block;height:100%;border-radius:5px;width:{{ round($v / $mx * 100) }}%;background:#f59e0b"></i></div>
                                <span>{{ fa($v) }}</span>
                            </div>
                        @endforeach
                    </div>
                @endif
                @if (! empty($s['texts']))
                    <ul style="margin:0;padding-right:18px;font-size:13px;display:grid;gap:4px">@foreach ($s['texts'] as $t)<li>{{ $t }}</li>@endforeach</ul>
                @endif
            </x-filament::section>
        @endforeach
    </div>

    <x-filament::section heading="پاسخ‌ها" icon="heroicon-o-chat-bubble-left-right">
        <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;font-size:13px">
            <thead><tr style="text-align:right;opacity:.65"><th style="padding:6px">سفارش</th><th style="padding:6px">مشتری</th><th style="padding:6px">کارشناس</th><th style="padding:6px">امتیاز</th><th style="padding:6px">توضیح</th><th style="padding:6px">تاریخ</th></tr></thead>
            <tbody>
            @forelse ($rows->take(200) as $r)
                <tr style="border-top:1px solid rgba(127,127,127,.2)">
                    <td style="padding:6px">@if ($r->order)<a href="{{ \App\Filament\Resources\OrderResource::getUrl('view', ['record' => $r->order]) }}" style="color:rgb(var(--primary-600));font-weight:700">{{ fa($r->order->number) }}</a>@endif</td>
                    <td style="padding:6px">{{ $r->order?->customer_name }}</td>
                    <td style="padding:6px">{{ $r->assignee?->displayName() ?? '—' }}</td>
                    <td style="padding:6px;color:#f59e0b;white-space:nowrap">{{ $r->rating ? fa($r->rating) : '—' }}</td>
                    <td style="padding:6px">{{ $r->comment }}</td>
                    <td style="padding:6px;white-space:nowrap">{{ jdate($r->created_at, true) }}</td>
                </tr>
            @empty
                <tr><td colspan="6" style="padding:14px;text-align:center;opacity:.6">هنوز پاسخی ثبت نشده است.</td></tr>
            @endforelse
            </tbody>
        </table>
        </div>
    </x-filament::section>
</x-filament-panels::page>
