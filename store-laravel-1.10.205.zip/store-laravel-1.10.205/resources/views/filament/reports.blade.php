@php
    $r = $this->reports();
    $s = $r->summary();
    $daily = $r->daily();
    $max = max(1, collect($daily)->max('total'));
    $t = $r->table($tab, $productId);
    $card = 'padding:14px 16px;border-radius:14px;background:white;border:1px solid rgb(127 127 127 / .15)';
@endphp
<x-filament-panels::page>
    <style>
        .rp-filters{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
        .rp-filters select,.rp-filters input{height:38px;border-radius:10px;border:1px solid rgb(127 127 127/.3);padding:0 10px;background:transparent;font:inherit}
        .rp-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}
        .rp-card{padding:14px 16px;border-radius:14px;border:1px solid rgb(127 127 127/.18);background:rgb(255 255 255/.6)}
        .dark .rp-card{background:rgb(255 255 255/.03)}
        .rp-card small{display:block;opacity:.65;font-size:12.5px}
        .rp-card b{font-size:20px;font-weight:800}
        .rp-chart{display:flex;align-items:flex-end;gap:3px;height:200px;padding:10px 0 0;overflow-x:auto}
        .rp-bar{flex:1 0 10px;min-width:10px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:4px;height:100%}
        .rp-bar i{display:block;width:100%;border-radius:6px 6px 0 0;background:rgb(var(--primary-500));min-height:2px}
        .rp-bar span{font-size:10px;opacity:.6;white-space:nowrap}
        .rp-tabs{display:flex;flex-wrap:wrap;gap:6px}
        .rp-tabs button{padding:6px 12px;border-radius:99px;border:1px solid rgb(127 127 127/.25);font-size:13px;font-weight:600}
        .rp-tabs button.on{background:rgb(var(--primary-600));border-color:transparent;color:white}
        .rp-table{width:100%;border-collapse:collapse;font-size:13px}
        .rp-table th,.rp-table td{padding:8px 10px;border-bottom:1px solid rgb(127 127 127/.15);text-align:right;white-space:nowrap}
        .rp-table th{font-weight:700;opacity:.75;position:sticky;top:0;background:inherit}
        .rp-wrap{overflow-x:auto;max-height:620px}
        .up{color:#16a34a}.down{color:#dc2626}
    </style>

    <div class="rp-filters">
        <select wire:model.live="period" aria-label="بازه">
            @foreach (\App\Services\Reports::PERIODS as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach
        </select>
        @if ($period === 'custom')
            <input wire:model.blur="from" placeholder="از ۱۴۰۵/۰۷/۰۱" dir="ltr" style="width:140px">
            <input wire:model.blur="to" placeholder="تا ۱۴۰۵/۰۷/۳۰" dir="ltr" style="width:140px">
        @endif
        <span style="opacity:.7;font-size:13px">{{ $r->label() }}</span>
        <span wire:loading style="opacity:.6;font-size:13px">در حال محاسبه…</span>
        <x-filament::button size="sm" color="gray" icon="heroicon-o-arrow-down-tray" wire:click="export('summary')" style="margin-inline-start:auto">اکسل خلاصه</x-filament::button>
    </div>

    <div class="rp-cards">
        @foreach ([
            ['فروش کل (تومان)', money($s['sales']), $s['growth'] !== null ? ($s['growth'] >= 0 ? '▲ ' : '▼ ').fa(abs($s['growth'])).'٪ نسبت به دوره قبل' : null],
            ['تعداد سفارش', fa($s['orders']), 'لغوشده: '.fa($s['cancelled'])],
            ['میانگین هر سفارش', money($s['avg']), 'میانگین روزانه: '.money($s['per_day'])],
            ['کالای فروخته‌شده', fa($s['units']).' عدد', fa($s['cartons']).' کارتن · تکی: '.money($s['retail_sales'])],
            ['مشتریان', fa($s['customers']), 'ثبت‌نام جدید: '.fa($s['new_customers'])],
            ['تخفیف داده‌شده', money($s['discount'] + $s['coupons']), 'کد تخفیف: '.money($s['coupons'])],
            ['پرداخت‌شده', money($s['paid']), 'پرداخت‌نشده: '.money($s['unpaid'])],
            ['هزینه ارسال دریافتی', money($s['shipping']), null],
        ] as [$l, $v, $sub])
            <div class="rp-card"><small>{{ $l }}</small><b>{{ $v }}</b>@if ($sub)<small class="{{ str_starts_with($sub, '▲') ? 'up' : (str_starts_with($sub, '▼') ? 'down' : '') }}">{{ $sub }}</small>@endif</div>
        @endforeach
    </div>

    <x-filament::section heading="روند فروش" :description="count($daily) > 40 ? 'ماهانه' : 'روزانه'">
        <x-slot name="headerEnd"><x-filament::button size="xs" color="gray" icon="heroicon-o-arrow-down-tray" wire:click="export('daily')">اکسل</x-filament::button></x-slot>
        <div class="rp-chart" dir="rtl">
            @foreach ($daily as $d)
                <div class="rp-bar" title="{{ $d['label'] }} — {{ money($d['total']) }} تومان ({{ fa($d['count']) }} سفارش)">
                    <i style="height:{{ max(1, round($d['total'] * 100 / $max)) }}%"></i>
                    @if (count($daily) <= 31 || $loop->index % (int) ceil(count($daily) / 20) === 0)<span>{{ $d['short'] }}</span>@endif
                </div>
            @endforeach
        </div>
    </x-filament::section>

    <x-filament::section>
        <div class="rp-tabs">
            @foreach (\App\Filament\Pages\ReportsPage::TABS as $k => $v)
                <button type="button" wire:click="setTab('{{ $k }}')" @class(['on' => $tab === $k])>{{ $v }}</button>
            @endforeach
        </div>
        @if ($tab === 'product')
            <div style="margin-top:12px;display:grid;gap:8px;max-width:520px">
                <input wire:model.live.debounce.400ms="productSearch" placeholder="نام یا بارکد کالا را جستجو کنید…" style="height:40px;border-radius:10px;border:1px solid rgb(127 127 127/.3);padding:0 12px;background:transparent">
                @foreach ($this->productOptions() as $id => $name)
                    <button type="button" wire:click="pickProduct({{ $id }})" style="text-align:right;padding:6px 10px;border-radius:8px;background:rgb(127 127 127/.08)">{{ $name }}</button>
                @endforeach
                @if ($productId && ($pp = \App\Models\Product::find($productId)))
                    @php $ps = collect($t['rows']); @endphp
                    <div class="rp-card"><small>{{ $pp->name }}</small><b>{{ money($ps->sum(7)) }} تومان</b>
                        <small>{{ fa($ps->count()) }} سفارش · {{ fa($ps->sum(5)) }} عدد · بازدید {{ fa($pp->views) }} @unless (\App\Models\Product::unlimited())· موجودی {{ $pp->stock === null ? '—' : fa($pp->stock) }}@endunless</small></div>
                @endif
            </div>
        @endif
        <div style="display:flex;justify-content:space-between;align-items:center;margin:14px 0 6px">
            <b>{{ \App\Filament\Pages\ReportsPage::TABS[$tab] }} <span style="opacity:.6;font-weight:400">({{ fa(count($t['rows'])) }} ردیف)</span></b>
            @if ($t['rows'])<x-filament::button size="sm" color="gray" icon="heroicon-o-arrow-down-tray" wire:click="export('{{ $tab }}')">دانلود اکسل</x-filament::button>@endif
        </div>
        @if (! $t['rows'])
            <p style="opacity:.6;padding:20px 0;text-align:center">{{ $tab === 'product' && ! $productId ? 'یک کالا را انتخاب کنید.' : 'در این بازه داده‌ای نیست.' }}</p>
        @else
            <div class="rp-wrap">
                <table class="rp-table">
                    <thead><tr><th>#</th>@foreach ($t['head'] as $h)<th>{{ $h }}</th>@endforeach</tr></thead>
                    <tbody>
                        @foreach ($t['rows'] as $i => $row)
                            <tr><td style="opacity:.5">{{ fa($i + 1) }}</td>@foreach (array_values($row) as $ci => $cell)<td @if ($ci === 0) style="white-space:normal;min-width:180px;font-weight:600" @endif>{{ is_int($cell) ? (in_array($ci, $t['money'] ?? [], true) ? money($cell) : fa($cell)) : (is_float($cell) ? fa($cell) : ($cell === null || $cell === '' ? '—' : fa((string) $cell))) }}</td>@endforeach</tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </x-filament::section>
</x-filament-panels::page>
