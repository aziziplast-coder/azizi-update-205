<x-filament-panels::page>
<div wire:poll.60s.visible style="display:grid;gap:20px;font-size:13.5px">
    <x-filament::section heading="حساب‌های مقصد منتظر تأیید شما" icon="heroicon-o-building-library" :description="'کارخانه‌دار تعیین کرده که مبلغ حواله به کدام حساب(ها) واریز شود. پس از تأیید، حواله جاری می‌شود و مبالغ مشتریان به همین حساب‌ها صادر می‌شود.'">
        @forelse ($review as $r)
            <div style="border:1px solid rgba(127,127,127,.25);border-radius:14px;padding:12px;margin-bottom:12px;display:grid;gap:10px">
                <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><b>حواله {{ fa($r->code) }} — {{ $r->title }}</b><b>{{ money($r->amount) }} تومان</b></div>
                @include('filament.factory.dests', ['r' => $r, 'ds' => $r->destinations->where('status', 'submitted')->values()])
                @if ($chief)
                    <div style="display:flex;gap:8px;flex-wrap:wrap">
                        <button type="button" wire:click="approve({{ $r->id }})" wire:confirm="حساب‌های مقصد حواله {{ $r->code }} تأیید و حواله جاری شود؟" style="padding:6px 16px;border-radius:10px;background:#16a34a;color:#fff;font-weight:700">✓ تأیید و جاری کردن حواله</button>
                        @include('filament.orders.partials.reject-pop', ['call' => "\$wire.reject({$r->id}, %s)", 'reasons' => ['شبا با نام صاحب حساب تطبیق ندارد' => 'شبا با نام صاحب حساب تطبیق ندارد', 'اطلاعات گیرنده ناقص است' => 'اطلاعات گیرنده ناقص است'], 'label' => '✕ رد'])
                    </div>
                @else
                    <small style="opacity:.7">تأیید با حسابدار کل است.</small>
                @endif
            </div>
        @empty
            <p style="opacity:.6;margin:0">موردی نیست.</p>
        @endforelse
    </x-filament::section>

    <x-filament::section heading="منتظر تصمیم کارخانه‌دار" icon="heroicon-o-clock" collapsible>
        @forelse ($awaiting as $r)
            <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center;padding:8px 0;border-bottom:1px solid rgba(127,127,127,.15)">
                <span><b>{{ fa($r->code) }}</b> — {{ $r->factory?->name }}@if ($r->factory?->isThird()) <small style="color:#6d28d9">(شخص ثالث — منتظر ثبت حساب)</small>@endif — {{ money($r->amount) }} تومان — از {{ jdate($r->created_at, true) }}
                    @if ($r->dest_status === 'rejected')<span style="color:#b91c1c"> (رد شد: {{ $r->dest_reason }})</span>@endif</span>
                <button type="button" wire:click="remind({{ $r->id }})" style="padding:4px 12px;border-radius:8px;background:rgba(127,127,127,.12);font-weight:700">پیامک دوباره</button>
            </div>
        @empty
            <p style="opacity:.6;margin:0">موردی نیست.</p>
        @endforelse
    </x-filament::section>

    @php $K = $fac['kpi']; @endphp
    <x-filament::section heading="🏭 تأیید فیش‌ها توسط کارخانه‌دار (ملاک اصلی)" icon="heroicon-o-banknotes"
        :description="'تأیید ما فقط برای پیشبرد سفارش است؛ پول وقتی قطعاً رسیده که کارخانه‌دار در اپ خودش «نشستن در حساب» را تأیید کند. فیش‌های قرمز بیش از '.fa($lateH).' ساعت منتظرند (پایا ممکن است چند ساعت طول بکشد؛ بعد از آن پیگیری کنید).'">
        <style>
            .fd-k{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin-bottom:14px}
            .fd-k div{border-radius:14px;padding:10px 12px;border:1px solid rgba(127,127,127,.2)}
            .fd-k b{display:block;font-size:17px;font-weight:900}
            .fd-k small{opacity:.75}
            .fd-k .w{background:rgba(245,158,11,.1);border-color:rgba(245,158,11,.35)}
            .fd-k .r{background:rgba(220,38,38,.08);border-color:rgba(220,38,38,.3)}
            .fd-k .o{background:rgba(59,130,246,.08);border-color:rgba(59,130,246,.3)}
            .fd-k .g{background:rgba(22,163,74,.08);border-color:rgba(22,163,74,.3)}
            .fd-tabs{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
            .fd-tabs button{padding:6px 14px;border-radius:999px;font-weight:700;background:rgba(127,127,127,.1)}
            .fd-tabs button.on{background:#4f4a63;color:#fff}
            .fd-g{border:1px solid rgba(127,127,127,.22);border-radius:16px;margin-bottom:14px;overflow:hidden}
            .fd-gh{display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between;align-items:center;padding:10px 14px;background:rgba(127,127,127,.06)}
            .fd-bar{height:8px;border-radius:99px;background:rgba(127,127,127,.18);overflow:hidden;display:flex;min-width:160px;flex:1;max-width:320px}
            .fd-bar i{display:block;height:100%}
            .fd-t{width:100%;border-collapse:collapse}
            .fd-t th{font-size:12px;opacity:.7;text-align:right;padding:6px 10px;font-weight:700}
            .fd-t td{padding:7px 10px;border-top:1px solid rgba(127,127,127,.13);vertical-align:middle}
            .fd-t tr.late td{background:rgba(220,38,38,.06)}
            .fd-b{display:inline-block;padding:2px 10px;border-radius:99px;font-weight:800;font-size:12px;white-space:nowrap}
            .fd-b.fw{background:#fef3c7;color:#92400e}.fd-b.fl{background:#fee2e2;color:#b91c1c}.fd-b.fo{background:#dcfce7;color:#166534}
            .fd-b.ow{background:rgba(127,127,127,.12)}.fd-b.oo{background:#dbeafe;color:#1d4ed8}
            .fd-th{width:40px;height:40px;object-fit:cover;border-radius:8px;border:1px solid rgba(127,127,127,.25)}
        </style>
        <div class="fd-k">
            <div class="w"><small>منتظر تأیید کارخانه‌دار</small><b>{{ money($K['wait_s']) }} ت</b><small>{{ fa($K['wait_n']) }} فیش</small></div>
            <div class="r"><small>دیرشده (بیش از {{ fa($lateH) }} ساعت)</small><b>{{ fa($K['late_n']) }} فیش</b><small>پیگیری تلفنی/پیامک</small></div>
            <div class="o"><small>ما تأیید کرده‌ایم، کارخانه هنوز نه</small><b>{{ money($K['ours_s']) }} ت</b><small>{{ fa($K['ours_n']) }} فیش — ریسک</small></div>
            <div class="g"><small>تأیید کارخانه‌دار (۳۰ روز اخیر)</small><b>{{ money($K['done_s']) }} ت</b><small>قطعی</small></div>
        </div>
        <div class="fd-tabs">
            <button type="button" wire:click="$set('fTab','wait')" @class(['on' => $fTab === 'wait'])>⏳ منتظر تأیید کارخانه ({{ fa($K['wait_n']) }})</button>
            <button type="button" wire:click="$set('fTab','done')" @class(['on' => $fTab === 'done'])>✓ تأییدشده توسط کارخانه (۳۰ روز)</button>
            <button type="button" wire:click="$set('fTab','all')" @class(['on' => $fTab === 'all'])>همه</button>
            <input type="search" wire:model.live.debounce.400ms="fq" placeholder="کد حواله، کارخانه، سفارش، مشتری یا مبلغ" style="flex:1;min-width:200px;max-width:340px;border-radius:10px;border:1px solid rgba(127,127,127,.3);padding:6px 10px;background:transparent">
        </div>

        @forelse ($fac['groups'] as $g)
            @php $r = $g['r']; $pct = $g['sum'] ? round($g['fac'] * 100 / $g['sum']) : 0; @endphp
            <div class="fd-g">
                <div class="fd-gh">
                    <div>
                        <a href="{{ \App\Filament\Resources\RemittanceResource::getUrl('view', ['record' => $r->id]) }}" style="font-weight:900">حواله {{ fa($r->code) }}</a>
                        — {{ $r->factory?->name }} <small style="opacity:.7">({{ \Illuminate\Support\Str::limit($r->title, 30) }} · {{ money($r->amount) }} ت)</small>
                        @if ($g['late'])<span class="fd-b fl">{{ fa($g['late']) }} دیرشده</span>@endif
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
                        <div class="fd-bar" title="سبز: تأیید کارخانه‌دار"><i style="width:{{ $pct }}%;background:#16a34a"></i><i style="width:{{ 100 - $pct }}%;background:#f59e0b"></i></div>
                        <small><b style="color:#15803d">{{ money($g['fac']) }}</b> از {{ money($g['sum']) }} ت تأیید کارخانه ({{ fa($g['fn']) }}/{{ fa($g['n']) }} فیش)</small>
                        @if ($r->factory_id && $g['sum'] > $g['fac'])<button type="button" wire:click="remindPayments({{ $r->factory_id }})" style="padding:4px 12px;border-radius:8px;background:rgba(127,127,127,.14);font-size:12px;font-weight:700">📩 یادآوری به کارخانه‌دار</button>@endif
                    </div>
                </div>
                <div style="overflow-x:auto">
                <table class="fd-t">
                    <thead><tr><th>فیش</th><th>مشتری / سفارش</th><th>مبلغ</th><th>ثبت فیش</th><th>تأیید ما</th><th>🏭 تأیید کارخانه‌دار</th><th></th></tr></thead>
                    <tbody>
                    @foreach ($g['rows'] as $p)
                        @php $late = \App\Services\FactoryPortal::isLate($p); $files = $p->files(); @endphp
                        <tr @class(['late' => $late])>
                            <td>@if ($files)<a href="{{ route('admin.remit.receipt', [$p, 'i' => 0, 'v' => substr(md5((string) $p->updated_at), 0, 8)]) }}" target="_blank">@if (\App\Models\RemitPayment::isPdfPath($files[0]))📄 PDF@else<img class="fd-th" src="{{ route('admin.remit.receipt', [$p, 'i' => 0, 'v' => substr(md5((string) $p->updated_at), 0, 8)]) }}" alt="" loading="lazy">@endif</a>@if (count($files) > 1)<small> +{{ fa(count($files) - 1) }}</small>@endif @else — @endif</td>
                            <td>{{ $p->partyName() ?: '—' }}<br><small style="opacity:.7">{{ $p->refLabel() }} · {{ $p->kindLabel() }}@if ($p->receipt_ref) · پیگیری <span dir="ltr">{{ fa($p->receipt_ref) }}</span>@endif</small></td>
                            <td style="font-weight:800;white-space:nowrap">{{ money($p->amount) }}</td>
                            <td style="white-space:nowrap;{{ $late ? 'color:#b91c1c;font-weight:700' : '' }}">{{ jdate($p->submitted_at, true) }}<br><small>{{ $p->submitted_at?->diffForHumans() }}</small></td>
                            <td>@if ($p->status === 'confirmed')<span class="fd-b oo">✓ {{ $p->reviewer?->name ?: 'تأیید شد' }}</span>@else<span class="fd-b ow">منتظر بررسی ما</span>@endif</td>
                            <td>@if ($p->factory_confirmed_at)<span class="fd-b fo">✓ نشست در حساب</span><br><small>{{ jdate($p->factory_confirmed_at, true) }}</small>
                                @else<span @class(['fd-b', 'fl' => $late, 'fw' => ! $late])>{{ $late ? '⏰ دیر — تأیید نکرده' : '⏳ منتظر کارخانه‌دار' }}</span>@if ($p->factory_seen_at)<br><small style="opacity:.7">دیده شد {{ $p->factory_seen_at->diffForHumans() }}</small>@else<br><small style="opacity:.7">هنوز ندیده</small>@endif @endif</td>
                            @if ($chief && $p->status === 'confirmed' && ! $p->factory_confirmed_at)
                                <td><a href="{{ \App\Filament\Resources\RemitPaymentResource::getUrl('index', ['activeTab' => 'confirmed', 'tableAction' => 'fixConfirmed', 'tableActionRecord' => $p->id]) }}" style="padding:3px 10px;border-radius:8px;background:rgba(220,38,38,.1);color:#b91c1c;font-size:12px;font-weight:800;white-space:nowrap" title="پول کامل نرسیده؟ مبلغ واقعی را ثبت و کسری را دوباره صادر کنید">⚠ کسری / اصلاح</a></td>
                            @else<td></td>@endif
                        </tr>
                    @endforeach
                    </tbody>
                </table>
                </div>
            </div>
        @empty
            <p style="opacity:.6;margin:0">{{ $fTab === 'wait' ? 'همه فیش‌ها را کارخانه‌دارها تأیید کرده‌اند ✓' : 'موردی نیست.' }}</p>
        @endforelse
    </x-filament::section>
</div>
</x-filament-panels::page>
