<div style="display:grid;gap:10px;font-size:13.5px">
    @if ($r->factory?->isThird())<div style="padding:6px 10px;border-radius:8px;background:rgba(109,40,217,.08);color:#6d28d9">شخص ثالث: این حواله از طرف «{{ $r->factory->referrer?->name }}» به او منتقل شده و حساب خودش را ثبت کرده است.</div>@endif
    @if ($r->factory)<div>{{ $r->factory->isThird() ? 'گیرنده' : 'کارخانه‌دار' }}: <b>{{ $r->factory->name }}</b> — <span dir="ltr">{{ fa($r->factory->mobile) }}</span> — ثبت: {{ $r->dest_at ? jdate($r->dest_at, true) : '—' }}</div>@endif
    @foreach ($ds as $i => $d)
        @php
            $shOk = \App\Support\Banks::validSheba($d->sheba);
            $cdOk = ! $d->card_number || \App\Support\Banks::validCard($d->card_number);
        @endphp
        <div style="border:1px solid rgba(127,127,127,.3);border-radius:12px;padding:10px;display:grid;gap:4px;{{ $d->kind === 'other' ? 'border-color:#a78bfa' : '' }}">
            <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap">
                <b>{{ fa($i + 1) }}) {{ $d->kindLabel() }}: {{ $d->holder_name }}</b>
                <b style="font-size:15px">{{ money($d->amount) }} تومان</b>
            </div>
            <div>بانک: <b>{{ $d->bank_name ?: 'نامشخص' }}</b></div>
            <div dir="ltr" style="text-align:right;user-select:all;font-family:monospace">{{ \App\Support\Banks::formatSheba($d->sheba) }} <span style="color:{{ $shOk ? '#16a34a' : '#dc2626' }}">{{ $shOk ? '✓' : '✗ نامعتبر' }}</span></div>
            @if ($d->card_number)<div dir="ltr" style="text-align:right;user-select:all;font-family:monospace">{{ \App\Support\Banks::formatCard($d->card_number) }} <span style="color:{{ $cdOk ? '#16a34a' : '#dc2626' }}">{{ $cdOk ? '✓' : '✗' }}</span></div>@endif
            @if ($d->account_number)<div>شماره حساب: <span dir="ltr" style="user-select:all">{{ $d->account_number }}</span></div>@endif
            @if ($d->mobile)<div>موبایل گیرنده: <a href="tel:{{ $d->mobile }}" dir="ltr">{{ fa($d->mobile) }}</a>@if ($d->national_id) — کد ملی <span dir="ltr">{{ $d->national_id }}</span>@endif</div>@endif
            @if ($d->note)<div style="opacity:.8">توضیح: {{ $d->note }}</div>@endif
        </div>
    @endforeach
    @if ($ds->count() > 1)<p style="margin:0;opacity:.75">با تأیید، حساب اول روی همین حواله می‌نشیند و برای بقیه حواله‌های جدا (زیرمجموعه همین حواله) ساخته می‌شود.</p>@endif
    <p style="margin:0;opacity:.75">پیش از تأیید، نام صاحب حساب را با استعلام شبا در اپ بانک تطبیق دهید.</p>
</div>
