<x-filament-panels::page>
<link rel="stylesheet" href="{{ asset('css/admin-tools.css') }}?v={{ @filemtime(public_path('css/admin-tools.css')) }}">

<div class="bu" id="bu" data-products="{{ $productsUrl }}">
    <svg width="0" height="0" style="position:absolute"><defs><linearGradient id="buGrad" x1="0" x2="1"><stop offset="0" stop-color="rgb(var(--primary-400))"/><stop offset="1" stop-color="rgb(var(--primary-700))"/></linearGradient></defs></svg>

    <div class="bu-hero">
        <i class="deco"></i><i class="deco2"></i>
        <h2>بار جدید را یک‌جا تحویل بده 📦</h2>
        <p>یک فایل RAR یا ZIP با عکس کالاها و یک اکسل بده؛ بقیه‌اش با ما: عکس‌ها به کد کالا وصل می‌شوند، مغایرت‌ها پیدا می‌شوند و کالاها پنهان و آماده تأیید ساخته می‌شوند.</p>
        <div class="pills"><span>⚡ باز شدن فایل در خود مرورگر</span><span>🔍 پیدا کردن مغایرت‌ها</span><span>🗂 دسته و کالای مشابه خودکار</span><span>👀 انتشار فقط بعد از تأیید</span></div>
    </div>

    <div class="bu-steps" id="buSteps"><i class="track" id="buTrack"></i>
        <div class="on"><b>۱</b>انتخاب فایل</div><div><b>۲</b>آپلود</div><div><b>۳</b>بررسی</div><div><b>۴</b>ساخت</div>
    </div>

    {{-- ۱. انتخاب --}}
    <div class="bu-card bu-anim" id="buPick">
        <label class="bu-drop" id="buDrop">
            <input type="file" id="buFile" multiple hidden accept=".rar,.zip,.7z,.xlsx,.xls,.csv,image/*">
            <div class="icons"><span class="x">XLSX</span><span class="z">ZIP</span><span class="j">JPG</span></div>
            <b class="t" id="buDropT">فایل RAR یا ZIP را اینجا رها کنید</b>
            <small id="buDropS">عکس‌ها + یک فایل اکسل — یا عکس‌ها و اکسل را جدا جدا انتخاب کنید.</small>
            <span class="btnish">انتخاب از کامپیوتر</span>
        </label>
        <div class="bu-help">
            <div><em>🖼</em><span><b>نام هر عکس:</b> شماره انبار عمده ـ کد کالا<br><code>7-202545.jpg</code> عکس اصلی، <code>7-202545-2.jpg</code> عکس دوم</span></div>
            <div><em>📊</em><span><b>اکسل:</b> کد کالا، نام کالا، قیمت، «تعداد» (= تعداد در کارتن)، واحد، دسته. ستون‌های کارتن، موجودی، جمع، درصد تخفیف و شرح کالا نادیده گرفته می‌شوند.</span></div>
            <div><em>✅</em><span><b>بعد از ساخت:</b> کالاها پنهان‌اند تا در «محصولات ← منتظر تأیید» دسته را همان‌جا انتخاب و گروهی منتشر کنید.</span></div>
        </div>

        <div id="buPicked" hidden style="margin-top:18px">
            <div class="bu-kpis" id="buPickKpi"></div>
            <div id="buXls" style="margin-top:10px"></div>
            <div class="bu-row" style="margin-top:14px">
                <input class="bu-in" id="buTitle" placeholder="اسم این بار (مثلاً بار کارخانه X — آبان)" style="flex:1;min-width:220px">
                <select class="bu-in" id="buUnit"><option value="toman">قیمت‌ها به تومان</option><option value="rial">قیمت‌ها به ریال</option></select>
                <label class="bu-switch"><input type="checkbox" id="buStock" checked> کالاها «موجود» ساخته شوند</label>
            </div>
            <div class="bu-row" style="margin-top:14px">
                <button class="bu-btn pri lg" id="buGo">شروع آپلود ←</button>
                <button class="bu-btn" id="buReset">انتخاب دوباره</button>
            </div>
            <div class="bu-mosaic" id="buThumbs"></div>
        </div>
    </div>

    {{-- ۲. آپلود --}}
    <div class="bu-card bu-anim" id="buUp" hidden>
        <div class="bu-live">
            <div class="bu-ring" id="buRingUp"><svg viewBox="0 0 150 150"><circle class="bg" cx="75" cy="75" r="62"/><circle class="fg" cx="75" cy="75" r="62"/></svg><div><b>۰٪</b><small>آپلود</small></div></div>
            <div>
                <h3 id="buUpH">در حال ارسال عکس‌ها…</h3>
                <div class="bu-note"><span class="bu-shine">عکس‌ها در مرورگر کوچک و فشرده می‌شوند و چندتایی با هم فرستاده می‌شوند.</span></div>
                <div class="bu-stats" id="buUpStats"></div>
            </div>
        </div>
        <div class="bu-mosaic" id="buUpMosaic"></div>
    </div>

    {{-- ۳. بررسی --}}
    <div id="buAn" hidden>
        <div class="bu-card bu-anim"><div class="bu-kpis" id="buKpi"></div></div>
        <div class="bu-card bu-anim">
            <h3>ستون‌های اکسل</h3>
            <p class="bu-note" style="margin:-6px 0 12px">هر ستون در کدام فیلد کالا بنشیند؟ اگر چیزی را عوض کردید «بررسی دوباره» را بزنید.</p>
            <div class="bu-map" id="buMap"></div>
            <div class="bu-row" style="margin-top:12px"><button class="bu-btn" id="buRe">↻ بررسی دوباره</button></div>
        </div>
        <div class="bu-card bu-anim">
            <div class="bu-row" style="justify-content:space-between;margin-bottom:10px"><h3 style="margin:0">مغایرت‌ها</h3><a class="bu-btn" id="buRep" href="#">⬇ گزارش مغایرت‌ها (اکسل)</a></div>
            <div class="bu-tabs" id="buIssTabs"></div>
            <div class="bu-scroll" id="buIss"></div>
        </div>
        <div class="bu-card bu-anim">
            <div class="bu-row" style="justify-content:space-between;margin-bottom:8px"><h3 style="margin:0">کالاهایی که ساخته می‌شوند</h3><span class="bu-note">سبز آماده · نارنجی ناقص (بعداً کامل کنید) · «تکی» = تعداد در کارتن ۱، در سفارش خرده</span></div>
            <div class="bu-scroll"><table class="bu-tbl"><thead><tr><th></th><th>کد</th><th>نام کالا</th><th>قیمت</th><th>تعداد در کارتن</th><th>انبار عمده</th><th>دسته</th><th>وضعیت</th></tr></thead><tbody id="buRows"></tbody></table></div>
        </div>
        <div class="bu-card bu-anim" id="buUpd" hidden>
            <div class="bu-row" style="justify-content:space-between;margin-bottom:8px"><h3 style="margin:0">🔄 تعویض عکس کالاهای موجود</h3><span class="bu-note">کد این عکس‌ها در سایت هست؛ با «ساخت» عکس تازه عکس اصلی می‌شود و عکس اصلی قبلی اول گالری می‌رود (چیزی پاک نمی‌شود).</span></div>
            <div class="bu-scroll"><table class="bu-tbl"><thead><tr><th>عکس فعلی</th><th></th><th>عکس تازه</th><th>کد</th><th>کالا</th></tr></thead><tbody id="buUpdList"></tbody></table></div>
        </div>
        <div class="bu-dock">
            <span class="bu-note" id="buMakeNote"></span>
            <div class="bu-row"><button class="bu-btn" id="buCancel">انصراف و پاک کردن</button><button class="bu-btn ok lg" id="buMake">✓ تأیید و اجرا (کالاهای تازه منتشر نمی‌شوند)</button></div>
        </div>
    </div>

    {{-- ۴. ساخت --}}
    <div class="bu-card bu-anim" id="buMk" hidden>
        <div class="bu-live">
            <div class="bu-ring" id="buRingMk"><svg viewBox="0 0 150 150"><circle class="bg" cx="75" cy="75" r="62"/><circle class="fg" cx="75" cy="75" r="62"/></svg><div><b>۰٪</b><small>ساخت</small></div></div>
            <div>
                <h3>در حال ساخت کالاها…</h3>
                <div class="bu-note"><span class="bu-shine">عکس‌ها ذخیره، دسته و کالاهای مشابه تعیین و کالاها پنهان ساخته می‌شوند.</span></div>
                <div class="bu-stats" id="buMkStats"></div>
            </div>
        </div>
    </div>

    <div class="bu-card bu-done" id="buDone" hidden>
        <div class="check">✓</div>
        <h3 id="buDoneT"></h3>
        <p class="bu-note" id="buDoneD"></p>
        <div class="bu-row" style="justify-content:center;margin-top:14px"><a class="bu-btn pri lg" id="buReview" href="#">بررسی و انتشار گروهی ←</a><button class="bu-btn lg" onclick="location.reload()">آپلود بار بعدی</button></div>
    </div>

    @if ($recent->isNotEmpty())
        <div class="bu-card bu-recent bu-anim" id="buRecent">
            <h3>آپلودهای اخیر</h3>
            @foreach ($recent as $r)
                <div class="it">
                    <em>#{{ fa($r->id) }}</em>
                    <div><b>{{ $r->title }}</b><small>{{ jdate($r->created_at, true) }} · {{ $r->user }} · {{ fa($r->created_count) }} کالا</small></div>
                    <div>@if ($r->pending)<a href="{{ $productsUrl }}?activeTab=pending&tableFilters[import_id][value]={{ $r->id }}">{{ fa($r->pending) }} منتظر تأیید ←</a>@elseif ($r->status === 'done')<span class="bu-chip ok">همه منتشر شد</span>@else<span class="bu-chip mu">نیمه‌کاره</span>@endif</div>
                </div>
            @endforeach
        </div>
    @endif
    <canvas id="buConfetti" hidden></canvas>
</div>

<script type="module">
const $ = s => document.querySelector(s);
const fa = n => String(n ?? '').replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
const money = n => n ? fa(Number(n).toLocaleString('en-US')) : '—';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CSRF = document.querySelector('meta[name=csrf-token]')?.content;
const PRODUCTS = $('#bu').dataset.products;
const IMG = /\.(jpe?g|png|webp|gif|jfif)$/i, XLS = /\.(xlsx|xls|csv|xlsb)$/i, ARC = /\.(rar|zip|7z)$/i;
let images = [], excel = null, ID = null, AN = null, issTab = 'all';

/* ---------- ابزار ---------- */
function step(n) {
    document.querySelectorAll('#buSteps div').forEach((s, i) => { s.className = i < n - 1 ? 'done' : i === n - 1 ? 'on' : ''; });
    $('#buTrack').style.width = (Math.min(n - 1, 3) / 3 * 75) + '%';
}
async function api(url, body, isForm) {
    const r = await fetch('/admin-tools/bulk' + url, { method: 'POST', headers: Object.assign({ 'X-CSRF-TOKEN': CSRF, 'Accept': 'application/json' }, isForm ? {} : { 'Content-Type': 'application/json' }), body: isForm ? body : JSON.stringify(body || {}), credentials: 'same-origin' });
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (!r.ok || j.ok === false) throw new Error(j.msg || j.message || ('خطای سرور ' + r.status));
    return j;
}
function ring(el, pct, label) {
    const c = el.querySelector('.fg'), L = 2 * Math.PI * 62;
    c.style.strokeDasharray = L; c.style.strokeDashoffset = L * (1 - Math.max(0, Math.min(1, pct)));
    el.querySelector('b').textContent = fa(Math.round(pct * 100)) + '٪';
    if (label) el.querySelector('small').textContent = label;
}
function countUp(el, to) {
    const t0 = performance.now(), d = 700;
    const f = t => { const k = Math.min(1, (t - t0) / d); el.textContent = fa(Math.round(to * (1 - Math.pow(1 - k, 3)))); if (k < 1) requestAnimationFrame(f); };
    requestAnimationFrame(f);
}
const eta = s => s > 90 ? fa(Math.round(s / 60)) + ' دقیقه' : fa(Math.max(1, Math.round(s))) + ' ثانیه';
function kpis(box, list) {
    box.innerHTML = list.map(([cls, n, label, icon], i) => `<div class="bu-kpi ${cls}" style="animation-delay:${i * 60}ms"><em>${icon || ''}</em><b data-n="${n}">۰</b><small>${label}</small></div>`).join('');
    box.querySelectorAll('b[data-n]').forEach(b => countUp(b, +b.dataset.n));
}
function confetti() {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const cv = $('#buConfetti'), x = cv.getContext('2d'); cv.hidden = false;
    cv.width = innerWidth; cv.height = innerHeight;
    const cols = ['#22c55e', '#f59e0b', '#8b5cf6', '#3b82f6', '#ef4444', '#14b8a6'];
    const P = Array.from({ length: 160 }, () => ({ x: innerWidth / 2, y: innerHeight / 3, vx: (Math.random() - .5) * 16, vy: Math.random() * -14 - 4, s: 4 + Math.random() * 6, c: cols[Math.random() * cols.length | 0], r: Math.random() * 6, vr: (Math.random() - .5) * .3 }));
    let f = 0;
    (function loop() {
        x.clearRect(0, 0, cv.width, cv.height);
        P.forEach(p => { p.vy += .35; p.vx *= .99; p.x += p.vx; p.y += p.vy; p.r += p.vr; x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c; x.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); x.restore(); });
        if (++f < 150) requestAnimationFrame(loop); else cv.hidden = true;
    })();
}

/* همان قاعده سرور: «انبار-کد» یا «انبار-کد-۲» یا «… (2)» */
function parseName(name) {
    let n = name.replace(/\.[^.]+$/, '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
    let idx = 1, m = n.match(/^(.*?)\s*\((\d{1,2})\)\s*$/); if (m) { n = m[1]; idx = +m[2]; }
    const p = n.trim().split(/\s*[-_–—]\s*|\s+/).filter(Boolean);
    if (!p.length) return null;
    if (p.length >= 3 && /^\d{1,2}$/.test(p[p.length - 1])) idx = +p.pop();
    if (p.length === 1) return /^[A-Za-z0-9.]+$/.test(p[0]) ? { wh: '', code: p[0], idx } : null;
    const code = p.slice(1).join('-');
    if (!/^\d{1,4}$/.test(p[0]) || !/^[A-Za-z0-9.\-]+$/.test(code)) return null;
    return { wh: p[0].replace(/^0+(?=\d)/, ''), code, idx };
}

/* ---------- ۱. انتخاب و باز کردن RAR/ZIP در مرورگر (یک‌جا، در پس‌زمینه) ---------- */
const drop = $('#buDrop');
const DT = 'فایل RAR یا ZIP را اینجا رها کنید', DS = 'عکس‌ها + یک فایل اکسل — یا عکس‌ها و اکسل را جدا جدا انتخاب کنید.';
['dragover', 'dragenter'].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.add('over'); $('#buDropT').textContent = 'رها کنید! 🎯'; }));
['dragleave', 'drop'].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.remove('over'); $('#buDropT').textContent = DT; }));
drop.addEventListener('drop', ev => take([...ev.dataTransfer.files]));
$('#buFile').addEventListener('change', ev => take([...ev.target.files]));
$('#buReset').onclick = () => { images = []; excel = null; $('#buPicked').hidden = true; $('#buFile').value = ''; };

let Archive = null;
function flatten(obj, out) {
    for (const k in obj) {
        const v = obj[k];
        if (v instanceof Blob) out.push(v instanceof File ? v : new File([v], k, { type: v.type || '' }));
        else if (v && typeof v === 'object') flatten(v, out);
    }
    return out;
}
async function unpack(file) {
    if (!Archive) { Archive = (await import('/vendor/libarchive/libarchive.js')).Archive; }
    const arc = await Archive.open(file);
    const all = flatten(await arc.extractFiles(), []);
    try { await arc.close(); } catch (e) {}
    return all.filter(f => f.name && !f.name.startsWith('.') && !/Thumbs\.db/i.test(f.name) && (IMG.test(f.name) || XLS.test(f.name)));
}
async function take(files) {
    drop.classList.add('busy'); $('#buDropT').textContent = 'در حال باز کردن فایل‌ها…'; $('#buDropS').textContent = 'چند لحظه؛ فایل فشرده در خود مرورگر باز می‌شود.';
    try {
        for (const f of files) { if (ARC.test(f.name)) (await unpack(f)).forEach(add); else add(f); }
    } catch (e) { alert('باز کردن فایل فشرده ناموفق بود: ' + e.message + '\nاگر RAR رمزدار است، رمز را بردارید یا ZIP بفرستید.'); }
    drop.classList.remove('busy'); $('#buDropT').textContent = DT; $('#buDropS').textContent = DS;
    showPicked();
}
function add(f) {
    if (IMG.test(f.name)) { if (!images.some(x => x.name === f.name && x.size === f.size)) images.push(f); }
    else if (XLS.test(f.name)) excel = f;
}
function mosaic(box, list, cls, limit) {
    box.innerHTML = list.slice(0, limit).map((f, i) => {
        const p = parseName(f.name);
        return `<figure data-i="${i}" class="${p ? cls : 'bad'}" style="animation-delay:${Math.min(i, 40) * 18}ms"><img src="${URL.createObjectURL(f)}" loading="lazy" alt=""><figcaption>${p ? (p.wh ? fa(p.wh) + ' · ' : '') + fa(p.code) + (p.idx > 1 ? ' (' + fa(p.idx) + ')' : '') : esc(f.name)}</figcaption></figure>`;
    }).join('') + (list.length > limit ? `<figure class="more">+${fa(list.length - limit)}</figure>` : '');
}
function showPicked() {
    if (!images.length && !excel) return;
    const bad = images.filter(f => !parseName(f.name)).length;
    const codes = new Set(images.map(f => (parseName(f.name) || {}).code).filter(Boolean));
    kpis($('#buPickKpi'), [[images.length ? 'ok' : 'bad', images.length, 'عکس', '🖼'], ['', codes.size, 'کد کالای مختلف', '🏷'], ...(bad ? [['bad', bad, 'نام عکس نامعتبر', '⚠️']] : [])]);
    $('#buXls').innerHTML = excel ? `<div class="bu-xls"><em>XLSX</em><div><b>${esc(excel.name)}</b><div class="bu-note">فایل اکسل پیدا شد ✓</div></div></div>` : `<div class="bu-xls no"><em>?</em><div><b>فایل اکسل پیدا نشد</b><div class="bu-note">اکسل را هم کنار عکس‌ها انتخاب کنید.</div></div></div>`;
    mosaic($('#buThumbs'), images, '', 60);
    $('#buGo').disabled = !excel && !images.length; // فقط عکس هم می‌شود (تعویض عکس کالاهای موجود)
    $('#buPicked').hidden = false;
}

/* ---------- ۲. آپلود: کوچک کردن عکس در پس‌زمینه (چند هسته) + ارسال چندتایی ---------- */
const MAX = 1600;
const W_SRC = `self.onmessage=async e=>{const{id,file}=e.data;try{const png=/\\.png$/i.test(file.name);const bmp=await createImageBitmap(file);const sc=Math.min(1,${MAX}/Math.max(bmp.width,bmp.height));if(sc===1&&file.size<=700*1024&&/\\.(jpe?g|jfif|webp)$/i.test(file.name)){bmp.close();self.postMessage({id,keep:true});return}const w=Math.round(bmp.width*sc),h=Math.round(bmp.height*sc);const c=new OffscreenCanvas(w,h);const x=c.getContext('2d');if(!png){x.fillStyle='#fff';x.fillRect(0,0,w,h)}x.drawImage(bmp,0,0,w,h);bmp.close();const type=png?'image/webp':'image/jpeg';const blob=await c.convertToBlob({type,quality:.88});self.postMessage({id,blob,type})}catch(err){self.postMessage({id,keep:true})}}`;
let pool = null;
function makePool() {
    if (!('OffscreenCanvas' in window) || !window.Worker) return null;
    try {
        const url = URL.createObjectURL(new Blob([W_SRC], { type: 'text/javascript' }));
        const n = Math.max(2, Math.min(4, navigator.hardwareConcurrency || 2));
        const ws = Array.from({ length: n }, () => new Worker(url)), cbs = new Map(); let rr = 0, seq = 0;
        ws.forEach(w => w.onmessage = e => { const cb = cbs.get(e.data.id); cbs.delete(e.data.id); cb && cb(e.data); });
        return { run: file => new Promise(res => { const id = ++seq; cbs.set(id, res); ws[rr++ % n].postMessage({ id, file }); }), end: () => ws.forEach(w => w.terminate()) };
    } catch (e) { return null; }
}
async function shrinkMain(f) {
    try {
        const bmp = await createImageBitmap(f), sc = Math.min(1, MAX / Math.max(bmp.width, bmp.height));
        if (sc === 1 && f.size <= 700 * 1024 && /\.(jpe?g|jfif|webp)$/i.test(f.name)) return f;
        const c = document.createElement('canvas'); c.width = Math.round(bmp.width * sc); c.height = Math.round(bmp.height * sc);
        const png = /\.png$/i.test(f.name), x = c.getContext('2d'); if (!png) { x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); }
        x.drawImage(bmp, 0, 0, c.width, c.height);
        const type = png ? 'image/webp' : 'image/jpeg', b = await new Promise(r => c.toBlob(r, type, .88));
        return b ? new File([b], f.name.replace(/\.[^.]+$/, png ? '.webp' : '.jpg'), { type }) : f;
    } catch (e) { return f; }
}
async function shrink(f) {
    if (!pool) return shrinkMain(f);
    const r = await pool.run(f);
    if (r.keep || !r.blob) return f;
    return new File([r.blob], f.name.replace(/\.[^.]+$/, r.type === 'image/webp' ? '.webp' : '.jpg'), { type: r.type });
}
async function send(path, fd) {
    for (let t = 0; ; t++) {
        try { return await api(path, fd, true); } catch (e) { if (t >= 2 || /معتبر|فرمت/.test(e.message)) throw e; await new Promise(r => setTimeout(r, 900 * (t + 1))); }
    }
}
$('#buGo').onclick = async () => {
    $('#buPick').hidden = true; $('#buUp').hidden = false; step(2); scrollTo({ top: 0, behavior: 'smooth' });
    const R = $('#buRingUp'), N = images.length, errs = [];
    ring(R, 0);
    mosaic($('#buUpMosaic'), images, 'wait', 120);
    const figs = [...$('#buUpMosaic').querySelectorAll('figure[data-i]')];
    pool = makePool();
    try {
        ID = (await api('/start', { title: $('#buTitle').value })).id;
        if (excel) { const fx = new FormData(); fx.append('file', excel); fx.append('kind', 'excel'); fx.append('name', excel.name); await send('/' + ID + '/file', fx); }
        let cursor = 0, done = 0, bytes = 0; const t0 = performance.now(), cache = new Map();
        const prep = i => { if (!cache.has(i)) cache.set(i, shrink(images[i])); return cache.get(i); };
        const BATCH = 10, LIMIT = 5 * 1024 * 1024;
        const tick = () => {
            const sec = (performance.now() - t0) / 1000, rate = done / Math.max(.5, sec);
            ring(R, N ? done / N : 1, fa(done) + ' از ' + fa(N));
            $('#buUpStats').innerHTML = `<span>⚡ ${fa(rate.toFixed(1))} عکس در ثانیه</span><span>📦 ${fa((bytes / 1048576).toFixed(1))} مگابایت ارسال شد</span>` + (done < N && done > 3 ? `<span>⏳ حدود ${eta((N - done) / rate)} مانده</span>` : '');
        };
        const uploader = async () => {
            while (cursor < N) {
                const idx = []; for (let j = cursor; j < N && idx.length < BATCH; j++) idx.push(j);
                cursor += idx.length;
                for (let j = cursor; j < Math.min(N, cursor + BATCH); j++) prep(j); // آماده کردن دسته بعد هم‌زمان با ارسال این دسته
                const files = await Promise.all(idx.map(prep)); idx.forEach(j => cache.delete(j));
                let part = [], size = 0;
                const flush = async () => {
                    if (!part.length) return;
                    const fd = new FormData();
                    part.forEach(([j, f]) => { fd.append('files[]', f); fd.append('names[]', images[j].name.replace(/\.[^.]+$/, '') + f.name.slice(f.name.lastIndexOf('.'))); });
                    try { const r = await send('/' + ID + '/images', fd); (r.bad || []).forEach(b => errs.push(b)); }
                    catch (e) { part.forEach(([j]) => errs.push(images[j].name + ': ' + e.message)); }
                    part.forEach(([j, f]) => { done++; bytes += f.size; const fg = figs[j]; if (fg) { fg.classList.remove('wait'); fg.classList.add('up'); } });
                    tick(); part = []; size = 0;
                };
                for (let k = 0; k < idx.length; k++) {
                    if (size + files[k].size > LIMIT) await flush();
                    part.push([idx[k], files[k]]); size += files[k].size;
                }
                await flush();
            }
        };
        tick();
        await Promise.all([uploader(), uploader(), uploader()]);
        pool && pool.end();
        if (errs.length) alert(fa(errs.length) + ' عکس ارسال نشد:\n' + errs.slice(0, 15).join('\n'));
        $('#buUpH').textContent = 'تطبیق عکس‌ها با اکسل…'; ring(R, 1, 'تطبیق');
        await analyze(null);
    } catch (e) { alert(e.message); $('#buUpH').textContent = 'خطا: ' + e.message; }
};

/* ---------- ۳. بررسی ---------- */
async function analyze(mapping) {
    AN = await api('/' + ID + '/analyze', { mapping, unit: $('#buUnit').value, in_stock: $('#buStock').checked });
    $('#buUp').hidden = true; $('#buAn').hidden = false; step(3);
    $('#buRep').href = '/admin-tools/bulk/' + ID + '/report';
    drawAn(true);
}
function drawAn(first) {
    const s = AN.stats, iss = s.issues || {}, nIss = Object.values(iss).reduce((a, b) => a + b, 0);
    const incomplete = AN.rows.filter(r => r.flags.length || !r.cat || !r.imgs.length).length;
    const single = AN.rows.filter(r => +r.pc === 1).length;
    if (first) kpis($('#buKpi'), [['ok', s.rows, 'کالا ساخته می‌شود', '📦'], ...(s.updates ? [['ok', s.updates, 'عکس کالای موجود عوض می‌شود', '🔄']] : []), ['', s.with_img, 'کالای عکس‌دار', '🖼'], ['', s.cat_auto, 'دسته خودکار پیدا شد', '🗂'],
        [incomplete ? 'wa' : 'ok', incomplete, 'ناقص (قیمت/عکس/دسته)', '✏️'], [nIss ? 'bad' : 'ok', nIss, 'مغایرت', nIss ? '⚠️' : '✅'], ...(single ? [['', single, 'تکی (در سفارش خرده)', '1️⃣']] : [])]);
    $('#buMap').closest('.bu-card').hidden = !AN.headers.length;
    $('#buMap').innerHTML = AN.headers.map((h, i) => {
        const v = AN.mapping[i] ?? '';
        return `<label class="${v ? 'on' : 'off'}"><span>${esc(h)}<i>${v ? '✓ خوانده می‌شود' : 'نادیده'}</i></span><select class="bu-in" data-i="${i}">${Object.entries(AN.fields).map(([k, t]) => `<option value="${k}"${v === k ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select></label>`;
    }).join('');
    const types = Object.keys(iss);
    $('#buIssTabs').innerHTML = types.length ? [['all', 'همه', nIss], ...types.map(t => [t, AN.issue_labels[t] || t, iss[t]])].map(([k, l, n]) => `<button data-t="${k}" class="${issTab === k ? 'on' : ''}">${esc(l)}<em>${fa(n)}</em></button>`).join('') : '';
    const list = AN.issues.filter(x => issTab === 'all' || x.t === issTab);
    const sev = t => ['img_no_row', 'wh_mismatch', 'dup_code', 'bad_name', 'exists'].includes(t) ? 'bad' : 'wa';
    $('#buIss').innerHTML = list.length ? `<table class="bu-tbl"><tbody>${list.slice(0, 500).map(x => `<tr class="${sev(x.t)}"><td>${x.img ? `<img src="/admin-tools/bulk/${ID}/thumb/${encodeURIComponent(x.img)}" loading="lazy" alt="">` : ''}</td><td><span class="bu-chip ${sev(x.t)}">${esc(AN.issue_labels[x.t] || x.t)}</span></td><td class="bu-ltr">${esc(fa(x.code || ''))}</td><td>${esc(x.name || x.img || '')}</td><td>${x.row ? 'ردیف ' + fa(x.row) : ''}</td><td>${x.pid ? `<a target="_blank" href="${PRODUCTS}/${x.pid}/edit">کالای موجود: ${esc(x.msg)}</a>` : esc(x.msg || '')}</td></tr>`).join('')}</tbody></table>` : '<p class="bu-note" style="font-size:14px">🎉 مغایرتی نیست؛ همه عکس‌ها و ردیف‌ها با هم جورند.</p>';
    $('#buRows').innerHTML = AN.rows.slice(0, 600).map(r => {
        const miss = [...(r.flags.includes('no_price') ? ['قیمت'] : []), ...(r.imgs.length ? [] : ['عکس']), ...(r.cat ? [] : ['دسته']), ...(r.flags.includes('no_name') ? ['نام'] : [])];
        const cls = r.flags.includes('wh_mismatch') ? 'bad' : miss.length ? 'wa' : 'ok';
        return `<tr class="${cls}"><td>${r.imgs[0] ? `<img src="/admin-tools/bulk/${ID}/thumb/${encodeURIComponent(r.imgs[0])}" loading="lazy" alt="">` : ''}</td><td class="bu-ltr">${fa(r.code)}</td><td><b>${esc(r.name)}</b>${r.imgs.length > 1 ? ` <span class="bu-chip mu">${fa(r.imgs.length)} عکس</span>` : ''}</td><td>${money(r.price)}</td><td>${fa(r.pc)}${r.unit ? ' ' + esc(r.unit) : ''}${+r.pc === 1 ? ' <span class="bu-chip mu">تکی</span>' : ''}</td><td>${r.wh ? fa(r.wh) : '—'}</td><td>${r.cat ? esc(r.cat) + (r.cat_guess ? ' <span class="bu-chip mu">خودکار</span>' : '') : '<span class="bu-chip wa">انتخاب نشده</span>'}</td><td>${miss.length ? `<span class="bu-chip wa">ناقص: ${miss.join('، ')}</span>` : '<span class="bu-chip ok">آماده</span>'}${r.flags.includes('wh_mismatch') ? ' <span class="bu-chip bad">مغایرت انبار</span>' : ''}</td></tr>`;
    }).join('') + (AN.rows.length > 600 ? `<tr><td colspan="8" class="bu-note">و ${fa(AN.rows.length - 600)} کالای دیگر…</td></tr>` : '');
    const U = AN.updates || [];
    $('#buUpd').hidden = !U.length;
    if (U.length) $('#buUpdList').innerHTML = U.slice(0, 400).map(u => `<tr><td>${u.old ? `<img src="${esc(u.old)}" loading="lazy" alt="" style="opacity:.6">` : '<span class="bu-chip mu">بی‌عکس</span>'}</td><td style="font-size:18px">←</td><td><img src="/admin-tools/bulk/${ID}/thumb/${encodeURIComponent(u.imgs[0])}" loading="lazy" alt=""></td><td class="bu-ltr">${fa(u.code)}</td><td><a target="_blank" href="${PRODUCTS}/${u.pid}/edit"><b>${esc(u.name)}</b></a>${u.imgs.length > 1 ? ` <span class="bu-chip mu">+${fa(u.imgs.length - 1)} عکس گالری</span>` : ''}</td></tr>`).join('') + (U.length > 400 ? `<tr><td colspan="5" class="bu-note">و ${fa(U.length - 400)} کالای دیگر…</td></tr>` : '');
    $('#buMakeNote').innerHTML = (s.rows ? '<b style="font-size:15px">' + fa(s.rows) + ' کالا</b> پنهان و «منتظر تأیید» ساخته می‌شود.' : '') + (U.length ? (s.rows ? '<br>' : '') + '<b style="font-size:15px">' + fa(U.length) + ' کالای موجود</b>: عکس اصلی عوض می‌شود و عکس قبلی به گالری می‌رود.' : '');
    $('#buMake').disabled = !s.rows && !U.length;
}
$('#buIssTabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { issTab = b.dataset.t; drawAn(); } });
$('#buMap').addEventListener('change', e => { const l = e.target.closest('label'); if (l) { l.className = e.target.value ? 'on' : 'off'; l.querySelector('i').textContent = e.target.value ? '✓ خوانده می‌شود' : 'نادیده'; } });
$('#buRe').onclick = async () => {
    const m = {}; document.querySelectorAll('#buMap select').forEach(s => { m[s.dataset.i] = s.value; });
    $('#buRe').disabled = true;
    try { await analyze(m); } catch (e) { alert(e.message); }
    $('#buRe').disabled = false;
};
$('#buCancel').onclick = async () => { if (!confirm('فایل‌های این آپلود پاک شود؟')) return; await api('/' + ID + '/cancel').catch(() => {}); location.reload(); };

/* ---------- ۴. ساخت: چند بسته هم‌زمان ---------- */
$('#buMake').onclick = async () => {
    $('#buAn').hidden = true; $('#buMk').hidden = false; step(4); scrollTo({ top: 0, behavior: 'smooth' });
    const R = $('#buRingMk'), total = AN.stats.rows, CH = 15, UT = (AN.updates || []).length; let next = 0, made = 0, finished = 0, errs = [], updated = 0;
    const t0 = performance.now();
    ring(R, 0);
    const tick = () => {
        const sec = (performance.now() - t0) / 1000, rate = finished / Math.max(.5, sec);
        ring(R, total ? finished / total : 1, fa(finished) + ' از ' + fa(total));
        $('#buMkStats').innerHTML = `<span>✅ ${fa(made)} کالا ساخته شد</span>` + (finished < total && finished > 5 ? `<span>⏳ حدود ${eta((total - finished) / rate)} مانده</span>` : '') + (errs.length ? `<span style="color:var(--bad)">⚠ ${fa(errs.length)} خطا</span>` : '');
    };
    const worker = async () => {
        while (next < total) {
            const off = next; next += CH;
            for (let t = 0; ; t++) {
                try { const j = await api('/' + ID + '/create', { offset: off, limit: CH, parallel: 1 }); made += j.made; errs = errs.concat(j.errors || []); break; }
                catch (e) { if (t >= 2) { errs.push({ code: 'بسته ' + fa(off), msg: e.message }); break; } await new Promise(r => setTimeout(r, 1200 * (t + 1))); }
            }
            finished = Math.min(total, finished + CH); tick();
        }
    };
    tick();
    await Promise.all([worker(), worker(), worker()]);
    // تعویض عکس کالاهای موجود (قبل از پاک شدن فایل‌های آپلود)
    for (let off = 0; off < UT; off += 10) {
        ring(R, (off) / UT, 'عکس ' + fa(off) + ' از ' + fa(UT));
        for (let t = 0; ; t++) {
            try { const j = await api('/' + ID + '/update-images', { offset: off, limit: 10 }); updated += j.updated; errs = errs.concat(j.errors || []); break; }
            catch (e) { if (t >= 2) { errs.push({ code: 'عکس‌ها ' + fa(off), msg: e.message }); break; } await new Promise(r => setTimeout(r, 1200 * (t + 1))); }
        }
    }
    let res = { made };
    try { res = await api('/' + ID + '/finish'); } catch (e) {}
    $('#buMk').hidden = true; $('#buDone').hidden = false;
    document.querySelectorAll('#buSteps div').forEach(s => s.className = 'done'); $('#buTrack').style.width = '75%';
    $('#buDoneT').textContent = (total ? fa(res.made ?? made) + ' کالا ساخته شد' : '') + (total && UT ? ' و ' : '') + (UT ? 'عکس ' + fa(updated) + ' کالا عوض شد' : '') + ' 🎉';
    $('#buDoneD').textContent = (errs.length ? fa(errs.length) + ' ردیف ساخته نشد. ' : '') + 'کالاها پنهان و منتظر تأیید هستند. در صفحه بعد دسته هر کالا را همان‌جا در جدول انتخاب کنید (خودکار ذخیره می‌شود)، موارد ناقص را کامل و گروهی «تأیید و انتشار» بزنید.';
    $('#buReview').href = PRODUCTS + '?activeTab=pending&tableFilters[import_id][value]=' + ID;
    confetti();
};
</script>
</x-filament-panels::page>
