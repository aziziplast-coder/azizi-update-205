@php
    $S = \App\Services\Crm::SEGMENTS;
    $cu = \App\Filament\Pages\CrmCustomers::getUrl();
@endphp
<x-filament-panels::page>
<style>
.crm-g{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px}
.crm-k{position:relative;border-radius:18px;padding:14px;background:var(--c-bg,#fff);border:1px solid rgba(127,127,127,.15);text-decoration:none;color:inherit;display:block;overflow:hidden;transition:transform .15s}
.crm-k:hover{transform:translateY(-2px)}
.crm-k::before{content:'';position:absolute;inset:0 0 auto 0;height:4px;background:var(--c)}
.crm-k small{display:block;font-size:12.5px;font-weight:700;color:var(--c)}.crm-k b{font-size:26px;font-weight:900;display:block;margin:4px 0}.crm-k span{font-size:11.5px;opacity:.7}
.dark .crm-k{background:rgba(255,255,255,.03)}
.crm-row{display:grid;grid-template-columns:1.2fr 1fr;gap:14px;margin-top:14px}
.crm-box{border:1px solid rgba(127,127,127,.15);border-radius:18px;padding:16px;background:#fff}.dark .crm-box{background:rgba(255,255,255,.03)}
.crm-box h3{margin:0 0 12px;font-size:14.5px;font-weight:800}
.crm-trend{display:flex;align-items:flex-end;gap:3px;height:120px}.crm-trend div{flex:1;display:flex;flex-direction:column-reverse;min-width:4px}.crm-trend i{display:block}
.crm-legend{display:flex;flex-wrap:wrap;gap:10px;font-size:12px;margin-top:8px}.crm-legend span::before{content:'';display:inline-block;width:10px;height:10px;border-radius:3px;background:var(--c);margin-left:4px;vertical-align:middle}
.crm-t{width:100%;border-collapse:collapse;font-size:13px}.crm-t th,.crm-t td{padding:7px 6px;border-bottom:1px solid rgba(127,127,127,.12);text-align:right}.crm-t th{opacity:.65;font-weight:700;font-size:12px}
.crm-big{display:flex;gap:16px;align-items:center}.crm-big b{font-size:30px;font-weight:900;color:#16a34a}
.crm-btns{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
.crm-help{font-size:12.5px;opacity:.75;line-height:2}
@media (max-width:1100px){.crm-g{grid-template-columns:repeat(3,1fr)}.crm-row{grid-template-columns:1fr}}
</style>
<div class="crm-g">
    @foreach ($S as $k => [$label, $color])
        <a class="crm-k" style="--c:{{ $color }}" href="{{ $cu }}?tableFilters[segment][values][0]={{ $k }}">
            <small>{{ $label }}</small><b>{{ fa((int) ($seg[$k]->n ?? 0)) }}</b><span>خرید ۱۲ ماه: {{ money((int) ($seg[$k]->s ?? 0)) }}</span>
        </a>
    @endforeach
</div>
<div class="crm-row">
    <div class="crm-box">
        <h3>📈 روند دسته‌ها (۳۰ روز اخیر)</h3>
        @php $max = max(1, $snap->max(fn ($x) => array_sum((array) json_decode($x->counts, true)))); @endphp
        @if ($snap->count() < 2)
            <p class="crm-help">نمودار بعد از چند روز کامل می‌شود (هر روز یک بار خودکار حساب می‌شود).</p>
        @endif
        <div class="crm-trend">
            @foreach ($snap as $x)
                @php $c = (array) json_decode($x->counts, true); @endphp
                <div title="{{ jdate($x->day) }}">@foreach ($S as $k => [$l, $col])<i style="height:{{ round(($c[$k] ?? 0) / $max * 120) }}px;background:{{ $col }}"></i>@endforeach</div>
            @endforeach
        </div>
        <div class="crm-legend">@foreach ($S as $k => [$l, $col])<span style="--c:{{ $col }}">{{ $l }}</span>@endforeach</div>
    </div>
    <div class="crm-box">
        <h3>🔄 برگشتی‌های این ماه</h3>
        <div class="crm-big"><b>{{ fa($returned) }}</b><div>مشتری «در خطر / از دست رفته» دوباره خرید کرد<br><span class="crm-help">جمع خریدشان در این ماه: <b>{{ money($retSum) }}</b> تومان</span></div></div>
        <p class="crm-help">کل مشتریان: {{ fa($total) }} — با موبایل: {{ fa($withMobile) }} — در فهرست تماس مشاوران: {{ fa($queue) }}<br>
            آخرین فاکتور هلو: {{ $holooMax ? jdate($holooMax) : '—' }} · آخرین محاسبه: {{ $computed ? jdate(\Illuminate\Support\Carbon::parse($computed), true) : '—' }}</p>
        <div class="crm-btns">
            <x-filament::button size="sm" color="gray" wire:click="recompute" icon="heroicon-o-arrow-path">محاسبه دوباره</x-filament::button>
            <x-filament::button size="sm" color="gray" wire:click="assign" icon="heroicon-o-phone">پر کردن فهرست تماس مشاوران</x-filament::button>
        </div>
    </div>
</div>
<div class="crm-row">
    <div class="crm-box">
        <h3>🏆 مشاوران در این ماه</h3>
        @if ($lead->isEmpty())
            <p class="crm-help">هنوز تماس یا فروشی ثبت نشده است.</p>
        @else
            <table class="crm-t"><tr><th>مشاور</th><th>تماس</th><th>نتیجه مثبت</th><th>مشتری برگشته</th><th>فروش (پورسانت‌دار)</th></tr>
                @foreach ($lead as $i => $x)<tr><td>{{ ['🥇', '🥈', '🥉'][$i] ?? fa($i + 1) }} {{ $x['n'] }}</td><td>{{ fa($x['calls']) }}</td><td>{{ fa($x['ok']) }}</td><td><b>{{ fa($x['ret']) }}</b></td><td>{{ money($x['sales']) }}</td></tr>@endforeach
            </table>
        @endif
    </div>
    <div class="crm-box">
        <h3>📥 ورود اکسل از هلو</h3>
        <form wire:submit="import">
            {{ $this->form }}
            <div class="crm-btns"><x-filament::button type="submit" icon="heroicon-o-arrow-up-tray">ورود و محاسبه</x-filament::button></div>
        </form>
        <p class="crm-help">از هلو این گزارش‌ها را اکسل بگیرید: <b>۱) فهرست اشخاص</b> (کد، نام، موبایل، شهر، فروشگاه) — <b>۲) فهرست فاکتورهای فروش</b> (شماره، تاریخ، نام/کد مشتری، مبلغ؛ ترجیحاً ۲ تا ۳ سال) — <b>۳) اختیاری: فروش کالا به تفکیک مشتری</b>. ستون‌ها از روی عنوانشان پیدا می‌شوند؛ ورود دوباره فقط تازه‌ها را اضافه می‌کند. واحد مبلغ (ریال/تومان) در تنظیمات.</p>
        @if ($imports->isNotEmpty())
            <table class="crm-t"><tr><th>فایل</th><th>نوع</th><th>ردیف</th><th>زمان</th></tr>
                @foreach ($imports as $im)@php $st = (array) json_decode($im->stats, true); @endphp<tr><td>{{ \Illuminate\Support\Str::limit($im->file, 30) }}</td><td>{{ ['customers' => 'اشخاص', 'invoices' => 'فاکتورها', 'items' => 'کالاها'][$im->kind] ?? $im->kind }}</td><td>{{ fa($st['rows'] ?? 0) }}</td><td>{{ jdate($im->created_at, true) }}</td></tr>@endforeach
            </table>
        @endif
    </div>
</div>
</x-filament-panels::page>
