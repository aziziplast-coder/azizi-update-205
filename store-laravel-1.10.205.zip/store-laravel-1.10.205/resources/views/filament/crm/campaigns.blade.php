<x-filament-panels::page>
    <div style="font-size:13px;opacity:.8;margin-bottom:-8px;line-height:1.9">هر کمپین به گروهی از مشتریان پیامک می‌فرستد؛ اگر تا {{ fa(\App\Services\Crm::cfg()['return_days']) }} روز بعد خرید کنند (در سایت یا در فاکتورهای هلو)، «برگشته» حساب می‌شوند. لینک داخل پیامک، لینک مشاورِ همان مشتری است تا پورسانت به نام او ثبت شود.</div>
    {{ $this->table }}
</x-filament-panels::page>
