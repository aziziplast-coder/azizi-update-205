@php
    $u = auth()->user();
    $admin = $u->isAdmin();
    $cfg = [
        'csrf' => csrf_token(), 'inbox' => route('admin.chat.inbox'), 'show' => route('admin.chat.show', 0), 'products' => route('admin.chat.products'),
        'typing' => url('chat-t.php'), 'up' => route('admin.chat.up'), 'mb' => asset('js/vendor/mediabunny.min.js'), 'sig' => \App\Services\Chat::staffSignalUrl($u->id), 'orderUrl' => url('/admin/orders/0'),
        'admin' => $admin, 'me' => (int) $u->id, 'open' => (int) request('o') ?: null, 'alert' => max(1, \App\Services\Chat::cfg()['alert_min'] ?: 30),
        'filters' => $admin
            ? [['open', 'همه باز'], ['unread', 'خوانده‌نشده'], ['waiting', 'بی‌جواب'], ['rcpt', '🧾 فیش رسیده'], ['mine', 'مال من'], ['nobody', 'بی‌مسئول'], ['closed', 'بسته'], ['cancelled', '✖ لغو شده']]
            : [['open', 'باز'], ['unread', 'خوانده‌نشده'], ['waiting', 'بی‌جواب'], ['rcpt', '🧾 فیش رسیده'], ['closed', 'بسته'], ['cancelled', '✖ لغو شده']],
    ];
    \App\Services\Chat::staffSignal($u->id); // فایل شمارنده همین همکار حتماً باشد
    $stats = $admin ? \App\Services\Chat::stats() : null;
@endphp
<x-filament-panels::page>
<div x-data="{ tab: 'chat' }" wire:ignore>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:12px">
        <h1 style="margin:0;font-size:22px;font-weight:900">💬 گفتگو با مشتری</h1>
        @if ($admin)
            <div style="display:flex;gap:6px;background:rgba(0,0,0,.05);padding:4px;border-radius:14px" class="dark:bg-white/5">
                <button type="button" @click="tab='chat'" class="chs-tab" :class="tab==='chat' && 'on'">💬 گفتگوها</button>
                <button type="button" @click="tab='stats'" class="chs-tab" :class="tab==='stats' && 'on'">📊 گزارش همکاران</button>
                <a href="{{ url('/admin/settings/chat') }}" class="chs-tab" title="تنظیمات گفتگو">⚙️</a>
            </div>
        @endif
    </div>

    @php $sigOk = is_writable(\App\Services\Chat::dir()); @endphp
    @unless ($sigOk)
        <div style="background:#fee2e2;color:#991b1b;border-radius:12px;padding:10px 14px;margin-bottom:10px;font-size:13px">پوشه <code dir="ltr">public/uploads/_chat</code> روی هاست قابل نوشتن نیست؛ پیام‌ها با تأخیر (هر ۳۰ ثانیه) می‌رسند. از مدیر فایل هاست، دسترسی این پوشه را 755 بگذارید.</div>
    @endunless
    <div x-show="tab==='chat'">
        <div class="chs" id="chs" data-chat="{{ json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) }}"></div>
    </div>

    @if ($admin)
    <div x-show="tab==='stats'" x-cloak>
        <div class="chs-stats">
            <div><b>{{ fa($stats['open']) }}</b><small>گفتگوی فعال (۷ روز)</small></div>
            <div><b style="color:#d97706">{{ fa($stats['waiting']) }}</b><small>منتظر پاسخ همکار</small></div>
            <div><b style="color:#dc2626">{{ fa($stats['unassigned']) }}</b><small>پیام بی‌مسئول</small></div>
        </div>
        <div style="background:#fff;border-radius:20px;padding:12px;border:1px solid rgba(0,0,0,.06);overflow-x:auto" class="dark:!bg-gray-900">
            <table class="chs-table">
                <thead><tr><th>همکار</th><th>گفتگو (۳۰ روز)</th><th>بی‌جواب الان</th><th>میانگین زمان پاسخ</th><th>اولین پاسخ</th><th>امتیاز مشتریان (نظرسنجی)</th></tr></thead>
                <tbody>
                @forelse ($stats['staff'] as $s)
                    <tr>
                        <td><b>{{ $s['name'] }}</b></td>
                        <td>{{ fa($s['threads']) }}</td>
                        <td>@if ($s['waiting'])<b style="color:#dc2626">{{ fa($s['waiting']) }}</b>@else — @endif</td>
                        <td>{{ \App\Services\Chat::dur($s['avg_reply']) }}</td>
                        <td>{{ \App\Services\Chat::dur($s['first_reply']) }}</td>
                        <td>@if ($s['rating'])<span class="chs-star">★ {{ fa($s['rating']) }}</span> <small style="opacity:.6">از {{ fa($s['votes']) }} نظر</small>@else — @endif</td>
                    </tr>
                @empty
                    <tr><td colspan="6" style="text-align:center;opacity:.6;padding:24px">هنوز گفتگویی ثبت نشده است.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
        <p style="font-size:12px;opacity:.6;margin-top:8px">زمان پاسخ: فاصله پیام مشتری تا اولین جواب مسئول. امتیاز از نظرسنجی پایان سفارش (سؤال‌های مربوط به همکار) خوانده می‌شود.</p>
    </div>
    @endif
</div>
<script>
(function () {
    function go() { var r = document.getElementById('chs'); if (r && window.StoreChat) window.StoreChat.staff(r); else setTimeout(go, 60); }
    go();
})();
</script>
</x-filament-panels::page>
