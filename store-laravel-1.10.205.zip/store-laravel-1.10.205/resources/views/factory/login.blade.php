@extends('factory.layout', ['title' => \App\Services\FactoryPortal::cfg()['name']])
@section('body')
<div class="fp-login">
    <div class="fp-login-ic"><img src="{{ route('pwa.factory_icon', 192) }}" alt="" width="96" height="96" style="width:96px;height:96px;border-radius:24px;box-shadow:0 4px 14px rgba(0,0,0,.18)"></div>
    <h1>ورود کارخانه‌داران</h1>
    <p class="muted">حواله‌های صادرشده برای شما، واریزها و تأیید نشستن مبلغ در حساب.</p>
    <form method="post" action="{{ url('/factory/login') }}" class="fp-card fp-form">
        @csrf
        @if ($step === 'code')
            <label>کد پیامک‌شده به {{ fa($mobile) }}
                <input name="code" inputmode="numeric" autocomplete="one-time-code" dir="ltr" maxlength="8" required autofocus class="fp-big">
            </label>
            <input type="hidden" name="mobile" value="{{ $mobile }}">
            <button class="fp-btn">ورود</button>
            <button class="fp-link" type="submit" form="resend">ارسال دوباره کد</button>
        @else
            <label>شماره موبایل
                <input name="mobile" inputmode="numeric" dir="ltr" maxlength="14" placeholder="09xxxxxxxxx" value="{{ $mobile }}" required autofocus class="fp-big">
            </label>
            <button class="fp-btn">دریافت کد ورود</button>
        @endif
    </form>
    @if ($step === 'code')
        <form id="resend" method="post" action="{{ url('/factory/login') }}">@csrf<input type="hidden" name="mobile" value="{{ $mobile }}"></form>
    @endif
    <p class="muted" style="font-size:13px">فقط شماره‌هایی که حسابداری شرکت ثبت کرده می‌توانند وارد شوند.</p>
</div>
@endsection
