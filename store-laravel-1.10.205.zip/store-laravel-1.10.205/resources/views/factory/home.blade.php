@extends('factory.layout', ['nav' => $tab === 'remits' ? 'remits' : ($tab === 'done' ? 'done' : 'todo')])
@section('body')
@if ($tab === 'todo')
    <div class="fp-tiles">
        <div class="fp-tile {{ $sum['decide'] ? 'warn' : '' }}"><small>منتظر تصمیم شما</small><b>{{ fa($sum['decide']) }}</b><span>حواله</span></div>
        <div class="fp-tile {{ $sum['waiting_n'] ? 'info' : '' }}"><small>فیش منتظر تأیید</small><b>{{ fa($sum['waiting_n']) }}</b><span>{{ money($sum['waiting']) }} ت</span></div>
        <div class="fp-tile ok"><small>دریافت‌شده (تأیید شما)</small><b>{{ money($sum['received']) }}</b><span>تومان</span></div>
        <div class="fp-tile"><small>جمع حواله‌ها</small><b>{{ money($sum['total']) }}</b><span>تومان</span></div>
    </div>

    @php $todo = $rs->filter(fn ($r) => \App\Services\FactoryPortal::needsDecision($r)); $rev = $rs->where('dest_status', 'review'); @endphp
    @if ($todo->isNotEmpty())
        <h2 class="fp-h">🔔 حواله‌های منتظر تصمیم شما</h2>
        @foreach ($todo as $r)
            <a href="{{ route('factory.remit', $r) }}" class="fp-card fp-remit todo">
                <div class="fp-remit-h"><b>{{ money($r->amount) }} <small>تومان</small></b><span class="fp-tag">{{ $r->code }}</span></div>
                <div>{{ $r->title }}</div>
                @if ($r->dest_status === 'rejected')<div class="fp-wait late">حسابداری رد کرد: {{ $r->dest_reason }} — لطفاً اصلاح کنید.</div>@endif
                <span class="fp-btn">تعیین حساب واریز ←</span>
            </a>
        @endforeach
    @endif
    @if ($rev->isNotEmpty())
        <h2 class="fp-h">⏳ در حال بررسی حسابداری</h2>
        @foreach ($rev as $r)
            <a href="{{ route('factory.remit', $r) }}" class="fp-card fp-remit"><div class="fp-remit-h"><b>{{ money($r->amount) }} <small>تومان</small></b><span class="fp-tag">{{ $r->code }}</span></div><small class="muted">حساب مقصد ثبت شد؛ پس از تأیید حسابداری پیامک می‌شود.</small></a>
        @endforeach
    @endif

    <h2 class="fp-h">💳 فیش‌های منتظر تأیید شما @if ($sum['late_n'])<span class="fp-badge err">{{ fa($sum['late_n']) }} دیرکرد</span>@endif</h2>
    @if ($wait->isEmpty())
        <div class="fp-empty">فیش تازه‌ای منتظر تأیید نیست 👌</div>
    @else
        <p class="muted fp-note">پس از نشستن هر مبلغ در حساب، «به حسابم نشست» را بزنید. کارت‌به‌کارت معمولاً فوری است؛ پایا ممکن است تا چرخه بعدی بانک (چند ساعت، روزهای کاری) و ساتنا تا پایان همان روز کاری طول بکشد.</p>
        @if ($wait->count() > 1)
            <form id="many" method="post" action="{{ route('factory.confirm.many') }}" onsubmit="return confirm('همه فیش‌های انتخاب‌شده به حسابتان نشسته است؟')" class="fp-many">
                @csrf
                <label><input type="checkbox" onclick="document.querySelectorAll('.fp-chk').forEach(c=>c.checked=this.checked)"> انتخاب همه</label>
                <button class="fp-btn fp-btn-sm">✓ تأیید انتخاب‌شده‌ها</button>
            </form>
        @endif
        @foreach ($wait as $p)
            @include('factory._pay', ['p' => $p, 'sel' => $wait->count() > 1])
        @endforeach
    @endif
@elseif ($tab === 'remits')
    <h2 class="fp-h">🧾 حواله‌های شما</h2>
    @forelse ($rs as $r)
        @php $s = $st[$r->id]; $pct = $r->amount > 0 ? min(100, round($s['confirmed'] * 100 / $r->amount)) : 0; @endphp
        <a href="{{ route('factory.remit', $r) }}" class="fp-card fp-remit">
            <div class="fp-remit-h"><b>{{ money($r->amount) }} <small>تومان</small></b><span class="fp-tag">{{ $r->code }}</span></div>
            <div class="fp-remit-sub">{{ $r->title }}@if ($r->holder_name) — به حساب {{ $r->holder_name }}@endif</div>
            @if ($r->status !== 'transferred')<div class="fp-bar"><i style="width:{{ $pct }}%"></i></div>@endif
            <div class="fp-remit-f"><span>واریز تأییدشده: <b>{{ money($s['confirmed']) }}</b></span><span>مانده: <b>{{ money($s['left']) }}</b></span>
                <span @class(['fp-st', $r->status])>{{ $r->status === 'pending' ? (\App\Models\Remittance::DEST[$r->dest_status] ?? 'منتظر تعیین حساب') : $r->statusLabel() }}</span></div>
        </a>
    @empty
        <div class="fp-empty">هنوز حواله‌ای برای شما صادر نشده است.</div>
    @endforelse
@else
    <h2 class="fp-h">✅ فیش‌های تأییدشده (۵۰ مورد آخر)</h2>
    @forelse ($done as $p)
        @include('factory._pay', ['p' => $p])
    @empty
        <div class="fp-empty">هنوز فیشی تأیید نکرده‌اید.</div>
    @endforelse
@endif
@endsection
