@extends('factory.layout', ['title' => 'گفتگو با حسابداری', 'nav' => 'chat', 'back' => route('factory.home')])
@push('head')<link rel="stylesheet" href="{{ asset('css/chat.css') }}?v={{ config('store.version') }}">@endpush
@section('body')
@php
    $cfg = [
        'plain' => true, 'side' => 'c', 'hash' => 'fchat', 'autoOpen' => true, 'closeUrl' => route('factory.home'),
        'csrf' => csrf_token(), 'state' => route('factory.chat.state'), 'act' => route('factory.chat.act'), 'typing' => url('chat-t.php'),
        'up' => route('factory.chat.up'), 'mb' => asset('js/vendor/mediabunny.min.js'),
        'sig' => \App\Services\Chat::signalUrl($t), 'last' => (int) $t->customer_read_id, 'unread' => (int) $t->unread_customer,
        'title' => 'حسابداری '.store_name(), 'sub' => 'درباره حواله‌ها و واریزها بپرسید', 'initial' => '🧾',
        'phone' => setting('phone') ? en_digits((string) setting('phone')) : null,
        'empty' => '<i>💬</i><b>سؤالی درباره حواله یا واریزها دارید؟</b><br>همین‌جا بنویسید؛ حسابداری پاسخ می‌دهد.',
    ];
@endphp
<div id="fchat" data-chat="{{ json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) }}">
    <button type="button" class="chc-card fp-card" style="width:100%;text-align:right">
        <span class="ch-av">🧾</span>
        <div><b>گفتگو با حسابداری {{ store_name() }}</b><small>{{ $t->last_text ?: 'درباره حواله‌ها و واریزها همین‌جا بپرسید' }}</small></div>
        <span class="go">💬 باز کردن</span>
    </button>
</div>
@endsection
@push('js')
<script src="{{ asset('js/chat.js') }}?v={{ config('store.version') }}"></script>
<script>StoreChat.customer(document.getElementById('fchat'));</script>
@endpush
