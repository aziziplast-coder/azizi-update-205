@extends('factory.layout', ['title' => 'حساب‌های ذخیره‌شده', 'nav' => 'accounts'])
@section('body')
<p class="muted">این حساب‌ها هنگام تعیین مقصد حواله با یک انتخاب پر می‌شوند. حساب تازه را هنگام تعیین مقصد حواله اضافه کنید.</p>
@forelse ($accounts as $a)
    <div class="fp-card fp-dest">
        <div class="fp-remit-h"><b>{{ $a->holder_name }}</b><span class="fp-tag">{{ $a->kind === 'other' ? 'شخص دیگر' : 'حساب خودم' }}</span></div>
        <small class="muted" dir="ltr" style="text-align:right;display:block">{{ $a->bank_name }} {{ \App\Support\Banks::formatSheba($a->sheba) }} {{ $a->card_number ? ' / '.\App\Support\Banks::formatCard($a->card_number) : '' }}</small>
        @if ($a->mobile)<small class="muted">موبایل: {{ fa($a->mobile) }}</small>@endif
        <form method="post" action="{{ route('factory.account.delete', $a) }}" onsubmit="return confirm('این حساب حذف شود؟')">@csrf<button class="fp-link danger">حذف</button></form>
    </div>
@empty
    <div class="fp-empty">هنوز حسابی ذخیره نشده است.</div>
@endforelse
@endsection
