@extends('factory.layout', ['title' => 'حواله '.$r->code, 'back' => route('factory.home', ['tab' => 'remits']), 'nav' => 'remits'])
@section('body')
@php $pct = $r->amount > 0 ? min(100, round($st['confirmed'] * 100 / $r->amount)) : 0; @endphp
<div class="fp-card fp-hero">
    <small>{{ $r->title }}</small>
    <div class="fp-hero-amt">{{ money($r->amount) }} <small>تومان</small></div>
    <div class="fp-hero-meta"><span class="fp-tag">{{ $r->code }}</span><span>صدور: {{ jdate($r->created_at) }}</span>
        <span @class(['fp-st', $r->status])>{{ $r->status === 'pending' ? (\App\Models\Remittance::DEST[$r->dest_status] ?? 'منتظر تعیین حساب') : $r->statusLabel() }}</span></div>
    @if (! in_array($r->status, ['pending', 'transferred'], true))
        <div class="fp-bar"><i style="width:{{ $pct }}%"></i></div>
        <div class="fp-remit-f"><span>واریز تأییدشده: <b>{{ money($st['confirmed']) }}</b></span><span>مانده: <b>{{ money($st['left']) }}</b></span></div>
    @endif
</div>

@if ($decide)
    <div class="fp-card fp-decide">
        @php $third = $factory->isThird(); @endphp
        @if ($third)
            <h2 class="fp-h" style="margin-top:0">حساب خود را برای دریافت این مبلغ وارد کنید</h2>
            <p class="muted">این حواله{{ $factory->referrer ? ' از طرف '.$factory->referrer->name : '' }} به شما منتقل شده است. مبلغ مستقیم به حسابی که وارد می‌کنید واریز می‌شود و هر واریز را همین‌جا می‌بینید و تأیید می‌کنید.</p>
        @else
            <h2 class="fp-h" style="margin-top:0">این حواله به کدام حساب واریز شود؟</h2>
            <p class="muted">مبلغ را به حساب خودتان بگیرید، یا به شخص دیگری منتقل کنید (فقط نام و موبایل؛ بقیه را خود او در همین اپ وارد می‌کند){{ $cfg['allow_split'] ? '، یا بین چند نفر تقسیم کنید' : '' }}.</p>
        @endif
        @if ($r->dest_status === 'rejected')<div class="fp-alert err">حسابداری قبلی را رد کرد: {{ $r->dest_reason }}</div>@endif

        <form method="post" action="{{ route('factory.dest', $r) }}" id="destForm" data-total="{{ (int) $r->amount }}" data-split="{{ $cfg['allow_split'] && ! $third ? 1 : 0 }}" data-max="{{ $cfg['max_split'] }}" data-third="{{ $third ? 1 : 0 }}">
            @csrf
            <div id="rows"></div>
            @if ($cfg['allow_split'] && ! $third)
                <button type="button" class="fp-btn fp-btn-line" id="addRow">＋ تقسیم: افزودن ردیف دیگر <small>(حداکثر {{ fa($cfg['max_split']) }} حساب)</small></button>
            @endif
            <div class="fp-sum" id="sumBox" hidden>جمع: <b id="sumVal">۰</b> از {{ money($r->amount) }} تومان — <span id="sumMsg"></span></div>
            <button class="fp-btn fp-btn-ok" id="sendBtn">ثبت</button>
        </form>
    </div>

    <template id="rowTpl">
        <fieldset class="fp-row">
            <legend>ردیف <span data-n></span> <button type="button" class="fp-x" data-del aria-label="حذف">✕</button></legend>
            <div class="fp-kind" @if ($factory->isThird()) hidden @endif>
                <label><input type="radio" data-f="kind" value="own" checked> <span>💼 به حساب خودم</span></label>
                <label><input type="radio" data-f="kind" value="other"> <span>👤 انتقال به شخص دیگر</span></label>
            </div>
            <label data-amount>مبلغ این ردیف (تومان)<input data-f="amount" inputmode="numeric" dir="ltr" class="fp-money"></label>
            <label><span data-holder-l>نام صاحب حساب</span><input data-f="holder_name" maxlength="120" required></label>
            <div data-other hidden class="fp-other">
                <label>شماره موبایل گیرنده<input data-f="mobile" inputmode="numeric" dir="ltr" maxlength="14" placeholder="09xxxxxxxxx"></label>
                <small class="muted">با ثبت، حواله همان لحظه به این شخص منتقل و برایش پیامک می‌شود؛ شماره شبا و کارت را خودش در اپ وارد می‌کند و واریزها را خودش تأیید می‌کند.</small>
            </div>
            <div data-bankf class="fp-other">
            @if ($saved->isNotEmpty())
                <label>از حساب‌های ذخیره‌شده
                    <select data-saved><option value="">— حساب تازه —</option>
                        @foreach ($saved as $a)<option value="{{ $a->id }}">{{ $a->summary() }}</option>@endforeach
                    </select>
                </label>
            @endif
            <label>شماره شبا <small>(الزامی)</small>
                <div class="fp-sheba"><span>IR</span><input data-f="sheba" inputmode="numeric" dir="ltr" maxlength="32" placeholder="۲۴ رقم" required></div>
                <small class="fp-bank" data-bank></small>
            </label>
            <label>شماره کارت <small>(اختیاری)</small><input data-f="card_number" inputmode="numeric" dir="ltr" maxlength="23" placeholder="۱۶ رقم"></label>
            <label>شماره حساب <small>(اختیاری)</small><input data-f="account_number" inputmode="numeric" dir="ltr" maxlength="40"></label>
            <label class="fp-save"><input type="checkbox" data-f="save" value="1" checked> این حساب برای دفعه‌های بعد ذخیره شود</label>
            </div>
            <label>توضیح <small>(اختیاری)</small><input data-f="note" maxlength="300" placeholder="مثلاً بابت خرید مواد اولیه"></label>
        </fieldset>
    </template>
@endif

@if ($dests->isNotEmpty() && ! $decide)
    <h2 class="fp-h">🏦 حساب‌های مقصد</h2>
    @foreach ($dests as $d)
        <div class="fp-card fp-dest">
            <div class="fp-remit-h"><b>{{ money($d->amount) }} <small>تومان</small></b><span @class(['fp-st', $d->status])>{{ \App\Models\RemitDestination::STATUSES[$d->status] ?? $d->status }}</span></div>
            <div>{{ $d->kindLabel() }}: <b>{{ $d->holder_name }}</b>@if ($d->mobile) — {{ fa($d->mobile) }}@endif</div>
            @if ($d->status === 'transferred')
                @php $ch = $d->child; $cs = $ch?->stats(); @endphp
                <small class="muted">حواله {{ $ch?->code }} به نام این شخص ساخته شد —
                    {{ $ch ? ($ch->status === 'pending' ? (\App\Models\Remittance::DEST[$ch->dest_status] ?? '') : $ch->statusLabel().' — واریز تأییدشده '.money($cs['confirmed']).' تومان') : '' }}</small>
            @else
                <small class="muted" dir="ltr" style="text-align:right;display:block">{{ $d->accountLine() }}</small>
            @endif
            @if ($d->status === 'rejected' && $d->reason)<div class="fp-wait late">{{ $d->reason }}</div>@endif
        </div>
    @endforeach
@elseif ($r->status !== 'pending' && $r->holder_name)
    <div class="fp-card fp-dest"><small class="muted">واریز به حساب</small><div><b>{{ $r->holder_name }}</b> {{ $r->bank_name ? '— '.$r->bank_name : '' }}</div>
        <small class="muted" dir="ltr" style="text-align:right;display:block">{{ \App\Support\Banks::formatSheba($r->sheba) }} {{ $r->card_number ? ' / '.\App\Support\Banks::formatCard($r->card_number) : '' }}</small></div>
@endif

@if ($kids->isNotEmpty())
    <h2 class="fp-h">🔀 بخش‌های این حواله</h2>
    @foreach ($kids as $k)
        @php $ks = $k->stats(); @endphp
        <div class="fp-card fp-remit"><div class="fp-remit-h"><b>{{ money($k->amount) }} <small>تومان</small></b><span class="fp-tag">{{ $k->code }}</span></div>
            <div class="fp-remit-sub">به حساب {{ $k->holder_name }} {{ $k->bank_name ? '— '.$k->bank_name : '' }}</div>
            <div class="fp-remit-f"><span>واریز تأییدشده: <b>{{ money($ks['confirmed']) }}</b></span><span>مانده: <b>{{ money($ks['left']) }}</b></span></div></div>
    @endforeach
@endif

@if ($pays->isNotEmpty())
    <h2 class="fp-h">💳 فیش‌های واریزی</h2>
    @foreach ($pays as $p)
        @include('factory._pay', ['p' => $p])
    @endforeach
@elseif ($r->status === 'active')
    <div class="fp-empty">هنوز فیشی برای این حواله ثبت نشده است. با هر واریز مشتری پیامک می‌گیرید.</div>
@endif
@endsection

@if ($decide)
@php
    $savedJs = $saved->keyBy('id')->map(fn ($a) => $a->only(['kind', 'holder_name', 'card_number', 'sheba', 'account_number', 'mobile', 'national_id']));
    $oldJs = array_values((array) old('d', []));
@endphp
@push('js')
<script>
(function () {
    var form = document.getElementById('destForm'), rows = document.getElementById('rows'), tpl = document.getElementById('rowTpl');
    var total = +form.dataset.total, split = form.dataset.split === '1';
    var SHEBA = @json(\App\Support\Banks::SHEBA), BIN = @json(\App\Support\Banks::BIN);
    var SAVED = {!! json_encode($savedJs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) !!};
    var OLD = {!! json_encode($oldJs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) !!};
    var en = function (s) { return String(s || '').replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }).replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }); };
    var dig = function (s) { return en(s).replace(/\D/g, ''); };
    var fa = function (n) { return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; }); };
    var money = function (n) { return fa(String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '٬')); };
    function renumber() {
        var list = rows.querySelectorAll('.fp-row');
        list.forEach(function (r, i) {
            r.querySelector('[data-n]').textContent = fa(i + 1);
            r.querySelectorAll('[data-f]').forEach(function (el) { el.name = 'd[' + i + '][' + el.dataset.f + ']'; });
            r.querySelector('[data-del]').hidden = list.length < 2;
            r.querySelector('[data-amount]').hidden = list.length < 2;
        });
        var ab = document.getElementById('addRow'); if (ab) ab.hidden = list.length >= (+form.dataset.max || 2);
        sum();
    }
    function bank(row) {
        var s = dig(row.querySelector('[data-f=sheba]').value), c = dig(row.querySelector('[data-f=card_number]').value);
        var b = (s.length >= 5 && SHEBA[s.substr(2, 3)]) || (c.length >= 6 && BIN[c.substr(0, 6)]) || '';
        row.querySelector('[data-bank]').textContent = b ? 'بانک ' + b : '';
    }
    function sum() {
        var list = rows.querySelectorAll('.fp-row'), box = document.getElementById('sumBox');
        if (list.length < 2) { box.hidden = true; return; }
        var t = 0; list.forEach(function (r) { t += +dig(r.querySelector('[data-f=amount]').value) || 0; });
        box.hidden = false; document.getElementById('sumVal').textContent = money(t);
        var d = total - t, m = document.getElementById('sumMsg');
        m.textContent = d === 0 ? '✓ درست است' : (d > 0 ? money(d) + ' تومان باقی مانده' : money(-d) + ' تومان بیشتر از مبلغ حواله');
        box.className = 'fp-sum ' + (d === 0 ? 'ok' : 'err');
    }
    function kind(row) {
        var other = row.querySelector('[data-f=kind]:checked').value === 'other';
        row.querySelector('[data-other]').hidden = !other;
        row.querySelector('[data-bankf]').hidden = other;
        row.querySelector('[data-f=mobile]').required = other;
        row.querySelector('[data-f=sheba]').required = !other;
        row.querySelector('[data-holder-l]').textContent = other ? 'نام و نام خانوادگی گیرنده' : 'نام صاحب حساب';
        row.classList.toggle('other', other);
    }
    function fill(row, v) {
        Object.keys(v || {}).forEach(function (k) {
            if (k === 'kind') { var r = row.querySelector('[data-f=kind][value=' + (v.kind === 'other' ? 'other' : 'own') + ']'); if (r) r.checked = true; return; }
            var el = row.querySelector('[data-f=' + k + ']'); if (!el || el.type === 'checkbox') return;
            el.value = k === 'sheba' ? dig(v[k]) : (k === 'amount' && v[k] ? money(dig(v[k])) : (v[k] || ''));
        });
        kind(row); bank(row);
    }
    function add(v) {
        var row = tpl.content.firstElementChild.cloneNode(true);
        rows.appendChild(row);
        row.querySelectorAll('[data-f=kind]').forEach(function (r) { r.addEventListener('change', function () { kind(row); }); });
        row.querySelector('[data-del]').onclick = function () { row.remove(); renumber(); };
        row.querySelector('[data-f=sheba]').addEventListener('input', function () { bank(row); });
        row.querySelector('[data-f=card_number]').addEventListener('input', function () { bank(row); });
        var am = row.querySelector('[data-f=amount]');
        am.addEventListener('input', function () { var d = dig(am.value); am.value = d ? money(d) : ''; sum(); });
        var sv = row.querySelector('[data-saved]');
        if (sv) sv.onchange = function () { if (SAVED[sv.value]) fill(row, SAVED[sv.value]); };
        renumber();
        if (v) fill(row, v); else kind(row);
        // نام‌های radio باید برای هر ردیف جدا باشد
        row.querySelectorAll('[data-f=kind]').forEach(function (r) { r.name = 'd[' + (rows.children.length - 1) + '][kind]'; });
        return row;
    }
    if (OLD.length) OLD.forEach(function (v) { add(v); }); else add();
    var ab = document.getElementById('addRow');
    if (ab) ab.onclick = function () { add(); };
    form.addEventListener('submit', function (e) {
        rows.querySelectorAll('[data-f=amount]').forEach(function (el) { el.value = dig(el.value); });
        rows.querySelectorAll('[data-f=sheba],[data-f=card_number],[data-f=mobile]').forEach(function (el) { el.value = dig(el.value); });
        var list = rows.querySelectorAll('.fp-row');
        if (list.length > 1) {
            var t = 0; list.forEach(function (r) { t += +r.querySelector('[data-f=amount]').value || 0; });
            if (t !== total) { e.preventDefault(); sum(); rows.querySelectorAll('[data-f=amount]').forEach(function (el) { el.value = el.value ? money(el.value) : ''; }); alert('جمع مبالغ باید با مبلغ حواله برابر باشد.'); return; }
        }
        document.getElementById('sendBtn').disabled = true;
    });
})();
</script>
@endpush
@endif
