{{-- یک فیش برای کارخانه‌دار: $p (RemitPayment) ، $sel = چک‌باکس انتخاب گروهی --}}
@php
    $late = \App\Services\FactoryPortal::isLate($p);
    $files = $p->files();
    $mins = $p->submitted_at ? (int) $p->submitted_at->diffInMinutes(now()) : 0;
@endphp
<article @class(['fp-pay', 'late' => $late, 'done' => $p->factory_confirmed_at]) data-pay="{{ $p->id }}" data-amt="{{ money($p->amount) }}" data-code="{{ $p->remittance?->code }}" data-ref="{{ $p->refLabel() }}" @if ($p->factory_confirmed_at) data-done="1" @endif>
    <div class="fp-pay-h">
        @if (! empty($sel) && ! $p->factory_confirmed_at)<input type="checkbox" name="ids[]" value="{{ $p->id }}" form="many" class="fp-chk" aria-label="انتخاب">@endif
        <div class="fp-pay-amt">{{ money($p->amount) }} <small>تومان</small></div>
        <span class="fp-tag">{{ $p->remittance?->code }}</span>
    </div>
    <div class="fp-pay-meta">
        <span>{{ $p->refLabel() }}</span>
        <span>ثبت فیش: {{ $p->submitted_at ? jdate($p->submitted_at, true) : '—' }}</span>
        @php $pacc = $p->account(); @endphp
        @if ($pacc['holder'])<span>به حساب: {{ $pacc['holder'] }}{{ $pacc['bank'] ? ' — '.$pacc['bank'] : '' }}@if ($pacc['alt']) <b style="color:#c2410c">(حساب جدید — پس از برگشت واریز قبلی)</b>@endif</span>@endif
        @if (! empty($p->bounce))<span style="color:#c2410c;font-weight:800">🔁 واریز مجدد حواله برگشتی</span>@endif
    </div>
    @if ($files)
        <div class="fp-thumbs">
            @foreach ($files as $i => $path)
                @php $u = route('factory.receipt', [$p, 'i' => $i, 'v' => substr(md5((string) $p->updated_at), 0, 8)]); @endphp
                <a href="{{ $u }}" target="_blank" @unless (str_ends_with(strtolower($path), '.pdf')) data-lb @endunless>@if (str_ends_with(strtolower($path), '.pdf'))<span class="fp-pdf">PDF</span>@else<img src="{{ $u }}" alt="فیش" loading="lazy">@endif</a>
            @endforeach
        </div>
    @endif
    @if ($p->factory_confirmed_at)
        <div class="fp-ok">✓ {{ ! empty($p->factory_ok_by) ? 'نشستن در حساب را حسابداری پخش تأیید کرد' : 'نشستن در حساب را تأیید کردید' }} — {{ jdate($p->factory_confirmed_at, true) }}</div>
        @if ($p->factory_confirmed_at->gt(now()->subDays(3)))
            <form method="post" action="{{ route('factory.undo', $p) }}" style="margin-top:6px" onsubmit="return confirm('تأیید {{ money($p->amount) }} تومان برگردانده شود؟ (یعنی هنوز به حسابتان ننشسته)')">
                @csrf<input type="hidden" name="reason" value="کارخانه‌دار: اشتباه تأیید کردم؛ هنوز به حسابم ننشسته">
                <button style="background:none;border:0;color:#b45309;font-weight:800;text-decoration:underline;cursor:pointer;font:inherit;font-size:13px">↩ اشتباه زدم — هنوز ننشسته</button>
            </form>
        @endif
    @else
        <div @class(['fp-wait', 'late' => $late])>
            @if ($late)
                ⚠️ {{ fa(intdiv($mins, 60)) }} ساعت از ثبت فیش گذشته؛ اگر هنوز ننشسته، با حسابداری تماس بگیرید.
            @else
                ⏳ {{ $mins < 60 ? fa(max(1, $mins)).' دقیقه' : fa(intdiv($mins, 60)).' ساعت' }} پیش ثبت شد. واریز پایا ممکن است چند ساعت (تا چرخه بعدی بانک) طول بکشد.
            @endif
        </div>
        <form method="post" action="{{ route('factory.confirm', $p) }}" data-okform onsubmit="return confirm('{{ money($p->amount) }} تومان به حساب شما نشسته است؟')">
            @csrf<button class="fp-btn fp-btn-ok">✓ این مبلغ به حسابم نشست</button>
        </form>
    @endif
</article>
