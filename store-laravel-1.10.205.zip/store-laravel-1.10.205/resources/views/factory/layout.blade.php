<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="{{ setting('brand_color', '#4f4a63') }}">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="{{ \App\Services\FactoryPortal::cfg()['name'] }}">
<meta name="format-detection" content="telephone=no">
<title>{{ $title ?? \App\Services\FactoryPortal::cfg()['name'] }} | {{ store_name() }}</title>
<link rel="manifest" href="{{ route('factory.manifest') }}">
<link rel="apple-touch-icon" href="{{ route('pwa.factory_icon', 180) }}">
<link rel="icon" href="{{ route('pwa.factory_icon', 64) }}">
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}?v={{ config('store.version') }}">
<link rel="stylesheet" href="{{ asset('css/factory.css') }}?v={{ @filemtime(public_path('css/factory.css')) }}">
<link rel="stylesheet" href="{{ asset('css/receipt-lb.css') }}?v={{ @filemtime(public_path('css/receipt-lb.css')) }}">
@stack('head')
@php $fpInstall = \App\Services\FactoryPortal::cfg()['install_required']; @endphp
<script>
/* نصب اجباری اپ روی گوشی: بیرون از اپ نصب‌شده (مرورگر، بله، تلگرام) صفحه پشت «دروازه نصب» می‌ماند */
(function () {
    var ua = navigator.userAgent || '', d = document.documentElement;
    var standalone = (window.matchMedia && (matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: fullscreen)').matches || matchMedia('(display-mode: minimal-ui)').matches)) || navigator.standalone === true;
    var ios = /iPhone|iPad|iPod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
    var android = /Android/i.test(ua);
    var inapp = /; wv\)|Telegram|Bale|Instagram|FBAN|FBAV|WhatsApp|Eitaa|Rubika|Line\/|MicroMessenger|Snapchat/i.test(ua) || (ios && !/Safari\//.test(ua));
    window.FP_ENV = { standalone: standalone, ios: ios, android: android, inapp: inapp };
    if (standalone) d.classList.add('fp-app');
    var inst = false; try { inst = localStorage.getItem('fpInst') === '1'; } catch (e) {}
    // روی همین گوشی قبلاً نصب شده: ادامه کار در همین صفحه هم آزاد است (لازم نیست صفحه بسته شود)
    if (@json($fpInstall) && (ios || android || /Mobile/i.test(ua)) && !standalone && !inst) d.classList.add('fp-gate-on');
})();
if ('serviceWorker' in navigator) { window.addEventListener('load', function () { navigator.serviceWorker.register('{{ route('factory.sw', [], false) }}', { scope: '/factory' }).catch(function () {}); }); }
</script>
<style>:root{--ac:{{ setting('brand_color', '#4f4a63') }};--font:{!! \App\Support\Fonts::stack() !!}}</style>
</head>
<body class="fp">
<header class="fp-top">
    <div class="fp-top-in">
        @isset($back)<a href="{{ $back }}" class="fp-back" aria-label="بازگشت">→</a>@endisset
        <img src="{{ route('pwa.factory_icon', 180) }}" alt="" class="fp-logo" width="40" height="40">
        <div class="fp-brand"><b>{{ $title ?? \App\Services\FactoryPortal::cfg()['name'] }}</b><small>{{ store_name() }}@isset($factory) — {{ $factory->name }}@endisset</small></div>
        @isset($factory)
            <form method="post" action="{{ route('factory.logout') }}">@csrf<button class="fp-out" title="خروج">خروج</button></form>
        @endisset
    </div>
</header>
<main class="fp-main">
    @if (session('fac_ok'))<div class="fp-alert ok">{{ session('fac_ok') }}</div>@endif
    @if (session('fac_err'))<div class="fp-alert err">{{ session('fac_err') }}</div>@endif
    @if ($errors->any())<div class="fp-alert err">{{ $errors->first() }}</div>@endif
    @yield('body')
    {!! \App\Support\Credit::html('padding:18px 0 8px') !!}
</main>
@if (isset($factory) && \App\Services\FactoryPortal::needsTerms($factory))
{{-- شرایط حسابداری: تا «متوجه شدم» زده نشود، روی صفحه می‌ماند --}}
<div style="position:fixed;inset:0;z-index:60;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:16px">
    <div style="background:#fff;color:#111827;border-radius:18px;max-width:520px;width:100%;max-height:88vh;overflow:auto;padding:18px 18px 14px;box-shadow:0 20px 50px rgba(0,0,0,.3)">
        <h2 style="margin:0 0 8px;font-size:17px;font-weight:900">📌 پیام حسابداری {{ store_name() }}</h2>
        <div style="font-size:14px;line-height:2.1;white-space:pre-line">{{ \App\Services\FactoryPortal::cfg()['terms'] }}</div>
        <form method="post" action="{{ route('factory.terms') }}" style="margin-top:12px">@csrf
            <button style="width:100%;height:48px;border:0;border-radius:12px;background:#15803d;color:#fff;font:inherit;font-size:16px;font-weight:900;cursor:pointer">✓ متوجه شدم</button>
        </form>
    </div>
</div>
@endif
@isset($factory)
@php $fChat = \App\Services\FactoryChat::enabled(); $fUnread = $fChat ? (int) (\App\Models\ChatThread::query()->where('factory_id', $factory->id)->value('unread_customer') ?? 0) : 0; @endphp
<nav class="fp-nav" @if ($fChat) style="grid-template-columns:repeat(5,1fr)" @endif>
    <a href="{{ route('factory.home') }}" @class(['on' => ($nav ?? '') === 'todo'])><span>📋</span>کارها</a>
    <a href="{{ route('factory.home', ['tab' => 'remits']) }}" @class(['on' => ($nav ?? '') === 'remits'])><span>🧾</span>حواله‌ها</a>
    <a href="{{ route('factory.home', ['tab' => 'done']) }}" @class(['on' => ($nav ?? '') === 'done'])><span>✅</span>تأییدشده</a>
    <a href="{{ route('factory.accounts') }}" @class(['on' => ($nav ?? '') === 'accounts'])><span>🏦</span>حساب‌ها</a>
    @if ($fChat)<a href="{{ route('factory.chat') }}" @class(['on' => ($nav ?? '') === 'chat']) style="position:relative"><span>💬</span>گفتگو@if ($fUnread)<em class="fp-nb">{{ fa(min(99, $fUnread)) }}</em>@endif</a>@endif
</nav>
@endisset
@if ($fpInstall)
<section class="fp-gate" id="fpGate" aria-label="نصب اپ" hidden>
    <div class="fp-gate-in">
        <img src="{{ route('pwa.factory_icon', 192) }}" alt="لوگوی {{ \App\Services\FactoryPortal::cfg()['name'] }}" class="fp-gate-logo" width="112" height="112">

        <div data-v="main">
            <h1>{{ \App\Services\FactoryPortal::cfg()['name'] }} را نصب کنید</h1>
            <p>تأیید فیش‌ها و دیدن حواله‌ها فقط از داخل اپ است.</p>
            <button type="button" class="fp-gate-btn" data-a="install">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg>
                <span data-t="blabel">دانلود اپلیکیشن</span>
            </button>
            <p class="fp-gate-note">قبلاً نصب کرده‌اید؟ اپ را از صفحه گوشی باز کنید.</p>
        </div>

        <div data-v="inapp" hidden>
            <h1>برای نصب، صفحه را در <span data-t="browser">کروم</span> باز کنید</h1>
            <div class="fp-gate-warn">این صفحه داخل بله / تلگرام باز شده و از اینجا نصب نمی‌شود. منوی <b>⋮</b> یا <b>…</b> بالای صفحه ← <b>«باز کردن در مرورگر»</b>. یا لینک را کپی کنید و در <span data-t="browser">کروم</span> بچسبانید.</div>
            <div class="fp-gate-link"><input type="text" readonly dir="ltr" data-t="url" aria-label="لینک اپ"><button type="button" data-a="copy">کپی لینک</button></div>
            <a class="fp-gate-btn" data-a="chrome" href="#" hidden>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4h6v6"/><path d="M20 4 10 14"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>
                باز کردن در کروم
            </a>
        </div>

        <div data-v="done" hidden>
            <h1>اپ نصب شد ✓</h1>
            <p>از دفعه بعد اپ <b>{{ \App\Services\FactoryPortal::cfg()['name'] }}</b> را از صفحه گوشی باز کنید.</p>
            <button type="button" class="fp-gate-btn" data-a="cont">ادامه</button>
        </div>
    </div>

    <div class="fp-sheet" data-v="guide" hidden>
        <div class="fp-sheet-in" role="dialog" aria-modal="true" aria-labelledby="fpGuideT">
            <i class="fp-sheet-grip"></i>
            <b id="fpGuideT" data-t="gtitle">نصب روی گوشی</b>
            <ol class="fp-gate-steps" data-t="gsteps"></ol>
            <button type="button" class="fp-gate-btn" data-a="close">متوجه شدم</button>
            <button type="button" class="fp-gate-btn fp-gate-btn2" data-a="cont" data-t="gcont" hidden>نصب کردم، ادامه</button>
            <div class="fp-sheet-hint" data-t="ghint" hidden>دکمه اشتراک‌گذاری این پایین است<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v15"/><path d="m6 13 6 6 6-6"/></svg></div>
        </div>
    </div>
</section>
<script>
(function () {
    var E = window.FP_ENV || {}, d = document.documentElement, g = document.getElementById('fpGate');
    var prompt = null;
    window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); prompt = e; });
    function mark() { try { localStorage.setItem('fpInst', '1'); } catch (e) {} }
    window.addEventListener('appinstalled', function () { prompt = null; mark(); if (g && !g.hidden) show('done'); });
    if (E.standalone) mark();
    if (!g || !d.classList.contains('fp-gate-on')) return;
    g.hidden = false;
    var $ = function (s) { return g.querySelector(s); };
    function show(v) { ['main', 'inapp', 'done'].forEach(function (k) { $('[data-v="' + k + '"]').hidden = k !== v; }); }
    var IC = {
        share: '<svg viewBox="0 0 24 24" class="blue"><path d="M12 3v12"/><path d="m8 7 4-4 4 4"/><path d="M8 11H6a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8a1 1 0 0 0-1-1h-2"/></svg>',
        plus: '<svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="4"/><path d="M12 8v8M8 12h8"/></svg>',
        dots: '<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg>',
        phone: '<svg viewBox="0 0 24 24"><rect x="6" y="2" width="12" height="20" rx="2.5"/><path d="M11 18h2"/></svg>'
    };
    function guide(ios) {
        var st = ios
            ? [['دکمه <b>اشتراک‌گذاری</b> پایین صفحه را بزنید', IC.share], ['پایین‌تر بروید و <b>Add to Home Screen</b> (افزودن به صفحه اصلی) را بزنید', IC.plus], ['بالای صفحه <b>Add</b> (افزودن) را بزنید', '<em>Add</em>']]
            : [['منوی <b>⋮</b> بالای مرورگر را بزنید', IC.dots], ['<b>«نصب برنامه»</b> یا <b>«افزودن به صفحه اصلی»</b> را بزنید', IC.plus], ['اپ را از <b>صفحه گوشی</b> باز کنید', IC.phone]];
        $('[data-t="gtitle"]').textContent = ios ? 'نصب روی آیفون — سه قدم ساده' : 'نصب روی گوشی — سه قدم ساده';
        $('[data-t="gsteps"]').innerHTML = st.map(function (x, i) { return '<li><span>' + '۱۲۳'[i] + '</span><div>' + x[0] + '</div>' + x[1] + '</li>'; }).join('');
        $('[data-t="ghint"]').hidden = !ios;
        $('[data-t="gcont"]').hidden = !ios; // آیفون: نصب را نمی‌شود فهمید؛ پس از انجام قدم‌ها، ادامه در همین صفحه
        $('[data-v="guide"]').hidden = false;
    }
    if (E.inapp) {
        show('inapp');
        g.querySelectorAll('[data-t="browser"]').forEach(function (el) { el.textContent = E.ios ? 'سافاری' : 'کروم'; });
        var url = location.origin + '/factory';
        $('[data-t="url"]').value = url;
        if (E.android) { var a = $('[data-a="chrome"]'); a.href = 'intent://' + location.host + '/factory#Intent;scheme=https;package=com.android.chrome;end'; a.hidden = false; }
    }
    g.addEventListener('click', function (e) {
        var b = e.target.closest('[data-a]'); if (!b) return;
        var a = b.getAttribute('data-a');
        if (a === 'install') {
            if (E.ios) { guide(true); return; }
            var go = function () {
                if (!prompt) return false;
                prompt.prompt();
                prompt.userChoice.then(function (r) { if (r && r.outcome === 'accepted') { mark(); show('done'); } prompt = null; }).catch(function () {});
                return true;
            };
            if (go()) return;
            // اندروید: پنجره نصب گوشی گاهی چند لحظه بعد از باز شدن صفحه آماده می‌شود؛ کمی صبر، بعد راهنما
            var lab = $('[data-t="blabel"]'), t0 = Date.now();
            b.disabled = true; lab.textContent = 'در حال آماده‌سازی…';
            (function wait() {
                if (go() || Date.now() - t0 > 3000) { b.disabled = false; lab.textContent = 'دانلود اپلیکیشن'; if (!prompt && Date.now() - t0 > 3000) guide(false); return; }
                setTimeout(wait, 150);
            })();
        } else if (a === 'cont') {
            mark(); d.classList.remove('fp-gate-on'); g.hidden = true;
        } else if (a === 'close') {
            $('[data-v="guide"]').hidden = true;
        } else if (a === 'copy') {
            var inp = $('[data-t="url"]');
            var ok = function () { b.textContent = 'کپی شد ✓'; setTimeout(function () { b.textContent = 'کپی لینک'; }, 2000); };
            if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(inp.value).then(ok, function () { inp.select(); document.execCommand('copy'); ok(); }); }
            else { inp.select(); document.execCommand('copy'); ok(); }
        }
    });
    $('[data-v="guide"]').addEventListener('click', function (e) { if (e.target === this) this.hidden = true; });
})();
</script>
@endif
@stack('js')
<script src="{{ asset('js/factory-lb.js') }}?v={{ @filemtime(public_path('js/factory-lb.js')) }}" defer></script>
</body>
</html>
