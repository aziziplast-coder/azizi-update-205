@extends('manage.layout', ['title' => 'همه بخش‌ها', 'sub' => 'متناسب با دسترسی شما'])
@section('body')
<div class="m-search">
    <svg viewBox="0 0 24 24"><path d="M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4"/></svg>
    <input type="search" id="modq" placeholder="جستجوی بخش… (مثلاً محصولات، اکسل، پیامک)" autocomplete="off">
</div>
<p class="m-mu m-sm" style="margin:-2px 2px 0">بخش‌های 📱 نسخه مخصوص گوشی دارند؛ بقیه همان صفحه پنل است که در گوشی باز می‌شود و با «بازگشت به اپ» برمی‌گردید.</p>
@if ($groups)
    @include('manage.partials.modules', ['groups' => $groups])
    <div class="m-empty" id="modnone" hidden><i>🔍</i>بخشی پیدا نشد.</div>
@else
    <div class="m-empty"><i>🔒</i>بخشی برای شما فعال نشده است.</div>
@endif
@endsection
@push('foot')
<script>
(function () {
    var q = document.getElementById('modq'); if (!q) return;
    q.addEventListener('input', function () {
        var v = q.value.trim().replace(/ي/g, 'ی').replace(/ك/g, 'ک'), any = false;
        document.querySelectorAll('[data-mod-g]').forEach(function (g) {
            var n = 0;
            g.querySelectorAll('[data-mod]').forEach(function (a) { var ok = !v || a.getAttribute('data-mod').indexOf(v) > -1; a.hidden = !ok; if (ok) n++; });
            g.hidden = !n; if (n) any = true;
        });
        var e = document.getElementById('modnone'); if (e) e.hidden = any;
    });
})();
</script>
@endpush
