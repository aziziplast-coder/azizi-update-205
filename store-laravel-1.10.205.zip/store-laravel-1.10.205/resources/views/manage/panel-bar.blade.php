@php
    $oid = request()->route('record');
    $back = $oid && request()->is('admin/orders/*') ? url('/manage/orders/'.$oid) : url('/manage/all');
    $auto = request('from') === 'app' && request('action');
@endphp
<div id="mapp-bar" class="mapp-bar">
    <a href="{{ $back }}">‹ بازگشت به اپ مدیریت</a>
    <a href="{{ url('/manage/all') }}" class="mn">▦ منو</a>
</div>
<style>
.mapp-bar { display: none; }
@media (max-width: 1023px) {
    .mapp-bar { display: flex; gap: 8px; position: sticky; top: 0; z-index: 30; justify-content: center; padding: 8px 12px; background: #14131a; }
    .mapp-bar a { color: #fff; font-weight: 800; font-size: 14px; text-decoration: none; padding: 6px 16px; border-radius: 999px; background: rgb(255 255 255 / .12); }
    .mapp-bar.go a { background: #16a34a; }
}
</style>
@if ($auto)
<script>
/* از اپ برای یک کار مشخص آمده: پس از ثبت موفق و بسته شدن فرم، خودکار به صفحه سفارش در اپ برمی‌گردد */
(function () {
    var back = @json($back), seen = false, t0 = Date.now();
    var iv = setInterval(function () {
        var open = !!document.querySelector('.fi-modal-open .fi-modal-window, .fi-modal.fi-modal-open');
        if (open) { seen = true; return; }
        if (!seen) { if (Date.now() - t0 > 15000) clearInterval(iv); return; }
        clearInterval(iv);
        setTimeout(function () {
            var bad = document.querySelector('.fi-no-notification.fi-color-danger, .fi-no-notification.fi-color-warning, .fi-no-notification.fi-status-danger, .fi-no-notification.fi-status-warning');
            if (bad) { document.getElementById('mapp-bar').classList.add('go'); return; }
            var n = document.querySelector('.fi-no-notification .fi-no-notification-title, .fi-no-notification h3');
            location.href = back + (n ? '?m_msg=' + encodeURIComponent(n.textContent.trim().slice(0, 200)) : '');
        }, 1300);
    }, 350);
})();
</script>
@endif
