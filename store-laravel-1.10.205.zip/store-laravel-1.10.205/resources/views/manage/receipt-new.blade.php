@extends('manage.layout', ['title' => 'فیش حضوری تازه', 'sub' => 'برای مشتری حضوری (بدون سفارش سایت)', 'back' => route('manage.receipts')])
@section('body')
@if ($remits->isEmpty())
    <div class="m-card"><div class="m-empty" style="padding:24px 8px"><i>🧾</i>حواله جاری با ظرفیت آزاد ندارید.<br><small>از حسابدار کل بخواهید برایتان حواله صادر کند.</small></div></div>
@else
<form method="post" class="m-form" action="{{ route('manage.receipt.new') }}">
    @csrf
    <div class="m-card m-form">
        <label class="m-field"><span>نام مشتری</span>
            <input name="name" value="{{ old('name') }}" required maxlength="120" placeholder="مثلاً: فروشگاه رضایی — آقای رضایی" autocomplete="off">
        </label>
        <label class="m-field"><span>موبایل مشتری <small class="m-mu">(اختیاری)</small></span>
            <input name="mobile" type="tel" inputmode="tel" dir="ltr" value="{{ old('mobile') }}" placeholder="۰۹۱۲…" data-en>
        </label>
        <label class="m-field"><span>مبلغ (تومان)</span>
            <input name="amount" inputmode="numeric" class="m-in big" value="{{ old('amount') }}" required placeholder="۰" data-money autocomplete="off">
            <small data-money-hint></small>
        </label>
    </div>
    <div class="m-sec"><b>واریز به حساب کدام حواله؟</b></div>
    <div class="m-list">
        @foreach ($remits as $i => $r)
            <label class="m-item" style="cursor:pointer">
                <input type="radio" name="remit" value="{{ $r->id }}" @checked(old('remit', request('remit')) ? (int) old('remit', request('remit')) === $r->id : $i === 0) style="width:20px;height:20px;accent-color:var(--ac)">
                <span class="tx">
                    <b>{{ $r->holder_name ?: $r->title }}</b>
                    <small>{{ $r->bank_name ? 'بانک '.$r->bank_name.' · ' : '' }}حواله {{ fa($r->code) }} · {{ $r->title }}</small>
                </span>
                <span class="en"><small class="m-mu">آزاد</small><span class="amt" style="color:var(--ok)">{{ money($r->free) }}</span></span>
            </label>
        @endforeach
    </div>
    <label class="m-field"><span>توضیح <small class="m-mu">(اختیاری)</small></span><textarea name="note" maxlength="300" rows="2" placeholder="مثلاً شماره فاکتور هلو">{{ old('note') }}</textarea></label>
    <button class="m-btn pri lg block">صدور فیش و چاپ</button>
</form>
@endif
@endsection
