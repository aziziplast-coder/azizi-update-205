@extends('manage.layout', ['title' => $p->order_id ? $p->kindLabel().' — سفارش '.fa($p->order?->number) : 'فیش حضوری', 'sub' => $p->partyName(), 'back' => route('manage.receipts', ['tab' => $p->status === 'submitted' ? 'submitted' : 'awaiting'])])
@php
    $step = ['awaiting' => 1, 'rejected' => 1, 'submitted' => 2, 'confirmed' => 3][$p->status] ?? 0;
    $files = $p->files();
    $link = $p->walkin_token ? \App\Services\WalkinReceipt::link($p) : null;
@endphp
@push('head')<script src="{{ asset('js/vendor/qrmini.js') }}?v=1"></script>@endpush
@section('body')
<div class="m-card">
    <div style="display:flex;justify-content:space-between;align-items:center">
        @include('manage.partials.pstatus', ['p' => $p])
        <span class="m-mu m-sm">{{ jdate($p->created_at, true) }}</span>
    </div>
    <div class="m-amt"><b>{{ money($p->amount) }}</b><small>تومان</small></div>
    <div class="m-steps"><i @class(['on' => $step >= 1])></i><i @class(['on' => $step >= 2])></i><i @class(['on' => $step >= 3])></i></div>
    <div style="display:flex;justify-content:space-between;font-size:11.5px;color:var(--mu);margin-top:4px"><span>صادر شد</span><span>فیش رسید</span><span>تأیید</span></div>
    @if ($p->status === 'rejected' && $p->reject_reason)<div class="m-flash err" style="margin-top:10px">علت رد: {{ $p->reject_reason }}</div>@endif
</div>

<div class="m-card">
    <h3>🏦 واریز به</h3>
    <dl class="m-kv" style="margin-bottom:10px">
        <dt>صاحب حساب</dt><dd>{{ $acc['holder'] ?: '—' }}</dd>
        @if ($acc['bank'])<dt>بانک</dt><dd>{{ $acc['bank'] }}</dd>@endif
        <dt>حواله</dt><dd>{{ fa($acc['code']) }}</dd>
    </dl>
    @if ($acc['card'])<div class="m-copy" style="margin-bottom:8px"><b>{{ fa($acc['card']) }}</b><button type="button" data-copy="{{ str_replace(' ', '', $acc['card']) }}">کپی کارت</button></div>@endif
    @if ($acc['sheba'])<div class="m-copy" style="margin-bottom:8px"><b style="font-size:13px">{{ $acc['sheba'] }}</b><button type="button" data-copy="{{ str_replace(' ', '', $acc['sheba']) }}">کپی شبا</button></div>@endif
    @if ($acc['account'])<div class="m-copy"><b>{{ fa($acc['account']) }}</b><button type="button" data-copy="{{ $acc['account'] }}">کپی حساب</button></div>@endif
</div>

<div class="m-card">
    <h3>👤 مشتری</h3>
    <dl class="m-kv">
        <dt>نام</dt><dd>{{ $p->partyName() ?: '—' }}</dd>
        @if ($p->partyMobile())<dt>موبایل</dt><dd><a href="tel:{{ $p->partyMobile() }}" dir="ltr">{{ fa((string) $p->partyMobile()) }}</a></dd>@endif
        <dt>صادرکننده</dt><dd>{{ $p->issuer?->displayName() ?: '—' }}</dd>
        @if ($p->receipt_ref)<dt>شماره پیگیری</dt><dd dir="ltr">{{ fa($p->receipt_ref) }}</dd>@endif
        @if ($p->customer_note)<dt>توضیح</dt><dd>{{ $p->customer_note }}</dd>@endif
        @if ($p->reviewer)<dt>بررسی</dt><dd>{{ $p->reviewer->displayName() }} — {{ jdate($p->reviewed_at, true) }}</dd>@endif
    </dl>
    @if ($p->order_id)<a class="m-btn block" style="margin-top:12px" href="{{ route('manage.order', $p->order_id) }}">مشاهده سفارش {{ fa($p->order?->number) }}</a>@endif
</div>

<div class="m-btns">
    <a class="m-btn pri" href="{{ route('manage.receipt.print', [$p, 'auto' => 1]) }}" target="_blank" @if (request('new')) style="animation:m-pulse 1.4s 3" @endif>🖨 چاپ فیش</a>
    @if ($link)
        <button type="button" class="m-btn" data-sheet-open="share">📲 لینک برای مشتری</button>
    @else
        <a class="m-btn" href="{{ url('/admin/remit-payments') }}">پنل</a>
    @endif
</div>

@if ($files)
<div class="m-card">
    <h3>📎 عکس فیش ({{ fa(count($files)) }})</h3>
    <div class="m-imgs">
        @foreach ($files as $i => $f)
            <span style="position:relative;display:inline-block">
            <a href="{{ route('manage.receipt.img', [$p, $i, 'v' => substr(md5((string) $p->updated_at), 0, 8)]) }}" target="_blank">@if (\App\Models\RemitPayment::isPdfPath($f))PDF@else<img src="{{ route('manage.receipt.img', [$p, $i, 'v' => substr(md5((string) $p->updated_at), 0, 8)]) }}" alt="" loading="lazy">@endif</a>
            @if (($canFix ?? false) && count($files) > 1)
                <form method="post" action="{{ route('manage.receipt.review', $p) }}" style="position:absolute;top:-6px;inset-inline-end:-6px;margin:0">@csrf<input type="hidden" name="do" value="drop"><input type="hidden" name="i" value="{{ $i }}">
                    <button data-confirm="این تصویر (تکراری) از فیش حذف شود؟ بقیه تصویرها می‌ماند." title="حذف تصویر تکراری" style="width:28px;height:28px;border-radius:50%;border:2px solid #fff;background:#dc2626;color:#fff;font-weight:900;box-shadow:0 2px 6px rgb(0 0 0/.25)">✕</button></form>
            @endif
            </span>
        @endforeach
    </div>
    @if (($canFix ?? false) && count($files) > 1)<small style="color:#64748b">اگر یک فیش دو بار آمده، تصویر تکراری را با ✕ حذف کنید و بعد «تأیید» بزنید.</small>@endif
</div>
@endif

@if (($canFix ?? false))
    <details class="m-card">
        <summary style="font-weight:800;cursor:pointer">🔁 جایگزینی فیش (تصویر اشتباه / واریز برگشت خورده)</summary>
        <form method="post" action="{{ route('manage.receipt.review', $p) }}" enctype="multipart/form-data" class="m-form" style="margin-top:10px">
            @csrf<input type="hidden" name="do" value="replace">
            <input type="file" name="files[]" accept="image/*,application/pdf" multiple required>
            <input type="text" name="reason" required maxlength="200" placeholder="علت (مثلاً: واریز قبلی برگشت خورد)">
            <input type="text" name="ref" maxlength="80" inputmode="numeric" placeholder="شماره پیگیری تازه (اختیاری)">
            <label style="display:flex;gap:8px;align-items:center;font-size:13px"><input type="checkbox" name="add" value="1"> تصویرهای قبلی هم بمانند (فقط اضافه شود)</label>
            @if ($p->status === 'confirmed')<small style="color:#b45309">این فیش تأیید شده؛ با جایگزینی، تأیید کارخانه‌دار پاک می‌شود و فیش تازه برایش می‌رود.</small>@endif
            <button class="m-btn block" data-confirm="فیش تازه جایگزین شود؟">ثبت فیش تازه</button>
        </form>
    </details>
@endif

@if ($canReview)
    <div class="m-btns">
        <form method="post" action="{{ route('manage.receipt.review', $p) }}">@csrf<input type="hidden" name="do" value="ok"><button class="m-btn ok block lg" data-confirm="مبلغ {{ money($p->amount) }} تومان در حساب دیده شد؟">✅ تأیید</button></form>
        <button type="button" class="m-btn er lg" data-sheet-open="reject">✕ رد فیش</button>
    </div>
@endif

@if ($p->payable())
<form method="post" action="{{ route('manage.receipt.upload', $p) }}" enctype="multipart/form-data" class="m-card m-form">
    @csrf
    <h3>📷 {{ $files ? 'افزودن عکس فیش' : 'بارگذاری عکس فیش' }}</h3>
    <p class="m-mu m-sm" style="margin:-4px 0 0">اگر مشتری نتوانست خودش بفرستد: از روی گوشی مشتری با دوربین عکس بگیرید یا عکس را از گالری انتخاب کنید.</p>
    <div class="m-btns">
        <label class="m-up" data-up="#pv" style="min-height:92px"><input type="file" name="files[]" accept="image/*" capture="environment"><b>📷 دوربین</b></label>
        <label class="m-up" data-up="#pv" style="min-height:92px"><input type="file" name="files[]" accept="image/*,application/pdf" multiple><b>🖼 گالری / فایل</b></label>
    </div>
    <div class="m-prev" id="pv"></div>
    <label class="m-field"><span>شماره پیگیری <small class="m-mu">(اختیاری)</small></span><input name="ref" dir="ltr" inputmode="numeric" data-en maxlength="80"></label>
    <button class="m-btn pri block" data-up-go hidden>ارسال فیش</button>
</form>
@endif

@if (! $p->order_id && in_array($p->status, ['awaiting', 'rejected'], true))
    <form method="post" action="{{ route('manage.receipt.cancel', $p) }}">@csrf<button class="m-btn ghost block" style="color:var(--er)" data-confirm="این فیش باطل شود؟ ظرفیت حواله آزاد می‌شود.">ابطال فیش</button></form>
@endif

@if ($link)
<div class="m-sheet" data-sheet="share" hidden><div class="m-sheet-box" style="align-items:center;text-align:center">
    <div class="m-grab"></div>
    <b style="font-size:17px">لینک بارگذاری فیش برای مشتری</b>
    <p class="m-mu m-sm" style="margin:0">مشتری با اسکن این کد یا باز کردن لینک، شماره حساب را می‌بیند و عکس فیش را خودش می‌فرستد.</p>
    <div data-qr="{{ $link }}" style="background:#fff;padding:10px;border-radius:16px"></div>
    <div class="m-copy" style="width:100%"><b style="font-size:12px">{{ $link }}</b><button type="button" data-copy="{{ $link }}">کپی</button></div>
    <div class="m-btns" style="width:100%">
        @if ($p->walkin_mobile)<a class="m-btn" href="sms:{{ $p->walkin_mobile }}?body={{ rawurlencode('فیش '.money($p->amount).' تومان — '.store_name().': '.$link) }}">✉️ پیامک</a>@endif
        <button type="button" class="m-btn pri" data-share="{{ $link }}" @if (! $p->walkin_mobile) style="grid-column:span 2" @endif>اشتراک‌گذاری</button>
    </div>
</div></div>
@endif

@if ($canReview)
<div class="m-sheet" data-sheet="reject" hidden><div class="m-sheet-box">
    <div class="m-grab"></div>
    <b style="font-size:17px">علت رد فیش</b>
    <form method="post" action="{{ route('manage.receipt.review', $p) }}" class="m-form">
        @csrf<input type="hidden" name="do" value="no">
        @foreach ($reasons as $r)<label class="m-row-link" style="padding:10px"><input type="radio" name="reason" value="{{ $r }}" style="width:20px;height:20px;accent-color:var(--ac)"> {{ $r }}</label>@endforeach
        <label class="m-row-link" style="padding:10px"><input type="radio" name="reason" value="_other" style="width:20px;height:20px;accent-color:var(--ac)" @checked(! $reasons)> علت دیگر</label>
        <label class="m-field"><input name="other" placeholder="علت را بنویسید" maxlength="300"></label>
        <button class="m-btn er block lg">رد فیش</button>
    </form>
</div></div>
@endif
@endsection
@push('foot')
<script>
document.querySelectorAll('[data-qr]').forEach(function (e) { if (window.QRMini) e.innerHTML = QRMini.svg(e.getAttribute('data-qr'), 190); });
document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-share]'); if (!b) return;
    var u = b.getAttribute('data-share');
    if (navigator.share) navigator.share({ title: 'بارگذاری فیش', text: 'لینک ارسال فیش واریز', url: u }).catch(function () {});
    else { navigator.clipboard && navigator.clipboard.writeText(u); mToast('لینک کپی شد'); }
});
</script>
@endpush
