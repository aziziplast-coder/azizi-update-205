@extends('manage.layout', ['title' => 'حواله‌ها', 'sub' => $chief ? 'همه حواله‌ها' : 'حواله‌های من'])
@section('topActions')
@if ($chief)<a href="{{ route('manage.remit.new') }}" class="m-btn pri sm">＋ حواله</a>@endif
@endsection
@section('body')
<div class="m-tabs">
    @foreach (['active' => 'جاری', 'filled' => 'پر شده', 'closed' => 'بسته'] as $k => $v)
        <a href="{{ route('manage.remits', ['tab' => $k]) }}" @class(['on' => $tab === $k])>{{ $v }}</a>
    @endforeach
</div>
<div class="m-list">
    @forelse ($list as $x)
        @php $st = $x->statsCached(); $a = max(1, $st['amount']); @endphp
        <a class="m-card" href="{{ route('manage.remit', $x) }}" style="display:block;color:inherit;text-decoration:none">
            <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start">
                <div style="min-width:0">
                    <b style="font-size:15.5px;font-weight:900">{{ $x->title }}</b>
                    <div class="m-mu m-sm">حواله {{ fa($x->code) }} · {{ $x->holder_name ?: '—' }}@if ($chief && $x->assignee) · {{ $x->assignee->displayName() }}@endif</div>
                </div>
                <span @class(['m-chip', 'ok' => $x->status === 'active', 'wa' => $x->status === 'pending', 'in' => $x->status === 'filled'])>{{ $x->statusLabel() }}</span>
            </div>
            <div class="m-bar" style="margin:10px 0 6px">
                <i class="ok" style="width:{{ $st['confirmed'] * 100 / $a }}%"></i><i class="sub" style="width:{{ $st['submitted'] * 100 / $a }}%"></i><i class="aw" style="width:{{ $st['awaiting'] * 100 / $a }}%"></i>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:12.5px">
                <span class="m-mu">کل {{ money($st['amount']) }}</span>
                <b style="color:var(--ok)">آزاد {{ money($st['free']) }}</b>
            </div>
        </a>
    @empty
        <div class="m-empty"><i>💳</i>حواله‌ای در این بخش نیست.</div>
    @endforelse
</div>
@include('manage.partials.pager', ['p' => $list])
@endsection
