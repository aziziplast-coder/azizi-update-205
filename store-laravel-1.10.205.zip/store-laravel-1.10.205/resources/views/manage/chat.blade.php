@extends('manage.layout', ['title' => 'گفتگو با مشتری', 'bodyClass' => 'm-chat'])
@push('head')
<link rel="stylesheet" href="{{ asset('css/chat.css') }}?v={{ config('store.version') }}">
<script>if (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches) document.documentElement.classList.add('dark');</script>
@endpush
@php
    $admin = $u->isAdmin();
    $cfg = [
        'csrf' => csrf_token(), 'inbox' => route('admin.chat.inbox'), 'show' => route('admin.chat.show', 0), 'products' => route('admin.chat.products'),
        'typing' => url('chat-t.php'), 'up' => route('admin.chat.up'), 'mb' => asset('js/vendor/mediabunny.min.js'), 'sig' => \App\Services\Chat::staffSignalUrl($u->id), 'orderUrl' => url('/manage/orders/0'),
        'admin' => $admin, 'me' => (int) $u->id, 'open' => (int) request('o') ?: null, 'alert' => max(1, \App\Services\Chat::cfg()['alert_min'] ?: 30),
        'filters' => $admin
            ? [['open', 'همه باز'], ['unread', 'خوانده‌نشده'], ['waiting', 'بی‌جواب'], ['rcpt', '🧾 فیش رسیده'], ['mine', 'مال من'], ['nobody', 'بی‌مسئول'], ['closed', 'بسته'], ['cancelled', '✖ لغو شده']]
            : [['open', 'باز'], ['unread', 'خوانده‌نشده'], ['waiting', 'بی‌جواب'], ['rcpt', '🧾 فیش رسیده'], ['closed', 'بسته'], ['cancelled', '✖ لغو شده']],
    ];
    \App\Services\Chat::staffSignal($u->id);
@endphp
@section('body')
<div class="chs" id="chs" data-chat="{{ json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) }}"></div>
@endsection
@push('foot')
<script src="{{ asset('js/chat.js') }}?v={{ config('store.version') }}"></script>
<script>window.StoreChat && StoreChat.staff(document.getElementById('chs'));</script>
@endpush
