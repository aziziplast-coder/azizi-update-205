@php
    $PR = \App\Filament\Resources\ProductResource::class;
    $L = $PR::QUICK_FIELDS;
    $sw = fn ($k, $on) => '<label class="m-swrow"><span><b>'.e($L[$k]).'</b></span><input type="hidden" name="_b_'.$k.'" value="1"><span class="m-sw"><input type="checkbox" name="'.$k.'" value="1" '.($on ? 'checked' : '').'><i></i></span></label>';
@endphp
<form class="m-form" data-qef action="{{ route('manage.product.qe', $p) }}">
    <div style="display:flex;gap:10px;align-items:center">
        @if ($p->image)<img src="{{ thumb($p->image, 160) }}" alt="" style="width:48px;height:48px;border-radius:12px;object-fit:cover;flex:none">@endif
        <div style="min-width:0"><b style="display:block;font-size:15px;line-height:1.5">⚡ {{ $p->name }}</b><small class="m-mu">ویرایش سریع</small></div>
    </div>
    @foreach ($fields as $k)
        @switch($k)
            @case('in_stock') @case('is_active') @case('retail_enabled')
                {!! $sw($k, $p->{$k}) !!}
                @break
            @case('price') @case('compare_price') @case('retail_price')
                <label class="m-field"><span>{{ $L[$k] }} (تومان)</span><input name="{{ $k }}" value="{{ $p->{$k} }}" inputmode="numeric" data-money @class(['m-in big' => $k === 'price'])><small data-money-hint></small></label>
                @break
            @case('per_carton') @case('stock') @case('retail_stock')
                <label class="m-field"><span>{{ $L[$k] }}</span><input name="{{ $k }}" value="{{ $p->{$k} === null ? '' : fa($p->{$k}) }}" inputmode="numeric" dir="ltr" data-en @if ($k !== 'per_carton') placeholder="خالی = نامحدود" @endif></label>
                @break
            @case('category_id')
                <label class="m-field"><span>{{ $L[$k] }}</span><select name="category_id"><option value="">— بدون دسته —</option>
                    @foreach ($cats->whereNull('parent_id') as $c)<option value="{{ $c->id }}" @selected($p->category_id === $c->id)>{{ $c->name }}</option>@foreach ($cats->where('parent_id', $c->id) as $s)<option value="{{ $s->id }}" @selected($p->category_id === $s->id)>— {{ $s->name }}</option>@endforeach @endforeach
                </select></label>
                @break
            @case('warehouse_id')
                <label class="m-field"><span>{{ $L[$k] }}</span><select name="warehouse_id"><option value="">—</option>@foreach ($whs as $id => $n)<option value="{{ $id }}" @selected((int) $p->warehouse_id === (int) $id)>{{ $n }}</option>@endforeach</select></label>
                @break
            @case('buy_mode')
                <div class="m-two">
                    <label class="m-field"><span>{{ $L[$k] }}</span><select name="buy_mode"><option value="">طبق قانون انبار</option>@foreach (\App\Models\Product::BUY_MODES as $m => $n)<option value="{{ $m }}" @selected($p->buy_mode === $m)>{{ $n }}</option>@endforeach</select></label>
                    <label class="m-field"><span>تعداد N</span><input name="buy_qty" value="{{ $p->buy_qty ? fa($p->buy_qty) : '' }}" inputmode="numeric" dir="ltr" data-en placeholder="بسته/فله"></label>
                </div>
                @break
            @case('short_description')
                <label class="m-field"><span>{{ $L[$k] }}</span><textarea name="short_description" rows="3">{{ $p->short_description }}</textarea></label>
                @break
            @case('unit_label')
                <label class="m-field"><span>{{ $L[$k] }}</span><input name="unit_label" value="{{ $p->unit_label }}" list="qeUnits"><datalist id="qeUnits">@foreach (['عدد', 'جفت', 'دست', 'دست ۶ عددی', 'دست ۱۲ عددی', 'پک', 'ست', 'بسته', 'جین', 'کیلو'] as $x)<option value="{{ $x }}">@endforeach</datalist></label>
                @break
            @default
                <label class="m-field"><span>{{ $L[$k] ?? $k }}</span><input name="{{ $k }}" value="{{ $p->{$k} }}" @if (in_array($k, ['sku', 'barcode'], true)) dir="ltr" data-en @endif></label>
        @endswitch
    @endforeach
    <div class="m-btns">
        <a class="m-btn" href="{{ route('manage.product', $p) }}">صفحه کامل کالا</a>
        <button class="m-btn pri" type="submit">ذخیره</button>
    </div>
</form>
