@php $cl = ['awaiting' => 'wa', 'submitted' => 'in', 'confirmed' => 'ok', 'rejected' => 'er', 'cancelled' => ''][$p->status] ?? ''; @endphp
<span class="m-chip {{ $cl }}">{{ ['awaiting' => 'منتظر واریز', 'submitted' => 'منتظر تأیید', 'confirmed' => 'تأیید شد', 'rejected' => 'رد شد', 'cancelled' => 'باطل'][$p->status] ?? $p->status }}</span>
@if (\App\Support\DbSchema::hasColumn('remit_payments', 'factory_confirmed_at') && $p->remittance?->factory_id && in_array($p->status, ['submitted', 'confirmed'], true) && $p->submitted_at)
<span class="m-chip {{ $p->factory_confirmed_at ? 'ok' : (\App\Services\FactoryPortal::isLate($p) ? 'er' : 'wa') }}" title="تأیید کارخانه‌دار">🏭 {{ $p->factory_confirmed_at ? '✓ کارخانه' : (\App\Services\FactoryPortal::isLate($p) ? 'کارخانه: دیر' : 'منتظر کارخانه') }}</span>
@endif
