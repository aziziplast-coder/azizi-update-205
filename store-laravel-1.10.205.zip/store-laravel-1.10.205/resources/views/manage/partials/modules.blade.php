@foreach ($groups as $g)
    <section class="m-mod" data-mod-g>
        <div class="m-sec"><b>{{ $g['label'] }}</b></div>
        <div class="m-mods">
            @foreach ($g['items'] as $i)
                <a class="m-modi" href="{{ $i['url'] }}" data-mod="{{ $g['label'] }} {{ $i['label'] }}" @if ($i['ext']) target="_blank" @endif>
                    <span class="ic">{!! svg($i['icon'])->toHtml() !!}@if ($i['badge'])<em>{{ $i['badge'] }}</em>@endif</span>
                    <span class="lb">{{ $i['label'] }}</span>
                    @if ($i['app'])<span class="ap">📱</span>@endif
                </a>
            @endforeach
        </div>
    </section>
@endforeach
