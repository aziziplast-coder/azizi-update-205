@if ($p->hasPages())
<div class="m-pager">
    @if ($p->previousPageUrl())<a class="m-btn sm" href="{{ $p->previousPageUrl() }}">قبلی</a>@endif
    <span class="m-chip" style="align-self:center">صفحه {{ fa($p->currentPage()) }} از {{ fa($p->lastPage()) }}</span>
    @if ($p->nextPageUrl())<a class="m-btn sm" href="{{ $p->nextPageUrl() }}">بعدی</a>@endif
</div>
@endif
