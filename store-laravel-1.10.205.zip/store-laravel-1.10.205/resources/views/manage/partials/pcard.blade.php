@php $code = $p->sku ?: ($p->sync_code ?: $p->barcode); @endphp
<div class="m-pc" data-pid="{{ $p->id }}">
    <a class="m-pc-top" href="{{ route('manage.product', $p) }}">
        <span class="im">@if ($p->image)<img src="{{ thumb($p->image, 320) }}" alt="" loading="lazy">@else<i>📷</i>@endif</span>
        <span class="tx">
            <b>{{ $p->name }}</b>
            <small>@if ($code)کد {{ fa($code) }} · @endif{{ $p->category?->name ?: 'بدون دسته' }}</small>
            <span class="chips">
                @if ($p->review === 'pending')<span class="m-chip wa">منتظر تأیید</span>@endif
                @if ($p->per_carton > 1)<span class="m-chip">کارتن {{ fa($p->per_carton) }}تایی</span>@endif
                @if ($p->stock !== null)@if (\App\Models\Product::unlimited())<span class="m-chip er" data-stock>کارتنی ناموجود</span>@else<span class="m-chip {{ $p->stock > 0 ? 'in' : 'er' }}" data-stock>موجودی {{ fa($p->stock) }}</span>@endif @endif
                @if ($p->retail_enabled)<span class="m-chip ok">تکی</span>@endif
            </span>
        </span>
    </a>
    <div class="m-pc-bot">
        <button type="button" class="m-pc-price" data-qe="{{ $p->id }}">
            <b data-price-l>{{ money($p->price) }}</b><small>تومان</small><span class="qe">⚡ ویرایش سریع</span>
        </button>
        <label class="m-sw"><input type="checkbox" data-q="in_stock" @checked($p->in_stock)><i></i><span>موجود</span></label>
        <label class="m-sw"><input type="checkbox" data-q="is_active" @checked($p->is_active)><i></i><span>نمایش</span></label>
    </div>
</div>
