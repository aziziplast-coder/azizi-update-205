@extends('manage.layout', ['title' => 'فیش‌ها', 'sub' => 'حضوری و آنلاین'])
@php
    $tabs = ['submitted' => ['منتظر تأیید', $counts['submitted']], 'awaiting' => ['منتظر واریز', $counts['awaiting']], 'confirmed' => ['تأییدشده', 0], 'all' => ['همه', 0]];
@endphp
@section('topActions')
@if (\App\Http\Controllers\ManageController::can($u, 'walkin'))<a href="{{ route('manage.receipt.new') }}" class="m-btn pri sm">＋ فیش حضوری</a>@endif
@endsection
@section('body')
<form class="m-search" method="get">
    <svg viewBox="0 0 24 24"><path d="M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4"/></svg>
    <input type="search" name="q" value="{{ $q }}" placeholder="نام، موبایل، سفارش یا شماره حواله" enterkeyhint="search">
    <input type="hidden" name="tab" value="{{ $tab }}"><input type="hidden" name="kind" value="{{ $kind }}">
</form>
<div class="m-tabs">
    @foreach ($tabs as $k => [$v, $n])
        <a href="{{ route('manage.receipts', ['tab' => $k, 'kind' => $kind, 'q' => $q ?: null]) }}" @class(['on' => $tab === $k])>{{ $v }}@if ($n)<i>{{ fa($n) }}</i>@endif</a>
    @endforeach
</div>
@if (\App\Http\Controllers\ManageController::can($u, 'walkin'))
<div class="m-seg">
    @foreach (['all' => 'همه', 'walkin' => '🏪 حضوری', 'online' => '🌐 آنلاین'] as $k => $v)
        <a href="{{ route('manage.receipts', ['tab' => $tab, 'kind' => $k, 'q' => $q ?: null]) }}" @class(['on' => $kind === $k])>{{ $v }}</a>
    @endforeach
</div>
@endif
<div class="m-list">
    @forelse ($list as $p)
        <a class="m-item" href="{{ route('manage.receipt', $p) }}">
            <span class="ic">{{ $p->order_id ? '🌐' : '🏪' }}</span>
            <span class="tx">
                <b>{{ $p->partyName() ?: '—' }}</b>
                <small>{{ $p->refLabel() }}{{ $p->order_id ? ' · '.$p->kindLabel() : '' }} · حواله {{ fa($p->remittance?->code) }} · {{ ($p->submitted_at ?? $p->created_at)?->diffForHumans() }}</small>
            </span>
            <span class="en"><span class="amt">{{ money($p->amount) }}</span>@include('manage.partials.pstatus', ['p' => $p])</span>
        </a>
    @empty
        <div class="m-empty"><i>{{ $tab === 'submitted' ? '🎉' : '🧾' }}</i>{{ $tab === 'submitted' ? 'فیشی منتظر تأیید نیست.' : 'فیشی در این بخش نیست.' }}</div>
    @endforelse
</div>
@include('manage.partials.pager', ['p' => $list])
@endsection
