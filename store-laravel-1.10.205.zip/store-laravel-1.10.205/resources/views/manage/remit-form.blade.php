@extends('manage.layout', ['title' => $x ? 'ویرایش حواله '.fa($x->code) : 'حواله تازه', 'back' => $x ? route('manage.remit', $x) : route('manage.remits')])
@php $v = fn ($k, $d = '') => old($k, $x?->$k ?? $d); @endphp
@section('body')
<form method="post" action="{{ $x ? route('manage.remit.edit', $x) : route('manage.remit.new') }}" class="m-form" id="rf">
    @csrf
    <div class="m-card m-form">
        <h3>📄 مشخصات</h3>
        <label class="m-field"><span>شماره حواله</span><input name="code" value="{{ $v('code') }}" required dir="ltr" inputmode="numeric" data-en></label>
        <label class="m-field"><span>عنوان</span><input name="title" value="{{ $v('title') }}" required placeholder="مثلاً حواله کارخانه …"></label>
        <label class="m-field"><span>مبلغ حواله (تومان)</span><input class="m-in big" name="amount" value="{{ $v('amount') }}" required inputmode="numeric" data-money><small data-money-hint></small></label>
        <label class="m-field"><span>مسئول (کمک‌حسابدار)</span>
            <select name="assignee_id" required>
                @foreach ($assistants as $a)<option value="{{ $a->id }}" @selected((int) $v('assignee_id', $u->id) === $a->id)>{{ $a->displayName() }}</option>@endforeach
            </select>
        </label>
        <label class="m-field"><span>کارخانه <small class="m-mu">(اختیاری)</small></span>
            <select name="factory_id" id="fac">
                <option value="">—</option>
                @foreach ($factories as $f)<option value="{{ $f->id }}" @selected((int) $v('factory_id') === $f->id)>{{ $f->name }}</option>@endforeach
            </select>
        </label>
        @unless ($x)
            <label class="m-switch" id="decWrap" hidden><span>شماره حساب را کارخانه‌دار تعیین کند</span><input type="checkbox" name="factory_decides" value="1" id="dec" @checked(old('factory_decides'))></label>
        @endunless
    </div>
    <div class="m-card m-form" id="acc">
        <h3>🏦 حساب واریز</h3>
        <label class="m-field"><span>نام صاحب حساب</span><input name="holder_name" value="{{ $v('holder_name') }}"></label>
        <label class="m-field"><span>شماره کارت</span><input name="card_number" value="{{ $v('card_number') }}" dir="ltr" inputmode="numeric" data-en maxlength="30"></label>
        <label class="m-field"><span>شماره شبا</span><input name="sheba" value="{{ $v('sheba') }}" dir="ltr" placeholder="IR…" data-en maxlength="40"></label>
        <label class="m-field"><span>شماره حساب</span><input name="account_number" value="{{ $v('account_number') }}" dir="ltr" inputmode="numeric" data-en></label>
        <label class="m-field"><span>بانک <small class="m-mu">(خالی بماند خودکار)</small></span><input name="bank_name" value="{{ $v('bank_name') }}"></label>
    </div>
    <div class="m-card m-form">
        <h3>⚙️ سایر</h3>
        <label class="m-field"><span>موبایل کارخانه‌دار</span><input name="factory_phone" value="{{ $v('factory_phone') }}" dir="ltr" inputmode="tel" data-en></label>
        <label class="m-field"><span>ترتیب نمایش</span><input name="sort" value="{{ $v('sort', 0) }}" inputmode="numeric" data-en></label>
        <label class="m-field"><span>توضیح</span><textarea name="note">{{ $v('note') }}</textarea></label>
    </div>
    <button class="m-btn pri block lg">{{ $x ? 'ذخیره تغییرات' : 'ایجاد حواله' }}</button>
</form>
@endsection
@push('foot')
<script>
(function () {
    var fac = document.getElementById('fac'), w = document.getElementById('decWrap'), d = document.getElementById('dec'), acc = document.getElementById('acc');
    function upd() { if (!w) return; w.hidden = !fac.value; if (!fac.value) d.checked = false; acc.hidden = d.checked; }
    if (w) { fac.addEventListener('change', upd); d.addEventListener('change', upd); upd(); }
})();
</script>
@endpush
