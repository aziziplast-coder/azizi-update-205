@extends('manage.layout', ['title' => 'محصولات', 'sub' => fa($list->total()).' کالا'])
@section('topActions')
<button type="button" class="m-icon" data-sheet-open="qecfg" aria-label="فیلدهای ویرایش سریع" title="فیلدهای ویرایش سریع">⚙️</button>
<a href="{{ url('/admin/products/create') }}?from=app" class="m-btn pri sm">＋ کالا</a>
@endsection
@section('body')
<form class="m-search" method="get" id="pf">
    <svg viewBox="0 0 24 24"><path d="M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4"/></svg>
    <input type="search" name="q" value="{{ $q }}" placeholder="نام، کد کالا یا بارکد" enterkeyhint="search" id="pq">
    <button type="button" class="m-scan" id="scan" hidden aria-label="اسکن بارکد"><svg viewBox="0 0 24 24"><path d="M4 7V4h3M17 4h3v3M20 17v3h-3M7 20H4v-3M7 8v8M10 8v8M13 8v8M16 8v8"/></svg></button>
    <input type="hidden" name="tab" value="{{ $tab }}">
</form>
<div class="m-tabs">
    @foreach (\App\Http\Controllers\ManageProductsController::TABS as $k => $v)
        <a href="{{ route('manage.products', array_filter(['tab' => $k, 'q' => $q ?: null, 'cat' => $cat ?: null, 'sort' => $sort !== 'new' ? $sort : null])) }}" @class(['on' => $tab === $k])>{{ $v }}@if ($k !== 'all' && ($counts[$k] ?? 0))<i @if (! in_array($k, ['pending', 'out'], true)) style="background:#94a3b8" @endif>{{ fa($counts[$k]) }}</i>@endif</a>
    @endforeach
</div>
<div class="m-filt">
    <select form="pf" name="cat" onchange="this.form.submit()">
        <option value="">همه دسته‌ها</option>
        @foreach ($cats->whereNull('parent_id') as $c)
            <option value="{{ $c->id }}" @selected($cat === $c->id)>{{ $c->name }}</option>
            @foreach ($cats->where('parent_id', $c->id) as $s)<option value="{{ $s->id }}" @selected($cat === $s->id)>— {{ $s->name }}</option>@endforeach
        @endforeach
    </select>
    <select form="pf" name="sort" onchange="this.form.submit()">
        @foreach (\App\Http\Controllers\ManageProductsController::SORTS as $k => $v)<option value="{{ $k }}" @selected($sort === $k)>{{ $v }}</option>@endforeach
    </select>
</div>

<div class="m-list">
    @forelse ($list as $p)
        @include('manage.partials.pcard', ['p' => $p])
    @empty
        <div class="m-empty"><i>📦</i>کالایی پیدا نشد.</div>
    @endforelse
</div>
@include('manage.partials.pager', ['p' => $list])

<div class="m-sheet" data-sheet="qe" hidden><div class="m-sheet-box" style="max-height:88vh;overflow:auto">
    <div class="m-grab"></div>
    <div id="qeBox"><div class="m-empty" style="padding:24px">در حال بارگذاری…</div></div>
</div></div>

<div class="m-sheet" data-sheet="qecfg" hidden><div class="m-sheet-box" style="max-height:88vh;overflow:auto">
    <div class="m-grab"></div>
    <b style="font-size:16px">⚙️ فیلدهای «ویرایش سریع»</b>
    <p class="m-mu m-sm" style="margin:0">همین انتخاب در پنل کامپیوتر هم اعمال می‌شود.</p>
    <form method="post" action="{{ route('manage.product.qefields') }}" class="m-form">
        @csrf
        <div class="m-chk">
            @foreach (\App\Filament\Resources\ProductResource::QUICK_FIELDS as $k => $v)
                <label><input type="checkbox" name="fields[]" value="{{ $k }}" @checked(in_array($k, \App\Filament\Resources\ProductResource::quickFields(), true))><span>{{ $v }}</span></label>
            @endforeach
        </div>
        <button class="m-btn pri block lg">ذخیره</button>
    </form>
</div></div>
@endsection
@push('foot')
<script>
(function () {
    var tok = document.querySelector('meta[name=csrf-token]').content, base = @json(url('/manage/products'));
    function post(id, data) {
        var fd = new FormData(); Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
        return fetch(base + '/' + id + '/quick', { method: 'POST', body: fd, headers: { 'X-CSRF-TOKEN': tok, 'Accept': 'application/json' } })
            .then(function (r) { if (!r.ok) throw r; return r.json(); });
    }
    document.addEventListener('change', function (e) {
        var c = e.target.closest('[data-q]'); if (!c) return;
        var card = c.closest('[data-pid]');
        post(card.getAttribute('data-pid'), { f: c.getAttribute('data-q'), v: c.checked ? 1 : 0 })
            .then(function (j) { mToast(c.getAttribute('data-q') === 'in_stock' ? (j.in_stock ? 'موجود شد' : 'ناموجود شد') : (j.is_active ? 'در سایت نمایش داده می‌شود' : 'از سایت مخفی شد')); })
            .catch(function () { c.checked = !c.checked; mToast('ذخیره نشد؛ دوباره امتحان کنید'); });
    });
    var box = document.getElementById('qeBox'), cur = null;
    document.addEventListener('click', function (e) {
        var b = e.target.closest('[data-qe]'); if (!b) return;
        cur = b.closest('[data-pid]');
        box.innerHTML = '<div class="m-empty" style="padding:24px">در حال بارگذاری…</div>';
        mSheet('qe', true);
        fetch(base + '/' + b.getAttribute('data-qe') + '/qe', { headers: { 'Accept': 'text/html' } }).then(function (r) { return r.text(); }).then(function (h) {
            box.innerHTML = h; mBind(box);
            var f = box.querySelector('[name=price]'); if (f) setTimeout(function () { f.focus(); f.select(); }, 60);
        }).catch(function () { box.innerHTML = '<div class="m-empty">بارگذاری نشد</div>'; });
    });
    box.addEventListener('submit', function (e) {
        var f = e.target; if (!f.matches('[data-qef]')) return;
        e.preventDefault();
        f.querySelectorAll('[data-money]').forEach(function (i) { i.value = mEn(i.value).replace(/\D/g, ''); });
        f.querySelectorAll('[data-en]').forEach(function (i) { i.value = mEn(i.value); });
        var btn = f.querySelector('button'); btn.classList.add('busy');
        fetch(f.action, { method: 'POST', body: new FormData(f), headers: { 'X-CSRF-TOKEN': tok, 'Accept': 'application/json' } })
            .then(function (r) { return r.json().then(function (j) { return [r.ok, j]; }); })
            .then(function (x) {
                btn.classList.remove('busy');
                if (!x[0] || !x[1].ok) { mToast(x[1].msg || 'ذخیره نشد'); return; }
                if (cur && x[1].html) { var t = document.createElement('div'); t.innerHTML = x[1].html.trim(); cur.replaceWith(t.firstChild); }
                mSheet('qe', false); mToast(x[1].msg);
            }).catch(function () { btn.classList.remove('busy'); mToast('ذخیره نشد؛ اینترنت را بررسی کنید'); });
    });
    /* اسکن بارکد با دوربین (اندروید/کروم) */
    if ('BarcodeDetector' in window && navigator.mediaDevices) {
        var sb = document.getElementById('scan'); sb.hidden = false;
        sb.addEventListener('click', function () { window.mScan && mScan(function (code) { document.getElementById('pq').value = code; document.getElementById('pf').submit(); }); });
    }
})();
</script>
@endpush
