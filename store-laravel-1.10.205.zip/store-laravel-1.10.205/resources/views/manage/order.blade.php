@extends('manage.layout', ['title' => 'سفارش '.fa($o->number), 'sub' => $o->customer_name, 'back' => route('manage.orders')])
@php $hx = \App\Models\Order::HEX[$o->status] ?? ['#f1f5f9', '#334155']; $paid = $pays->where('status', 'confirmed')->sum('amount'); @endphp
@section('body')
<div class="m-card">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px">
        <span class="m-chip" style="background:{{ $hx[0] }};color:{{ $hx[1] }};font-size:13px;padding:4px 12px">{{ $o->statusLabel() }}</span>
        <span class="m-mu m-sm">{{ jdate($o->created_at, true) }}</span>
    </div>
    <div class="m-amt"><b>{{ money($o->final_amount ?: $o->total) }}</b><small>تومان {{ $o->final_amount ? '(مبلغ نهایی)' : '' }}</small></div>
    @if ($o->placed_total !== null && (int) $o->placed_total !== (int) $o->total)
        <div style="font-size:12.5px;opacity:.8;margin-top:4px">مبلغ اولیه سفارش مشتری (پیش از تغییرات انبار): <b>{{ money((int) $o->placed_total) }}</b> تومان — فقط برای اطلاع</div>
    @endif
    <dl class="m-kv">
        <dt>مشتری</dt><dd>{{ $o->customer_name }}{{ $o->company ? ' — '.$o->company : '' }}</dd>
        <dt>موبایل</dt><dd><a href="tel:{{ $o->mobile }}" dir="ltr">{{ fa((string) $o->mobile) }}</a></dd>
        <dt>شهر</dt><dd>{{ $o->city ?: '—' }}</dd>
        <dt>مسئول</dt><dd>{{ $o->assignee?->displayName() ?: '—' }}</dd>
        <dt>پرداخت‌شده</dt><dd style="color:var(--ok)">{{ money($paid) }} تومان</dd>
        @if ($o->freight_name)<dt>باربری</dt><dd>{{ $o->freight_name }}{{ $o->freight_dest ? ' — '.$o->freight_dest : '' }}</dd>@endif
    </dl>
    <div class="m-btns" style="margin-top:12px">
        <a class="m-btn" href="tel:{{ $o->mobile }}">📞 تماس</a>
        @if ($canChat)<a class="m-btn pri" href="{{ route('manage.chat', ['o' => $o->id]) }}">💬 گفتگو</a>@else<a class="m-btn" href="{{ url('/admin/orders/'.$o->id) }}?from=app">پنل</a>@endif
    </div>
</div>

@if ($acts)
<div class="m-card m-acts">
    <h3>⚡ کارهای این سفارش</h3>
    @foreach ($acts as $g => $rows)
        @if ($g !== '')<div class="m-acts-g">{{ $g }}</div>@endif
        <div class="m-acts-l">
            @foreach ($rows as $a)
                @if ($a['off'])
                    <span class="m-act off">{{ $a['label'] }}</span>
                @else
                    <a class="m-act {{ $a['color'] }}" href="{{ $a['url'] }}" @if ($a['tab']) target="_blank" @endif>{{ $a['label'] }}</a>
                @endif
            @endforeach
        </div>
    @endforeach
</div>
@endif

@if ($pays->isNotEmpty())
<div class="m-sec"><b>واریزها</b></div>
<div class="m-list">
    @foreach ($pays as $p)
        <a class="m-item" href="{{ \App\Http\Controllers\ManageController::can($u, 'receipts') ? route('manage.receipt', $p) : '#' }}">
            <span class="ic">{{ $p->kind === 'deposit' ? '💳' : '🧾' }}</span>
            <span class="tx"><b>{{ $p->kindLabel() }} — {{ money($p->amount) }}</b><small>حواله {{ fa($p->remittance?->code) }} · {{ $p->remittance?->holder_name }}</small></span>
            <span class="en">@include('manage.partials.pstatus', ['p' => $p])</span>
        </a>
    @endforeach
</div>
@endif

<details class="m-card">
    <summary>اقلام ({{ fa($o->items->where('units', '>', 0)->count()) }} قلم)</summary>
    <div class="m-items" style="margin-top:8px">
        @foreach ($o->items as $it)
            <div class="it" @if ((int) $it->units === 0) style="opacity:.45" @endif>
                <img src="{{ $it->image ? thumb($it->image, 160) : url('/pwa-icon-64.png') }}" alt="" loading="lazy">
                <div><b>{{ $it->name }}</b><small>{{ $it->qtyLabel() ?? fa($it->units).' عدد' }} · {{ money($it->total ?? ($it->unit_price * $it->units)) }}</small></div>
            </div>
        @endforeach
    </div>
</details>

@if ($events->isNotEmpty())
<details class="m-card">
    <summary>تاریخچه</summary>
    <div class="m-tl" style="margin-top:8px">
        @foreach ($events as $e)<div><small>{{ jdate($e->created_at, true) }}</small><span>{{ $e->message }}</span></div>@endforeach
    </div>
</details>
@endif
@endsection
