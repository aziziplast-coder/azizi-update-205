@extends('manage.layout', ['title' => 'حواله '.fa($x->code), 'sub' => $x->title, 'back' => route('manage.remits')])
@php $a = max(1, $st['amount']); @endphp
@section('topActions')
@if ($chief && ! in_array($x->status, ['closed', 'transferred'], true))<a href="{{ route('manage.remit.edit', $x) }}" class="m-btn sm">ویرایش</a>@endif
@endsection
@section('body')
<div class="m-card">
    <div style="display:flex;justify-content:space-between;align-items:center">
        <span @class(['m-chip', 'ok' => $x->status === 'active', 'wa' => $x->status === 'pending', 'in' => $x->status === 'filled'])>{{ $x->statusLabel() }}</span>
        <span class="m-mu m-sm">{{ jdate($x->created_at) }}</span>
    </div>
    <div class="m-amt"><b>{{ money($st['amount']) }}</b><small>تومان مبلغ حواله</small></div>
    <div class="m-bar"><i class="ok" style="width:{{ $st['confirmed'] * 100 / $a }}%"></i><i class="sub" style="width:{{ $st['submitted'] * 100 / $a }}%"></i><i class="aw" style="width:{{ $st['awaiting'] * 100 / $a }}%"></i></div>
    <div class="m-legend">
        <span><b style="background:#16a34a"></b>تأیید {{ money($st['confirmed']) }}</span>
        <span><b style="background:#3b82f6"></b>فیش رسیده {{ money($st['submitted']) }}</span>
        <span><b style="background:#f59e0b"></b>منتظر واریز {{ money($st['awaiting']) }}</span>
        <span><b style="background:rgb(127 127 127 / .3)"></b>آزاد {{ money($st['free']) }}</span>
    </div>
    @if ($x->factory_id)
        @php
            $fq = \App\Models\RemitPayment::query()->where('remittance_id', $x->id)->whereIn('status', ['submitted', 'confirmed'])->whereNotNull('submitted_at');
            $fOk = (int) (clone $fq)->whereNotNull('factory_confirmed_at')->sum('amount'); $fWait = (int) (clone $fq)->whereNull('factory_confirmed_at')->sum('amount');
        @endphp
        <div class="m-flash {{ $fWait ? 'err' : 'ok' }}" style="margin-top:10px;{{ $fWait ? 'background:#fef3c7;color:#92400e' : '' }}">🏭 تأیید کارخانه‌دار (ملاک اصلی): <b>{{ money($fOk) }}</b> تومان@if ($fWait) — منتظر تأیید کارخانه: <b>{{ money($fWait) }}</b> تومان@endif</div>
    @endif
</div>

<div class="m-card">
    <h3>🏦 حساب مقصد</h3>
    @if ($x->status === 'pending')
        <p class="m-mu" style="margin:0">منتظر تعیین حساب توسط کارخانه‌دار.</p>
    @else
        <dl class="m-kv" style="margin-bottom:10px">
            <dt>صاحب حساب</dt><dd>{{ $x->holder_name ?: '—' }}</dd>
            @if ($x->bank_name)<dt>بانک</dt><dd>{{ $x->bank_name }}</dd>@endif
        </dl>
        @if ($x->card_number)<div class="m-copy" style="margin-bottom:8px"><b>{{ fa(\App\Support\Banks::formatCard($x->card_number)) }}</b><button type="button" data-copy="{{ $x->card_number }}">کپی کارت</button></div>@endif
        @if ($x->sheba)<div class="m-copy" style="margin-bottom:8px"><b style="font-size:13px">{{ \App\Support\Banks::formatSheba($x->sheba) }}</b><button type="button" data-copy="{{ $x->sheba }}">کپی شبا</button></div>@endif
        @if ($x->account_number)<div class="m-copy"><b>{{ fa($x->account_number) }}</b><button type="button" data-copy="{{ $x->account_number }}">کپی حساب</button></div>@endif
    @endif
    <dl class="m-kv" style="margin-top:12px">
        <dt>مسئول</dt><dd>{{ $x->assignee?->displayName() ?: '—' }}</dd>
        @if ($x->factory)<dt>کارخانه</dt><dd>{{ $x->factory->name }}</dd>@endif
        @if ($x->note)<dt>توضیح</dt><dd>{{ $x->note }}</dd>@endif
    </dl>
</div>

@if ($x->status === 'active' && $st['free'] > 0 && \App\Http\Controllers\ManageController::can($u, 'walkin'))
    <a class="m-btn pri block lg" href="{{ route('manage.receipt.new', ['remit' => $x->id]) }}">＋ فیش حضوری از این حواله</a>
@endif

<div class="m-card">
    <h3>🧾 فیش‌ها ({{ fa($pays->count()) }})</h3>
    <div class="m-list" style="gap:6px">
        @forelse ($pays as $p)
            <a class="m-row-link" href="{{ route('manage.receipt', $p) }}" style="justify-content:space-between">
                <span style="min-width:0"><b style="display:block">{{ $p->partyName() ?: '—' }}</b><small class="m-mu">{{ $p->refLabel() }} · {{ jdate($p->created_at) }}</small></span>
                <span style="text-align:left"><b style="display:block">{{ money($p->amount) }}</b>@include('manage.partials.pstatus', ['p' => $p])</span>
            </a>
        @empty
            <div class="m-mu" style="text-align:center;padding:14px">هنوز فیشی صادر نشده.</div>
        @endforelse
    </div>
</div>

@if ($chief && in_array($x->status, ['active', 'filled', 'pending'], true))
    <form method="post" action="{{ route('manage.remit.close', $x) }}">@csrf<button class="m-btn ghost block" style="color:var(--er)" data-confirm="حواله بسته شود؟ فیش‌های منتظر واریز باطل می‌شوند.">بستن حواله</button></form>
@endif
@endsection
