<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>فیش {{ fa($p->id) }} | {{ store_name() }}</title>
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}?v={{ config('store.version') }}">
<script src="{{ asset('js/vendor/qrmini.js') }}?v=1"></script>
<style>
:root { --w: 80mm; --font:{!! \App\Support\Fonts::stack() !!}; }
html[data-w="58"] { --w: 58mm; }
* { box-sizing: border-box; }
body { margin: 0; background: #e9e9ee; font-family: var(--font); color: #000; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
.bar { position: sticky; top: 0; display: flex; gap: 8px; align-items: center; justify-content: center; flex-wrap: wrap; padding: 10px; background: #fff; box-shadow: 0 2px 10px rgb(0 0 0 / .08); font-size: 14px; }
.bar button, .bar a { font: inherit; font-weight: 800; border: 1px solid #d4d4dc; background: #fff; border-radius: 12px; padding: 9px 14px; color: #222; text-decoration: none; cursor: pointer; }
.bar button.on { background: #222; color: #fff; border-color: #222; }
.bar .go { background: #16a34a; border-color: #16a34a; color: #fff; }
.paper { width: var(--w); margin: 14px auto; background: #fff; padding: 3mm 3mm 6mm; box-shadow: 0 4px 20px rgb(0 0 0 / .12); font-size: 12px; line-height: 1.6; }
html[data-w="58"] .paper { font-size: 10.5px; }
.c { text-align: center; }
.store { font-size: 1.45em; font-weight: 900; }
.ttl { display: inline-block; margin: 2px 0 4px; padding: 1px 12px; border: 1.5px solid #000; border-radius: 30px; font-weight: 900; }
.hr { border-top: 1.5px dashed #000; margin: 6px 0; }
.amt { text-align: center; font-size: 1.9em; font-weight: 900; letter-spacing: -.3px; line-height: 1.25; }
.words { text-align: center; font-weight: 700; font-size: .95em; }
table { width: 100%; border-collapse: collapse; }
td { padding: 1.5px 0; vertical-align: top; }
td:first-child { white-space: nowrap; padding-left: 6px; font-weight: 700; width: 1%; }
td:last-child { font-weight: 900; text-align: left; word-break: break-all; }
.num { direction: ltr; unicode-bidi: plaintext; font-family: inherit; letter-spacing: .3px; }
.big { font-size: 1.15em; }
.box { border: 1.5px solid #000; border-radius: 6px; padding: 4px 5px; margin: 4px 0; }
.box .k { font-weight: 700; font-size: .9em; }
.box .v { font-weight: 900; direction: ltr; text-align: center; font-size: 1.12em; word-break: break-all; }
html[data-w="58"] .box .v { font-size: 1em; }
.qr { display: flex; justify-content: center; margin: 4px 0 0; }
.qr svg { width: 34mm; height: 34mm; }
html[data-w="58"] .qr svg { width: 30mm; height: 30mm; }
.note { font-size: .9em; text-align: center; font-weight: 700; }
.mu { font-size: .85em; }
@media print {
    @page { size: var(--w) auto; margin: 0; }
    body { background: #fff; }
    .bar { display: none; }
    .paper { margin: 0; box-shadow: none; width: 100%; }
}
</style>
<script>try { var w = localStorage.getItem('m_print_w'); if (w === '58' || w === '80') document.documentElement.setAttribute('data-w', w); } catch (e) {}</script>
<style id="pg"></style>
</head>
<body>
<div class="bar">
    <span>عرض کاغذ:</span>
    <button type="button" data-w="80">۸۰ میلی‌متر</button>
    <button type="button" data-w="58">۵۸ میلی‌متر</button>
    <button type="button" class="go" onclick="window.print()">🖨 چاپ</button>
    <a href="{{ route('manage.receipt', $p) }}">بازگشت</a>
</div>
<div class="paper">
    <div class="c"><div class="store">{{ store_name() }}</div><div class="ttl">فیش واریز</div></div>
    <table>
        <tr><td>تاریخ</td><td>{{ jdate($p->created_at, true) }}</td></tr>
        <tr><td>شماره فیش</td><td>{{ fa($p->id) }}</td></tr>
        <tr><td>{{ $p->order_id ? 'سفارش' : 'مشتری' }}</td><td>{{ $p->order_id ? fa($p->order?->number).' — ' : '' }}{{ $p->partyName() }}</td></tr>
        @if ($p->partyMobile())<tr><td>موبایل</td><td class="num">{{ fa((string) $p->partyMobile()) }}</td></tr>@endif
    </table>
    <div class="hr"></div>
    <div class="c mu">مبلغ قابل واریز</div>
    <div class="amt">{{ money($p->amount) }} <span style="font-size:.5em">تومان</span></div>
    <div class="words">{{ num_words($p->amount) }} تومان</div>
    <div class="hr"></div>
    <div class="c mu" style="font-weight:800">واریز فقط به حساب زیر</div>
    <table>
        <tr><td>صاحب حساب</td><td class="big">{{ $acc['holder'] ?: '—' }}</td></tr>
        @if ($acc['bank'])<tr><td>بانک</td><td>{{ $acc['bank'] }}</td></tr>@endif
    </table>
    @if ($acc['card'])<div class="box"><div class="k">شماره کارت</div><div class="v">{{ fa($acc['card']) }}</div></div>@endif
    @if ($acc['sheba'])<div class="box"><div class="k">شماره شبا</div><div class="v">{{ $acc['sheba'] }}</div></div>@endif
    @if ($acc['account'])<div class="box"><div class="k">شماره حساب</div><div class="v">{{ fa($acc['account']) }}</div></div>@endif
    <table>
        <tr><td>حواله</td><td>{{ fa($acc['code']) }}</td></tr>
        <tr><td>صادرکننده</td><td>{{ $p->issuer?->displayName() ?: $u->displayName() }}</td></tr>
    </table>
    @if ($link)
        <div class="hr"></div>
        <div class="note">پس از واریز، این کد را با دوربین گوشی اسکن کنید و عکس فیش را بفرستید</div>
        <div class="qr" data-qr="{{ $link }}"></div>
    @endif
    <div class="hr"></div>
    <div class="note">لطفاً دقیقاً همین مبلغ را به همین حساب واریز کنید.<br>بار شما پس از تأیید واریز تحویل می‌شود.</div>
    @if (setting('phone'))<div class="c mu num" style="margin-top:3px">{{ fa(setting('phone')) }}</div>@endif
</div>
<script>
(function () {
    var h = document.documentElement;
    function set(w) {
        h.setAttribute('data-w', w);
        try { localStorage.setItem('m_print_w', w); } catch (e) {}
        document.getElementById('pg').textContent = '@media print{@page{size:' + w + 'mm auto;margin:0}}';
        document.querySelectorAll('[data-w]').forEach(function (b) { if (b.tagName === 'BUTTON') b.classList.toggle('on', b.getAttribute('data-w') === w); });
    }
    set(h.getAttribute('data-w') || '80');
    document.querySelectorAll('button[data-w]').forEach(function (b) { b.onclick = function () { set(b.getAttribute('data-w')); }; });
    document.querySelectorAll('[data-qr]').forEach(function (e) { if (window.QRMini) e.innerHTML = QRMini.svg(e.getAttribute('data-qr'), 260); });
    @if (request('auto'))setTimeout(function () { window.print(); }, 450);@endif
})();
</script>
</body>
</html>
