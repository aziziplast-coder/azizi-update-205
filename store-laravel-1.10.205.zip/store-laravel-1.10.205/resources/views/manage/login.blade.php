@extends('manage.layout', ['title' => 'ورود', 'bare' => true, 'bodyClass' => 'no-nav'])
@section('body')
<div class="m-login">
    <div class="brand">
        <img src="{{ route('pwa.manage_icon', 192) }}" alt="">
        <h1>اپ مدیریت</h1>
        <p>{{ store_name() }} — ورود همکاران</p>
    </div>
    @if (session('m_err'))<div class="m-flash err">{{ session('m_err') }}</div>@endif
    <form method="post" action="{{ url('/manage/login') }}" class="m-form" data-login>
        @csrf
        <label class="m-field"><span>شماره موبایل</span>
            <input type="tel" name="mobile" inputmode="tel" autocomplete="username" dir="ltr" placeholder="۰۹۱۲ ۳۴۵ ۶۷۸۹" value="{{ old('mobile') }}" required autofocus data-en>
        </label>
        <label class="m-field" data-pass @if (! old('mobile')) hidden @endif><span>رمز عبور</span>
            <input type="password" name="password" autocomplete="current-password" dir="ltr" placeholder="••••••">
        </label>
        <button type="submit" class="m-btn pri lg block" data-go>{{ old('mobile') ? 'ورود' : 'ادامه' }}</button>
        <p class="m-mu m-sm" style="text-align:center;margin:0">رمز عبور همان رمز ورود به پنل مدیریت است.</p>
    </form>
</div>
<script>
(function () {
    var f = document.querySelector('[data-login]'), p = f.querySelector('[data-pass]'), b = f.querySelector('[data-go]'), m = f.querySelector('[name=mobile]'), pw = f.querySelector('[name=password]');
    f.addEventListener('submit', function (e) {
        if (p.hidden) {
            e.preventDefault();
            var d = window.mEn(m.value).replace(/\D/g, '');
            if (d.length < 10) { window.mToast('شماره موبایل را کامل بنویسید'); return; }
            p.hidden = false; pw.required = true; b.textContent = 'ورود'; setTimeout(function () { pw.focus(); }, 60);
        }
    });
})();
</script>
@endsection
