@extends('manage.layout', ['title' => 'سفارش‌ها', 'sub' => $list->total() ? fa($list->total()).' سفارش' : null])
@php
    $tabs = ['mine' => 'مال من', 'free' => 'بدون مسئول', 'open' => 'همه باز', 'on_hold' => 'در انتظار بیعانه', 'processing' => 'جمع‌آوری', 'settling' => 'تسویه', 'shipped' => 'در حال ارسال', 'completed' => 'تکمیل', 'all' => 'همه'];
@endphp
@section('body')
<form class="m-search" method="get">
    <svg viewBox="0 0 24 24"><path d="M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4"/></svg>
    <input type="search" name="q" value="{{ $q }}" placeholder="شماره سفارش، نام یا موبایل" enterkeyhint="search">
    <input type="hidden" name="f" value="{{ $f }}">
</form>
<div class="m-tabs">
    @foreach ($tabs as $k => $v)
        <a href="{{ route('manage.orders', ['f' => $k, 'q' => $q ?: null]) }}" @class(['on' => $f === $k])>{{ $v }}</a>
    @endforeach
</div>
<div class="m-list">
    @forelse ($list as $o)
        @php $hx = \App\Models\Order::HEX[$o->status] ?? ['#f1f5f9', '#334155']; @endphp
        <a class="m-item" href="{{ route('manage.order', $o) }}">
            <span class="ic" style="background:{{ $hx[0] }};color:{{ $hx[1] }};font-size:13px;font-weight:900">{{ fa(substr((string) $o->number, -4)) }}</span>
            <span class="tx">
                <b>{{ $o->customer_name ?: '—' }}</b>
                <small>{{ fa((string) $o->mobile) }} · {{ $o->created_at ? $o->created_at->diffForHumans() : '' }}{{ $o->assignee ? ' · '.$o->assignee->displayName() : '' }}</small>
            </span>
            <span class="en"><span class="amt">{{ money($o->total) }}</span><span class="m-chip" style="background:{{ $hx[0] }};color:{{ $hx[1] }}">{{ $o->statusLabel() }}</span></span>
        </a>
    @empty
        <div class="m-empty"><i>📭</i>سفارشی پیدا نشد.</div>
    @endforelse
</div>
@include('manage.partials.pager', ['p' => $list])
@endsection
