@extends('manage.layout', ['title' => 'مدیریت', 'sub' => store_name()])
@php $C = \App\Http\Controllers\ManageController::class; $h = (int) now()->format('G'); @endphp
@section('body')
<div class="m-hello">
    <div><b>{{ $h < 12 ? 'صبح بخیر' : ($h < 17 ? 'روز بخیر' : 'عصر بخیر') }}، {{ \Illuminate\Support\Str::of($u->displayName())->explode(' ')->first() }} 👋</b><small>{{ jdate(now()) }}</small></div>
</div>

@if ($C::can($u, 'receipts'))
    <div class="m-hero">
        <small>ظرفیت آزاد حواله‌های {{ $C::can($u, 'chief') ? 'جاری' : 'شما' }} ({{ fa($k['remits']) }} حواله)</small>
        <span class="v">{{ money($k['free']) }} <small>تومان</small></span>
        <div class="m-btns">
            @if ($C::can($u, 'walkin'))
                <a href="{{ route('manage.receipt.new') }}" class="m-btn lg">＋ فیش حضوری</a>
            @else
                <a href="{{ route('manage.orders', ['f' => 'mine']) }}" class="m-btn lg">سفارش‌های من</a>
            @endif
            <a href="{{ route('manage.receipts', ['tab' => 'submitted']) }}" class="m-btn lg" style="background:rgb(255 255 255/.16);color:#fff">بررسی فیش‌ها @if ($k['review'])({{ fa($k['review']) }})@endif</a>
        </div>
        @if ($k['today'])<small style="display:block;margin-top:10px">فیش‌های حضوری امروز: {{ money($k['today']) }} تومان</small>@endif
    </div>
@endif

<div class="m-tiles">
    @if ($C::can($u, 'chat'))
        <a class="m-tile t-chat" href="{{ route('manage.chat') }}"><span class="ic"><svg viewBox="0 0 24 24"><path d="M4 5h16v11H8l-4 4z"/></svg></span><b>{{ fa($k['chat']) }}</b><span>پیام خوانده‌نشده</span>@if ($k['chat'])<span class="m-chip er badge">تازه</span>@endif</a>
    @endif
    @if ($C::can($u, 'receipts'))
        <a class="m-tile t-rc" href="{{ route('manage.receipts', ['tab' => 'submitted']) }}"><span class="ic"><svg viewBox="0 0 24 24"><path d="M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6"/></svg></span><b>{{ fa($k['review']) }}</b><span>فیش منتظر تأیید</span></a>
        <a class="m-tile t-rc" href="{{ route('manage.receipts', ['tab' => 'awaiting']) }}"><span class="ic"><svg viewBox="0 0 24 24"><path d="M12 7v5l3 2M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z"/></svg></span><b>{{ fa($k['awaiting']) }}</b><span>منتظر واریز مشتری</span></a>
    @endif
    @if ($C::can($u, 'orders'))
        <a class="m-tile t-or" href="{{ route('manage.orders') }}"><span class="ic"><svg viewBox="0 0 24 24"><path d="M5 7h14l-1.5 12h-11zM9 7V5a3 3 0 0 1 6 0v2"/></svg></span><b>{{ fa($k['orders']) }}</b><span>{{ $u->isAdmin() ? 'سفارش باز' : 'سفارش باز من' }}</span></a>
        <a class="m-tile t-wb" href="{{ route('manage.waybills') }}"><span class="ic"><svg viewBox="0 0 24 24"><path d="M3 6h11v10H3zM14 9h4l3 3v4h-7z"/></svg></span><b>{{ fa($k['waybills']) }}</b><span>بیجک ارسال‌نشده</span>@if ($k['late'])<span class="m-chip er badge">{{ fa($k['late']) }} دیرکرد</span>@endif</a>
    @endif
    @if ($C::can($u, 'remits'))
        <a class="m-tile t-rm" href="{{ route('manage.remits') }}"><span class="ic"><svg viewBox="0 0 24 24"><path d="M3 7h18v10H3zM3 11h18M7 15h3"/></svg></span><b>{{ fa($k['remits']) }}</b><span>حواله جاری</span></a>
    @endif
</div>

@isset($k['prod'])
<div class="m-sec"><b>📦 محصولات</b><a href="{{ route('manage.products') }}" class="m-sm" style="color:var(--ac);font-weight:800">همه ←</a></div>
<div class="m-tiles">
    <a class="m-tile" href="{{ route('manage.products', ['tab' => 'pending']) }}"><span class="ic" style="background:#fef3c7;color:#b45309">⏳</span><b>{{ fa($k['prod']['pending']) }}</b><span>منتظر تأیید و انتشار</span></a>
    <a class="m-tile" href="{{ route('manage.products', ['tab' => 'out']) }}"><span class="ic" style="background:#fee2e2;color:#b91c1c">⛔</span><b>{{ fa($k['prod']['out']) }}</b><span>ناموجود</span></a>
    <a class="m-tile" href="{{ route('manage.products', ['tab' => 'nophoto']) }}"><span class="ic" style="background:#e0e7ff;color:#4338ca">📷</span><b>{{ fa($k['prod']['nophoto']) }}</b><span>بدون عکس</span></a>
    <a class="m-tile" href="{{ route('manage.products') }}"><span class="ic" style="background:#dcfce7;color:#15803d">📦</span><b>{{ fa($k['prod']['all']) }}</b><span>کل کالاها</span></a>
</div>
@endisset

@if ($groups !== null)
    @if ($groups)
        @include('manage.partials.modules', ['groups' => $groups])
    @else
        <div class="m-empty"><i>🔒</i>هنوز بخشی برای شما فعال نشده است. از مدیر بخواهید دسترسی‌های لازم را بدهد.</div>
    @endif
@else
    <a class="m-row-link" href="{{ route('manage.all') }}" style="background:var(--card);border:1px solid var(--ln);margin-top:4px"><svg viewBox="0 0 24 24"><path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"/></svg><b>همه بخش‌های مدیریت</b><small class="m-mu" style="margin-inline-start:auto">محصولات، حسابداری، گزارش‌ها، تنظیمات …</small></a>
@endif
@endsection
