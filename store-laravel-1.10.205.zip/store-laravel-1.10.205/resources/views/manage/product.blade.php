@extends('manage.layout', ['title' => 'ویرایش کالا', 'sub' => \Illuminate\Support\Str::limit($p->name, 40), 'back' => url()->previous() !== url()->current() && str_contains(url()->previous(), '/manage/products') ? url()->previous() : route('manage.products')])
@php
    $imgs = $p->images();
    $code = $p->sku ?: ($p->sync_code ?: $p->barcode);
    $sw = fn ($name, $on, $label, $hint = null) => '<label class="m-swrow"><span><b>'.e($label).'</b>'.($hint ? '<small>'.e($hint).'</small>' : '').'</span><input type="hidden" name="_b_'.$name.'" value="1"><span class="m-sw"><input type="checkbox" name="'.$name.'" value="1" '.($on ? 'checked' : '').'><i></i></span></label>';
@endphp
@section('body')
{{-- عکس‌ها --}}
<div class="m-gal">
    @forelse ($imgs as $i => $img)
        <button type="button" class="m-gal-i" data-img="{{ $img }}" data-main="{{ $i === 0 ? 1 : 0 }}" data-src="{{ thumb($img, 960) }}">
            <img src="{{ thumb($img, 480) }}" alt="" loading="lazy">@if ($i === 0)<em>اصلی</em>@endif
        </button>
    @empty
        <div class="m-gal-empty">📷<span>این کالا عکس ندارد</span></div>
    @endforelse
</div>
<form method="post" action="{{ route('manage.product.image', $p) }}" enctype="multipart/form-data" class="m-btns" id="imgF">
    @csrf<input type="hidden" name="do" value="add"><input type="hidden" name="as" value="{{ $imgs ? 'gallery' : 'main' }}" id="imgAs">
    <label class="m-btn"><input type="file" name="files[]" accept="image/*" capture="environment" hidden data-auto>📷 عکس با دوربین</label>
    <label class="m-btn"><input type="file" name="files[]" accept="image/*" multiple hidden data-auto>🖼 از گالری</label>
</form>

{{-- وضعیت --}}
@if ($p->review === 'pending')
    <div class="m-card" style="border-color:#f59e0b">
        <b>⏳ منتظر تأیید و انتشار</b>
        @if ($missing)<p class="m-sm" style="margin:6px 0 0;color:var(--er)">کمبود: {{ implode('، ', $missing) }}</p>@endif
        <form method="post" action="{{ route('manage.product.publish', $p) }}" style="margin-top:10px">@csrf
            @if ($missing)<input type="hidden" name="force" value="1">@endif
            <button class="m-btn ok block" @if ($missing) data-confirm="کالا ناقص است ({{ implode('، ', $missing) }}). با این حال منتشر شود؟" @endif>✅ تأیید و انتشار در سایت</button>
        </form>
    </div>
@endif

<form method="post" action="{{ route('manage.product', $p) }}" class="m-form" id="pform">
    @csrf
    <div class="m-card m-form">
        <h3>نمایش و موجودی</h3>
        {!! $sw('is_active', $p->is_active, 'نمایش در سایت', $p->is_active ? 'مشتری‌ها این کالا را می‌بینند' : 'از سایت مخفی است') !!}
        {!! $sw('in_stock', $p->in_stock, 'موجود است', 'خاموش = «ناموجود» در سایت') !!}
    </div>

    <div class="m-card m-form">
        <h3>💰 قیمت و کارتن (عمده)</h3>
        <label class="m-field"><span>قیمت هر عدد (تومان)</span><input class="m-in big" name="price" value="{{ (int) $p->price }}" inputmode="numeric" data-money><small data-money-hint></small></label>
        <label class="m-field"><span>قیمت قبل از تخفیف <small class="m-mu">(اختیاری؛ اگر بیشتر باشد تخفیف نمایش داده می‌شود)</small></span><input name="compare_price" value="{{ $p->compare_price }}" inputmode="numeric" data-money><small data-money-hint></small></label>
        <div class="m-two">
            <label class="m-field"><span>تعداد در کارتن</span><input name="per_carton" value="{{ fa($p->per_carton) }}" inputmode="numeric" data-en dir="ltr"></label>
            @unless (\App\Models\Product::unlimited())<label class="m-field"><span>موجودی (عدد)</span><input name="stock" value="{{ $p->stock === null ? '' : fa($p->stock) }}" inputmode="numeric" data-en dir="ltr" placeholder="نامحدود"></label>@endunless
        </div>
        <div class="m-two">
            <label class="m-field"><span>نوع خرید عمده</span>
                <select name="buy_mode">
                    <option value="">طبق قانون انبار</option>
                    @foreach (\App\Models\Product::BUY_MODES as $m => $n)<option value="{{ $m }}" @selected($p->buy_mode === $m)>{{ $n }}</option>@endforeach
                </select>
            </label>
            <label class="m-field"><span>تعداد N <small class="m-mu">(بسته/فله)</small></span><input name="buy_qty" value="{{ $p->buy_qty ? fa($p->buy_qty) : '' }}" inputmode="numeric" data-en dir="ltr"></label>
        </div>
        @php [$bmin, $bstep] = $p->buyRule(); @endphp
        <div class="m-mu m-sm">الان: {{ $p->buyRuleText() ?: ($p->per_carton > 1 ? 'فقط کارتن '.fa($p->per_carton).'تایی' : 'یکی‌یکی') }}@if (\App\Models\Warehouse::isLoose((int) $p->warehouse_id) && $p->buy_mode !== 'carton') · انبار عمده عددی؛ برای «فقط کارتنی» نوع خرید را «کارتن کامل» و تعداد در کارتن را بنویسید.@endif</div>
        @if ($p->per_carton > 1)
            <div class="m-mu m-sm">قیمت هر کارتن: <b style="color:var(--tx)">{{ money($p->price * $p->per_carton) }}</b> تومان</div>
        @endif
    </div>

    @if ($p->per_carton > 1)
    <div class="m-card m-form">
        <h3>🛍 فروش تکی (خرده)</h3>
        {!! $sw('retail_enabled', $p->retail_enabled, 'فروش تکی فعال باشد') !!}
        <div class="m-two">
            <label class="m-field"><span>قیمت تکی</span><input name="retail_price" value="{{ $p->retail_price }}" inputmode="numeric" data-money></label>
            @unless (\App\Models\Product::unlimited())<label class="m-field"><span>موجودی خرده</span><input name="retail_stock" value="{{ $p->retail_stock === null ? '' : fa($p->retail_stock) }}" inputmode="numeric" data-en dir="ltr" placeholder="نامحدود"></label>@endunless
        </div>
        {!! $sw('retail_in_stock', $p->retail_in_stock, 'تکی موجود است') !!}
    </div>
    @endif

    <div class="m-card m-form">
        <h3>📝 مشخصات</h3>
        <label class="m-field"><span>نام کالا</span><input name="name" value="{{ $p->name }}" required maxlength="190"></label>
        <div class="m-two">
            <label class="m-field"><span>کد کالا</span><input name="sku" value="{{ $p->sku }}" dir="ltr" data-en maxlength="64"></label>
            <label class="m-field"><span>بارکد</span><input name="barcode" value="{{ $p->barcode }}" dir="ltr" data-en maxlength="64"></label>
        </div>
        <label class="m-field"><span>دسته</span>
            <select name="category_id">
                <option value="">— بدون دسته —</option>
                @foreach ($cats->whereNull('parent_id') as $c)
                    <option value="{{ $c->id }}" @selected($p->category_id === $c->id)>{{ $c->name }}</option>
                    @foreach ($cats->where('parent_id', $c->id) as $s)<option value="{{ $s->id }}" @selected($p->category_id === $s->id)>— {{ $s->name }}</option>@endforeach
                @endforeach
            </select>
        </label>
        <label class="m-field"><span>واحد <small class="m-mu">(مثلاً عدد، دست ۶ عددی، جفت)</small></span><input name="unit_label" value="{{ $p->unit_label }}" list="units"></label>
        <label class="m-field"><span>توضیح کوتاه</span><textarea name="short_description" rows="3">{{ $p->short_description }}</textarea></label>
        <datalist id="units">@foreach (['عدد', 'جفت', 'دست', 'دست ۶ عددی', 'دست ۱۲ عددی', 'پک', 'ست', 'بسته', 'جین', 'کیلو'] as $x)<option value="{{ $x }}">@endforeach</datalist>
    </div>

    <dl class="m-card m-kv">
        <dt>فروش</dt><dd>{{ fa($p->sales_count) }} بار</dd>
        <dt>بازدید</dt><dd>{{ fa($p->views) }}</dd>
        @if ($p->warehouse_id)<dt>انبار عمده</dt><dd>{{ $warehouses[$p->warehouse_id] ?? '—' }}</dd>@endif
        <dt>آخرین تغییر</dt><dd>{{ jdate($p->updated_at, true) }}</dd>
    </dl>

    <div class="m-btns">
        <a class="m-btn" href="{{ url('/admin/products/'.$p->id.'/edit') }}?from=app">⚙️ ویرایش کامل (پنل)</a>
        <a class="m-btn" href="{{ $p->url() }}" target="_blank">🌐 در سایت</a>
    </div>
    <div class="m-save"><button class="m-btn pri block lg">ذخیره تغییرات</button></div>
</form>

<div class="m-sheet" data-sheet="img" hidden><div class="m-sheet-box">
    <div class="m-grab"></div>
    <img id="imgV" alt="" style="width:100%;max-height:52vh;object-fit:contain;border-radius:16px;background:rgb(127 127 127 / .08)">
    <form method="post" action="{{ route('manage.product.image', $p) }}" class="m-btns">
        @csrf<input type="hidden" name="path" id="imgP">
        <button name="do" value="main" class="m-btn" id="imgMain">⭐ عکس اصلی شود</button>
        <button name="do" value="delete" class="m-btn er" data-confirm="این عکس حذف شود؟">🗑 حذف عکس</button>
    </form>
</div></div>
@endsection
@push('foot')
<script>
document.querySelectorAll('[data-auto]').forEach(function (i) { i.addEventListener('change', function () { if (i.files.length) { mToast('در حال ارسال عکس…'); i.form.submit(); } }); });
document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-img]'); if (!b) return;
    document.getElementById('imgV').src = b.getAttribute('data-src');
    document.getElementById('imgP').value = b.getAttribute('data-img');
    document.getElementById('imgMain').hidden = b.getAttribute('data-main') === '1';
    mSheet('img', true);
});
</script>
@endpush
