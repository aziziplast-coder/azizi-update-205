@php
    $u = auth()->user();
    $C = \App\Http\Controllers\ManageController::class;
    $navItems = [];
    if ($u) {
        $navItems[] = ['home', route('manage.home'), 'خانه', 'M3 11.5 12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z'];
        if ($C::can($u, 'chat')) $navItems[] = ['chat', route('manage.chat'), 'گفتگو', 'M4 5h16v11H8l-4 4z'];
        if ($C::can($u, 'receipts')) $navItems[] = ['receipts', route('manage.receipts'), 'فیش‌ها', 'M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6'];
        if ($C::can($u, 'orders')) $navItems[] = ['orders', route('manage.orders'), 'سفارش‌ها', 'M5 7h14l-1.5 12h-11zM9 7V5a3 3 0 0 1 6 0v2'];
        if ($C::can($u, 'remits')) $navItems[] = ['remits', route('manage.remits'), 'حواله‌ها', 'M3 7h18v10H3zM3 11h18M7 15h3'];
        if ($C::can($u, 'waybills')) $navItems[] = ['waybills', route('manage.waybills'), 'بیجک', 'M3 6h11v10H3zM14 9h4l3 3v4h-7zM6.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM17.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z'];
        if ($C::can($u, 'products')) $navItems[] = ['products', route('manage.products'), 'محصولات', 'M12 3 3 7.5v9L12 21l9-4.5v-9zM3 7.5 12 12l9-4.5M12 12v9'];
        // نوار پایین: ۴ بخش اول + «منو» (همه بخش‌های پنل متناسب با دسترسی)
        $navItems = array_slice($navItems, 0, 4);
        $navItems[] = ['all', route('manage.all'), 'منو', 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z'];
        $more = [];
    }
@endphp
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#ffffff" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#14131a" media="(prefers-color-scheme: dark)">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="مدیریت">
<meta name="format-detection" content="telephone=no">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>{{ $title ?? 'مدیریت' }} | {{ store_name() }}</title>
<link rel="manifest" href="{{ route('manage.manifest') }}">
<link rel="apple-touch-icon" href="{{ route('pwa.manage_icon', 180) }}">
<link rel="icon" href="{{ route('pwa.manage_icon', 64) }}">
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}?v={{ config('store.version') }}">
<link rel="stylesheet" href="{{ asset('css/manage.css') }}?v={{ @filemtime(public_path('css/manage.css')) }}">
<style>:root{--ac:{{ setting('brand_color', '#4f4a63') }};--font:{!! \App\Support\Fonts::stack() !!}}</style>
@stack('head')
<script>
if ('serviceWorker' in navigator) { window.addEventListener('load', function () { navigator.serviceWorker.register('{{ route('manage.sw', [], false) }}', { scope: '/manage' }).catch(function () {}); }); }
(function () { var s = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true; if (s) document.documentElement.classList.add('m-app'); })();
</script>
</head>
<body class="m @isset($bodyClass){{ $bodyClass }}@endisset">
@unless (! empty($bare))
<header class="m-top">
    @isset($back)<a href="{{ $back }}" class="m-icon" aria-label="بازگشت"><svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg></a>@endisset
    <div class="m-title"><b>{{ $title ?? 'مدیریت' }}</b>@isset($sub)<small>{{ $sub }}</small>@endisset</div>
    @yield('topActions')
    @if ($u)
        <button type="button" class="m-ava" data-sheet-open="me" aria-label="حساب من">{{ mb_substr($u->displayName(), 0, 1) }}</button>
    @endif
</header>
@endunless
<main class="m-main">
    @if (session('m_ok'))<div class="m-flash ok" data-flash>{{ session('m_ok') }}</div>@endif
    @if (is_string(request('m_msg')) && request('m_msg') !== '')<div class="m-flash ok" data-flash>✅ {{ \Illuminate\Support\Str::limit(request('m_msg'), 200) }}</div>@endif
    @if (session('m_err'))<div class="m-flash err" data-flash>{{ session('m_err') }}</div>@endif
    @if ($errors->any())<div class="m-flash err" data-flash>{{ $errors->first() }}</div>@endif
    @yield('body')
</main>
@if ($u && empty($bare) && empty($noNav))
<nav class="m-nav" style="--n:{{ count($navItems) + ($more ? 1 : 0) }}">
    @foreach ($navItems as [$k, $href, $label, $icon])
        <a href="{{ $href }}" @class(['on' => ($nav ?? '') === $k])><svg viewBox="0 0 24 24"><path d="{{ $icon }}"/></svg><span>{{ $label }}</span></a>
    @endforeach
    @if ($more)
        <button type="button" data-sheet-open="more" @class(['on' => in_array($nav ?? '', array_column($more, 0), true)])><svg viewBox="0 0 24 24"><path d="M5 12h.01M12 12h.01M19 12h.01"/></svg><span>بیشتر</span></button>
    @endif
</nav>
@if ($more)
<div class="m-sheet" data-sheet="more" hidden><div class="m-sheet-box">
    <div class="m-grab"></div>
    @foreach ($more as [$k, $href, $label, $icon])
        <a class="m-row-link" href="{{ $href }}"><svg viewBox="0 0 24 24"><path d="{{ $icon }}"/></svg><b>{{ $label }}</b></a>
    @endforeach
</div></div>
@endif
<div class="m-sheet" data-sheet="me" hidden><div class="m-sheet-box">
    <div class="m-grab"></div>
    <div class="m-me"><span class="m-ava lg">{{ mb_substr($u->displayName(), 0, 1) }}</span><div><b>{{ $u->displayName() }}</b><small>{{ fa((string) $u->mobile) }} — {{ \App\Models\User::ROLES[$u->role] ?? $u->role }}</small></div></div>
    <a class="m-row-link" href="{{ url('/admin') }}"><svg viewBox="0 0 24 24"><path d="M4 5h16v10H4zM8 19h8M12 15v4"/></svg><b>پنل کامل (کامپیوتر)</b></a>
    <button type="button" class="m-row-link" data-install hidden><svg viewBox="0 0 24 24"><path d="M12 3v12M7 10l5 5 5-5M5 21h14"/></svg><b>نصب اپ روی گوشی</b></button>
    <form method="post" action="{{ route('manage.logout') }}">@csrf<button class="m-row-link danger"><svg viewBox="0 0 24 24"><path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/></svg><b>خروج</b></button></form>
</div></div>
@endif
<div class="m-toast" data-toast hidden></div>
<script src="{{ asset('js/manage.js') }}?v={{ @filemtime(public_path('js/manage.js')) }}"></script>
@auth @if (in_array(auth()->user()->role, ['admin', 'staff'], true)) @include('partials.rcpt-view') @endif @endauth
@stack('foot')
</body>
</html>
