@extends('manage.layout', ['title' => 'ارسال فیش واریز', 'bare' => true, 'noNav' => true, 'bodyClass' => 'm-pubb'])
@php $u = null; $files = $p->files(); @endphp
@section('body')
<div class="m-pub">
    <div class="m-pub-head"><b>{{ store_name() }}</b><small>فیش واریز {{ $p->partyName() ? '— '.$p->partyName() : '' }}</small></div>

    @if ($p->status === 'confirmed')
        <div class="m-card" style="text-align:center"><div style="font-size:46px">✅</div><b style="font-size:18px">واریز شما تأیید شد</b><p class="m-mu">مبلغ {{ money($p->amount) }} تومان دریافت شد. سپاس از شما.</p></div>
    @elseif ($p->status === 'cancelled')
        <div class="m-card" style="text-align:center"><div style="font-size:46px">⛔</div><b>این فیش باطل شده است.</b><p class="m-mu">لطفاً با فروشگاه تماس بگیرید.</p></div>
    @else
        <div class="m-card">
            <div class="m-amt"><small>مبلغ قابل واریز</small><b>{{ money($p->amount) }}</b><small>تومان — {{ num_words($p->amount) }} تومان</small></div>
            @if ($p->status === 'submitted' && ! session('m_ok'))<div class="m-flash ok" style="margin-top:10px">فیش شما رسید ✅ پس از دیدن مبلغ در حساب تأیید می‌شود.</div>@endif
            @if ($p->status === 'rejected')<div class="m-flash err" style="margin-top:10px">فیش قبلی تأیید نشد{{ $p->reject_reason ? ': '.$p->reject_reason : '' }}. لطفاً دوباره بفرستید.</div>@endif
        </div>
        <div class="m-card">
            <h3>🏦 واریز فقط به این حساب</h3>
            <dl class="m-kv" style="margin-bottom:10px"><dt>صاحب حساب</dt><dd>{{ $acc['holder'] ?: '—' }}</dd>@if ($acc['bank'])<dt>بانک</dt><dd>{{ $acc['bank'] }}</dd>@endif</dl>
            @if ($acc['card'])<div class="m-copy" style="margin-bottom:8px"><b>{{ fa($acc['card']) }}</b><button type="button" data-copy="{{ str_replace(' ', '', $acc['card']) }}">کپی کارت</button></div>@endif
            @if ($acc['sheba'])<div class="m-copy" style="margin-bottom:8px"><b style="font-size:13px">{{ $acc['sheba'] }}</b><button type="button" data-copy="{{ str_replace(' ', '', $acc['sheba']) }}">کپی شبا</button></div>@endif
            @if ($acc['account'])<div class="m-copy"><b>{{ fa($acc['account']) }}</b><button type="button" data-copy="{{ $acc['account'] }}">کپی حساب</button></div>@endif
        </div>
        @if ($p->payable())
        <form method="post" action="{{ route('walkin.upload', $p->walkin_token) }}" enctype="multipart/form-data" class="m-card m-form">
            @csrf
            <h3>📷 {{ $files ? 'افزودن عکس فیش' : 'ارسال عکس فیش' }}</h3>
            <label class="m-up" data-up="#pv"><input type="file" name="files[]" accept="image/*,application/pdf" multiple><b>انتخاب عکس فیش</b><small>از گالری یا دوربین گوشی</small></label>
            <div class="m-prev" id="pv"></div>
            <label class="m-field"><span>شماره پیگیری <small class="m-mu">(اختیاری)</small></span><input name="ref" dir="ltr" inputmode="numeric" data-en maxlength="80"></label>
            <button class="m-btn pri block lg" data-up-go hidden>ارسال فیش</button>
        </form>
        @endif
    @endif
    <p class="m-mu m-sm" style="text-align:center">@if (setting('phone'))تماس: <span dir="ltr">{{ fa(setting('phone')) }}</span>@endif</p>
</div>
@endsection
