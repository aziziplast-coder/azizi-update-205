@extends('manage.layout', ['title' => 'بیجک', 'sub' => $tab === 'archive' ? 'بایگانی ارسال‌شده‌ها' : 'بارهای منتظر بیجک'])
@section('body')
<form class="m-search" method="get">
    <svg viewBox="0 0 24 24"><path d="M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4"/></svg>
    <input type="search" name="q" value="{{ $q }}" placeholder="شماره سفارش، نام یا موبایل" enterkeyhint="search">
    <input type="hidden" name="tab" value="{{ $tab }}">
</form>
<div class="m-seg">
    <a href="{{ route('manage.waybills', ['tab' => 'pending']) }}" @class(['on' => $tab === 'pending'])>ارسال‌نشده {{ $counts['pending'] ? '('.fa($counts['pending']).')' : '' }}</a>
    <a href="{{ route('manage.waybills', ['tab' => 'archive']) }}" @class(['on' => $tab === 'archive'])>🗂 بایگانی</a>
</div>
@if ($tab === 'pending' && $counts['late'])
    <div class="m-flash err">⏰ {{ fa($counts['late']) }} بار از مهلت بارگذاری بیجک گذشته است.</div>
@endif
<div class="m-list">
    @forelse ($list as $o)
        @php
            $dl = $tab === 'pending' ? \App\Services\Shipping::deadline($o) : null;
            $late = $dl && $dl->isPast();
            $img = $o->waybill_path && ! str_ends_with(strtolower($o->waybill_path), '.pdf');
        @endphp
        <div class="m-card" style="padding:12px 14px">
            <div class="m-wb">
                <span class="th">
                    @if ($tab === 'archive' && $o->waybill_path)
                        <a href="{{ route('admin.waybill', $o) }}" target="_blank" style="display:contents">@if ($img)<img src="{{ route('admin.waybill', $o) }}" alt="" loading="lazy">@else📄@endif</a>
                    @else
                        {{ $o->direct_at ? '🚚' : '📦' }}
                    @endif
                </span>
                <span style="flex:1;min-width:0;line-height:1.6">
                    <b style="display:block;font-weight:900">{{ $o->customer_name ?: '—' }}</b>
                    <small class="m-mu">سفارش {{ fa($o->number) }}@if ($o->city) · {{ $o->city }}@endif</small>
                    @if ($tab === 'archive')
                        <span style="display:block;margin-top:3px">
                            @if ($o->direct_at)<span class="m-chip in">ارسال مستقیم</span>@if ($o->driver_phone) <a href="tel:{{ $o->driver_phone }}" class="m-sm" dir="ltr">📞 {{ fa($o->driver_phone) }}</a>@endif
                            @else<span class="m-chip ok">بیجک باربری</span>@endif
                            <small class="m-mu">{{ jdate($o->direct_at ?? $o->updated_at) }}</small>
                        </span>
                    @else
                        <small style="display:block;color:{{ $late ? 'var(--er)' : 'var(--mu)' }};font-weight:700">ارسال {{ $o->status_changed_at?->diffForHumans() }}{{ $late ? ' — دیر شده' : '' }}</small>
                    @endif
                </span>
                @if ($o->mobile)<a href="tel:{{ $o->mobile }}" class="m-icon" aria-label="تماس">📞</a>@endif
            </div>
            <div class="m-btns" style="margin-top:10px">
                @if ($tab === 'pending')
                    <button type="button" class="m-btn pri" data-wb="{{ $o->id }}" data-wb-n="{{ fa($o->number) }}" data-wb-m="waybill">📷 بیجک باربری</button>
                    <button type="button" class="m-btn" data-wb="{{ $o->id }}" data-wb-n="{{ fa($o->number) }}" data-wb-m="direct">🚚 ارسال مستقیم</button>
                @elseif ($o->waybill_path)
                    <a class="m-btn" href="{{ route('admin.waybill', $o) }}" target="_blank">👁 مشاهده</a>
                    <a class="m-btn" href="{{ route('admin.waybill', [$o, 'dl' => 1]) }}">⬇️ دانلود</a>
                @else
                    <a class="m-btn" style="grid-column:span 2" href="{{ route('manage.order', $o) }}">جزئیات سفارش</a>
                @endif
            </div>
        </div>
    @empty
        <div class="m-empty"><i>{{ $tab === 'pending' ? '🎉' : '🗂' }}</i>{{ $tab === 'pending' ? 'همه بیجک‌ها ارسال شده‌اند.' : 'چیزی در بایگانی نیست.' }}</div>
    @endforelse
</div>
@include('manage.partials.pager', ['p' => $list])

<div class="m-sheet" data-sheet="wb" hidden><div class="m-sheet-box">
    <div class="m-grab"></div>
    <b style="font-size:17px" id="wbT"></b>
    <form method="post" enctype="multipart/form-data" class="m-form" id="wbF">
        @csrf<input type="hidden" name="mode" id="wbM">
        <p class="m-mu m-sm" id="wbH" style="margin:0"></p>
        <div class="m-btns">
            <label class="m-up" data-up="#wbP" style="min-height:92px"><input type="file" name="file" accept="image/*" capture="environment"><b>📷 دوربین</b></label>
            <label class="m-up" data-up="#wbP" style="min-height:92px"><input type="file" name="file" accept="image/*,application/pdf"><b>🖼 گالری</b></label>
        </div>
        <div class="m-prev" id="wbP"></div>
        <label class="m-field" id="wbD"><span>شماره راننده <small class="m-mu">(اختیاری — اگر وارد شود برای مشتری پیامک می‌رود)</small></span><input name="driver" dir="ltr" inputmode="tel" data-en maxlength="20" placeholder="09…"></label>
        <button class="m-btn pri block lg" id="wbG">ثبت</button>
    </form>
</div></div>
@endsection
@push('foot')
<script>
(function () {
    var base = @json(url('/manage/waybills'));
    document.addEventListener('click', function (e) {
        var b = e.target.closest('[data-wb]'); if (!b) return;
        var direct = b.getAttribute('data-wb-m') === 'direct';
        document.getElementById('wbF').action = base + '/' + b.getAttribute('data-wb');
        document.getElementById('wbM').value = direct ? 'direct' : 'waybill';
        document.getElementById('wbT').textContent = (direct ? '🚚 ارسال مستقیم — سفارش ' : '📷 بیجک باربری — سفارش ') + b.getAttribute('data-wb-n');
        document.getElementById('wbH').textContent = direct ? 'بار مستقیم با ماشین به مغازه مشتری رفته. عکس بارنامه و شماره راننده هر دو اختیاری‌اند.' : 'از بیجک باربری عکس بگیرید یا از گالری انتخاب کنید.';
        document.getElementById('wbD').hidden = !direct;
        document.getElementById('wbG').textContent = direct ? 'ثبت ارسال مستقیم' : 'بارگذاری بیجک';
        document.getElementById('wbP').innerHTML = '';
        document.querySelectorAll('#wbF input[type=file]').forEach(function (i) { i.value = ''; i.disabled = false; });
        document.querySelector('#wbF [name=driver]').value = '';
        mSheet('wb', true);
    });
    document.getElementById('wbF').addEventListener('submit', function (e) {
        var has = Array.prototype.some.call(this.querySelectorAll('input[type=file]'), function (i) { return i.files && i.files.length; });
        if (document.getElementById('wbM').value === 'waybill' && !has) { e.preventDefault(); e.stopImmediatePropagation(); mToast('عکس بیجک را انتخاب کنید'); }
    }, true);
})();
</script>
@endpush
