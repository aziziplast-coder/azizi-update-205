/* Service Worker فروشگاه — نسخه {{ $version }} */
const V = '{{ $version }}';
const STATIC = 'static-' + V;
const PAGES = 'pages-' + V;
const IMAGES = 'images-v1';
const PRECACHE = @json($assets);
const NO_CACHE = /^\/(keeper|walkin|buyer|admin|admin-tools|livewire|filament|install|login|logout|register|cart|checkout|payment|account|order|search\/suggest|health-check|up)(\/|$|\?)/;

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(STATIC).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => ![STATIC, PAGES, IMAGES].includes(k)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

async function trim(name, max) {
  const c = await caches.open(name);
  const keys = await c.keys();
  for (let i = 0; i < keys.length - max; i++) await c.delete(keys[i]);
}

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  if (NO_CACHE.test(url.pathname)) {
    if (req.mode === 'navigate') {
      e.respondWith(fetch(req).catch(() => caches.match('/offline')));
    }
    return;
  }

  // صفحه‌ها: اول شبکه، در صورت قطعی نسخه ذخیره‌شده یا صفحه آفلاین
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then((res) => {
        if (res.ok && res.type === 'basic') {
          const copy = res.clone();
          caches.open(PAGES).then((c) => c.put(req, copy)).then(() => trim(PAGES, 40));
        }
        return res;
      }).catch(() => caches.match(req).then((r) => r || caches.match('/offline')))
    );
    return;
  }

  // تصاویر محصولات: اول کش
  // تصاویر اپ خرید در حافظه گوشی ذخیره نمی‌شوند (فقط در حافظه مرورگر همان نوبت)
  if (url.pathname.startsWith('/uploads/_buyer/')) return;
  // گفتگو: فایل سیگنال همیشه تازه؛ عکس/ویس/ویدیوی گفتگو در حافظه گوشی انبار نشود
  if (url.pathname.startsWith('/live/') || url.pathname.endsWith('/live.php')) return; // گفتگوی زنده همیشه تازه
  if (url.pathname.startsWith('/uploads/_chat/') || url.pathname.startsWith('/uploads/chat/') || url.pathname.endsWith('/chat-t.php') || url.pathname.endsWith('/chat-s.php')) return;
  if (url.pathname.startsWith('/uploads/') || url.pathname.startsWith('/pwa-icon-')) {
    e.respondWith(
      caches.open(IMAGES).then((c) => c.match(req).then((hit) => hit || fetch(req).then((res) => {
        if (res.ok) { c.put(req, res.clone()); trim(IMAGES, 300); }
        return res;
      })))
    );
    return;
  }

  // css/js/فونت: نسخه ذخیره‌شده + به‌روزرسانی در پس‌زمینه
  if (/^\/(css|js|fonts)\//.test(url.pathname)) {
    e.respondWith(
      caches.open(STATIC).then((c) => c.match(req).then((hit) => {
        const net = fetch(req).then((res) => { if (res.ok) c.put(req, res.clone()); return res; }).catch(() => hit);
        return hit || net;
      }))
    );
  }
});

// اعلان‌های مرورگر
self.addEventListener('push', (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (x) { d = { title: e.data ? e.data.text() : '' }; }
  const title = d.title || @json(store_name());
  e.waitUntil(self.registration.showNotification(title, {
    body: d.body || '', icon: d.icon, badge: d.badge, image: d.image || undefined,
    tag: d.tag || undefined, dir: 'rtl', lang: 'fa', data: { url: d.url || '/' },
  }));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || '/';
  e.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
    for (const c of list) { if (c.url === url && 'focus' in c) return c.focus(); }
    return clients.openWindow(url);
  }));
});
