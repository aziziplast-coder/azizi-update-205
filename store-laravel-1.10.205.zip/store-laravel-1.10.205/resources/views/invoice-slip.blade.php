@php
    /** @var \App\Models\Warehouse|null $wh */
    $wh = $wid ? ($warehouses[$wid] ?? null) : null;
    $keepers = $wh ? $wh->keepers->map(fn ($u) => $u->displayName())->filter()->implode('، ') : '';
    $wids = $group['wids'] ?? [$wid];
    $multi = count($wids) > 1;
    $whTitle = $group['whLabel'] ?? ($wh?->label() ?? 'بدون انبار مشخص');
    if (! empty($group['keepers'])) {
        $keepers = $group['keepers'];
    }
    $whName = fn ($id) => ($id ? ($warehouses[$id] ?? null)?->label() : null) ?? 'بدون انبار مشخص';
    $whCount = $items->countBy(fn ($it) => (int) $it->warehouse_id);
    $qty = 0;
    $cartons = 0;
    $singles = 0;
    foreach ($items as $it) {
        $qty += $it->units;
        if (! $it->isRetail() && $it->per_carton > 1) {
            $cartons += $it->units / $it->per_carton;
        } else {
            $singles += $it->units;
        }
    }
    $showCode = (bool) setting('invoice_barcode', true);
    $tz = config('app.timezone');
    // روال کاغذی انبار سرپرست‌دار: دو خانه تیک (جمع‌کننده + بررسی سرپرست)
    $supId = ! empty($group['key']) && $group['key'][0] === 'k' ? (int) substr($group['key'], 1) : 0;
    $two = $supId && \App\Services\Picking::paper() && \App\Models\User::query()->whereKey($supId)->where('pick_role', 'supervisor')->exists();
@endphp
<article class="sl-page">
    {{-- سربرگ فشرده --}}
    <header class="sl-head">
        <div class="sl-title">
            <h1>{{ ! empty($repl) ? 'حواله کالاهای جایگزین‌شده' : (! empty($addsInfo) ? 'حواله کالاهای افزوده مشتری' : 'حواله خروج انبار') }}</h1>
            <span>{{ store_name() }}</span>
        </div>
        <div class="sl-wh">
            @if ($multi)
                <span>انباردار</span>
                <b>{{ $keepers ?: '..............................' }}</b>
                <small>انبارها: {{ $whTitle }}</small>
            @else
                <span>انبار</span>
                <b>{{ $whTitle }}</b>
                <small>انباردار: {{ $keepers ?: '..............................' }}</small>
            @endif
        </div>
        <div class="sl-no">
            <span>شماره سفارش</span>
            <b>{{ fa($order->number) }}</b>
            @if ($barcodeSvg)<div class="sl-bc">{!! $barcodeSvg !!}</div>@endif
        </div>
    </header>

    {{-- مشخصات مشتری و ثبت سفارش --}}
    <table class="sl-info">
        <tr>
            <th>مشتری</th>
            <td colspan="3"><b>{{ $order->customer_name }}</b>@if ($order->company) — {{ $order->company }}@endif</td>
            <th>موبایل</th>
            <td class="num">{{ fa($order->mobile) }}</td>
        </tr>
        <tr>
            <th>شهر</th>
            <td>{{ trim(($order->province ? $order->province.'، ' : '').$order->city) ?: '—' }}</td>
            <th>تاریخ ثبت</th>
            <td class="num">{{ jdate($order->created_at) }} — {{ fa($order->created_at->setTimezone($tz)->format('H:i')) }}</td>
            <th>اقلام این حواله</th>
            <td class="num">{{ fa($items->count()) }} از {{ fa($order->items->count()) }}</td>
        </tr>
        <tr>
            <th>مسئول سفارش</th>
            <td>{{ $order->assignee?->displayName() ?? '—' }}</td>
            <th>تاریخ چاپ</th>
            <td class="num">{{ jdate(now(), true) }}</td>
            <th>حواله</th>
            <td class="num">{{ fa($pageNo) }} از {{ fa($pageCount) }}</td>
        </tr>
    </table>

    @php
        $pickTasks = \App\Models\PickTask::query()->with(['picker', 'checker', 'keeper'])->whereIn('id', $items->pluck('pick_task_id')->filter()->unique())->get();
    @endphp
    @if ($pickTasks->isNotEmpty())
        <div class="sl-pick">
            @foreach ($pickTasks as $pt)
                <span>
                    @if ($pt->picker)جمع‌کننده: <b>{{ $pt->picker->displayName() }}</b>@elseif ($pt->keeper)انباردار: <b>{{ $pt->keeper->displayName() }}</b>@endif
                    @if ($pt->bay) — جایگاه بار: <b>{{ $pt->bay }}</b>@endif
                    @if ($pt->bags || $pt->boxes) — بسته‌بندی: <b>{{ \App\Http\Controllers\DeskController::packLabel($pt) }}</b>@endif
                    @if ($pt->checked_at) — بررسی و تأیید: <b>{{ $pt->checker?->displayName() }}</b> {{ jdate($pt->checked_at, true) }}@elseif ($pt->isDone()) — جمع شد {{ jdate($pt->done_at, true) }}@else — {{ $pt->stageLabel() }}@endif
                </span>
            @endforeach
        </div>
    @endif

    {{-- اقلام --}}
    @php
        $prices = $showPrice ?? true;
        $amount = 0;
        $cols = 6 + ($prices ? 2 : 0) + ($showCode ? 1 : 0) + ($two ? 1 : 0);
    @endphp
    <table class="sl-table">
        <colgroup>
            <col class="w-n">
            <col class="{{ $two ? 'w-chk2' : 'w-chk' }}">
            @if ($two)<col class="w-chk2">@endif
            @if ($showCode)<col class="w-bc">@endif
            <col>
            <col class="w-type">
            <col class="w-qty">
            @if ($prices)<col class="w-price"><col class="w-sum">@endif
            <col class="w-op">
        </colgroup>
        <thead>
            <tr class="sl-run"><td colspan="{{ $cols }}">حواله {{ $multi ? 'انباردار '.$keepers : $whTitle }} — سفارش {{ fa($order->number) }} — {{ $order->customer_name }}</td></tr>
            <tr>
                <th>ردیف</th>
                @if ($two)
                    <th class="sl-th2" title="جمع‌کننده: تیک = برداشته شد، ضربدر = نبود">جمع‌کننده<br>✓</th>
                    <th class="sl-th2" title="سرپرست پس از کنترل تیک می‌زند">بررسی<br>✓</th>
                @else
                    <th title="تیک = برداشته شد، ضربدر = حذف">✓ / ✗</th>
                @endif
                @if ($showCode)<th>بارکد</th>@endif
                <th class="l">نام کالا</th>
                <th>نوع</th>
                <th>تعداد</th>
                @if ($prices)<th>فی هر عدد</th><th>مبلغ (تومان)</th>@endif
                <th>{{ $two ? 'تغییر / توضیح جمع‌کننده' : 'عملیات' }}</th>
            </tr>
        </thead>
        <tbody>
        @php $prevWh = null; @endphp
        @foreach ($items as $i => $it)
            @php
                $carton = ! $it->isRetail() && $it->per_carton > 1;
                $amount += $it->total;
                $curWh = (int) $it->warehouse_id;
            @endphp
            @if ($multi && $curWh !== $prevWh)
                <tr class="sl-grp"><td colspan="{{ $cols }}">{{ $whName($curWh) }} <small>({{ fa($whCount[$curWh] ?? 0) }} قلم)</small></td></tr>
                @php $prevWh = $curWh; @endphp
            @endif
            <tr>
                <td class="c num">{{ fa($i + 1) }}</td>
                <td class="c"><span class="sl-box"></span></td>
                @if ($two)<td class="c"><span class="sl-box"></span></td>@endif
                @if ($showCode)<td class="c code sl-bcode">{{ $it->code() ?: '—' }}</td>@endif
                <td class="l">{{ $it->name }}@if (! empty($repl))<small style="display:block;font-size:9.5px;font-weight:600">🔁 {{ $it->replaces_item_id && isset($replOf[$it->replaces_item_id]) ? 'جایگزین «'.$replOf[$it->replaces_item_id].'»' : 'کالای جایگزین (انتخاب مشتری)' }}</small>@endif</td>
                <td class="c">
                    @if ($it->isRetail())<span class="sl-type r">خرده</span>
                    @elseif ($carton)<span class="sl-type k">کارتنی</span>
                    @else<span class="sl-type">عددی</span>@endif
                </td>
                <td class="c qtyc">
                    @if ($carton)
                        <b>{{ fa($it->cartons()) }}</b> کارتن<small>{{ fa($it->per_carton) }} تایی = {{ fa($it->units) }} عدد</small>
                    @else
                        <b>{{ fa($it->units) }}</b> عدد
                    @endif
                </td>
                @if ($prices)
                    <td class="num money">{{ money($it->unit_price) }}</td>
                    <td class="num money strong">{{ money($it->total) }}</td>
                @endif
                <td class="op"></td>
            </tr>
        @endforeach
        </tbody>
        <tfoot>
            <tr>
                <td colspan="{{ 4 + ($showCode ? 1 : 0) + ($two ? 1 : 0) }}">جمع حواله: {{ fa($items->count()) }} قلم</td>
                <td class="c qtyc">@if ($cartons)<b>{{ fa(round($cartons, 2)) }}</b> کارتن@endif @if ($cartons && $singles)<br>@endif @if ($singles)<b>{{ fa($singles) }}</b> عدد خرده/عددی@endif</td>
                @if ($prices)<td></td><td class="num money strong">{{ money($amount) }}</td>@endif
                <td></td>
            </tr>
        </tfoot>
    </table>
    @if ($prices)
        <div class="sl-total"><span>جمع مبلغ این حواله:</span> <b>{{ money($amount) }} تومان</b> <small>({{ num_words($amount) }} تومان)</small></div>
    @endif

    @if (! empty($addsInfo))
        <div class="sl-note" style="font-size:13px"><b>📍 جایگاه بقیه بار این سفارش:</b> <b style="font-size:15px">{{ $addsInfo['bays'] ? implode('، ', $addsInfo['bays']) : '—' }}</b><br>این برگه فقط کالاهایی است که مشتری اضافه کرده؛ پس از جمع‌آوری کنار همان بار بگذارید.</div>
    @endif
    @if (! empty($repl))
        <div class="sl-note"><b>توجه:</b> این برگه فقط کالاهای جایگزین‌شده است؛ مشتری آن‌ها را به‌جای کالای ناموجود/کسری انتخاب کرده و مسئول پیگیری تأیید کرده است. بقیه اقلام سفارش در حواله قبلی بوده.</div>
    @endif
    @if ($order->note)
        <div class="sl-note"><b>توضیح مشتری:</b> {{ $order->note }}</div>
    @endif

    @if ($two)
        <div class="sl-note"><b>روال کاغذی:</b> جمع‌کننده هر قلم را برداشت تیک بزند و هر تغییری (کم بود / نبود) را در ستون «تغییر» بنویسد؛ سپس فاکتور را به سرپرست تحویل دهد. سرپرست پس از کنترل، ستون «بررسی» را تیک می‌زند و تغییرات را در اپ ثبت می‌کند.</div>
        <section class="sl-sign">
            <div><span>جمع‌کننده</span></div>
            <div><span>سرپرست (بررسی)</span><b>{{ $keepers }}</b></div>
            <div><span>تحویل‌گیرنده</span></div>
        </section>
    @else
    <section class="sl-sign">
        <div><span>انباردار</span><b>{{ $keepers }}</b></div>
        <div><span>جمع‌آوری و کنترل</span></div>
        <div><span>تحویل‌گیرنده</span></div>
    </section>
    @endif
</article>
