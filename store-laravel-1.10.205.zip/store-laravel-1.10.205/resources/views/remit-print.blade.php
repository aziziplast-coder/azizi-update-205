<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>حواله {{ $r->code }} — {{ $r->title }}</title>
<link rel="stylesheet" href="/fonts/fonts.css">
<style>
*{box-sizing:border-box}body{margin:0;font-family:var(--font,Vazirmatn),Tahoma,sans-serif;background:#eef0f4;color:#14161c;font-size:13px}
.bar{position:sticky;top:0;background:#1f2230;color:#fff;padding:10px 16px;display:flex;gap:10px;align-items:center;z-index:5}
.bar b{flex:1}.bar button{background:#fff;border:0;border-radius:10px;padding:8px 14px;font:inherit;font-weight:700;cursor:pointer}
.page{background:#fff;max-width:210mm;margin:16px auto;padding:14mm;box-shadow:0 10px 30px rgba(0,0,0,.08)}
h1{font-size:20px;margin:0 0 4px}.muted{color:#6b7180}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:6px 18px;margin:14px 0;padding:12px;border:1px solid #e3e5ea;border-radius:12px}
.grid div{display:flex;justify-content:space-between;gap:8px}.grid span{color:#6b7180}.ltr{direction:ltr;unicode-bidi:embed}
table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #e3e5ea;padding:6px 8px;text-align:right}th{background:#f4f5f8;font-size:12px}
td.n{font-weight:800;white-space:nowrap}tfoot td{font-weight:800;background:#f4f5f8}
.rc{page-break-before:always}.rc h2{font-size:15px;margin:0 0 6px}.rc img{display:block;max-width:100%;max-height:235mm;margin:8px auto;border:1px solid #e3e5ea;border-radius:8px}
tr.fc td{background:#e8f8ee}td.fk{text-align:center;font-weight:900;color:#15803d;font-size:16px}td.fk small{display:block;font-size:10px;font-weight:600;color:#3f6b4f}
*{-webkit-print-color-adjust:exact;print-color-adjust:exact}
.ok{display:inline-block;padding:2px 10px;border-radius:99px;background:#dcfce7;color:#166534;font-weight:700}
@media print{body{background:#fff}.bar{display:none}.page{box-shadow:none;margin:0;max-width:none;padding:8mm}@page{size:A4;margin:8mm}}
</style>
</head>
<body>
<div class="bar"><b>حواله {{ fa($r->code) }} — {{ $r->title }}</b><button onclick="print()">⬇ ذخیره PDF / چاپ</button></div>
<div class="page">
    <h1>گزارش واریزهای حواله {{ fa($r->code) }}</h1>
    <div class="muted">{{ $r->title }} — تهیه‌شده در {{ jdate(now(), true) }} @if ($r->status === 'filled')<span class="ok">پر شده — {{ jdate($r->filled_at, true) }}</span>@endif</div>
    <div class="grid">
        <div><span>مبلغ حواله</span><b>{{ money($r->amount) }} تومان</b></div>
        <div><span>جمع واریزهای تأییدشده</span><b>{{ money($rows->sum('amount')) }} تومان</b></div>
        <div><span>صاحب حساب</span><b>{{ $r->holder_name }}</b></div>
        <div><span>تعداد واریز</span><b>{{ fa($rows->count()) }}</b></div>
        <div style="grid-column:1/-1"><span>ردیف‌های سبز با ✔✔ = دریافتشان را کارخانه تأیید کرده است</span></div>
    </div>
    {{-- گزارش برای کارخانه‌دار: فقط شماره سفارش، مبلغ و تصویر واریز (بدون هیچ اطلاعاتی از مشتری) --}}
    <table>
        <thead><tr><th>#</th><th>شماره سفارش</th><th>نام مشتری</th><th>مبلغ واریزی (تومان)</th><th>تأیید کارخانه</th><th>تعداد فیش</th></tr></thead>
        <tbody>
        @foreach ($rows as $i => $p)
            @php($fc = $p->factory_confirmed_at ?? null)
            <tr @class(['fc' => $fc])><td>{{ fa($i + 1) }}</td><td>{{ $p->order_id ? fa($p->order?->number) : 'حضوری' }}</td><td>{{ $p->partyName() }}{{ $p->order?->company ? ' — '.$p->order->company : '' }}</td><td class="n">{{ money($p->amount) }}</td><td class="fk">@if ($fc)✔✔<small>دریافت شد {{ jdate($fc) }}</small>@else<span class="muted" style="font-size:12px;font-weight:400">—</span>@endif</td><td>{{ fa(count($p->files())) }}</td></tr>
        @endforeach
        </tbody>
        <tfoot><tr><td colspan="3">جمع</td><td class="n">{{ money($rows->sum('amount')) }}</td><td class="fk" style="font-size:12px">@php($fcs = $rows->filter(fn ($p) => $p->factory_confirmed_at ?? null))✔ {{ fa($fcs->count()) }} از {{ fa($rows->count()) }}<small>{{ money($fcs->sum('amount')) }} تومان</small></td><td></td></tr></tfoot>
    </table>
</div>
@foreach ($rows as $i => $p)
    @foreach ($p->files() as $fi => $fp)
        <div class="page rc">
            <h2>واریز {{ fa($i + 1) }} — {{ $p->refLabel() }} — {{ $p->partyName() }} — {{ money($p->amount) }} تومان @if (count($p->files()) > 1)(فیش {{ fa($fi + 1) }} از {{ fa(count($p->files())) }})@endif</h2>
            @if (\App\Models\RemitPayment::isPdfPath($fp))
                <p><a href="{{ route('admin.remit.receipt', [$p, 'i' => $fi, 'v' => substr(md5((string) $p->updated_at), 0, 8)]) }}" target="_blank">فیش PDF ↗</a></p>
            @else
                <img src="{{ route('admin.remit.receipt', [$p, 'i' => $fi, 'v' => substr(md5((string) $p->updated_at), 0, 8)]) }}" alt="">
            @endif
        </div>
    @endforeach
@endforeach
{!! \App\Support\Credit::html() !!}
</body>
</html>
