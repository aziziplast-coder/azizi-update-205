<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ $title }}</title>
<meta name="robots" content="noindex">
<link rel="stylesheet" href="/fonts/fonts.css">
<style>
@page { size: A4; margin: 12mm 10mm; }
* { box-sizing: border-box; }
body { margin: 0; font-family: Vazirmatn, Tahoma, sans-serif; color: #1e1c2a; background: #f3f2f7; font-size: 12px; }
.bar { position: sticky; top: 0; z-index: 5; display: flex; flex-wrap: wrap; gap: 10px; align-items: center; justify-content: space-between; padding: 12px 20px; background: #1e1c2a; color: #fff; }
.bar button { font: inherit; font-weight: 800; border: 0; border-radius: 10px; padding: 10px 18px; background: #fff; color: #1e1c2a; cursor: pointer; }
.bar small { opacity: .8; }
.doc { max-width: 210mm; margin: 16px auto; padding: 12mm 10mm; background: #fff; box-shadow: 0 10px 30px rgba(0,0,0,.08); }
.head { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid {{ setting('brand_color', '#4f4a63') }}; padding-bottom: 8px; margin-bottom: 10px; }
.head h1 { font-size: 18px; margin: 0; }
.head img { height: 40px; }
h2 { font-size: 14px; margin: 14px 0 8px; padding: 4px 10px; border-radius: 6px; background: #f3f2f7; break-after: avoid; }
.grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
.item { border: 1px solid #e5e3ec; border-radius: 8px; padding: 6px; break-inside: avoid; display: flex; flex-direction: column; gap: 3px; }
.item img { width: 100%; aspect-ratio: 1; object-fit: cover; border-radius: 6px; background: #f6f5f9; }
.item b { font-size: 11px; line-height: 1.6; }
.item .p { font-weight: 800; font-size: 12px; }
.item .s { color: #6f6b7d; font-size: 10px; }
table { width: 100%; border-collapse: collapse; }
th, td { border: 1px solid #e5e3ec; padding: 4px 6px; text-align: right; vertical-align: middle; }
th { background: #f3f2f7; font-size: 11px; }
td img { width: 38px; height: 38px; object-fit: cover; border-radius: 4px; }
tr { break-inside: avoid; }
.foot { margin-top: 12px; text-align: center; color: #6f6b7d; font-size: 10px; }
@media print { body { background: #fff; } .bar { display: none; } .doc { margin: 0; padding: 0; box-shadow: none; max-width: none; } }
</style>
</head>
<body>
<div class="bar">
    <span><b>{{ fa($count) }} کالا</b> <small>— برای ذخیره PDF دکمه را بزنید و در پنجره چاپ «Save as PDF / ذخیره به‌صورت PDF» را انتخاب کنید.</small></span>
    <button type="button" onclick="window.print()">ذخیره PDF / چاپ</button>
</div>
<div class="doc">
    <div class="head">
        <div><h1>{{ $title }}</h1><small>{{ jdate(now(), true) }}@if (setting('phone')) — تلفن: {{ fa(setting('phone')) }}@endif</small></div>
        @if (setting('logo'))<img src="{{ upload_url(setting('logo')) }}" alt="">@endif
    </div>
    @foreach ($groups as $cat => $items)
        <h2>{{ $cat }} <small>({{ fa($items->count()) }})</small></h2>
        @if ($layout === 'table')
            <table>
                <thead><tr>
                    @if ($show['image'])<th></th>@endif<th>نام کالا</th>@if ($show['barcode'])<th>بارکد</th>@endif<th>در کارتن</th>
                    @if ($show['price'])<th>قیمت هر عدد</th>@endif @if ($show['retail'])<th>قیمت تکی</th>@endif @if ($show['stock'])<th>موجودی</th>@endif
                </tr></thead>
                <tbody>
                @foreach ($items as $p)
                    <tr>
                        @if ($show['image'])<td>@if ($p->image)<img src="{{ thumb($p->image, 160) }}" alt="">@endif</td>@endif
                        <td><b>{{ $p->name }}</b></td>
                        @if ($show['barcode'])<td dir="ltr">{{ $p->barcode }}</td>@endif
                        <td>{{ fa($p->per_carton) }}</td>
                        @if ($show['price'])<td>{{ money($p->price) }}</td>@endif
                        @if ($show['retail'])<td>{{ $p->retailAllowed() ? money($p->unitPrice('retail')) : '—' }}</td>@endif
                        @if ($show['stock'])<td>{{ $p->stock === null ? '—' : fa($p->stock) }}</td>@endif
                    </tr>
                @endforeach
                </tbody>
            </table>
        @else
            <div class="grid">
                @foreach ($items as $p)
                    <div class="item">
                        @if ($show['image'])@if ($p->image)<img src="{{ thumb($p->image, 320) }}" alt="">@else<span style="aspect-ratio:1;background:#f6f5f9;border-radius:6px"></span>@endif @endif
                        <b>{{ $p->name }}</b>
                        @if ($show['price'])<span class="p">{{ money($p->price) }} تومان</span>@endif
                        <span class="s">@if ($p->hasCartons())کارتن {{ fa($p->per_carton) }} عددی @endif @if ($show['retail'] && $p->retailAllowed())· تکی {{ money($p->unitPrice('retail')) }}@endif</span>
                        @if ($show['barcode'] && $p->barcode)<span class="s" dir="ltr">{{ $p->barcode }}</span>@endif
                        @if ($show['stock'] && $p->stock !== null)<span class="s">موجودی: {{ fa($p->stock) }}</span>@endif
                    </div>
                @endforeach
            </div>
        @endif
    @endforeach
    <div class="foot">{{ store_name() }} — {{ url('/') }}</div>
</div>
</body>
</html>
