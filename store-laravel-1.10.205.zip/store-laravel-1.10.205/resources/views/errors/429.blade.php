@extends('errors.layout')
@section('code', '429')
@section('title', 'درخواست‌ها زیاد است')
@section('message', 'چند لحظه صبر کنید و دوباره تلاش کنید.')
