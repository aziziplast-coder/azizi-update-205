<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title')</title>
<link rel="stylesheet" href="/fonts/fonts.css"><link rel="stylesheet" href="/css/app.css">
@php try { $b = installed() ? setting('brand_color', '#4f4a63') : '#4f4a63'; } catch (\Throwable $e) { $b = '#4f4a63'; } @endphp
<style>:root{--brand:{{ $b }}}</style>
</head>
<body style="padding:0">
<div class="closed"><div class="card">
<b style="font-size:56px;color:var(--brand);line-height:1">@yield('code')</b>
<h1>@yield('title')</h1>
<div class="muted" style="margin:0">@yield('message')</div>
<a class="btn" href="/">بازگشت به صفحه اصلی</a>
</div></div>
</body>
</html>
