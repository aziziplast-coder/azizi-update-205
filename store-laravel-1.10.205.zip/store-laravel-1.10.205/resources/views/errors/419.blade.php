@extends('errors.layout')
@section('code', '419')
@section('title', 'صفحه منقضی شد')
@section('message', 'صفحه را دوباره باز کنید و دوباره تلاش کنید.')
