@extends('errors.layout')
@section('code', '503')
@section('title', 'در حال به‌روزرسانی')
@section('message', 'سایت چند دقیقه دیگر در دسترس خواهد بود.')
