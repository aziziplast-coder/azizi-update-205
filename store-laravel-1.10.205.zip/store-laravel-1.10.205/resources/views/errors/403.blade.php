@extends('errors.layout')
@section('code', '403')
@section('title', 'دسترسی ندارید')
@section('message', 'اجازه مشاهده این صفحه را ندارید.')
