@extends('errors.layout')
@section('code', '500')
@section('title', 'خطایی رخ داد')
@section('message')
مشکلی در سرور پیش آمد. لطفاً کمی بعد دوباره تلاش کنید.
@php
    // برای مدیر و کارمندان، متن خطا نمایش داده می‌شود تا عیب‌یابی ساده شود
    $__err = null;
    try {
        $__u = auth()->user();
        if ($__u && method_exists($__u, 'isStaffLike') && $__u->isStaffLike() && isset($exception)) {
            $__e = $exception->getPrevious() ?: $exception;
            $__file = str_replace(base_path().DIRECTORY_SEPARATOR, '', $__e->getFile());
            $__err = class_basename($__e).': '.$__e->getMessage()."\n".$__file.':'.$__e->getLine();
        }
    } catch (\Throwable $__x) {
    }
@endphp
@if ($__err)
    <span style="display:block;margin-top:14px;text-align:right;font-size:13px">متن خطا (فقط برای مدیر نمایش داده می‌شود؛ همین را برای پشتیبانی بفرستید):</span>
    <textarea readonly dir="ltr" onclick="this.select()" style="width:100%;min-height:140px;margin-top:6px;font:12px/1.6 monospace;padding:10px;border-radius:10px;border:1px solid #ddd;background:#fafafa;color:#b91c1c">{{ mb_substr($__err, 0, 3000) }}</textarea>
@endif
@endsection
