@extends('errors.layout')
@section('code', '404')
@section('title', 'صفحه پیدا نشد')
@section('message', 'آدرس اشتباه است یا این صفحه حذف شده است.')
