<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="{{ setting('brand_color', '#4f4a63') }}">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="{{ $cfg['app_name'] }}">
<meta name="format-detection" content="telephone=no">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>{{ $title ?? $cfg['app_name'] }} | {{ store_name() }}</title>
<link rel="manifest" href="{{ route('buyer.manifest') }}">
<link rel="apple-touch-icon" href="{{ route('pwa.buyer_icon', 180) }}">
<link rel="icon" href="{{ route('pwa.buyer_icon', 64) }}">
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}?v={{ config('store.version') }}">
<link rel="stylesheet" href="{{ asset('css/buyer.css') }}?v={{ @filemtime(public_path('css/buyer.css')) }}">
<style>:root{--ac:{{ setting('brand_color', '#4f4a63') }};--font:{!! \App\Support\Fonts::stack() !!}}</style>
</head>
<body class="by {{ $bodyClass ?? '' }}">
@yield('body')
</body>
</html>
