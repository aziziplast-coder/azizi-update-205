@extends('buyer.layout')

@section('body')
<header class="b-top">
    <div class="b-top-row">
        <img src="{{ route('pwa.buyer_icon', 192) }}" alt="" class="b-top-logo">
        <div class="b-brand"><b>{{ $cfg['app_name'] }}</b><small id="bSub">در حال بارگذاری…</small></div>
        <button class="b-ic" id="bRefresh" aria-label="به‌روزرسانی"><svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg></button>
        <button class="b-ic" id="bMenu" aria-label="منو"><svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></svg></button>
    </div>
    <div class="b-search">
        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
        <input id="bQ" type="search" placeholder="جستجوی کارخانه، نام کالا یا کد…" autocomplete="off" enterkeyhint="search">
        <button id="bQx" class="b-qx" hidden aria-label="پاک کردن">×</button>
    </div>
    <nav class="b-tabs" id="bTabs">
        <button data-t="sup" class="on">کارخانه‌ها <em id="tSup">۰</em></button>
        <button data-t="items">کالاها <em id="tItems">۰</em></button>
        <button data-t="cart">سبد خرید <em id="tCart">۰</em></button>
        <button data-t="orders">سفارش‌ها <em id="tOrders">۰</em></button>
    </nav>
</header>

<div class="b-upd" id="bUpd" hidden></div>
<div class="b-filters" id="bFilters">
    <button class="b-chip wch" data-f="w" hidden>⚠️ در اسکن نیامد <em id="fW">۰</em></button>
    <button class="b-chip on" data-f="o">ناموجود</button>
    <button class="b-chip" data-f="l">کم‌موجود</button>
    <button class="b-chip" data-f="sold">فقط فروش‌دار</button>
    <button class="b-chip" data-f="ordered">سفارش‌داده‌شده‌ها</button>
    <button class="b-chip" data-f="site">بدون عکاسی‌نشده‌ها</button>
    <button class="b-chip" data-f="x">حذف‌شده‌ها</button>
    <select id="bSort" class="b-sort">
        <option value="sales">پرفروش‌ترین</option>
        <option value="count">بیشترین ناموجود</option>
        <option value="name">الفبایی</option>
    </select>
</div>

<main id="bMain" class="b-main"><div class="b-load"><i></i><i></i><i></i></div></main>

<section id="bSup" class="b-page" hidden></section>
<section id="bSheet" class="b-sheet" hidden></section>
<div id="bToast" class="b-toast" hidden></div>
<input type="file" id="bFile" accept=".xls,.xlsx,.xlsb,.ods,.csv" multiple hidden>

<script>window.BY = {!! json_encode($kp + ['csrf' => csrf_token(), 'sw' => route('pwa.worker')], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) !!};</script>
<script src="{{ asset('js/buyer.js') }}?v={{ @filemtime(public_path('js/buyer.js')) }}"></script>
@endsection
