<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>سفارش خرید{{ $cfg['report_name'] !== '' ? ' | '.$cfg['report_name'] : '' }}</title>
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}?v={{ config('store.version') }}">
<style>
:root { --ac: {{ setting('brand_color', '#4f4a63') }}; }
* { box-sizing: border-box; }
body { margin: 0; font-family: {!! \App\Support\Fonts::stack() !!}; color: #15171c; background: #e9ebef; font-size: 13px; }
.bar { position: sticky; top: 0; display: flex; gap: 8px; justify-content: center; padding: 10px; background: #fff; box-shadow: 0 2px 10px rgb(0 0 0 / .08); z-index: 5; }
.bar button, .bar a { font: inherit; font-weight: 800; padding: 9px 18px; border-radius: 12px; border: 0; background: var(--ac); color: #fff; cursor: pointer; text-decoration: none; }
.bar a { background: #e5e7eb; color: #111; }
.page { width: 210mm; min-height: 297mm; margin: 14px auto; background: #fff; padding: 12mm 12mm 14mm; box-shadow: 0 4px 20px rgb(0 0 0 / .1); display: flex; flex-direction: column; }
.hd { display: flex; align-items: center; gap: 12px; border-bottom: 3px solid var(--ac); padding-bottom: 10px; }
.hd img { width: 54px; height: 54px; border-radius: 12px; }
.hd .t { flex: 1; }
.hd h1 { margin: 0; font-size: 20px; }
.hd .t div { color: #555; font-size: 12px; }
.hd .m { text-align: left; font-size: 12px; line-height: 1.9; }
.hd .m b { display: inline-block; background: var(--ac); color: #fff; border-radius: 8px; padding: 0 10px; font-size: 14px; }
.sup { margin: 12px 0; display: flex; gap: 10px; flex-wrap: wrap; background: #f5f6f8; border-radius: 12px; padding: 10px 14px; border-right: 5px solid var(--ac); }
.sup b { font-size: 16px; }
.sup span { color: #555; }
table { width: 100%; border-collapse: collapse; }
th { background: var(--ac); color: #fff; font-size: 12px; padding: 7px 6px; }
td { border-bottom: 1px solid #e3e5ea; padding: 6px; vertical-align: middle; }
tr:nth-child(even) td { background: #fafbfc; }
td.n { text-align: center; color: #666; width: 34px; }
td.c { font-family: monospace; direction: ltr; text-align: center; width: 90px; font-size: 13px; }
td.pc { text-align: center; width: 110px; color: #444; }
.rules { margin-top: 8px; font-size: 12px; line-height: 1.9; border: 1px dashed #c9cdd6; border-radius: 10px; padding: 8px 12px; }
.rules b { display: block; font-size: 13px; }
td.q span { font-size: 12px; font-weight: 700; }
td.q { text-align: center; width: 110px; white-space: nowrap; font-size: 17px; font-weight: 900; }
td.i { width: 52px; } td.i img { width: 44px; height: 44px; object-fit: cover; border-radius: 8px; display: block; }
td small { display: block; color: #777; font-size: 11px; }
.ft { margin-top: auto; padding-top: 14px; display: flex; justify-content: space-between; gap: 10px; align-items: flex-end; font-size: 12px; color: #444; }
.tot { font-size: 15px; font-weight: 900; color: #111; background: #f5f6f8; border-radius: 10px; padding: 8px 14px; }
.sign { width: 160px; border-top: 1px dashed #999; text-align: center; padding-top: 4px; color: #777; }
.empty { text-align: center; padding: 60px 20px; color: #666; font-size: 16px; }
@page { size: A4; margin: 0; }
@media print {
    body { background: #fff; }
    .bar { display: none; }
    .page { margin: 0; box-shadow: none; page-break-after: always; break-after: page; }
    .page:last-child { page-break-after: auto; break-after: auto; }
    th { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .hd .m b, .sup, tr:nth-child(even) td, .tot { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
}
</style>
</head>
<body>
<div class="bar"><button onclick="print()">چاپ / ذخیره PDF ({{ fa(count($reports)) }} کارخانه)</button><a href="{{ url('/buyer') }}">بازگشت به اپ</a></div>
@forelse ($reports as $r)
    <section class="page">
        <div class="hd">
            @if ($cfg['report_logo'])<img src="{{ route('pwa.icon', 192) }}" alt="">@endif
            <div class="t"><h1>سفارش خرید{{ $cfg['report_name'] !== '' ? ' — '.$cfg['report_name'] : '' }}</h1><div>{{ $cfg['report_phone'] ? 'تلفن: '.fa($cfg['report_phone']) : '' }}</div></div>
            <div class="m">@if ($r['number'])شماره سفارش: <b>{{ fa($r['number']) }}</b><br>@endif تاریخ: {{ $r['date'] }}</div>
        </div>
        <div class="sup"><span>طرف حساب:</span><b>{{ $r['supplier'] }}</b>@if ($r['contact'])<span>— {{ $r['contact'] }}</span>@endif @if ($r['phone'])<span>— {{ fa($r['phone']) }}</span>@endif</div>
        <table>
            <thead><tr><th>ردیف</th>@if ($cfg['report_images'])<th>تصویر</th>@endif<th style="text-align:right">نام کالا</th><th>تعداد کارتن</th><th>تعداد در کارتن</th></tr></thead>
            <tbody>
            @foreach ($r['lines'] as $i => $l)
                <tr>
                    <td class="n">{{ fa($i + 1) }}</td>
                    @if ($cfg['report_images'])<td class="i">@if (! empty($l['img']))<img src="{{ $l['img'] }}" alt="" loading="eager">@endif</td>@endif
                    <td>{{ \App\Services\Purchasing::cleanName($l['n']) }}@if ($l['note'] ?? '')<small>توضیح: {{ $l['note'] }}</small>@endif</td>
                    <td class="q">{{ fa($l['q']) }} <span>کارتن</span></td>
                    <td class="pc">{{ fa(max(1, (int) ($l['pc'] ?? 1))) }} عددی</td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <div class="ft">
            <div>
                @if ($cfg['report_total'])<div class="tot">جمع: {{ fa(count($r['lines'])) }} قلم — {{ fa($r['total']) }} کارتن</div>@endif
                @if ($r['note'])<p>توضیحات: {{ $r['note'] }}</p>@endif
                @if ($cfg['report_note'])<p>{{ $cfg['report_note'] }}</p>@endif
                @if (trim($cfg['unload_rules']) !== '')<div class="rules"><b>قوانین تخلیه بار</b>{!! nl2br(e(trim($cfg['unload_rules']))) !!}</div>@endif
            </div>
            <div class="sign">مهر و امضا</div>
        </div>
    </section>
@empty
    <div class="page"><div class="empty">هنوز برای هیچ کارخانه‌ای تعداد کارتن وارد نشده است.</div></div>
@endforelse
{!! \App\Support\Credit::html() !!}
<script>if (location.search.indexOf('auto=1') > -1) addEventListener('load', function () { setTimeout(print, 400); });</script>
</body>
</html>
