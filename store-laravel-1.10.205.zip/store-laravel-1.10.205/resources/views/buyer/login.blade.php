@extends('buyer.layout', ['title' => 'ورود', 'bodyClass' => 'by-login'])

@section('body')
<main class="bl">
    <div class="bl-card">
        <img src="{{ route('pwa.buyer_icon', 192) }}" alt="" class="bl-logo">
        <h1>{{ $cfg['app_name'] }}</h1>
        <p>{{ store_name() }}</p>
        @if ($errors->any())<div class="b-alert">{{ $errors->first() }}</div>@endif
        <form method="post" action="{{ url('/buyer/login') }}" class="bl-form">
            @csrf
            <label>شماره موبایل<input name="mobile" inputmode="tel" autocomplete="username" dir="ltr" value="{{ old('mobile') }}" required></label>
            <label>رمز عبور<input type="password" name="password" autocomplete="current-password" dir="ltr" required></label>
            <button class="b-btn b-pri b-lg" type="submit">ورود</button>
        </form>
        <small>دسترسی «خرید و تأمین» را مدیر فروشگاه در بخش «کارمندان» می‌دهد.</small>
    </div>
</main>
@endsection
