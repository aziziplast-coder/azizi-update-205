@extends('advisor.layout')
@section('body')
@php
    $lc = \App\Services\Live::cfg();
    $pushOn = \App\Services\WebPush::enabled();
    $cfg = [
        'state' => route('admin.live.state'), 'send' => route('admin.live.send'), 'close' => route('admin.live.close'), 'assign' => route('admin.live.assign'), 'csrf' => csrf_token(),
        'quick' => array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string) $lc['quick'])))),
        'rules' => \App\Services\Live::RULES, 'sound' => true, 'site' => url('/'), 'settings' => $u->hasPerm('settings') ? url('/admin/settings/live') : null,
        'admin' => $u->isAdmin(), 'voice' => $lc['voice'] ? (int) $lc['voice_sec'] : 0, 'me' => \Illuminate\Support\Str::before(trim((string) $u->name), ' '), 'meId' => $u->id,
        'app' => true, 'badge' => true, 'title' => 'اپ مشاور', 'login' => route('advisor.login'),
    ];
    $live = $u->hasPerm('live') && \App\Services\Live::enabled();
    $isAdv = \App\Services\Advisors::enabled() && \App\Services\Advisors::isAdvisor($u);
    $crm = $isAdv && \App\Services\Crm::ready() && \Illuminate\Support\Facades\DB::table('crm_customers')->exists();
    $adv = ['home' => route('advisor.home'), 'customers' => route('advisor.customers'), 'wallet' => route('advisor.wallet'), 'bank' => route('advisor.bank'), 'calls' => route('advisor.calls'), 'crm' => url('/advisor/api/crm'), 'call' => route('advisor.call'),
        'csrf' => csrf_token(), 'login' => route('advisor.login'), 'site' => rtrim(url('/'), '/'), 'store' => store_name(), 'days' => (int) \App\Services\Advisors::cfg()['link_days']];
@endphp
<div class="av-shell">
    <header class="av-top">
        <span class="av-me">{{ mb_substr(trim((string) $u->name) ?: 'م', 0, 1) }}</span>
        <div><b>{{ $u->name }}</b><small>اپ مشاور · {{ store_name() }}</small></div>
        <span class="av-sp"></span>
        <button type="button" class="av-ib" data-notif hidden>🔔 فعال کردن اعلان</button>
        <button type="button" class="av-ib" data-menu aria-label="منو">☰</button>
    </header>
    <div class="av-body">
        @if ($isAdv)<section class="av-pane" data-pane="home" hidden></section>@endif
        @if ($live)<section class="av-pane chat" data-pane="chat" hidden><div class="ld app" id="ld" data-cfg='@json($cfg, JSON_UNESCAPED_UNICODE | JSON_HEX_APOS)'></div></section>@endif
        @if ($isAdv && $crm)<section class="av-pane" data-pane="calls" hidden></section>@endif
        @if ($isAdv)<section class="av-pane" data-pane="cust" hidden></section><section class="av-pane" data-pane="wallet" hidden></section>@endif
    </div>
    @if ($isAdv)
    <nav class="av-nav">
        <button type="button" data-go-tab="home"><span>🏠</span>خانه</button>
        @if ($live)<button type="button" data-go-tab="chat"><span>💬</span>گفتگو<em data-chat-n hidden></em></button>@endif
        @if ($crm)<button type="button" data-go-tab="calls"><span>📞</span>تماس<em data-calls-n hidden></em></button>@endif
        <button type="button" data-go-tab="cust"><span>👥</span>مشتری‌ها</button>
        <button type="button" data-go-tab="wallet"><span>💰</span>کیف پول</button>
    </nav>
    @else
    <span data-go-tab="chat" hidden></span>
    @endif
</div>
<div class="av-menu" data-sheet hidden>
    <div class="in">
        <button type="button" data-notif2>🔔 اعلان پیام تازه روی این گوشی<small data-nst></small></button>
        <button type="button" data-install hidden>📲 نصب اپ روی گوشی</button>
        @if ($u->isAdmin() || $u->hasPerm('orders'))<a href="{{ url('/admin') }}">🖥 پنل مدیریت</a>@endif
        <form method="post" action="{{ route('advisor.logout') }}" style="margin:0">@csrf<button type="submit">🚪 خروج</button></form>
    </div>
</div>
<div class="av-toast" data-toast></div>
@if ($live)<script src="{{ asset('js/live-desk.js') }}?v={{ config('store.version') }}"></script>@endif
@if ($isAdv)<script src="{{ asset('js/vendor/qrmini.js') }}?v=1"></script>@endif
<script>window.ADV = @json($adv, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);</script>
<script src="{{ asset('js/advisor.js') }}?v={{ config('store.version') }}"></script>
<script>
(function () {
    var PUSH = @json($pushOn ? ['key' => \App\Services\WebPush::keys()['public'], 'url' => route('push.subscribe')] : null), CSRF = @json(csrf_token()), SW = @json(route('pwa.worker'));
    var sheet = document.querySelector('[data-sheet]'), toastEl = document.querySelector('[data-toast]');
    function toast(t) { toastEl.textContent = t; toastEl.classList.add('on'); setTimeout(function () { toastEl.classList.remove('on'); }, 3200); }
    document.querySelector('[data-menu]').addEventListener('click', function () { sheet.hidden = false; st(); });
    sheet.addEventListener('click', function (e) { if (e.target === sheet) sheet.hidden = true; });
    function on() { try { return localStorage.getItem('av-push') === '1'; } catch (e) { return false; } }
    function st() {
        var p = window.Notification ? Notification.permission : 'none';
        document.querySelector('[data-nst]').textContent = p === 'granted' && on() ? 'فعال است ✓ (حتی با اپ بسته)' : p === 'denied' ? 'در تنظیمات مرورگر مسدود شده' : 'خاموش — بزنید تا فعال شود';
        document.querySelector('[data-notif]').hidden = !(window.Notification && p !== 'denied' && !(p === 'granted' && on()));
    }
    function b64u(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; var r = atob(s), a = new Uint8Array(r.length); for (var i = 0; i < r.length; i++) a[i] = r.charCodeAt(i); return a; }
    function enable() {
        if (!window.Notification) { toast('این مرورگر اعلان ندارد؛ با Chrome باز کنید.'); return; }
        Promise.resolve(Notification.requestPermission()).then(function (p) {
            if (p !== 'granted') { toast('برای اعلان، «اجازه» (Allow) را بزنید.'); st(); return; }
            if (!PUSH || !('PushManager' in window)) { toast('اعلان فقط وقتی اپ باز است کار می‌کند (اعلان مرورگر در پنل خاموش است).'); st(); return; }
            navigator.serviceWorker.register(SW, { scope: '/' }).then(function () { return navigator.serviceWorker.ready; }).then(function (reg) {
                return reg.pushManager.getSubscription().then(function (s) { return s || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(PUSH.key) }); });
            }).then(function (sub) {
                var j = sub.toJSON(); j.staff = 0;
                return fetch(PUSH.url, { method: 'POST', body: JSON.stringify(j), credentials: 'same-origin', headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'X-CSRF-TOKEN': CSRF } });
            }).then(function (r) { if (!r.ok) throw 0; try { localStorage.setItem('av-push', '1'); } catch (e) {} toast('اعلان پیام تازه روی این گوشی فعال شد ✓'); st(); })
              .catch(function () { toast('فعال کردن اعلان انجام نشد؛ دوباره امتحان کنید.'); st(); });
        });
    }
    document.querySelector('[data-notif]').addEventListener('click', enable);
    document.querySelector('[data-notif2]').addEventListener('click', function () { sheet.hidden = true; enable(); });
    var inst = null, ib = document.querySelector('[data-install]');
    addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); inst = e; ib.hidden = false; });
    ib.addEventListener('click', function () { if (inst) { inst.prompt(); inst = null; ib.hidden = true; sheet.hidden = true; } });
    st();
})();
</script>
@endsection
