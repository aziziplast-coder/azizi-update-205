@extends('advisor.layout')
@section('body')
<style>
.lg{min-height:100dvh;display:grid;place-items:center;padding:20px;background:radial-gradient(circle at 30% 0%,#8b5cf6 0,#6d5dfc 40%,#312e81 100%)}
.lg form{width:min(380px,100%);background:#fff;color:#0f172a;border-radius:24px;padding:28px 22px;box-shadow:0 30px 80px rgba(0,0,0,.35);display:flex;flex-direction:column;gap:12px}
.lg h1{margin:0;font-size:20px;text-align:center}.lg p{margin:0 0 6px;text-align:center;color:#64748b;font-size:13px}
.lg .ic{width:72px;height:72px;margin:0 auto 6px;border-radius:22px;background:linear-gradient(135deg,#6d5dfc,#8b5cf6);display:grid;place-items:center;font-size:34px}
.lg input{border:1px solid #e2e8f0;border-radius:14px;padding:13px 14px;font:inherit;font-size:15px;outline:0}
.lg input:focus{border-color:#6d5dfc;box-shadow:0 0 0 3px rgba(109,93,252,.15)}
.lg button{border:0;border-radius:14px;padding:14px;background:linear-gradient(135deg,#6d5dfc,#8b5cf6);color:#fff;font:inherit;font-size:15px;font-weight:800;cursor:pointer}
.lg .er{background:#fef2f2;color:#b91c1c;border-radius:12px;padding:10px 12px;font-size:13px}
</style>
<div class="lg">
    <form method="post" action="{{ route('advisor.login') }}">
        @csrf
        <div class="ic">💬</div>
        <h1>اپ مشاور</h1>
        <p>{{ store_name() }} — گفتگوی زنده با مشتری‌ها</p>
        @if ($errors->any())<div class="er">{{ $errors->first() }}</div>@endif
        <input name="mobile" value="{{ old('mobile') }}" placeholder="شماره موبایل" inputmode="tel" dir="ltr" autocomplete="username" required>
        <input name="password" type="password" placeholder="رمز عبور" dir="ltr" autocomplete="current-password" required>
        <button type="submit">ورود</button>
    </form>
</div>
@endsection
