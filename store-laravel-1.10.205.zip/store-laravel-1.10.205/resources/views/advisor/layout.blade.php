<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, viewport-fit=cover, interactive-widget=resizes-content">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#6d5dfc">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="اپ مشاور">
<meta name="format-detection" content="telephone=no">
<title>اپ مشاور | {{ store_name() }}</title>
<link rel="manifest" href="{{ route('advisor.manifest') }}">
<link rel="apple-touch-icon" href="{{ route('pwa.icon', 192) }}">
<link rel="icon" href="{{ route('pwa.icon', 192) }}">
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}?v={{ config('store.version') }}">
<link rel="stylesheet" href="{{ asset('css/live-desk.css') }}?v={{ config('store.version') }}">
<style>
:root{--font:{!! \App\Support\Fonts::stack() !!}}
*{box-sizing:border-box}
html,body{margin:0;height:100%;font-family:var(--font);background:#f6f7fb;color:#334155;-webkit-tap-highlight-color:transparent}
@media (prefers-color-scheme:dark){html,body{background:#0b1020;color:#cbd5e1}}
a{color:inherit}
.av-shell{position:fixed;inset:0;display:flex;flex-direction:column;height:100dvh}
.av-top{flex:none;display:flex;align-items:center;gap:10px;padding:calc(8px + env(safe-area-inset-top)) 14px 8px;background:linear-gradient(135deg,#6d5dfc,#8b5cf6);color:#fff}
.av-top b{font-size:15px}.av-top small{display:block;font-size:11.5px;opacity:.85}
.av-me{width:38px;height:38px;border-radius:50%;background:rgba(255,255,255,.2);display:grid;place-items:center;font-weight:800}
.av-sp{flex:1}
.av-ib{border:0;background:rgba(255,255,255,.16);color:#fff;border-radius:12px;height:38px;padding:0 12px;font:inherit;font-size:13px;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:6px}
.av-ib[hidden]{display:none}
.av-body{flex:1;min-height:0}
.av-menu{position:fixed;inset:0;background:rgba(15,23,42,.45);display:flex;align-items:flex-start;justify-content:flex-start;padding:calc(56px + env(safe-area-inset-top)) 10px;z-index:50}
.av-menu[hidden]{display:none}
.av-menu .in{background:#fff;color:#0f172a;border-radius:16px;min-width:230px;box-shadow:0 20px 50px rgba(0,0,0,.25);overflow:hidden}
@media (prefers-color-scheme:dark){.av-menu .in{background:#121829;color:#f1f5f9}}
.av-menu button,.av-menu a{display:flex;width:100%;gap:10px;align-items:center;border:0;background:none;padding:14px 16px;font:inherit;font-size:14px;text-align:right;color:inherit;cursor:pointer;text-decoration:none;border-bottom:1px solid rgba(127,127,127,.15)}
.av-menu small{display:block;font-size:11.5px;opacity:.65}
.av-pane{height:100%;overflow-y:auto;padding:14px 14px 90px;-webkit-overflow-scrolling:touch}.av-pane.chat{padding:0;overflow:hidden}
.av-pane[hidden]{display:none}
.av-nav{flex:none;display:grid;grid-auto-flow:column;grid-auto-columns:1fr;background:#fff;border-top:1px solid #e7e9f0;padding-bottom:env(safe-area-inset-bottom)}
@media (prefers-color-scheme:dark){.av-nav{background:#121829;border-color:#1f2a40}}
.av-nav button{border:0;background:none;padding:8px 0 9px;font:inherit;font-size:11.5px;font-weight:700;color:#94a3b8;display:flex;flex-direction:column;align-items:center;gap:2px;position:relative;cursor:pointer}
.av-nav button span{font-size:20px;filter:grayscale(1);opacity:.7}.av-nav button.on{color:#6d5dfc}.av-nav button.on span{filter:none;opacity:1}
body[data-tab=chat] .av-pane.chat{padding:0}
.av-hero{background:linear-gradient(135deg,#6d5dfc,#8b5cf6);color:#fff;border-radius:22px;padding:18px;box-shadow:0 14px 34px -12px rgba(109,93,252,.6)}
.av-hero.w{background:linear-gradient(135deg,#059669,#10b981);box-shadow:0 14px 34px -12px rgba(5,150,105,.55)}
.av-hero small{opacity:.85;font-size:12.5px}.av-hero>b{display:block;font-size:28px;font-weight:900;margin:4px 0}.av-hero>b i{font-style:normal;font-size:13px;opacity:.8}
.av-goal{margin:8px 0 4px}.av-gbar{height:8px;border-radius:8px;background:rgba(255,255,255,.25);overflow:hidden}.av-gbar i{display:block;height:100%;background:#fff;border-radius:8px}
.av-goal span{font-size:12px;opacity:.9}
.av-row3{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px}.av-row3 div{background:rgba(255,255,255,.14);border-radius:14px;padding:8px;text-align:center}.av-row3 b{display:block;font-size:15px}.av-row3 small{font-size:11px}
.av-cards{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:12px 0}
.av-c{background:#fff;border:1px solid #e7e9f0;border-radius:18px;padding:12px;cursor:pointer}.av-c small{display:block;font-size:11.5px;color:#64748b}.av-c b{font-size:17px;color:#0f172a}.av-c i{font-style:normal;font-size:11px;color:#16a34a;margin-right:4px}
.av-c.g b{color:#059669}.av-c.o b{color:#d97706}
@media (prefers-color-scheme:dark){.av-c,.av-box,.av-cu,.av-cm{background:#121829;border-color:#1f2a40}.av-c b,.av-box h3,.av-cu b,.av-cm b{color:#f1f5f9}}
.av-box{background:#fff;border:1px solid #e7e9f0;border-radius:20px;padding:14px;margin-bottom:12px}.av-box h3{margin:0 0 10px;font-size:14.5px;color:#0f172a}
.av-link{background:#f1f0ff;color:#4c3fd6;border-radius:12px;padding:10px 12px;font-size:13px;font-weight:700;word-break:break-all;text-align:left}.av-link.sm{font-size:12px;margin-top:6px;display:flex;gap:8px;align-items:center;justify-content:space-between}
.av-link button{border:0;background:#fff;border-radius:8px;padding:4px 8px;cursor:pointer}
.av-btns{display:flex;gap:8px;margin:10px 0;flex-wrap:wrap}.av-btns button{flex:1;border:0;border-radius:12px;padding:10px;background:#6d5dfc;color:#fff;font:inherit;font-weight:700;font-size:13px;cursor:pointer}
.av-btns button+button{background:#eef2ff;color:#4c3fd6}
.av-qr{text-align:center;padding:10px;background:#fff;border-radius:14px}.av-qr small{display:block;font-size:11.5px;color:#64748b}
.av-mk{display:block;font-size:12px;color:#64748b;margin-top:10px}.av-mk input{width:100%;margin-top:4px;border:1px solid #e2e8f0;border-radius:12px;padding:10px;font:inherit;font-size:13px}
.av-hint{font-size:12px;color:#64748b;line-height:1.9;margin:8px 0 0}.av-hint.warn{color:#d97706;font-weight:700}
.av-board{list-style:none;margin:0;padding:0}.av-board li{display:flex;align-items:center;gap:10px;padding:8px 4px;border-bottom:1px dashed #e7e9f0}.av-board li.me{background:#f1f0ff;border-radius:10px}
.av-board span{width:26px;text-align:center}.av-board b{flex:1;font-size:13.5px}.av-board em{font-style:normal;font-size:12.5px;color:#64748b}
.av-t{width:100%;border-collapse:collapse;font-size:12.5px}.av-t th,.av-t td{padding:6px;border-bottom:1px solid #eef0f5;text-align:center}.av-t th{color:#64748b;font-weight:700}
.av-search input{width:100%;border:1px solid #e2e8f0;border-radius:14px;padding:11px 14px;font:inherit;font-size:14px;margin-bottom:8px}
.av-sort{display:flex;gap:6px;margin-bottom:10px;overflow-x:auto}.av-sort button{flex:none;border:1px solid #e2e8f0;background:#fff;border-radius:20px;padding:6px 12px;font:inherit;font-size:12.5px;font-weight:700;color:#64748b}.av-sort button.on{background:#6d5dfc;border-color:#6d5dfc;color:#fff}
.av-list{display:flex;flex-direction:column;gap:8px}.av-empty{text-align:center;color:#94a3b8;padding:30px 10px;line-height:2}
.av-cu,.av-cm{background:#fff;border:1px solid #e7e9f0;border-radius:16px;padding:12px;display:flex;gap:10px;align-items:center}
.av-cu1,.av-cm>div:first-child{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.av-cu b,.av-cm b{font-size:14px;color:#0f172a}.av-cu small,.av-cm small{font-size:12px;color:#64748b}.av-cu small.warn{color:#dc2626;font-weight:700}
.av-cu2{display:flex;gap:6px}.av-cu2 a{width:38px;height:38px;border-radius:12px;background:#f1f5f9;display:grid;place-items:center;text-decoration:none;font-size:17px}.av-cu2 a.call{background:#dcfce7}
.av-am{text-align:left;display:flex;flex-direction:column;align-items:flex-end;gap:3px}.av-am b.neg{color:#dc2626}.av-am b.pos{color:#059669}
.av-am em{font-style:normal;font-size:11px;padding:1px 8px;border-radius:10px;background:#f1f5f9}.av-am em.g{background:#dcfce7;color:#166534}.av-am em.o{background:#fef3c7;color:#92400e}.av-am em.m{opacity:.6}
.av-bank{background:#f8fafc;border-radius:12px;padding:10px 12px;display:flex;flex-direction:column;gap:2px}.av-bank small{font-size:12.5px;color:#475569;text-align:left;font-weight:700;letter-spacing:.5px}
.av-bf summary{cursor:pointer;color:#6d5dfc;font-weight:700;font-size:13px;margin-top:10px}
.av-bf form{display:flex;flex-direction:column;gap:8px;margin-top:8px}.av-bf input{border:1px solid #e2e8f0;border-radius:12px;padding:11px;font:inherit;font-size:14px}.av-bf button{border:0;border-radius:12px;padding:12px;background:#059669;color:#fff;font:inherit;font-weight:800}
@media (min-width:900px){.av-pane:not(.chat){max-width:760px;margin:0 auto}}
.av-nav button em{position:absolute;top:4px;left:calc(50% - 22px);min-width:18px;height:18px;border-radius:9px;background:#ef4444;color:#fff;font-style:normal;font-size:11px;display:grid;place-items:center;padding:0 4px}
.av-nav button em[hidden]{display:none}
.av-kp{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}.av-kp div{background:#fff;border:1px solid #e7e9f0;border-radius:14px;padding:10px;text-align:center}.av-kp b{display:block;font-size:18px;color:#0f172a}.av-kp small{font-size:11px;color:#64748b}
.av-call{background:#fff;border:1px solid #e7e9f0;border-radius:18px;padding:12px;margin-bottom:10px}
.av-call .h{display:flex;align-items:center;gap:8px}.av-call .h b{flex:1;font-size:15px;color:#0f172a}.av-call .seg{font-size:11.5px;font-weight:700;padding:2px 8px;border-radius:10px;background:#f1f5f9}
.av-call .seg.risk{background:#fee2e2;color:#b91c1c}.av-call .seg.lost{background:#e2e8f0;color:#334155}.av-call .seg.gold{background:#fef3c7;color:#92400e}
.av-call p{margin:6px 0;font-size:12.5px;color:#475569;line-height:1.9}.av-call p b{color:#0f172a}
.av-call .acts{display:flex;gap:6px;margin-top:8px}.av-call .acts a,.av-call .acts button{flex:1;border:0;border-radius:12px;padding:10px 6px;font:inherit;font-size:13px;font-weight:800;text-align:center;text-decoration:none;cursor:pointer;background:#f1f5f9;color:#0f172a}
.av-call .acts .c{background:#16a34a;color:#fff}.av-call .acts .r{background:#6d5dfc;color:#fff}
.av-call .more{font-size:12px;color:#475569;background:#f8fafc;border-radius:12px;padding:8px 10px;margin-top:8px;line-height:1.9}
.av-sheet{position:fixed;inset:0;background:rgba(15,23,42,.5);z-index:55;display:flex;align-items:flex-end}.av-sheet[hidden]{display:none}
.av-sheet .in{background:#fff;color:#0f172a;width:100%;border-radius:22px 22px 0 0;padding:16px 16px calc(16px + env(safe-area-inset-bottom));max-height:85vh;overflow:auto}
@media (prefers-color-scheme:dark){.av-sheet .in,.av-call,.av-kp div{background:#121829;color:#f1f5f9;border-color:#1f2a40}.av-call .h b,.av-kp b{color:#f1f5f9}}
.av-sheet h3{margin:0 0 10px;font-size:15px}.av-res{display:grid;grid-template-columns:1fr 1fr;gap:8px}.av-res button{border:1px solid #e2e8f0;background:#fff;border-radius:12px;padding:11px 6px;font:inherit;font-size:13px;font-weight:700;cursor:pointer}
.av-res button.on{background:#6d5dfc;color:#fff;border-color:#6d5dfc}
.av-sheet textarea{width:100%;border:1px solid #e2e8f0;border-radius:12px;padding:10px;font:inherit;margin-top:10px}
.av-when{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.av-when button{border:1px solid #e2e8f0;background:#fff;border-radius:20px;padding:6px 12px;font:inherit;font-size:12.5px}.av-when button.on{background:#0f172a;color:#fff}
.av-save{width:100%;margin-top:12px;border:0;border-radius:14px;padding:13px;background:#16a34a;color:#fff;font:inherit;font-size:15px;font-weight:800}
.av-toast{position:fixed;bottom:calc(20px + env(safe-area-inset-bottom));left:50%;transform:translateX(-50%) translateY(30px);background:#0f172a;color:#fff;padding:10px 16px;border-radius:12px;font-size:13.5px;opacity:0;transition:.25s;z-index:60;pointer-events:none;max-width:90vw;text-align:center}
.av-toast.on{opacity:1;transform:translateX(-50%)}
</style>
</head>
<body>
@yield('body')
<script>if('serviceWorker' in navigator){addEventListener('load',function(){navigator.serviceWorker.register('{{ route('pwa.worker') }}',{scope:'/'}).catch(function(){});});}</script>
</body>
</html>
