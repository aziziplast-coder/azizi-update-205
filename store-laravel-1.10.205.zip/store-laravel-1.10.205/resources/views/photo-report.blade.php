<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>گزارش محصولات برای عکاسی — {{ jdate($at, false) }}</title>
<link rel="stylesheet" href="{{ asset('fonts/fonts.css') }}">
<style>
@page { size: A4 portrait; margin: 12mm 11mm 14mm; }
* { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
html, body { margin: 0; background: #e9e9ec; color: #000; font-family: Vazirmatn, Tahoma, sans-serif; }
.bar { position: sticky; top: 0; z-index: 2; display: flex; gap: 8px; justify-content: center; align-items: center; flex-wrap: wrap; padding: 10px; background: #1f1f24; color: #fff; font-size: 14px; }
.bar button, .bar a { border: 0; border-radius: 10px; padding: 9px 16px; font: inherit; font-weight: 800; cursor: pointer; background: #fff; color: #000; text-decoration: none; }
.bar small { opacity: .75; }
.sheet { width: 210mm; min-height: 297mm; margin: 14px auto; background: #fff; padding: 12mm 11mm; box-shadow: 0 6px 30px rgba(0, 0, 0, .15); }
.hd { display: grid; grid-template-columns: 1fr auto; gap: 10px; align-items: end; padding-bottom: 8px; border-bottom: 2.5px solid #000; }
.hd h1 { margin: 0; font-size: 21px; font-weight: 900; letter-spacing: -.2px; }
.hd .sub { margin-top: 3px; font-size: 12px; color: #333; }
.hd .meta { text-align: left; font-size: 12px; line-height: 1.9; }
.hd .meta b { font-size: 13px; }
.chips { display: flex; gap: 6px; margin: 8px 0 10px; flex-wrap: wrap; font-size: 11.5px; }
.chips span { border: 1px solid #000; border-radius: 6px; padding: 2px 8px; }
table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
thead { display: table-header-group; }
th { background: #000 !important; color: #fff !important; font-weight: 800; padding: 6px 6px; border: 1px solid #000; font-size: 12px; }
td { border: 1px solid #000; padding: 0 6px; height: 9.5mm; vertical-align: middle; }
tr { page-break-inside: avoid; }
tbody tr:nth-child(even) td { background: #f1f1f1 !important; }
td.n { width: 11mm; text-align: center; font-weight: 800; }
td.bc { width: 40mm; direction: ltr; text-align: center; font-family: "Courier New", monospace; font-size: 14px; font-weight: 700; letter-spacing: .5px; }
td.nm { font-weight: 600; line-height: 1.6; padding: 3px 6px; }
td.kp { width: 42mm; }
td.ok { width: 11mm; text-align: center; }
td.ok i { display: inline-block; width: 5mm; height: 5mm; border: 1.4px solid #000; border-radius: 1mm; vertical-align: middle; }
.ft { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10mm; margin-top: 10mm; font-size: 12px; page-break-inside: avoid; }
.ft div { border-top: 1px dashed #000; padding-top: 4px; text-align: center; min-height: 16mm; }
.note { margin-top: 6mm; font-size: 11px; color: #333; line-height: 1.9; }
@media print {
  html, body { background: #fff; }
  .bar { display: none; }
  .sheet { width: auto; min-height: 0; margin: 0; padding: 0; box-shadow: none; }
}
@media (max-width: 230mm) { .sheet { width: auto; margin: 0; padding: 14px; } }
</style>
</head>
<body>
<div class="bar"><button onclick="window.print()">🖨 چاپ / ذخیره PDF</button><a href="{{ route('admin.export.report', 'photo') }}">⬇ اکسل</a><small>در پنجره چاپ، «ذخیره به‌صورت PDF» یا چاپگر را انتخاب کنید (A4 — سیاه‌وسفید)</small></div>
<div class="sheet">
    <div class="hd">
        <div>
            <h1>📷 گزارش محصولات برای عکاسی</h1>
            <div class="sub">{{ store_name() }} — کالاهایی که در فایل «اطلاعات کالا» بودند ولی هنوز در سایت ثبت نشده‌اند؛ از انبار جمع و عکاسی شوند.</div>
        </div>
        <div class="meta">تاریخ: <b>{{ jdate($at, false) }}</b><br>ساعت: {{ fa($at->timezone('Asia/Tehran')->format('H:i')) }}<br>تعداد: <b>{{ fa(count($rows)) }}</b> کالا</div>
    </div>
    <div class="chips">@if ($files)<span>فایل: {{ \Illuminate\Support\Str::limit($files, 80) }}</span>@endif<span>تهیه‌کننده: {{ $by }}</span><span>چاپ: {{ jdate(now(), true) }}</span></div>
    <table>
        <thead><tr><th>ردیف</th><th>بارکد</th><th>نام محصول</th><th>نام انباردار</th><th>✓</th></tr></thead>
        <tbody>
        @foreach ($rows as $i => $r)
            <tr><td class="n">{{ fa($i + 1) }}</td><td class="bc">{{ $r[1] }}</td><td class="nm">{{ $r[2] !== '' ? $r[2] : '—' }}</td><td class="kp"></td><td class="ok"><i></i></td></tr>
        @endforeach
        </tbody>
    </table>
    <div class="note">ستون «✓» را پس از جمع‌آوری کالا از انبار علامت بزنید و نام انباردار را بنویسید. پس از عکاسی، کالا را از بخش «بارگذاری گروهی» یا «کالای جدید» در سایت ثبت کنید.</div>
    <div class="ft"><div>تحویل‌دهنده (انبار)</div><div>عکاس</div><div>تأیید مدیر</div></div>
</div>
</body>
</html>
