@php
    $stats = (array) $s->stats;
    $o = $s->allOptions();
    $counts = \App\Models\SyncItem::query()->where('source_id', $s->id)->selectRaw('COUNT(*) n, SUM(CASE WHEN product_id IS NOT NULL THEN 1 ELSE 0 END) linked, SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) skipped, SUM(CASE WHEN image_status = ? THEN 1 ELSE 0 END) imgfail', ['skipped', 'failed'])->first();
@endphp
    <div @if ($pg['running']) wire:poll.6s="tick" @else wire:poll.30s @endif>
        <x-filament::section>
            <div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between">
                <div style="display:grid;gap:4px">
                    <b style="font-size:16px">
                        @if ($pg['running']) ⏳ {{ $pg['mode'] === 'excel' ? 'در حال اجرای فهرست اکسل' : ($pg['mode'] === 'repair' ? 'در حال تعمیر کالاها' : 'در حال همگام‌سازی') }}
                        @elseif ($s->enabled) ✅ همگام‌سازی خودکار روشن است — هر {{ fa($s->interval) }} دقیقه
                        @else ⏸ همگام‌سازی خودکار خاموش است @endif
                    </b>
                    <span style="opacity:.7;font-size:13px">آخرین اجرا: {{ $s->last_run_at ? jdate($s->last_run_at, true) : 'هنوز اجرا نشده' }}
                        · سود پیش‌فرض {{ fa($o['markup']) }}٪{{ $o['tiers'] ? ' + '.fa(count($o['tiers'])).' بازه پلکانی' : '' }}{{ $o['cat_rules'] ? ' + '.fa(count($o['cat_rules'])).' قانون دسته' : '' }}
                        @if ($o['only_listed']) · فقط فهرست اکسل ({{ fa(count((array) ($o['listed_codes'] ?? []))) }} کد) @endif</span>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                    @if ($pg['running'])
                        <x-filament::button color="danger" icon="heroicon-o-stop" wire:click="stopRun">توقف</x-filament::button>
                    @else
                        <x-filament::button icon="heroicon-o-play" wire:click="startRun(false)" wire:loading.attr="disabled">اجرای الان</x-filament::button>
                        <x-filament::button color="gray" icon="heroicon-o-arrow-path" wire:click="startRun(true)" wire:loading.attr="disabled" tooltip="همه کالاها حتی اگر JSON تغییر نکرده">اجرای کامل</x-filament::button>
                    @endif
                </div>
            </div>
            <div wire:loading wire:target="startRun" style="margin-top:12px;opacity:.7;font-size:13px">در حال شروع…</div>
            @php
                $orph = $pg['running'] ? 0 : \App\Services\Sync\SyncEngine::orphanCount();
            @endphp
            @if ($orph)
                <div style="margin-top:12px;font-size:13px;padding:10px 12px;border-radius:10px;background:rgba(220,38,38,.08);line-height:1.9">
                    🧹 {{ fa($orph) }} کالا از یک همگام‌سازی JSON حذف‌شده قبلی هنوز در سایت مانده است. اگر می‌خواهید همه از نو (همراه تصویر) ساخته شوند،
                    از «بیشتر ← پاک‌سازی کامل و شروع از صفر» با گزینه «کالاهای JSONهای حذف‌شده قبلی هم پاک شوند» استفاده کنید.
                </div>
            @endif
            @if ($pg['running'])
                <div style="margin-top:14px;display:grid;gap:8px">
                    <div class="sy-bar"><i style="width:{{ $pg['pct'] }}%"></i></div>
                    <div style="display:flex;justify-content:space-between;font-size:13px"><span>{{ $pg['label'] }}</span><b>{{ fa($pg['pct']) }}٪</b></div>
                    <div style="font-size:12.5px;opacity:.75">ساخته {{ fa($pg['c']['created'] ?? 0) }} · به‌روز {{ fa($pg['c']['updated'] ?? 0) }} · بدون تغییر {{ fa($pg['c']['unchanged'] ?? 0) }} · ساخته‌نشده {{ fa($pg['c']['skipped'] ?? 0) }} · تغییر قیمت {{ fa($pg['c']['prices'] ?? 0) }} · تصویر {{ fa($pg['c']['images'] ?? 0) }}</div>
                    @if ($pg['eta'])<div style="font-size:12.5px;opacity:.8">⏱ {{ $pg['eta'] }}</div>@endif
                    @if ($pg['worker'] || $pg['cron'])
                        <div style="font-size:12.5px;padding:8px 12px;border-radius:10px;background:rgba(22,163,74,.10);line-height:1.9">
                            ✅ کار در پس‌زمینه سرور در حال انجام است{{ $pg['cron'] ? ' (با کرون هاست)' : '' }}. می‌توانید این صفحه را ببندید یا از پنل خارج شوید؛ تا پایان ادامه پیدا می‌کند.
                            اگر هاست وسط کار راه‌اندازی دوباره شود، با اولین بازدید سایت{{ $pg['cron'] ? ' یا اجرای کرون' : '' }} از آخرین نقطه ذخیره‌شده ادامه می‌یابد.
                        </div>
                    @elseif ($pg['broken'])
                        <div style="font-size:12.5px;padding:8px 12px;border-radius:10px;background:rgba(245,158,11,.12);line-height:1.9">
                            ⚠️ هاست اجازه اجرای پس‌زمینه را نمی‌دهد؛ تا وقتی کرون تنظیم نشده، کار فقط با باز بودن همین صفحه جلو می‌رود.
                        </div>
                    @else
                        <div style="font-size:12.5px;opacity:.7">در حال راه‌اندازی پردازش پس‌زمینه…</div>
                    @endif
                    @if (! $pg['cron'])
                        <details style="font-size:12.5px;padding:8px 12px;border-radius:10px;background:rgb(127 127 127/.08);line-height:1.9">
                            <summary style="cursor:pointer">پیشنهاد: کرون هاست را تنظیم کنید تا حتی بدون هیچ بازدیدی، بعد از قطعی هاست هم خودکار ادامه دهد</summary>
                            <div style="margin-top:6px">با دکمه زیر خودکار تنظیم می‌شود. اگر هاست اجازه ندهد، در cPanel ← Cron Jobs، با زمان‌بندی «هر دقیقه» (* * * * *) این دستور را اضافه کنید:</div>
                            <code dir="ltr" style="display:block;user-select:all;margin:4px 0">{{ \App\Support\CronInstaller::command() }}</code>
                            <x-filament::button size="sm" icon="heroicon-o-clock" wire:click="installCron" wire:loading.attr="disabled">تنظیم خودکار کرون</x-filament::button>
                        </details>
                    @endif
                </div>
            @endif
        </x-filament::section>

        <div class="sy-grid" style="margin-top:14px">
            @foreach ([
                ['کالا در JSON', $counts->n ?? 0], ['ساخته‌شده در سایت', $counts->linked ?? 0], ['ساخته‌نشده', $counts->skipped ?? 0], ['تصویر ناموفق', $counts->imgfail ?? 0],
                ['آخرین اجرا: ساخته', $stats['created'] ?? 0], ['آخرین اجرا: به‌روز', $stats['updated'] ?? 0], ['آخرین اجرا: تغییر قیمت', $stats['prices'] ?? 0], ['آخرین اجرا: تصویر', $stats['images'] ?? 0],
            ] as [$l, $v])
                <div class="sy-card"><small>{{ $l }}</small><b>{{ fa((int) $v) }}</b></div>
            @endforeach
        </div>
    </div>

