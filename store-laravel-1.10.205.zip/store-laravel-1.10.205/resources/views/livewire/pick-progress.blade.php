<div wire:poll.30s.visible style="display:grid;gap:12px;font-size:13.5px">
    @php
        $chip = fn ($bg, $fg) => "display:inline-block;padding:1px 9px;border-radius:999px;font-size:12px;font-weight:700;background:$bg;color:$fg;white-space:nowrap";
        $stC = ['open' => ['#e8effe', '#1d4ed8'], 'saved' => ['#fff4e0', '#b45309'], 'done' => ['#e7f6ee', '#0f7a45']];
    @endphp
    <div style="display:flex;flex-wrap:wrap;gap:8px 18px;align-items:center">
        @if ($order->fulfil_status)
            <span style="{{ $chip(['picking' => '#e8effe', 'picked' => '#e7f6ee', 'replace_review' => '#fff4e0'][$order->fulfil_status] ?? '#eee', ['picking' => '#1d4ed8', 'picked' => '#0f7a45', 'replace_review' => '#b45309'][$order->fulfil_status] ?? '#333') }};font-size:13px">{{ $order->fulfilLabel() }}</span>
        @endif
        @if ($order->referred_at)<span style="opacity:.75">ارجاع: {{ jdate($order->referred_at, true) }}</span>@endif
        @if ($order->picked_at)<span style="opacity:.75">جمع‌آوری: {{ jdate($order->picked_at, true) }}</span>@endif
        @if ($order->deposit_amount)<span>بیعانه: <b>{{ money($order->deposit_amount) }}</b> تومان{{ $order->deposit_ref ? ' — پیگیری '.$order->deposit_ref : '' }}</span>@endif
        @if ($order->replace_until)<span style="color:{{ $order->replace_until->isFuture() ? '#b45309' : '#64748b' }}">مهلت جایگزینی مشتری: {{ jdate($order->replace_until, true) }}{{ $order->replace_until->isPast() ? ' (تمام شده)' : '' }}</span>@endif
    </div>

    <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fill,minmax(260px,1fr))">
    @foreach ($tasks as $t)
        @php
            [$c, $n] = [$t->items->whereNotNull('pick_status')->count(), $t->items->count()];
            $bad = $t->items->whereIn('pick_status', ['short', 'missing']);
            $pct = $n ? round($c / $n * 100) : 0;
        @endphp
        <div style="border:1px solid rgb(127 127 127 / .25);border-radius:12px;padding:10px 12px;display:grid;gap:6px">
            <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
                <b>{{ $t->keeper?->displayName() ?? '⚠️ بدون انباردار' }}</b>
                @if ($t->round > 1)<span style="{{ $chip('#ffe7b3', '#7a4b00') }}">جایگزین — مرحله {{ fa($t->round) }}</span>@endif
                <span style="{{ $chip(...(in_array($t->stage, ['review', 'desk'], true) ? ['#fff4e0', '#b45309'] : ($stC[$t->status] ?? ['#eee', '#333']))) }};margin-inline-start:auto">{{ $t->stage || $t->checked_at ? $t->stageLabel() : ($t->status === 'open' && ! $c ? ($t->seen_at ? 'دیده شد' : 'در انتظار') : $t->statusLabel()) }}</span>
            </div>
            @if ($t->picker || $t->bay || $t->checked_at)
                <div style="display:flex;flex-wrap:wrap;gap:4px 12px;font-size:12.5px;opacity:.85">
                    @if ($t->picker)<span>جمع‌کننده: <b>{{ $t->picker->displayName() }}</b></span>@endif
                    @if ($t->bay)<span>📍 جایگاه بار: <b>{{ $t->bay }}</b></span>@endif
                    @if ($t->checked_at)<span>✓ بررسی: {{ $t->checker?->displayName() }} {{ jdate($t->checked_at, true) }}</span>@endif
                </div>
            @endif
            <div style="height:8px;border-radius:9px;background:rgb(127 127 127 / .18);overflow:hidden"><div style="height:100%;width:{{ $pct }}%;background:#16a34a"></div></div>
            <div style="display:flex;justify-content:space-between;opacity:.8;font-size:12.5px">
                <span>{{ fa($c) }} از {{ fa($n) }} قلم بررسی شد</span>
                <span>{{ $t->done_at ? 'جمع شد '.jdate($t->done_at, true) : ($t->started_at ? 'شروع '.$t->started_at->diffForHumans() : '') }}</span>
            </div>
            @php
                $byWh = $t->items->groupBy(fn ($it) => $it->warehouse?->label() ?? 'بدون انبار');
                $hallKey = \App\Services\Picking::hasDesk() && ! $t->keeper?->isSupervisor() ? \App\Services\Picking::taskHall($t) : null;
            @endphp
            <div style="font-size:12px;opacity:.8">🏬 {{ $byWh->keys()->implode('، ') }}@if ($hallKey) — {{ \App\Services\Picking::hallName($hallKey) }}@endif
                @if ($t->stage === 'desk') — <b style="color:#b45309">در بررسی رومیزی: {{ fa($t->items->whereNotNull('desk_units')->count()) }} از {{ fa($n) }} قلم تأیید شده</b>@endif
                @if ($t->bags || $t->boxes) — 📦 {{ \App\Http\Controllers\DeskController::packLabel($t) }}@endif
            </div>
            <details style="font-size:12.5px" wire:ignore.self wire:key="pkd-{{ $t->id }}">
                <summary style="cursor:pointer;font-weight:700;color:rgb(var(--primary-600))">مشاهده اقلام این حواله ({{ fa($n) }} قلم)</summary>
                @foreach ($byWh as $whName => $its)
                    <div style="margin-top:6px;font-weight:800;opacity:.75">{{ $whName }}</div>
                    <ul style="margin:2px 0 0;padding:0;list-style:none;display:grid;gap:2px">
                        @foreach ($its as $it)
                            @php
                                $want = $it->orderedUnits();
                                [$ic, $col, $txt] = match ($it->pick_status) {
                                    'ok' => ['✓', '#16a34a', 'جمع شد'],
                                    'short' => ['◐', '#b45309', 'کسری: '.$it->unitsLabel((int) $it->picked_units)],
                                    'missing' => ['✗', '#dc2626', 'ناموجود'],
                                    default => ['⏳', '#64748b', 'هنوز جمع نشده'],
                                };
                            @endphp
                            <li style="display:flex;gap:6px;justify-content:space-between;border-bottom:1px dashed rgb(127 127 127 / .2);padding:2px 0">
                                <span><b style="color:{{ $col }}">{{ $ic }}</b> {{ $it->name }} <span style="opacity:.6">— {{ $it->unitsLabel($want) }}</span></span>
                                <span style="color:{{ $col }};white-space:nowrap">{{ $txt }}@if ($t->stage === 'desk' && $it->desk_units !== null) · بررسی: {{ fa((int) $it->desk_units) }}@endif</span>
                            </li>
                        @endforeach
                    </ul>
                @endforeach
            </details>
            @if ($bad->isNotEmpty())
                <ul style="margin:0;padding:0;list-style:none;display:grid;gap:3px;font-size:12.5px">
                    @foreach ($bad as $it)
                        <li style="color:{{ $it->pick_status === 'missing' ? '#dc2626' : '#b45309' }}">{{ $it->pick_status === 'missing' ? '✗ ناموجود' : '◐ کسری' }}: {{ $it->name }} — {{ $it->unitsLabel((int) $it->picked_units) }} از {{ $it->unitsLabel($it->orderedUnits()) }}{{ $it->pick_note ? ' — '.$it->pick_note : '' }}</li>
                    @endforeach
                </ul>
            @endif
            @if ($canEdit)
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                    @if ((! $t->keeper_id || ! $t->keeper?->is_active) && $keepers->isNotEmpty() && ! \App\Services\Picking::deskChecked($t))
                        <select wire:change="assign({{ $t->id }}, $event.target.value)" style="border-radius:8px;padding:4px 8px;font-size:12.5px;background:transparent;border:1px solid rgb(127 127 127 / .35)">
                            <option value="">{{ $t->keeper_id ? '⚠ انباردار غیرفعال است — سپردن به…' : 'سپردن به انباردار…' }}</option>
                            @foreach ($keepers as $k)<option value="{{ $k->id }}">{{ $k->displayName() }}</option>@endforeach
                        </select>
                    @endif
                    @if ($t->status === 'done')
                        @php($onDesk = \App\Services\Picking::deskChecked($t))
                        <button type="button" wire:click="reopen({{ $t->id }})" wire:confirm="{{ $onDesk ? 'بررسی رومیزی این سالن دوباره باز شود تا بررسی‌کننده اصلاح و دوباره تأیید کند؟' : 'حواله دوباره باز شود تا انباردار اصلاح کند؟' }}" style="font-size:12.5px;text-decoration:underline;opacity:.8">{{ $onDesk ? 'بازگشایی بررسی رومیزی برای اصلاح' : 'بازگشایی برای اصلاح' }}</button>
                    @endif
                </div>
            @endif
        </div>
    @endforeach
    </div>

    @if ($reps->isNotEmpty())
        <div style="border-top:1px dashed rgb(127 127 127 / .35);padding-top:10px;display:grid;gap:4px">
            <b>جایگزین‌های انتخابی مشتری</b>
            @foreach ($reps as $r)
                <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                    <span style="{{ $chip(...(['draft' => ['#f1f5f9', '#475569'], 'submitted' => ['#fff4e0', '#b45309'], 'approved' => ['#e7f6ee', '#0f7a45'], 'rejected' => ['#fdecea', '#b91c1c']][$r->status])) }}">{{ ['draft' => 'پیش‌نویس مشتری', 'submitted' => 'در انتظار تأیید', 'approved' => 'تأیید شد', 'rejected' => 'رد شد'][$r->status] }}</span>
                    <span><b>{{ $r->name }}</b> — {{ $r->qtyLabel() }} — {{ money($r->total()) }} ت</span>
                    @if ($r->replaces)<span style="opacity:.7">به‌جای «{{ $r->replaces->name }}»</span>@endif
                </div>
            @endforeach
        </div>
    @endif
</div>
