<?php

return [
    'version' => '1.0.0',
    'brand_default' => 'مهدوب',
];
