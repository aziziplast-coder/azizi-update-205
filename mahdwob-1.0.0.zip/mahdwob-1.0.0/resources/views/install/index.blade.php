<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<title>نصب مهدوب</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;800&display=swap">
<link rel="stylesheet" href="{{ asset('css/admin.css') }}">
</head>
<body>
<main class="box" style="margin-top:30px">
  <h1>نصب فروشگاه لایسنس مهدوب</h1>
  @if(session('err'))<div class="alert err">{{ session('err') }}</div>@endif
  @if($errors->any())<div class="alert err">چند فیلد نیاز به اصلاح دارد.</div>@endif

  <div class="card">
    <h2>۱. پیش‌نیازها</h2>
    <table class="req">
      @foreach($checks as $c)
        <tr>
          <td>{{ $c['label'] }}</td>
          <td class="{{ $c['ok'] ? 'yes' : ($c['required'] ? 'no' : 'opt') }}">{{ $c['ok'] ? 'تأیید' : ($c['required'] ? 'ناموفق' : 'هشدار') }}</td>
        </tr>
      @endforeach
    </table>
    @if($blocked)<div class="alert err">موارد ناموفق را درست کنید و صفحه را تازه کنید.</div>@endif
  </div>

  <form method="POST" action="{{ route('install.run') }}">
    @csrf
    <div class="card">
      <h2>۲. دیتابیس</h2>
      <label class="check"><input type="radio" name="db_mode" value="sqlite" @checked(old('db_mode', 'sqlite') === 'sqlite')><span><b>SQLite</b> — ساده‌ترین؛ بدون MySQL</span></label>
      <label class="check"><input type="radio" name="db_mode" value="manual" @checked(old('db_mode') === 'manual')><span><b>MySQL دستی</b></span></label>
      <div id="manual" @if(old('db_mode') !== 'manual') hidden @endif>
        <div class="grid2">
          <div class="field"><label>هاست</label><input class="ltr" type="text" name="db_host" value="{{ old('db_host', '127.0.0.1') }}"></div>
          <div class="field"><label>پورت</label><input class="ltr" type="number" name="db_port" value="{{ old('db_port', 3306) }}"></div>
          <div class="field"><label>نام دیتابیس</label><input class="ltr" type="text" name="db_name" value="{{ old('db_name') }}"></div>
          <div class="field"><label>کاربر</label><input class="ltr" type="text" name="db_user" value="{{ old('db_user') }}"></div>
          <div class="field"><label>رمز</label><input class="ltr" type="password" name="db_pass"></div>
        </div>
        <p class="muted" style="margin-top:10px">اگر جدول‌ها ساخته نشد، فایل <span class="ltr">database/mahdwob-mysql.sql</span> را در phpMyAdmin ایمپورت کنید و دوباره نصب را بزنید.</p>
      </div>
    </div>

    <div class="card">
      <h2>۳. برند و کارت‌به‌کارت</h2>
      <div class="grid2">
        <div class="field"><label>نام برند</label><input type="text" name="brand" value="{{ old('brand', 'مهدوب') }}" required></div>
        <div class="field"><label>صاحب کارت</label><input type="text" name="card_holder" value="{{ old('card_holder', 'مهدوب') }}" required></div>
        <div class="field"><label>شماره کارت</label><input class="ltr" type="text" name="card_number" value="{{ old('card_number', '6037-9971-1234-5678') }}" required></div>
      </div>
    </div>

    <div class="card">
      <h2>۴. مدیر</h2>
      <div class="grid2">
        <div class="field"><label>نام</label><input type="text" name="admin_name" value="{{ old('admin_name') }}" required></div>
        <div class="field"><label>ایمیل</label><input class="ltr" type="email" name="admin_email" value="{{ old('admin_email') }}" required></div>
        <div class="field"><label>رمز عبور</label><input class="ltr" type="password" name="admin_password" required></div>
        <div class="field"><label>تکرار رمز</label><input class="ltr" type="password" name="admin_password_confirmation" required></div>
      </div>
    </div>

    <button class="btn" type="submit" @disabled($blocked)>نصب مهدوب</button>
  </form>
</main>
<script>
document.querySelectorAll('input[name=db_mode]').forEach(function(r){
  r.addEventListener('change', function(){
    document.getElementById('manual').hidden = r.value !== 'manual' || !r.checked;
    if(r.checked) document.getElementById('manual').hidden = r.value !== 'manual';
  });
});
</script>
</body>
</html>
