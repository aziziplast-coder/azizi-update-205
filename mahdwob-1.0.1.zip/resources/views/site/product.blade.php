<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{{ $product->title }} | {{ $brand }}</title>
<meta name="description" content="{{ $product->summary }}">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('css/site.css') }}">
</head>
<body>
<div class="atmos"></div><div class="grain"></div>
<header class="nav">
  <a class="brand" href="{{ route('home') }}">
    <img src="{{ asset('logo-mahdwob.jpg') }}" alt="{{ $brand }}">
    <span><b>{{ $brand }}</b></span>
  </a>
  <nav class="nav-links">
    <a href="{{ route('home') }}">خانه</a>
    <a class="btn sm" href="{{ route('order.create', ['product' => $product->slug]) }}">ثبت سفارش</a>
  </nav>
</header>

<div class="p-hero">
  <div class="visual"><div class="fill"></div></div>
  <div class="info">
    <div class="meta"><b>{{ $product->typeLabel() }}</b><span>{{ $product->categoryLabel() }}</span>@if($product->needs_domain)<span>لایسنس یک دامنه</span>@endif</div>
    <h1>{{ $product->title }}</h1>
    <p class="hero-lead" style="max-width:none">{{ $product->description ?: $product->summary }}</p>
    <ul class="feats">
      @foreach($product->featureList() as $f)
        <li>{{ $f }}</li>
      @endforeach
    </ul>
    <div class="buy-box">
      <div class="price">{!! \App\Support\Fa::money($product->price) !!}</div>
      <a class="btn block" href="{{ route('order.create', ['product' => $product->slug]) }}">ثبت سفارش و دریافت شماره کارت</a>
      <p class="note">پس از ثبت سفارش، شماره کارت برای واریز نمایش داده می‌شود. فعال‌سازی پس از تأیید واریز انجام می‌شود.</p>
    </div>
  </div>
</div>
</body>
</html>
