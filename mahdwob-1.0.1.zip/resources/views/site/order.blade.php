<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>ثبت سفارش | {{ $brand }}</title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('css/site.css') }}">
</head>
<body>
<div class="atmos"></div><div class="grain"></div>
<header class="nav">
  <a class="brand" href="{{ route('home') }}">
    <img src="{{ asset('logo-mahdwob.jpg') }}" alt="{{ $brand }}">
    <span><b>{{ $brand }}</b></span>
  </a>
  <nav class="nav-links">
    <a href="{{ route('home') }}">خانه</a>
  </nav>
</header>

@if(session('err'))
  <div class="wrap" style="padding-top:12px"><div class="panel" style="border-color:#c45c26;color:#8a3b10">{{ session('err') }}</div></div>
@endif

<div class="order-wrap">
  <div class="panel">
    <h1>ثبت سفارش</h1>
    <p class="lead">محصول و مشخصات را وارد کنید. بعد از ثبت، شماره کارت نمایش داده می‌شود.</p>
    @if($order)
      <div class="summary">
        <div class="line"><span>کد سفارش</span><b dir="ltr">{{ $order->code }}</b></div>
        <div class="line"><span>محصول</span><b>{{ $order->product->title }}</b></div>
        <div class="line"><span>وضعیت</span><b>{{ $order->statusLabel() }}</b></div>
        @if($order->domain)<div class="line"><span>دامنه</span><b dir="ltr">{{ $order->domain }}</b></div>@endif
        @if($order->license_key)<div class="line"><span>لایسنس</span><b dir="ltr">{{ $order->license_key }}</b></div>@endif
      </div>
      <p class="note" style="margin-top:16px">اگر سفارش جدید می‌خواهید، <a href="{{ route('order.create') }}"><u>اینجا</u></a> ثبت کنید.</p>
    @else
      <form class="form" method="POST" action="{{ route('order.store') }}">
        @csrf
        <label>محصول
          <select name="product_id" required>
            @foreach($products as $p)
              <option value="{{ $p->id }}" @selected(old('product_id', $selected?->id) == $p->id)>
                {{ $p->title }} — {{ \App\Support\Fa::money($p->price) }}
              </option>
            @endforeach
          </select>
        </label>
        <label>نام و نام خانوادگی
          <input name="customer_name" value="{{ old('customer_name') }}" required>
          @error('customer_name')<span class="note" style="color:#8a3b10">{{ $message }}</span>@enderror
        </label>
        <label>موبایل
          <input name="customer_phone" value="{{ old('customer_phone') }}" required inputmode="tel" dir="ltr" style="text-align:left">
          @error('customer_phone')<span class="note" style="color:#8a3b10">{{ $message }}</span>@enderror
        </label>
        <label>ایمیل (اختیاری)
          <input name="customer_email" type="email" value="{{ old('customer_email') }}" dir="ltr" style="text-align:left">
        </label>
        <label>دامنه نصب (برای اسکریپت)
          <input name="domain" value="{{ old('domain') }}" placeholder="example.ir" dir="ltr" style="text-align:left">
        </label>
        <label>توضیح سفارش
          <textarea name="note" placeholder="اگر افزونه است، بگویید روی کدام اسکریپت نصب می‌شود.">{{ old('note') }}</textarea>
        </label>
        <button class="btn block" type="submit">ادامه و نمایش شماره کارت</button>
      </form>
    @endif
  </div>

  <div class="panel">
    <h2>پرداخت کارت‌به‌کارت</h2>
    @if($order)
      <span class="status {{ $order->status === 'activated' ? 'ok' : '' }}">{{ $order->statusLabel() }}</span>
      <p class="lead">مبلغ را به کارت زیر واریز کنید. پس از تأیید، فعال‌سازی انجام می‌شود.</p>
      <div class="amount">{!! \App\Support\Fa::money($order->amount) !!}</div>
      <div class="card-box">
        <div class="lab">شماره کارت</div>
        <div class="num" id="card-num">{{ $card['number'] }}</div>
        <div class="name">به نام: {{ $card['holder'] }}</div>
        <button type="button" class="btn sm" id="copy-card" style="justify-self:start;margin-top:6px" data-copy="{{ preg_replace('/\D+/', '', $card['number']) }}">کپی شماره کارت</button>
      </div>
      <ol class="steps-mini">
        <li class="done">ثبت مشخصات سفارش</li>
        <li class="{{ in_array($order->status, ['awaiting_payment'], true) ? 'on' : 'done' }}">واریز به شماره کارت</li>
        <li class="{{ $order->status === 'paid' ? 'on' : ($order->status === 'activated' ? 'done' : '') }}">بررسی و فعال‌سازی توسط مهدوب</li>
        <li class="{{ $order->status === 'activated' ? 'done' : '' }}">دریافت لایسنس / فایل</li>
      </ol>
      <p class="note">بعد از واریز، رسید را ارسال کنید تا سفارش بررسی شود. این صفحه را با کد سفارش نگه دارید.</p>
    @else
      <p class="lead">هنوز سفارشی ثبت نشده. فرم را کامل کنید.</p>
      <ol class="steps-mini">
        <li class="on">ثبت مشخصات سفارش</li>
        <li>واریز به شماره کارت</li>
        <li>بررسی و فعال‌سازی توسط مهدوب</li>
        <li>دریافت لایسنس / فایل</li>
      </ol>
    @endif
  </div>
</div>
<div class="toast" id="toast"></div>
<script src="{{ asset('js/site.js') }}"></script>
</body>
</html>
