<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{{ $brand }} | فروش اسکریپت و افزونه با لایسنس</title>
<meta name="description" content="اسکریپت فروشگاهی و شرکتی با لایسنس دامنه، افزونه‌های لاراولی، پرداخت کارت‌به‌کارت.">
<meta name="theme-color" content="#0E3F8C">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('css/site.css') }}">
</head>
<body>
<div class="atmos"></div><div class="grain"></div>
<header class="nav">
  <a class="brand" href="{{ route('home') }}">
    <img src="{{ asset('logo-mahdwob.jpg') }}" alt="{{ $brand }}">
    <span><b>{{ $brand }}</b><small>{{ $tagline }}</small></span>
  </a>
  <nav class="nav-links">
    <a href="#products" class="active">محصولات</a>
    <a href="#plugins">افزونه‌ها</a>
    <a href="#process">مراحل خرید</a>
    <a class="btn sm" href="{{ route('order.create') }}">ثبت سفارش</a>
  </nav>
</header>

<main>
  <section class="hero">
    <div class="hero-visual" aria-hidden="true"><div class="plane"></div><div class="ring"></div></div>
    <div class="hero-copy">
      <p class="brand-hero"><span>MAHDWOB</span>{{ $brand }}</p>
      <h1>اسکریپت فروشگاهی و شرکتی با لایسنس، آماده نصب روی هاست شما</h1>
      <p class="hero-lead">اسکریپت را بخرید، روی دامنه خودتان اجرا کنید. افزونه‌های لاراولی را هم جدا سفارش دهید. پرداخت کارت‌به‌کارت؛ فعال‌سازی دستی بعد از واریز.</p>
      <div class="cta-row">
        <a class="btn" href="#products">مشاهده محصولات</a>
        <a class="btn ghost" href="{{ route('order.create') }}">ثبت سفارش</a>
      </div>
    </div>
    <aside class="hero-aside">
      <div class="license-card">
        <div class="top"><span class="live">لایسنس دامنه</span><span>بدون درگاه</span></div>
        <div class="mock">
          <div class="row"><span>domain</span><span>shop.example.ir</span></div>
          <div class="row"><span>license</span><span>MHD-8F2C-91AA</span></div>
          <div class="bar"><i></i></div>
          <div class="chips"><span>فروشگاهی</span><span>Laravel</span><span>فعال</span></div>
        </div>
        <p class="foot">بعد از واریز، لایسنس روی <b>دامنه شما</b> فعال می‌شود.</p>
      </div>
    </aside>
  </section>

  <section class="products" id="products">
    <div class="wrap">
      <div class="sec-head">
        <span class="kicker">SCRIPTS</span>
        <h2>اسکریپت‌ها</h2>
        <p>هر اسکریپت با لایسنس تک‌دامنه ارائه می‌شود و روی هاست معمولی قابل نصب است.</p>
      </div>
      @forelse($scripts as $p)
        <article class="product reveal">
          <div class="p-media"><div class="fill"></div><span class="badge">{{ $p->typeLabel() }}</span></div>
          <div class="p-body">
            <div class="meta"><b>{{ $p->categoryLabel() }}</b><span>Laravel</span><span>لایسنس دامنه</span></div>
            <h3>{{ $p->title }}</h3>
            <p>{{ $p->summary }}</p>
            <div class="price">{!! \App\Support\Fa::money($p->price) !!} <small>لایسنس یک دامنه</small></div>
            <div class="actions">
              <a class="btn sm" href="{{ route('product.show', $p->slug) }}">جزئیات و خرید</a>
              <a class="btn sm ghost" href="{{ route('order.create', ['product' => $p->slug]) }}">ثبت سفارش</a>
            </div>
          </div>
        </article>
      @empty
        <p class="note">هنوز اسکریپتی منتشر نشده است.</p>
      @endforelse
    </div>
  </section>

  <section id="plugins">
    <div class="wrap">
      <div class="sec-head">
        <span class="kicker">PLUGINS</span>
        <h2>افزونه‌های لاراولی</h2>
        <p>ماژول‌های قابل اتصال به اسکریپت‌های مهدوب.</p>
      </div>
      <div class="plugin-list">
        @forelse($plugins as $p)
          <div class="plugin">
            <div>
              <h3>{{ $p->title }}</h3>
              <p>{{ $p->summary }}</p>
            </div>
            <div style="text-align:left">
              <div class="price" style="font-size:18px">{!! \App\Support\Fa::money($p->price) !!}</div>
              <a class="btn sm" href="{{ route('order.create', ['product' => $p->slug]) }}">سفارش</a>
            </div>
          </div>
        @empty
          <p class="note">هنوز افزونه‌ای منتشر نشده است.</p>
        @endforelse
      </div>
    </div>
  </section>

  <section id="process" style="background:linear-gradient(180deg,var(--bg-2),var(--bg))">
    <div class="wrap">
      <div class="sec-head">
        <span class="kicker">PROCESS</span>
        <h2>چطور خرید می‌کنید؟</h2>
        <p>بدون درگاه پرداخت — کارت‌به‌کارت و فعال‌سازی دستی.</p>
      </div>
      <ol class="steps">
        <li class="reveal"><h3>انتخاب محصول</h3><p>اسکریپت یا افزونه را انتخاب کنید.</p></li>
        <li class="reveal"><h3>ثبت سفارش</h3><p>دامنه و مشخصات را وارد کنید.</p></li>
        <li class="reveal"><h3>واریز کارت‌به‌کارت</h3><p>مبلغ را به شماره کارت نمایش‌داده‌شده واریز کنید.</p></li>
        <li class="reveal"><h3>فعال‌سازی</h3><p>پس از تأیید، لایسنس و فایل برایتان فعال می‌شود.</p></li>
      </ol>
    </div>
  </section>
</main>

<footer class="wrap" style="width:min(1160px,100% - 40px)">
  <span>© {{ $brand }} — {{ $tagline }}</span>
  <span>فروش اسکریپت و افزونه با لایسنس · کارت‌به‌کارت</span>
</footer>
<script src="{{ asset('js/site.js') }}"></script>
</body>
</html>
