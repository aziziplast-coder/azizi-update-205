<div class="view"><div class="sw" style="--p:{{ $w->color }}">@include('site.mocks.'.$w->kind)</div></div>
