@extends('layouts.admin')
@section('title', 'سفارش '.$order->code)
@section('content')
<div class="head"><h1>سفارش <span class="ltr">{{ $order->code }}</span></h1></div>
<div class="grid2">
  <div class="card">
    <h2>اطلاعات</h2>
    <p><b>محصول:</b> {{ $order->product->title }}</p>
    <p><b>مشتری:</b> {{ $order->customer_name }}</p>
    <p><b>موبایل:</b> <span class="ltr">{{ $order->customer_phone }}</span></p>
    @if($order->customer_email)<p><b>ایمیل:</b> <span class="ltr">{{ $order->customer_email }}</span></p>@endif
    @if($order->domain)<p><b>دامنه:</b> <span class="ltr">{{ $order->domain }}</span></p>@endif
    <p><b>مبلغ:</b> {{ \App\Support\Fa::money($order->amount) }}</p>
    <p><b>وضعیت:</b> {{ $order->statusLabel() }}</p>
    @if($order->note)<p><b>توضیح مشتری:</b> {{ $order->note }}</p>@endif
    @if($order->license_key)<p><b>لایسنس:</b> <span class="ltr">{{ $order->license_key }}</span></p>@endif
  </div>
  <div class="card">
    <h2>فعال‌سازی</h2>
    <form method="POST" action="{{ route('admin.orders.update', $order) }}">
      @csrf
      <div class="field">
        <label>وضعیت</label>
        <select name="status">
          <option value="awaiting_payment" @selected($order->status==='awaiting_payment')>در انتظار واریز</option>
          <option value="paid" @selected($order->status==='paid')>واریز شده</option>
          <option value="activated" @selected($order->status==='activated')>فعال‌شده</option>
          <option value="cancelled" @selected($order->status==='cancelled')>لغو شده</option>
        </select>
      </div>
      <div class="field"><label>کلید لایسنس (خالی = تولید خودکار هنگام فعال‌سازی)</label><input class="ltr" name="license_key" value="{{ old('license_key', $order->license_key) }}"></div>
      <div class="field"><label>یادداشت ادمین</label><textarea name="admin_note" rows="3">{{ old('admin_note', $order->admin_note) }}</textarea></div>
      <button class="btn" type="submit">ذخیره</button>
    </form>
    <form method="POST" action="{{ route('admin.orders.activate', $order) }}" style="margin-top:12px" onsubmit="return confirm('فعال و لایسنس صادر شود؟')">
      @csrf
      <button class="btn" type="submit">فعال‌سازی سریع + صدور لایسنس</button>
    </form>
  </div>
</div>
@endsection
