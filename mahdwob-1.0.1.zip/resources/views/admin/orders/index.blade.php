@extends('layouts.admin')
@section('title', 'سفارش‌ها')
@section('content')
<div class="head">
  <h1>سفارش‌ها</h1>
  <div>
    <a href="{{ route('admin.orders.index') }}">همه</a> ·
    <a href="{{ route('admin.orders.index', ['status' => 'awaiting_payment']) }}">در انتظار واریز</a> ·
    <a href="{{ route('admin.orders.index', ['status' => 'paid']) }}">واریز شده</a> ·
    <a href="{{ route('admin.orders.index', ['status' => 'activated']) }}">فعال‌شده</a>
  </div>
</div>
<table>
  <thead><tr><th>کد</th><th>محصول</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th><th></th></tr></thead>
  <tbody>
  @forelse($orders as $o)
    <tr>
      <td class="ltr">{{ $o->code }}</td>
      <td>{{ $o->product?->title }}</td>
      <td>{{ $o->customer_name }}<br><span class="muted ltr">{{ $o->customer_phone }}</span></td>
      <td>{{ \App\Support\Fa::money($o->amount) }}</td>
      <td>{{ $o->statusLabel() }}</td>
      <td><a href="{{ route('admin.orders.show', $o) }}">مدیریت</a></td>
    </tr>
  @empty
    <tr><td colspan="6">سفارشی نیست.</td></tr>
  @endforelse
  </tbody>
</table>
@endsection
