@extends('layouts.admin')
@section('title', $product->exists ? 'ویرایش محصول' : 'محصول جدید')
@section('content')
<div class="head"><h1>{{ $product->exists ? 'ویرایش محصول' : 'محصول جدید' }}</h1></div>
<form method="POST" action="{{ $product->exists ? route('admin.products.update', $product) : route('admin.products.store') }}" class="card">
  @csrf
  @if($product->exists) @method('PUT') @endif
  <div class="grid2">
    <div class="field"><label>عنوان</label><input name="title" value="{{ old('title', $product->title) }}" required>@error('title')<span class="err">{{ $message }}</span>@enderror</div>
    <div class="field"><label>اسلاگ (اختیاری)</label><input class="ltr" name="slug" value="{{ old('slug', $product->slug) }}"></div>
    <div class="field"><label>نوع</label>
      <select name="type">
        <option value="script" @selected(old('type', $product->type)==='script')>اسکریپت</option>
        <option value="plugin" @selected(old('type', $product->type)==='plugin')>افزونه</option>
      </select>
    </div>
    <div class="field"><label>دسته</label>
      <select name="category">
        <option value="shop" @selected(old('category', $product->category)==='shop')>فروشگاهی</option>
        <option value="corporate" @selected(old('category', $product->category)==='corporate')>شرکتی</option>
        <option value="other" @selected(old('category', $product->category)==='other')>سایر</option>
      </select>
    </div>
    <div class="field"><label>قیمت (تومان)</label><input class="ltr" type="number" name="price" value="{{ old('price', $product->price) }}" required></div>
    <div class="field"><label>ترتیب</label><input class="ltr" type="number" name="sort_order" value="{{ old('sort_order', $product->sort_order) }}"></div>
  </div>
  <div class="field"><label>خلاصه</label><textarea name="summary" rows="2">{{ old('summary', $product->summary) }}</textarea></div>
  <div class="field"><label>توضیح</label><textarea name="description" rows="4">{{ old('description', $product->description) }}</textarea></div>
  <div class="field"><label>ویژگی‌ها (هر خط یک مورد)</label><textarea name="features" rows="5">{{ old('features', $product->features) }}</textarea></div>
  <label class="check"><input type="checkbox" name="needs_domain" value="1" @checked(old('needs_domain', $product->needs_domain))><span>نیاز به دامنه دارد</span></label>
  <label class="check"><input type="checkbox" name="published" value="1" @checked(old('published', $product->published))><span>منتشر شود</span></label>
  <button class="btn" type="submit">ذخیره</button>
</form>
@endsection
