@extends('layouts.admin')
@section('title', 'محصولات')
@section('content')
<div class="head">
  <h1>محصولات</h1>
  <a class="btn" href="{{ route('admin.products.create') }}">محصول جدید</a>
</div>
<table>
  <thead><tr><th>عنوان</th><th>نوع</th><th>قیمت</th><th>وضعیت</th><th></th></tr></thead>
  <tbody>
  @foreach($products as $p)
    <tr>
      <td>{{ $p->title }}</td>
      <td>{{ $p->typeLabel() }} / {{ $p->categoryLabel() }}</td>
      <td class="ltr">{{ number_format($p->price) }}</td>
      <td>{{ $p->published ? 'منتشر' : 'پیش‌نویس' }}</td>
      <td style="white-space:nowrap">
        <a href="{{ route('admin.products.edit', $p) }}">ویرایش</a>
        <form method="POST" action="{{ route('admin.products.destroy', $p) }}" style="display:inline" onsubmit="return confirm('حذف شود؟')">@csrf @method('DELETE')
          <button type="submit">حذف</button>
        </form>
      </td>
    </tr>
  @endforeach
  </tbody>
</table>
@endsection
