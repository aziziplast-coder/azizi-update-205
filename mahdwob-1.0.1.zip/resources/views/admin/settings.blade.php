@extends('layouts.admin')
@section('title', 'تنظیمات')
@section('content')
<div class="head"><h1>تنظیمات</h1></div>
<form method="POST" action="{{ route('admin.settings.site') }}" class="card">
  @csrf
  <h2>سایت و کارت‌به‌کارت</h2>
  <div class="grid2">
    <div class="field"><label>نام برند</label><input name="brand" value="{{ old('brand', $s['brand'] ?? 'مهدوب') }}" required></div>
    <div class="field"><label>شعار</label><input name="tagline" value="{{ old('tagline', $s['tagline'] ?? 'طراحی و توسعه وب‌سایت') }}"></div>
    <div class="field"><label>شماره کارت</label><input class="ltr" name="card_number" value="{{ old('card_number', $s['card_number'] ?? '') }}" required></div>
    <div class="field"><label>صاحب کارت</label><input name="card_holder" value="{{ old('card_holder', $s['card_holder'] ?? '') }}" required></div>
    <div class="field"><label>تلفن</label><input class="ltr" name="contact_phone" value="{{ old('contact_phone', $s['contact_phone'] ?? '') }}"></div>
    <div class="field"><label>تلگرام</label><input class="ltr" name="contact_telegram" value="{{ old('contact_telegram', $s['contact_telegram'] ?? '') }}"></div>
    <div class="field"><label>ایمیل</label><input class="ltr" name="contact_email" type="email" value="{{ old('contact_email', $s['contact_email'] ?? '') }}"></div>
  </div>
  <button class="btn" type="submit">ذخیره</button>
</form>

<form method="POST" action="{{ route('admin.settings.password') }}" class="card">
  @csrf
  <h2>تغییر رمز مدیر</h2>
  <div class="grid2">
    <div class="field"><label>رمز فعلی</label><input class="ltr" type="password" name="current_password" required></div>
    <div class="field"><label>رمز جدید</label><input class="ltr" type="password" name="password" required></div>
    <div class="field"><label>تکرار رمز جدید</label><input class="ltr" type="password" name="password_confirmation" required></div>
  </div>
  <button class="btn" type="submit">تغییر رمز</button>
</form>
@endsection
