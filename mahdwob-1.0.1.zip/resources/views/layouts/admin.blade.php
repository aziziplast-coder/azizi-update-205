<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<title>@yield('title', 'پنل مهدوب')</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;800&family=JetBrains+Mono:wght@500&display=swap">
<link rel="stylesheet" href="{{ asset('css/admin.css') }}">
</head>
<body>
<header class="bar">
  <a class="brand" href="{{ route('admin.orders.index') }}"><span class="mark"></span><span>پنل مهدوب</span></a>
  <nav>
    <a href="{{ route('admin.orders.index') }}" @class(['on' => request()->routeIs('admin.orders*')])>سفارش‌ها</a>
    <a href="{{ route('admin.products.index') }}" @class(['on' => request()->routeIs('admin.products*')])>محصولات</a>
    <a href="{{ route('admin.settings') }}" @class(['on' => request()->routeIs('admin.settings')])>تنظیمات</a>
    <a href="{{ route('home') }}" target="_blank" rel="noopener">مشاهده سایت</a>
    <form method="POST" action="{{ route('admin.logout') }}" style="display:inline">@csrf<button type="submit">خروج</button></form>
  </nav>
</header>
<main class="box">
  @if(session('ok'))<div class="alert ok">{{ session('ok') }}</div>@endif
  @if(session('err'))<div class="alert err">{{ session('err') }}</div>@endif
  @yield('content')
</main>
</body>
</html>
