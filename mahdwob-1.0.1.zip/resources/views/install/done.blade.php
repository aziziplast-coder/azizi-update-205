<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>نصب انجام شد</title>
<link rel="stylesheet" href="{{ asset('css/admin.css') }}">
</head>
<body>
<main class="box" style="margin-top:30px">
  <h1>نصب انجام شد</h1>
  <div class="card">
    <div class="alert ok">فروشگاه لایسنس مهدوب آماده است. دیتابیس و جدول‌ها ساخته شدند.</div>
    @if(session('admin_email'))
      <p>ورود پنل با ایمیل: <b class="ltr">{{ session('admin_email') }}</b> و رمزی که هنگام نصب گذاشتید.</p>
    @endif
    <p><a class="btn" href="{{ url('/') }}">مشاهده سایت</a>
    <a class="btn" href="{{ url('/admin/login') }}" style="margin-inline-start:8px">ورود به پنل</a></p>
  </div>
</main>
</body>
</html>
