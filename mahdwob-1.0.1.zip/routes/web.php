<?php

use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\ProductController as AdminProductController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\InstallController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\StoreController;
use Illuminate\Support\Facades\Route;

Route::get('/', [StoreController::class, 'home'])->name('home');
Route::get('/product/{slug}', [StoreController::class, 'product'])->name('product.show');
Route::get('/order', [StoreController::class, 'orderForm'])->name('order.create');
Route::post('/order', [StoreController::class, 'orderStore'])->name('order.store');
Route::get('/order/{code}', [StoreController::class, 'orderShow'])->name('order.show');

Route::get('/install', [InstallController::class, 'show'])->name('install');
Route::post('/install', [InstallController::class, 'run'])->name('install.run');
Route::get('/install/done', [InstallController::class, 'done'])->name('install.done');

Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('login', [AuthController::class, 'login'])->middleware('throttle:10,1')->name('login.post');

    Route::middleware('auth')->group(function () {
        Route::post('logout', [AuthController::class, 'logout'])->name('logout');

        Route::get('/', fn () => redirect()->route('admin.orders.index'));

        Route::get('orders', [AdminOrderController::class, 'index'])->name('orders.index');
        Route::get('orders/{order}', [AdminOrderController::class, 'show'])->name('orders.show');
        Route::post('orders/{order}', [AdminOrderController::class, 'update'])->name('orders.update');
        Route::post('orders/{order}/activate', [AdminOrderController::class, 'activate'])->name('orders.activate');

        Route::resource('products', AdminProductController::class)->except(['show']);

        Route::get('settings', [SettingsController::class, 'show'])->name('settings');
        Route::post('settings/site', [SettingsController::class, 'updateSite'])->name('settings.site');
        Route::post('settings/password', [SettingsController::class, 'updatePassword'])->name('settings.password');
    });
});
