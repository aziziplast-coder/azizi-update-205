<?php

return [
    'version' => '1.0.1',
    'brand_default' => 'مهدوب',
];
