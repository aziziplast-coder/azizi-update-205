<?php

return [
    // نسخه برنامه (برای به‌روزرسانی و پشتیبان‌ها)
    'version' => '1.1.0',

    // cPanel connection (filled in by the installer or the settings page)
    'cpanel' => [
        'host' => env('CPANEL_HOST'),
        'port' => (int) env('CPANEL_PORT', 2083),
        'user' => env('CPANEL_USER'),
        'token' => env('CPANEL_TOKEN'),
        'root_domain' => env('CPANEL_ROOT_DOMAIN'),
        'verify_ssl' => filter_var(env('CPANEL_VERIFY_SSL', true), FILTER_VALIDATE_BOOLEAN),
    ],

    // Absolute path of the hosting account home (auto-detected when empty)
    'home' => env('STUDIO_HOME'),

    // Folder, relative to the home directory, that holds one folder per demo
    'demos_dir' => env('STUDIO_DEMOS_DIR', 'demos'),
];
