<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $fillable = ['key', 'value'];

    /** All settings as a key => value array. */
    public static function allKeyed(): array
    {
        return static::query()->pluck('value', 'key')->all();
    }

    public static function put(string $key, ?string $value): void
    {
        static::query()->updateOrCreate(['key' => $key], ['value' => $value]);
        static::$cache = null;
    }

    protected static ?array $cache = null;

    /** خواندن یک تنظیم (با کش در همین درخواست؛ اگر دیتابیس در دسترس نباشد مقدار پیش‌فرض) */
    public static function get(string $key, mixed $default = null): mixed
    {
        try {
            static::$cache ??= static::allKeyed();
        } catch (\Throwable) {
            return $default;
        }

        return array_key_exists($key, static::$cache) && static::$cache[$key] !== null ? static::$cache[$key] : $default;
    }

    public static function getJson(string $key): array
    {
        $v = json_decode((string) static::get($key, ''), true);

        return is_array($v) ? $v : [];
    }

    public static function putJson(string $key, array $value): void
    {
        static::put($key, json_encode($value, JSON_UNESCAPED_UNICODE));
    }

    public static function flush(): void
    {
        static::$cache = null;
    }
}
