<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Order extends Model
{
    protected $fillable = [
        'code', 'product_id', 'customer_name', 'customer_phone', 'customer_email',
        'domain', 'note', 'amount', 'status', 'license_key', 'admin_note',
        'paid_at', 'activated_at',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'integer',
            'paid_at' => 'datetime',
            'activated_at' => 'datetime',
        ];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public static function makeCode(): string
    {
        do {
            $code = 'MHD-'.strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        } while (static::query()->where('code', $code)->exists());

        return $code;
    }

    public function statusLabel(): string
    {
        return match ($this->status) {
            'awaiting_payment' => 'در انتظار واریز',
            'paid' => 'واریز شده / در صف فعال‌سازی',
            'activated' => 'فعال‌شده',
            'cancelled' => 'لغو شده',
            default => $this->status,
        };
    }

    public static function generateLicense(): string
    {
        $parts = [];
        for ($i = 0; $i < 4; $i++) {
            $parts[] = strtoupper(substr(bin2hex(random_bytes(2)), 0, 4));
        }

        return 'MHD-'.implode('-', $parts);
    }
}
