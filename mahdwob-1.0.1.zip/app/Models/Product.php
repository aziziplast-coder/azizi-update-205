<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    protected $fillable = [
        'title', 'slug', 'type', 'category', 'price', 'summary', 'description',
        'features', 'needs_domain', 'published', 'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'needs_domain' => 'boolean',
            'published' => 'boolean',
            'price' => 'integer',
            'sort_order' => 'integer',
        ];
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    public function scopePublished($query)
    {
        return $query->where('published', true)->orderBy('sort_order')->orderBy('id');
    }

    public function featureList(): array
    {
        $raw = trim((string) $this->features);
        if ($raw === '') {
            return [];
        }
        $json = json_decode($raw, true);
        if (is_array($json)) {
            return array_values(array_filter(array_map('strval', $json)));
        }

        return array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $raw) ?: [])));
    }

    public function typeLabel(): string
    {
        return match ($this->type) {
            'script' => 'اسکریپت',
            'plugin' => 'افزونه',
            default => $this->type,
        };
    }

    public function categoryLabel(): string
    {
        return match ($this->category) {
            'shop' => 'فروشگاهی',
            'corporate' => 'شرکتی',
            default => $this->category ?: 'عمومی',
        };
    }
}
