<?php

namespace App\Support;

class Paths
{
    /** Absolute path of the hosting account home directory. */
    public static function home(): string
    {
        $configured = config('studio.home');
        if ($configured) {
            return rtrim((string) $configured, '/');
        }
        $base = str_replace('\\', '/', base_path());
        $pos = strpos($base, '/public_html');
        if ($pos !== false) {
            return substr($base, 0, $pos);
        }
        if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
            $info = @posix_getpwuid(@posix_geteuid());
            if (! empty($info['dir'])) {
                return rtrim($info['dir'], '/');
            }
        }
        $env = getenv('HOME');
        if ($env) {
            return rtrim($env, '/');
        }

        return rtrim(dirname($base), '/');
    }

    /** Folder of a demo, relative to the home directory (what cPanel expects). */
    public static function demoRelative(string $sub): string
    {
        return trim((string) config('studio.demos_dir', 'demos'), '/').'/'.$sub;
    }

    public static function demoDir(string $sub): string
    {
        return self::home().'/'.self::demoRelative($sub);
    }
}
