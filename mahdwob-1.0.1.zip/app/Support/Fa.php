<?php

namespace App\Support;

class Fa
{
    /** Latin digits to Persian digits. */
    public static function digits(string|int $value): string
    {
        return strtr((string) $value, [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
        ]);
    }

    /** Format toman amount with Persian digits and separators. */
    public static function money(int|string $amount): string
    {
        return self::digits(number_format((int) $amount)).' تومان';
    }

    /** Persian validation messages, shared by all forms. */
    public static function messages(): array
    {
        return [
            'required' => 'این فیلد را پر کنید.',
            'required_if' => 'این فیلد را پر کنید.',
            'email' => 'ایمیل معتبر وارد کنید.',
            'url' => 'آدرس معتبر وارد کنید، مثل https://example.com',
            'unique' => 'این مقدار قبلاً ثبت شده است.',
            'confirmed' => 'تکرار رمز عبور با رمز عبور یکی نیست.',
            'min.string' => 'حداقل :min کاراکتر وارد کنید.',
            'max.string' => 'حداکثر :max کاراکتر مجاز است.',
            'regex' => 'قالب وارد شده درست نیست.',
            'in' => 'مقدار انتخاب‌شده معتبر نیست.',
            'integer' => 'یک عدد صحیح وارد کنید.',
            'file' => 'فایل معتبر انتخاب کنید.',
            'mimes' => 'فقط فایل zip مجاز است.',
            'uploaded' => 'آپلود فایل انجام نشد. حجم فایل از حد مجاز هاست بیشتر است.',
            'current_password' => 'رمز عبور فعلی درست نیست.',
        ];
    }
}
