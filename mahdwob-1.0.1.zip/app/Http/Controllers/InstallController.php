<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Setting;
use App\Models\User;
use App\Services\EnvWriter;
use App\Support\Fa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Throwable;

class InstallController extends Controller
{
    private function checks(): array
    {
        $items = [[
            'label' => 'نسخه PHP (حداقل ۸٫۲): '.PHP_VERSION,
            'ok' => version_compare(PHP_VERSION, '8.2.0', '>='),
            'required' => true,
        ]];
        foreach (['mbstring', 'openssl', 'tokenizer', 'xml', 'ctype', 'json', 'fileinfo', 'pdo'] as $ext) {
            $items[] = ['label' => 'افزونه '.$ext, 'ok' => extension_loaded($ext), 'required' => true];
        }
        $items[] = [
            'label' => 'افزونه pdo_sqlite یا pdo_mysql',
            'ok' => extension_loaded('pdo_sqlite') || extension_loaded('pdo_mysql'),
            'required' => true,
        ];
        $items[] = ['label' => 'پوشه storage قابل نوشتن', 'ok' => is_writable(storage_path()), 'required' => true];
        $items[] = ['label' => 'پوشه bootstrap/cache قابل نوشتن', 'ok' => is_writable(base_path('bootstrap/cache')), 'required' => true];

        return $items;
    }

    public function show()
    {
        $checks = $this->checks();
        $blocked = count(array_filter($checks, fn ($c) => $c['required'] && ! $c['ok'])) > 0;
        $canSqlite = extension_loaded('pdo_sqlite') && is_writable(storage_path());

        return view('install.index', compact('checks', 'blocked', 'canSqlite'));
    }

    public function run(Request $request)
    {
        foreach ($this->checks() as $c) {
            if ($c['required'] && ! $c['ok']) {
                return back()->with('err', 'پیش‌نیاز کامل نیست: '.$c['label']);
            }
        }

        // نصب فوری: فقط SQLite — دیتابیس و جدول‌ها خودکار
        if ($request->boolean('quick')) {
            $data = $request->validate([
                'admin_password' => ['required', 'string', 'min:8', 'confirmed'],
                'brand' => ['nullable', 'string', 'max:80'],
                'admin_email' => ['nullable', 'email', 'max:120'],
                'card_number' => ['nullable', 'string', 'max:40'],
                'card_holder' => ['nullable', 'string', 'max:80'],
            ], Fa::messages());

            $data['db_mode'] = 'sqlite';
            $data['brand'] = $data['brand'] ?: 'مهدوب';
            $data['admin_name'] = 'مدیر';
            $data['admin_email'] = $data['admin_email'] ?: 'admin@mahdwob.ir';
            $data['card_number'] = $data['card_number'] ?: '6037-9971-1234-5678';
            $data['card_holder'] = $data['card_holder'] ?: 'مهدوب';

            return $this->finishInstall($data, $request->except(['admin_password', 'admin_password_confirmation']));
        }

        $data = $request->validate([
            'db_mode' => ['required', 'in:sqlite,manual'],
            'db_host' => ['nullable', 'string', 'max:120'],
            'db_port' => ['nullable', 'integer'],
            'db_name' => ['required_if:db_mode,manual', 'nullable', 'string', 'max:64'],
            'db_user' => ['required_if:db_mode,manual', 'nullable', 'string', 'max:64'],
            'db_pass' => ['nullable', 'string', 'max:200'],
            'brand' => ['required', 'string', 'max:80'],
            'admin_name' => ['required', 'string', 'max:80'],
            'admin_email' => ['required', 'email', 'max:120'],
            'admin_password' => ['required', 'string', 'min:8', 'confirmed'],
            'card_number' => ['required', 'string', 'max:40'],
            'card_holder' => ['required', 'string', 'max:80'],
        ], Fa::messages());

        return $this->finishInstall($data, $request->except(['admin_password', 'admin_password_confirmation', 'db_pass']));
    }

    private function finishInstall(array $data, array $keep)
    {
        $sqlitePath = storage_path('app/database/mahdwob.sqlite');
        @mkdir(dirname($sqlitePath), 0755, true);

        try {
            if ($data['db_mode'] === 'sqlite') {
                if (! extension_loaded('pdo_sqlite')) {
                    return back()->withInput($keep)->with('err', 'pdo_sqlite فعال نیست.');
                }
                if (! is_file($sqlitePath)) {
                    file_put_contents($sqlitePath, '');
                }
                $env = [
                    'APP_NAME' => $data['brand'],
                    'APP_ENV' => 'production',
                    'APP_DEBUG' => 'false',
                    'APP_URL' => url('/'),
                    'APP_KEY' => 'base64:'.base64_encode(random_bytes(32)),
                    'DB_CONNECTION' => 'sqlite',
                    'DB_DATABASE' => $sqlitePath,
                    'SESSION_DRIVER' => 'file',
                    'CACHE_STORE' => 'file',
                ];
                config([
                    'database.default' => 'sqlite',
                    'database.connections.sqlite.database' => $sqlitePath,
                ]);
            } else {
                $host = $data['db_host'] ?: '127.0.0.1';
                $port = (int) ($data['db_port'] ?? 3306) ?: 3306;
                $env = [
                    'APP_NAME' => $data['brand'],
                    'APP_ENV' => 'production',
                    'APP_DEBUG' => 'false',
                    'APP_URL' => url('/'),
                    'APP_KEY' => 'base64:'.base64_encode(random_bytes(32)),
                    'DB_CONNECTION' => 'mysql',
                    'DB_HOST' => $host,
                    'DB_PORT' => (string) $port,
                    'DB_DATABASE' => $data['db_name'],
                    'DB_USERNAME' => $data['db_user'],
                    'DB_PASSWORD' => (string) ($data['db_pass'] ?? ''),
                    'SESSION_DRIVER' => 'file',
                    'CACHE_STORE' => 'file',
                ];
                config([
                    'database.default' => 'mysql',
                    'database.connections.mysql.host' => $host,
                    'database.connections.mysql.port' => $port,
                    'database.connections.mysql.database' => $data['db_name'],
                    'database.connections.mysql.username' => $data['db_user'],
                    'database.connections.mysql.password' => (string) ($data['db_pass'] ?? ''),
                ]);
            }

            DB::purge();
            DB::reconnect();
            DB::connection()->getPdo();

            EnvWriter::update(base_path('.env'), $env);
            Artisan::call('migrate', ['--force' => true]);

            User::query()->delete();
            User::create([
                'name' => $data['admin_name'],
                'email' => $data['admin_email'],
                'password' => Hash::make($data['admin_password']),
            ]);

            Setting::put('brand', $data['brand']);
            Setting::put('tagline', 'طراحی و توسعه وب‌سایت');
            Setting::put('card_number', $data['card_number']);
            Setting::put('card_holder', $data['card_holder']);

            $this->seedProducts();

            file_put_contents(storage_path('app/installed.lock'), now()->toDateTimeString());

            return redirect()->route('install.done')->with([
                'admin_email' => $data['admin_email'],
            ]);
        } catch (Throwable $e) {
            return back()->withInput($keep)->with('err', 'نصب انجام نشد: '.$e->getMessage());
        }
    }

    public function done()
    {
        return view('install.done');
    }

    private function seedProducts(): void
    {
        if (Product::query()->exists()) {
            return;
        }

        $items = [
            [
                'title' => 'اسکریپت فروشگاه عمده و خرده',
                'slug' => 'shop-script',
                'type' => 'script',
                'category' => 'shop',
                'price' => 4900000,
                'summary' => 'کاتالوگ، سبد، فاکتور، انبار و پنل مدیریت — مناسب فروش کارتنی و تکی.',
                'description' => 'نصب روی هاست خودتان، اتصال به دامنه، پنل مدیریت کامل.',
                'features' => "کاتالوگ، سبد خرید، فاکتور و انبار\nلایسنس قفل‌شده روی یک دامنه\nآماده اتصال افزونه‌های مهدوب\nراهنمای نصب و پشتیبانی فعال‌سازی",
                'needs_domain' => true,
                'sort_order' => 1,
            ],
            [
                'title' => 'اسکریپت سایت شرکتی',
                'slug' => 'corporate-script',
                'type' => 'script',
                'category' => 'corporate',
                'price' => 2900000,
                'summary' => 'معرفی شرکت، خدمات، گالری، مقالات و فرم تماس با پنل محتوای ساده.',
                'description' => 'اسکریپت شرکتی آماده نصب با لایسنس تک‌دامنه.',
                'features' => "صفحات معرفی و خدمات\nگالری و مقالات\nفرم تماس\nپنل مدیریت محتوا",
                'needs_domain' => true,
                'sort_order' => 2,
            ],
            [
                'title' => 'افزونه درگاه زرین‌پال',
                'slug' => 'zarinpal-plugin',
                'type' => 'plugin',
                'category' => 'other',
                'price' => 890000,
                'summary' => 'اتصال پرداخت آنلاین به فروشگاه مهدوب.',
                'description' => 'افزونه لاراولی قابل اتصال به اسکریپت فروشگاهی.',
                'features' => "اتصال زرین‌پال\nثبت تراکنش در پنل\nسازگار با اسکریپت فروشگاهی مهدوب",
                'needs_domain' => false,
                'sort_order' => 10,
            ],
            [
                'title' => 'افزونه پیامک و اعلان سفارش',
                'slug' => 'sms-plugin',
                'type' => 'plugin',
                'category' => 'other',
                'price' => 690000,
                'summary' => 'ارسال پیامک وضعیت سفارش به مشتری و مدیر.',
                'description' => 'افزونه پیامک برای اسکریپت‌های مهدوب.',
                'features' => "اعلان سفارش جدید\nاطلاع به مشتری\nقابل تنظیم پنل پیامک",
                'needs_domain' => false,
                'sort_order' => 11,
            ],
            [
                'title' => 'افزونه باشگاه مشتریان',
                'slug' => 'loyalty-plugin',
                'type' => 'plugin',
                'category' => 'other',
                'price' => 1200000,
                'summary' => 'امتیاز خرید و سطح‌بندی مشتری روی همان اسکریپت.',
                'description' => 'باشگاه مشتریان متصل به اسکریپت فروشگاهی.',
                'features' => "امتیاز خرید\nسطح‌بندی مشتری\nگزارش در پنل",
                'needs_domain' => false,
                'sort_order' => 12,
            ],
        ];

        foreach ($items as $item) {
            Product::create($item + ['published' => true]);
        }
    }
}
