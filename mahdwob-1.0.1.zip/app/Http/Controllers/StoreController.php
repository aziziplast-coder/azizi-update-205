<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\Setting;
use App\Support\Fa;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class StoreController extends Controller
{
    private function brand(): string
    {
        return Setting::get('brand', config('mahdwob.brand_default', 'مهدوب'));
    }

    private function cardInfo(): array
    {
        return [
            'number' => Setting::get('card_number', '6037-9971-1234-5678'),
            'holder' => Setting::get('card_holder', 'مهدوب'),
        ];
    }

    public function home()
    {
        $scripts = Product::published()->where('type', 'script')->get();
        $plugins = Product::published()->where('type', 'plugin')->get();
        $brand = $this->brand();
        $tagline = Setting::get('tagline', 'طراحی و توسعه وب‌سایت');

        return view('site.home', compact('scripts', 'plugins', 'brand', 'tagline'));
    }

    public function product(string $slug)
    {
        $product = Product::published()->where('slug', $slug)->firstOrFail();
        $brand = $this->brand();

        return view('site.product', compact('product', 'brand'));
    }

    public function orderForm(Request $request)
    {
        $products = Product::published()->get();
        $selected = null;
        if ($request->filled('product')) {
            $selected = $products->firstWhere('slug', $request->string('product')->toString())
                ?: $products->firstWhere('id', (int) $request->input('product'));
        }
        $brand = $this->brand();

        return view('site.order', [
            'products' => $products,
            'selected' => $selected,
            'brand' => $brand,
            'order' => null,
            'card' => $this->cardInfo(),
        ]);
    }

    public function orderStore(Request $request)
    {
        $products = Product::published()->pluck('id')->all();
        $data = $request->validate([
            'product_id' => ['required', 'integer', Rule::in($products)],
            'customer_name' => ['required', 'string', 'max:80'],
            'customer_phone' => ['required', 'string', 'max:20'],
            'customer_email' => ['nullable', 'email', 'max:120'],
            'domain' => ['nullable', 'string', 'max:120'],
            'note' => ['nullable', 'string', 'max:1000'],
        ], Fa::messages());

        $product = Product::published()->findOrFail($data['product_id']);
        if ($product->needs_domain && blank($data['domain'] ?? null)) {
            return back()->withInput()->with('err', 'برای این محصول دامنه نصب را وارد کنید.');
        }

        $order = Order::create([
            'code' => Order::makeCode(),
            'product_id' => $product->id,
            'customer_name' => $data['customer_name'],
            'customer_phone' => $data['customer_phone'],
            'customer_email' => $data['customer_email'] ?? null,
            'domain' => $data['domain'] ?? null,
            'note' => $data['note'] ?? null,
            'amount' => $product->price,
            'status' => 'awaiting_payment',
        ]);

        return redirect()->route('order.show', $order->code);
    }

    public function orderShow(string $code)
    {
        $order = Order::with('product')->where('code', $code)->firstOrFail();
        $brand = $this->brand();
        $products = Product::published()->get();

        return view('site.order', [
            'products' => $products,
            'selected' => $order->product,
            'brand' => $brand,
            'order' => $order,
            'card' => $this->cardInfo(),
        ]);
    }
}
