<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Support\Fa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class SettingsController extends Controller
{
    public function show()
    {
        $s = Setting::allKeyed();

        return view('admin.settings', compact('s'));
    }

    public function updateSite(Request $request)
    {
        $data = $request->validate([
            'brand' => ['required', 'string', 'max:80'],
            'tagline' => ['nullable', 'string', 'max:120'],
            'card_number' => ['required', 'string', 'max:40'],
            'card_holder' => ['required', 'string', 'max:80'],
            'contact_phone' => ['nullable', 'string', 'max:40'],
            'contact_telegram' => ['nullable', 'string', 'max:80'],
            'contact_email' => ['nullable', 'email', 'max:120'],
        ], Fa::messages());

        foreach ($data as $k => $v) {
            Setting::put($k, $v);
        }

        return back()->with('ok', 'تنظیمات ذخیره شد.');
    }

    public function updatePassword(Request $request)
    {
        $data = $request->validate([
            'current_password' => ['required', 'current_password'],
            'password' => ['required', 'confirmed', Password::min(8)],
        ], Fa::messages());

        $user = Auth::user();
        $user->password = Hash::make($data['password']);
        $user->save();

        return back()->with('ok', 'رمز عبور عوض شد.');
    }
}
