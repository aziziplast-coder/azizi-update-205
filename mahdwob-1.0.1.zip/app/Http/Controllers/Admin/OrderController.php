<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Support\Fa;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $q = Order::with('product')->orderByDesc('id');
        if ($request->filled('status')) {
            $q->where('status', $request->string('status'));
        }
        $orders = $q->get();

        return view('admin.orders.index', compact('orders'));
    }

    public function show(Order $order)
    {
        $order->load('product');

        return view('admin.orders.show', compact('order'));
    }

    public function update(Request $request, Order $order)
    {
        $data = $request->validate([
            'status' => ['required', Rule::in(['awaiting_payment', 'paid', 'activated', 'cancelled'])],
            'license_key' => ['nullable', 'string', 'max:80'],
            'admin_note' => ['nullable', 'string', 'max:2000'],
        ], Fa::messages());

        $order->status = $data['status'];
        $order->admin_note = $data['admin_note'] ?? $order->admin_note;

        if ($data['status'] === 'paid' && ! $order->paid_at) {
            $order->paid_at = now();
        }
        if ($data['status'] === 'activated') {
            $order->license_key = $data['license_key'] ?: ($order->license_key ?: Order::generateLicense());
            $order->activated_at = $order->activated_at ?: now();
            $order->paid_at = $order->paid_at ?: now();
        } elseif (! blank($data['license_key'] ?? null)) {
            $order->license_key = $data['license_key'];
        }

        $order->save();

        return back()->with('ok', 'سفارش به‌روز شد.');
    }

    public function activate(Order $order)
    {
        $order->status = 'activated';
        $order->license_key = $order->license_key ?: Order::generateLicense();
        $order->activated_at = now();
        $order->paid_at = $order->paid_at ?: now();
        $order->save();

        return back()->with('ok', 'لایسنس فعال شد: '.$order->license_key);
    }
}
