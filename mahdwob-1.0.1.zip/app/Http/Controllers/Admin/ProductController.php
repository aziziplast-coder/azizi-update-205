<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Support\Fa;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::query()->orderBy('sort_order')->orderByDesc('id')->get();

        return view('admin.products.index', compact('products'));
    }

    public function create()
    {
        return view('admin.products.form', ['product' => new Product([
            'type' => 'script',
            'category' => 'shop',
            'published' => true,
            'needs_domain' => true,
            'price' => 0,
        ])]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        Product::create($data);

        return redirect()->route('admin.products.index')->with('ok', 'محصول ذخیره شد.');
    }

    public function edit(Product $product)
    {
        return view('admin.products.form', compact('product'));
    }

    public function update(Request $request, Product $product)
    {
        $product->update($this->validated($request, $product));

        return redirect()->route('admin.products.index')->with('ok', 'محصول به‌روز شد.');
    }

    public function destroy(Product $product)
    {
        $product->delete();

        return redirect()->route('admin.products.index')->with('ok', 'محصول حذف شد.');
    }

    private function validated(Request $request, ?Product $product = null): array
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:120'],
            'slug' => ['nullable', 'string', 'max:140', Rule::unique('products', 'slug')->ignore($product?->id)],
            'type' => ['required', Rule::in(['script', 'plugin'])],
            'category' => ['nullable', 'string', 'max:40'],
            'price' => ['required', 'integer', 'min:0'],
            'summary' => ['nullable', 'string', 'max:500'],
            'description' => ['nullable', 'string', 'max:5000'],
            'features' => ['nullable', 'string', 'max:3000'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ], Fa::messages());

        $data['slug'] = $data['slug'] ?: Str::slug($data['title']) ?: 'product-'.Str::random(6);
        $data['needs_domain'] = $request->boolean('needs_domain');
        $data['published'] = $request->boolean('published');
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);
        // store features as newline text (Product::featureList supports both)
        return $data;
    }
}
