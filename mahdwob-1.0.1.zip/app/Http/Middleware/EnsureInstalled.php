<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureInstalled
{
    public function handle(Request $request, Closure $next): Response
    {
        $installed = is_file(storage_path('app/installed.lock'));
        $isInstaller = $request->is('install') || $request->is('install/*');

        if (! $installed && ! $isInstaller && ! $request->is('up')) {
            return redirect('/install');
        }
        if ($installed && $isInstaller && ! $request->is('install/done')) {
            abort(404);
        }

        return $next($request);
    }
}
