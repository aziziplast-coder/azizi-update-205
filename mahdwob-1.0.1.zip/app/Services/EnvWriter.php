<?php

namespace App\Services;

/** Reads and updates a .env file without touching unrelated lines. */
class EnvWriter
{
    public static function quote(string $value): string
    {
        if ($value === '' || preg_match('/[\s#"\'\\\\$]/', $value)) {
            if (! str_contains($value, "'")) {
                return "'".$value."'";
            }

            return '"'.str_replace(['\\', '"', '$'], ['\\\\', '\\"', '\\$'], $value).'"';
        }

        return $value;
    }

    /** Builds the text of a new .env file. */
    public static function render(array $pairs): string
    {
        $lines = [];
        foreach ($pairs as $key => $value) {
            $lines[] = $key.'='.self::quote((string) $value);
        }

        return implode("\n", $lines)."\n";
    }

    /** Sets keys in an existing file (creating it when missing). Returns false when it cannot be written. */
    public static function update(string $path, array $pairs): bool
    {
        $content = is_file($path) ? (string) file_get_contents($path) : '';
        $lines = $content === '' ? [] : preg_split('/\r\n|\n|\r/', rtrim($content, "\r\n"));

        foreach ($pairs as $key => $value) {
            $new = $key.'='.self::quote((string) $value);
            $found = false;
            foreach ($lines as $i => $line) {
                if (preg_match('/^\s*'.preg_quote((string) $key, '/').'\s*=/', $line)) {
                    $lines[$i] = $new;
                    $found = true;
                    break;
                }
            }
            if (! $found) {
                $lines[] = $new;
            }
        }

        return @file_put_contents($path, implode("\n", $lines)."\n") !== false;
    }

    /** Reads KEY=VALUE pairs (simple parser, enough for our own files). */
    public static function read(string $path): array
    {
        $out = [];
        if (! is_file($path)) {
            return $out;
        }
        foreach (preg_split('/\r\n|\n|\r/', (string) file_get_contents($path)) as $line) {
            if (preg_match('/^\s*([A-Z0-9_]+)\s*=\s*(.*)$/', $line, $m)) {
                $v = trim($m[2]);
                if (strlen($v) >= 2 && $v[0] === '"' && substr($v, -1) === '"') {
                    $v = stripcslashes(substr($v, 1, -1));
                } elseif (strlen($v) >= 2 && $v[0] === "'" && substr($v, -1) === "'") {
                    $v = substr($v, 1, -1);
                }
                $out[$m[1]] = $v;
            }
        }

        return $out;
    }
}
