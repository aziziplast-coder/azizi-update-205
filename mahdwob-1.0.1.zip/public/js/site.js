(function () {
  function reveal() {
    document.querySelectorAll('.product.reveal, .reveal').forEach(function (el) {
      if (el.getBoundingClientRect().top < innerHeight * 0.9) el.classList.add('in');
    });
  }
  addEventListener('scroll', reveal, { passive: true });
  reveal();

  var tt;
  function toast(msg) {
    var t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('on');
    clearTimeout(tt);
    tt = setTimeout(function () { t.classList.remove('on'); }, 1600);
  }

  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copy]');
    if (!b) return;
    var text = b.getAttribute('data-copy') || '';
    var done = function () { toast('کپی شد'); };
    var fail = function () {
      try {
        var ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        done();
      } catch (_) {
        toast('کپی نشد');
      }
    };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, fail);
    else fail();
  });
})();
