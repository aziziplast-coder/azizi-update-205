<?php

use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// نسخه PHP هاست کمتر از نیاز برنامه است: پیام فارسی به‌جای خطای انگلیسی
if (PHP_VERSION_ID < 80200) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>نسخه PHP</title>'
        .'<body style="font-family:Tahoma,sans-serif;max-width:560px;margin:60px auto;padding:0 16px;line-height:2">'
        .'<h2>نسخه PHP هاست را بالا ببرید</h2><p>نسخه فعلی: <b dir="ltr">'.PHP_VERSION.'</b> — این سایت به <b>PHP 8.2 یا بالاتر</b> (پیشنهاد: 8.3) نیاز دارد.</p>'
        .'<ol><li>وارد cPanel شوید.</li><li>بخش <b>Select PHP Version</b> یا <b>MultiPHP Manager</b> را باز کنید.</li><li>نسخه <b>8.3</b> را برای این دامنه انتخاب و ذخیره کنید.</li><li>این صفحه را دوباره باز کنید.</li></ol></body></html>';
    exit;
}

// در حال به‌روزرسانی (چند ثانیه جابه‌جایی فایل‌ها): صفحه کوتاه «چند ثانیه صبر کنید»
$updFlag = __DIR__.'/../storage/framework/updating';
if (is_file($updFlag) && @filemtime($updFlag) > time() - 240) {
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
    if (! preg_match('~^/(health-check|up)(\?|$)~', $uri) && ! str_contains($uri, 'tools/update')) {
        http_response_code(503);
        header('Retry-After: 6');
        header('Cache-Control: no-store');
        header('Content-Type: text/html; charset=utf-8');
        exit('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="6"><title>در حال به‌روزرسانی</title>'
            .'<body style="font-family:Tahoma,sans-serif;background:#0A1430;color:#F2EEE2;display:grid;place-items:center;min-height:90vh;margin:0"><div style="text-align:center;line-height:2">'
            .'<div style="font-size:40px">⏳</div><b>سایت در حال به‌روزرسانی است</b><br><span style="color:#9AA7C6">چند ثانیه دیگر خودکار باز می‌شود…</span></div></body></html>');
    }
}

// اولین اجرا روی هاست: اگر فایل .env نیست، با کلید امن ساخته شود تا نصب‌کننده باز شود
if (! file_exists(__DIR__.'/../.env') && file_exists(__DIR__.'/../.env.example')) {
    $env = (string) file_get_contents(__DIR__.'/../.env.example');
    $env = preg_replace('/^APP_KEY=.*$/m', 'APP_KEY=base64:'.base64_encode(random_bytes(32)), $env);
    @file_put_contents(__DIR__.'/../.env', $env);
}

if (! is_file(__DIR__.'/../vendor/autoload.php')) {
    http_response_code(503);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        .'<title>نصب ناقص است</title><body style="font-family:Tahoma,sans-serif;max-width:560px;margin:60px auto;padding:0 16px;line-height:2">'
        .'<h2>پوشه vendor پیدا نشد</h2>'
        .'<p>پکیج‌های لاراول هنوز نصب نشده‌اند. از پشتیبان هاست بخواهید در پوشه اصلی پروژه این دستور را اجرا کند:</p>'
        .'<pre style="direction:ltr;background:#eee;padding:12px;border-radius:8px">composer install --no-dev --optimize-autoloader</pre>'
        .'<p>یا پوشه vendor را از نسخه کامل پروژه آپلود کنید.</p></body></html>';
    exit;
}

if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) {
    require $maintenance;
}

require __DIR__.'/../vendor/autoload.php';

(require_once __DIR__.'/../bootstrap/app.php')->handleRequest(Request::capture());
