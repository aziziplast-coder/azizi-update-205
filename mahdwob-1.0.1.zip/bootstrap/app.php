<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->redirectGuestsTo(fn () => route('admin.login'));
        $middleware->redirectUsersTo('/admin');
        $middleware->web(append: [
            \App\Http\Middleware\EnsureInstalled::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        // فایل بزرگ‌تر از حد مجاز هاست: پیام فارسی به‌جای صفحه خطا
        $exceptions->render(function (\Illuminate\Http\Exceptions\PostTooLargeException $e, $request) {
            $msg = 'حجم فایل از حد مجاز آپلود این هاست ('.ini_get('post_max_size').') بیشتر است. '
                .'در cPanel بخش Select PHP Version ← Options مقدار upload_max_filesize و post_max_size را بیشتر کنید، '
                .'یا (برای به‌روزرسانی) فایل zip را با File Manager در پوشه storage/app/update آپلود کنید.';

            $back = e(url()->previous() ?: '/admin');

            return response('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>حجم فایل زیاد است</title>'
                .'<body style="font-family:Tahoma,sans-serif;background:#0A1430;color:#F2EEE2;max-width:600px;margin:60px auto;padding:0 16px;line-height:2.1">'
                .'<h2 style="color:#F2BE3A">حجم فایل زیاد است</h2><p>'.e($msg).'</p><p><a href="'.$back.'" style="color:#F2BE3A">بازگشت</a></p></body></html>', 413);
        });
    })->create();
