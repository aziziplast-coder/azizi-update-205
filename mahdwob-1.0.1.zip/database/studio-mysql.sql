-- جدول‌های سایت نمونه‌کار برای ساخت دستی دیتابیس MySQL
-- فقط وقتی لازم است که نصب‌کننده (/install) نتوانسته جدول‌ها را بسازد:
-- phpMyAdmin ← انتخاب دیتابیس ← Import ← همین فایل ← Go. بعد دوباره /install را باز و «نصب» را بزنید.
-- (حساب مدیر و نمونه‌کارهای اولیه را خود نصب‌کننده می‌سازد)

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `works` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tech` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kind` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'generic',
  `color` varchar(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#F2BE3A',
  `description` text COLLATE utf8mb4_unicode_ci,
  `demo_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `panel_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `demo_user` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `demo_pass` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subdomain` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `demo_kind` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `db_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `db_user` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `db_pass` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `works_subdomain_unique` (`subdomain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`migration`, `batch`)
SELECT * FROM (SELECT '2024_01_01_000001_create_users_table' AS m, 1 AS b) t WHERE NOT EXISTS (SELECT 1 FROM `migrations` WHERE `migration` = '2024_01_01_000001_create_users_table');
INSERT INTO `migrations` (`migration`, `batch`)
SELECT * FROM (SELECT '2024_01_01_000002_create_works_table' AS m, 1 AS b) t WHERE NOT EXISTS (SELECT 1 FROM `migrations` WHERE `migration` = '2024_01_01_000002_create_works_table');
INSERT INTO `migrations` (`migration`, `batch`)
SELECT * FROM (SELECT '2024_01_01_000003_create_settings_table' AS m, 1 AS b) t WHERE NOT EXISTS (SELECT 1 FROM `migrations` WHERE `migration` = '2024_01_01_000003_create_settings_table');

SET FOREIGN_KEY_CHECKS=1;
