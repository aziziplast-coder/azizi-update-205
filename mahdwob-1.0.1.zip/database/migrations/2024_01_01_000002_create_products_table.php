<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('slug')->unique();
            $table->string('type', 20); // script | plugin
            $table->string('category', 40)->nullable(); // shop | corporate | other
            $table->unsignedInteger('price'); // تومان
            $table->text('summary')->nullable();
            $table->text('description')->nullable();
            $table->text('features')->nullable(); // JSON array as text
            $table->boolean('needs_domain')->default(true);
            $table->boolean('published')->default(true);
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
