<?php

/**
 * Fallback for hosts that ignore root .htaccess rewrite.
 * Extract zip into public_html, then open the domain — this file boots Laravel.
 */
require __DIR__.'/public/index.php';
